# Critical compression: exact source-form argument

Status: ordinary mathematical derivation, independently reconstructed; no new
Lean term, kernel replay, or RH closure. The screenshot provides no evaluator
source or explicit target compression inequality. The following result applies
to the definitions below, not automatically to an unknown screenshot program.

## Definitions and exact source normalization

Let phi be a nonzero C-infinity compactly supported complex function with
support in [-R,R], R>0. For an integer m>=1 put d=2m,
P(D)=(D^2-1/4)^m, and for s>=1 define

  H_s(x)=s^(1/2-d) P(D)[phi(s x)].

Then H_s(x)=sqrt(s) F_s(s x), where

  F_s(u)=sum_{j=0}^m binomial(m,j)(-1/4)^(m-j)
                            s^(2j-2m) phi^(2j)(u).

Thus F_s -> A=phi^(d) in H^1 with error O(s^-2), and
E_s=||H_s||_2^2=||F_s||_2^2=E+O(s^-2), E=||phi^(d)||_2^2>0.
Compact support makes every nonzero phi have nonzero d-th derivative.
The critical amplitude is |c_s|^2=s^(1-2d), hence s^-3,s^-7,s^-11
for differential orders2,4,6 respectively. Here compression was phi(s x)
BEFORE applying P(D); changing that convention changes amplitude powers.

Repeated integration by parts gives both moments integral exp(+-x/2)H_s=0,
since P(+1/2)=P(-1/2)=0. All boundary terms vanish. The actual source carrier
is W_s(y)=y^-1/2 H_s(log y) for y>0, zero otherwise. This has the source's
two moments integral W_s/y=integral W_s=0, positive compact support and
energy E_s by y=exp(x). No surrogate quadratic is introduced.

For H write C_H(t)=integral H(x+t) conjugate H(x) dx and E_H=C_H(0).
Define Q(H)=-Re WeilExplicitRightSideV1(autocorrelation W_H). On the legal
moment-zero carrier the existing exact explicit formula identifies this with
the actual zero quadratic. Source constants and ordinary measures are those
of AegisRH/PR606/WeilCriterionCompactSmoothV1.lean at
f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f, blob
1223d431c79cada6c7865b83b855e752f280c67c.

The original Arch integrand, under y=exp(t), is EXACTLY

  I(H)=integral_0^infty [exp(t/2) Re C_H(t)-E_H]/sinh(t) dt,
  C0=log(4*pi)+gamma.

When2R/s<log2, every prime-power sample vanishes individually, including all
higher powers; Lambda(1)=0. Therefore Q(H_s)=-C0 E_s-I(H_s).
The pole terms vanish by the two source moments. The infinite Arch tail does
NOT vanish and must be retained.

## Full logarithmic asymptotic, including the tail

Let L=2R. C_Hs(t)=C_Fs(s t) and is zero for |t|>L/s. Split I at L/s.
The tail is evaluated exactly:

  I_tail=E_s log(tanh(L/(2s))).

On the near interval, change variable u=s t:

  I_near=integral_0^L [exp(u/(2s)) Re C_Fs(u)-E_s]
                                      /[s sinh(u/s)] du.

For every compact smooth F,
Re C_F(u)-||F||^2=-||F(.-u)-F||^2/2,
and its magnitude is at most u^2||F'||^2/2. The H^1 norms of F_s are
uniformly bounded for fixed phi and m. Also s sinh(u/s)>=u. The separate
exp correction is bounded by a constant, since
(exp(u/(2s))-1)/u<=exp(L/2)/(2s). These give an integrable dominating function
on [0,L]. Dominated convergence now proves

  I_near -> integral_0^L [Re C_A(u)-E]/u du = J.

Using tanh(z)/z->1 and (E_s-E)log(s)->0 in the exact tail gives

  Q(H_s)=E log(s)+K+o(1),
  K=-C0 E-E log(L/2)-J.

All integrals displayed in K converge. This establishes a positive leading
coefficient for EVERY fixed seed and fixed m, without numerical quadrature,
a digamma approximation, or omission of any infinite tail.

The fixed-seed asymptotic does not assert a uniform remainder over all phi,m.
For a target upper bound independent of s, critical power normalization alone
is insufficient: the positive E log(s) diverges. A further squared-amplitude
factor1/log(s) is the critical logarithmic correction in this fixed family.
For a lower-sign target, the positive logarithm instead helps. The intended
inequality from the screenshot must be specified before choosing either use.

## Uniform support/energy lower bound

A different and stronger-uniformity statement follows directly. Let H be ANY
smooth compact function supported in an interval of half-width h with
2h<log2. Translation of its center changes neither its autocorrelation nor
energy. Moment conditions are required when identifying Q with the zero side.
Cauchy-Schwarz in ordinary L2 gives Re C_H(t)<=E_H. Splitting at2h yields

  I_near <= E_H integral_0^(2h)(exp(t/2)-1)/sinh(t) dt
         <= E_H (exp(h)-1),
  I_tail = E_H log(tanh h).

The second near inequality uses sinh(t)>=t and
exp(t/2)-1 <= (t/2)exp(t/2). Hence

  Q(H) >= [log(coth h)-C0-(exp(h)-1)] E_H
       >= [-log h-C0-h exp(h)] E_H.

No fixed seed or derivative-norm bound is needed here. This is a uniform
energy-relative bound on the stated narrow class, not on all supports.

## Exact fine diagonal and three-resonance budget

At h=1/256 use log(coth h)>=log256>448/81,
exp(h)-1<=1/255 and C0<25/8. It follows that

  Q(H) > (132299/55080) E_H >= (12/5) E_H

for E_H>0; the non-strict form also covers the zero function.
The slack above12/5 is107/55080. The constant bound is elementary:

* log2 > 2/3+2/81+2/1215=842/1215 by the positive atanh series.
* For a_n=H_n-log n, a_n-gamma=sum_{k=n}^infty
  [log(1+1/k)-1/(k+1)] >=1/(2(n+1)). The inequality follows by integrating
  ((k+1)-x)/(x(k+1)) on[k,k+1] and comparing the resulting reciprocal-square
  sum with an integral. At n8 this gives
  gamma< H8-3*(842/1215)-1/18=13229/22680<7/12.
* pi<22/7 follows from the strictly positive integral
  integral_0^1 x^4(1-x)^4/(1+x^2) dx=22/7-pi.
  Polynomial division gives quotient x^6-4x^5+5x^4-4x^2+4 and remainder-4.
* The positive Taylor sum throughdegree7 at61/24 is
  292216825390621/23115815976960>88/7. Thus log(4pi)<61/24.
  Consequently log(4pi)+gamma<61/24+7/12=25/8.

For two unrelated source-fine moment-zero packets with oriented center gap
delta>=35/128, reuse the existing genuine Arch cross estimate
c=676/65536. Suppose the closed log correlation window
[delta-1/128,delta+1/128] contains at most THREE positive integers m with
Lambda(m)!=0. Each oriented reciprocal sample contributes at most
Lambda(m)/(2sqrt(m)) times total energy. The direct positive samples vanish
by orientation. Since Lambda(m)<=log(m) and log(m)/sqrt(m)<=2/e<3/4,
the full Hermitian two-block prime cost is at most3*(3/4) total energy.
The original exact block identity and explicit formula then give

  Q(p+q) >= [12/5-9/4-2*(676/65536)]*(Ep+Eq)
          = (5299/40960)*(Ep+Eq)
          > (1/8)*(Ep+Eq) for positive total energy.

The surplus above1/8 is179/40960. Unlike prime-free selection, this pays up
to three actual prime-power samples and keeps the full Arch contribution.
This does not pay the same diagonal repeatedly across an arbitrary N-packet
interaction graph. At fixed width the prime count in far log windows grows,
so the three-sample hypothesis is not an all-shift or global RH producer.

## Trust and provenance

Exact scalar identities are in EXACT_BUDGET_SCALARS.json. They are not a
standalone proof of the analytic identities. The source Arch definition,
log isometry, actual moments, cross estimate, diagonal and explicit-formula
interfaces were read and distinguished from current kernel replay.
Novelty across the full corpus is UNKNOWN. A new Lean port and axiom audit
remain NOT_RUN. No Screenshot V6 code or numerical outputs were recovered;
this is an independent analytic result under the explicit normalization above.

## Legality check: operator order cannot be silently reversed

For a nonnegative nonzero compact smooth phi, m>=1 and s>1, compressing the
already moment-killed seed G_s(x)=[(D^2-1/4)^m phi](s x) does NOT generally
preserve the two required moments. Substitution and repeated integration by
parts give, for sigma=+-1/2,

  integral exp(sigma x)G_s(x)dx
    = s^-1 (sigma^2/s^2-1/4)^m
                    integral exp(sigma u/s)phi(u)du !=0.

The integral factor is strictly positive and the polynomial factor nonzero.
Applying the moment killer AFTER dilation, as in the theorem above, gives
zero instead. The two operator compositions obey P(D)T_s=T_s P(sD), not
P(D)T_s=T_s P(D). No claim is made that the unseen screenshot evaluator
uses the incorrect order; the source needs inspection before that inference.
