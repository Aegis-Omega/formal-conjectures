# Source-bound mathematical delta, 1 November 2026

Research source pin: Aegis-Omega/formal-conjectures
f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f. This document contains ordinary
mathematical proofs and source-level compositions. New Lean kernel execution
and transitive axiom audit: NOT_RUN. No RH proof is asserted.

## 1. A forced genuine prime-resonant mixed term

Let r=1/256, D=509/384 and a=log5. Exactly D+2r=4/3<a:
log x-2(x-1)/(x+1) vanishes at1 and has positive derivative
(x-1)^2/[x(x+1)^2] for x>1.

Take a nonzero real smooth compact bump phi supported in [-r,r], and set
U=phi''-phi/4. Twice integration by parts proves both exponential moments
integral exp(+-t/2)U(t)dt vanish. Moreover
integral phi U=-integral(phi')^2-(1/4)integral phi^2<0, so U!=0.
Write E=integral|U|^2>0, H=U+U(.-a). The supports are disjoint, and direct
finite expansion gives C_H(a)=C_H(-a)=E, where
C_H(t)=integral H(x+t) conjugate H(x)dx.

Suppose H=sum_i F_i is ANY finite exact decomposition into smooth compact
functions, each supported in [c_i-r,c_i+r]. If C_ij(a)!=0, support intersection
implies |a-(c_i-c_j)|<=2r. Thus c_i-c_j>=a-2r>D and the corresponding far
pair is resonant at prime5. In fact sum_ij Re C_ij(a)=E, so at least one such
far resonant ordered pair has strictly positive real correlation. Arbitrary
complex coefficients can be absorbed in F_i. No identical-mother restriction
is used.

Consequently it is FALSE that every legal packet admits a fine finite
partition whose EVERY pair is either L43-near (distance<=D) or prime-power-free
far (distance>2r from every prime-power logarithm). The near pairs cannot
contribute at a because a>D+2r, and the prime-power-free pairs cannot contribute
there by their definition. Their putative complete sum would give C_H(a)=0.
This refutes only that proposed exhaustive fusion; it does not refute the
existing local/far lemmas, generic Krein partition, Weil positivity, or RH.

The exact source carrier is W(x)=x^(-1/2)H(log x) on x>0 and0 otherwise.
It is smooth and compact inside the positive axis. With ordinary dx measure,
its two required moments are the two exponential moments above, and its
energy is2E. The source identity is
C_H(t)=exp(t/2)*mixed(W,W)(exp t).
Therefore the genuine n=4 (m=5) prime summand is 2log5 E/sqrt5>0.
This is one summand, not the full Weil form. See the independently read
17-source carrier review for all definitions and exact source identities.

## 2. Pay the forced resonance instead of discarding it

Now take arbitrary fine packets p,q supported at centers b-a=log5, with their
source moment conditions. For the oriented logCross(p,q), the support is
[-log5-1/128,-log5+1/128]. The positive sample at5 vanishes. At the inverse
sample, mixed(p,q)(1/5)=sqrt5*C_pq(-log5). Every other integer sample vanishes:
for m<=4, log5-logm>=log(5/4)>1/5>1/128, and for m>=6,
logm-log5>=log(6/5)>1/6>1/128. The inverse sample is the ONLY surviving prime
sample; one must not count it twice in this oriented B coefficient.

The independently positive L2 space, through the source log isometry, gives
|C_pq(-log5)|<=sqrt(Ep Eq)<=(Ep+Eq)/2. Thus the exact prime sum satisfies

  ||PrimeSum(mixed p q)|| <= (log5/(2sqrt5))*(Ep+Eq).

Reuse the existing moment-cancelled Arch estimate c=676/65536 and the existing
fine diagonal bound Re B(p,p)<=-A Ep with A=5671/3200. These are source
interfaces, not newly assumed replacements for global positivity. Their
compiled provenance remains separate from this new source composition.
The complete Hermitian two-block expansion then gives

  Re B(p+q,p+q) <= -[A-log5/sqrt5-2c]*(Ep+Eq).

No pole, prime-power or Arch term was dropped: moments and the existing
exact explicit formula handle the former; support handles all unused samples.
To bound the remaining scalar without floating point,
exp(5/3)>sum_{k=0}^4 (5/3)^k/k!=10009/1944>5,
and sqrt5>20/9 because400/81<5. Therefore log5/sqrt5<3/4. Exactly

  A-3/4-2c-1 = 319/204800 > 0.

Hence, under those actual source inequalities, the SAME zero-side quadratic
for p+q has margin at least (1+319/204800)*(Ep+Eq), and in particular at least
Ep+Eq. This pays the very resonance forced by Section1. It is an ordinary
composition, not a new kernel-accepted theorem or a claimed global bound.

More generally, any fine separation d>=35/128 whose 1/128 log window contains
at most one positive prime power has the same budget: Lambda(m)/sqrt(m)
<=log(m)/sqrt(m)<=2/e<3/4. The maximum follows by differentiating
s exp(-s/2); e>8/3 follows from its positive Taylor series. If the window
contains no prime power, the prime term is zero. This abstraction preserves
prime powers, orientation and the full mixed term. Novelty beyond the searched
sources is UNKNOWN; it is an application of existing bounds.

## 3. Strict prime-power-only gap extension

The existing integer-log avoidance can be weakened to avoidance only at
positive m with Lambda(m)!=0: the other summands already have zero scalar
weight. This is an equality of each exact summand, so no divergent-limit
interchange is involved. At d=log144 the only possibly active integers are
143,144,145; all have two distinct prime divisors, and their von Mangoldt
weights vanish. For m<=142 the gap is at least log(72/71)>1/72>1/128;
for m>=146 it is at least log(73/72)>1/73>1/128. Thus the weakened predicate
holds, whereas the old one fails at m144.

This does not give a global far-window mechanism. PNT implies that every
fixed positive log-width interval around sufficiently large d contains a
prime: theta(exp(d+epsilon/2))-theta(exp(d-epsilon/2))
=2sinh(epsilon/2)exp(d)+o(exp(d))>0. Even one-prime-power-only windows
cannot be assumed to cover all d; any such global cover needs a separate
arithmetic argument. Indeed the positive theta difference divided by d+epsilon/2
lower-bounds the number of primes in that interval and tends to infinity;
at-most-one active-prime-power windows are eventually impossible too.

## 4. What remains mathematically necessary

For an arbitrary exact moment-preserving finite packet partition, genuine
prime-resonant cross terms cannot all be removed. Section2 pays an isolated
resonance, not the total budget of an arbitrary large interaction graph.
The missing producer in this reviewed partition path is a signed full-family
bound sufficient to control the entire mixed Gram sum (or an independently
proved cofinal Schur/approximation producer). Reusing one diagonal budget per
incident pair without paying its multiplicity is invalid.

The CvS source definition UniversalActualCvSLowBlockApproximation quantifies
all admissible g, but its convergence is of scalar Q values on a139-dimensional
basis. It does not itself state convergence of test functions or an operator
intertwiner. Thus finite-basis nondensity alone does not refute this precise
scalar predicate; conversely finite PSD does not construct its scalar limits.
The existing theorem consuming that predicate remains a genuine conditional.
Other uninspected semantic paths in the corpus remain UNKNOWN.
