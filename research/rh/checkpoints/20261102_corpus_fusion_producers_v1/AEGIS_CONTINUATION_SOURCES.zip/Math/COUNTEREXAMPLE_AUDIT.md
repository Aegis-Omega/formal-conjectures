# Adversarial audit of this continuation

No counterexample below is a counterexample to RH. Previous frozen audits are
preserved. This file records the scope of the mathematical claims actually used.

1. **Positive blocks do not give a positive form.** The real matrix
   [[1,2],[2,1]] has two positive diagonal blocks and value -2 on (1,-1).
   Therefore the new positive moment complement is not admitted as a global
   sign producer without its full signed low/cross budget.

2. **A crude Schur estimate need not follow from an exact positive form.**
   [[1,10],[10,100]] is positive semidefinite (value |x+10y|²). Its high block
   is bounded below by 31/100, but the sufficient replacement inequality
   1 >= 10²/(31/100) is false. The exact Schur inequality holds with the true
   high quadratic norm. Thus a failure of the crude matrix budget would not
   refute the existing L43 theorem or local positivity.

3. **Shrinking a fixed finite geometry does not approximate an arbitrary
   nonzero target.** If all approximants are supported in the shrinking union
   of finitely many intervals around fixed centers, their error from a fixed
   H in L² is at least the mass of H outside that union, which tends to the
   full mass. The proved finite-geometry Gram margin does not change this.

4. **The asymmetric moment complement cannot simply be split by parity.**
   Reflection interchanges the +/- exponential moment conditions. Multiplicities
   p=71,q=70 differ. The new balanced p=q=71 construction adds one actual odd
   atom before asserting reflection invariance. No assertion that the lowest
   eigenfunction is even for arbitrary support follows from this decomposition.

5. **Operator order matters.** Compressing D0^m phi after differentiation is
   different from differentiating a compressed phi. For a nonnegative nonzero
   phi and s>1,

       integral exp(sigma x)(D0^m phi)(s x) dx
        = s^-1[(sigma/s)^2-1/4]^m
          integral exp((sigma/s)u)phi(u)du !=0, sigma=+/-1/2.

   The family with D0 applied AFTER dilation does preserve both moments.
   This is not attributed as a bug in the unseen screenshot evaluator.

6. **Critical scaling leaves a logarithm.** The independently reviewed
   compression argument gives Q(H_s)=E log s+K+o(1), E>0 for a fixed seed and
   order. It supports eventual lower positivity for that family. It refutes
   an s-uniform upper bound at that normalization unless an additional log
   factor is paid. It does not control arbitrary mother functions or supports.

7. **All endpoint and prime terms are retained.** Actual CvS atoms have jumps;
   their Archimedean operator has logarithmic endpoint singularities in L².
   The common singular coefficient is rank one modulo bounded remainders;
   those remainders are not zero. Shift terms use zero extension, not periodic
   wraparound. Finite-difference potentials reach Fourier modes +/-(N+1),
   although their atom indices originally run -N,...,N.

8. **Ritz values have the upper-bound direction only for the exact form.**
   Floating quadrature and eigenvalues are not themselves rigorous enclosures
   of even those Ritz values. The new lambda-lab audit preserves its results
   as diagnostics. In particular the claim that N=12 and N=20 agree at a=1/2
   fails in the bounded replay; this does not refute the N=20 data or RH.
   A finite set of small positive upper estimates cannot exclude EVERY
   positive uniform constant or establish a double-exponential decay law.

9. **Generic finite-codimension positivity does not force zero negative index.**
   Replacing the multiplier w by w-M, with M any fixed positive constant,
   leaves its logarithmic growth and the high-moment complement argument
   intact on every compact support. Choose a nonzero legal smooth H and
   M>Q(H)/||H||². The modified form is negative on H but still has positive
   sufficiently high-moment complements on each interval. This falsifies any
   attempted implication using only that generic complement property. It
   changes the actual zeta form and is not a zeta counterexample. The remaining
   proof must use the actual arithmetic signed low/cross structure.

The analytical proofs, rational comparisons, finite core-Lean checks, existing
source proofs, and their port/replay obligations remain separate trust scopes.
No global positivity or RH premise is used to prove the new complement.
