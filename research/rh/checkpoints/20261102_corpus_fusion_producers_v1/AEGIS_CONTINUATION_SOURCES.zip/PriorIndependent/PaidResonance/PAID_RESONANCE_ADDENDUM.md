# Pay the forced prime-5 edge: independent mathematical review

This addendum is subsequent to, and does not change, the frozen independent
fusion obstruction review. It independently checks the parent's new paid-edge
argument. No Lean compiler, axiom collector, numerical simulator or remote
mutation was run. Novelty across the whole corpus is UNKNOWN.

## Exact theorem at the actual prime resonance

Let p,q be actual WeilCompactSmoothGV1 packets with logarithmic half-widths
r=1/256 at centers a,b, respectively. Assume both actual Weil moments vanish
for p and q, and b-a=log5. Put Ep=energy p, Eq=energy q and E=Ep+Eq.
Then the proposed source-interface composition yields

    -(B(p+q,p+q)).re >= (1+319/204800)*E >= E,

and the original autocorrelation explicit formula gives the SAME lower bound
on the actual zero-side quadratic of p+q. The stronger rational margin is
retained below; no prime term, Arch term, constant or pole is silently omitted.
This is an ordinary mathematical composition of the inspected source theorem
interfaces, NOT a new admitted Lean theorem or rebuilt transitive kernel closure.

### 1. Exactly one oriented prime sample, not two

Use P=logLift p and Q=logLift q, with the definitions read in the prior audit.
Define R(t)=integral P(x+t)conj Q(x) dx. Its support is contained in

    [a-b-2r,a-b+2r]=[-log5-1/128,-log5+1/128].

Every positive sample t=log m, m>=1, is outside this interval; in particular
mixed(p,q)(5)=0. A reciprocal sample t=-log m can survive only if
|log m-log5|<=1/128. For m<=4 the distance is at least log(5/4)>1/5>1/128;
for m>=6 it is at least log(6/5)>1/6>1/128. These strict inequalities follow
by integrating1/t over[4,5] or[5,6]; no numerical logarithms are used.
Thus only m=5 survives. The m=1 term is inert anyway, since Lambda1=0.

By the read logCross_eq_mixed_v28 identity,

    mixed(p,q)(1/5)=sqrt5*R(-log5).

The exact WeilPrimeTermV1 definition indexes m=n+1 and has reciprocal factor1/m.
Therefore

    WeilPrimeSum(mixed(p,q)) = (log5/sqrt5)*R(-log5).

Its forward sample does not supply another copy. The TWO samples seen for
the full autocorrelation of U+T_log5 U arise from the two Hermitian orientations;
they must not be charged twice again inside this oriented B(p,q).

### 2. Use an independently positive space, already present in source

The read theorem
RHActualMixedDefectV1.distinct_logCross_norm_le_mean_energy gives

    |R(t)| <= (Ep+Eq)/2.

Its source proof integrates the pointwise squared-norm inequality in ordinary
L2(logLift); it does not apply Cauchy-Schwarz in the unproved Weil-positive space.
Consequently

    |WeilPrimeSum(mixed(p,q))| <= (log5/(2sqrt5))*E.

This could alternatively be obtained by L2 Cauchy-Schwarz followed by
sqrt(Ep Eq)<=E/2, but no new formal Cauchy-Schwarz adapter is necessary.

### 3. Retain the complete Arch and constant accounting

The support gap is positive, so mixed(p,q)(1)=0. This removes exactly the
Archimedean CONSTANT times that sample, not the Arch integral. The existing
distinct_fine_actual_B_any_positive_gap theorem bounds the full actual B by
the genuine prime norm PLUS the moment-cancelled Arch remainder. With
delta=log5-1/128, the existing moment_zero_fine_middle_arch_q16 gives

    |B(p,q)| <= (log5/(2sqrt5)+c)*E,
    c=676/65536.

Its hypotheses hold because log5>4/3 implies delta>17/64. Both weighted
moments of p are retained for the source rank-one Arch cancellation.

### 4. Exact rational payment

Taylor's lower bound at positive5/3 gives

    exp(5/3) >= sum_(k=0)^4 (5/3)^k/k! =10009/1944>5.

Thus log5<5/3. Also (20/9)^2=400/81<5, so sqrt5>20/9. Both numbers are
positive, giving log5/sqrt5<(5/3)/(20/9)=3/4. In particular

    2 Re B(p,q) <= (3/4+2c)*E.

The source fine diagonal theorem is

    (5671/3200)*energy(p) <= -Re B(p,p)

and likewise for q. Its full displayed body in the recovered PR721 archive
has been read: it adds exact negative Arch bands(1/128,1/64] and(1/64,1/32]
to the inherited inner/tail estimate, with exact prime vanishing for the
fine autocorrelation. It requires the fine support, not an RH sign premise.
The archived dependency's effective use in a fresh Lean environment remains
unverified here; this review is not a new transitive formal audit.

Applying the genuine Hermitian two-block identity gives

    -Re B(p+q,p+q)
       >= [5671/3200-3/4-2*(676/65536)]*E
        = (1+319/204800)*E.

E>=0, so this is at least E. The exact surplus is319/204800>0. The zero-side
claim then uses the SAME source autocorrelation formula with both p,q moments
and the existing moment-preservation-under-addition theorem. There is no
substitution of a different quadratic form or norm.

The estimate holds after arbitrary complex scaling of p and q as well, since
width and moments are preserved and energies scale by squared norms. It thus
controls all coefficients in this two-packet span, not only a single real sum.
This does not imply PSD of arbitrary larger families from their pair bounds.

## General source interface: at most one active prime power

Let d=b-a>=35/128 and suppose the finite active set

    S(d)={m>=1 : Lambda(m)!=0 and |log m-d|<=1/128}

has cardinality at most one. Finiteness is elementary from the bounded
exponential interval containing m. If S is empty the genuine prime sum is0.
If S={m}, only its reciprocal sample survives and

    |PrimeSum(mixed(p,q))| <= Lambda(m)/(2sqrt m)*E.

Here 0<=Lambda(m)<=log m. Setting t=log m shows
log m/sqrt m=t exp(-t/2)<=2/e. The derivative changes sign exactly at t=2.
Moreover e>8/3 by the positive Taylor remainder after degree3. Hence
Lambda(m)/sqrt m<3/4 uniformly. The exact same full-form payment proves
the rational margin above under this one-active-prime-power hypothesis.
This handles the forced prime5 test rather than trying to delete its resonance.

The geometric/arithmetic active-set premise is explicit and limited. For a
FIXED positive half-width, PNT implies the number of primes in that logarithmic
window tends to infinity; eventually the at-most-one hypothesis fails. The
new producer is therefore not an all-support/far-shift RH result. Multiple
active samples and global diagonal reuse still need signed cancellation or a
different complete operator/Schur argument. The earlier forcing counterexample
remains valid against the narrower proposed near-or-prime-free classifier,
while its particular ln5 interaction is now paid by this stronger mechanism.

## Reuse and verification status

The bounded search of the nineteen source files read by this reviewer found
no existing explicit log5 resonance or one-active-prime-power energy-margin
producer. That is NOT a whole-project absence or originality claim. Existing
generic conditional prime-budget theorems in RHActualMixedDefectV1 are reused
as interfaces; their prime-budget hypotheses alone do not construct this
specific single-sample support producer.

New analytic/math status: ordinary argument independently reconstructed.
New Lean source/typecheck: NOT_RUN / PORT_PENDING. New axiom audit: NOT_RUN.
Actual RH integration: OPEN. RH proven by this addendum: false.
