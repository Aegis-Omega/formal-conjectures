from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent
out = base / 'CONSTANT_BUDGET_RECEIPT.json'
if out.exists():
    raise ValueError('refusing receipt overwrite')
H8 = sum((F(1,k) for k in range(1,9)), F(0))
gamma_upper = H8-3*F(842,1215)-F(1,18)
fine_slack = F(448,81)-F(25,8)-F(1,255)-F(12,5)
taylor = sum((F(61,24)**j/factorial(j) for j in range(8)), F(0))
q = [F(4),F(0),F(-4),F(0),F(5),F(-4),F(1)]
prod = [F(0)]*9
for i,a in enumerate(q):
    for j,b in enumerate([F(1),F(0),F(1)]):
        prod[i+j] += a*b
prod[0] -= 4
expected = [F(0)]*9
for j,c in ((4,1),(5,-4),(6,6),(7,-4),(8,1)):
    expected[j] = F(c)
if prod != expected:
    raise ValueError('Dalzell polynomial identity')
poly_integral = sum(c/F(i+1) for i,c in enumerate(q))
slack3 = F(12,5)-F(9,4)-2*F(676,65536)-F(1,8)
if (poly_integral != F(22,7) or gamma_upper != F(13229,22680)
        or F(7,12)-gamma_upper != F(1,22680)
        or fine_slack != F(107,55080) or taylor <= F(88,7)
        or slack3 != F(179,40960)):
    raise ValueError('exact rational constant budget')
record = {'schema':'AEGIS_INDEPENDENT_UNIFORM_FINE_CONSTANT_BUDGET_V1',
          'status':'PASS_EXACT_RATIONAL_CALCULATIONS_ONLY',
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'paper_sha256':hashlib.sha256((base/'UNIFORM_FINE_CONSTANTS_ADDENDUM.md').read_bytes()).hexdigest(),
          'H8':str(H8),'gamma_upper':str(gamma_upper),
          'gamma_slack_below_7_12':str(F(7,12)-gamma_upper),
          'exp_61_24_Taylor_degree':7,'Taylor_lower':str(taylor),
          'Taylor_slack_above_88_7':str(taylor-F(88,7)),
          'Dalzell_polynomial_identity':True,'Dalzell_polynomial_integral':str(poly_integral),
          'fine_diagonal_slack_above_12_5':str(fine_slack),
          'three_active_slack_above_1_8':str(slack3),
          'analytic_infinite_claims_verified_by_this_script':False,
          'ordinary_mathematical_proof':'UNIFORM_FINE_CONSTANTS_ADDENDUM.md',
          'kernel':'NOT_RUN','axioms':'NOT_AUDITED','RH_proven':False}
out.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record,indent=2))
