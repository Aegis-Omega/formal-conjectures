# Independent compression/moment-killer scaling review

This review checks the mathematical family communicated by the parent, not an
unseen screenshot evaluator or claimed Claude execution. No numerical job or
Lean compilation was run. The prior independent reviews remain unchanged.

## 1. Fixed objects and critical normalization

Fix a nonzero complex phi in C_c^infinity(R), supp(phi) subset[-R,R], R>0.
Fix a monic REAL constant-coefficient polynomial P(z)=sum_(j=0)^d p_j z^j,
degree d>=2, with roots +/-1/2. Let s>=1 and define

    H_s(x)=s^(1/2-d) P(D)[phi(s*x)]
          =sqrt(s) F_s(s*x),
    F_s(x)=sum_(j=0)^d p_j s^(j-d) phi^(j)(x).

All coefficients, phi and d are fixed while s varies. Exactly

    ||H_s||_2^2=||F_s||_2^2 -> E_d=||phi^(d)||_2^2>0.

The limit follows from finite-term L2 convergence. A nonzero compactly supported
smooth function cannot have its d-th derivative identically zero: it would be
a polynomial of degree below d with compact support and hence zero. Continuity
therefore gives E_d>0. The unnormalized squared norm is asymptotic to
s^(2d-1)E_d. The critical amplitude squared is s^(1-2d), giving s^-3 at d=2,
s^-7 at d=4 and s^-11 at d=6. These exponents are not interchangeable.

In fact E_s=||H_s||^2=E_d+O(s^-2) for real coefficients. The prospective
1/s term is2p_(d-1) Re integral phi^(d) conjugate(phi^(d-1)), which vanishes
because it is the integral of one half the derivative of
|phi^(d-1)|^2. All boundary terms vanish. The constants in these estimates
depend on the fixed phi,P,d; there is no asserted universal bound on them.

## 2. Actual source legality and prime-free hypothesis

P(D) does not enlarge support, so supp(H_s) subset[-R/s,R/s]. For sigma=+/-1/2,
integration by parts gives

    integral exp(sigma*x) H_s(x)dx
      =s^(1/2-d) P(-sigma) integral exp(sigma*x)phi(s*x)dx=0.

The exact source inverse lift is W_s(x)=x^-1/2 H_s(log x) for x>0 and0 otherwise.
The read source definitions and constructors prove the ordinary mathematical
carrier interface: W_s is smooth compactly supported away from0, the two
moments are integral W_s(x)/x dx and integral W_s(x)dx, and they are zero.
The actual source energy is E_s=integral |W_s(x)|^2dx=integral |H_s(t)|^2dt.

If2R/s<log2, the autocorrelation's additive support lies strictly between
-log2 and+log2. Both samples at every m>=2, including all higher prime powers,
are exactly zero; Lambda1=0 kills m1. Thus the genuine Weil prime sum vanishes.
This is a shrinking support family, not exhaustion of arbitrary large windows.
The zero-side form equals Q(W_s)=-Re WeilExplicitRightSideV1(autocorrelation W_s)
by the existing moment-zero explicit formula. No pole term has been ignored.

## 3. Exact real-space Arch normalization, retaining the full tail

For ANY smooth compact H, define

    C_H(t)=integral H(x+t)conjugate(H(x))dx, E=C_H(0)=||H||^2.

The read source identity is mixed(W,W)(exp t)=exp(-t/2)C_H(t).
Substituting x=exp t into the ACTUAL source Arch integrand gives exactly

    I(H)=integral_0^infty [exp(t/2) Re C_H(t)-E]/sinh(t) dt.

The source constant is C0=log(4pi)+EulerGamma, so when the prime sum is zero,
Q(W)=-C0 E-I(H). The measure is ordinary dx in W, not multiplicative dx/x.

Put L=2R and A=phi^(d). Since C_Hs(t)=C_Fs(s*t), split the integral at L/s:

    I_near(s)=integral_0^L
       [exp(u/(2s)) Re C_Fs(u)-E_s]/[s sinh(u/s)] du,
    I_tail(s)=E_s log tanh(L/(2s)).

The sign of the tail is negative. It follows by integrating -E_s/sinh(t)
from L/s to infinity; the primitive of1/sinh(t) is log tanh(t/2).
There is no tail truncation or omitted boundary term.

For u>0,

    Re C_Fs(u)-E_s=-||T_u F_s-F_s||^2/2,
    |Re C_Fs(u)-E_s|<=u^2 ||F_s'||^2/2.

Translation is an isometry in the independently positive ordinary L2 space.
The last inequality follows from F(x+u)-F(x)=integral_0^u F'(x+t)dt,
Cauchy-Schwarz and Fubini, valid for smooth compact functions. For fixed
phi,P,d, both||F_s|| and||F_s'|| are uniformly bounded for s>=1.

Also s sinh(u/s)>=u, and
(exp(u/(2s))-1)/u<=exp(L/2)/(2s)<=exp(L/2)/2 on0<u<=L.
Therefore the near integrand is dominated by a fixed integrable function
of the form K1*u+K2. Its pointwise limit is(Re C_A(u)-E_d)/u.
Finite-term L2 convergence implies uniform-in-u correlation convergence,
since |C_Fs(u)-C_A(u)|<=||F_s-A||*(||F_s||+||A||).
Dominated convergence consequently gives

    I_near(s) -> integral_0^L (Re C_A(u)-E_d)/u du.

Finally log tanh(L/(2s))=-log s+log(L/2)+o(1), and E_s remains bounded.
The exact ordinary asymptotic is thus

    Q(W_s)=E_s log s+K_phi,d+o(1)=E_d log s+K_phi,d+o(1),
    K_phi,d=-C0 E_d-E_d log(L/2)
             -integral_0^L (Re C_A(u)-E_d)/u du.

Replacing E_s by E_d is licensed because(E_s-E_d)log s=O(s^-2 log s)->0.
The integrand at u0 has a removable integrable singularity: its numerator is
O(u^2). If L is increased beyond the correlation support, the extra integral
-E_d log(L_new/L_old) exactly cancels the change in -E_d log(L/2).
Thus K is independent of the chosen containing support interval.

The leading coefficient is exactly +E_d, with neither an extra2 nor2pi.

## 4. Fourier conventions and the finite constant

With angular Fourier transform Ahat(t)=integral A(x)exp(-i*t*x)dx,
Plancherel is E_d=(1/(2pi))integral |Ahat(t)|^2dt. The same constant is

    K_phi,d=(1/(2pi))integral
      log(|t|/(2pi))*|t|^(2d)*|phihat(t)|^2dt.

One way to verify the constant without assuming a source digamma implementation
is to insert exp(-epsilon*u), use Fourier inversion and the real Frullani identity

    integral_0^infty [exp(-epsilon*u)cos(t*u)-exp(-u)]du/u
      =-(1/2)log(epsilon^2+t^2), epsilon>0,

then let epsilon decrease to0. Schwartz decay supplies the required spectral
moments; log|t| is locally integrable at0, and the weighted Fourier function is
rapidly decreasing. The EulerGamma reference identity is

    integral_0^infty [exp(-u)-1_(u<=L)]du/u=-EulerGamma-log L.

Combining it with the real-space K expression yields exactly log|t|-log(2pi).
For fixed epsilon, Fubini is justified near u0 by the quadratic cosine remainder
and first-order exponential differences, and at infinity by exponential damping.
The final real-space correlation has compact support, so its limit has an
integrable dominating function after the reference subtraction.

Equivalently, under the usual gamma representation, the actual source frequency
weight is Re psi(1/4+i*t/2)-log pi, whose high-frequency asymptotic is
log(|t|/(2pi))+o(1). This is a classical analytic identity, not a newly executed
Lean theorem or a read/verified implementation of an unseen evaluator.

For Fourier transform with exp(-2pi*i*xi*x), Plancherel has NO outside1/(2pi),
and the constant becomes

    K_phi,d=integral log|xi|*|(2pi*i*xi)^d phihat_2pi(xi)|^2 dxi.

Here the2pi moves into the derivative multiplier and cancels from the logarithm.
One must not mix angular and cycles-per-unit frequency conventions.

## 5. Genuine uniform lower bound versus nonuniform asymptotic constant

For ANY smooth compact H supported in[-h,h], h>0, with E=||H||^2>0 and
2h<log2, the same actual prime-free arithmetic form satisfies

    Q(W)/E >= log coth(h)-C0-(exp(h)-1)
            >= log(1/h)-C0-h exp(h).

Indeed Re C_H(t)<=E in ordinary L2. Over0<t<2h the near integral is at most
E integral (exp(t/2)-1)/sinh(t)dt, which is bounded by
E integral (1/2)exp(t/2)dt=E(exp(h)-1). The full tail is E log tanh h.
Finally tanh h<=h and exp h-1<=h exp h. Every sign is retained.

This bound IS uniform over all such H at the stated support and energy,
independently of polynomial order or bump shape. Moment-zero is required only
when identifying this arithmetic Q with the canonical zero-side form.

It does NOT assert a uniform K_phi,d or uniform error rate for arbitrary
varying phi,P,d. Nor does shrinking support give global positivity for all
supports or automatically control the mixed terms of a partitioned large packet.
Its relationship to existing stronger/narrower diagonal theorems must be checked
against the full source corpus before claiming novelty. Existing fine diagonal
theorems may provide different certified constants for their exact domains.

## Status

Independent ordinary reconstruction: completed, with direct real-space proof.
Source conventions: match definitions in the earlier read/bound
WeilCriterionCompactSmoothV1, WeilLogCoordinateIsometryV21,
WeilThreeBlockCrossPrimeV28 and RHKreinMultiplicativeTransportV1 sources.
Screenshot code/data reproduced: NO; none supplied to this reviewer.
New Lean declaration/compilation/axiom audit: NOT_RUN / PORT_PENDING.
Uniform all-support RH producer or root integration: OPEN.
