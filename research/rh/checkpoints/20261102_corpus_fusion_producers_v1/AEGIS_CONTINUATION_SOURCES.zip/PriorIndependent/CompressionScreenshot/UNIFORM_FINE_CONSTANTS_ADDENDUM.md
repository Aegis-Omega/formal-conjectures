# Uniform fine diagonal and three-active-prime-power payment

Subsequent independent review of the parent's stronger constant proposal.
This does not modify COMPRESSION_SCALING_REVIEW.md or prior frozen results.
All source conventions are those in the prior manifest, including the genuine
Arch integrand, C0=log(4pi)+EulerGamma, ordinary energy, and fine half-radius1/256.
No kernel compilation, source-wide novelty determination, or RH closure is claimed.

## 1. Exact EulerGamma upper bound

Put a_n=H_n-log n. By the defining EulerGamma limit and telescoping,

    a_n-EulerGamma=sum_(k=n)^infinity
       [log(1+1/k)-1/(k+1)].

For each k>=1, the bracket is exactly
integral_k^(k+1) (k+1-t)/[t(k+1)]dt. Since t<=k+1,
it is at least1/[2(k+1)^2]. Comparison of the decreasing positive function
1/x^2 with its integral yields

    a_8-EulerGamma >= (1/2)sum_(j=9)^infinity j^-2 >=1/18.

No unjustified limit interchange is required: use partial telescoping sums,
finite term inequalities, and the convergent positive comparison series,
then the stated defining limit. The lower bound on log2 from its positive
atanh series through three terms is log2>842/1215. Hence

    EulerGamma < H8-3*(842/1215)-1/18
               =13229/22680=7/12-1/22680 <7/12.

The small strict slack is exact1/22680, not a decimal rounding argument.

## 2. Exact log(4pi) upper bound

Dalzell's positive integral supplies pi<22/7:

    integral_0^1 x^4(1-x)^4/(1+x^2)dx=22/7-pi>0.

The exact division is

    x^4(1-x)^4=(1+x^2)(x^6-4x^5+5x^4-4x^2+4)-4.

The polynomial integrates to22/7, while4 integral_0^1 1/(1+x^2)dx=pi.
The integrand is positive on the open interval, proving strict positivity.

The degree7 Taylor polynomial at61/24 is
292216825390621/23115815976960, which exceeds88/7 by
1617995965981/23115815976960. All remaining exponential Taylor terms are
positive. Thus exp(61/24)>88/7>4pi, so log(4pi)<61/24.
Combining with the EulerGamma bound gives C0<25/8.

## 3. Genuine uniform fine diagonal

The independently reconstructed exact Arch identity gives, for any smooth
packet with log-lift supported in[-h,h] and prime-free autocorrelation,

    Q/energy >= log coth(h)-C0-(exp(h)-1).

This assertion is translation-invariant in the log center. The source energy
is exactly the additive L2 norm by the read isometry. If the energy is zero,
smoothness implies the packet is identically zero and the corresponding
unnormalized inequality holds trivially; division is used only for positive
energy. Fine support h=1/256 is prime-free because2h=1/128<log2.

Use log coth h>=log(1/h), log256=8log2>448/81 from the first TWO positive
atanh terms, and exp(1/256)-1<=1/255 from exp x<=1/(1-x),0<=x<1.
Consequently

    Q/energy >448/81-25/8-1/255
             =12/5+107/55080 >12/5.

All quantities and signs agree with the actual source B diagonal:
Q=-Re B(g,g), including its constant and full Arch tail. Moment-zero is
not needed for this arithmetic fine diagonal, but is retained when passing
to the actual zero quadratic. This is a stronger ordinary bound than the
5671/3200 source theorem read in the earlier review; another stronger bound
may already exist in the unexamined corpus. No novelty claim is made.

## 4. Pay at most THREE active prime powers

For fine p,q with b-a=d>=35/128, let the actual active reciprocal samples be
the positive m with Lambda(m)!=0 and |log m-d|<=1/128. Suppose there are at
most three. All forward samples are zero by ordered support separation.
The original m=n+1 sum and the exact correlation normalization give

    |PrimeSum(mixed(p,q))|
      <= (1/2) sum_active Lambda(m)/sqrt(m) * (Ep+Eq)
      <= (9/8)(Ep+Eq),

since0<=Lambda(m)<=log m and log(m)/sqrt(m)<=2/e<3/4. The bound is paid in
ordinary positive L2 using the existing mean-energy cross-correlation lemma;
it is not Cauchy-Schwarz in the unproved Weil form. Higher powers are retained
as actual Lambda samples, not silently replaced by primes.

The existing moment-zero fine Arch cost remains c=676/65536, and the constant
sample at1 vanishes by strict support separation. With the new arithmetic
diagonal at least12/5 times energy for BOTH packets, the exact Hermitian
two-block expansion gives

    -Re B(p+q,p+q) >= [12/5-9/4-2c]*(Ep+Eq)
                    =(1/8+179/40960)*(Ep+Eq)
                    >=(1/8)*(Ep+Eq).

The existing actual explicit formula transfers this same bound to the actual
zero quadratic when both p,q moments vanish. Complex coefficients are handled
by scaling the actual packets, preserving widths/moments and scaling energies.

This is a concrete bounded-multiplicity prime-resonant two-packet result, not
an unrestricted all-distance/full-family Gram bound. At fixed log width, PNT
implies the number of active primes eventually exceeds three. Large reconstructed
families still require a complete signed budget and control of diagonal reuse.
No scalar support count is substituted for that global mathematical obligation.

## Status

The above independent ordinary argument and exact rational arithmetic support
the proposed constants. The logarithm, EulerGamma, exponential, integral and
operator statements themselves have NOT been kernel-formalized by the finite
rational script. Lean adapter/compilation: PORT_PENDING / NOT_RUN. Transitive
axiom audit: NOT_RUN. All-support RH production and integration: OPEN.
