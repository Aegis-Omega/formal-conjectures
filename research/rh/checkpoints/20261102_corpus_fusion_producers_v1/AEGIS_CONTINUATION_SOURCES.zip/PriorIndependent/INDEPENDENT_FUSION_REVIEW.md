# Independent source and mathematical review, 2026-11-01

Scope: exact pinned source bodies, a new near/far pair-classification obstruction,
and a prime-power-support weakening. No remote mutation, Lean execution, numeric
simulation, or claim of exhaustive project coverage occurred. This is a separate
agent's written reconstruction, not an independent Lean kernel replay.

## Reused results and their actual premises

PR79 `RHExistingProofFusionV1.lean`, commit
f9b1fbc7817ff2556b5131cf1455e05acc00743a, blob
d0edb96c5333fd23469e2186b0162466e154b6a6, has complete source bodies for
the V8 signed-prime dictionary, combined/prime-only eventual-boundedness iff,
cofinal pi-window iff, complementary moment-zero packets, and the cofinal
Feshbach limit theorem. The last theorem explicitly requires hSchur for EVERY
index, positive complement gap mu<c, coupling control, form convergence and
norm convergence. The finite-to-limit step is already present and must not be
reproved or counted as the missing mathematical producer. Its premises are
not discharged by that theorem. The iff statements are not new sign producers.

At PR92 commit f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f:

* RHL43ActualWeightedGramV1 has the source-body full complex-weighted Gram
  sign for any finite family sharing ONE half-width 2/3 window. It preserves
  all mixed terms. The pair threshold is D=509/384 for fine half-radius r=1/256.
  No arbitrary-center family follows by summing separate pair estimates.
* RHFarPrimeFreeActualGramV1 assumes EVERY positive integer logarithm misses
  the separation by more than 1/128. Its proof uses existing genuine prime
  vanishing, moment-cancelled Arch bound and fine diagonal theorem interfaces.
* RHKreinMultiplicativeTransportV1 provides exact arbitrary-finite packet
  reconstruction with both moments preserved. It supplies no mixed sign or
  Schur lower bound. It is not subject to a same-mother restriction.

All current source body identities/hashes are recorded in SOURCE_MANIFEST.json.
Current kernel status is NOT_RUN here, regardless of earlier source comments
or reported CI. Transitive imported proof closure was not rebuilt in this review.

## New forcing example: a prime-resonant edge cannot be partitioned away

Set r=1/256, D=509/384 and a=log 5. Then D+2r=4/3<a.
For completeness, log x>2(x-1)/(x+1) for x>1: the difference has derivative
(x-1)^2/[x(x+1)^2]>0 and vanishes at x=1. At x=5 this gives log5>4/3.

Choose any nonzero real C-infinity compact bump phi supported in [-r,r] and
set U=phi''-phi/4. Such a bump exists, e.g. the usual exp(-1/(1-(t/r)^2))
inside (-r,r) extended by zero. U is smooth, real, compact and supported in
[-r,r]. Twice integrating by parts gives, for sigma=+/-1/2,

    integral exp(sigma*t) U(t) dt
      = (sigma^2-1/4) integral exp(sigma*t) phi(t) dt = 0.

Boundary terms vanish because the functions are smooth and compactly supported.
U is not zero: integration by parts also gives

    integral phi*U = -integral (phi')^2 - (1/4)integral phi^2 < 0.

All integrals are finite. In particular E=integral |U|^2 is strictly positive,
since a nonzero continuous function is nonzero on an open interval.

Use the translation convention T_a U(t)=U(t-a), and put H=U+T_a U. H remains
smooth compact and has both exponential moments zero; a translation multiplies
the sigma moment by exp(sigma*a). Its two supports are disjoint. For

    C_H(t)=integral H(x+t) conjugate(H(x)) dx,

expanding its four integrals gives C_H(a)=C_H(-a)=E. The three noncentral
terms vanish by support separation; the surviving term is integral |U|^2.

Suppose H=sum_i f_i is ANY finite exact decomposition into arbitrary complex
functions supported in [c_i-r,c_i+r]. Smoothness and individual moment zero may
be imposed too; the following impossibility does not need those extra conditions.
Finite sums commute with integration because all f_i products are integrable
when the f_i are the smooth compact packets under discussion. Define
C_ij(t)=integral f_i(x+t) conjugate(f_j(x)) dx. If C_ij(a) is nonzero then

    |a-(c_i-c_j)| <= 2r.

This is just the necessary intersection condition for the two support intervals.
Consequently c_i-c_j >= a-2r>D. In particular it is a far ordered pair and
the absolute-center-distance version also has

    ||c_i-c_j|-log5| <= 2r.

Thus its far separation is resonant at the genuine prime 5. Any rule requiring
every pair to be EITHER near (distance <=D) OR prime-power-free far (distance
more than 2r from EVERY prime-power logarithm) forces C_ij(a)=0 for every i,j.
Diagonals and near pairs vanish directly because a>D+2r. Far pairs vanish by
the m=5 exclusion, with reversed orientation handled by support disjointness.
Then C_H(a)=sum_ij C_ij(a)=0, contradicting E>0.

Indeed sum_ij Re C_ij(a)=E>0, so at least one genuinely resonant ordered edge
has positive real correlation. Arbitrary complex coefficients are absorbed into
the f_i and cannot defeat this finite-sum argument. Neither changing mothers
nor freely changing centers can avoid all such resonant edges.

**Precisely falsified producer:** universal existence of an exact finite fine
decomposition whose EVERY pair is covered solely by these two geometric classes.
This is not a counterexample to either existing pair theorem, generic Krein
partition, full Weil positivity or RH. Pairwise estimates would also require a
separate total budget even if this geometric covering condition were available.

## Exact transport to the read repository carrier

The relevant definitions were read, not inferred from notation:

    WeilCompactSmoothGV1 = {W : R->C // C-infinity W AND compact support W
                                               AND tsupport W subset (0,infty)}.
    WeilMomentConditionsV1 W = (integral_(x>0) W(x)/x dx=0)
                              AND (integral_(x>0) W(x) dx=0).
    energy(W) = integral_R |W(x)|^2 dx.
    mixed(W,V)(s) = integral_(y>0) W(s*y) conjugate(V(y)) dy.

The measure here is ordinary dy, not dy/y. The actual map is

    W(x) = x^(-1/2) H(log x) for x>0; W(x)=0 for x<=0.

Its support lies in [exp(-r), exp(a+r)], a compact subset of (0,infty).
It is smooth on the positive axis by composition and multiplication, and is
identically zero on a neighborhood of the nonpositive axis. Thus W belongs to
the exact mathematical subtype. Substitution x=exp(t) gives

    integral W(x)/x dx = integral exp(-t/2)H(t)dt = 0,
    integral W(x) dx   = integral exp(t/2)H(t)dt = 0,
    energy(W) = integral |H(t)|^2 dt = 2E.

These formulas match current unlift/unliftWeilPacket and lift_unlift in transport,
the two lift moment identities in the read RHKreinFactorV13 source archive,
and logLift_energy_eq_packet_energy in WeilLogCoordinateIsometryV21.
Both named lift definitions are literally exp(t/2)*W(exp t) in the read sources.

WeilThreeBlockCrossPrimeV28.logCross_eq_mixed_v28 has the exact normalization

    C_H(t) = exp(t/2) mixed(W,W)(exp t).

Therefore mixed(W,W)(5)=E/sqrt5, mixed(W,W)(1/5)=sqrt5*E. The repository
WeilPrimeTermV1 indexes m=n+1. Its n=4 term, i.e. m=5, is exactly

    Lambda(5) [mixed(W,W)(5)+(1/5)mixed(W,W)(1/5)]
       = 2 log5 E/sqrt5 > 0.

This is a source-normalized positive prime contribution, not a negative full
Weil quadratic. The full Archimedean contribution, constant, diagonal and any
other prime-power samples have not been deleted. No full-form sign follows
from this single positive term. The existing explicit formula's pole terms
are handled by the actual moment conditions, not by pretending that the prime
term already equals the full form.

The carrier transport is complete as an ordinary mathematical argument under
these source definitions. A new Lean existential witness and its source-bound
typed adapters have NOT been compiled: PORT_PENDING, KERNEL_NOT_RUN. The archived
RHKreinFactorV13 source identity is explicit and does not by itself verify which
effective provider dependency was used in any historical compiled environment.

## New source-interface weakening and its limitation

Replace the old integer-avoidance premise by

    for every positive m with Lambda(m)!=0,
        |log m-(b-a)| > 1/128.

The exact original prime-term definition has the scalar Lambda(m) multiplying
BOTH samples. For Lambda(m)=0 that whole summand is zero. For Lambda(m)!=0,
reuse distinct_fine_prime_samples_vanish_of_integer_log_gap. Thus every term
is exactly zero and the original tsum vanishes; no interchange of a divergent
series or omission of higher prime powers is involved. Reusing the existing
positive-gap Arch and fine diagonal source interfaces gives the same
676/65536 bound and two-packet zero-side energy margin, under their original
moment and width hypotheses. This is an ordinary source-interface composition,
not an admitted Lean theorem or a new audit of all imported analytic lemmas.

The weakening is strict, with a concrete nonvacuous beyond-log128 instance:
take b-a=log144. If 1<=m<=142 then
log144-log m >= log(72/71)>1/72>1/128. If m>=146 then
log m-log144 >= log(73/72)>1/73>1/128. The remaining143,144,145 have
factorizations11*13, 2^4*3^2 and5*29, so are not prime powers and Lambda is0.
The old integer premise fails at m144 itself. The true weakened premise holds.
All logarithmic inequalities are strict exact inequalities, not rounded bounds.

However PNT implies that for EVERY FIXED epsilon>0, all sufficiently large d
have a prime p with |log p-d|<epsilon. For instance theta(exp(d+epsilon/2))
minus theta(exp(d-epsilon/2)) equals
2*sinh(epsilon/2)*exp(d)+o(exp(d))>0. This gives a prime in the inner interval.
Thus even the prime-power-only avoidance at fixed1/128 is eventually impossible.
The log144 example genuinely extends the old finite range, but is not an
arbitrarily distant fixed-width mechanism and does not evade the forcing example.
No effective numerical PNT threshold is claimed.

## Smallest visible producer in this inspected composition

The existing arbitrary finite carrier and local/far Arch producers are retained.
What they do not supply is signed control of the actual prime-resonant mixed
terms for the resulting complete Gram, or an alternative certified cofinal
Schur family with all the already explicit hypotheses fulfilled. The forcing
example establishes that those resonant entries cannot all be discarded by an
exhaustive near/nonresonant geometry selector, even with arbitrary mothers.
This is a precise obstruction to that proposed producer, not an assertion that
no other branch has a producer, nor a new equivalence offered as RH progress.

Formal gate: no new Lean execution; new lemma axioms NOT_AUDITED; actual RH
integration OPEN; no final RH proof term produced by this review.
