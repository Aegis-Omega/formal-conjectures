#!/usr/bin/env python3
"""Selected diagnostic replay; no numerical result is a certified lower bound."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import importlib.util,json,hashlib,time,platform
import numpy as np,scipy
from scipy.linalg import eigh,null_space
source=Path(__file__).parent/'source'/'qw.py'
spec=importlib.util.spec_from_file_location('bound_qw',source)
qw=importlib.util.module_from_spec(spec);spec.loader.exec_module(qw)
results=[]
for N in [12,20]:
 for M in [240,480]:
  start=time.monotonic();Q,G,mom=qw.qw_matrices(.5,N,M=M)
  eg,V=eigh(Q,G);z=null_space(mom)
  e0=eigh(z.T@Q@z,z.T@G@z,eigvals_only=True)
  even=np.arange(0,N,2);odd=np.arange(1,N,2)
  Ge=np.diag(1/np.sqrt(np.diag(G)));B=Ge@Q@Ge
  vals,vec=np.linalg.eigh(B);minvec=vec[:,0]
  results.append(dict(a_exact='1/2',a_float_hex=(.5).hex(),N=N,M=M,
   full_ritz_min=float(eg[0]),moment_zero_ritz_min=float(e0[0]),
   full_second_ritz=float(eg[1]),odd_fraction_of_lowest=float(np.linalg.norm(minvec[odd])),
   parity_cross_block_norm=float(np.linalg.norm(B[np.ix_(even,odd)],ord=2)),
   moment_nullspace_dimension=int(z.shape[1]),
   moment_null_residual=float(np.linalg.norm(mom@z,ord=2)),
   Gram_error_to_exact_diagonal=float(np.linalg.norm(G-np.diag([1/(2*k+1) for k in range(N)]),ord=2)),
   source_Q_symmetry_error=float(np.linalg.norm(Q-Q.T,ord=2)),
   seconds=time.monotonic()-start))
output=dict(status='FLOATING_POINT_DIAGNOSTIC_REPLAY_COMPLETED',rh_proven=False,
 lower_bound_certified=False,source_commit='d7e6bc7602ccfe4bf5fb094ab595b36eb532d8d5',
 source_blob='74fbe9c90b5f8416fef7b22306123f3c127b632b',
 source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
 runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
 results=results)
print(json.dumps(output,indent=2))
