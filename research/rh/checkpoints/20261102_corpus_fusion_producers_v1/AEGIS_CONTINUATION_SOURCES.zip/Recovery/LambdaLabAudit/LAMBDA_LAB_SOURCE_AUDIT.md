# λ_a laboratory: exact-source audit and selected replay

Date2026-11-02. Repo Aegis-Omega/formal-conjectures, newly observed head d7e6bc7602ccfe4bf5fb094ab595b36eb532d8d5. All nine files under research/rh/checkpoints/20261101_lambda_lab_s1 were read and copied without modification; SOURCE_MANIFEST.json binds bytes to exact Git blobs. Original S1/S2 results are preserved. No high-precision table or300-zero run was repeated; no packages installed, no remote changes, no RH claim.

## Exact normalization

The code implements the complete Suzuki-normalized arithmetic Weil functional stated in its docstring. Let H be zero-extended from[-a,a], C(t)=∫H(x)conj(H(x−t))dx, E=||H||², M±=∫H(x)e^(±x/2)dx. For complex vectors its real-symmetric matrices represent the Hermitian form by conjugate coefficient pairing. The pole contribution is

∫C(t)(e^(t/2)+e^(−t/2))dt=2Re(M+ conjugate(M−)).

It is not generally positive. It vanishes on the repository's two-moment-zero packet class. The prime contribution is−2∑Λ(m)/sqrt(m)ReC(logm), with all prime powers m<=exp(2a), exactly matching the source support cutoff.

The complete Archimedean contribution of the code is

−(log(4π)+γ)E−∫_0∞ [e^(t/2)ReC(t)−E]/sinh(t)dt.

Since ∫_0∞(e^(t/2)−1)/sinh(t)dt=log2+π/2, the same form is

(1/2π)∫[Reψ(1/4+iξ/2)−logπ]|Hhat(ξ)|²dξ.

The constant identity follows by expanding1/sinh into positive exponentials and using ψ(1/2)−ψ(1/4)=log2+π/2; it also follows directly from the convergent digamma series. Thus moment-zero λ0_a uses the SAME complete Q normalization as the high-moment complement manuscript. The README's isolated phrase '½log|t| growth' does not match the code's multiplier, whose leading growth is log|t|. The computed kernel itself has the correct factor through S=R+Rᵀ and the1/(2sinh) kernel.

The tail term G log(tanh(a)) in both implementations is correct and necessary: beyond2a, C(t)=0, and the residual integral is−E∫_(2a)^∞1/sinh(t)dt=E log(tanh(a)) inside WR. It is not an omitted infinite Archimedean tail.

## Implementation scope

qw.py uses real Legendre polynomials on[-a,a]. Its inner Gauss rule has N+12 points: at the exact nodes/weights it integrates the autocorrelation polynomial of degree<=2N−2 exactly. Actual NumPy nodes and weights are floating approximations. The outer M=240 Gauss rule for the Archimedean integral has no proved error bound. Subtraction at t≈0 has removable analytic cancellation, but floating cancellation remains. np.linalg/scipy generalized eigenvalues are numerical approximations without outward rounding or an eigenvalue residual enclosure.

qwhp.py computes the polynomial autocorrelations rho_jk with exact fmpq coefficients, independent of a. Its scaling is consistent: S(t)=a*sigma(t/a), mu_m=∫_0^(2a)(t/a)^m K(t)dt, and the constant coefficient is separated into2G*nu. Subsequent mpmath quad, arithmetic and eigsy at200 nominal digits are NOT interval calculations; no analytic quadrature/eigenvalue error theorem is supplied. Exact rho alone does not certify the final matrix.

hpscan.py first parses the decimal support arguments through Python float, then passes the float to mp.mpf. Inputs such as0.85 and1.1 therefore mean the corresponding binary64 rationals, not exact decimal rationals. This does not invalidate every diagnostic, but exact support identity/prime cutoff requires preserving the original string or a rational specification. The selected replay uses a=1/2, exactly binary representable.

rho_table loads rho_N.pkl with pickle if present. Such a cache is neither source-hashed nor validated for content/schema/version, and loading pickle executes its serialization protocol. No pre-existing cache was loaded in this audit. A proof receipt must bind/validate exact rational data; simply finding a matching filename is not mathematical provenance. python-flint is absent here, so no qwhp execution was attempted and no installation requested.

The moment-zero nullspace is constructed numerically (SciPy SVD or mpmath Gram–Schmidt with a magnitude threshold). The exact moment map has rank2 for a>0,N>=2: its even and odd rows can be distinguished using1 andx. Floating nullspace residuals below are diagnostics, not exact moment satisfaction. The high-precision routine does not explicitly assert the final basis dimension, orthogonality or moment residuals.

## Spectral and domain interpretation

The correct natural domain is the logarithmic Fourier form domain X_a: compactly supported L² functions with ∫log(2+|ξ|)|Hhat|² finite, or its closed-form realization. Q is not an everywhere finite quadratic map on arbitrary L². The Legendre zero extensions are piecewise smooth with jumps, hence their O(1/|ξ|) Fourier decay puts them in this form domain. Their two weighted moments are finite and continuous on the fixed support.

For the EXACT matrices on nested Legendre polynomial spaces, Rayleigh–Ritz gives

λ_a <= λ_a,N+1 <= λ_a,N,
λ0_a <= λ0_a,N+1 <= λ0_a,N.

A negative rigorously enclosed trial value would be a genuine counterexample at that support; a positive finite Ritz value does not lower-bound the full form. Approximate matrices do not automatically even supply certified upper bounds, until a rigorous evaluation error is attached to a particular trial vector.

Density must be proved in the form norm for a limiting equality. One route is smooth approximation followed by C¹ polynomial approximation on the interval: the zero-extended error has controlled L² norm and Fourier O(1/|ξ|) bound from endpoint values plus the derivative L¹ norm, implying logarithmic form-norm convergence. Exact moment correction can use two fixed polynomial directions1,x, whose weighted moment matrix is invertible. This explains how a true nested limit could be justified; the repository's finite table alone does not establish convergence or its rate.

Reflection commutes with the complete form: w is even, each prime term is a symmetric pair of shifts, and the pole term also respects reflection. Thus even and odd blocks decouple EXACTLY. The original two moment constraints impose one scalar condition in each parity block. Numerical evenness of a few lowest Ritz vectors does not establish a universally even or simple lowest eigenfunction.

## Actual selected replay

Ran only qw.py-derived matrices at a=1/2, N=12 and20, with M=240 and480. Source blob74fbe9c90b5f8416fef7b22306123f3c127b632b. Replay used Python3.12.14, NumPy2.3.5, SciPy1.17.0, and no cached matrices. The complete output, exact source hash, runner hash, residuals and versions are in replay/NUMPY_DIAGNOSTIC_RECEIPT.json.

|N|M|full Ritz minimum|moment-zero Ritz minimum|
|---|---|---|---|
|12|240|1.5082258724269995e-6|0.012292525739588505|
|12|480|1.5082258883305846e-6|0.012292525739625377|
|20|240|9.563425845485296e-7|0.0120236853089792|
|20|480|9.563425998905856e-7|0.012023685309018485|

The N20 full value reproduces the README's explicit9.5634e-7 crosscheck. Doubling outer quadrature changes full values by about1.5e-14 and moment-zero values by about4e-14, supporting this particular robust diagnostic. It is not a general quadrature error bound. The moment null residual is<=1.6e-18, parity cross-block norm<=1.9e-14 and the lowest vector's odd norm<=5.4e-13. These are floating diagnostic observations only.

The README's stronger assertion that 'N=12/20/28 agree' and these results are converged is contradicted at a=0.5: N12's full minimum is about58% above N20. This does NOT invalidate the preserved high-precision N32/48 results or the underlying arithmetic formula. It corrects the convergence scope of that specific prose claim.

## Provenance and claims requiring qualification

* S1_results.txt is content-bound by its recorded SHA256, but contains no command line, dps, library versions or source-execution binding. The README's200-digit provenance remains a reported fact, not a freshly verified receipt.
* The current validate.py loops a=1.7,2.5 and k=6,10. The README's quoted validation at0.5 and1.0 cannot be replayed from that loop as it stands; it may refer to an earlier invocation. No source was modified to reconstruct that historical run.
* A finite sum over300 known critical-line zeros is a diagnostic for the explicit formula and truncation, not a certified representation of all zeros without an unconditional omitted-zero tail estimate. No300-zero validation was executed here.
* The fitted exp(−4πe^(2a)) rate, digit requirements, and spectral concentration claims are conjectural numerical interpretations. The archive itself says the larger-a Ritz values are not converged. Those data cannot establish the true infimum's asymptotic rate.
* A finite table of positive values does not contradict EVERY constant c>0 uniform in a: an arbitrarily smaller positive c remains consistent with finitely many upper bounds. Once certified, a particular finite trial may rule out constants above that trial value. A separate unconditional null-sequence argument can establish absence of a global energy gap; it must be cited/composed rather than replaced by this table.

## What this adds to the actual signed low-block target

The lab samples the difficult low-spectrum sector and supplies candidate vectors, parity information and strong warnings about conditioning and support-dependent margins. It contributes no unconditional low-block PSD theorem, no signed mixed budget, no complete complement estimate, and no formal packet sign producer. Positive Ritz plateaus cannot be inserted as hlow.

The new high-moment construction supplies what these trials omit: an unconditional positive complement on each fixed support, compatible with actual CvS atom spans and rigorously paid infinite tails. It does not prove a low Schur block. The p71/q70 projection used in the first construction is not reflection invariant, so the laboratory's parity observation cannot simply be applied to it. A separate balanced p=q71,140-atom construction is being written and adversarially checked; its utility is exact parity-compatible decomposition, not a claim that the even block is positive or that its lowest eigenvalue is always smaller.

At widths already covered by source window_L43 (fullwidth<=4/3), local positivity should be reused through the written rough-domain mollifier bridge, not independently rediscovered from this table. For larger supports, the mathematically useful next experiment is a source-bound trial on the actual low/complement Schur geometry with rigorous Archimedean/prime tail and coupling costs. The present source does not supply that missing signed inequality. RH remains unproved by this material.
