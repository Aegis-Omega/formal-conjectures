# Exact carrier audit of the recovered sinc/Levy probe

Source pin: Aegis-Omega/AEGIS-OMEGA
`5ffb5e2b969cd3873160696d88ea593ac28f77e3`.
Read bodies:

* `weil_spectral_inertia_probe.py`, blob
  `eb30839b4ba5c9253eabf5dcb73c87e42712e93b`;
* `weil_levy_gap_probe.py`, blob
  `5729678b1a0293b453ae72c73703890c19d61940`.

These sources label their outputs T1 numerical diagnostics and deny RH or
global sign authority. That status is preserved. No full probe run was
needed to determine the following exact mathematical interface.

## What the implemented constraint means

For physical half-width r=tau*scale_factor, the frequency basis is

    psi_k(t)=sinc(r t/pi-k),

where NumPy sinc(x)=sin(pi x)/(pi x). In the angular Fourier convention this
is EXACTLY the transform of

    h_k(x)=(1/(2r)) exp(i k pi x/r) 1_[-r,r](x).

The source row `sum(psi*w_quad,axis=1)` approximates
(1/(2pi)) integral psi_k(t)dt. Its symmetric improper integral is
h_k(0)=1/(2r), independently of k. Thus its exact limiting constraint on
H=sum c_k h_k is

    sum c_k=0, equivalently H(0)=0.

It is one evaluation constraint. It is not the pair of actual exponential
moment conditions. The finite frequency cutoff makes it an approximation
even to the evaluation constraint; it does not turn it into the moments.

The actual moment rows have the closed formula, for sigma=+/-1/2,

    M_sigma(h_k)=(-1)^k sinh(sigma r)/(sigma r+i k pi).

Indeed integrate exp((sigma+i k pi/r)x)/(2r) on[-r,r], and use
sinh(sigma r+i k pi)=(-1)^k sinh(sigma r). No quadrature, eigenvalue or
floating assertion is involved in this identity. For r>0 its denominators
do not vanish. Both rows must be used, over the complex coefficient space,
for an exact direct identification with the target legal packet class.

## Concrete counterexample to identifying the two constraint systems

Take c_0=1,c_1=c_-1=-1/2 and all other coefficients zero. Then sum c_k=0,
but

    H(x)=(1-cos(pi x/r))/(2r) 1_[-r,r](x).

This H is nonnegative, nonzero and zero at0. Consequently BOTH
integrals exp(+/-x/2)H(x)dx are strictly positive. It satisfies the exact
limiting implemented constraint and violates both actual moment conditions.
Its zero extension is piecewise smooth, has O(1/|t|) Fourier decay and
belongs to the logarithmic form domain, so this is not a divergent-integral
counterexample. Smooth variants can be made by an even cutoff if required;
nonnegativity and H(0)=0 remain while both moments stay positive.

This proves that the direct identity of carriers is false. It does not
prove that a different derivative/lift adapter elsewhere in the corpus is
impossible. No such adapter appears in the two read probe modules. A
separate D0-image construction could restore the moments, but it changes
the actual Fourier density by the differential multiplier and must also
transport the norm, form, cutoff and all errors. Reusing the existing
numerical spectrum without that transport is invalid.

## What can actually be composed

The existing normalized-symbol identity eta_M=S_M-S_M(0) is valid in its
finite-cutoff model. Its positive Levy measure and adverse negative scalar
are mathematically useful and are reused in SIGNED_JUMP_ATTACK.md.
It does not produce the required gap on the canonical two-moment class.
Its untempered infinite prime measure also has divergent mass away from0,
as the source itself records; an infinite Levy-process limit cannot be
assumed.

The new lambda laboratory instead implements two numerical exponential
moment rows, with its own error/conditioning limitations. The balanced
actual-CvS construction proves exact moments and gives an analytic positive
complement. These three evidence types and carriers must remain distinct.
No old numerical result is retracted merely because it concerns its own
stated model, and no fresh kernel theorem is claimed by this audit.
