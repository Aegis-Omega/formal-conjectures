# Independent finite-geometry Gram review — 2026-11-02

Status: ordinary mathematical argument checked against the source conventions below. New Lean formalization and kernel replay NOT_RUN. No RH proof or corpus-wide novelty claim. Previous reports under `/workspace/aegis-nov1-independent` remain unchanged.

## Corrected proposition

Fix N≥2, R>0, and distinct real centers a₁,…,a_N. Set η=min_{i≠j}|aᵢ−aⱼ|>0 and D=max_{i,j}|aᵢ−aⱼ|. Define

    C₀ = log(4π)+γ,
    Kη = exp(η/4)/sinh(η/2),
    S_D = Σ_{m integer, 2≤m≤exp(D+2R)} Λ(m)/√m,
    B* = S_D + 2R Kη.

The finite sum uses ordinary von Mangoldt Λ; it is not a sum over all real m. Non-prime-powers contribute zero. S_D is finite, nonnegative, and independent of s and of the packets.

Suppose s≥1, h=R/s≤η/4, and 2h<log2. For each i let Hᵢ:ℝ→ℂ be smooth, supported in [aᵢ−h,aᵢ+h], with

    ∫ exp(x/2) Hᵢ(x) dx = ∫ exp(−x/2) Hᵢ(x) dx = 0.

Let Gᵢ(x)=x^(−1/2)Hᵢ(log x) for x>0, and zero otherwise. These are actual compact-positive smooth Weil packets, with the actual two moment conditions. Let Eᵢ=∫|Hᵢ|²=energy(Gᵢ), and define the actual zero quadratic Q(G) by the zero side of the existing autocorrelation explicit formula. On moment-zero packets it equals −Re B(G,G), where B is the actual repository Weil RHS applied to mixed autocorrelation.

Then for all complex c₁,…,c_N,

    Q(Σ cᵢGᵢ) ≥ [log(s/R)−C₀−h exp(h)−(N−1)B*] Σ |cᵢ|² Eᵢ.

The final sum equals energy(ΣcᵢGᵢ), since the log supports are disjoint. No common mother packet is required. The same scalar estimate also holds without the moment conditions if Q is defined only as −Re B; moments are required to identify that arithmetic expression with the intended zero quadratic and to remove the endpoint/pole terms in the existing explicit formula.

Missing hypotheses found during review: s≥1 is needed for the proposed cutoff D+2R and bound h≤R; 2h<log2 is needed for the displayed prime-free diagonal argument. The separation condition alone does not imply prime-free diagonals for large η. The theorem is valid after these clauses are included. N=0 and N=1 can be treated separately without a minimum separation.

## Exact source interface

All source conventions below were recovered at Aegis-Omega/formal-conjectures commit f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f. The earlier exact source manifests are:

* `/workspace/aegis-nov1-independent/SOURCE_MANIFEST.json`, SHA256 0fde002642bd24f1d3a9bb96a2af0c5201f92571a092a149c20684d1cfa6420b;
* `/workspace/aegis-nov1-independent/ADAPTER_MANIFEST.json`, SHA256 5854ad03875aa42e4ce1c534b66d57f86bed37324af5dd6c0b5bd93e9c4c5ecb.

The current additional source copies and verified Git blob identities are recorded in `SOURCE_MANIFEST.json` beside this report. Source bodies were read; no fresh transitive Lean replay was performed by this reviewer.

`WeilCriterionCompactSmoothV1.lean`, blob 1223d431c79cada6c7865b83b855e752f280c67c, defines

    Prime(f) = Σ_{m≥1} Λ(m)[f(m)+m⁻¹ f(m⁻¹)],
    Arch(f) = ∫_{x>1} [f(x)+x⁻¹f(x⁻¹)−2x⁻¹f(1)]/(x−x⁻¹) dx,
    RHS(f) = Prime(f)+C₀ f(1)+Arch(f).

The source indexes m=n+1; m=1 is inert. `WeilMixedClosureV2.lean`, blob 1ae43c67062ca3017696450c46db604518313950, uses mixed(Gᵢ,Gⱼ)(x)=∫_{y>0}Gᵢ(xy)conj(Gⱼ(y))dy, with ordinary dy. `WeilThreeBlockCrossPrimeV28.lean`, blob 1da314ff47a8d1f80ef5d2c12fd1418c1c3ee842, proves

    Rᵢⱼ(t) := ∫ Hᵢ(x+t)conj(Hⱼ(x))dx
            = exp(t/2) mixed(Gᵢ,Gⱼ)(exp t).

`WeilLogCoordinateIsometryV21.lean`, blob 14243b1ca04855f9b61dbe910902c55aae2f3606, gives the exact energy isometry. `RHKreinMultiplicativeTransportV1.lean`, blob d882947b11b1981bb7ed9daedcfc702f972627e2, supplies the actual unlift/smoothness/compactness and moment transport. `WeilMixedAlgebraV2.lean`, blob 70c56a1fdb790efefa3d4540eee80671bf68fab1, defines B=RHS(mixed), proves Hermitian symmetry and sesquilinear packet expansion. `WeilExplicitFormulaV10.lean`, blob 67d1007c6698d1fcd8374cdd6257479335337008, retains the endpoint terms; their vanishing here follows from the explicit moment assumptions, not from a discarded term.

The ordinary diagonal estimate was derived and independently checked in `/workspace/aegis-nov1-independent/CompressionScreenshot/COMPRESSION_SCALING_REVIEW.md`, SHA256 b4aff21d706af3788ddd0793b4e2c372710b0936305acda94b935e7d1842e2a4. The short derivation is repeated below to make this proposition self-contained; no claim of a new standalone kernel theorem is made.

## Diagonal with the full Archimedean tail

For H supported in an interval of half-width h, write C_H(t)=∫H(x+t)conj(H(x))dx and E=C_H(0). Translation of the support does not change C_H. C_H(t)=0 for |t|≥2h (values at endpoints do not affect integrals), and Re C_H(t)≤E by Cauchy–Schwarz in the ordinary positive L² space. This does not assume positivity of Q.

Self mixed autocorrelation and the exact x=exp(t) change of variables give

    I(H) = ∫₀∞ [exp(t/2) Re C_H(t)−E]/sinh(t) dt.

This includes the reciprocal sample and the subtraction at 1. Since 2h<log2, all prime samples m≥2 and their reciprocals vanish. Thus Q(H)=−C₀E−I(H).

The tail is evaluated exactly:

    ∫_{2h}∞ (−E)/sinh(t) dt = E log tanh(h).

On [0,2h], Re C_H≤E and sinh(t)≥t give

    [exp(t/2)Re C_H(t)−E]/sinh(t)
      ≤ E [exp(t/2)−1]/sinh(t)
      ≤ (E/2) exp(t/2).

The last inequality follows from exp(t/2)−1≤(t/2)exp(t/2). Therefore I_near≤E(exp h−1), and

    Q(H)/E ≥ log coth(h)−C₀−(exp h−1)
           ≥ log(1/h)−C₀−h exp h.

For E=0 the smooth H is zero and no division is needed. The integrand is locally integrable at 0: Re C_H(t)−E=−||T_tH−H||²/2=O(t²), whereas exp(t/2)−1=O(t). Compact support gives the exactly controlled tail above. This proves the stated uniform diagonal for all packet shapes.

## Offdiagonal geometry and the factor check

Order aᵢ<aⱼ and put d=aⱼ−aᵢ≥η. Then Rᵢⱼ is supported in [−d−2h,−d+2h]. Since 2h≤η/2, this interval is strictly negative and bounded away from zero. In particular mixed(Gᵢ,Gⱼ)(1)=0. Both the C₀ term and the Archimedean subtraction proportional to this value vanish exactly.

For every integer m≥1, the forward sample mixed(Gᵢ,Gⱼ)(m) vanishes. The reciprocal sample contributes exactly

    Λ(m)m⁻¹ mixed(Gᵢ,Gⱼ)(m⁻¹)
      = Λ(m)/√m Rᵢⱼ(−log m).

Only ONE oriented sample remains. Its conjugate orientation occurs later in the full Hermitian expansion, which is where the factor 2 belongs. By ordinary L² Cauchy–Schwarz, |Rᵢⱼ(t)|≤√(EᵢEⱼ) for every t. An active sample has log m≤d+2h≤D+2R, because s≥1. Hence

    |Prime(mixed(Gᵢ,Gⱼ))|≤S_D √(EᵢEⱼ).

This pays all prime powers, including exact resonances. No prime-void condition and no cancellation of unknown sign is assumed. The compact support makes this arithmetic sum finite, so no infinite-sum interchange is needed for this bound.

The exact change of variables in Arch, now with the forward and constant samples zero, gives

    Arch(mixed(Gᵢ,Gⱼ))
       = ∫₀∞ k(t)Rᵢⱼ(−t)dt,
    k(t)=exp(t/2)/(2sinh t).

The integrand is supported in [d−2h,d+2h], an interval of length 4h with lower endpoint ≥η/2. The kernel is positive and decreasing on t>0, since (log k)'=1/2−coth t<0. Consequently

    |Arch|≤4h k(η/2) √(EᵢEⱼ)
          =2h Kη √(EᵢEⱼ).

The 4h support length and denominator 2 in k have both been retained. This proves

    |B(Gᵢ,Gⱼ)|≤[S_D+2hKη]√(EᵢEⱼ)≤B*√(EᵢEⱼ).

The opposite orientation follows from the actual B_hermitian identity, without paying another factor in this single-pair bound. The Arch integral is over a compact set away from its singular endpoint; all of its nonzero domain has been included.

## All complex coefficients

Use exact sesquilinearity and Hermitian symmetry to expand

    Q(Σ cᵢGᵢ)=Σ|cᵢ|²Q(Gᵢ)−2Re Σ_{i<j}cᵢconj(cⱼ)B(Gᵢ,Gⱼ).

Put uᵢ=|cᵢ|√Eᵢ≥0. The offdiagonal lower loss is at most 2B*Σ_{i<j}uᵢuⱼ. The exact identity

    (N−1)Σuᵢ²−2Σ_{i<j}uᵢuⱼ = Σ_{i<j}(uᵢ−uⱼ)² ≥0

gives the claimed coefficient (N−1)B*, not 2(N−1)B*. This controls every mixed term and all complex phases. Disjoint support gives energy(ΣcᵢGᵢ)=Σuᵢ² via the log-coordinate isometry. The moment conditions are linear and thus pass to the full sum, permitting its zero-side identification.

## Explicit threshold and quantifier order

For any desired ε>0 let

    Sε=max(1, R, 4R/η, 4R/log2,
           R exp(C₀+e+(N−1)B*+ε)).

For s≥Sε we have h≤1, h≤η/4, and 2h≤log2/2<log2. Also log(s/R)≥C₀+e+(N−1)B*+ε and h exp h≤e. Therefore Q(ΣcᵢGᵢ)≥ε energy(ΣcᵢGᵢ), uniformly over all allowed packet shapes and all complex coefficients.

The conclusion has the order

    for each fixed finite center geometry and R, ε,
    there exists Sε,
    for all s≥Sε and all legal packets in those shrinking intervals,
    for all complex coefficients, the displayed positivity holds.

It does not give one s for all geometries, all N, or all target test functions. Kη behaves like 2/η as η→0, and S_D grows with D; changing N, η or D can destroy any common threshold. The result does not supply a moment-preserving density or convergence theorem into the full Weil class.

For fixed centers there is a more direct scope limitation: any approximant supported in the shrinking union U_s=∪[aᵢ−R/s,aᵢ+R/s] has squared L² error from a fixed H at least ∫_{ℝ\U_s}|H|²→||H||². This follows by dominated convergence because U_s shrinks to a finite null set. Hence this particular fixed-geometry shrinking family cannot approximate any fixed nonzero L² target, regardless of coefficients. This is not a counterexample to varying-center families or RH.

## Reuse comparison: actual source bodies, not names

The following three additional source bodies were fetched read-only at the pin above; their exact blob checks pass against the already recovered untruncated tree. No historical replay result is being replaced by a fresh replay claim.

1. `RHDyadicTowerV13.lean.src`, blob a7dbe8ff995e8cace45cdccfd60f05f59928129b, already proves dyadic_tower: for every N, m=max(10,N+2) works for all moment-zero seeds of half-width 2^(−m), all translations j log2 for 0≤j≤N, and all complex coefficients. Its actual bodies provide the diagonal, single dyadic prime sample at each gap, a geometric row-sum bound, and the full Gram inequality. This is a stronger specialized quantitative result than a crude all-primes S_D bound on that lattice. It uses a common seed. The present argument permits arbitrary fixed centers and independently chosen shapes, with a much poorer threshold.

2. `RHRationalNinePacketConcreteV1.lean.src`, blob 54ac309843e2a649f05474a4dec03e944af714f1, already proves nine_packet_coercive_v1 with margin 6/5 for all complex coefficients of one seed translated to j log(33/16), j=0,…,8, under its WidthOneOneTwentyEightAt and moment conditions. The body explicitly obtains all 36 mixed bounds from eight prime-void gap producers, all nine diagonal bounds, and applies actual_nine_block_bound_v1. The declaration's exact width predicate, rather than informal file prose, governs its domain. This existing concrete theorem is reused as established source content, not re-proved or dismissed.

3. `RHNineBlockActualBridgeV1.lean.src`, blob e3d884f6a1fe3ba12e7bd688d27971dd78ec7c70, is the existing conditional finite complex algebra: nine diagonal bounds ≥32/25 E and all 36 mixed bounds ≤E/100 imply the exact 6/5 margin. The present weighted-energy proof is the ordinary general N version of this same valid Gram budget principle; such finite algebra is not a newly discovered RH mechanism.

The prior `RHL43ActualWeightedGramV1.lean` actual all-shapes common-window theorem also remains stronger at its certified width for centers fitting a common half-width 2/3 interval. The new estimate addresses arbitrary but fixed separated center geometries by permitting further shrinkage. Novelty across all other branches and historical variants remains UNKNOWN. This bounded review establishes compatible mathematical composition and a precise scope, not nonexistence of an earlier matching theorem.

## Adversarial verdict

The corrected finite-geometry proposition survives the normalization and mixed-term audit. It includes resonant prime windows rather than excluding them; it never invokes Cauchy–Schwarz in the unknown Weil form; it retains the full Archimedean tail and both orientations at the correct stage; it preserves moments and all complex phases. The result explains why shrinking a fixed finite packet pattern can eventually overwhelm a fixed finite mixed budget with a log(1/h) diagonal.

It does not control the simultaneous growth of a center dictionary needed for an arbitrary target, and cannot be inserted as a universal-positive producer without an additional compatible decomposition/limit argument. Kernel status of the new proposition is NOT_RUN; formal source adapter and build are PORT_PENDING. No additional equivalence was proved in this review.
