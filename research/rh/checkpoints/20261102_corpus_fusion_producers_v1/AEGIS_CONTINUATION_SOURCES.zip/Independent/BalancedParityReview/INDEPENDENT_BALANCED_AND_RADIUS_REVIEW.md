# Independent balanced-parity and explicit-radius review

Date2026-11-02. Inputs are copied and SHA256-bound in `INPUT_MANIFEST.json`: balanced addendum7746aa6786fa4fd53e20d32d2632d8714d3aae8eddbe976adf1f83a09e948ba4; explicit selector40e39f313bc2e343810db9333a4d07d6f6449961aac02b3649e2a7cdf193843e. The ordinary derivations survive the bounded adversarial checks below. This is not a proof of full Weil positivity or RH.

The actual source-atom and Fourier normalization were already independently checked at PR92 f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f in the earlier HighMomentReview source manifest; those files remain unchanged. A later branch head is not independently audited here. The new symmetric integer file is separately kernel replayed; its result is limited to exact constants.

## Actual centered phase and dimension

The source potential sin²(πy/L)exp(i2πny/L), upon y=x+L/2, becomes (−1)^n cos²(πx/L)exp(i2πnx/L). Thus multiplying the translated source atom by (−1)^n produces exactly V_n in the addendum, with no remaining phase. Since D²−1/4 has real coefficients, reflection sends V_n toV_−n. Therefore C_n andS_n are real even and real odd functions respectively, and both retain the original legal exponential moments.

The original atom family centered at−N,…,N has N+1 cosine andN sine directions. Adding S_(N+1) adds exactly one independent odd direction: its potential has the previously absent sine frequencyN+1. Equivalently independence follows from the invertible moment map below and compact-potential injectivity of D²−1/4. The enlarged low space has complex dimension2N+2 with parity blocks of complex dimensionN+1 each, obtained by complexifying the indicated real bases. It is a one-direction enlargement, not a claim that a single unmodified source U_(N+1) supplies a purely odd atom.

At N=69 the added direction is (translated U70−translated U−70)/(2i); both phases are(+1), since70 is even. At N=0 the construction still has two independent directions C₀,S₁ and a balanced4-moment residual, not a degenerate odd block.

## Chebyshev witness with roots outside the half interval

The integration-by-parts triangular map for extra moments k=1,…,N+1 on each sign reduces its kernel to orthogonality of the potential against

    E=span{x^kexp(−x/2),x^kexp(+x/2):0≤k≤N}.

The total real dimension is2N+2, with global zero bound2N+1 counting multiplicities. Reflection splits E into E_+,E_− of dimensionN+1 each. A nonzero even function has at mostN positive roots because each positive root is mirrored with its multiplicity; a nonzero odd function has the same bound and additionally has a root at0. These assertions hold on the entire positive half-line, not merely inside the packet support.

Even low potentials are the positive interior envelope cos²(πx/L) times a real polynomial of degree≤N in cosθ. Odd low potentials are that envelope times sinθ times such a polynomial, θ=2πx/L. On0<x<L/2, cosθ is strictly decreasing andsinθ>0. Each nonzero potential therefore has at mostN sign changes on this interval.

If m sign changes occur, impose zeros on F∈E_± at those m points and at N−m further distinct positive points strictly beyond L/2. This imposes N homogeneous equations on dimensionN+1 and has a nonzero solution. The global positive-root bound forces all prescribed roots to be simple and forbids ANY additional positive root. Thus placing witness roots outside the half interval is legitimate and prevents extra undesired interior sign changes. After a global sign choice, the product with the potential is nonnegative and positive on an open interval. Both factors have the same parity, so their full-interval pairing is twice the positive half-interval pairing, contradicting orthogonality.

This proves invertibility separately in both parity blocks. A complex kernel vector would give a real or imaginary kernel vector because the displayed bases and weight functions are real, so the proof establishes the complex moment projection as well. For N=0 there are zero root conditions; any nonzero function of the relevant one-dimensional parity space has no positive roots and the same argument applies.

The residual has both weighted moment sets through degreeN+1, hence total order2N+4. Its compact potential belongs to H^(2N+4) in the rough domain. The low space and residual kernel are reflection invariant; uniqueness of the decomposition implies the oblique projection commutes with reflection. This argument does not replace it by an L²-orthogonal projection.

The full form commutes with reflection because its Archimedean multiplier is even and every finite prime shift occurs with its opposite. Polarization then makes all even/odd mixed terms zero. It does not imply the minimum occurs in one parity, or prove a low Schur block positive. No such stronger claim is present in the addendum.

## Concrete142-moment constant and kernel scope

For R=3/5,T=85 andtotalorder142, the same established ordinary Hermite bound has rational upper expression

    68(260109/100)^142/(142!)².

The new integer theorem clears its positive denominators against1/10000:68·10000=680000. Using the already established analytic digamma/prime constants, ordinary rational algebra gives

    (103/40)(9999/10000)−6/10000−9/4
      =129657/400000=0.3241425>8/25.

Strict Q(V)>cE requires nonzero V; at V=0 use≥. The addendum explicitly fixes this quantifier issue.

The exact source `/workspace/aegis-nov2/HighMomentSymmetric142.lean`, SHA2565ca3b7b33801a0399ac859360a205564a38f2a4e3cf0495737e1e38992a77cc5, was copied unchanged into the existing independent replay directory. Only this new source was rebuilt; the previously verified HighMomentExactConstants source/olean was reused unchanged. Actual compile command:

    LEAN_PATH=/workspace/aegis-nov2-independent/HighMomentKernelReplay /workspace/aegis-nov2-runtime/toolchain/lean-4.33.1-linux/bin/lean --trust=0 -j2 -M4096 -o HighMomentSymmetric142.olean HighMomentSymmetric142.lean

Exit0. The actual output prints both exact integer types and proof bodies; both #print axioms results state no axioms. The separate receipt records the completed targeted leanchecker replay and binds its transcript. There is no Mathlib import or analytic definition in these integer endpoints, and no native_decide. This is exact-constant evidence only; the balanced Chebyshev and Hermite/Weil transport remain ordinary proofs.

## Explicit selector: prime and digamma bounds

For integer R≥1 the complete prime bound satisfies

    A_R≤4RΣ_{2≤m≤exp(2R)}m^(−1/2)≤8RexpR<8R3^R=a.

The sum estimate follows by a decreasing-function integral and includes every prime power. Replacing Λ bylogm here is an explicitly paid upper bound on the full finite operator, not an unjustified sign substitution.

For t≥2, b=t/2 andM=floorb≥1, the first M+1 reciprocal terms in the convergent digamma series contribute H_(M+1)>logb. The Lorentzian subtractions satisfy

    Σ_{j=0}^M (j+1/4)/[(j+1/4)²+b²]
      ≤Σ_{j=0}^M(j+1/4)/M²
      =(M+1)(2M+1)/(4M²)≤3/2.

The last inequality is exact forM=1 and improves for largerM. The remaining series has lower bound−3/[4(M+1/4)]>−3/(4M), by the same negative integral tail already independently checked. Thus

    w(t)>logt−[log(2π)+γ+3/2+3/4]>logt−5.

Indeed log(2π)<log8<21/10 andγ<3/5 give a total<4.95<5. These are strictly weaker elementary constants than the earlier actual ones. ForT=3^(a+8), log3>1 givesw(T)>a+3. The bound is used only at this enormous T≥2, so the b≥1 hypothesis is satisfied.

## Factorial selector and minimal radius

Set A0=R(T+1), B0=2RT3^R, J=max(2,3A0,B0(a+9)), n=2J. The Hermite bound is at most

    B0 A0^(2n)/(n!)²,

usingπ>1, expR<3^R andR√(T²+1/4)<A0. The elementary integral estimate log(n!)≥nlogn−n+1 implies n!≥(n/e)^n. Since e<3 andn≥6A0,

    ε_n<B0(3A0/n)^(2n)≤B0·4^(−n).

For n≥0,4^n≥n+1 by induction. Here n=2J≥2B0(a+9), hence n+1>B0(a+9), and ε_n<1/(a+9). In particularε_n<1, so the subsequent convex low/high Fourier-mass substitution has the required positive coefficients. With A_R<a,w(T)>a+3,w(0)>−6 it gives

    Q(H)/E>3−(a+9)ε_n>2

for nonzero H satisfying the balanced2J moments. The zero function has Q=E=0 as separately specified. There is no division by zero or inference of strict0>0.

At the smallest allowed radius R=1, a=24,K=32,T=3^32 are positive finite integers, A0,B0 are positive, andJ≥2. Thus N_CvS=J−2 is a legitimate nonnegative index. The balanced low dimension is2J−2, withJ−1 directions of each parity, and the high order is2J. No hidden N=−1 or missing small-radius case occurs. Any real finite support radius can be covered by an integer R≥1; its moment order is permitted to increase.

## Verdict

The balanced parity decomposition, its concrete>0.32 complement constant, and the explicit all-integer-radius positive-complement selector are valid ordinary results under the stated domains. No counterexample was found in the requested phase, outside-root, N=0,R=1 or factorial tests. The selector proves termination only for the high-complement dimension choice. It supplies no signed low/complement Schur budget at arbitrary radius and no successful whole-form certificate algorithm. The increasingly restrictive high-moment subspaces are not the original universal two-moment class. Their>2 coercivity therefore does not contradict a global legal null sequence and does not imply RH.
