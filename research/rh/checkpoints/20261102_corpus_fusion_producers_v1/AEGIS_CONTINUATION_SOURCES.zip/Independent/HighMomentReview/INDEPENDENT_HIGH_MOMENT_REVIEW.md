# Independent high-moment review — 2026-11-02

Scope: §§4–7 of the exact `INPUT_SNAPSHOT.md` copied from the ongoing HighMoment result, its checker, the actual CvS moment atoms, and source normalization. Verdict: the stated ordinary 139-dimensional moment decomposition and full-form complement bound survive this audit. This is not a Lean proof, fresh kernel replay, arbitrary-support positivity theorem, or RH proof. The low/complement mixed Schur inequality remains an independent required obligation.

## Exact inputs and performed checks

The frozen input, checker, and fetched source bytes are listed in `SOURCE_MANIFEST.json`. Six fresh source bodies were fetched read-only from Aegis-Omega/formal-conjectures at f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f, and their Git blob SHA1 identities were recomputed from their bytes against the previously recovered untruncated tree:

* CvSArchDigammaV1: d763158a515617804dd985bf6e617ab1b65521bd;
* CvSArchSourceV1: b6d3ad3a79504c4a9b2efe7f6e3a339be79d5e29;
* CvSWindowCertV1: 48c52acfbc83303d1ff8e4d5d080d8f6da21a9fd;
* CvSDigammaSeriesV1: f0fc59cbb207a7374555c5c2ccd8bc9cf63864c3;
* RHKreinSymbolIntegrationV1: 90cd14bc007cabdba0449b405234e66ccb9ee0c7;
* archived WeilCriticalLineKreinFormV1: 752a5719d42ac3848b24b50c4b58b7578f5fe78e.

The actual CvSMomentBasisV1 body copied from the HighMoment source set is blob 0d37c5c5a262e46b5aa01fefed9422ebcdd95a2a. Its bytes agree with that set's manifest. The actual 139 index mapping is also explicit in CvSProjectedTransportL12V1: atomCenter ranges from −69 to69 and the resulting Fourier support from −70 to70.

Executed the original checker with ordinary Python: exit0, EXACT_RATIONAL_CONSTANT_CHECK_PASS. Independently executed its identical frozen snapshot with `python -O`: exit0, same exact conclusions. The latter actual output is saved in `EXACT_CHECKER_REPLAY.json`. The checker uses explicit `require` raising ValueError, so optimization does not erase its inequality checks. No claim is made that running this script validates the analytic argument; that argument is checked below.

## Actual atom and rough domain

The source defines `momentAtom L a` as basisFun with weights (−1/4,1/2,−1/4) at a−1,a,a+1. This is exactly

    (D²−1/4)[sin²(πx/L) exp(2πiax/L)]

on the whole line before restriction. The function used in `lowBlock` and its moments is its indicator restriction to [0,L]. The source proves momentZero_of_ode by two integrations by parts and both potential/derivative endpoint values. Thus the atom legality is genuine and does not follow from an unsupported spectral-coefficient shortcut.

The zero-extended potential is C¹ because sin² and its derivative vanish at both endpoints. Its distributional second derivative is the indicator restriction of its classical second derivative: there are no delta terms because the potential and its first derivative match zero. The atom itself can jump at the endpoints. It is bounded and piecewise smooth with finite variation, hence its Fourier transform is O(1/|ξ|), and it belongs to L² and to the stated logarithmic form domain X. In particular ∫log(2+|ξ|)|Uhat|² is finite. The report correctly refrains from treating these rough atoms as `WeilCompactSmoothGV1` objects.

Subtracting a finite sum of such atoms from any H∈X preserves X. All moment functionals on a fixed compact interval are bounded L² functionals. Thus an invertible finite moment matrix defines a bounded L² projection onto the atom span; it is also a well-defined map on X. This supplies no useful numerical condition bound by itself, but existence of the decomposition does not require one.

## The 139×139 moment matrix, including complex coefficients

Let Φ=sin²(πx/L)T(x), T a complex trigonometric polynomial with frequencies −69,…,69, and U=(D²−1/4)Φ on [0,L]. For σ=±1/2 and k≥1, integration by parts gives

    ∫x^k exp(σx)U(x)dx
       = ∫exp(σx)[2σk x^(k−1)+k(k−1)x^(k−2)]Φ(x)dx.

The sign is positive on 2σk: the adjoint of D² is D². For each σ this is a triangular transformation of potential moments with nonzero diagonal 2σk. Therefore vanishing of the 70 negative-exponential extra moments and69 positive-exponential extra moments is equivalent to orthogonality of Φ to

    V=span{exp(−x/2)x^j:0≤j≤69}
      +span{exp(+x/2)x^j:0≤j≤68}.

V has real dimension139 and is an extended Chebyshev space: exponential polynomials with these real characteristic roots have at most138 real zeros counting multiplicity unless zero. The standard induction by an exponential factor, differentiation, and Rolle proves this. For a lower dimensional witness space one may explicitly choose initial segments of the polynomial-degree chains for each root. This makes the needed nested Chebyshev subspace precise.

V is real and the trigonometric span is conjugation-stable. Consequently a nonzero complex nullvector would yield a nonzero real or imaginary part T₀ whose sin²-weighted function is orthogonal to V. A nonzero real trigonometric polynomial with frequencies −69,…,69 has at most138 interior zeros over one period: multiplication by exp(2πi69x/L) gives a polynomial of degree at most138 in exp(2πix/L). In particular it has at most138 sign changes.

At its m sign changes, take a nonzero function F in a Chebyshev subspace of dimension m+1, imposing those m homogeneous point conditions. Its zero bound forces these zeros to be simple and forbids any others in the interval. F therefore changes sign at precisely the same places as T₀; choose its global sign accordingly. Then sin²(πx/L)T₀(x)F(x) is nonnegative and positive on an open subinterval, contradicting orthogonality. Thus T₀=0 and no complex nullvector exists.

This proves injectivity and hence invertibility of the complex 139×139 extra-moment matrix for every L>0. It also establishes independence of the139 actual atoms. No numerical determinant, real-only coefficient restriction, or false zero count is hidden in the argument.

The residual has the141 total moments (71 negative-exponential,70 positive-exponential), including the original2 legal moments. The resulting projection is OBLIQUE relative to the atom span. It is not the source's L² orthogonal projection onto that span. The report explicitly retains this distinction, and source `Admissible`/`window_of_certificate` cannot be applied by silently identifying the two residuals.

## Complex Hermite–Genocchi remainder

For f_x(z)=exp(zx), Hermite interpolation uses p copies of −1/2 and q copies of +1/2, with n=p+q. Its interpolant is a linear combination of the node derivatives x^k exp(±x/2), so integration against H with the indicated moments is exactly zero. This remains true for complex H and complex evaluation z=−iξ; interpolation coefficients depend on z, not on x.

The remainder is the product of n node factors times the divided difference at those n nodes and z. The Hermite–Genocchi formula is valid for complex nodes because exp is entire; it integrates f_x^(n) over the real barycentric simplex of dimension n, whose volume is1/n!. The convex combination of all nodes has real part in [−1/2,1/2], including z=−iξ. For |x|≤R,

    |remainder|≤exp(R/2) R^n (ξ²+1/4)^(n/2)/n!.

Repeated nodes follow by continuity; the bound does not introduce exp(R|ξ|). For compact L² H, ||H||₁≤sqrt(2R)||H||₂. Squaring the bound for its Fourier transform and integrating |ξ|≤T with angular Plancherel measure dξ/(2π) gives exactly

    lowmass/E≤(2RT/π)exp(R)[R²(T²+1/4)]^n/(n!)².

There is no missing n!, interval length2R, frequency length2T, or 2π factor. The estimate requires only L², support, and moment cancellation, so it applies to the rough residual as stated.

## Full-form normalization and infinite tail

CvSDigammaSeriesV1 defines hplus(t)=Reψ(1/4+it/2)−logπ, proves its convergent series, and CvSArchDigammaV1 identifies the actual archSymbol with it by rfl. Its archTerm is

    1/(j+1)−2(2j+1/2)/[(2j+1/2)²+ξ²]
      =1/(j+1)−(j+1/4)/[(j+1/4)²+(ξ/2)²].

Thus the report's w and its rational lower-sum formula use the source's actual half-frequency, rather than ξ or2ξ in the wrong place. The archived actual Weil Krein-form theorem has the angular factor1/(2π) and the prime symbol 2Λ(m)/√m cos(ξlog m). Its even-part density may be replaced inside the w integral by the full density because w is even. Angular Fourier inversion turns each cosine integral into Re C_H(log m), giving the report's prime factor2, with every prime power retained.

The repository Gm convention can reflect the positive logLift coordinate; w and the prime cosine multiplier are even, so this reflection preserves Q and does not alter the sign or factor2. The source CvS raw integral ∫ScertM|Hhat|² is 2π times the normalized Q here, and its raw Fourier energy is2π times ordinary L² energy. Hence the complement ratio0.03 is the same in both conventions if BOTH numerator and denominator are converted. Finite Gram matrices and operator-cross matrices must likewise be consistently scaled; an unconverted raw CvS matrix is not automatically the normalized C in the report's §8.

For fixed compact support, all prime samples with log m>2R vanish. The operator bound A_R=2ΣΛ(m)/√m follows from ordinary L² Cauchy–Schwarz, independently of any Weil positivity. At R=3/5, exp(2R)<4; therefore only m=2,3 contribute. Endpoint terms vanish by the two original moments. The full gamma/digamma integral and its tail are retained.

For w, subtracting the convergent ξ=0 series gives a sum of nonnegative functions increasing in |ξ|. Alternatively expansion of1/sinh(t) gives

    w(ξ)−w(0)=∫₀∞exp(t/2)(1−cos ξt)/sinh(t)dt.

Tonelli applies to these nonnegative integrands. It justifies the multiplier difference identity on the logarithmic form domain, without a signed conditional interchange. Also w→∞ by retaining j+1/4≤|ξ|/2. Combining high and low Fourier mass yields the stated ordinary complement estimate. This does not need RH, a positive zero measure, or a zero-free strip assumption.

The rough form Q is an ordinary extension on X. The sources identify it with the actual zero-side object on the original smooth legal packets. This review does not invent a Lean zero-sum declaration for a rough residual. The decomposition can nevertheless be used at the ordinary quadratic-form level for an original smooth packet because each component lies in X. Formalizing this extension and its compatibility is still separate work.

## Exact constants and independent checker audit

For j≥N≥1 the omitted series summand is at least

    1/(j+1)−1/(j+1/4)
      =−(3/4)/[(j+1)(j+1/4)]
      ≥−(3/4)/(j+1/4)².

The decreasing-series integral test gives Σ_{j=N}∞1/(j+1/4)²≤1/(N−3/4). Thus the negative tail in psi_lower is genuinely a lower bound, including N=2 at ξ=0. A finite positive-looking digamma sum is not being substituted for the infinite series.

Every decision in the checker is a Fraction comparison. The Taylor upper tail uses the first omitted term and a ratio bound x/(N+2)<1 for positive x, which bounds all later term ratios. Lower exponentials use finite positive terms, so the log upper bounds are valid. The radical lower bounds are exact squaring comparisons. The Euler constant bound uses γ≤H₃₂−log32 and a certified rational log2 lower bound. The program's assumed π>3 can independently be supplied by the alternating geometric integral:

    π>4Σ_{k=0}^7(−1)^k/(2k+1)=135904/45045>3.

The π<22/7 bound used for logπ is the positive Dalzell integral already derived in the source argument. These analytic constant lemmas are ordinary proof prerequisites; the Fraction script does not itself prove their link to π orγ.

The independently replayed exact comparisons establish ε<1/1000, w(64)>229/100, w(0)>−6, and A_R<9/4. Consequently

    Q(V)/E≥(229/100)(999/1000)−6/1000−9/4
          =3171/100000>3/100.

Substitution of lower bounds for w(64) andw(0) is valid: if α is the actual low-mass fraction, use w(64)(1−α)+w(0)α and then0≤α≤1/1000. No upper bound on w(64) is needed. The very small displayed diagnostic ε≈8.66e−39 is non-authoritative and not used to strengthen the inequality.

## Boundaries of this conclusion

No mathematical defect or counterexample was found to §§4–7 under their stated assumptions. The139-atom projection and the >0.03 full-form complement are ordinary analytic results with a completed constant check, not yet kernel evidence. They do not imply the full low-plus-complement sign: cross terms can overwhelm two positive diagonal blocks, as [[1,2],[2,1]] demonstrates.

The proposed normalized sufficient inequality C−(100/3)D≥0 in §8 has NOT been proved or verified here. Its moment-complement projection differs from source Admissible's orthogonality to the CvS atoms. This is a real transport obligation, not evidence against the existing source theorem. The fixed L=6/5 conclusion does not cover all support widths, detectingPacket, or DenseFixedPacketSign. No novelty claim beyond the searched source set and no claim of universal RH closure is made.
