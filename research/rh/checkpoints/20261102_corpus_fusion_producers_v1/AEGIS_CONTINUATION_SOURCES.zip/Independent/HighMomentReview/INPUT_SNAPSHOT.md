# High moments, the actual 139 CvS atoms, and a positive complement

Status: NEW ordinary mathematical derivation, not a Lean theorem or a kernel replay. RH is not proved. Exact rational arithmetic below checks only explicitly identified constants. Scope of source search: fourteen selected source files at Aegis-Omega/formal-conjectures PR92 commit f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f. No claim of novelty or exhaustive corpus search.

## 1. Conventions and exact objects

Let D=d/dx, D0=D²−1/4, I=(-R,R), and

P(D)=(D−1/2)^p(D+1/2)^q, n=p+q, p,q>=1.

Write M[s,k](H)=∫ x^k e^(sx) H(x) dx. Original legality in centered logarithmic coordinates is M[-1/2,0]=M[+1/2,0]=0. The raw logarithmic operator in the source WeilMomentKillerRangeV1 is D²+D, with moments ∫g=∫e^x g=0. These are conjugate, not identical: H=e^(x/2)g and Φ=e^(x/2)ψ imply D0Φ=e^(x/2)(ψ''+ψ'). All shifts preserve the full set of moments up to each specified degree by the binomial formula.

Fourier convention: Hhat(ξ)=∫ H(x)e^(-iξx)dx; E=||H||²₂=(1/2π)∫|Hhat|². This is Mathlib's Fourier evaluated at ξ/(2π).

For compact logarithmic support and the two original moments, define the complete Weil quadratic form with the usual zero-positive sign by

Q(H)=(1/2π)∫ w(ξ)|Hhat(ξ)|²dξ − 2∑_{m>=2} Λ(m)/sqrt(m) Re C_H(log m),

w(ξ)=Re ψ(1/4+iξ/2)−log π,
C_H(t)=∫ H(x) conjugate(H(x−t)) dx.

The pole terms vanish by the original moments. The prime sum retains EVERY prime power; compact support makes it finite. We work on the form domain X(I): L² functions supported in the closed interval, with ∫log(2+|ξ|)|Hhat(ξ)|²dξ finite. Cc∞ is a subspace; zero-extended piecewise smooth bounded functions with finitely many jumps also belong. Statements about this ordinary Q require the explicit-formula identification with the repository's actual packet form; the selected sources give the source-specific bridge and hypotheses, not an unconditional RH theorem.

## 2. Exact compact-support range, including adjoint signs

**Theorem 1.** For H∈Cc∞(I), the following are equivalent:

(a) H=P(D)u for u∈Cc∞(I).
(b) M[-1/2,k](H)=0 for 0<=k<p, and M[+1/2,k](H)=0 for 0<=k<q.

The compact inverse preserves the convex hull of support. Necessity follows by integrating against the kernel of P(−D); the negative sign on the first exponential is essential.

For sufficiency, for λ=±1/2 and 1<=j<=its multiplicity define

R[λ,j]H(x)=e^(λx)/(j−1)! ∫_{−∞}^x (x−t)^(j−1)e^(−λt)H(t)dt.

The integral is zero on the left. On the right it is e^(λx) times a polynomial whose coefficients are precisely weighted moments of H up to degree j−1, and hence is zero. Differentiation gives (D−λ)R[λ,1]H=H and (D−λ)R[λ,j]H=R[λ,j−1]H. The partial fractions of 1/P(z) now give u by a finite linear combination of these compact inverses. The distribution identity P(D)u=H follows from the same rational identity; convolution with smooth H gives an ordinary smooth solution. A homogeneous constant-coefficient ODE has only exponential-polynomial solutions, so the compact solution is unique.

The same proof for compact L² H gives u∈H^n(R), supported in the same interval, satisfying P(D)u=H weakly. One can justify H^n regularity directly from the distribution identity: P(iξ) has no real zero and has growth |ξ|^n, so (1+|ξ|²)^(n/2)/|P(iξ)| is bounded. This is the relevant range class when subtracting the rough CvS atoms below, not Cc∞.

## 3. A smooth finite correction with exactly n−2 dimensions

Choose nonzero φ>=0 in Cc∞((-r,r)), r<R, and U=D0φ. Choose n−2 distinct centers c_j in (-R+r,R−r). All U_j(x)=U(x−c_j) are legal and retain support in I.

Twice integrating by parts gives, for σ=±1/2 and k>=1,

M[σ,k](D0 T_cφ)=∫ e^(σx)[2σk x^(k−1)+k(k−1)x^(k−2)]φ(x−c)dx.

This is e^(σc) times a polynomial of degree k−1 in c, with leading coefficient 2σk∫e^(σt)φ(t)dt !=0. Hence the matrix of EXTRA moments of U_j is an invertible triangular row transformation of evaluation of

e^(−c/2)c^l (0<=l<p−1), e^(+c/2)c^l (0<=l<q−1).

A real exponential polynomial with real characteristic roots and total multiplicity d has at most d−1 real zeros counting multiplicity, unless identically zero. Proof by induction: multiply by e^(−λx), differentiate, and apply Rolle with multiplicities; the differentiated exponential-polynomial space has dimension d−1. If the derivative vanishes identically the original function is a single exponential. The same argument works on every finite interval and then on R. This proves invertibility at any d distinct real centers; complex nullvectors split into real and imaginary ones.

Consequently the legal smooth space is the exact direct sum

W0(I)=span{U_j:1<=j<=n−2} ⊕ P(D)Cc∞(I).

There are no omitted mixed terms: this is an algebraic/domain decomposition, not positivity of the sum. The correction projection is bounded in L² on a fixed interval because every moment functional is bounded there and the fixed finite matrix is invertible.

## 4. The ACTUAL CvS 139 atoms also give a correction complement

The source CvSMomentBasisV1 defines, on [0,L],

Φ_a(x)=sin²(πx/L)e^(2πiax/L),
U_a=D0Φ_a, a=-69,...,69.

The actual atom used in the integral is the zero extension 1_[0,L] U_a. The source proves its two exponential moments vanish by Φ_a=Φ'_a=0 at BOTH endpoints. The Fourier weights (−1/4,1/2,−1/4) alone are not the legality argument. These atoms are modulations of a potential, not translates of one U. The zero-extended potential is C¹ and piecewise smooth, U_a is L² with possible jumps, and U_a belongs to X([0,L]) because its Fourier transform is O(1/|ξ|).

**Theorem 2.** For p=71,q=70, the 139-by-139 matrix of extra moments

M[-1/2,k](U_a), k=1,...,70;
M[+1/2,k](U_a), k=1,...,69

is invertible for EVERY L>0.

Proof. Suppose a combination U=D0Φ, Φ=sin²(πx/L)T(x), T=∑_{a=-69}^{69}c_a e^(2πiax/L), has all extra moments zero. The integration-by-parts triangular identities in §3 imply

∫ Φ(x)e^(−x/2)x^j dx=0, j=0,...,69;
∫ Φ(x)e^(+x/2)x^j dx=0, j=0,...,68.

The span V of these 139 real exponential polynomials is an extended Chebyshev space on R by the multiplicity proof above. The real and imaginary parts of Φ separately have these orthogonalities; the trig span is conjugation stable. A nonzero real trig polynomial T of degree <=69 has at most138 zeros (with multiplicity) in one period: multiply by e^(2πi69x/L) to obtain a nonzero polynomial of degree <=138 in e^(2πix/L). Thus it has at most138 sign changes on (0,L).

Let its m sign changes be x_1<...<x_m, m<=138. Select any nested real-root exponential-polynomial subspace of V of dimension m+1. Solving m homogeneous point conditions yields a nonzero F vanishing at the x_i. Its zero bound counting multiplicity forces all these roots to be simple, with no other roots in (0,L). Change its overall sign to agree with T. Then sin²(πx/L)T(x)F(x)>=0 throughout (0,L) and is positive on some open interval. Its integral is strictly positive, contradicting orthogonality to V. Thus T=0, proving injectivity and hence matrix invertibility. No numerical determinant is required.

As a result, on X([0,L]) intersected with the original two moment conditions there is a direct sum

H=∑_{a=-69}^{69} c_a U_a + V,
V∈X([0,L]), M[-1/2,k](V)=0 (k<=70), M[+1/2,k](V)=0 (k<=69).

The projection onto the atom span is defined by these moments and is generally OBLIQUE, not the source's L²-orthogonal projection. This distinction changes the mixed-term calculation. V=P(D)u for compact u∈H^141, not necessarily smooth. This is an actual source-object connection, beyond the coincidence 141−2=139. It does not identify this moment projection with the source's R_basis or its trace-minimizing coefficients.

## 5. Efficient Hermite remainder using ALL weighted moments

Let H satisfy the n conditions in Theorem1, centered in [-R,R]. Interpolate the entire function f_x(z)=e^(zx) in its spectral variable z at nodes −1/2 repeated p times and +1/2 repeated q times. Its Hermite interpolant, evaluated at z=−iξ, is a linear combination of x^k e^(−x/2), k<p, and x^k e^(+x/2), k<q. It integrates to zero against H.

The exact interpolation remainder is

f_x(z)−interpolant(z)=(z+1/2)^p(z−1/2)^q f_x[−1/2 (p times),+1/2 (q times),z].

The Hermite–Genocchi formula writes this last divided difference as the simplex integral of x^n exp(x∑t_j z_j), whose simplex volume is 1/n!. It follows first for distinct complex nodes from the fundamental theorem of calculus on line segments, then for repeated nodes by continuity. Every node has real part in [-1/2,1/2] when z=−iξ. Therefore

|remainder| <= e^(R/2) R^n (ξ²+1/4)^(n/2)/n!.

Crucially there is NO exp(R|ξ|) loss. Hölder and Plancherel give

(1/2π)∫_{−T}^T |Hhat(ξ)|²dξ <= ε_n(R,T) E,
ε_n=(2RT/π)e^R [R²(T²+1/4)]^n/(n!)².

This holds for all compact L² H with the stated moments, without smoothness. For fixed R,T, ε_n tends to zero as n grows.

## 6. Full Archimedean and prime control, with no omitted tails

From the convergent digamma series,

w(ξ)−w(0)=∑_{j>=0} [1/(j+1/4)−(j+1/4)/((j+1/4)²+(ξ/2)²)].

Every term is nonnegative and increasing with |ξ|. Thus w>=w(0), w(ξ)>=w(T) for |ξ|>=T, and w(T) tends to infinity (retain j+1/4<=T/2, where each term is at least 1/[2(j+1/4)]).

Equivalently w(ξ)−w(0)=∫_0∞ e^(t/2)(1−cos ξt)/sinh(t)dt. This identity follows by expanding 1/sinh(t) as a nonnegative exponential series and applying Tonelli to 1−cos. On the form domain the Archimedean quadratic identity follows from Plancherel and the same nonnegative Tonelli argument. It does not discard an Archimedean tail or exchange a conditionally convergent signed integral.

For support [-R,R], C_H(t)=0 when |t|>2R, and |C_H(t)|<=E. Hence the COMPLETE prime-power operator has the bound

|2∑ Λ(m)/sqrt(m) Re C_H(log m)| <= A_R E,
A_R=2∑_{2<=m<=e^(2R)} Λ(m)/sqrt(m).

Consequently

Q(H)>= [w(T)−A_R−(w(T)−w(0))ε_n(R,T)] E.

For each fixed support and prescribed δ>0, choose T with w(T)>A_R+2δ, then n large enough. This proves an unconditional positive finite-codimension complement on each fixed support. It does NOT control its finite-dimensional correction or their mixed terms.

## 7. Concrete complement at the actual CvS width L=6/5

Translate [0,6/5] to [-3/5,3/5]. All weighted moment sets are invariant under this translation. Set R=3/5,T=64,n=141,p=71,q=70.

The accompanying exact-rational checker proves:

* ε_141(3/5,64)<1/1000. It uses π>3 and exp(3/5)<2; its much smaller diagnostic decimal is not needed.
* w(64)>229/100.
* w(0)>−6.
* A_R=2(log2/sqrt2+log3/sqrt3)<9/4. No other prime power is active because exp(6/5)<4.

For the digamma inequalities it uses γ<3/5, logπ<23/20 and, for N=1024 or2,

w(2y) >= −3/5−23/20 +∑_{j=0}^{N−1}[1/(j+1)−(j+1/4)/((j+1/4)²+y²)] −(3/4)/(N−3/4).

Indeed each omitted summand is >=−(3/4)/(j+1/4)²; the integral test bounds their sum. This explicitly controls the infinite tail, rather than treating a truncated sum as an enclosure.

Elementary constants are independently reducible to rationals: γ<=H_32−log32 and log2>0.692 from the first three positive terms of 2atanh(1/3); log2<0.6932, log3<1.0987, and logπ<1.15 from finite positive exponential Taylor sums; sqrt2>1.4142 and sqrt3>1.7320 by squaring. The classical π<22/7 follows by integrating the positive function x^4(1−x)^4/(1+x²) on (0,1), whose integral is22/7−π. The elementary π>3 may equally be obtained from the alternating geometric integral for4atan(1), using enough terms. The checker uses exact Taylor geometric remainders for exp(3/5)<2.

We obtain, for EVERY residual V in the actual CvS moment complement,

Q(V) >= [ (229/100)(1−1/1000)−6/1000−9/4 ]||V||²₂
      = (3171/100000)||V||²₂ > (3/100)||V||²₂.

The equality arithmetic is (2.29−2.25)−0.00829=0.03171. This is a positive full-form complement, conditional only on the exact moment constraints, NOT on RH or on a new unproved sign assumption. No claim is made that the existing Lean trace complement is this complement.

## 8. Adversarial tests and remaining load-bearing task

1. Roots with the wrong adjoint sign are rejected by integration by parts.
2. Higher-order ranges are proper subspaces; the 139 correction is indispensable.
3. Trig coefficient constraints alone do not imply legal exponential moments; the source uses endpoint vanishing and D0.
4. CvS atoms have boundary jumps: all decompositions involving them use X(I)/compact H^141 potentials, not Cc∞.
5. The oblique moment complement is not the source's orthogonal complement. Reusing an orthogonal-complement cross bound without transport is invalid.
6. The compact-support prime cutoff includes all powers and endpoints. At L=6/5 exactly2,3 can contribute, and both are retained in the operator bound.
7. Arbitrary low and high positive blocks do not make the full form positive. A 2-by-2 counterexample is [[1,2],[2,1]], whose diagonal blocks are positive but eigenvalue−1 remains.
8. The finite-width result does not cover arbitrary supports, detectingPacket, or all legal packet functions.
9. CvSProjectedTransportL12V1.hTransport is a finite exact congruence for Q_CvS and R_basis. Its own coercivity consumers still require interval entries, R_basis surjectivity/norm bounds, and signed cross budgets. CvSActualWeilInteropV1 converts an ALREADY supplied packet zero-side sign into an actual mixed budget; it does not manufacture the missing sign.

**Small next mathematical obligation for THIS construction:** for L=6/5, derive and prove the signed low/high Schur inequality for the actual moment projection just constructed:

Q(v) >= sup_{V in this141-moment complement, V!=0} |B_Q(v,V)|²/Q(V)
for every v in span{actual139 CvS atoms}.

That L² cross bound does exist for these actual atoms. Each U_a is piecewise smooth with finite jumps, hence Uhat_a=O(1/|ξ|). The digamma series, split at j≈|ξ|, gives w(ξ)=O(log(2+|ξ|)); therefore w Uhat_a∈L². The complete prime part is a finite sum of bounded translations at this width. Thus A U_a∈L², where A is the full Archimedean multiplier minus the finite prime-shift operator, and B_Q(v,V)=<1_I Av,V> for the form domain.

Let Π be the L² projection onto the nullspace of the141 weighted moments. It is the orthogonal complement of the141 exponential-polynomial functions (not the span of the139 CvS atoms). Then

|B_Q(v,V)|² <= ||Π(1_I Av)||²₂ ||V||²₂.

A concrete sufficient finite matrix inequality is therefore

Q(v) >= (100/3)||Π(1_I Av)||²₂ for every actual CvS low vector v.

The projection is explicitly computable from the positive Gram matrix of the141 real exponential-polynomial functions. If Y_a=1_I A U_a and F is this141-dimensional span, its cross-cost matrix is D_ab=<Y_a,Y_b>−<Proj_F Y_a,Proj_F Y_b>. Testing C−(100/3)D>=0, where C is the full actual low Gram matrix, is a genuine proof-or-falsification target. It may fail because the crude0.03 bound loses information; failure would reject this sufficient budget, not Q or RH. The exact complement-energy Schur norm is sharper and remains another target. No positivity of this finite matrix has been asserted or checked here. Arbitrary-width/globalization remains a separate requirement.

## 9. Source and trust ledger

All source copies are bound by SOURCE_MANIFEST.json, ADDITIONAL_SOURCE_MANIFEST.json and TRANSPORT_SOURCE_MANIFEST.json; Git blob identity was recomputed from bytes. The selected source files contain complete proof bodies for their stated conditional theorems; no fresh typecheck was performed here. Their existing reported checks must not be upgraded to fresh kernel evidence.

The new arguments in §§2–7 are ordinary proofs, not extracted Lean terms. high_moment_exact_bounds.py is a small rational checker for numerical constants. Its success is not a soundness theorem for §5, not a proof of all CvS premises, not a Lean axiom audit, and not RH. A complete source-bound ordinary proof and independent mathematical review are still distinct trust dimensions from the exact arithmetic receipt.
