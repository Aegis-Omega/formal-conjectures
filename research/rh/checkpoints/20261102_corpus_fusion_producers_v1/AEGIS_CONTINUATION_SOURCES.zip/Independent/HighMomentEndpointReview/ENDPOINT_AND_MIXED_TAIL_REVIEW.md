# Independent endpoint and mixed-tail audit

Reviewed §§11,14,15 of the frozen manuscript SHA256 f9129b8cbb95a8be79612db10f1b5359c23086b71ee285d815608967d703048c. The exact snapshot is stored beside this review. Under L>0, N∈ℕ and0≤r,s≤2N, the ordinary formulas survive this bounded adversarial check. No new kernel or RH claim is made.

Source normalization remains the one independently checked in `HighMomentReview/INDEPENDENT_HIGH_MOMENT_REVIEW.md`: PR92 f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f, actual momentAtom from blob0d37c5c5a262e46b5aa01fefed9422ebcdd95a2a; w(ξ)=Reψ(1/4+iξ/2)−logπ from CvSDigammaSeriesV1/CvSArchDigammaV1; angular Fourier with inverse factor1/(2π); complete prime multiplier−2ΣΛ(m)m^(−1/2)cos(ξlogm). Source manifests and copies from that earlier review remain unchanged.

## Exact physical Archimedean operator

The series-derived identity w(ξ)−w(0)=∫₀∞a(t)(1−cosξt)dt, a(t)=exp(t/2)/sinh t, implies the operator difference H−(T_tH+T_−tH)/2. The factor1/2 on the shifts is necessary and correctly retained. At first truncate t away from0 and∞; the resulting bounded multipliers justify the Fourier/operator calculation. The nonnegative quadratic difference form then gives the limit and its polarization. For the finite trigonometric atoms the same limit is an actual L² function: Fourier decayO(1/|ξ|) and w=O(log(2+|ξ|)) imply w Hhat∈L².

For u=exp(−t/2), a(t)dt=−4du/(1−u⁴). Therefore

    J(s)=4∫₀^{exp(−s/2)}du/(1−u⁴)
        =log[(1+exp(−s/2))/(1−exp(−s/2))]
         +2atan(exp(−s/2)).

The primitive is exact because4/(1−u⁴)=2/(1−u²)+2/(1+u²). There is no missing factor2. As s→0+, J(s)=−logs+log4+π/2+O(s), so its claimed logarithmic coefficient is correct.

For x∈(0,L), split the two shifted integrals where x−t and x+t leave the zero-extended support. This gives the two interior half-difference integrals and H(x)[J(x)+J(L−x)]/2, exactly as in §11. Individual divergent pieces at t=0 must remain combined; the manuscript explicitly does so. For smooth H on the closed interval each interior difference is bounded in magnitude by ||H'||∞t, uniformly in x. Integration against a(t) gives a finite uniform bound on0<t<L, while the remaining tail is exact J. Hence

    A_arch H(x)=−H(0)logx/2+O(1),
    A_arch H(x)=−H(L)log(L−x)/2+O(1)

at the respective endpoints, because (H(x)−H(0))logx→0 and its opposite-end analogue. These logarithms are L²; deleting them would change the actual cross matrix.

## Endpoint rank and polynomial jets

For potential sin²(ax)exp(iω_nx), a=π/L,ω_n=2πn/L, the endpoint values of its D²−1/4 image are2a² at BOTH ends, and those of its first derivative are6iω_na². The periodic phase equals1 at x=L, so there is no extra endpoint phase. These statements also hold for n=0.

Thus all columns have the identical unbounded J-tail a²[J(x)+J(L−x)] modulo a bounded remainder. The rank-one statement concerns this singular part across the finite atom family; it does not say that the full physical cross operator has rank one or that the remainder is uniformly bounded independently of n orL.

For higher derivatives, put F_j(z)=(iz)^j[(iz)²−1/4]. The coefficient identity

    U_n^(j)(0)=F_j(ω_n)/2−F_j(ω_n−2a)/4−F_j(ω_n+2a)/4

is the source's exact three-frequency potential identity. The centered second difference lowers the leading degree j+2 by2. Its leading term is

    a²(j+1)(j+2)(iω_n)^j,

because −a²·i^(j+2)=a²i^j. This is nonzero as a polynomial coefficient in n for every j≥0,L>0. Lower terms cannot alter triangular invertibility of the first r endpoint jets against the first r coefficient moments Σn^kc_n. Complex coefficients cause no issue: the triangular identities hold overℂ.

For r≥1, killing those first r endpoint jets makes the zero extension C^(r−1). For r=0 there is no endpoint constraint; the zero extension may jump. The isolated C^(r−1) wording in §14 should therefore be read only for r≥1, rather than assigning a fictitious C^(−1) regularity class. The later r=0 decay/tail statement has its own valid integration-by-parts proof and does not need that wording.

## Finite-difference basis and edge cases

With z=exp(i2πx/L), F(z)=Σ_{n=−N}^Nc_nz^(n+N), the identity sin²(πx/L)=−(z−1)²/(4z) gives the stated potential exactly. The operator (z d/dz−N)^j evaluated at1 gives Σn^jc_n. Its triangular conversion to ordinary derivatives at1 has unit leading coefficient, so the moment conditions are equivalent to divisibility of F by(z−1)^r.

The polynomials1,(z−1),…,(z−1)^(2N) form a basis of all polynomials of degree≤2N by a triangular binomial matrix with diagonal1. There is no numerical solve or hidden rank hypothesis. The associated potential Φ_r=−z^(−N−1)(z−1)^(r+2)/4 has a zero of order r+2 at both endpoints; its D²−1/4 image v_r has the advertised first r vanishing jets and retains both ORIGINAL exponential legal moments by the same twice-integrated endpoint proof. This endpoint coefficient flag is not the141 weighted-moment complement from earlier sections.

Adversarial boundary checks:

* N=0 allows r=0 only and gives Φ₀=sin²(πx/L), the actual single atom. Its nonzero endpoint value after D²−1/4 is paid in C₀.
* r=0 uses one integration by parts, including both endpoint values. It givesO(1/|t|), not a false endpoint cancellation.
* At the maximal r=2N, the basis polynomial still lies within degree2N. The potential has order2N+2 zeros, so r+1 integrations by parts remain valid.
* The Fourier frequencies of Φ_r andv_r range from−N−1 up to r−N+1. In particular the complete atom span can involve±(N+1), although its atom CENTERS range only from−N toN. The manuscript's unspecified finite b_{r,k} sum correctly permits those outer frequencies; implementations must not truncate them to the centers.
* In the finite upper bound for C_r, |ω₀|⁰ is1, the ordinary zeroth derivative convention. Setting0⁰ to0 would incorrectly omit a constant Fourier term when r=0. For positive derivative orders the zero frequency contributes0, as expected.

## Integration by parts and full mixed tail

After r+1 integrations by parts, derivatives below r have zero endpoint values, while the r-th derivative boundary term is explicitly retained. Therefore

    |vhat_r(t)|≤[|v_r^(r)(0)|+|v_r^(r)(L)|
                +∫₀ᴸ|v_r^(r+1)|]/|t|^(r+1).

This includes the r=0 jump case. The finite Fourier upper bound in §15 follows by the triangle inequality separately for endpoints and the interior derivative integral. It need not be numerically sharp or well-conditioned to be a correct upper bound.

For t≥1, J=ceil(t+1) obeys J−3/4≥t+1/4. The digamma tail is at most (t/2)²/[2(J−3/4)²]≤1/8, after dropping its negative shift term. The first J terms are at mostH_J. Since H_J≤1+logJ≤1+log(t+2), and log(t+2)−logt≤log3<3/2, this proves w(t)<logt+3. The negative constants −γ−logπ can indeed be dropped for this upper bound. Together with the previously justified w(t)>−6 and evenness ofw, one gets |w(t)|≤6+log|t| for |t|≥1.

Set p=r+s+1≥1. The product Fourier tail is bounded by C_rC_s|t|^(−p−1). Integrating BOTH tails and the angular measure gives the factor1/π, not1/(2π). The exact elementary integral is

    ∫_T∞t^(−p−1)(6+logt)dt
      =T^(−p)[(6+logT)/p+1/p²], T≥1.

This gives the manuscript's full mixed-Gram tail for every pair r,s, including0,0. It pays offdiagonal as well as diagonal tails. Nothing requires unknown Weil positivity.

The full finite-support prime multiplier has absolute value at mostA_(L/2)=2Σ_{2≤m≤expL}Λ(m)/√m. Therefore replacing6 by6+A_(L/2) covers the entire multiplier with all active prime powers and both cosine orientations. Alternatively using the exact physical shifts and estimating only the Arch tail is valid.

The physical shifts are zero-extended translations H(x±logm); they are NOT periodic translates of the finite Fourier formula. The Fourier representation is only valid inside[0,L]. The indicator breakpoints x=logm and x=L−logm must remain in any physical integration. Treating the same trigonometric expression as periodic beyond the interval would be a different, generally false prime operator; §11 explicitly rules this out.

## Verdict and scope

No counterexample was found to §§11,14,15 under the stated finite-L,finite-N assumptions and the r=0 convention above. The physical tail, endpoint rank structure, binomial basis, and full mixed-Gram tail are compatible with the actual source atoms and normalization. These are ordinary analytic/algebraic identities and bounds. They do not establish positivity of any previously unverified low Gram matrix, all-radius Schur budget, or RH. No new kernel replay of these analytic formulas was performed by this review.
