#!/usr/bin/env python3
"""Exact rational arithmetic only; verifies constants, NOT the analytic theorem or Lean."""
from fractions import Fraction as F
from math import factorial
import hashlib, json, pathlib, sys

def require(b, name):
    if not b:
        raise ValueError("FAILED: " + name)

def exp_bounds(x, N=24):
    terms = [x**k / factorial(k) for k in range(N+1)]
    lower = sum(terms, F())
    first = x**(N+1) / factorial(N+1)
    ratio = x / (N+2)
    require(0 <= ratio < 1, "exp tail ratio")
    return lower, lower + first/(1-ratio)

def psi_lower(y, N):
    # psi real-part series; gamma<3/5 and log(pi)<23/20.
    s = sum((F(1,k+1) - (F(k)+F(1,4))/((F(k)+F(1,4))**2+y*y)
             for k in range(N)), F())
    tail = -F(3,4)/(F(N)-F(3,4))
    return s + tail - F(3,5) - F(23,20)

def main():
    # All exponentials below certified by positive Taylor terms + geometric tail.
    for x, threshold, relation in [(F(6932,10000),F(2),"lower"),
                                    (F(10987,10000),F(3),"lower"),
                                    (F(23,20),F(22,7),"lower"),
                                    (F(3,5),F(2),"upper")]:
        lo,hi=exp_bounds(x)
        require(lo>threshold if relation=="lower" else hi<threshold,
                "exp comparison "+str(x))
    log2_lower=2*sum((F(1,(2*j+1)*3**(2*j+1)) for j in range(3)),F())
    require(log2_lower>F(692,1000),"log2 lower artanh")
    H32=sum((F(1,k) for k in range(1,33)),F())
    require(H32-5*F(692,1000)<F(3,5),"Euler gamma upper")
    require(F(14142,10000)**2<2,"sqrt2 lower")
    require(F(17320,10000)**2<3,"sqrt3 lower")
    prime_upper=2*(F(6932,10000)/F(14142,10000)+F(10987,10000)/F(17320,10000))
    require(prime_upper<F(9,4),"full prime-power norm at length6/5")
    w64_lower=psi_lower(F(32),1024)
    w0_lower=psi_lower(F(0),2)
    require(w64_lower>F(229,100),"arch weight64")
    require(w0_lower>F(-6),"arch weight0")
    R=F(3,5);T=64;n=141
    # pi>3 and exp(R)<2; exact Hermite divided-difference remainder.
    eps_upper=F(4*R*T,3)*(R*R*(F(T*T)+F(1,4)))**n/F(factorial(n)**2)
    require(eps_upper<F(1,1000),"low Fourier mass")
    final_lower=F(229,100)*(1-F(1,1000))-6*F(1,1000)-F(9,4)
    require(final_lower>F(3,100),"positive complement lower bound")
    output={"status":"EXACT_RATIONAL_CONSTANT_CHECK_PASS",
      "analytic_proof_checked_by_this_program":False,"lean_kernel_run":False,"rh_proven":False,
      "inputs":{"support_half_width":"3/5","T":64,"p":71,"q":70,"total_order":141,
      "digamma_finite_terms":1024},
      "exact_conclusions":{"w64_lower_gt":"229/100","w0_lower_gt":"-6",
      "prime_operator_upper_lt":"9/4","low_fourier_mass_ratio_lt":"1/1000",
      "Weil_complement_coercivity_gt":"3/100"},
      "integer_comparisons_passed":True,
      "diagnostics_non_authoritative":{"w64_lower":float(w64_lower),
        "prime_upper":float(prime_upper),"lowmass_upper":float(eps_upper)},
      "checker_sha256":hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
    print(json.dumps(output,indent=2))

if __name__=="__main__":
    main()
