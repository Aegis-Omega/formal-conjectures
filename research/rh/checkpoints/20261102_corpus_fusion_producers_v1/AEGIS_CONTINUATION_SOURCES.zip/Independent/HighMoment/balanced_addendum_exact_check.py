#!/usr/bin/env python3
"""Exact constants/selector sanity checks only; not the ordinary proofs or Lean."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib,json
from high_moment_exact_bounds import require,psi_lower
n=142
eps=68*F(260109,100)**n/F(factorial(n)**2)
require(eps<F(1,10000),'balanced low-frequency leakage')
require(psi_lower(F(85,2),1024)>F(103,40),'balanced digamma85')
delta=F(103,40)*F(9999,10000)-6*F(1,10000)-F(9,4)
require(delta==F(129657,400000),'balanced exact gap identity')
require(delta>F(8,25),'balanced positive complement gap')
# R1 is a sanity check of indexing and integer relationships, not full factorial execution.
R=1;a=8*R*3**R;K=a+8;T=3**K;A0=R*(T+1);B0=2*R*T*3**R
J=max(2,3*A0,B0*(a+9));nR=2*J;N=J-2
require(nR>=6*A0,'dimension meets factorial ratio')
require(nR+1>B0*(a+9),'dimension meets lowmass denominator')
require(2*N+2==nR-2,'balanced low dimension')
print(json.dumps(dict(status='EXACT_RATIONAL_BALANCED_ADDENDUM_PASS',rh_proven=False,
    analytic_proof_checked_by_this_program=False,lean_kernel_run=False,
    order142=dict(epsilon_upper='1/10000',coercivity_nonstrict_universal='8/25',
                  stronger_strict_nonzero_gap=str(delta)),
    selector_R1=dict(R=R,prime_upper=a,T=T,A0=A0,B0=B0,J=J,total_order=nR,low_dimension=2*N+2),
    checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    dependency_sha256=hashlib.sha256(Path(__file__).with_name('high_moment_exact_bounds.py').read_bytes()).hexdigest()),indent=2))
