#!/usr/bin/env python3
"""Preserves the original T64 receipt; exact-rational stronger constants only."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib,json
from high_moment_exact_bounds import require,psi_lower
R=F(3,5); n=141
results=[]
for T,threshold,wlower,delta in [(80,F(1,10**10),F(251,100),F(1,4)),
                                  (85,F(13,20000),F(103,40),F(31,100))]:
    e=F(4*R*T,3)*(R*R*(F(T*T)+F(1,4)))**n/F(factorial(n)**2)
    w=psi_lower(F(T,2),1024)
    require(e<threshold,'low Fourier mass T'+str(T))
    require(w>wlower,'digamma T'+str(T))
    final=wlower*(1-threshold)-6*threshold-F(9,4)
    require(final>delta,'positive complement T'+str(T))
    results.append(dict(T=T,epsilon_upper=str(threshold),w_lower=str(wlower),
                        coercivity_gt=str(delta),exact_arithmetic_lower=str(final)))
print(json.dumps(dict(status='EXACT_RATIONAL_EXTENSION_PASS',rh_proven=False,
    analytic_proof_checked_by_this_program=False,lean_kernel_run=False,results=results,
    checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    dependency_sha256=hashlib.sha256(Path(__file__).with_name('high_moment_exact_bounds.py').read_bytes()).hexdigest()),indent=2))
