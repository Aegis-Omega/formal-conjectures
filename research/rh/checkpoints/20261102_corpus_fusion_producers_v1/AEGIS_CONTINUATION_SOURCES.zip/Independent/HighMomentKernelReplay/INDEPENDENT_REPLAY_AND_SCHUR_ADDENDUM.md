# Independent integer replay and ordinary local Schur composition

Date: 2026-11-02. This addendum supersedes only the earlier review's description of the local exact Schur inequality as an unresolved ordinary sign obligation. Previous frozen files remain unchanged. The new exact arithmetic is kernel checked; the mollification/Schur transfer below is an ordinary proof, not a Lean theorem.

## Fresh exact-integer kernel replay

Source copied without modification from `/workspace/aegis-nov2/HighMomentExactConstants.lean` into this previously nonexistent directory. SHA256 is exactly

    4eccbe4e4524bf7bd10d378ab70fb50d58171b0d5f003daa5e21b16e56c380f8

Actual compiler: Lean4.33.1, commit819816b2e0a3bf405af45ae5c7af2491d8f5bee6, x86_64-unknown-linux-gnu, Release. No Mathlib import, no native_decide, no new mathematical axiom, no imported RH declaration.

Commands executed in this fresh directory:

    /workspace/aegis-nov2-runtime/toolchain/lean-4.33.1-linux/bin/lean --trust=0 -j2 -M4096 -o HighMomentExactConstants.olean HighMomentExactConstants.lean
    LEAN_PATH=/workspace/aegis-nov2-independent/HighMomentKernelReplay /workspace/aegis-nov2-runtime/toolchain/lean-4.33.1-linux/bin/lean --trust=0 -j2 -M4096 AuditTypes.lean
    PATH=/workspace/aegis-nov2-runtime/toolchain/lean-4.33.1-linux/bin:$PATH LEAN_PATH=/workspace/aegis-nov2-independent/HighMomentKernelReplay /workspace/aegis-nov2-runtime/toolchain/lean-4.33.1-linux/bin/leanchecker --fresh -v HighMomentExactConstants

All three commands returned exit0. Actual outputs are `compile.log`, `types-and-axioms.log`, and `leanchecker.log`. The compiler printed the first proof as `of_decide_eq_true (id (Eq.refl true))`; all six axiom reports state no axioms. AuditTypes re-elaborates the full six exact types and repeats all six axiom checks. Leanchecker replays this module and its imported constants into a fresh environment; it is the official same-Lean kernel tool, not a different foundational verifier.

Diagnostic note: this leanchecker does not implement a help option. An initial `--help` probe attempted its default module scan and was explicitly stopped. The successful recorded replay names exactly the target module and uses `--fresh`. That initial probe is not counted as verification.

The six endpoints prove only the following integer propositions: the cleared factorial bound; the complete1024-row Boolean positivity checks for numerators and denominators; the complete1024-row integer rounded-lower-bound check; the cleared finite lower-sum inequality; and the final integer margin comparison. Their actual types are in `types-and-axioms.log`. They do not themselves define digamma, the Weil form, the Hermite remainder, or the rational semantics of the rows.

## Integer-to-rational semantics independently checked

For R=3/5,T=85,n=141, the previously proved ordinary Hermite mass bound has

    (4RT/3)[R²(T²+1/4)]^141/(141!)²
      =68 (260109/100)^141/(141!)².

Here4RT/3 uses π>3 and exp(R)<2. The first exact Lean inequality is precisely the positive-denominator clearing of this expression <13/20000:68·20000=1360000. The recursive factorial is the usual natural factorial by its defining recursion.

At t=85, y=t/2=85/2, the j-th digamma-series rational summand is

    1/(j+1)−(j+1/4)/[(j+1/4)²+(85/2)²]
      =(28897−12j)/[(j+1)((4j+1)²+28900)].

For0≤j<1024 its numerator is strictly positive. Therefore natural subtraction28897−12j is the intended signed integer subtraction without truncation. Denominators are positive. Integer division at scale10^9 yields a rational lower bound lowerTerm/scale for every row, as checked over the full List.range1024; ordinary List.all semantics gives all rows, not a sample.

The digamma tail bound from the previous ordinary proof is3/(4·1024−3)=3/4093. Bounds γ<3/5 and logπ<23/20 cost a total7/4. Thus

    lowerSum/scale−7/4−3/4093>103/40

is equivalent, after multiplying positive denominators, to

    scale(173·4093+120)<40·4093·lowerSum,

which is the fifth exact endpoint. Hence it supports w(85)>103/40 only together with the separately checked analytic series and tail theorem.

Finally

    103/40−9/4−(103/40+6)(13/20000)
      =255541/800000=0.31942625>31/100.

The last Lean endpoint certifies the final strict comparison. The displayed equality and interpretation follow by ordinary rational algebra, not by pretending the Lean declaration contains the Weil inequality. Combining all separately justified analytic inputs therefore strengthens the ordinary high-moment complement to Q(V)>(31/100)||V||² for nonzero V at L=6/5. The analytic statement is still PORT_PENDING in Lean.

## Reusing the existing all-legal smooth window

The source `CvSWindowL43V1.window_L43` at PR92 f8cb6544e9451910fbf1ed5fa71e76a5fa1b747f has the exact type

    for every actual smooth legal packet g, every r,a,
    HalfWidthAt g r a →2r≤4/3 →actual zero quadratic(g)≥0.

The body explicitly supplies the trace premises, the positive gap, the far tau bound and relative row budget to `window_of_certificate_gram_moment`. There is no residual Schur hypothesis in this endpoint's type. The local source `/workspace/aegis-nov2/SourceCrosscheck/CvSWindowL43V1.lean` agrees byte-for-byte with the earlier pinned exact source: SHA256d2fa9d223ac0114995815ff4ebada406b18216eec6c1145cb991f4e04dd1294d, Git blobad354cb73a86952dc7bed0a04dbce285b5feb103. Its complete transitive source closure was not rebuilt by this reviewer. In particular the fresh integer replay above is not a replay of window_L43 or its imports.

The following is a valid ordinary composition from that source theorem and the previously checked exact smooth Weil/Arch/prime identification.

Let H∈X([0,6/5]) have both original exponential moments zero. Take a nonnegative real smooth mollifier ρ of integral1 supported in[−1,1], and ρε(x)=ε⁻¹ρ(x/ε),0<ε<1/15. Put Hε=H*ρε. Compact L² H is L¹, so Hε is compact smooth, supported in[−ε,6/5+ε]. Its width is6/5+2ε<4/3. Absolute Fubini gives, forσ=±1/2,

    ∫exp(σx)Hε(x)dx
      =[∫exp(σx)H(x)dx][∫exp(σx)ρε(x)dx]=0.

Thus actual unlift gives a smooth legal packet to which window_L43 applies; no moment correction is needed. Its normalized ordinary Q(Hε) is nonnegative by the source explicit-formula bridge.

In angular Fourier coordinates, Hhatε=Hhat·ρhatε, |ρhatε|≤1 and ρhatε→1 pointwise. The absolute Archimedean integrand is dominated by |w(ξ)||Hhat(ξ)|², which is integrable on X because w=O(log(2+|ξ|)). Dominated convergence proves convergence of the full Archimedean term, including its infinite tail.

All expanded supports have width<4/3<log4, so the complete prime operator still has only m=2,3. Hε→H in L², and

    |C_Hε(t)−C_H(t)|
      ≤||Hε−H||₂(||Hε||₂+||H||₂)→0

uniformly in t, by translation isometry and Cauchy–Schwarz in ordinary L². Therefore both retained prime contributions converge. No limit/sum interchange over infinitely many primes is required. We obtain Q(H)=lim Q(Hε)≥0 for every such rough legal H.

## Exact Schur consequence for the new moment decomposition

Every actual139-atom low vector v and every141-moment residual V in the preceding construction lies in X([0,6/5]) and has the original legal moments. Hence v+zV is legal for every complex z and is covered by the rough positivity just proved. The residual is coercive by the new complement bound, so Q(V)>0 whenever V≠0.

Write B_Q for the normalized Hermitian polarization of Q, linear in its first argument. Expanding Q(v+zV)≥0 for all z and minimizing the scalar quadratic gives

    Q(v)≥|B_Q(v,V)|²/Q(V).

Taking the supremum over every nonzero V in the exact moment complement yields the precise Schur inequality originally proposed as the next ordinary target. It is already obtainable by this composition; it should not remain on the ordinary open-obligation list merely because the new oblique projection differs from the source's internal orthogonal decomposition.

This conclusion does NOT imply the stronger computable sufficient inequality Q(v)≥c⁻¹||ΠAv||² using only a crude lower coercivity constant c. That replaces the exact inverse-complement energy by a larger upper budget and can fail even for a positive full form. Thus that optional finite matrix budget may remain a falsification target, but it is unnecessary for ordinary sign at this already covered width.

The genuinely unresolved global issue is coverage outside the existing all-legal width, or a separate valid global producer. This argument does not globalize a fixed-width window, prove RH, or formalize the new mollifier transfer. Trust dimensions remain separate: exact constants KERNEL_VERIFIED here; new analytic remainder/transfer ordinary proofs PORT_PENDING; historical smooth window source/body recovered with fresh closure replay pending in this independent review.
