import CvSFullBudgetJoinV1
import CvSFullTableRejectV1
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option maxHeartbeats 0
elab "#export_local_graph" : command => do
  let env ← getEnv
  let roots : List Name := [
    ``AEGIS.CvSCachedColumnV1.evalDot_eq,
    ``AEGIS.CvSCachedEnvelopeJoinV1.envelope_eq_cached,
    ``AEGIS.CvSFullTableClosureV1.full_table_contains,
    ``AEGIS.CvSFullTableClosureV1.full_table_mem,
    ``AEGIS.CvSFullTableClosureV1.real_envelope_mem,
    ``AEGIS.CvSFullBudgetJoinV1.budgetEnergy_le_of_inputs,
    ``AEGIS.CvSFullBudgetJoinV1.budgetEnergy_margin_le_of_inputs,
    ``AEGIS.CvSStrictRowBudgetV1.margin_exact,
    ``AEGIS.CvSStrictRowBudgetV1.margin_positive,
    ``AEGIS.CvSFullTableRejectV1.reject_zero_output,
    ``AEGIS.CvSFullTableRejectV1.reject_missing_diagonal,
    ``AEGIS.CvSFullTableRejectV1.reject_modified_cache]
  let mut pending := roots
  let mut seen : NameSet := {}
  let mut rows : Array Json := #[]
  while !pending.isEmpty do
    let n := pending.head!
    pending := pending.tail!
    if seen.contains n then continue
    seen := seen.insert n
    if let some ci := (env.setExporting false).find? n then
      let deps := ci.getUsedConstantsAsSet.toList
      pending := deps ++ pending
      let origin := match env.getModuleIdxFor? n with
        | some idx => env.header.moduleNames[idx.toNat]!.toString
        | none => env.mainModule.toString
      let isAxiom := match ci with | .axiomInfo _ => true | _ => false
      let isOpaque := match ci with | .opaqueInfo _ => true | _ => false
      let kind := match ci with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient_primitive"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
      let axioms ← collectAxioms n
      rows := rows.push (Json.mkObj [
        ("identifier", toJson n.toString),
        ("origin_module", toJson origin),
        ("is_axiom", toJson isAxiom),
        ("is_opaque", toJson isOpaque),
        ("kind", toJson kind),
        ("type_expr", toJson (toString ci.type)),
        ("direct_dependencies", toJson (deps.map Name.toString)),
        ("axioms", toJson (axioms.map Name.toString)),
        ("has_body", toJson (ci.value? (allowOpaque := true)).isSome)])
    else throwError m!"MISSING_DEPENDENCY: {n}"
  liftIO <| IO.FS.writeFile "/workspace/aegis-full-table-bridge/NATIVE_FULL_TABLE_PROOF_GRAPH.json"
    (Json.mkObj [("roots",toJson (roots.map Name.toString)),
      ("declarations",Json.arr rows)]).compress
  logInfo m!"NATIVE_PROOF_GRAPH_DECLARATIONS {rows.size}"
#export_local_graph
