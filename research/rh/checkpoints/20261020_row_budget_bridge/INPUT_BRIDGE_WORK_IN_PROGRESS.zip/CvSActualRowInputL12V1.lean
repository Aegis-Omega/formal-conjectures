/- Source memberships for the fixed L=6/5 relative row-budget calculation.
No output-table or positivity assumption is discharged by this input layer. -/
import CvSProjectedEntryL12V1
import CvSGramTailV1
import CvSTauSigned150L12V1
import CvSFrequencyIntervalV1

namespace AEGIS.CvSActualRowInputL12V1
open AEGIS.RHFixIntervalV1 AEGIS.CvSRationalIntervalV1
open AEGIS.CvSProjectedPackedCertificateL12V1 AEGIS.CvSProjectedEntryL12V1

/-- The actual transformed source coefficient, enclosed at arbitrary precision. -/
theorem transformedCoeff_mem (p : ℕ) (k : Fin 141) (i : Fin 139) :
    (AEGIS.CvSFrequencyIntervalV1.coefficientInterval p (signedFreq k)
      (wZ (signedFreq k) i)).Mem p (transformedCoeff k i) := by
  rw [transformedCoeff_eq]
  exact AEGIS.CvSFrequencyIntervalV1.coefficient_mem p (signedFreq k) (wZ (signedFreq k) i)

/-- Exact rational harmonic Gram kernel; the diagonal is the source upper bound. -/
def gramRat (NP : ℕ) (n m : ℤ) : ℚ :=
  if n = m then 1 / ((NP : ℚ) - n + 1 / 2) + 1 / ((NP : ℚ) + n + 1 / 2)
  else (harmonic ((NP : ℤ) - m).toNat - harmonic ((NP : ℤ) - n).toNat +
    (harmonic ((NP : ℤ) + n).toNat - harmonic ((NP : ℤ) + m).toNat)) / ((n : ℚ) - m)

/-- Identifies the rational data with the original real source definition. -/
theorem gramRat_cast (NP : ℕ) (n m : ℤ) :
    (gramRat NP n m : ℝ) = AEGIS.CvSGramTailV1.gramUp NP n m := by
  simp only [gramRat, AEGIS.CvSGramTailV1.gramUp, AEGIS.CvSGramTailV1.H]
  split_ifs <;> push_cast <;> rfl

/-- No numerical harmonic approximation is used. -/
theorem gramUp_mem (p NP : ℕ) (n m : ℤ) :
    (rationalRange p (gramRat NP n m) (gramRat NP n m)).Mem p
      (AEGIS.CvSGramTailV1.gramUp NP n m) := by
  rw [← gramRat_cast]
  exact rationalRange_mem p _ _ le_rfl le_rfl

end AEGIS.CvSActualRowInputL12V1
#print axioms AEGIS.CvSActualRowInputL12V1.transformedCoeff_mem
#print axioms AEGIS.CvSActualRowInputL12V1.gramRat_cast
#print axioms AEGIS.CvSActualRowInputL12V1.gramUp_mem
