import CvSRowBudgetEnvelopeV1
import CvSOddSignedEnclosureV1
import CvSRationalIntervalV1
import SourceRowDistributionV1
import RowBudgetStagedDotPilot
import CvSIntervalDivideV1
import CvSFrequencyIntervalV1
import CvSListIntervalDotV1
import RowBudgetListCell0Pilot
import CvSListIntervalMixedV1
import CvSNeSymmRegressionV1
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option maxHeartbeats 0
elab "#export_local_graph" : command => do
  let env ← getEnv
  let roots : List Name := [
    ``AEGIS.CvSIntervalMatrixProductV1.midpoint_error,
    ``AEGIS.CvSIntervalMatrixProductV1.dot_mem,
    ``AEGIS.CvSIntervalMatrixProductV1.matrixMul_mem,
    ``AEGIS.CvSIntervalMatrixProductV1.congruence_mem,
    ``AEGIS.CvSIntervalMatrixProductV1.hull_mem_left,
    ``AEGIS.CvSIntervalMatrixProductV1.downscale_mem,
    ``AEGIS.CvSIntervalMatrixProductV1.upscale_mem,
    ``AEGIS.CvSIntervalMatrixProductV1.mem_of_contains,
    ``AEGIS.CvSIntervalMatrixProductV1.tableCheck_sound,
    ``AEGIS.CvSRowBudgetEnvelopeV1.point_mem,
    ``AEGIS.CvSRowBudgetEnvelopeV1.envelope_mem,
    ``AEGIS.CvSRowBudgetEnvelopeV1.stored_envelope_mem_of_check,
    ``AEGIS.CvSOddSignedEnclosureV1.signed_enclosure,
    ``AEGIS.CvSOddSignedEnclosureV1.signed_rational_bounds,
    ``AEGIS.CvSRationalIntervalV1.rationalRange_mem,
    ``AEGIS.SourceRowDistributionV1.distribute_source_row,
    ``AEGIS.RowBudgetStagedDotPilot.weighted_column_exact,
    ``AEGIS.RowBudgetStagedDotPilot.gram_source_dot,
    ``AEGIS.RowBudgetStagedDotPilot.gram_tau_weighted_dot,
    ``AEGIS.CvSIntervalDivideV1.divPos_mem,
    ``AEGIS.CvSIntervalDivideV1.divInt_mem,
    ``AEGIS.CvSFrequencyIntervalV1.pi_bounds,
    ``AEGIS.CvSFrequencyIntervalV1.frequency_bounds,
    ``AEGIS.CvSFrequencyIntervalV1.coefficient_mem,
    ``AEGIS.CvSFrequencyIntervalV1.lp_mem,
    ``AEGIS.CvSFrequencyIntervalV1.lp_squared_mem,
    ``AEGIS.CvSListIntervalDotV1.listDot_eq_dot,
    ``AEGIS.CvSListIntervalDotV1.listCongruence_eq,
    ``AEGIS.RowBudgetListCell0Pilot.gram_source_exact,
    ``AEGIS.RowBudgetListCell0Pilot.gram_weighted_exact,
    ``AEGIS.RowBudgetListCell0Pilot.stored_cell0_fast,
    ``AEGIS.RowBudgetListCell0Pilot.original_eq_fast,
    ``AEGIS.RowBudgetListCell0Pilot.stored_cell0_original,
    ``AEGIS.CvSListIntervalMixedV1.mixed_listCongruence_eq,
    ``AEGIS.CvSNeSymmRegressionV1.reverse_ne,
    ``AEGIS.CvSNeSymmRegressionV1.gram_symm]
  let mut pending := roots
  let mut seen : NameSet := {}
  let mut rows : Array Json := #[]
  while !pending.isEmpty do
    let n := pending.head!
    pending := pending.tail!
    if seen.contains n then continue
    seen := seen.insert n
    if let some ci := (env.setExporting false).find? n then
      let deps := ci.getUsedConstantsAsSet.toList
      pending := deps ++ pending
      let origin := match env.getModuleIdxFor? n with
        | some idx => env.header.moduleNames[idx.toNat]!.toString
        | none => env.mainModule.toString
      let isAxiom := match ci with | .axiomInfo _ => true | _ => false
      let isOpaque := match ci with | .opaqueInfo _ => true | _ => false
      let kind := match ci with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient_primitive"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
      let axioms ← collectAxioms n
      rows := rows.push (Json.mkObj [
        ("identifier", toJson n.toString),
        ("origin_module", toJson origin),
        ("is_axiom", toJson isAxiom),
        ("is_opaque", toJson isOpaque),
        ("kind", toJson kind),
        ("type_expr", toJson (toString ci.type)),
        ("direct_dependencies", toJson (deps.map Name.toString)),
        ("axioms", toJson (axioms.map Name.toString)),
        ("has_body", toJson (ci.value? (allowOpaque := true)).isSome)])
    else throwError m!"MISSING_DEPENDENCY: {n}"
  liftIO <| IO.FS.writeFile "/workspace/aegis-row-budget-bridge/NATIVE_REPAIR_PROOF_GRAPH.json"
    (Json.mkObj [("roots",toJson (roots.map Name.toString)),
      ("declarations",Json.arr rows)]).compress
  logInfo m!"NATIVE_PROOF_GRAPH_DECLARATIONS {rows.size}"
#export_local_graph
