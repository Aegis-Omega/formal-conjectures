import CvSActualGramWindowV1
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option maxHeartbeats 0
elab "#export_local_graph" : command => do
  let env ← getEnv
  let roots : List Name := [
    ``AEGIS.CvSActualLiteralInputsV1.sourceKernel_signed,
    ``AEGIS.CvSActualLiteralInputsV1.projectedEntry_as_Y,
    ``AEGIS.CvSActualLiteralInputsV1.Q_mem,
    ``AEGIS.CvSActualLiteralInputsV1.actual_budgetEnergy_margin,
    ``AEGIS.CvSActualBasisBudgetV1.actualBudget_le_original,
    ``AEGIS.CvSActualRowConsumerV1.hfin,
    ``AEGIS.CvSActualRowConsumerV1.hB,
    ``AEGIS.CvSActualGramWindowV1.gramUp_nonneg,
    ``AEGIS.CvSActualGramWindowV1.gramTail_nonneg,
    ``AEGIS.CvSActualGramWindowV1.actual_hlow,
    ``AEGIS.CvSActualGramWindowV1.window_of_actual_rows,
    ``AEGIS.CvSActualGramWindowV1.window_of_trace_le_six,
    ``AEGIS.CvSKreinScalarUniformV1.gap_lower,
    ``AEGIS.CvSKreinScalarUniformV1.schur_budget_with_reserve]
  let mut pending := roots
  let mut seen : NameSet := {}
  let mut rows : Array Json := #[]
  while !pending.isEmpty do
    let n := pending.head!
    pending := pending.tail!
    if seen.contains n then continue
    seen := seen.insert n
    if let some ci := (env.setExporting false).find? n then
      let deps := ci.getUsedConstantsAsSet.toList
      pending := deps ++ pending
      let origin := match env.getModuleIdxFor? n with
        | some idx => env.header.moduleNames[idx.toNat]!.toString
        | none => env.mainModule.toString
      let isAxiom := match ci with | .axiomInfo _ => true | _ => false
      let isOpaque := match ci with | .opaqueInfo _ => true | _ => false
      let kind := match ci with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient_primitive"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
      let axioms ← collectAxioms n
      rows := rows.push (Json.mkObj [
        ("identifier", toJson n.toString),
        ("origin_module", toJson origin),
        ("is_axiom", toJson isAxiom),
        ("is_opaque", toJson isOpaque),
        ("kind", toJson kind),
        ("type_expr", toJson (toString ci.type)),
        ("direct_dependencies", toJson (deps.map Name.toString)),
        ("axioms", toJson (axioms.map Name.toString)),
        ("has_body", toJson (ci.value? (allowOpaque := true)).isSome)])
    else throwError m!"MISSING_DEPENDENCY: {n}"
  liftIO <| IO.FS.writeFile "ACTUAL_SOURCE_PROOF_GRAPH_RAW.json"
    (Json.mkObj [("roots",toJson (roots.map Name.toString)),
      ("declarations",Json.arr rows)]).compress
  logInfo m!"NATIVE_PROOF_GRAPH_DECLARATIONS {rows.size}"
#export_local_graph
