/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows18
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows18
theorem row180 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row180.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨180, by decide⟩) k := by decide +kernel
#print axioms row180
theorem row181 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row181.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨181, by decide⟩) k := by decide +kernel
#print axioms row181
theorem row182 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row182.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨182, by decide⟩) k := by decide +kernel
#print axioms row182
theorem row183 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row183.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨183, by decide⟩) k := by decide +kernel
#print axioms row183
theorem row184 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row184.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨184, by decide⟩) k := by decide +kernel
#print axioms row184
theorem row185 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row185.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨185, by decide⟩) k := by decide +kernel
#print axioms row185
theorem row186 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row186.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨186, by decide⟩) k := by decide +kernel
#print axioms row186
theorem row187 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row187.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨187, by decide⟩) k := by decide +kernel
#print axioms row187
theorem row188 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row188.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨188, by decide⟩) k := by decide +kernel
#print axioms row188
theorem row189 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows18.row189.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨189, by decide⟩) k := by decide +kernel
#print axioms row189
end AEGIS.CvSAnalyticERows18
