/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows6
theorem row60 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 60 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨60, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨60, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row60
theorem row61 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 61 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨61, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨61, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row61
theorem row62 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 62 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨62, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨62, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row62
theorem row63 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 63 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨63, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨63, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row63
theorem row64 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 64 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨64, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨64, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row64
theorem row65 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 65 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨65, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨65, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row65
theorem row66 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 66 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨66, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨66, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row66
theorem row67 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 67 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨67, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨67, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row67
theorem row68 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 68 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨68, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨68, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row68
theorem row69 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 69 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨69, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨69, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row69
end AEGIS.CvSAnalyticGRows6
