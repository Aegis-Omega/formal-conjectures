/- Fixed normalization and signed-tau source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetStagedDotPilot
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticScalarInputsV1

theorem tau_source : ∀ k : Fin 141,
    AEGIS.RowBudgetStagedDotPilot.T.getD k.val ⟨0, 0⟩ = tauBox 96 (signedFreq k) := by decide +kernel

theorem lp_source : AEGIS.RowBudgetListCell0Pilot.LP2 =
    AEGIS.CvSFrequencyIntervalV1.lpSquaredInterval 96 := by decide +kernel
end AEGIS.CvSAnalyticScalarInputsV1
#print axioms AEGIS.CvSAnalyticScalarInputsV1.tau_source
#print axioms AEGIS.CvSAnalyticScalarInputsV1.lp_source
