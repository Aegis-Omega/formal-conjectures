/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput130
import CvSCachedOutput131
import CvSCachedOutput132
import CvSCachedOutput133
import CvSCachedOutput134
import CvSCachedOutput135
import CvSCachedOutput136
import CvSCachedOutput137
import CvSCachedOutput138
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns13
theorem column130 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput130.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 130) := by decide +kernel
#print axioms column130
theorem column131 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput131.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 131) := by decide +kernel
#print axioms column131
theorem column132 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput132.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 132) := by decide +kernel
#print axioms column132
theorem column133 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput133.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 133) := by decide +kernel
#print axioms column133
theorem column134 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput134.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 134) := by decide +kernel
#print axioms column134
theorem column135 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput135.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 135) := by decide +kernel
#print axioms column135
theorem column136 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput136.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 136) := by decide +kernel
#print axioms column136
theorem column137 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput137.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 137) := by decide +kernel
#print axioms column137
theorem column138 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput138.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 138) := by decide +kernel
#print axioms column138
end AEGIS.CvSAnalyticQColumns13
