/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows8
theorem row80 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 80 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨80, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨80, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row80
theorem row81 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 81 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨81, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨81, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row81
theorem row82 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 82 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨82, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨82, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row82
theorem row83 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 83 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨83, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨83, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row83
theorem row84 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 84 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨84, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨84, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row84
theorem row85 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 85 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨85, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨85, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row85
theorem row86 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 86 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨86, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨86, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row86
theorem row87 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 87 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨87, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨87, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row87
theorem row88 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 88 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨88, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨88, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row88
theorem row89 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 89 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨89, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨89, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row89
end AEGIS.CvSAnalyticGRows8
