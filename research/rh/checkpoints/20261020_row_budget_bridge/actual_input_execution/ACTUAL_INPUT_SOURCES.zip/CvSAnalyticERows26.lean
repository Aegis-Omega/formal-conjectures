/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows26
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows26
theorem row260 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row260.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨260, by decide⟩) k := by decide +kernel
#print axioms row260
theorem row261 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row261.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨261, by decide⟩) k := by decide +kernel
#print axioms row261
theorem row262 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row262.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨262, by decide⟩) k := by decide +kernel
#print axioms row262
theorem row263 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row263.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨263, by decide⟩) k := by decide +kernel
#print axioms row263
theorem row264 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row264.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨264, by decide⟩) k := by decide +kernel
#print axioms row264
theorem row265 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row265.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨265, by decide⟩) k := by decide +kernel
#print axioms row265
theorem row266 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row266.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨266, by decide⟩) k := by decide +kernel
#print axioms row266
theorem row267 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row267.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨267, by decide⟩) k := by decide +kernel
#print axioms row267
theorem row268 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row268.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨268, by decide⟩) k := by decide +kernel
#print axioms row268
theorem row269 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows26.row269.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨269, by decide⟩) k := by decide +kernel
#print axioms row269
end AEGIS.CvSAnalyticERows26
