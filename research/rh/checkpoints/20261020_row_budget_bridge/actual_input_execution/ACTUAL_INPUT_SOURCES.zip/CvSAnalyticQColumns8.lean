/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput80
import CvSCachedOutput81
import CvSCachedOutput82
import CvSCachedOutput83
import CvSCachedOutput84
import CvSCachedOutput85
import CvSCachedOutput86
import CvSCachedOutput87
import CvSCachedOutput88
import CvSCachedOutput89
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns8
theorem column80 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput80.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 80) := by decide +kernel
#print axioms column80
theorem column81 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput81.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 81) := by decide +kernel
#print axioms column81
theorem column82 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput82.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 82) := by decide +kernel
#print axioms column82
theorem column83 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput83.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 83) := by decide +kernel
#print axioms column83
theorem column84 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput84.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 84) := by decide +kernel
#print axioms column84
theorem column85 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput85.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 85) := by decide +kernel
#print axioms column85
theorem column86 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput86.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 86) := by decide +kernel
#print axioms column86
theorem column87 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput87.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 87) := by decide +kernel
#print axioms column87
theorem column88 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput88.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 88) := by decide +kernel
#print axioms column88
theorem column89 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput89.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 89) := by decide +kernel
#print axioms column89
end AEGIS.CvSAnalyticQColumns8
