/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows5
theorem row50 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 50 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨50, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨50, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row50
theorem row51 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 51 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨51, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨51, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row51
theorem row52 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 52 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨52, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨52, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row52
theorem row53 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 53 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨53, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨53, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row53
theorem row54 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 54 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨54, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨54, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row54
theorem row55 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 55 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨55, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨55, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row55
theorem row56 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 56 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨56, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨56, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row56
theorem row57 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 57 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨57, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨57, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row57
theorem row58 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 58 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨58, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨58, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row58
theorem row59 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 59 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨59, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨59, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row59
end AEGIS.CvSAnalyticGRows5
