/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput120
import CvSCachedOutput121
import CvSCachedOutput122
import CvSCachedOutput123
import CvSCachedOutput124
import CvSCachedOutput125
import CvSCachedOutput126
import CvSCachedOutput127
import CvSCachedOutput128
import CvSCachedOutput129
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns12
theorem column120 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput120.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 120) := by decide +kernel
#print axioms column120
theorem column121 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput121.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 121) := by decide +kernel
#print axioms column121
theorem column122 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput122.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 122) := by decide +kernel
#print axioms column122
theorem column123 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput123.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 123) := by decide +kernel
#print axioms column123
theorem column124 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput124.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 124) := by decide +kernel
#print axioms column124
theorem column125 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput125.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 125) := by decide +kernel
#print axioms column125
theorem column126 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput126.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 126) := by decide +kernel
#print axioms column126
theorem column127 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput127.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 127) := by decide +kernel
#print axioms column127
theorem column128 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput128.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 128) := by decide +kernel
#print axioms column128
theorem column129 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput129.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 129) := by decide +kernel
#print axioms column129
end AEGIS.CvSAnalyticQColumns12
