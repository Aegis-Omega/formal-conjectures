/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows17
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows17
theorem row170 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row170.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨170, by decide⟩) k := by decide +kernel
#print axioms row170
theorem row171 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row171.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨171, by decide⟩) k := by decide +kernel
#print axioms row171
theorem row172 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row172.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨172, by decide⟩) k := by decide +kernel
#print axioms row172
theorem row173 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row173.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨173, by decide⟩) k := by decide +kernel
#print axioms row173
theorem row174 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row174.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨174, by decide⟩) k := by decide +kernel
#print axioms row174
theorem row175 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row175.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨175, by decide⟩) k := by decide +kernel
#print axioms row175
theorem row176 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row176.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨176, by decide⟩) k := by decide +kernel
#print axioms row176
theorem row177 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row177.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨177, by decide⟩) k := by decide +kernel
#print axioms row177
theorem row178 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row178.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨178, by decide⟩) k := by decide +kernel
#print axioms row178
theorem row179 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows17.row179.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨179, by decide⟩) k := by decide +kernel
#print axioms row179
end AEGIS.CvSAnalyticERows17
