/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows8
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows8
theorem row80 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row80.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨80, by decide⟩) k := by decide +kernel
#print axioms row80
theorem row81 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row81.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨81, by decide⟩) k := by decide +kernel
#print axioms row81
theorem row82 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row82.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨82, by decide⟩) k := by decide +kernel
#print axioms row82
theorem row83 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row83.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨83, by decide⟩) k := by decide +kernel
#print axioms row83
theorem row84 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row84.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨84, by decide⟩) k := by decide +kernel
#print axioms row84
theorem row85 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row85.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨85, by decide⟩) k := by decide +kernel
#print axioms row85
theorem row86 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row86.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨86, by decide⟩) k := by decide +kernel
#print axioms row86
theorem row87 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row87.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨87, by decide⟩) k := by decide +kernel
#print axioms row87
theorem row88 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row88.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨88, by decide⟩) k := by decide +kernel
#print axioms row88
theorem row89 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows8.row89.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨89, by decide⟩) k := by decide +kernel
#print axioms row89
end AEGIS.CvSAnalyticERows8
