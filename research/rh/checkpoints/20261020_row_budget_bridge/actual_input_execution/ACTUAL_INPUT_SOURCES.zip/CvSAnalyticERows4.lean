/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows4
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows4
theorem row40 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row40.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨40, by decide⟩) k := by decide +kernel
#print axioms row40
theorem row41 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row41.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨41, by decide⟩) k := by decide +kernel
#print axioms row41
theorem row42 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row42.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨42, by decide⟩) k := by decide +kernel
#print axioms row42
theorem row43 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row43.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨43, by decide⟩) k := by decide +kernel
#print axioms row43
theorem row44 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row44.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨44, by decide⟩) k := by decide +kernel
#print axioms row44
theorem row45 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row45.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨45, by decide⟩) k := by decide +kernel
#print axioms row45
theorem row46 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row46.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨46, by decide⟩) k := by decide +kernel
#print axioms row46
theorem row47 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row47.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨47, by decide⟩) k := by decide +kernel
#print axioms row47
theorem row48 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row48.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨48, by decide⟩) k := by decide +kernel
#print axioms row48
theorem row49 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows4.row49.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨49, by decide⟩) k := by decide +kernel
#print axioms row49
end AEGIS.CvSAnalyticERows4
