/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows22
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows22
theorem row220 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row220.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨220, by decide⟩) k := by decide +kernel
#print axioms row220
theorem row221 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row221.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨221, by decide⟩) k := by decide +kernel
#print axioms row221
theorem row222 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row222.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨222, by decide⟩) k := by decide +kernel
#print axioms row222
theorem row223 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row223.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨223, by decide⟩) k := by decide +kernel
#print axioms row223
theorem row224 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row224.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨224, by decide⟩) k := by decide +kernel
#print axioms row224
theorem row225 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row225.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨225, by decide⟩) k := by decide +kernel
#print axioms row225
theorem row226 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row226.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨226, by decide⟩) k := by decide +kernel
#print axioms row226
theorem row227 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row227.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨227, by decide⟩) k := by decide +kernel
#print axioms row227
theorem row228 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row228.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨228, by decide⟩) k := by decide +kernel
#print axioms row228
theorem row229 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows22.row229.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨229, by decide⟩) k := by decide +kernel
#print axioms row229
end AEGIS.CvSAnalyticERows22
