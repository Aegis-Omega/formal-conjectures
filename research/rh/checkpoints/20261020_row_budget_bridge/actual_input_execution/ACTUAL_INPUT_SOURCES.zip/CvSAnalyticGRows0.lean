/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows0
theorem row0 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 0 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨0, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨0, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row0
theorem row1 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 1 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨1, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨1, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row1
theorem row2 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 2 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨2, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨2, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row2
theorem row3 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 3 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨3, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨3, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row3
theorem row4 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 4 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨4, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨4, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row4
theorem row5 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 5 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨5, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨5, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row5
theorem row6 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 6 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨6, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨6, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row6
theorem row7 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 7 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨7, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨7, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row7
theorem row8 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 8 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨8, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨8, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row8
theorem row9 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 9 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨9, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨9, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row9
end AEGIS.CvSAnalyticGRows0
