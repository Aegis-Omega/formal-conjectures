/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows10
theorem row100 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 100 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨100, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨100, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row100
theorem row101 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 101 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨101, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨101, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row101
theorem row102 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 102 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨102, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨102, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row102
theorem row103 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 103 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨103, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨103, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row103
theorem row104 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 104 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨104, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨104, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row104
theorem row105 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 105 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨105, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨105, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row105
theorem row106 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 106 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨106, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨106, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row106
theorem row107 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 107 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨107, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨107, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row107
theorem row108 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 108 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨108, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨108, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row108
theorem row109 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 109 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨109, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨109, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row109
end AEGIS.CvSAnalyticGRows10
