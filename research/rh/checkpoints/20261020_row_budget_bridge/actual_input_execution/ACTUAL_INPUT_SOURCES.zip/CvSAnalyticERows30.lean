/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows30
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows30
theorem row300 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows30.row300.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨300, by decide⟩) k := by decide +kernel
#print axioms row300
end AEGIS.CvSAnalyticERows30
