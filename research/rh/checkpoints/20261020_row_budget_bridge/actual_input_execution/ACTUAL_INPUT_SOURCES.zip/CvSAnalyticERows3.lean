/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows3
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows3
theorem row30 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row30.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨30, by decide⟩) k := by decide +kernel
#print axioms row30
theorem row31 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row31.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨31, by decide⟩) k := by decide +kernel
#print axioms row31
theorem row32 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row32.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨32, by decide⟩) k := by decide +kernel
#print axioms row32
theorem row33 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row33.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨33, by decide⟩) k := by decide +kernel
#print axioms row33
theorem row34 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row34.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨34, by decide⟩) k := by decide +kernel
#print axioms row34
theorem row35 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row35.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨35, by decide⟩) k := by decide +kernel
#print axioms row35
theorem row36 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row36.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨36, by decide⟩) k := by decide +kernel
#print axioms row36
theorem row37 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row37.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨37, by decide⟩) k := by decide +kernel
#print axioms row37
theorem row38 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row38.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨38, by decide⟩) k := by decide +kernel
#print axioms row38
theorem row39 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows3.row39.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨39, by decide⟩) k := by decide +kernel
#print axioms row39
end AEGIS.CvSAnalyticERows3
