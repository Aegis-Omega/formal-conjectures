/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows12
theorem row120 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 120 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨120, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨120, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row120
theorem row121 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 121 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨121, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨121, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row121
theorem row122 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 122 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨122, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨122, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row122
theorem row123 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 123 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨123, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨123, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row123
theorem row124 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 124 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨124, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨124, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row124
theorem row125 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 125 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨125, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨125, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row125
theorem row126 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 126 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨126, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨126, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row126
theorem row127 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 127 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨127, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨127, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row127
theorem row128 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 128 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨128, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨128, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row128
theorem row129 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 129 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨129, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨129, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row129
end AEGIS.CvSAnalyticGRows12
