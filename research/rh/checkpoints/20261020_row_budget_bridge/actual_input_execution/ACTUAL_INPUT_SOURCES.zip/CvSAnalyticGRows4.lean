/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows4
theorem row40 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 40 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨40, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨40, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row40
theorem row41 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 41 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨41, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨41, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row41
theorem row42 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 42 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨42, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨42, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row42
theorem row43 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 43 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨43, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨43, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row43
theorem row44 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 44 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨44, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨44, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row44
theorem row45 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 45 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨45, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨45, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row45
theorem row46 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 46 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨46, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨46, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row46
theorem row47 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 47 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨47, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨47, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row47
theorem row48 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 48 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨48, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨48, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row48
theorem row49 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 49 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨49, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨49, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row49
end AEGIS.CvSAnalyticGRows4
