/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows2
theorem row20 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 20 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨20, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨20, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row20
theorem row21 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 21 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨21, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨21, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row21
theorem row22 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 22 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨22, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨22, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row22
theorem row23 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 23 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨23, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨23, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row23
theorem row24 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 24 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨24, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨24, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row24
theorem row25 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 25 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨25, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨25, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row25
theorem row26 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 26 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨26, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨26, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row26
theorem row27 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 27 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨27, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨27, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row27
theorem row28 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 28 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨28, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨28, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row28
theorem row29 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 29 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨29, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨29, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row29
end AEGIS.CvSAnalyticGRows2
