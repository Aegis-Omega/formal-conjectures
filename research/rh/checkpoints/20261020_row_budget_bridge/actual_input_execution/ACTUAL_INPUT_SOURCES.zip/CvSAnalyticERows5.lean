/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows5
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows5
theorem row50 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row50.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨50, by decide⟩) k := by decide +kernel
#print axioms row50
theorem row51 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row51.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨51, by decide⟩) k := by decide +kernel
#print axioms row51
theorem row52 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row52.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨52, by decide⟩) k := by decide +kernel
#print axioms row52
theorem row53 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row53.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨53, by decide⟩) k := by decide +kernel
#print axioms row53
theorem row54 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row54.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨54, by decide⟩) k := by decide +kernel
#print axioms row54
theorem row55 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row55.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨55, by decide⟩) k := by decide +kernel
#print axioms row55
theorem row56 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row56.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨56, by decide⟩) k := by decide +kernel
#print axioms row56
theorem row57 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row57.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨57, by decide⟩) k := by decide +kernel
#print axioms row57
theorem row58 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row58.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨58, by decide⟩) k := by decide +kernel
#print axioms row58
theorem row59 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows5.row59.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨59, by decide⟩) k := by decide +kernel
#print axioms row59
end AEGIS.CvSAnalyticERows5
