/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows11
theorem row110 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 110 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨110, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨110, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row110
theorem row111 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 111 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨111, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨111, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row111
theorem row112 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 112 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨112, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨112, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row112
theorem row113 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 113 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨113, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨113, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row113
theorem row114 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 114 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨114, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨114, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row114
theorem row115 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 115 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨115, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨115, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row115
theorem row116 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 116 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨116, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨116, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row116
theorem row117 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 117 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨117, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨117, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row117
theorem row118 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 118 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨118, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨118, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row118
theorem row119 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 119 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨119, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨119, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row119
end AEGIS.CvSAnalyticGRows11
