/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput0
import CvSCachedInput1
import CvSCachedInput2
import CvSCachedInput3
import CvSCachedInput4
import CvSCachedInput5
import CvSCachedInput6
import CvSCachedInput7
import CvSCachedInput8
import CvSCachedInput9
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns0
theorem column0 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput0.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨0, by decide⟩ := by decide +kernel
#print axioms column0
theorem column1 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput1.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨1, by decide⟩ := by decide +kernel
#print axioms column1
theorem column2 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput2.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨2, by decide⟩ := by decide +kernel
#print axioms column2
theorem column3 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput3.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨3, by decide⟩ := by decide +kernel
#print axioms column3
theorem column4 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput4.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨4, by decide⟩ := by decide +kernel
#print axioms column4
theorem column5 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput5.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨5, by decide⟩ := by decide +kernel
#print axioms column5
theorem column6 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput6.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨6, by decide⟩ := by decide +kernel
#print axioms column6
theorem column7 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput7.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨7, by decide⟩ := by decide +kernel
#print axioms column7
theorem column8 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput8.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨8, by decide⟩ := by decide +kernel
#print axioms column8
theorem column9 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput9.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨9, by decide⟩ := by decide +kernel
#print axioms column9
end AEGIS.CvSAnalyticXColumns0
