/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput30
import CvSCachedOutput31
import CvSCachedOutput32
import CvSCachedOutput33
import CvSCachedOutput34
import CvSCachedOutput35
import CvSCachedOutput36
import CvSCachedOutput37
import CvSCachedOutput38
import CvSCachedOutput39
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns3
theorem column30 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput30.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 30) := by decide +kernel
#print axioms column30
theorem column31 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput31.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 31) := by decide +kernel
#print axioms column31
theorem column32 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput32.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 32) := by decide +kernel
#print axioms column32
theorem column33 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput33.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 33) := by decide +kernel
#print axioms column33
theorem column34 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput34.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 34) := by decide +kernel
#print axioms column34
theorem column35 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput35.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 35) := by decide +kernel
#print axioms column35
theorem column36 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput36.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 36) := by decide +kernel
#print axioms column36
theorem column37 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput37.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 37) := by decide +kernel
#print axioms column37
theorem column38 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput38.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 38) := by decide +kernel
#print axioms column38
theorem column39 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput39.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 39) := by decide +kernel
#print axioms column39
end AEGIS.CvSAnalyticQColumns3
