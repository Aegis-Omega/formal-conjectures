/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows13
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows13
theorem row130 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row130.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨130, by decide⟩) k := by decide +kernel
#print axioms row130
theorem row131 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row131.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨131, by decide⟩) k := by decide +kernel
#print axioms row131
theorem row132 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row132.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨132, by decide⟩) k := by decide +kernel
#print axioms row132
theorem row133 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row133.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨133, by decide⟩) k := by decide +kernel
#print axioms row133
theorem row134 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row134.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨134, by decide⟩) k := by decide +kernel
#print axioms row134
theorem row135 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row135.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨135, by decide⟩) k := by decide +kernel
#print axioms row135
theorem row136 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row136.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨136, by decide⟩) k := by decide +kernel
#print axioms row136
theorem row137 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row137.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨137, by decide⟩) k := by decide +kernel
#print axioms row137
theorem row138 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row138.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨138, by decide⟩) k := by decide +kernel
#print axioms row138
theorem row139 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows13.row139.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨139, by decide⟩) k := by decide +kernel
#print axioms row139
end AEGIS.CvSAnalyticERows13
