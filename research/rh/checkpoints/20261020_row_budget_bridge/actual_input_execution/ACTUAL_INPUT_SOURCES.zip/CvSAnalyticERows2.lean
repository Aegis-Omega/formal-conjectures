/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows2
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows2
theorem row20 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row20.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨20, by decide⟩) k := by decide +kernel
#print axioms row20
theorem row21 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row21.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨21, by decide⟩) k := by decide +kernel
#print axioms row21
theorem row22 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row22.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨22, by decide⟩) k := by decide +kernel
#print axioms row22
theorem row23 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row23.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨23, by decide⟩) k := by decide +kernel
#print axioms row23
theorem row24 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row24.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨24, by decide⟩) k := by decide +kernel
#print axioms row24
theorem row25 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row25.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨25, by decide⟩) k := by decide +kernel
#print axioms row25
theorem row26 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row26.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨26, by decide⟩) k := by decide +kernel
#print axioms row26
theorem row27 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row27.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨27, by decide⟩) k := by decide +kernel
#print axioms row27
theorem row28 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row28.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨28, by decide⟩) k := by decide +kernel
#print axioms row28
theorem row29 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows2.row29.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨29, by decide⟩) k := by decide +kernel
#print axioms row29
end AEGIS.CvSAnalyticERows2
