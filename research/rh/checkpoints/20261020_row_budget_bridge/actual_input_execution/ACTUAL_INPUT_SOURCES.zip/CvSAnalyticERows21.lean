/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows21
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows21
theorem row210 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row210.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨210, by decide⟩) k := by decide +kernel
#print axioms row210
theorem row211 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row211.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨211, by decide⟩) k := by decide +kernel
#print axioms row211
theorem row212 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row212.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨212, by decide⟩) k := by decide +kernel
#print axioms row212
theorem row213 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row213.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨213, by decide⟩) k := by decide +kernel
#print axioms row213
theorem row214 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row214.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨214, by decide⟩) k := by decide +kernel
#print axioms row214
theorem row215 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row215.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨215, by decide⟩) k := by decide +kernel
#print axioms row215
theorem row216 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row216.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨216, by decide⟩) k := by decide +kernel
#print axioms row216
theorem row217 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row217.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨217, by decide⟩) k := by decide +kernel
#print axioms row217
theorem row218 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row218.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨218, by decide⟩) k := by decide +kernel
#print axioms row218
theorem row219 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows21.row219.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨219, by decide⟩) k := by decide +kernel
#print axioms row219
end AEGIS.CvSAnalyticERows21
