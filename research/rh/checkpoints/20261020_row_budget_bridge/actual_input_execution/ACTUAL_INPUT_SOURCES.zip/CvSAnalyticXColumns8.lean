/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput80
import CvSCachedInput81
import CvSCachedInput82
import CvSCachedInput83
import CvSCachedInput84
import CvSCachedInput85
import CvSCachedInput86
import CvSCachedInput87
import CvSCachedInput88
import CvSCachedInput89
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns8
theorem column80 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput80.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨80, by decide⟩ := by decide +kernel
#print axioms column80
theorem column81 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput81.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨81, by decide⟩ := by decide +kernel
#print axioms column81
theorem column82 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput82.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨82, by decide⟩ := by decide +kernel
#print axioms column82
theorem column83 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput83.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨83, by decide⟩ := by decide +kernel
#print axioms column83
theorem column84 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput84.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨84, by decide⟩ := by decide +kernel
#print axioms column84
theorem column85 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput85.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨85, by decide⟩ := by decide +kernel
#print axioms column85
theorem column86 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput86.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨86, by decide⟩ := by decide +kernel
#print axioms column86
theorem column87 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput87.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨87, by decide⟩ := by decide +kernel
#print axioms column87
theorem column88 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput88.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨88, by decide⟩ := by decide +kernel
#print axioms column88
theorem column89 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput89.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨89, by decide⟩ := by decide +kernel
#print axioms column89
end AEGIS.CvSAnalyticXColumns8
