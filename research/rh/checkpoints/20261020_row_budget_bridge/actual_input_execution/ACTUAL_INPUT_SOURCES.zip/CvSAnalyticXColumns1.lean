/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput10
import CvSCachedInput11
import CvSCachedInput12
import CvSCachedInput13
import CvSCachedInput14
import CvSCachedInput15
import CvSCachedInput16
import CvSCachedInput17
import CvSCachedInput18
import CvSCachedInput19
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns1
theorem column10 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput10.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨10, by decide⟩ := by decide +kernel
#print axioms column10
theorem column11 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput11.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨11, by decide⟩ := by decide +kernel
#print axioms column11
theorem column12 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput12.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨12, by decide⟩ := by decide +kernel
#print axioms column12
theorem column13 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput13.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨13, by decide⟩ := by decide +kernel
#print axioms column13
theorem column14 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput14.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨14, by decide⟩ := by decide +kernel
#print axioms column14
theorem column15 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput15.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨15, by decide⟩ := by decide +kernel
#print axioms column15
theorem column16 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput16.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨16, by decide⟩ := by decide +kernel
#print axioms column16
theorem column17 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput17.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨17, by decide⟩ := by decide +kernel
#print axioms column17
theorem column18 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput18.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨18, by decide⟩ := by decide +kernel
#print axioms column18
theorem column19 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput19.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨19, by decide⟩ := by decide +kernel
#print axioms column19
end AEGIS.CvSAnalyticXColumns1
