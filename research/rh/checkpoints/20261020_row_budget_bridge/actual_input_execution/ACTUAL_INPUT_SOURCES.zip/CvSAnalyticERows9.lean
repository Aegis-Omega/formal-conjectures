/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows9
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows9
theorem row90 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row90.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨90, by decide⟩) k := by decide +kernel
#print axioms row90
theorem row91 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row91.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨91, by decide⟩) k := by decide +kernel
#print axioms row91
theorem row92 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row92.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨92, by decide⟩) k := by decide +kernel
#print axioms row92
theorem row93 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row93.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨93, by decide⟩) k := by decide +kernel
#print axioms row93
theorem row94 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row94.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨94, by decide⟩) k := by decide +kernel
#print axioms row94
theorem row95 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row95.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨95, by decide⟩) k := by decide +kernel
#print axioms row95
theorem row96 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row96.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨96, by decide⟩) k := by decide +kernel
#print axioms row96
theorem row97 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row97.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨97, by decide⟩) k := by decide +kernel
#print axioms row97
theorem row98 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row98.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨98, by decide⟩) k := by decide +kernel
#print axioms row98
theorem row99 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows9.row99.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨99, by decide⟩) k := by decide +kernel
#print axioms row99
end AEGIS.CvSAnalyticERows9
