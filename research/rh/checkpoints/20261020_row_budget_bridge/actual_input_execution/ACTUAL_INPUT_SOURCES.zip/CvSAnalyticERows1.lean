/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows1
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows1
theorem row10 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row10.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨10, by decide⟩) k := by decide +kernel
#print axioms row10
theorem row11 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row11.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨11, by decide⟩) k := by decide +kernel
#print axioms row11
theorem row12 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row12.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨12, by decide⟩) k := by decide +kernel
#print axioms row12
theorem row13 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row13.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨13, by decide⟩) k := by decide +kernel
#print axioms row13
theorem row14 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row14.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨14, by decide⟩) k := by decide +kernel
#print axioms row14
theorem row15 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row15.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨15, by decide⟩) k := by decide +kernel
#print axioms row15
theorem row16 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row16.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨16, by decide⟩) k := by decide +kernel
#print axioms row16
theorem row17 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row17.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨17, by decide⟩) k := by decide +kernel
#print axioms row17
theorem row18 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row18.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨18, by decide⟩) k := by decide +kernel
#print axioms row18
theorem row19 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows1.row19.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨19, by decide⟩) k := by decide +kernel
#print axioms row19
end AEGIS.CvSAnalyticERows1
