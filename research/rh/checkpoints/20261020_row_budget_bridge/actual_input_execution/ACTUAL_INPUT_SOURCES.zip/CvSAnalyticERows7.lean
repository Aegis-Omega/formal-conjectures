/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows7
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows7
theorem row70 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row70.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨70, by decide⟩) k := by decide +kernel
#print axioms row70
theorem row71 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row71.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨71, by decide⟩) k := by decide +kernel
#print axioms row71
theorem row72 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row72.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨72, by decide⟩) k := by decide +kernel
#print axioms row72
theorem row73 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row73.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨73, by decide⟩) k := by decide +kernel
#print axioms row73
theorem row74 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row74.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨74, by decide⟩) k := by decide +kernel
#print axioms row74
theorem row75 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row75.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨75, by decide⟩) k := by decide +kernel
#print axioms row75
theorem row76 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row76.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨76, by decide⟩) k := by decide +kernel
#print axioms row76
theorem row77 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row77.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨77, by decide⟩) k := by decide +kernel
#print axioms row77
theorem row78 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row78.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨78, by decide⟩) k := by decide +kernel
#print axioms row78
theorem row79 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows7.row79.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨79, by decide⟩) k := by decide +kernel
#print axioms row79
end AEGIS.CvSAnalyticERows7
