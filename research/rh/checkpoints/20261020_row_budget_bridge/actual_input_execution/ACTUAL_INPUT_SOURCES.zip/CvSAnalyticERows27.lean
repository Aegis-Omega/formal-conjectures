/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows27
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows27
theorem row270 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row270.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨270, by decide⟩) k := by decide +kernel
#print axioms row270
theorem row271 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row271.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨271, by decide⟩) k := by decide +kernel
#print axioms row271
theorem row272 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row272.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨272, by decide⟩) k := by decide +kernel
#print axioms row272
theorem row273 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row273.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨273, by decide⟩) k := by decide +kernel
#print axioms row273
theorem row274 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row274.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨274, by decide⟩) k := by decide +kernel
#print axioms row274
theorem row275 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row275.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨275, by decide⟩) k := by decide +kernel
#print axioms row275
theorem row276 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row276.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨276, by decide⟩) k := by decide +kernel
#print axioms row276
theorem row277 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row277.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨277, by decide⟩) k := by decide +kernel
#print axioms row277
theorem row278 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row278.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨278, by decide⟩) k := by decide +kernel
#print axioms row278
theorem row279 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows27.row279.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨279, by decide⟩) k := by decide +kernel
#print axioms row279
end AEGIS.CvSAnalyticERows27
