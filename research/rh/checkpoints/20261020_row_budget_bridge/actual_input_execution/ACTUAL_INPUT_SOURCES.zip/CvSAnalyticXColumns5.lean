/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput50
import CvSCachedInput51
import CvSCachedInput52
import CvSCachedInput53
import CvSCachedInput54
import CvSCachedInput55
import CvSCachedInput56
import CvSCachedInput57
import CvSCachedInput58
import CvSCachedInput59
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns5
theorem column50 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput50.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨50, by decide⟩ := by decide +kernel
#print axioms column50
theorem column51 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput51.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨51, by decide⟩ := by decide +kernel
#print axioms column51
theorem column52 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput52.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨52, by decide⟩ := by decide +kernel
#print axioms column52
theorem column53 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput53.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨53, by decide⟩ := by decide +kernel
#print axioms column53
theorem column54 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput54.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨54, by decide⟩ := by decide +kernel
#print axioms column54
theorem column55 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput55.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨55, by decide⟩ := by decide +kernel
#print axioms column55
theorem column56 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput56.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨56, by decide⟩ := by decide +kernel
#print axioms column56
theorem column57 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput57.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨57, by decide⟩ := by decide +kernel
#print axioms column57
theorem column58 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput58.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨58, by decide⟩ := by decide +kernel
#print axioms column58
theorem column59 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput59.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨59, by decide⟩ := by decide +kernel
#print axioms column59
end AEGIS.CvSAnalyticXColumns5
