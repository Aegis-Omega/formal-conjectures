/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput60
import CvSCachedInput61
import CvSCachedInput62
import CvSCachedInput63
import CvSCachedInput64
import CvSCachedInput65
import CvSCachedInput66
import CvSCachedInput67
import CvSCachedInput68
import CvSCachedInput69
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns6
theorem column60 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput60.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨60, by decide⟩ := by decide +kernel
#print axioms column60
theorem column61 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput61.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨61, by decide⟩ := by decide +kernel
#print axioms column61
theorem column62 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput62.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨62, by decide⟩ := by decide +kernel
#print axioms column62
theorem column63 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput63.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨63, by decide⟩ := by decide +kernel
#print axioms column63
theorem column64 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput64.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨64, by decide⟩ := by decide +kernel
#print axioms column64
theorem column65 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput65.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨65, by decide⟩ := by decide +kernel
#print axioms column65
theorem column66 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput66.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨66, by decide⟩ := by decide +kernel
#print axioms column66
theorem column67 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput67.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨67, by decide⟩ := by decide +kernel
#print axioms column67
theorem column68 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput68.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨68, by decide⟩ := by decide +kernel
#print axioms column68
theorem column69 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput69.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨69, by decide⟩ := by decide +kernel
#print axioms column69
end AEGIS.CvSAnalyticXColumns6
