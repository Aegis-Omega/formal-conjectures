/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows3
theorem row30 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 30 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨30, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨30, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row30
theorem row31 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 31 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨31, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨31, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row31
theorem row32 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 32 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨32, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨32, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row32
theorem row33 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 33 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨33, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨33, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row33
theorem row34 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 34 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨34, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨34, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row34
theorem row35 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 35 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨35, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨35, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row35
theorem row36 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 36 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨36, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨36, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row36
theorem row37 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 37 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨37, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨37, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row37
theorem row38 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 38 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨38, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨38, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row38
theorem row39 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 39 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨39, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨39, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row39
end AEGIS.CvSAnalyticGRows3
