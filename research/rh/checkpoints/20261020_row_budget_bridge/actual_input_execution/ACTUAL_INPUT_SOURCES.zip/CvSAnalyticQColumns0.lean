/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput0
import CvSCachedOutput1
import CvSCachedOutput2
import CvSCachedOutput3
import CvSCachedOutput4
import CvSCachedOutput5
import CvSCachedOutput6
import CvSCachedOutput7
import CvSCachedOutput8
import CvSCachedOutput9
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns0
theorem column0 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput0.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 0) := by decide +kernel
#print axioms column0
theorem column1 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput1.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 1) := by decide +kernel
#print axioms column1
theorem column2 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput2.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 2) := by decide +kernel
#print axioms column2
theorem column3 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput3.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 3) := by decide +kernel
#print axioms column3
theorem column4 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput4.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 4) := by decide +kernel
#print axioms column4
theorem column5 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput5.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 5) := by decide +kernel
#print axioms column5
theorem column6 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput6.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 6) := by decide +kernel
#print axioms column6
theorem column7 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput7.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 7) := by decide +kernel
#print axioms column7
theorem column8 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput8.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 8) := by decide +kernel
#print axioms column8
theorem column9 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput9.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 9) := by decide +kernel
#print axioms column9
end AEGIS.CvSAnalyticQColumns0
