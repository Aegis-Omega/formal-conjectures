/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows10
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows10
theorem row100 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row100.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨100, by decide⟩) k := by decide +kernel
#print axioms row100
theorem row101 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row101.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨101, by decide⟩) k := by decide +kernel
#print axioms row101
theorem row102 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row102.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨102, by decide⟩) k := by decide +kernel
#print axioms row102
theorem row103 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row103.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨103, by decide⟩) k := by decide +kernel
#print axioms row103
theorem row104 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row104.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨104, by decide⟩) k := by decide +kernel
#print axioms row104
theorem row105 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row105.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨105, by decide⟩) k := by decide +kernel
#print axioms row105
theorem row106 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row106.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨106, by decide⟩) k := by decide +kernel
#print axioms row106
theorem row107 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row107.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨107, by decide⟩) k := by decide +kernel
#print axioms row107
theorem row108 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row108.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨108, by decide⟩) k := by decide +kernel
#print axioms row108
theorem row109 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows10.row109.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨109, by decide⟩) k := by decide +kernel
#print axioms row109
end AEGIS.CvSAnalyticERows10
