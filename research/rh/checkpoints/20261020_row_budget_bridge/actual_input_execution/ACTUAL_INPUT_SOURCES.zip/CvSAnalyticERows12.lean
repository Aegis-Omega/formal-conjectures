/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows12
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows12
theorem row120 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row120.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨120, by decide⟩) k := by decide +kernel
#print axioms row120
theorem row121 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row121.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨121, by decide⟩) k := by decide +kernel
#print axioms row121
theorem row122 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row122.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨122, by decide⟩) k := by decide +kernel
#print axioms row122
theorem row123 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row123.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨123, by decide⟩) k := by decide +kernel
#print axioms row123
theorem row124 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row124.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨124, by decide⟩) k := by decide +kernel
#print axioms row124
theorem row125 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row125.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨125, by decide⟩) k := by decide +kernel
#print axioms row125
theorem row126 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row126.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨126, by decide⟩) k := by decide +kernel
#print axioms row126
theorem row127 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row127.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨127, by decide⟩) k := by decide +kernel
#print axioms row127
theorem row128 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row128.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨128, by decide⟩) k := by decide +kernel
#print axioms row128
theorem row129 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows12.row129.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨129, by decide⟩) k := by decide +kernel
#print axioms row129
end AEGIS.CvSAnalyticERows12
