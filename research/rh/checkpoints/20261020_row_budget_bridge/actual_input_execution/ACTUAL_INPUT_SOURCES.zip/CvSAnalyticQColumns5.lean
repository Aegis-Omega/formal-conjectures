/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput50
import CvSCachedOutput51
import CvSCachedOutput52
import CvSCachedOutput53
import CvSCachedOutput54
import CvSCachedOutput55
import CvSCachedOutput56
import CvSCachedOutput57
import CvSCachedOutput58
import CvSCachedOutput59
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns5
theorem column50 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput50.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 50) := by decide +kernel
#print axioms column50
theorem column51 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput51.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 51) := by decide +kernel
#print axioms column51
theorem column52 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput52.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 52) := by decide +kernel
#print axioms column52
theorem column53 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput53.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 53) := by decide +kernel
#print axioms column53
theorem column54 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput54.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 54) := by decide +kernel
#print axioms column54
theorem column55 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput55.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 55) := by decide +kernel
#print axioms column55
theorem column56 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput56.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 56) := by decide +kernel
#print axioms column56
theorem column57 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput57.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 57) := by decide +kernel
#print axioms column57
theorem column58 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput58.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 58) := by decide +kernel
#print axioms column58
theorem column59 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput59.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 59) := by decide +kernel
#print axioms column59
end AEGIS.CvSAnalyticQColumns5
