/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput120
import CvSCachedInput121
import CvSCachedInput122
import CvSCachedInput123
import CvSCachedInput124
import CvSCachedInput125
import CvSCachedInput126
import CvSCachedInput127
import CvSCachedInput128
import CvSCachedInput129
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns12
theorem column120 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput120.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨120, by decide⟩ := by decide +kernel
#print axioms column120
theorem column121 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput121.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨121, by decide⟩ := by decide +kernel
#print axioms column121
theorem column122 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput122.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨122, by decide⟩ := by decide +kernel
#print axioms column122
theorem column123 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput123.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨123, by decide⟩ := by decide +kernel
#print axioms column123
theorem column124 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput124.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨124, by decide⟩ := by decide +kernel
#print axioms column124
theorem column125 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput125.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨125, by decide⟩ := by decide +kernel
#print axioms column125
theorem column126 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput126.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨126, by decide⟩ := by decide +kernel
#print axioms column126
theorem column127 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput127.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨127, by decide⟩ := by decide +kernel
#print axioms column127
theorem column128 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput128.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨128, by decide⟩ := by decide +kernel
#print axioms column128
theorem column129 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput129.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨129, by decide⟩ := by decide +kernel
#print axioms column129
end AEGIS.CvSAnalyticXColumns12
