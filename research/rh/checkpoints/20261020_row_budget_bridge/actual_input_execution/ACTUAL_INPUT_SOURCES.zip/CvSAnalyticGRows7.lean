/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows7
theorem row70 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 70 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨70, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨70, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row70
theorem row71 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 71 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨71, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨71, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row71
theorem row72 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 72 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨72, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨72, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row72
theorem row73 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 73 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨73, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨73, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row73
theorem row74 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 74 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨74, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨74, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row74
theorem row75 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 75 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨75, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨75, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row75
theorem row76 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 76 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨76, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨76, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row76
theorem row77 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 77 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨77, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨77, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row77
theorem row78 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 78 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨78, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨78, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row78
theorem row79 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 79 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨79, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨79, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row79
end AEGIS.CvSAnalyticGRows7
