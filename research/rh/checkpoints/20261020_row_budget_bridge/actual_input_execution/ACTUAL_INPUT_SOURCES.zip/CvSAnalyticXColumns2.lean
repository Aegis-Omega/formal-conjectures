/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput20
import CvSCachedInput21
import CvSCachedInput22
import CvSCachedInput23
import CvSCachedInput24
import CvSCachedInput25
import CvSCachedInput26
import CvSCachedInput27
import CvSCachedInput28
import CvSCachedInput29
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns2
theorem column20 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput20.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨20, by decide⟩ := by decide +kernel
#print axioms column20
theorem column21 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput21.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨21, by decide⟩ := by decide +kernel
#print axioms column21
theorem column22 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput22.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨22, by decide⟩ := by decide +kernel
#print axioms column22
theorem column23 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput23.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨23, by decide⟩ := by decide +kernel
#print axioms column23
theorem column24 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput24.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨24, by decide⟩ := by decide +kernel
#print axioms column24
theorem column25 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput25.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨25, by decide⟩ := by decide +kernel
#print axioms column25
theorem column26 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput26.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨26, by decide⟩ := by decide +kernel
#print axioms column26
theorem column27 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput27.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨27, by decide⟩ := by decide +kernel
#print axioms column27
theorem column28 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput28.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨28, by decide⟩ := by decide +kernel
#print axioms column28
theorem column29 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput29.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨29, by decide⟩ := by decide +kernel
#print axioms column29
end AEGIS.CvSAnalyticXColumns2
