/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows0
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows0
theorem row0 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row0.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨0, by decide⟩) k := by decide +kernel
#print axioms row0
theorem row1 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row1.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨1, by decide⟩) k := by decide +kernel
#print axioms row1
theorem row2 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row2.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨2, by decide⟩) k := by decide +kernel
#print axioms row2
theorem row3 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row3.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨3, by decide⟩) k := by decide +kernel
#print axioms row3
theorem row4 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row4.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨4, by decide⟩) k := by decide +kernel
#print axioms row4
theorem row5 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row5.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨5, by decide⟩) k := by decide +kernel
#print axioms row5
theorem row6 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row6.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨6, by decide⟩) k := by decide +kernel
#print axioms row6
theorem row7 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row7.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨7, by decide⟩) k := by decide +kernel
#print axioms row7
theorem row8 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row8.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨8, by decide⟩) k := by decide +kernel
#print axioms row8
theorem row9 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows0.row9.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨9, by decide⟩) k := by decide +kernel
#print axioms row9
end AEGIS.CvSAnalyticERows0
