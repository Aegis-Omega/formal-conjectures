/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput130
import CvSCachedInput131
import CvSCachedInput132
import CvSCachedInput133
import CvSCachedInput134
import CvSCachedInput135
import CvSCachedInput136
import CvSCachedInput137
import CvSCachedInput138
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns13
theorem column130 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput130.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨130, by decide⟩ := by decide +kernel
#print axioms column130
theorem column131 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput131.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨131, by decide⟩ := by decide +kernel
#print axioms column131
theorem column132 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput132.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨132, by decide⟩ := by decide +kernel
#print axioms column132
theorem column133 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput133.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨133, by decide⟩ := by decide +kernel
#print axioms column133
theorem column134 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput134.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨134, by decide⟩ := by decide +kernel
#print axioms column134
theorem column135 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput135.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨135, by decide⟩ := by decide +kernel
#print axioms column135
theorem column136 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput136.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨136, by decide⟩ := by decide +kernel
#print axioms column136
theorem column137 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput137.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨137, by decide⟩ := by decide +kernel
#print axioms column137
theorem column138 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput138.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨138, by decide⟩ := by decide +kernel
#print axioms column138
end AEGIS.CvSAnalyticXColumns13
