/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows15
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows15
theorem row150 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row150.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨150, by decide⟩) k := by decide +kernel
#print axioms row150
theorem row151 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row151.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨151, by decide⟩) k := by decide +kernel
#print axioms row151
theorem row152 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row152.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨152, by decide⟩) k := by decide +kernel
#print axioms row152
theorem row153 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row153.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨153, by decide⟩) k := by decide +kernel
#print axioms row153
theorem row154 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row154.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨154, by decide⟩) k := by decide +kernel
#print axioms row154
theorem row155 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row155.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨155, by decide⟩) k := by decide +kernel
#print axioms row155
theorem row156 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row156.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨156, by decide⟩) k := by decide +kernel
#print axioms row156
theorem row157 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row157.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨157, by decide⟩) k := by decide +kernel
#print axioms row157
theorem row158 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row158.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨158, by decide⟩) k := by decide +kernel
#print axioms row158
theorem row159 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows15.row159.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨159, by decide⟩) k := by decide +kernel
#print axioms row159
end AEGIS.CvSAnalyticERows15
