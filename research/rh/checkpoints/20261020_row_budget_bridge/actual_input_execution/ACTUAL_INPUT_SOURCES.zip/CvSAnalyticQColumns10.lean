/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput100
import CvSCachedOutput101
import CvSCachedOutput102
import CvSCachedOutput103
import CvSCachedOutput104
import CvSCachedOutput105
import CvSCachedOutput106
import CvSCachedOutput107
import CvSCachedOutput108
import CvSCachedOutput109
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns10
theorem column100 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput100.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 100) := by decide +kernel
#print axioms column100
theorem column101 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput101.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 101) := by decide +kernel
#print axioms column101
theorem column102 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput102.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 102) := by decide +kernel
#print axioms column102
theorem column103 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput103.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 103) := by decide +kernel
#print axioms column103
theorem column104 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput104.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 104) := by decide +kernel
#print axioms column104
theorem column105 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput105.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 105) := by decide +kernel
#print axioms column105
theorem column106 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput106.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 106) := by decide +kernel
#print axioms column106
theorem column107 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput107.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 107) := by decide +kernel
#print axioms column107
theorem column108 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput108.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 108) := by decide +kernel
#print axioms column108
theorem column109 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput109.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 109) := by decide +kernel
#print axioms column109
end AEGIS.CvSAnalyticQColumns10
