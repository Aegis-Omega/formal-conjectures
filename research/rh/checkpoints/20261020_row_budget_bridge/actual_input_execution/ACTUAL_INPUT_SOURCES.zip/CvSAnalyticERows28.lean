/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows28
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows28
theorem row280 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row280.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨280, by decide⟩) k := by decide +kernel
#print axioms row280
theorem row281 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row281.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨281, by decide⟩) k := by decide +kernel
#print axioms row281
theorem row282 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row282.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨282, by decide⟩) k := by decide +kernel
#print axioms row282
theorem row283 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row283.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨283, by decide⟩) k := by decide +kernel
#print axioms row283
theorem row284 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row284.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨284, by decide⟩) k := by decide +kernel
#print axioms row284
theorem row285 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row285.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨285, by decide⟩) k := by decide +kernel
#print axioms row285
theorem row286 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row286.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨286, by decide⟩) k := by decide +kernel
#print axioms row286
theorem row287 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row287.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨287, by decide⟩) k := by decide +kernel
#print axioms row287
theorem row288 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row288.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨288, by decide⟩) k := by decide +kernel
#print axioms row288
theorem row289 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows28.row289.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨289, by decide⟩) k := by decide +kernel
#print axioms row289
end AEGIS.CvSAnalyticERows28
