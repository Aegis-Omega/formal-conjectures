/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows6
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows6
theorem row60 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row60.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨60, by decide⟩) k := by decide +kernel
#print axioms row60
theorem row61 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row61.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨61, by decide⟩) k := by decide +kernel
#print axioms row61
theorem row62 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row62.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨62, by decide⟩) k := by decide +kernel
#print axioms row62
theorem row63 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row63.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨63, by decide⟩) k := by decide +kernel
#print axioms row63
theorem row64 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row64.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨64, by decide⟩) k := by decide +kernel
#print axioms row64
theorem row65 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row65.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨65, by decide⟩) k := by decide +kernel
#print axioms row65
theorem row66 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row66.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨66, by decide⟩) k := by decide +kernel
#print axioms row66
theorem row67 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row67.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨67, by decide⟩) k := by decide +kernel
#print axioms row67
theorem row68 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row68.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨68, by decide⟩) k := by decide +kernel
#print axioms row68
theorem row69 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows6.row69.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨69, by decide⟩) k := by decide +kernel
#print axioms row69
end AEGIS.CvSAnalyticERows6
