/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput40
import CvSCachedOutput41
import CvSCachedOutput42
import CvSCachedOutput43
import CvSCachedOutput44
import CvSCachedOutput45
import CvSCachedOutput46
import CvSCachedOutput47
import CvSCachedOutput48
import CvSCachedOutput49
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns4
theorem column40 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput40.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 40) := by decide +kernel
#print axioms column40
theorem column41 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput41.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 41) := by decide +kernel
#print axioms column41
theorem column42 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput42.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 42) := by decide +kernel
#print axioms column42
theorem column43 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput43.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 43) := by decide +kernel
#print axioms column43
theorem column44 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput44.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 44) := by decide +kernel
#print axioms column44
theorem column45 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput45.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 45) := by decide +kernel
#print axioms column45
theorem column46 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput46.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 46) := by decide +kernel
#print axioms column46
theorem column47 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput47.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 47) := by decide +kernel
#print axioms column47
theorem column48 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput48.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 48) := by decide +kernel
#print axioms column48
theorem column49 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput49.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 49) := by decide +kernel
#print axioms column49
end AEGIS.CvSAnalyticQColumns4
