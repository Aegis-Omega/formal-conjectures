/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput10
import CvSCachedOutput11
import CvSCachedOutput12
import CvSCachedOutput13
import CvSCachedOutput14
import CvSCachedOutput15
import CvSCachedOutput16
import CvSCachedOutput17
import CvSCachedOutput18
import CvSCachedOutput19
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns1
theorem column10 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput10.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 10) := by decide +kernel
#print axioms column10
theorem column11 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput11.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 11) := by decide +kernel
#print axioms column11
theorem column12 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput12.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 12) := by decide +kernel
#print axioms column12
theorem column13 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput13.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 13) := by decide +kernel
#print axioms column13
theorem column14 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput14.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 14) := by decide +kernel
#print axioms column14
theorem column15 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput15.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 15) := by decide +kernel
#print axioms column15
theorem column16 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput16.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 16) := by decide +kernel
#print axioms column16
theorem column17 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput17.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 17) := by decide +kernel
#print axioms column17
theorem column18 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput18.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 18) := by decide +kernel
#print axioms column18
theorem column19 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput19.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 19) := by decide +kernel
#print axioms column19
end AEGIS.CvSAnalyticQColumns1
