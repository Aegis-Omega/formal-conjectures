/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows9
theorem row90 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 90 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨90, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨90, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row90
theorem row91 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 91 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨91, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨91, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row91
theorem row92 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 92 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨92, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨92, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row92
theorem row93 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 93 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨93, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨93, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row93
theorem row94 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 94 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨94, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨94, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row94
theorem row95 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 95 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨95, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨95, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row95
theorem row96 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 96 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨96, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨96, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row96
theorem row97 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 97 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨97, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨97, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row97
theorem row98 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 98 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨98, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨98, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row98
theorem row99 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 99 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨99, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨99, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row99
end AEGIS.CvSAnalyticGRows9
