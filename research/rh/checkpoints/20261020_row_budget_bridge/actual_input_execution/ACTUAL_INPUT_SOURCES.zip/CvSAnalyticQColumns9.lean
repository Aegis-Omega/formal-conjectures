/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput90
import CvSCachedOutput91
import CvSCachedOutput92
import CvSCachedOutput93
import CvSCachedOutput94
import CvSCachedOutput95
import CvSCachedOutput96
import CvSCachedOutput97
import CvSCachedOutput98
import CvSCachedOutput99
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns9
theorem column90 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput90.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 90) := by decide +kernel
#print axioms column90
theorem column91 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput91.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 91) := by decide +kernel
#print axioms column91
theorem column92 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput92.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 92) := by decide +kernel
#print axioms column92
theorem column93 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput93.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 93) := by decide +kernel
#print axioms column93
theorem column94 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput94.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 94) := by decide +kernel
#print axioms column94
theorem column95 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput95.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 95) := by decide +kernel
#print axioms column95
theorem column96 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput96.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 96) := by decide +kernel
#print axioms column96
theorem column97 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput97.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 97) := by decide +kernel
#print axioms column97
theorem column98 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput98.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 98) := by decide +kernel
#print axioms column98
theorem column99 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput99.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 99) := by decide +kernel
#print axioms column99
end AEGIS.CvSAnalyticQColumns9
