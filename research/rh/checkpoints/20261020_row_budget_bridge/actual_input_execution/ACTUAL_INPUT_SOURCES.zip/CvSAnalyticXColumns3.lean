/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput30
import CvSCachedInput31
import CvSCachedInput32
import CvSCachedInput33
import CvSCachedInput34
import CvSCachedInput35
import CvSCachedInput36
import CvSCachedInput37
import CvSCachedInput38
import CvSCachedInput39
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns3
theorem column30 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput30.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨30, by decide⟩ := by decide +kernel
#print axioms column30
theorem column31 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput31.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨31, by decide⟩ := by decide +kernel
#print axioms column31
theorem column32 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput32.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨32, by decide⟩ := by decide +kernel
#print axioms column32
theorem column33 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput33.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨33, by decide⟩ := by decide +kernel
#print axioms column33
theorem column34 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput34.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨34, by decide⟩ := by decide +kernel
#print axioms column34
theorem column35 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput35.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨35, by decide⟩ := by decide +kernel
#print axioms column35
theorem column36 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput36.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨36, by decide⟩ := by decide +kernel
#print axioms column36
theorem column37 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput37.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨37, by decide⟩ := by decide +kernel
#print axioms column37
theorem column38 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput38.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨38, by decide⟩ := by decide +kernel
#print axioms column38
theorem column39 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput39.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨39, by decide⟩ := by decide +kernel
#print axioms column39
end AEGIS.CvSAnalyticXColumns3
