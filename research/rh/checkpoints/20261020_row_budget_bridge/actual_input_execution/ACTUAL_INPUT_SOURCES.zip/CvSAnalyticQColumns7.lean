/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput70
import CvSCachedOutput71
import CvSCachedOutput72
import CvSCachedOutput73
import CvSCachedOutput74
import CvSCachedOutput75
import CvSCachedOutput76
import CvSCachedOutput77
import CvSCachedOutput78
import CvSCachedOutput79
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns7
theorem column70 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput70.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 70) := by decide +kernel
#print axioms column70
theorem column71 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput71.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 71) := by decide +kernel
#print axioms column71
theorem column72 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput72.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 72) := by decide +kernel
#print axioms column72
theorem column73 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput73.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 73) := by decide +kernel
#print axioms column73
theorem column74 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput74.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 74) := by decide +kernel
#print axioms column74
theorem column75 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput75.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 75) := by decide +kernel
#print axioms column75
theorem column76 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput76.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 76) := by decide +kernel
#print axioms column76
theorem column77 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput77.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 77) := by decide +kernel
#print axioms column77
theorem column78 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput78.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 78) := by decide +kernel
#print axioms column78
theorem column79 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput79.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 79) := by decide +kernel
#print axioms column79
end AEGIS.CvSAnalyticQColumns7
