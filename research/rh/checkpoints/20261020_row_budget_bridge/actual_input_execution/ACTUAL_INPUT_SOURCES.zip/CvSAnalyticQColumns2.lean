/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput20
import CvSCachedOutput21
import CvSCachedOutput22
import CvSCachedOutput23
import CvSCachedOutput24
import CvSCachedOutput25
import CvSCachedOutput26
import CvSCachedOutput27
import CvSCachedOutput28
import CvSCachedOutput29
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns2
theorem column20 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput20.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 20) := by decide +kernel
#print axioms column20
theorem column21 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput21.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 21) := by decide +kernel
#print axioms column21
theorem column22 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput22.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 22) := by decide +kernel
#print axioms column22
theorem column23 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput23.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 23) := by decide +kernel
#print axioms column23
theorem column24 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput24.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 24) := by decide +kernel
#print axioms column24
theorem column25 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput25.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 25) := by decide +kernel
#print axioms column25
theorem column26 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput26.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 26) := by decide +kernel
#print axioms column26
theorem column27 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput27.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 27) := by decide +kernel
#print axioms column27
theorem column28 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput28.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 28) := by decide +kernel
#print axioms column28
theorem column29 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput29.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 29) := by decide +kernel
#print axioms column29
end AEGIS.CvSAnalyticQColumns2
