/- Original Q64-to-Q96 projected-entry input identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedOutput60
import CvSCachedOutput61
import CvSCachedOutput62
import CvSCachedOutput63
import CvSCachedOutput64
import CvSCachedOutput65
import CvSCachedOutput66
import CvSCachedOutput67
import CvSCachedOutput68
import CvSCachedOutput69
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticQColumns6
theorem column60 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput60.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 60) := by decide +kernel
#print axioms column60
theorem column61 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput61.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 61) := by decide +kernel
#print axioms column61
theorem column62 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput62.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 62) := by decide +kernel
#print axioms column62
theorem column63 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput63.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 63) := by decide +kernel
#print axioms column63
theorem column64 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput64.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 64) := by decide +kernel
#print axioms column64
theorem column65 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput65.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 65) := by decide +kernel
#print axioms column65
theorem column66 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput66.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 66) := by decide +kernel
#print axioms column66
theorem column67 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput67.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 67) := by decide +kernel
#print axioms column67
theorem column68 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput68.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 68) := by decide +kernel
#print axioms column68
theorem column69 : ∀ j : Fin 139,
    AEGIS.CvSCachedOutput69.q.getD j.val ⟨0, 0⟩ =
      upscale 32 (AEGIS.CvSPackedGramV1.Im certI j.val 69) := by decide +kernel
#print axioms column69
end AEGIS.CvSAnalyticQColumns6
