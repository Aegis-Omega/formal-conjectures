/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows1
theorem row10 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 10 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨10, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨10, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row10
theorem row11 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 11 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨11, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨11, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row11
theorem row12 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 12 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨12, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨12, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row12
theorem row13 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 13 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨13, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨13, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row13
theorem row14 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 14 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨14, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨14, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row14
theorem row15 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 15 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨15, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨15, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row15
theorem row16 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 16 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨16, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨16, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row16
theorem row17 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 17 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨17, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨17, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row17
theorem row18 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 18 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨18, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨18, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row18
theorem row19 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 19 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨19, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨19, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row19
end AEGIS.CvSAnalyticGRows1
