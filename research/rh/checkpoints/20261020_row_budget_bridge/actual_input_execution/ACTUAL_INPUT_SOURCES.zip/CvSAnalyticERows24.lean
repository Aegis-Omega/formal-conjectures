/- Exact source identity candidates; require original CvS import replay. -/
import CvSActualRowInputL12V1
import CvSSourceERows24
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticERows24
theorem row240 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row240.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨240, by decide⟩) k := by decide +kernel
#print axioms row240
theorem row241 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row241.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨241, by decide⟩) k := by decide +kernel
#print axioms row241
theorem row242 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row242.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨242, by decide⟩) k := by decide +kernel
#print axioms row242
theorem row243 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row243.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨243, by decide⟩) k := by decide +kernel
#print axioms row243
theorem row244 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row244.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨244, by decide⟩) k := by decide +kernel
#print axioms row244
theorem row245 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row245.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨245, by decide⟩) k := by decide +kernel
#print axioms row245
theorem row246 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row246.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨246, by decide⟩) k := by decide +kernel
#print axioms row246
theorem row247 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row247.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨247, by decide⟩) k := by decide +kernel
#print axioms row247
theorem row248 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row248.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨248, by decide⟩) k := by decide +kernel
#print axioms row248
theorem row249 : ∀ k : Fin 141,
    AEGIS.CvSSourceERows24.row249.values.getD k.val ⟨0, 0⟩ =
      kernelBox 96 (rowIndex ⟨249, by decide⟩) k := by decide +kernel
#print axioms row249
end AEGIS.CvSAnalyticERows24
