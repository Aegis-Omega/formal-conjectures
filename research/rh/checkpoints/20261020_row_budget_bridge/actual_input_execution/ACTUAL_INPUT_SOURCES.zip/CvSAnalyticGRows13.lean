/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows13
theorem row130 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 130 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨130, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨130, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row130
theorem row131 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 131 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨131, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨131, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row131
theorem row132 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 132 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨132, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨132, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row132
theorem row133 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 133 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨133, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨133, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row133
theorem row134 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 134 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨134, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨134, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row134
theorem row135 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 135 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨135, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨135, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row135
theorem row136 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 136 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨136, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨136, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row136
theorem row137 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 137 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨137, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨137, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row137
theorem row138 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 138 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨138, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨138, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row138
theorem row139 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 139 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨139, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨139, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row139
end AEGIS.CvSAnalyticGRows13
