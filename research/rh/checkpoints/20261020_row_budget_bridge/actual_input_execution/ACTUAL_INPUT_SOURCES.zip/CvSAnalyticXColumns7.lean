/- Actual transformed coefficient source identity candidates. -/
import CvSActualRowInputL12V1
import CvSCachedInput70
import CvSCachedInput71
import CvSCachedInput72
import CvSCachedInput73
import CvSCachedInput74
import CvSCachedInput75
import CvSCachedInput76
import CvSCachedInput77
import CvSCachedInput78
import CvSCachedInput79
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticXColumns7
theorem column70 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput70.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨70, by decide⟩ := by decide +kernel
#print axioms column70
theorem column71 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput71.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨71, by decide⟩ := by decide +kernel
#print axioms column71
theorem column72 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput72.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨72, by decide⟩ := by decide +kernel
#print axioms column72
theorem column73 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput73.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨73, by decide⟩ := by decide +kernel
#print axioms column73
theorem column74 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput74.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨74, by decide⟩ := by decide +kernel
#print axioms column74
theorem column75 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput75.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨75, by decide⟩ := by decide +kernel
#print axioms column75
theorem column76 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput76.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨76, by decide⟩ := by decide +kernel
#print axioms column76
theorem column77 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput77.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨77, by decide⟩ := by decide +kernel
#print axioms column77
theorem column78 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput78.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨78, by decide⟩ := by decide +kernel
#print axioms column78
theorem column79 : ∀ k : Fin 141,
    AEGIS.CvSCachedInput79.x.values.getD k.val ⟨0, 0⟩ = xBox k ⟨79, by decide⟩ := by decide +kernel
#print axioms column79
end AEGIS.CvSAnalyticXColumns7
