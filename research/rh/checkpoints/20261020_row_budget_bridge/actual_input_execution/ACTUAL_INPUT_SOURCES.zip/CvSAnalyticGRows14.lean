/- Actual rational harmonic Gram-majorant source identity candidates. -/
import CvSActualRowInputL12V1
import RowBudgetListCell0Pilot
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
open AEGIS.CvSActualRowInputL12V1 AEGIS.CvSProjectedPackedCertificateL12V1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
namespace AEGIS.CvSAnalyticGRows14
theorem row140 : ∀ l : Fin 141,
    (AEGIS.RowBudgetListCell0Pilot.G.getD 140 []).getD l.val ⟨0, 0⟩ =
      AEGIS.CvSRationalIntervalV1.rationalRange 96
        (gramRat 150 (signedFreq ⟨140, by decide⟩) (signedFreq l))
        (gramRat 150 (signedFreq ⟨140, by decide⟩) (signedFreq l)) := by decide +kernel
#print axioms row140
end AEGIS.CvSAnalyticGRows14
