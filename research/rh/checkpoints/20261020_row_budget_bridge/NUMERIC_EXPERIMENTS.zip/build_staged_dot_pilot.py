from pathlib import Path
import json,hashlib
w=Path('/workspace/aegis-row-budget-bridge');d=json.loads((w/'CELL0_INPUTS.json').read_text());P=96;S=1<<P
fmt=lambda v:f'⟨{v[0]}, {v[1]}⟩'
def mul(a,b):
 c=[a[i]*b[j] for i in range(2) for j in range(2)];return [min(c)//S,-((-max(c))//S)]
def dot(a,b):
 am=[(x+y)//2 for x,y in a];ar=[max(m-x,y-m) for (x,y),m in zip(a,am)]
 bm=[(x+y)//2 for x,y in b];br=[max(m-x,y-m) for (x,y),m in zip(b,bm)]
 c=sum(x*y for x,y in zip(am,bm));r=sum(abs(x)*yr+xr*abs(y)+xr*yr for x,xr,y,yr in zip(am,ar,bm,br))
 return [(c-r)//S,-((-(c+r))//S)]
dx=[mul(t,x) for t,x in zip(d['T'],d['X0'])];g0=d['G'][0]
vecs={'X0':d['X0'],'T':d['T'],'DX0':dx,'G0':g0}
s='''/- Staged real source-data arithmetic pilot. Only row 0 / column 0 products. -/
import CvSIntervalMatrixProductV1
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1
namespace AEGIS.RowBudgetStagedDotPilot
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
'''
for n,v in vecs.items():s+='def '+n+' : List Iv := ['+', '.join(fmt(a) for a in v)+']\n'
s+='''theorem weighted_column_exact :
    ∀ k : Fin 141, ((T.getD k.val ⟨0, 0⟩).mul 96 (X0.getD k.val ⟨0, 0⟩)) =
      DX0.getD k.val ⟨0, 0⟩ := by
  decide +kernel
'''
for name,v in [('gram_source_dot',d['X0']),('gram_tau_weighted_dot',dx)]:
 n='X0' if name=='gram_source_dot' else 'DX0'
 s+='theorem '+name+' : dot 96\n  (fun k : Fin 141 => G0.getD k.val ⟨0, 0⟩)\n  (fun k : Fin 141 => '+n+'.getD k.val ⟨0, 0⟩) = '+fmt(dot(g0,v))+' := by\n  decide +kernel\n'
s+='end AEGIS.RowBudgetStagedDotPilot\n'
for n in ['weighted_column_exact','gram_source_dot','gram_tau_weighted_dot']:s+='#print axioms AEGIS.RowBudgetStagedDotPilot.'+n+'\n'
(w/'RowBudgetStagedDotPilot.lean').write_text(s)
print('staged source bytes',len(s.encode()))
