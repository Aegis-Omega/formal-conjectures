"""Reconstruct exact source-box interval inputs using the stored rational Lambda.
No floating-point arithmetic is executed. Emits one genuine output-cell replay.
"""
from pathlib import Path
import json,re,hashlib
w=Path('/workspace/aegis-row-budget-bridge');root=Path('/workspace/formal-conjectures')
code=(root/'research/rh/checkpoints/20261020_row_budget/row_budget_exact.py').read_text();code=code[:code.index('# Deterministic rational Cholesky witness')]
start=code.index('Y=mm(E,X);');end=code.index('Lam=(LI*',start)
code=code[:start]+"Y=mm(E,X)\nstored=json.loads(Path('/workspace/aegis-row-budget-recovery/ROW_BUDGET_DATA.json').read_text())\nqproj=stored['projection_fractional_bits'];LI=np.array(stored['projection'],dtype=object)\n"+code[end:]
assert 'lstsq' not in code and 'dtype=float' not in code
ns={};exec(compile(code,'exact-input-reconstruction','exec'),ns)
D=json.loads(Path('/workspace/aegis-row-budget-recovery/ROW_BUDGET_DATA.json').read_text());C=ns['C'];assert all((int(C[0][i,j])//(1<<16),-((-int(C[1][i,j]))//(1<<16)))==tuple(D['I'][i][j]) for i in range(139) for j in range(139))
pair=lambda a,i,j:[int(a[0][i,j]),int(a[1][i,j])]
data={'p':96,'target':D['I'][0][0],'Q00':pair(ns['QI'],0,0),'X0':[pair(ns['X'],k,0) for k in range(141)],'T':[list(ns['T'][n]) for n in range(-70,71)],'G':[[pair(ns['G'],k,l) for l in range(141)] for k in range(141)],'Z0':[pair(ns['Z'],k,0) for k in range(301)],'LP2':list(ns['mul'](ns['lp'],ns['lp']))}
(w/'CELL0_INPUTS.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
fmt=lambda x:f'⟨{x[0]}, {x[1]}⟩'
s='''/- Actual certificate data, single-entry arithmetic pilot only. Not hB or RH. -/
import CvSRowBudgetEnvelopeV1
open AEGIS.RHFixIntervalV1 AEGIS.CvSIntervalMatrixProductV1 AEGIS.CvSRowBudgetEnvelopeV1
namespace AEGIS.RowBudgetCell0Pilot
set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option Elab.async false
'''
for name in ['X0','T','Z0']:s+='def '+name+' : List Iv :=\n  ['+', '.join(fmt(v) for v in data[name])+']\n'
for i,row in enumerate(data['G']):s+=f'private def GRow{i} : List Iv :=\n  ['+', '.join(fmt(v) for v in row)+']\n'
s+='def G : List (List Iv) := ['+', '.join('GRow'+str(i) for i in range(141))+']\n'
s+='def computed : Iv := downscale 16 (envelope 96\n  (fun (_ _ : Fin 1) => '+fmt(data['Q00'])+')\n  (fun (k : Fin 141) (_ : Fin 1) => X0.getD k.val ⟨0, 0⟩)\n  (fun (k l : Fin 141) => (G.getD k.val []).getD l.val ⟨0, 0⟩)\n  (fun k : Fin 141 => T.getD k.val ⟨0, 0⟩)\n  (fun (k : Fin 301) (_ : Fin 1) => Z0.getD k.val ⟨0, 0⟩)\n  '+fmt(data['LP2'])+' 0 0)\n'
s+='theorem stored_cell0_exact : computed = '+fmt(data['target'])+' := by\n  decide +kernel\nend AEGIS.RowBudgetCell0Pilot\n#print axioms AEGIS.RowBudgetCell0Pilot.stored_cell0_exact\n'
p=w/'RowBudgetCell0Pilot.lean';p.write_text(s)
(w/'CELL0_PROVENANCE.json').write_text(json.dumps({'classification':'Single cell (0,0), not full table or actual enclosure','source_head':ns['subprocess'].check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'rational_projection':'Exact Q48 witness loaded unchanged; no numerical fitting executed','all_19321_python_output_cells_match_stored_Q80':True,'emitted_kernel_cells':1,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'input_sha256':hashlib.sha256((w/'CELL0_INPUTS.json').read_bytes()).hexdigest(),'source_bound_hashes':json.loads((root/'research/rh/checkpoints/20261020_row_budget/ROW_BUDGET_EXACT_RECEIPT.json').read_text())['source_hashes']},indent=2)+'\n')
print('Emitted one-cell exact native program',len(s.encode()),'bytes',flush=True)
