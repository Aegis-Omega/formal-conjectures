import CvSFiniteCongruenceV1
import CvSDividedDifferenceCollectionV1
import CvSDyadicEnclosureV1
import NativeBasisRecovery
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms
open Lean Elab Command
set_option maxHeartbeats 0
elab "#export_local_graph" : command => do
  let env ← getEnv
  let roots : List Name := [
    ``AEGIS.CvSFiniteCongruenceV1.rotate_four_sums,
    ``AEGIS.CvSFiniteCongruenceV1.quadratic_form_finite_congruence,
    ``AEGIS.CvSFiniteCongruenceV1.transformed_coeff_linear,
    ``AEGIS.CvSFiniteCongruenceV1.quadratic_form_real_congruence,
    ``AEGIS.CvSDividedDifferenceCollectionV1.divided_difference_collection,
    ``AEGIS.CvSDividedDifferenceCollectionV1.diagonal_divided_difference_collection,
    ``AEGIS.CvSDyadicEnclosureV1.rescale_endpoint,
    ``AEGIS.CvSDyadicEnclosureV1.enclosure_transport,
    ``AEGIS.CvSTriangularTransportV1.upper_triangular_surjective,
    ``AEGIS.CvSRealBasisBoundV1.real_row_normSq_le,
    ``AEGIS.CvSRealBasisBoundV1.real_matrix_normSq_le,
    ``AEGIS.CvSRealBasisBoundV1.frobenius_pos_of_entry,
    ``AEGIS.CvSProjectedPackedCertificateL12V1.certR_upper,
    ``AEGIS.CvSProjectedPackedCertificateL12V1.certR_diag_ne_zero,
    ``AEGIS.CvSProjectedSchurBridgeL12V1.rCoeff_diag_ne_zero,
    ``AEGIS.CvSProjectedSchurBridgeL12V1.R_basis_surjective,
    ``AEGIS.CvSProjectedSchurBridgeL12V1.basisFrobenius_pos,
    ``AEGIS.CvSProjectedSchurBridgeL12V1.R_basis_normSq_bound,
    ``AEGIS.CvSProjectedSchurBridgeL12V1.R_basis_frobenius_bound]
  let mut pending := roots
  let mut seen : NameSet := {}
  let mut rows : Array Json := #[]
  while !pending.isEmpty do
    let n := pending.head!
    pending := pending.tail!
    if seen.contains n then continue
    seen := seen.insert n
    if let some ci := (env.setExporting false).find? n then
      let deps := ci.getUsedConstantsAsSet.toList
      pending := deps ++ pending
      let origin := match env.getModuleIdxFor? n with
        | some idx => env.header.moduleNames[idx.toNat]!.toString
        | none => env.mainModule.toString
      let isAxiom := match ci with | .axiomInfo _ => true | _ => false
      let isOpaque := match ci with | .opaqueInfo _ => true | _ => false
      let kind := match ci with
        | .axiomInfo _ => "axiom"
        | .defnInfo _ => "definition"
        | .thmInfo _ => "theorem"
        | .opaqueInfo _ => "opaque"
        | .quotInfo _ => "quotient_primitive"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
      let axioms ← collectAxioms n
      rows := rows.push (Json.mkObj [
        ("identifier", toJson n.toString),
        ("origin_module", toJson origin),
        ("is_axiom", toJson isAxiom),
        ("is_opaque", toJson isOpaque),
        ("kind", toJson kind),
        ("type_expr", toJson (toString ci.type)),
        ("direct_dependencies", toJson (deps.map Name.toString)),
        ("axioms", toJson (axioms.map Name.toString)),
        ("has_body", toJson (ci.value? (allowOpaque := true)).isSome)])
    else throwError m!"MISSING_DEPENDENCY: {n}"
  liftIO <| IO.FS.writeFile "/workspace/aegis-research-execution/current/NATIVE_BASIS_PROOF_GRAPH.json"
    (Json.mkObj [("roots",toJson (roots.map Name.toString)),
      ("declarations",Json.arr rows)]).compress
  logInfo m!"NATIVE_PROOF_GRAPH_DECLARATIONS {rows.size}"
#export_local_graph
