import json,sys,hashlib,subprocess,zipfile
from pathlib import Path
sys.setrecursionlimit(100000)
base=Path('/workspace/aegis-research-execution'); repo=Path('/workspace/formal-conjectures');dest=repo/'research/rh/checkpoints/20261020_basis_recovery'
path=base/'current/NATIVE_BASIS_PROOF_GRAPH.json';raw=json.loads(path.read_text());nodes={n['identifier']:n for n in raw['declarations']}
assert len(nodes)==len(raw['declarations'])
allow={'propext','Classical.choice','Quot.sound'}
assert all(set(x['axioms'])<=allow for x in nodes.values())
assert all(d in nodes for x in nodes.values() for d in x['direct_dependencies'])
assert not any(x['is_axiom'] and x['identifier'] not in allow for x in nodes.values())
ind={};lo={};stack=[];on=set();groups=[]
def visit(v):
 ind[v]=lo[v]=len(ind);stack.append(v);on.add(v)
 for w in nodes[v]['direct_dependencies']:
  if w not in ind:visit(w);lo[v]=min(lo[v],lo[w])
  elif w in on:lo[v]=min(lo[v],ind[w])
 if lo[v]==ind[v]:
  g=[]
  while True:
   w=stack.pop();on.remove(w);g.append(w)
   if w==v:break
  groups.append(g)
for v in nodes:
 if v not in ind:visit(v)
gid={n:i for i,g in enumerate(groups) for n in g};out=[];cyclic=0
for i,g in enumerate(groups):
 cyc=len(g)>1 or any(n in nodes[n]['direct_dependencies'] for n in g)
 if cyc:
  cyclic+=1;assert all(nodes[n]['kind'] in ['inductive','constructor'] for n in g),(g,[nodes[n]['kind'] for n in g])
 deps=sorted({gid[d] for n in g for d in nodes[n]['direct_dependencies'] if gid[d]!=i});assert all(j<i for j in deps)
 out.append({'id':i,'declarations':g,'direct_dependency_groups':deps,'kind':'kernel inductive/constructor group' if cyc else 'single declaration'})
# Original source paths for every imported module in this native closure.
mods=sorted({n['origin_module'] for n in nodes.values()});manifest=[]
leanprefix=Path(subprocess.check_output(['lake','env','lean','--print-prefix'],cwd=repo,text=True).strip())
custom={n:base/'analytic_bridge'/(n+'.lean') for n in ['CvSTriangularTransportV1','CvSRealBasisBoundV1','NativeBasisRecovery','CertRNative','CvSDividedDifferenceCollectionV1','CvSDyadicEnclosureV1']};custom['CvSFiniteCongruenceV1']=repo/'research/rh/feshbach_lean_v1/CvSFiniteCongruenceV1.lean'
for m in mods:
 rel=Path(*m.split('.')).with_suffix('.lean');choices=[custom.get(m),repo/rel,leanprefix/'src/lean'/rel]+[p/rel for p in (repo/'.lake/packages').iterdir() if p.is_dir()]
 p=next((p for p in choices if p is not None and p.is_file()),None)
 row={'module':m,'status':'FOUND' if p else 'SOURCE_NOT_LOCATED'}
 if p:
  b=p.read_bytes();row.update(path=str(p),sha256=hashlib.sha256(b).hexdigest(),blob_sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
 manifest.append(row)
obj={'scope':'Complete native proof-term closure for 19 roots (8 earlier algebra/scale + 11 basis roots). Actual analytic import consumers are separately CI-checked; not an RH proof.','source_commit':'c9fc5dfe42f5ddab6a621b088f16cd82603e4b98','lean':'4.33.1','mathlib':'0df444a360eaa60ab8c11dca51a86af692955474','roots':raw['roots'],'root_group_ids':[gid[n] for n in raw['roots']],'declaration_count':len(nodes),'metadata_cyclic_groups':cyclic,'proof_cycles':0,'missing_dependencies':0,'axioms':sorted(allow),'groups':out,'source_manifest':manifest,'raw_graph_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(dest/'AEGIS_RH_EXACT_HEAD_PROOF_GRAPH.json').write_text(json.dumps(obj,separators=(',',':'))+'\n')
with zipfile.ZipFile(dest/'NATIVE_BASIS_GRAPH.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in [path,base/'current/NativeBasisProofGraph.lean',Path(__file__)]:z.write(p,p.name)
print(json.dumps({'declarations':len(nodes),'roots':len(raw['roots']),'modules':len(mods),'missing_modules':[x['module'] for x in manifest if x['status']!='FOUND'],'metadata_scc':cyclic,'proof_cycles':0}))
