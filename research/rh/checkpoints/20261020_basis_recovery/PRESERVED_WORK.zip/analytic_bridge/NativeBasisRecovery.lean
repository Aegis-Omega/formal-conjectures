/- Exact source declaration slice for the basis map only.
All certR data and coefficient definitions have their actual source values.
This is not a replay of unrelated analytic imports of the original modules. -/
import CertRNative
import CvSTriangularTransportV1
import CvSRealBasisBoundV1
import Mathlib.Data.Complex.BigOperators

open scoped BigOperators

namespace AEGIS.CvSProjectedPackedCertificateL12V1
noncomputable def rCoeff (i j : Fin 139) : ℝ :=
  (((certR.getD i.val []).getD j.val 0 : ℤ) : ℝ) / 2 ^ 40
end AEGIS.CvSProjectedPackedCertificateL12V1

namespace AEGIS.CvSProjectedSchurBridgeL12V1
open AEGIS.CvSProjectedPackedCertificateL12V1
noncomputable def R_basis (v : Fin 139 → ℂ) : Fin 139 → ℂ :=
  fun i => ∑ j : Fin 139, (rCoeff i j : ℂ) * v j

/-- Nonzero diagonal of the actual rational coefficient matrix. -/
theorem rCoeff_diag_ne_zero (i : Fin 139) : rCoeff i i ≠ 0 := by
  change (RInt i i : ℝ) / (2 : ℝ) ^ 40 ≠ 0
  apply div_ne_zero
  · exact_mod_cast certR_diag_ne_zero i
  · norm_num

/-- Surjectivity of the exact source coefficient map. -/
theorem R_basis_surjective : Function.Surjective R_basis := by
  have hu : ∀ i j : Fin 139, j < i → (rCoeff i j : ℂ) = 0 := by
    intro i j h
    change (((RInt i j : ℤ) : ℝ) / (2 : ℝ) ^ 40 : ℂ) = 0
    rw [certR_upper i j h]
    simp
  have hd : ∀ i : Fin 139, (rCoeff i i : ℂ) ≠ 0 := by
    intro i
    exact_mod_cast rCoeff_diag_ne_zero i
  change Function.Surjective (fun (v : Fin 139 → ℂ) (i : Fin 139) =>
    ∑ j, (rCoeff i j : ℂ) * v j)
  exact AEGIS.CvSTriangularTransportV1.upper_triangular_surjective 139 _ hu hd

/-- The actual, dimension-explicit squared Frobenius budget. -/
noncomputable def basisFrobenius : ℝ := ∑ i : Fin 139, ∑ j : Fin 139, rCoeff i j ^ 2

/-- The Frobenius budget is positive from the verified diagonal. -/
theorem basisFrobenius_pos : 0 < basisFrobenius :=
  AEGIS.CvSRealBasisBoundV1.frobenius_pos_of_entry rCoeff 0 0 (rCoeff_diag_ne_zero 0)

/-- A uniform bound for all complex source coefficient vectors. -/
theorem R_basis_normSq_bound (v : Fin 139 → ℂ) :
    (∑ i, Complex.normSq (R_basis v i)) ≤
      basisFrobenius * ∑ j, Complex.normSq (v j) := by
  simpa only [basisFrobenius, R_basis] using
    AEGIS.CvSRealBasisBoundV1.real_matrix_normSq_le rCoeff v

end AEGIS.CvSProjectedSchurBridgeL12V1

#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.rCoeff_diag_ne_zero
#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.R_basis_surjective
#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.basisFrobenius_pos
#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.R_basis_normSq_bound
