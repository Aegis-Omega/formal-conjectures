from pathlib import Path
import re,json,hashlib
repo=Path('/workspace/formal-conjectures/research/rh/feshbach_lean_v1');rsource=repo/'CvSProjectedPackedCertificateL12V1.lean';bsource=repo/'CvSProjectedSchurBridgeL12V1.lean'
def decl(p,name):
 s=p.read_text();m=re.search(r'^noncomputable def '+name+r'\b',s,re.M);assert m;return s[m.start():s.index('\n\n',m.start())]
r=decl(rsource,'rCoeff');b=decl(bsource,'R_basis')
s='''/- Exact source declaration slice for the basis map only.
All certR data and coefficient definitions have their actual source values.
This is not a replay of unrelated analytic imports of the original modules. -/
import CertRNative
import CvSTriangularTransportV1
import CvSRealBasisBoundV1
import Mathlib.Data.Complex.BigOperators

open scoped BigOperators

namespace AEGIS.CvSProjectedPackedCertificateL12V1
'''+r+'''
end AEGIS.CvSProjectedPackedCertificateL12V1

namespace AEGIS.CvSProjectedSchurBridgeL12V1
open AEGIS.CvSProjectedPackedCertificateL12V1
'''+b+'''

/-- Nonzero diagonal of the actual rational coefficient matrix. -/
theorem rCoeff_diag_ne_zero (i : Fin 139) : rCoeff i i ≠ 0 := by
  change (RInt i i : ℝ) / (2 : ℝ) ^ 40 ≠ 0
  apply div_ne_zero
  · exact_mod_cast certR_diag_ne_zero i
  · norm_num

/-- Surjectivity of the exact source coefficient map. -/
theorem R_basis_surjective : Function.Surjective R_basis := by
  have hu : ∀ i j : Fin 139, j < i → (rCoeff i j : ℂ) = 0 := by
    intro i j h
    change (((RInt i j : ℤ) : ℝ) / (2 : ℝ) ^ 40 : ℂ) = 0
    rw [certR_upper i j h]
    simp
  have hd : ∀ i : Fin 139, (rCoeff i i : ℂ) ≠ 0 := by
    intro i
    exact_mod_cast rCoeff_diag_ne_zero i
  change Function.Surjective (fun (v : Fin 139 → ℂ) (i : Fin 139) =>
    ∑ j, (rCoeff i j : ℂ) * v j)
  exact AEGIS.CvSTriangularTransportV1.upper_triangular_surjective 139 _ hu hd

/-- The actual, dimension-explicit squared Frobenius budget. -/
noncomputable def basisFrobenius : ℝ := ∑ i : Fin 139, ∑ j : Fin 139, rCoeff i j ^ 2

/-- The Frobenius budget is positive from the verified diagonal. -/
theorem basisFrobenius_pos : 0 < basisFrobenius :=
  AEGIS.CvSRealBasisBoundV1.frobenius_pos_of_entry rCoeff 0 0 (rCoeff_diag_ne_zero 0)

/-- A uniform bound for all complex source coefficient vectors. -/
theorem R_basis_normSq_bound (v : Fin 139 → ℂ) :
    (∑ i, Complex.normSq (R_basis v i)) ≤
      basisFrobenius * ∑ j, Complex.normSq (v j) := by
  simpa only [basisFrobenius, R_basis] using
    AEGIS.CvSRealBasisBoundV1.real_matrix_normSq_le rCoeff v

end AEGIS.CvSProjectedSchurBridgeL12V1

#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.rCoeff_diag_ne_zero
#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.R_basis_surjective
#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.basisFrobenius_pos
#print axioms AEGIS.CvSProjectedSchurBridgeL12V1.R_basis_normSq_bound
'''
p=Path('/workspace/aegis-research-execution/analytic_bridge/NativeBasisRecovery.lean');p.write_text(s)
meta={'kind':'source-extracted coefficient declarations with exact data; full analytic import replay separate','definitions':[{'name':'rCoeff','source':str(rsource),'body_sha256':hashlib.sha256(r.encode()).hexdigest()},{'name':'R_basis','source':str(bsource),'body_sha256':hashlib.sha256(b.encode()).hexdigest()}],'native_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};p.with_suffix('.PROVENANCE.json').write_text(json.dumps(meta,indent=2)+'\n')
