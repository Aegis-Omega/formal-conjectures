from pathlib import Path
import subprocess,time,json,hashlib,concurrent.futures
root=Path('/workspace/formal-conjectures');src=Path('/workspace/aegis-research-execution/analytic_bridge');out=Path('/workspace/aegis-research-execution/integration')
def run(name):
 p=src/(name+'.lean');cmd=['lake','env','lean','-R',str(src),'-DwarningAsError=true','-o',str(out/(name+'.olean')),str(p)];t=time.monotonic();r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);log=r.stdout+r.stderr;(src/(name+'.compile.log')).write_text(log);d={'name':name,'command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'compiler_output':log};(src/(name+'.compile.RECEIPT.json')).write_text(json.dumps(d,indent=2)+'\n');return d
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:rs=list(ex.map(run,['CvSTriangularTransportV1','CvSRealBasisBoundV1','CertRNative']))
for r in rs:print(r['name'],r['returncode'],r['seconds'])
assert all(r['returncode']==0 and 'sorryAx' not in r['compiler_output'] for r in rs)
