# Independent route pilot review

All three supplied pilot sources independently compile with Lean 4.33.1,
Mathlib `0df444a360eaa60ab8c11dca51a86af692955474`, and warnings treated as
errors. Every printed axiom set is the standard set
`{propext, Classical.choice, Quot.sound}`. Commands, source hashes, runtimes,
and final compiler outputs are recorded in
`INDEPENDENT_PILOT_REPLAY_RECEIPT.json` and the three route logs.

## B — fixed-parameter tail cutoff

**PASS: the six pilot lemmas, with their exact quantifiers.**
`sourceRowTail_zero` specializes the displayed tail schema correctly:

`tail(K=0) = 16 scale² T² (sum_{n in F} σ(a_n))² / (NP-R)`.

The numerical constant 16 includes both signs of the integer tail and the
square-expansion budget. Direct comparison with
`CvSRowTailV1.rowTail` shows the schema is literally its definition with
`τ = CvSRowTailV1.tau`, `σ = norm`, and `scale = L/pi`. The specialization
does not change normalization, moment coefficients, powers, or cutoffs.
This comparison is a source-level observation here; this pilot does not
import the actual analytic module or kernel-check a theorem about it.

The Archimedean existence argument chooses a cutoff larger than
`R + C/ε + 1`. It correctly controls every later cutoff. Zero C and empty
support are harmless. Strictly positive ε is needed for division. T and
scale may be arbitrary real numbers in the purely algebraic lemma because
they enter only through squares. In an actual row application the
inequality `|tau M L k| ≤ T` additionally implies T is nonnegative.

`sourceRowTail_uniform_cutoff` is uniform over finite supports and
coefficient vectors **relative to their squared l1 functional**. For
`σ=norm`, the same cutoff works for every such vector at fixed M, L, R,
T, ε. This is a genuine parameterized result, rather than a list of finite
certificates. It is not a bound relative to a dimension-independent l2
norm or an actual CvS low-block positive energy. In general
`(sum |a_n|)^2` grows like support size times `sum |a_n|^2`. A uniformly
bounded relative l1 tail therefore does not prove stable operator bounds
as windows and low-block dimensions grow.

For the actual cross rows, retain **all** hypotheses of the existing
`CvSRowTailV1.rows_tail_le`: `L>0`, actual support `|n|≤R`, `R<NP`, and a
uniform analytic bound `|tau M L k|≤T`. Its terminal sum also has a finite
outer truncation N; the new cutoff must control every N without confusing
N with NP. Compose the actual theorem at K=0 with the algebraic cutoff
to obtain a legitimate actual tail corollary. This is the smallest sound
next integration step and would require native replay in the actual
module context.

The pilot's positive-block counterexample correctly shows that positive
diagonal blocks do not control cross interaction. In particular, tail
convergence alone supplies no positive Schur margin.

Recommendation: **promote the narrowly scoped actual-tail integration**;
hold promotion of the complete universal Feshbach RH route until the
low-block-minus-cross inequality and growth of all relevant constants
have a mathematical argument.

## C — weighted clique obstruction

**PASS: all three lemmas.** A minimum positive weight has every other
weight ratio at least one. A clique floor d on its n off-diagonal costs
therefore forces the common row ceiling to be at least n*d. The proof
handles n=0 and d=0 correctly. Symmetry of the costs is unnecessary for
this obstruction. The Q16 corollary performs exact ordered-field
arithmetic and yields `n*q ≤ 46688` without changing scales or rounding.

The negative rank-one Gram identity proves nonpositivity for arbitrary
finite dimension and real amplitudes even though a norm majorant for its
off-diagonal entries can have growing row sums. This is a valid reason
to retain signed cancellation in the search.

The obstruction is generic. Applying its clique floor to actual Weil
atoms still requires the actual entry estimates. It does **not** refute
an existential producer allowed to select a different reconstruction for
each packet. In particular, it cannot invalidate `hselect` merely because
one repeated-atom decomposition has an excessive absolute Schur budget.

Recommendation: keep as a countertest and reusable obstruction. It is not
an estimate establishing the universal signed-defect target.

## D — reciprocal-pair obstruction

**PASS: both lemmas for positive real w.** Their sign follows from
`w*(w+w^-1-2) = (w-1)^2`. The unit case has zero contribution; every
positive real nonunit has a strictly negative contribution to
`2-(w+w^-1)`.

Actual Li spectral factors are generally complex and carry a phase.
This positive real countermodel refutes a proposed claim that reciprocal
pairing *alone* guarantees nonnegative contributions. It does not prove
an off-critical zeta zero exists, does not give a sign for every complex
reciprocal pair, and does not obstruct an argument that uses additional
genuine zeta-specific analytic information. No connection to actual zeros
is supplied by this pilot.

Recommendation: preserve as an exact countertest; it supplies no positive
Li-coefficient or RH theorem.

## Research gate

These pilots preserve useful unconditional mathematics and reject two
invalid shortcuts. The B cutoff lemma advances a uniform finite-tail
obligation at fixed analytic parameters. None supplies a uniform
positive low-block-minus-cross bound for cofinal windows, a universal
actual packet reconstruction, or the canonical unconditional RH theorem.
Promoting the complete research route solely on these pilot compilation
results would exceed the evidence.
