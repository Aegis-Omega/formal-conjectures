# Independent review: finite projected CvS transport

Verdict: **PASS for the finite algebra and the source conventions reviewed.**
The exact concrete `hTransport` consumer still needs its own true-import
kernel compilation. This review does not certify analytic entry enclosures,
R invertibility, R norm bounds, a trace gap, or universal RH positivity.

Source HEAD inspected: `8a8e902e0baa48413ec24cb6c1e92b47fe391497`.
Generic congruence source was untracked when reviewed.

## Index and conjugation check

Write P(k,j)=atomWeight j k and R(j,i)=rCoeff j i. The actual definitions are

```
X(k,i) = transformedCoeff k i = sum_j P(k,j)*R(j,i)
(R_basis v)(j) = sum_i R(j,i)*v(i)
projectedEntry(i,j) = sum_k,l X(k,i)*X(l,j)*signedEntry(k,l)
```

Thus X=P*R and the transformed Fourier coefficient is X*v=P*(R*v).
The actual stored orientation is R with original-atom index first and
new-coordinate index second. A transpose of `rCoeff` would be wrong.

Both `projectedQ` and `Q_CvS` have EXACTLY the convention
`sum_ij coeff_i * conj(coeff_j) * entry_ij`, followed by real part.
The generic lemma has that same convention, including conjugation of X(l,j)
for complex X. Here X is real, so its conjugation disappears under the cast.
No symmetry, Hermitian hypothesis, positivity, or inversion is needed for
this finite identity. Reversing the coefficient conjugation just because
some linear algebra APIs use conj(v_i)*v_j would require a separate change
of convention and is unnecessary here.

## Normalization check

`Q_CvS` and `projectedQ` both use `cvsEntry` itself, with the latter named
`signedEntry M k l` after frequency reindexing. `cvsEntry` includes its
source normalization `1/(2*pi)` in its definition. Therefore

```
projectedQ M v = Q_CvS M (6/5) atomCenter (R_basis v)
```

has NO extra factor 2*pi. The factor 2*pi appears separately in
`CvSLowBlockMatrixV1.lowBlock_quad_re`, converting this finite matrix form
into the integral of ScertM times the low-block Fourier energy. Adding that
factor to hTransport would double-count this conversion.

## Exact coefficient and support contracts

The actual `lowCoeff` includes an explicit support guard:

```
sum_j c(j) * if k in sinSqSupport(center(j))
  then sinSqWeight center(j) k * (iw L k * iw L k - 1/4) else 0
```

At L=6/5, `iw L k = 2*pi*I*k/L`, so
`iw L k * iw L k - 1/4 = -(2*pi*k/L)^2 - 1/4` under complexification.
This matches the real expression in `atomWeight`, with weights
-1/4,1/2,-1/4 at center-1,center,center+1. Outside the three-point support,
`sinSqWeight` is zero, so removing the guard requires only that elementary
case proof. No entry enclosure is involved in this coefficient identity.

For Fin139 centers -69..69, the union of all sinSq supports is exactly the
integer interval [-70,70]. `signedFreq : Fin141 -> Int`, i |-> i-70, is a
bijection onto that union. The geometry pilot proves this for copied
finite definitions. The concrete consumer must replay the same statements
against the actual imported definitions; a pilot using copied definitions
alone does not close the source-level consumer.

After these two contracts are proved with the real imports, finite
congruence and reindexing give hTransport with no remaining analytic
hypothesis. R surjectivity and its operator norm are logically separate
obligations needed by `original_atom_coercivity`, not by hTransport.

## Independent native replay

Executed from the repository root:

```
lake env lean -DwarningAsError=true research/rh/feshbach_lean_v1/CvSFiniteCongruenceV1.lean
```

Exit 0. All four named roots (`rotate_four_sums`,
`quadratic_form_finite_congruence`, `transformed_coeff_linear`,
`quadratic_form_real_congruence`) printed only
`[propext, Classical.choice, Quot.sound]`. Full output is retained in
`TRANSPORT_GENERIC_NATIVE.log`. This review does not attribute the generic
replay to the future concrete consumer or any unrun CI head.

## Source hashes

- `research/rh/feshbach_lean_v1/CvSFiniteCongruenceV1.lean`: SHA-256 `a24778f0572b4d98f6fe6f32430ad78f1c0ad0dd26362553ed8db24189749840`; Git blob `untracked`.
- `research/rh/feshbach_lean_v1/CvSProjectedSchurBridgeL12V1.lean`: SHA-256 `9a6610f043977239b42c25ec1ba555d97d5cb8bd998ac800aa05cdde183e725d`; Git blob `facc95a4dae16d7f6b0f75cffaabcba3aab988cb`.
- `research/rh/feshbach_lean_v1/CvSSchurClosureFromBoundsV1.lean`: SHA-256 `3de9cf1f377f5a3f1d8180b8f4c20e7a2a88ad96991564f2f70deb6c86b2e3eb`; Git blob `a2c26d3f0c98dfed7c1aa8c8c73613be929ea97d`.
- `research/rh/feshbach_lean_v1/CvSProjectedPackedCertificateL12V1.lean`: SHA-256 `a56736a7c4067638df73c4f98ef336962c88eca5a3613e3abb98ef500c7b0735`; Git blob `47e63143ff24f012389c780d9bbdd65eb4432dae`.
- `research/rh/feshbach_lean_v1/CvSLowBlockMatrixV1.lean`: SHA-256 `cf143cdc22525f55145fde9ca224e40102f8d957492b13b9aee34884e6aed7a9`; Git blob `2dc93a229fb07966c0cb7de0fc8d1107b0687c88`.
- `research/rh/feshbach_lean_v1/CvSMomentBasisV1.lean`: SHA-256 `465d2a0019ae8ea474456ff3ac631715a21776d561181e41dd28b023d186ca2e`; Git blob `0d37c5c5a262e46b5aa01fefed9422ebcdd95a2a`.
