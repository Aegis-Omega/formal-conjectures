# Independent review of the proposed actual-tail integration

Reviewed against base commit
`251b6636b1764f5bf243f59807ffc5ebed8ed782`, with the proposed uncommitted
source hashes recorded in `INTEGRATION_REVIEW_SOURCE_HASHES.json`.

**Mathematical/interface review: PASS.** No omitted mathematical premise,
reversed inequality, incorrect normalization, quantifier exchange, or
apparent namespace defect was found in the proposed actual-tail addition.

**Native replay: PASS for the six generic residual/cutoff roots and five
integrated C/D pilot roots.** Exact commands, source hashes, stable-source
checks, and compiler results are in `INTEGRATION_NATIVE_REPLAY.json` and
the corresponding integration-review logs. All eleven roots use only
standard axioms, and warnings are treated as errors.

**Actual CvS import-context kernel status: NOT_RUN in this review.** The
full actual `CvSRowTailV1` module has no available local dependency closure.
Source review must not be reported as its kernel receipt. The two new
actual roots require the exact-commit `krein-ring` CI compilation and
fresh axiom audits before being described as kernel verified.

## Actual proof and quantifiers

`rowTail_zero` unfolds the existing actual definition at K=0. It correctly
leaves `16*(L/pi)^2*T^2*(sum |a|)^2/(NP-R)` with the original CvS scale.
This identity is algebraic even for a zero denominator; it makes no
analytic assertion until a positive gap is supplied.

`exists_uniform_rows_tail_cutoff` first chooses NP for the nonnegative
constant `16*(L/pi)^2*tauBound(M)^2`. NP depends on M, L, R, ε; it is chosen
before P, F, a, and N. For P≥NP, `R<P` follows explicitly. The call to
`rows_tail_le` retains positive L, the support bound `|n|≤R`, actual
`crossRow`, and the actual coefficient vector. Its uniform source bound
is supplied by the proved `tau_abs_le M hL k`. The latter's displayed
right side unfolds definitionally to `tauBound M`, so no extra bound is
silently assumed.

The theorem consistently distinguishes P, the lower tail cutoff, from N,
the outer finite truncation. N need not exceed P: the corresponding tail
sum is then empty. F and a are quantified after the shared cutoff, and
their influence remains entirely in the squared l1 mass. Empty F and zero
vectors therefore work without cancellation or division by their energy.
No matrix coefficient is numerically approximated and no finite Gram
positivity hypothesis is introduced.

The `open AEGIS.CvSCrossCertV1 in` scope matches the existing source use of
`crossRow`; the imported generic cutoff is fully qualified. The actual
source lemma locations are after `tauBound` and after their dependency
theorems, so declaration ordering is correct. This is a static source
assessment, not a substitute for elaboration.

## Remaining scope limits

The conclusion controls every finite partial tail sum. An infinite tsum,
operator norm, or cofinal-window positivity result is not asserted. In
particular, the existing low-block Schur inequality, finite cross-row
budget, trace/slack bound, positive complement gap, and pointwise Krein
certificate remain necessary. The l1-to-l2 comparison and all dependence
on increasing M, L, and R must be controlled before a uniform global
operator argument is available.

The integrated C/D files preserve their previously reviewed statements.
C is an obstruction to demanding an absolute row certificate for every
arbitrary decomposition, not a refutation of existential hselect. D is a
positive-real reciprocal countermodel, not a theorem about arbitrary
complex Li factors or actual off-critical zeros. The feasibility README
keeps these distinctions and explicitly holds universal RH closure.

## Workflow review

The ring job compiles the new generic dependency into the same RING path
that is prepended to LEAN_PATH before compiling `CvSRowTailV1`. The new
actual root names are included in the existing fail-closed axiom audit.
The compile job executes and audits the six generic and five C/D roots.
The source-placeholder scan and workflow path trigger include the new
feasibility directory. No source definition, pin, protected branch,
deployment setting, or spending configuration is changed by this diff.
`git diff --check` passes.

Recommendation: the source is mathematically suitable for exact-commit
CI validation. Do not mark the actual new roots PASS, attribute the old
successful workflow to them, or promote the complete RH route before the
new exact-SHA compiler and axiom receipts exist.
