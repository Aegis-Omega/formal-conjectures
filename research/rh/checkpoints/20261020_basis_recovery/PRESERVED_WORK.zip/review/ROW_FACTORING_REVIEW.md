# Independent review: projected certificate row factoring

**PASS for source/data preservation.** No repository source was edited by
this review.

Compared the candidate
`CvSProjectedPackedCertificateL12V1.row_factored.lean` against immutable Git
source at `8a8e902e0baa48413ec24cb6c1e92b47fe391497`.
For each of `certR`, `certL` and `certI`:

- There are exactly 139 rows, each with 139 columns.
- Each helper body is the identical original row literal, byte for byte.
- All 417 row hashes match the factoring provenance.
- The reference order is exactly Row0 through Row138.
- Independent parsing gives identical integer values and interval endpoints.

Replacing the helper declarations and table-reference list with each
original table declaration reconstructs the **entire original source
byte for byte**. Therefore no other numerical constants, theorem
statements, proof bodies, imports or options changed in this candidate.
The helpers are transparent `private def` declarations, so the tables
reduce to their original values in the kernel.

Original SHA-256:
`a56736a7c4067638df73c4f98ef336962c88eca5a3613e3abb98ef500c7b0735`.
Candidate SHA-256:
`eaf36488eca078f2497ddab4e04dc3617a11ae764da23752dc1f40212b447009`.
Both match the supplied provenance file.

The supplied numerical-slice receipt records an 80.185-second successful
kernel check of `packed_check_true`, depending only on `propext`.
This reviewer inspected that receipt but did not rerun the 80-second check.
It covers the computational slice, not the complete analytic imports or
the actual entry-enclosure bridge. Exact-head full-context CI remains
necessary after applying the source-preserving elaboration repair.

Machine receipt: `ROW_FACTORING_REVIEW_RECEIPT.json`.
