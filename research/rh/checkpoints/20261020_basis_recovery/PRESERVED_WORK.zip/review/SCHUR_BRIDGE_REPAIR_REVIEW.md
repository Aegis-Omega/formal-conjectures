# Independent review of projected Schur bridge repairs

Original source reviewed at HEAD
`8a8e902e0baa48413ec24cb6c1e92b47fe391497`,
`research/rh/feshbach_lean_v1/CvSProjectedSchurBridgeL12V1.lean`.
Three concrete elaboration defects were identified independently:

1. `Im` is defined in `AEGIS.CvSPackedGramV1`. The bridge opened the projected
certificate and symmetry namespaces but not the packed namespace. Their
local `open AEGIS.CvSPackedGramV1` commands do not re-export `Im`. Opening
that namespace in the bridge, or qualifying `Im`, is required.

2. `hratio` uses `(div_le_iff₀ hkappa).2`, whose argument has right side
`normSqCoeffs v * kappa`. Its actual input `hRnorm v` has right side
`kappa * normSqCoeffs v`. A direct `exact` application does not commute
these factors definitionally. `simpa only [mul_comm] using hRnorm v`
repairs this without modifying the theorem statement.

3. `hscaled` uses `(div_le_iff₀ htwo).2`, producing right side
`projectedQ M v * 2^certQ`. The packed bound has
`2^certQ * projectedQ M v`. Simplifying the two definitions does not
commute these factors by default. Adding `mul_comm` to the simplification
repairs this step.

The main agent applied precisely these three source repairs. A second read
confirmed the new open, hratio simplification and hscaled simplification.
No certificate numbers, mathematical hypotheses or theorem conclusions
need change for these repairs.

## Independently executed failure-shape fixture

`SchurBridgeFailureShapes.lean` imports only the available
`Mathlib.Data.Real.Basic`. Its namespace fixture requires the exact
`Unknown identifier Im` diagnostic after opening a namespace that had
locally opened a different namespace. Its two real scalar proofs contain
`fail_if_success` checks rejecting the original factor-order applications,
then finish using `mul_comm`. Thus the fixture rejects the old proof shapes
and accepts the repairs; it contains no assumed axioms or placeholders.

Executed:

```
lake env lean -DwarningAsError=true /workspace/aegis-research-execution/review/SchurBridgeFailureShapes.lean
```

Exit 0. The two repaired scalar theorems print only
`[propext, Classical.choice, Quot.sound]`. Full output:
`SCHUR_BRIDGE_FAILURE_SHAPES.log`.

This is an abstract failure-shape regression, not a replay of the actual
certificate import DAG. The concrete bridge and transport compilation
remain subject to the actual-source CI run.

## New concrete transport source review

The new `CvSProjectedTransportL12V1` explicitly qualifies
`AEGIS.CvSPackedGramV1.Im` in both consumer hypotheses. The namespaces for
`A_CvS`, `Q_CvS`, `R_basis`, the projected coefficients and source atom
coefficients are opened explicitly. No further unqualified-name defect
was found in static review.

Its eight finite-algebra declarations and two consumer compositions have
consistent orientations, conjugations, index dimensions and normalization.
Both consumer wrappers discharge only `hTransport`; the analytic interval
membership, R surjectivity and R norm bound remain explicit. The low-block
wrapper additionally retains the trace gap and mixed-budget hypotheses.
The wrappers do not imply finite positivity without these assumptions and
do not constitute universal window positivity or RH.

Verdict: **PASS for identified repair correctness and static transport
review; actual-import kernel replay pending.**
