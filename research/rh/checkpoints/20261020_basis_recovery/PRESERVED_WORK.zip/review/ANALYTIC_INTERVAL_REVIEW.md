# Independent review: collected analytic intervals and dyadic transport

Four generic roots independently compiled with
`lake env lean -DwarningAsError=true`, exit 0, and only the standard axioms
`propext`, `Classical.choice`, `Quot.sound`:

- `CvSDividedDifferenceCollectionV1.divided_difference_collection`
- `CvSDividedDifferenceCollectionV1.diagonal_divided_difference_collection`
- `CvSDyadicEnclosureV1.rescale_endpoint`
- `CvSDyadicEnclosureV1.enclosure_transport`

The exact commands, source hashes and scope are recorded by the paired
receipt and the two `ANALYTIC_*_NATIVE.log` files. The collection source is
in the repository checkpoint at `research/rh/checkpoints/20261019_transport/analytic_bridge`.
The dyadic source was independently read from the external research
execution directory. No repository file was edited by this review.

## Collection identity and limits of its scope

The identity collects the two occurrences of each tau variable using
antisymmetry of the denominator. The second collected term has a PLUS sign:

```
sum_kl x_k y_l C (tau_k-tau_l)/(nu_k-nu_l)
 = sum_k C tau_k [x_k sum_l y_l/(nu_k-nu_l)
                  + y_k sum_l x_l/(nu_k-nu_l)]
```

No positivity, symmetry, cardinality bound, or distinct-node hypothesis is
needed for this finite real identity. With repeated nodes, Lean's division
by zero evaluates to zero on both sides. This does not assert that an
analytic divided difference at coincident nodes equals zero: the actual
CvS entry formula still distinguishes its diagonal. The second theorem
adds arbitrary diagonal entries exactly. In the actual signed-index
application, `signedFreq` injectivity supplies distinct off-diagonal nodes.

These are uniform finite algebra lemmas. They do not themselves enclose
any tau value or CvS entry and do not establish an infinite tail estimate.

## Actual source normalization

`CvSRowTailV1.cvsEntry_off` has coefficient `L/(2*pi^2)`. At L=6/5 this is
exactly `3/(5*pi^2)`, matching experiment variable C. No extra 2*pi belongs
in the projected finite entry: that factor is used separately to convert
CvS quadratic forms to the energy integral.

For signed frequency n, the moment-atom frequency factor is
`-(2*pi*n/(6/5))^2-1/4 = -(25/9)*pi^2*n^2-1/4`, matching the experiment.
Since `rCoeff` has denominator 2^40, the three-point weights give

```
X_n,i = factor_n * (2*R_n,i - R_(n-1),i - R_(n+1),i)/2^42.
```

The experiment correctly supplies zero outside the atom-center interval
[-69,69], while summing signed frequencies n=-70,...,70. Its denominator
`k-l` is the exact signed-frequency difference `(k-70)-(l-70)`.
The diagonal lookup is indexed by |n|, using the actual source diagonal
reflection theorem. The tau lookup has an explicit zero at n=0 and uses
oddness at negative n. Those are existing analytic facts, with source
table enclosure theorems requiring the prime cutoff hypothesis M>=3.
The rational pi endpoints are exactly those in `CvSTauL12V1.piLo/piHi`.

## Interval arithmetic review and independent replay

Python uses unbounded exact integers and `Fraction`, with no floating-point
arithmetic in the mathematical computation. Conversion floors lower
endpoints and ceils upper endpoints. Multiplication takes the minimum and
maximum of the four signed endpoint products before outward division by
2^96. Integer division handles negative denominators by interval negation;
zero denominators are skipped in H. Reciprocal pi-square bounds reverse
the positive pi endpoints correctly. The negative square in the frequency
factor also reverses endpoints correctly.

Shared tau variables are collected before interval evaluation. The signed
frequency sum is not folded in a way that drops terms. Treating correlated
pi occurrences and reflected tau intervals independently can enlarge the
result, but does not make the bounds unsound.

An independent rerun changed only the output location, preserving the
original script and its evidence. It reproduced **9730/9730 upper-triangle
containments**, with every interval endpoint identical to the original
result; only elapsed time differed (about 6.36 seconds). The current actual
Lean `certR` and `certI` tables were separately parsed and matched the input
JSON exactly. `certI` is symmetric. Thus upper-triangle checks can extend
to the lower triangle once actual entry symmetry and this table symmetry
are connected in the formal proof.

This remains an exact-integer experiment conditional on the analytic source
bounds. Its hardcoded source label is historical 8a8e902e; the paired receipt
records the current review head and current source hashes separately.
No new CI success is inferred from the experiment.

## Dyadic scale review

`rescale_endpoint p d m` proves exact preservation of the endpoint value
under multiplication of the integer numerator by 2^d and refinement of
the denominator from 2^p to 2^(p+d), for every p,d and signed integer m.
`enclosure_transport` correctly requires the coarser lower endpoint to be
no larger than the finer lower endpoint, and the finer upper endpoint to
be no larger than the coarser upper endpoint. It also requires a real
fine-scale enclosure of x. Its conclusion is the requested coarse enclosure.
At p=64,d=32, the exact containment test is multiplication of both Q64
endpoints by 2^32, matching the experiment. The result holds also at p=0
or d=0 and with negative endpoints.

The theorem does NOT construct the fine-scale enclosure premise, prove
that an evaluator computes it correctly, or prove the 9730 concrete integer
containment comparisons inside Lean. These remain distinct formal tasks.

## Dependency audit and verdict

The supplied generic graph has 8 roots and 9093 distinct declarations.
Independent parsing found every root and every direct dependency present,
and no axiom outside `propext`, `Classical.choice`, `Quot.sound`. This graph
covers the four congruence roots and four collection/scale roots; it is
not the complete analytic CvS certificate dependency graph.

Verdict: **PASS for four uniform algebra/scale roots and exact conditional
interval replay; actual analytic `hIv` kernel proof NOT established by this
review.** The next formal obligation is to derive source tau/diagonal/pi
intervals in the pinned import context, prove the signed finite interval
evaluator sound, kernel-check its concrete integer containments, and apply
the dyadic transport lemma for every projected entry. Neither this review
nor the generic dependency graph proves RH.
