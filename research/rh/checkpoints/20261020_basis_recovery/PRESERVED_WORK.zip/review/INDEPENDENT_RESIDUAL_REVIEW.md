# Independent residual-certificate review

Review date: 2026-10-19. Repository source commit:
`251b6636b1764f5bf243f59807ffc5ebed8ed782`.
Reviewed source SHA-256:
`27255393cb52cde3ba63d1b579425a6b291512b1d0e4cb6d375797b3a044e726`.

## Decision by scope

* **PASS — finite real residual-transfer mathematics.** All five statements
  are correct with precisely their displayed hypotheses.
* **PASS — independent native replay.** The exact source and shipped
  regression file compile with warnings treated as errors. All five source
  axiom audits contain only `propext`, `Classical.choice`, and `Quot.sound`.
* **PASS — independent boundary and counterexample replay.** The additional
  review source checks implied nonnegative radii/budgets, empty dimension
  with negative budget, signed residual entries, a centre outside its entry
  enclosure, a concrete nonsymmetric row-only counterexample, and the
  distinction between real-part positivity and a Hermitian matrix.
* **NOT_ESTABLISHED — actual CvS finite certificate.** No actual CvS entry
  enclosures, shifted centre certificate, concrete matrix data, or
  successful instantiation of the window consumer is supplied here.
* **NOT_ESTABLISHED — H140 recovery or replay.** The screenshots identify a
  Hilbert matrix benchmark, not an actual CvS/Weil matrix. The missing
  packed checker, generated data, and reported 14-theorem audit were not
  independently recovered by this review.
* **NOT_ESTABLISHED — unconditional RH, cofinal positivity, or a universal
  producer.** None follows from the reviewed finite transfer lemma.

## Mathematical checks

The scalar proof uses `|xy| ≤ (x²+y²)/2` and the supplied absolute residual
enclosure. Its multiplication inequalities are valid: `|e| ≤ r` already
implies `0 ≤ r`. An additional radius-nonnegativity premise is unnecessary.

Summing the scalar estimates produces two quadratic sums. Symmetry of the
majorant `R` permits exchanging their indices and combining them into
`sum_i x_i² sum_j R_ij`. The row budget then gives the desired bound.
Neither symmetry nor a sign condition on the actual residual `E` is needed
for this particular quadratic-form conclusion.

The sign in `actual_quadratic_nonneg` is correct. It applies the residual
bound to `A0-A`, so the result is `q(A0)-q(A) ≤ ε||x||²`; subtracting this
from the centre lower bound gives `q(A) ≥ 0`. There is no reversed
inequality, missing factor two, or loss of diagonal residual entries.

For a nonempty index type, nonnegative entries of `R` and any one row
budget imply `0 ≤ ε`. For an empty index type, every form and squared norm
is zero, so the conclusion holds even if ε is negative. This explains
why the theorem correctly omits an explicit `0 ≤ ε` hypothesis.

For a real matrix, the real part of the complex form is the sum of the
forms evaluated at the real and imaginary coordinate vectors. The proof
uses exactly that identity. It does **not** establish that the complex
form is real for arbitrary `A`. For example, the real matrix
`[[1,2],[-2,1]]` has nonnegative real quadratic parts, but its form at
`z=(1,i)` is `2+4i`. This identity is independently kernel checked in the
review pilot. Calling the input matrix Hermitian or claiming the full
complex quadratic value is nonnegative additionally requires symmetry.
The reported application correctly identifies the existing
`CvSRowTailV1.cvsEntry_symm`, whose premise is positive window length.

## Regression quality and strongest challenge

The shipped positive test reaches the exact singular boundary. It must
not be read as strict coercivity: an error bound equal to the centre
margin leaves zero reserve.

The shipped negative tests establish exact arithmetic facts, but do not
by themselves invoke an executable matrix checker or test rejection of a
malformed matrix certificate. This is appropriate for a theorem-only
transfer library; they are not evidence that Claude's packed checker was
reproduced. The independent review strengthens the row-only example by
formally defining the offending matrix and vector and checking both the
row hypotheses and the failure of the requested quadratic inequality.

Absolute residual majorization deliberately discards cancellation. It
can be too weak for ill-conditioned or growing matrices. No dimension-free
claim or stable positive margin follows unless its input row budgets and
centre bounds are constructed uniformly.

## Existing overlap and integration

`AEGIS.WeightedSchur.weighted_schur` already proves a more general weighted
symmetric-majorant sum estimate. The new unweighted scalar/sum argument
is therefore not a new mathematical mechanism. Nevertheless, the generic
entry-enclosure-to-arbitrary-centre transfer interface is useful: none of
the inspected existing weighted Gram consumers directly supplies this
same contract, and importing the narrow new module avoids the broader
actual Weil infrastructure. Existing
`RHCofinalSchurAdapterV1.actual_zero_quadratic_nonnegative_of_gram_bounds`
concerns actual packet Gram data, with a different negative-Weil sign and
explicit diagonal/cross hypotheses. It does not eliminate the new input
obligations.

The nearest inspected actual consumer,
`CvSRowTailV1.window_of_certificate_tail`, requires a lower bound for the
actual low-frequency form **after** the cross-row/tail Schur subtraction,
for every coefficient vector. Nonnegativity of the unshifted centre, or
of an unrelated Hilbert matrix, is insufficient. The exact LDLT module
can provide the centre input only with the required shift and index/cast
identities. The finite cross estimate, explicit tail, positive complement
gap, pointwise Krein certificate, and trace/slack premises remain separate.

## Reproduction and evidence

Pinned Lean: `leanprover/lean4:v4.33.1`. Actual Mathlib checkout:
`0df444a360eaa60ab8c11dca51a86af692955474`.
The review makes no repository edits and does not change branches or refs.

Replay artifacts in this directory:

* `independent-source-receipt.json` and `independent-source-kernel.log`:
  exact source compilation, full elaborated theorem types, all five axiom
  sets, source hash, commit, pin, and runtime.
* `independent-regression.log`: shipped regression replay (successful
  compilation has no output).
* `IndependentResidualReview.lean`, `independent-edgecases.log`, and
  `independent-edgecases-receipt.json`: the extra checks and their final
  native kernel receipt.

The original exploratory attempt at the extra review source referenced
an unavailable convenience API, then lacked one final ring normalization.
Both were repaired inside this review directory; only the final successful
receipt is evidence for the extra lemmas. No admitted declaration is used.
Broader remote workflow status is deliberately not inferred from these
local successful checks; exact-SHA CI must be reported separately.
