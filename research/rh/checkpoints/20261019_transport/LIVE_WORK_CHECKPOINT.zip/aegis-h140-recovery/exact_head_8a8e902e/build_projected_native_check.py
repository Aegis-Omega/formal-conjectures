from pathlib import Path
import re,hashlib,json
repo=Path('/workspace/formal-conjectures');p=repo/'research/rh/feshbach_lean_v1/CvSProjectedPackedCertificateL12V1.lean';s=p.read_text();chunks=[];manifest=[]
for name in ['certL','certI','certQ','certBase','certB','certEps','certEta']:
 m=re.search(r'^def '+name+r'\b',s,re.M);assert m;start=m.start();a=s.index(':=',start)+2
 if s[a:].lstrip().startswith('['):
  i=s.index('[',a);depth=1;j=i+1
  while depth:
   if s[j]=='[':depth+=1
   if s[j]==']':depth-=1
   j+=1
  chunk=s[start:j]
 else:chunk=s[start:s.index('\n',a)]
 chunks.append(chunk);manifest.append({'name':name,'source_block_sha256':hashlib.sha256(chunk.encode()).hexdigest()})
a=s.index('theorem packed_check_true');b=s.index('/--',a);proof=s[a:b].strip();chunks.append(proof)
text='''-- Exact source-extracted numeric declaration slice only.
-- No analytic source enclosure is claimed by this finite Boolean computation.
import CvSPackedGramV1
namespace AEGIS.CvSProjectedPackedCertificateL12V1
open AEGIS.CvSPackedGramV1 AEGIS.RHFixIntervalV1
set_option maxHeartbeats 0
set_option maxRecDepth 100000
'''+ '\n\n'.join(chunks)+ '\nend AEGIS.CvSProjectedPackedCertificateL12V1\n#print axioms AEGIS.CvSProjectedPackedCertificateL12V1.packed_check_true\n'
out=Path('/workspace/aegis-h140-recovery/recovered_4fabfb66/native_slice/ProjectedNumericCheck.lean');out.write_text(text)
(out.parent/'PROJECTED_SLICE_PROVENANCE.json').write_text(json.dumps({'original_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_head':'8a8e902e0baa48413ec24cb6c1e92b47fe391497','blocks':manifest,'slice_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'scope':'original exact numeric data and exact packed_check_true statement/proof; computational slice, not full analytic imports'},indent=2)+'\n')
