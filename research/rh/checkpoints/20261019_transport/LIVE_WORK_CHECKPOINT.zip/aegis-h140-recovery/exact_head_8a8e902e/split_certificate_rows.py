"""Source-only row factoring; preserves every numeric row byte and row order."""
from pathlib import Path
import re,json,hashlib
repo=Path('/workspace/formal-conjectures');source=repo/'research/rh/feshbach_lean_v1/CvSProjectedPackedCertificateL12V1.lean';s=source.read_text();records=[]
def split(s,name,typ):
 start=re.search(r'^def '+name+r'\b',s,re.M).start();a=s.index('[',s.index(':=',start));depth=1;j=a+1;rows=[];begin=None
 while depth:
  if s[j]=='[':
   if depth==1:begin=j
   depth+=1
  if s[j]==']':
   depth-=1
   if depth==1:rows.append(s[begin:j+1])
  j+=1
 assert len(rows)==139
 helpers='\n\n'.join(f'private def {name}Row{k} : List {typ} :=\n  '+row for k,row in enumerate(rows))
 body='def '+name+' : List (List '+typ+') :=\n  ['+', '.join(f'{name}Row{k}' for k in range(139))+']'
 records.append({'name':name,'rows':139,'row_bytes_sha256':[hashlib.sha256(r.encode()).hexdigest() for r in rows],'row_order':list(range(139))})
 return s[:start]+helpers+'\n\n'+body+s[j:]
for n,t in [('certR','ℤ'),('certL','ℤ'),('certI','Iv')]:s=split(s,n,t)
out=Path('/workspace/aegis-h140-recovery/exact_head_8a8e902e/CvSProjectedPackedCertificateL12V1.row_factored.lean');out.write_text(s)
(out.parent/'ROW_FACTORING_PROVENANCE.json').write_text(json.dumps({'original_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'invariant':'Each helper body is the identical original row byte string, with original row order preserved; numerical constants and theorem statements/proofs unchanged','tables':records},indent=2)+'\n')
# The independent computational checker uses only certL and certI, not certR.
old=Path('/workspace/aegis-h140-recovery/recovered_4fabfb66/native_slice/ProjectedNumericCheck.lean').read_text()
for n,t in [('certL','ℤ'),('certI','Iv')]:old=split(old,n,t)
old=old.replace('theorem packed_check_true', '#eval IO.FS.writeFile "/workspace/aegis-h140-recovery/recovered_4fabfb66/native_slice/ROW_FACTORING_PROGRESS.txt" "data declarations completed"\n\ntheorem packed_check_true')
Path('/workspace/aegis-h140-recovery/recovered_4fabfb66/native_slice/ProjectedNumericSplit.lean').write_text(old)
