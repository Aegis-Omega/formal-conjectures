"""Exact outward integer interval experiment. Not a Lean proof.
Uses actual source tau/diagonal bounds, collecting the shared tau variables
before applying absolute interval bounds. No floating-point arithmetic.
"""
import ast,json,re,time
from fractions import Fraction as F
from pathlib import Path
root=Path('/workspace/formal-conjectures/research/rh/feshbach_lean_v1')
out=Path('/workspace/aegis-h140-recovery/exact_head_8a8e902e')
def ev(n):
 if isinstance(n,ast.Constant) and type(n.value)==int:return F(n.value)
 if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -ev(n.operand)
 if isinstance(n,ast.BinOp):
  a,b=ev(n.left),ev(n.right)
  if isinstance(n.op,ast.Div):return a/b
  if isinstance(n.op,ast.Add):return a+b
  if isinstance(n.op,ast.Sub):return a-b
  if isinstance(n.op,ast.Mult):return a*b
 raise ValueError(ast.dump(n))
def table(module,name):
 s=(root/(module+'.lean')).read_text();m=re.search(r'def '+name+r' : List ℚ := \[(.*?)\]',s,re.S);assert m
 return [ev(n) for n in ast.parse('['+m[1]+']',mode='eval').body.elts]
t0=time.monotonic();p=96;S=2**p
floor=lambda x:x.numerator//x.denominator
ceil=lambda x:-floor(-x)
def rat(a,b=None):
 if b is None:b=a
 return (floor(a*S),ceil(b*S))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def neg(a):return (-a[1],-a[0])
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 q=(a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]);return (min(q)//S,-((-max(q))//S))
def divint(a,d):
 if d<0:return neg(divint(a,-d))
 return (a[0]//d,-((-a[1])//d))
piLo=F(314159265358979323846,10**20);piHi=F(314159265358979323847,10**20)
C=rat(F(3,5)/piHi**2,F(3,5)/piLo**2)
dl=table('CvSDiagL12V1','diagLo');dh=table('CvSDiagL12V1','diagHi')
tl=table('CvSTauPrimeL12V1','tauFLo');th=table('CvSTauPrimeL12V1','tauFHi')
D=[rat(l,h) for l,h in zip(dl,dh)];T=[(0,0)]+[rat(l,h) for l,h in zip(tl,th)]
z=json.loads((out/'PROJECTED_DATA.json').read_text());R=z['data']['certR'];I=z['data']['certI']
def r(n,i):return R[n+69][i] if -69<=n<=69 else 0
X=[]
for n in range(-70,71):
 factor=rat(-F(25,9)*piHi**2*n*n-F(1,4),-F(25,9)*piLo**2*n*n-F(1,4))
 X.append([mul(factor,rat(F(2*r(n,i)-r(n-1,i)-r(n+1,i),2**42))) for i in range(139)])
H=[]
for k in range(141):
 row=[]
 for i in range(139):
  a=(0,0)
  for l in range(141):
   if l!=k:a=add(a,divint(X[l][i],k-l))
  row.append(a)
 H.append(row)
failed=[];worst_width=(0,None);widest_ratio=F(0);mid_misses=[];allivs=[]
for i in range(139):
 row=[]
 for j in range(i,139):
  acc=(0,0)
  for k in range(141):
   n=k-70
   acc=add(acc,mul(mul(X[k][i],X[k][j]),D[abs(n)]))
   if n:
    tc=mul(C,add(mul(X[k][i],H[k][j]),mul(X[k][j],H[k][i])))
    acc=add(acc,mul(tc,T[n] if n>0 else neg(T[-n])))
  lo,hi=I[i][j];target=(lo*2**(p-64),hi*2**(p-64))
  good=target[0]<=acc[0] and acc[1]<=target[1]
  if not good:failed.append([i,j,str(acc[0]-target[0]),str(target[1]-acc[1])])
  if not target[0]*2<=acc[0]+acc[1]<=target[1]*2:mid_misses.append([i,j])
  width=acc[1]-acc[0]
  if width>worst_width[0]:worst_width=(width,[i,j])
  ratio=F(width,target[1]-target[0]);widest_ratio=max(widest_ratio,ratio)
  row.append([str(acc[0]),str(acc[1])])
 allivs.append(row)
result={'kind':'rigorous exact-integer interval experiment conditional on the stated source bounds; NOT Lean kernel replay','source_head':'8a8e902e0baa48413ec24cb6c1e92b47fe391497','arithmetic':'Q96 outward integer interval operations; tau oddness and diagonal evenness; tau variables collected before interval evaluation; signed frequencies NOT folded together','checked_upper_triangle_entries':139*140//2,'intervals_contained':139*140//2-len(failed),'interval_containment_failures':failed,'midpoints_outside_target_count':len(mid_misses),'midpoints_outside_target_first':mid_misses[:10],'widest_interval_scaled_q96':str(worst_width[0]),'widest_interval_at':worst_width[1],'max_width_to_cert_width_ratio':str(widest_ratio),'seconds':time.monotonic()-t0,'source_bound_status':'check exact-commit CI for tau/diagonal source theorems; no assumption of new positivity or RH','all_upper_triangle_intervals_q96':allivs}
(out/'PROJECTED_ANALYTIC_INTERVAL_NO_FOLD.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['interval_containment_failures','all_upper_triangle_intervals_q96']},indent=2))
