# Sprint B: fixed-window Feshbach tails versus universal positivity

Source checkout: `tarikskalic33/formal-conjectures`, existing branch
`proof/rh-feshbach-schur-v1`, exact commit
`251b6636b1764f5bf243f59807ffc5ebed8ed782` inspected without changing repository files.
Lean 4.33.1; Mathlib `0df444a360eaa60ab8c11dca51a86af692955474`.

## Discovery and native pilot

The actual source already proves the row tail bound simultaneously for **every** outer
Fourier truncation N (`CvSRowTailV1.rows_tail_le`, lines 472–476). A useful additional
uniformity follows directly from its explicit definition at order K=0:

    rowTail(M,L,F,a,0,T,R,NP)
      = 16 (L/pi)^2 T^2 (sum_{n in F} ||a_n||)^2 / (NP-R).

The constant is exactly 16: the source has `2*(2*T*S)^2*(2/gap)`.
The identity is algebraic; in Lean total-field division it remains an identity even
at NP=R, but use as an analytic bound requires R<NP.

Fix L,T,R and epsilon>0. Choose a natural NP satisfying

    NP > R + 16 (L/pi)^2 T^2 / epsilon + 1.

Then for every later cutoff N>=NP, every finite F and every coefficient vector a,

    rowTail(M,L,F,a,0,T,R,N) <= epsilon (sum_F ||a||)^2.

In particular a single cutoff controls every coefficient vector with l1 mass at most
one. The quantified constant is independent of F and a. For the actual row-square
bound, additionally require F subset [-R,R], L>0 and |tau(k)|<=T for every k; those
premises are precisely in `rows_tail_le` and are not erased here. This gives uniform
fixed-support tail control, **not** a bound independent of L, M, R or the desired error.
For a fixed finite frequency set, Cauchy–Schwarz further bounds squared l1 mass by
`card(F) * sum_F ||a||^2`; that final comparison is mathematical deduction here,
not a new compiled theorem in this sprint.

`FeshbachTailPilot.lean` verifies the algebraic schema with analytic tau and the norm
functional left as arbitrary parameters. Instantiating them by actual tau, complex
norm, and scale=L/pi gives exactly the existing rowTail formula. The pilot deliberately
imports only narrow Mathlib modules; it does not claim to have imported/compiled the
full actual CvS closure or integrated a new theorem into `CvSRowTailV1`.

All six pilot lemmas compile under `-DwarningAsError=true` and print only
`propext`, `Classical.choice`, `Quot.sound`:

* `sourceRowTail_zero`: exact K=0 reduction.
* `exists_uniform_shifted_cutoff`: one natural cutoff controls all later indices.
* `sourceRowTail_uniform_cutoff`: one cutoff for all finite supports and coefficient directions,
  relative to their squared l1 mass.
* `exists_uniform_energy_cutoff`: abstract homogeneous energy version.
* `uniform_tail_budget`: normalized scalar budget comparison.
* `positive_blocks_do_not_imply_global`: exact 2x2 Schur obstruction.

This is newly proved, scoped algebra, not recovery of Claude's missing source and not
an unconditional positivity theorem. Native command and source hashes appear in receipt.json.

## Exact actual consumer and universal target

`CvSRowTailV1.window_of_certificate_tail` (lines 581–618) consumes all the following:

1. M:natural, L,LT,m:real, `0<LT`, `LT<L`, `LT<log(M+1)`.
2. Measurable bounded nonnegative slack s, genuine pointwise Krein certificate hcert
   for **every real spectral variable t**, with finite continuous/integrable H,
   integrable Fourier transforms, and H vanishing on |u|<L; finite correction d,j.
3. Finite moment basis indexed by `iota:Fin p -> Int` and trace approximant cf;
   an actual integrable slack-times-trial-distance bound with integral <=Ttrace,
   and positive complement gap `c=m-Ttrace/(2*pi)>0`.
4. R,NP,K:natural, `|iota_i|+1<=R`, `R<NP`, selected row subtraction lam and Brow(c).
5. hfin for **every coefficient vector c**: actual finite row-square sum + explicit
   rowTail <= Brow(c). In this item the rowTail parameter `tauBound M` is distinct
   from the trace bound Ttrace in item 3.
6. hlow for **every coefficient vector c**:

       Brow(c)/(2*pi*LT)/(m-Ttrace/(2*pi))
         <= 2*pi * Re sum_ab lowCoeff(c,a) conj(lowCoeff(c,b)) cvsEntry(M,LT,a,b).

Conclusion: for every moment-zero smooth compact Weil packet g whose `HalfWidthAt g r a`
obeys `2*r<=LT`, its actual nontrivial-zero quadratic sum has nonnegative real part.

An explicit sufficient universal producer is:

    for every W>0, there exist all the certificate data above, satisfying every
    premise of window_of_certificate_tail, and LT>=W.

The data may depend on W. No parameter-independent positive lower bound is intrinsically
required: each window can have its own proved positive complement gap and Schur budget.
This producer is stronger than universal positivity as currently established, in the
sense that the existing theorem proves sufficiency; necessity/equivalence has not been
proved for this particular certificate representation. Do not label it equivalent to RH.
The user-requested all-window/cofinal bridge must then compose it with the existing Weil
criterion. No theorem in this source directory supplies that universal producer.

## Strongest existing parameterized results and what they actually remove

* `CvSFourierIntervalV1.tendsto_partialSum` gives L2 convergence on a fixed positive interval.
* `CvSCrossCertV1.cross_sq_le_of_rows` uses a bound for all N, plus admissible complement
  regularity/orthogonality, to bound the actual infinite cross integral.
* `CvSRowTailV1.rows_tail_le` and `window_of_certificate_tail` already remove outer Fourier
  truncation with explicit tails for a fixed analytic matrix and support.
* `CvSWindowCertV1.exists_orth_coeffs` constructs low-block/complement decomposition for
  every packet. There is no need to postulate a decomposition separately per packet.
* `CvSTraceV1.complement_bound` derives the actual complement estimate from genuine
  Krein/slack and trace inputs; it does not prove those inputs.

Thus the missing mathematics is not an unspecified passage from finite Fourier sums to
an infinite complement. The existing sources already formalize that passage **assuming**
the correct quantitative hypotheses. The main remaining obligations are construction of
Krein data, certified trace bounds with a positive gap, actual entry/cross enclosures,
and the low-block Schur inequality, for arbitrarily large widths.

## Parameter dependence and challenge tests

1. `tauBound M=4*pi*(1+pi/4)+pi*sum_{j<M}|ppw(j)|`, with
   `ppw(j)=2*Lambda(j+1)*exp(-log(j+1)/2)`. It is not a documented universal constant.
   The width condition demands `M+1>exp(LT)`. Replacing tauBound M by its value at a
   smaller fixed M as LT grows is invalid. No asymptotic estimate for that sum is
   asserted as a newly verified result here.
2. The K=0 tail coefficient has a factor `(LT/pi)^2*tauBound(M)^2` and the coefficient
   l1 mass. This source does not establish that increasing block dimension or width
   preserves a fixed row budget or a positive Schur margin. The map from basis c to
   lowCoeff includes the frequency-dependent multiplier `iw(L,k)^2-1/4`.
3. Fixed NP-R=1 does not force the displayed tail to zero. With scale=T=S=1,
   its exact value is 16 for every R. If scale grows, this budget grows quadratically.
   This disproves a proposed **uniform bound on this certificate expression**, not
   positivity of any actual CvS matrix.
4. Uniform absolute tail control over all a without normalization or an energy factor
   is impossible by homogeneity: scaling a by lambda scales the tail by |lambda|^2.
5. Making NP large removes only the truncation uncertainty. It does not remove the
   limiting finite-plus-tail cross cost and does not force hlow. The kernel pilot
   explicitly checks [[1,2],[2,1]]: both diagonal blocks are positive, truncation can
   be exact, yet the quadratic value at (1,-1) is -2. This is an obstruction to the
   invalid inference, not a counterexample to the actual RH problem.
6. H140 screenshots concern a Hilbert demonstration. No actual CvS matrix entries,
   normalized basis identities, source-derived enclosures or Feshbach data for H140
   have been recovered. A positive Hilbert matrix supplies none of hcert/hT/hfin/hlow.

## Recommendation

**Continue locally / Hold universal promotion.** The uniform K=0 cutoff is a clean,
non-circular parameterized pilot and a useful truncation tool. It is not decisive
progress on the missing universal Schur/Krein construction. Do not expand certificate
benchmarking or claim global positivity on its strength.

Smallest integration experiment: add the exact `rowTail_zero` identity and the homogeneous
uniform-cutoff theorem to the actual source, compile that source in its real import context,
and audit the resulting named roots. This is an elementary source-compatible lemma,
not a new architecture. Then select a single actual nontrivial window and attempt hfin
and hlow using the existing analytic matrix plus residual-transfer lemma. The decisive
next mathematical test is whether a proved symbolic lower margin can dominate the
actual Schur cross budget as LT and the low block grow. No such comparison has been
proved in this sprint.
