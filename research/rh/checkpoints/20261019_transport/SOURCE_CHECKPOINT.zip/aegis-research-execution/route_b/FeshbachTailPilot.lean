import Mathlib.Algebra.Order.Archimedean.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Data.Complex.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset

namespace AEGIS.FeshbachTailPilot

open scoped BigOperators

/-- Literal algebraic schema of CvSRowTailV1.rowTail, with the analytic tau and norm functional left arbitrary. -/
noncomputable def sourceRowTail (τ : ℕ → ℝ → ℤ → ℝ) (σ : ℂ → ℝ) (M : ℕ) (L scale : ℝ)
    (F : Finset ℤ) (a : ℤ → ℂ) (K : ℕ) (T : ℝ) (R NP : ℕ) : ℝ :=
  scale ^ 2 * (2 * K * ∑ j ∈ Finset.range K,
      (σ (∑ n ∈ F, a n * ((τ M L n * (n : ℝ) ^ j : ℝ) : ℂ)) +
        T * σ (∑ n ∈ F, a n * (((n : ℝ) ^ j : ℝ) : ℂ))) ^ 2 * (2 / (NP : ℝ) ^ (2 * j + 1)) +
    2 * (2 * T * R ^ K * ∑ n ∈ F, σ (a n)) ^ 2 * (2 / ((NP : ℝ) ^ (2 * K) * ((NP : ℝ) - R))))

/-- At order zero the source tail is a single inverse-gap budget. -/
theorem sourceRowTail_zero (τ : ℕ → ℝ → ℤ → ℝ) (σ : ℂ → ℝ) (M : ℕ) (L scale : ℝ)
    (F : Finset ℤ) (a : ℤ → ℂ) (T : ℝ) (R NP : ℕ) :
    sourceRowTail τ σ M L scale F a 0 T R NP =
      16 * scale ^ 2 * T ^ 2 * (∑ n ∈ F, σ (a n)) ^ 2 / ((NP : ℝ) - R) := by
  simp only [sourceRowTail, Nat.cast_zero, Finset.range_zero, Finset.sum_empty,
    mul_zero, pow_zero, mul_one, one_mul, zero_add]
  ring

/-- For every fixed residual coefficient, one natural cutoff controls all later cutoffs. -/
theorem exists_uniform_shifted_cutoff (C : ℝ) (hC : 0 ≤ C) (R : ℕ)
    (ε : ℝ) (hε : 0 < ε) :
    ∃ NP : ℕ, R < NP ∧ ∀ N : ℕ, NP ≤ N → C / ((N : ℝ) - R) < ε := by
  obtain ⟨NP, hNP⟩ := exists_nat_gt ((R : ℝ) + C / ε + 1)
  have hr : (R : ℝ) < NP := by
    have : 0 ≤ C / ε := div_nonneg hC hε.le
    linarith
  refine ⟨NP, by exact_mod_cast hr, ?_⟩
  intro N hN
  have hNN : (NP : ℝ) ≤ N := by exact_mod_cast hN
  have hden : 0 < (N : ℝ) - R := by linarith
  rw [div_lt_iff₀ hden]
  have hc : C / ε < (N : ℝ) - R := by linarith
  have := (div_lt_iff₀ hε).mp hc
  nlinarith

/-- An operator-norm coefficient budget makes the cutoff independent of vector size/direction. -/
theorem uniform_tail_budget (C ε x y : ℝ) (hC : 0 ≤ C)
    (hy : 0 < y) (hcut : C / y ≤ ε) (hxy : x ^ 2 ≤ 1) :
    C * x ^ 2 / y ≤ ε := by
  have h1 : C * x ^ 2 ≤ C := mul_le_of_le_one_right hC hxy
  exact (div_le_div_of_nonneg_right h1 hy.le).trans hcut

/-- The same cutoff works for every vector and every later truncation for a fixed energy budget. -/
theorem exists_uniform_energy_cutoff {V : Type*} (C : ℝ) (hC : 0 ≤ C)
    (E : V → ℝ) (hE : ∀ v, 0 ≤ E v) (R : ℕ) (ε : ℝ) (hε : 0 < ε) :
    ∃ NP : ℕ, R < NP ∧ ∀ N : ℕ, NP ≤ N → ∀ v : V,
      C * E v / ((N : ℝ) - R) ≤ ε * E v := by
  obtain ⟨NP, hNP, hbound⟩ := exists_uniform_shifted_cutoff C hC R ε hε
  refine ⟨NP, hNP, fun N hN v => ?_⟩
  calc C * E v / ((N : ℝ) - R) = (C / ((N : ℝ) - R)) * E v := by ring
       _ ≤ ε * E v := mul_le_mul_of_nonneg_right (hbound N hN).le (hE v)

/-- Order-zero CvS tail convergence is uniform in all finite-support coefficient vectors,
measured in their squared l1 energy; no positivity of the low block is assumed. -/
theorem sourceRowTail_uniform_cutoff (τ : ℕ → ℝ → ℤ → ℝ) (σ : ℂ → ℝ) (M : ℕ) (L scale T : ℝ)
    (R : ℕ) (ε : ℝ) (hε : 0 < ε) :
    ∃ NP : ℕ, R < NP ∧ ∀ N : ℕ, NP ≤ N → ∀ (F : Finset ℤ) (a : ℤ → ℂ),
      sourceRowTail τ σ M L scale F a 0 T R N ≤ ε * (∑ n ∈ F, σ (a n)) ^ 2 := by
  have hC : 0 ≤ 16 * scale ^ 2 * T ^ 2 := by positivity
  obtain ⟨NP, hNP, hbound⟩ := exists_uniform_shifted_cutoff
    (16 * scale ^ 2 * T ^ 2) hC R ε hε
  refine ⟨NP, hNP, fun N hN F a => ?_⟩
  rw [sourceRowTail_zero]
  calc 16 * scale ^ 2 * T ^ 2 * (∑ n ∈ F, σ (a n)) ^ 2 / ((N : ℝ) - R) =
        (16 * scale ^ 2 * T ^ 2 / ((N : ℝ) - R)) * (∑ n ∈ F, σ (a n)) ^ 2 := by ring
       _ ≤ ε * (∑ n ∈ F, σ (a n)) ^ 2 :=
         mul_le_mul_of_nonneg_right (hbound N hN).le (sq_nonneg _)

/-- Positive diagonal blocks and zero truncation error do not supply the missing Schur inequality. -/
theorem positive_blocks_do_not_imply_global :
    (0 : ℝ) < 1 ∧ (0 : ℝ) < 1 ∧
      (1 : ℝ) * 1 ^ 2 + 2 * 2 * 1 * (-1) + 1 * (-1) ^ 2 < 0 := by
  norm_num

#print axioms positive_blocks_do_not_imply_global
#print axioms sourceRowTail_zero
#print axioms sourceRowTail_uniform_cutoff
#print axioms exists_uniform_energy_cutoff
#print axioms exists_uniform_shifted_cutoff
#print axioms uniform_tail_budget
end AEGIS.FeshbachTailPilot
