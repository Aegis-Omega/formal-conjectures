# Sprint C: signed mixed-defect feasibility

The inspected source is PR #89 commit `da0103e7afa0bb0ade1441f87d01e1b9416ef9c4`.
The execution checkout is detached Feshbach commit `251b6636b1764f5bf243f59807ffc5ebed8ed782`.
No repository file, branch, or remote ref was changed by this sprint.
All 20 inspected source interfaces, source blob identities, source SHA-256 hashes,
and the available prior exact-head kernel-root receipts are in
`source_interfaces.json`. Full readable signatures are in `exact_interfaces.txt`.

## Decision

**Continue in parallel for targeted analytic research; hold universal closure.**
There is no recovered unconditional signed mixed-defect producer in the sources
inspected here. The existing universal signed target is exactly RH-equivalent.
Neither that equivalence nor the new pilot qualifies as an independent analytic
mechanism proving RH. Do not promote this route to universal closure on their basis.

The new result is a kernel-verified, dimension-parametric obstruction to an
overstrong absolute-row approach, together with a signed comparison example.
It directs effort away from certifying every arbitrary redundant decomposition
and toward selected decompositions or complete signed cancellation estimates.

## Exact universal obligation and genuine RH bridge

Write `P` for `WeilCompactSmoothGV1`, `M g` for `WeilMomentConditionsV1 g`,
`S gs = packetSum (fun _ => (1 : ℂ)) gs`, and retain the actual Weil form `B`.
The exact sharp target is

```text
∀ g : P, M g →
  ∃ n : ℕ, ∃ gs : Fin (n+1) → P,
    g = S gs ∧
    actualMixedDefect n gs ≤ -(∑ i, (B (gs i) (gs i)).re).
```

`RHOptimizedSchurGlobalJoinV1.rh_iff_one_actual_sharp_signed_budget`
proves this equivalent to the canonical `RiemannHypothesis`. Its reverse
direction uses `RHRestrictedWeilBridgeV13.final_sign_implies_rh_v13`.
The source identity `actual_signed_defect_iff_packet_nonpositive` shows,
for each finite decomposition, that its signed inequality is exactly
`(B (S gs) (S gs)).re ≤ 0`. Thus if two reconstructions have the same source,
their paid sharp signed budgets have the same truth value. Repartitioning can
make estimates easier to prove; it cannot change the true source sign.

The sign convention is essential: arithmetic `Re B(g,g) ≤ 0` corresponds to
nonnegative zero-side quadratic, not to arithmetic `Re B(g,g) ≥ 0`.

The alternative `riemannHypothesis_of_optimized_actual_row_producer` has an
explicit `hselect`. For **every** moment-zero source and every supplied exact
fine decomposition with width and diagonal certificates, it must return
**one possibly different** exact reconstruction `selected`, with diagonals
`(5671/3200) E(selected_i) ≤ -Re B(selected_i,selected_i)` and witnesses `c,w`
satisfying nonnegativity, zero diagonal, symmetry, strictly positive weights,
actual complex cross bounds

```text
‖B(selected_i,selected_j)‖ ≤ c_ij sqrt(E_i) sqrt(E_j),  i ≠ j,
∑j c_ij w_j/w_i ≤ 46688/65536.
```

The full literal `hselect` type is preserved in `exact_interfaces.txt`.
The source proves sufficiency; this sprint does not claim a converse or that
`hselect` is strictly stronger than RH. It is not supplied premise-free.

## Existing cancellation and actual analytic content

* `RHScaleRowCompositionV1.actual_mixed_defect_eq_block_signed_split` is an
  exact signed intra/inter-block identity for every finite family and every
  map `block : Fin(n+1) → ℕ`. The inter-block contribution remains present.
* `actual_nine_macro_coercive_of_total_signed_defect` uses genuine local
  `9/64` macro-packet coercivity and only a summed signed cross budget.
  Its `htotal` assumption is explicitly
  `defect ≤ (1/10-gap)∑E`; it is not proved for arbitrary macro families.
* `RHPrimeFreeRecompositionJoinV1.every_packet_actual_fine_multiscale_receipt`
  supplies exact reconstruction for every moment-zero packet, the signed split,
  a **conditional common-center** local cluster bound, and genuine norm bounds
  on pairs separated in the two proved prime-log-free intervals.
* The prime-log-free bound is `676/65536*(E_i+E_j)` per admitted pair. Pairs near
  prime-log resonances and all other excluded gaps have no invented estimate.
  The same file proves exactly that **85** flat charges exceed `57430/65536`.
  This is an obstruction to that flat per-link accounting, not a lower bound
  on actual Weil interactions and not an RH counterexample.
* `actual_signed_two_block_schur_certificate` accepts `c²≤ab` with nonnegative
  reserves, including a singular Schur complement. Its signed cross-budget
  hypothesis is still explicit. The determinant inequality is not established
  for arbitrary actual cross blocks.
* `RHHexagram64MellinWeilFusionV1` preserves arbitrary source reconstruction,
  all Mellin terms, the true Gram, and multiplicity-weighted zero terms.
  Its `hexagram64_mellin_seed_zero_persists` explicitly prevents removing a
  common seed zero by translating/reweighting that seed. These are identities,
  not a universal signed estimate.
* `RHSnowflakeActualMellinFrameV1` gives an actual fixed pair with positive
  lower bound on each compact strip subset and cubic vertical decay. Its
  pointwise Bezout coefficients have no established regularity or test-space
  stability. Compact frame constants are not a uniform lower bound on the
  unbounded strip: the stated cubic upper decay already forces the two norms
  to approach zero at large height. No global Weil sign follows from these facts.

Some of these named roots have prior exact-PR89 kernel receipts in the supplied
107-root evidence package; others were inspected at source level here. The
machine manifest distinguishes each case. No old receipt is presented as a
fresh replay of the current Feshbach checkout.

## Strongest established parameterized positive family and its limitation

`RHFourLogThreeActualPrimeV1.actual_four_log_three_weighted_norm_coercive_sharp`
is a genuine all-finite-dimensions theorem, with arbitrary complex amplitudes,
true Weil entries, and exact margin `20829/16384`. The source builds the prime
row `1/4` and Arch row `29/65536`; sum-energy pair accounting contributes a
factor two. Its scoped prior kernel audit passed with standard axioms.

Its family consists of translates of **one mother**, with gaps
`4*Nat.dist(i,j)*log 3`, and mother support radius
`min(1/256,1/(4*3^K))`, with `4*Nat.dist(i,j)≤K`.
Consequently `K` must grow with the maximal finite index and the allowed
mother support shrinks. A dimension-independent row constant is not a proof
of positivity on every packet. A single fixed nonzero continuous mother cannot
have support inside arbitrarily shrinking intervals of radius tending to zero:
its support would have at most one point, forcing the function to vanish.

`RHFourLogThreeWeightedRHBridgeV1` explicitly assumes an exact weighted sparse
reconstruction for every arbitrary input. Generic fine partition existence
does not supply this same-mother, sparse-gap reconstruction. Neither a
density theorem with continuity of the full Weil quadratic nor uniform control
of its reconstruction residual is established by the inspected joins.

## New parameterized Lean pilot and countertests

`SignedCliqueObstruction.lean` contains three new kernel-checked lemmas over
every linearly ordered field, with all typeclass assumptions explicit:

1. `clique_floor_le_weighted_ceiling`: on `Fin(n+1)`, if every off-diagonal
   cost is at least `d≥0` and all weights are positive, a common weighted
   off-diagonal row ceiling `S` forces **`n*d≤S`**. Symmetry is not needed.
   The proof chooses a minimum-weight index, whose every outgoing weight ratio
   is at least one, then sums its `n` lower bounds.
2. `q16_clique_admission`: if those floors are `q/65536`, admission to the
   optimized `46688/65536` rows forces **`n*q≤46688`**, exactly.
3. `signed_rank_one_nonpositive`: for all finite index types, `a≥0`, and real
   amplitudes `z`, the rank-one signed Gram satisfies
   `∑i∑j -a*z_i*z_j = -a*(∑i z_i)^2 ≤ 0`.

Together these expose the concrete distinction: a negative rank-one Gram can
have the desired full signed sign in every dimension while absolute off-diagonal
Schur costs grow linearly. On genuine repeated nonzero Weil atoms with positive
energy, `‖B(u,u)‖≥-Re B(u,u)` and the source diagonal reserve force a normalized
absolute cost at least the conservative `116142/65536`; already one repeated
partner exceeds the optimized row ceiling. This last application is a
mathematical deduction from the inspected hypotheses, not a new compiled
actual-Weil bridge in the narrow pilot.

The clique theorem also applies to near-atom configurations **if** one proves
the stated common cost lower floor. No continuity theorem or quantitative
near-atom floor is silently assumed. The degenerate `n=0`, `d=0`, and zero
amplitude cases are included by the theorem statements.

**Scope of rejection:** this disproves the proposed demand that **every**
arbitrary redundant decomposition satisfy the fixed absolute row ceiling.
It does not disprove existential `hselect`, the actual sharp signed budget,
or RH. It does not turn a scalar/matrix pilot into an analytic Weil estimate.

Fresh command:

```text
lake env lean -DwarningAsError=true /workspace/aegis-research-execution/route_c/SignedCliqueObstruction.lean
```

Result: exit 0; all three `#print axioms` outputs contain only `propext`,
`Classical.choice`, and `Quot.sound`. All full `@#check` outputs are in
`pilot.log`. The measured fresh execution was about 1.52 seconds.
`ROUTE_C_RECEIPT.json` binds its exact source SHA-256 and environment.

## First missing analytic estimate and smallest decisive experiment

The exact remaining universal target is the sharp source budget above; stating
it again is not a discovery. A more informative next experiment is to test an
**explicit selected smooth partition into local macro-packets**, with all actual
intra-block interactions paid by proved local coercivity, and measure its
complete **signed** inter-macro residual. Any proposed cancellation rule must
keep prime-log resonances, unequal packet shapes, unequal energies, and overlap.
The necessary family estimate is the actual inter-macro signed contribution
bounded by the sum of the proved macro reserves, uniformly in support radius
and refinement. The existing exact block split gives the consumer, not the bound.

One exact sufficient producer interface for that experiment, using the existing
`9/64` macro consumer without adding another equivalence, is

```text
∀ g : P, M g →
  ∃ n : ℕ, ∃ gs : Fin(n+1) → P, ∃ center : Fin(n+1) → ℝ,
    g = S gs ∧ (∀ i, M (gs i)) ∧
    (∀ i, HalfWidthAt (gs i) (9/64) (center i)) ∧
    actualMixedDefect n gs ≤ (1/10)*(∑ i, energy (gs i).1).
```

This is a sufficient analytic construction request, not a newly proved fact;
no converse or strict comparison with RH is claimed. A selector must be fixed
or constructed before treating it as a testable proposed mechanism.

For a uniform prototype, first fix the partition rule and prove a quantitative
bound on its resonant mixed contribution as a function of refinement and
support radius, including signs; then check whether it remains below those
reserves. A bound proportional to the number of pairs, or one requiring a
fixed same mother at every refinement, fails this experiment's purpose.
An arbitrary positive-semidefinite demo such as a Hilbert H140 matrix supplies
neither the actual Weil entries nor this uniform analytic estimate.

No independent cancellation mechanism supplying this estimate was found in
the inspected source joins. Gate 2 should remain closed for a primary universal
proof claim until such a mechanism or a different credible analytic argument
is exhibited. The proven generic pilot is preserved as useful negative evidence.

## Comparative scores (0 to 5, evidence-limited)

| Criterion | Score | Reason |
|---|---:|---|
| Explicit universal target and bridge | 5 | Exact source target and canonical RH bridge |
| Progress proving that target | 1 | Strong restricted families; no universal signed producer |
| Independent analytic cancellation evidence | 1 | Signed identities preserve potential cancellation but do not bound it |
| Generality of proved structural algebra | 5 | Every finite dimension; arbitrary regrouping |
| Formalization feasibility | 4 | Existing consumers and narrow pilot compile; missing mathematics remains |
| Counterexample resistance | 2 | Arbitrary-decomposition absolute rows fail; existential signed route survives |
| Reduction of infinite obligations | 1 | Obligation localized exactly, not eliminated |
| Non-circularity of established results | 5 | Source hypotheses explicit; no RH assumption in positive restricted results |
| Stability of constants and domains | 2 | Sparse row stable, support shrinks; flat free-link rows accumulate |

Discovery: a uniform clique obstruction and signed rank-one contrast.
Evidence: fresh narrow native Lean replay, source-bound existing theorem types.
Challenge: the pilot is generic and does not supply the missing actual analytic bound.
Status: pilot kernel verified; universal closure obstructed by an unproved estimate.
Dependencies: pinned Mathlib algebra/finite sums; prior PR89 actual-Weil interfaces.
Next experiment: the selected-partition resonant signed residual estimate above.
