-- Parameterized algebra pilot only. Not an import replay of the analytic modules.
-- The arbitrary real kernel and real basis matrix are universally quantified.
import CvSFiniteCongruenceV1
open scoped BigOperators ComplexConjugate
open Finset
namespace TransportPilot
noncomputable section
set_option maxRecDepth 4000
set_option maxHeartbeats 800000
variable (πValue : ℝ) (matrix : ℕ → ℝ → ℤ → ℤ → ℝ) (basis : Fin 139 → Fin 139 → ℝ)
def signedFreq (i : Fin 141) : ℤ := (i.val : ℤ) - 70
def atomCenter (i : Fin 139) : ℤ := (i.val : ℤ) - 69
def sinSqSupport (n : ℤ) : Finset ℤ := {n - 1, n, n + 1}
def lowFreq {p : ℕ} (S : Fin p → Finset ℤ) : Finset ℤ := Finset.univ.biUnion S
def sinSqWeight (n : ℤ) (k : ℤ) : ℂ :=
  if k = n then 1 / 2 else if k = n - 1 ∨ k = n + 1 then -1 / 4 else 0
noncomputable def iw (L : ℝ) (k : ℤ) : ℂ := 2 * πValue * Complex.I * k / L
local notation "iw" => iw πValue
noncomputable def atomWeight (i : Fin 139) (k : Fin 141) : ℝ :=
  (if signedFreq k = atomCenter i then (1 / 2 : ℝ)
   else if signedFreq k = atomCenter i - 1 ∨ signedFreq k = atomCenter i + 1
        then (-1 / 4 : ℝ) else 0) *
  (-(2 * πValue * (signedFreq k : ℝ) / (6 / 5 : ℝ)) ^ 2 - 1 / 4)
local notation "atomWeight" => atomWeight πValue
local notation "rCoeff" => basis
noncomputable def transformedCoeff (k : Fin 141) (i : Fin 139) : ℝ :=
  ∑ j : Fin 139, atomWeight j k * rCoeff j i
local notation "transformedCoeff" => transformedCoeff πValue basis
noncomputable def signedEntry (M : ℕ) (i j : Fin 141) : ℝ :=
  matrix M (6 / 5) (signedFreq i) (signedFreq j)
local notation "signedEntry" => signedEntry matrix
noncomputable def projectedEntry (M : ℕ) (i j : Fin 139) : ℝ :=
  ∑ k : Fin 141, ∑ l : Fin 141,
    transformedCoeff k i * transformedCoeff l j * signedEntry M k l
local notation "projectedEntry" => projectedEntry πValue matrix basis
noncomputable def R_basis (v : Fin 139 → ℂ) : Fin 139 → ℂ :=
  fun i => ∑ j : Fin 139, (rCoeff i j : ℂ) * v j
local notation "R_basis" => R_basis basis
noncomputable def projectedQ (M : ℕ) (v : Fin 139 → ℂ) : ℝ :=
  (∑ i : Fin 139, ∑ j : Fin 139,
    v i * (starRingEnd ℂ) (v j) * (projectedEntry M i j : ℂ)).re
local notation "projectedQ" => projectedQ πValue matrix basis
noncomputable def lowCoeff {p : ℕ} (L : ℝ) (S : Fin p → Finset ℤ) (β : Fin p → ℤ → ℂ)
    (c : Fin p → ℂ) (k : ℤ) : ℂ :=
  ∑ i, c i * (if k ∈ S i then β i k * (iw L k * iw L k - 1 / 4) else 0)
local notation "lowCoeff" => lowCoeff πValue
noncomputable def A_CvS (M : ℕ) (LT : ℝ) (n k : ℤ) : ℝ := matrix M LT n k
local notation "A_CvS" => A_CvS matrix
noncomputable def Q_CvS {p : ℕ} (M : ℕ) (LT : ℝ)
    (centers : Fin p → ℤ) (c : Fin p → ℂ) : ℝ :=
  (∑ a ∈ lowFreq (fun i => sinSqSupport (centers i)),
    ∑ b ∈ lowFreq (fun i => sinSqSupport (centers i)),
      lowCoeff LT (fun i => sinSqSupport (centers i))
        (fun i => sinSqWeight (centers i)) c a *
      conj (lowCoeff LT (fun i => sinSqSupport (centers i))
        (fun i => sinSqWeight (centers i)) c b) *
      (A_CvS M LT a b : ℂ)).re
local notation "Q_CvS" => Q_CvS πValue matrix
open AEGIS.CvSFiniteCongruenceV1
theorem signedFreq_injective : Function.Injective signedFreq := by
  intro i j h
  apply Fin.ext
  simp only [signedFreq] at h
  omega

/-- The actual three-point atom supports cover exactly the signed interval. -/
theorem lowFreq_mem_iff (k : ℤ) :
    k ∈ lowFreq (fun i : Fin 139 => sinSqSupport (atomCenter i)) ↔
      -70 ≤ k ∧ k ≤ 70 := by
  constructor
  · intro hk
    simp only [lowFreq, Finset.mem_biUnion, Finset.mem_univ, true_and] at hk
    obtain ⟨i, hi⟩ := hk
    have h := i.isLt
    simp only [sinSqSupport, Finset.mem_insert, Finset.mem_singleton, atomCenter] at hi
    omega
  · rintro ⟨hlo, hhi⟩
    simp only [lowFreq, Finset.mem_biUnion, Finset.mem_univ, true_and]
    by_cases h : k = -70
    · refine ⟨⟨0, by omega⟩, ?_⟩
      simp [sinSqSupport, atomCenter, h]
    by_cases h' : k = 70
    · refine ⟨⟨138, by omega⟩, ?_⟩
      simp [sinSqSupport, atomCenter, h']
    · have hnonneg : 0 ≤ k + 69 := by omega
      refine ⟨⟨(k + 69).toNat, by omega⟩, ?_⟩
      simp only [sinSqSupport, Finset.mem_insert, Finset.mem_singleton, atomCenter]
      exact Or.inr (Or.inl (by omega))

/-- Sum over signed indices by the exact support bijection. -/
theorem sum_signedFreq {V : Type*} [AddCommMonoid V] (f : ℤ → V) :
    (∑ k : Fin 141, f (signedFreq k)) =
      ∑ k ∈ lowFreq (fun i : Fin 139 => sinSqSupport (atomCenter i)), f k := by
  apply Finset.sum_bij (fun k _ => signedFreq k)
  · intro k _
    rw [lowFreq_mem_iff]
    have h := k.isLt
    simp only [signedFreq]
    omega
  · intro i _ j _ h
    exact signedFreq_injective h
  · intro k hk
    rw [lowFreq_mem_iff] at hk
    refine ⟨⟨(k + 70).toNat, by omega⟩, Finset.mem_univ _, ?_⟩
    simp only [signedFreq]
    omega
  · intro k _
    rfl

/-- The real frequency factor is exactly the source ODE factor. -/
theorem frequency_factor (k : Fin 141) :
    ((-(2 * πValue * (signedFreq k : ℝ) / (6 / 5 : ℝ)) ^ 2 - 1 / 4 : ℝ) : ℂ) =
      iw (6 / 5) (signedFreq k) * iw (6 / 5) (signedFreq k) - 1 / 4 := by
  simp only [TransportPilot.iw]
  push_cast
  ring_nf
  simp [Complex.I_sq]
  ring

/-- A stored real atom weight equals its guarded source Fourier coefficient. -/
theorem atomWeight_eq (i : Fin 139) (k : Fin 141) :
    (atomWeight i k : ℂ) =
      if signedFreq k ∈ sinSqSupport (atomCenter i) then
        sinSqWeight (atomCenter i) (signedFreq k) *
          (iw (6 / 5) (signedFreq k) * iw (6 / 5) (signedFreq k) - 1 / 4)
      else 0 := by
  rw [TransportPilot.atomWeight, Complex.ofReal_mul, frequency_factor]
  by_cases hc : signedFreq k = atomCenter i
  · simp [sinSqSupport, sinSqWeight, hc]
  by_cases hs : signedFreq k = atomCenter i - 1 ∨ signedFreq k = atomCenter i + 1
  · have hm : signedFreq k ∈ sinSqSupport (atomCenter i) := by
      simpa only [sinSqSupport, Finset.mem_insert, Finset.mem_singleton] using
        hs.elim (fun h => Or.inl h) (fun h => Or.inr (Or.inr h))
    simp [hc, hs, hm, sinSqWeight]
  · have hm : signedFreq k ∉ sinSqSupport (atomCenter i) := by
      simp only [sinSqSupport, Finset.mem_insert, Finset.mem_singleton]
      tauto
    simp [hc, hs, hm]

/-- The transformed coefficients represent the source low-block coefficients. -/
theorem transformed_coeff_eq_lowCoeff (v : Fin 139 → ℂ) (k : Fin 141) :
    (∑ i : Fin 139, (transformedCoeff k i : ℂ) * v i) =
      lowCoeff (6 / 5) (fun i => sinSqSupport (atomCenter i))
        (fun i => sinSqWeight (atomCenter i)) (R_basis v) (signedFreq k) := by
  simp only [TransportPilot.transformedCoeff, Complex.ofReal_sum, Complex.ofReal_mul]
  rw [AEGIS.CvSFiniteCongruenceV1.transformed_coeff_linear
    (fun k j => (atomWeight j k : ℂ)) (fun j i => (rCoeff j i : ℂ)) v k]
  unfold TransportPilot.lowCoeff
  apply Finset.sum_congr rfl
  intro i _
  rw [atomWeight_eq]
  simp only [TransportPilot.R_basis]
  ring

/-- Congruence before replacing the signed finite frequency index. -/
theorem projectedQ_eq_signed_form (M : ℕ) (v : Fin 139 → ℂ) :
    projectedQ M v =
      (∑ k : Fin 141, ∑ l : Fin 141,
        lowCoeff (6 / 5) (fun i => sinSqSupport (atomCenter i))
          (fun i => sinSqWeight (atomCenter i)) (R_basis v) (signedFreq k) *
        conj (lowCoeff (6 / 5) (fun i => sinSqSupport (atomCenter i))
          (fun i => sinSqWeight (atomCenter i)) (R_basis v) (signedFreq l)) *
        (signedEntry M k l : ℂ)).re := by
  unfold TransportPilot.projectedQ TransportPilot.projectedEntry
  rw [quadratic_form_real_congruence (signedEntry M) transformedCoeff v]
  simp_rw [transformed_coeff_eq_lowCoeff]

/-- The exact, premise-free transport required by the existing Schur bridge. -/
theorem hTransport (M : ℕ) (v : Fin 139 → ℂ) :
    projectedQ M v = Q_CvS M (6 / 5) atomCenter (R_basis v) := by
  rw [projectedQ_eq_signed_form]
  unfold TransportPilot.Q_CvS
  simp only [TransportPilot.signedEntry]
  let f : ℤ → ℤ → ℂ := fun k l =>
    lowCoeff (6 / 5) (fun i => sinSqSupport (atomCenter i))
      (fun i => sinSqWeight (atomCenter i)) (R_basis v) k *
    conj (lowCoeff (6 / 5) (fun i => sinSqSupport (atomCenter i))
      (fun i => sinSqWeight (atomCenter i)) (R_basis v) l) * (A_CvS M (6 / 5) k l : ℂ)
  change (∑ k : Fin 141, ∑ l : Fin 141, f (signedFreq k) (signedFreq l)).re =
    (∑ k ∈ lowFreq (fun i : Fin 139 => sinSqSupport (atomCenter i)),
      ∑ l ∈ lowFreq (fun i : Fin 139 => sinSqSupport (atomCenter i)), f k l).re
  apply congrArg Complex.re
  calc
    _ = ∑ k ∈ lowFreq (fun i : Fin 139 => sinSqSupport (atomCenter i)),
        ∑ l : Fin 141, f k (signedFreq l) :=
      sum_signedFreq (fun k => ∑ l : Fin 141, f k (signedFreq l))
    _ = _ := Finset.sum_congr rfl fun k _ => sum_signedFreq (f k)


end
end TransportPilot
#check @TransportPilot.hTransport
#print axioms TransportPilot.hTransport
