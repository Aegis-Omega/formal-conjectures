from pathlib import Path
repo=Path('/workspace/formal-conjectures/research/rh/feshbach_lean_v1')
s=(repo/'CvSProjectedTransportL12V1.lean').read_text()
body=s[s.index('theorem signedFreq_injective'):s.index('/-- The existing coercivity consumer')]
body=body.replace('Real.pi','πValue')
for name in ['iw','atomWeight','transformedCoeff','R_basis','signedEntry']:
 body=body.replace('['+name+']','[TransportPilot.'+name+']')
 body=body.replace('['+name+',','[TransportPilot.'+name+',')
for name in ['lowCoeff','projectedQ','projectedEntry','Q_CvS','A_CvS']:
 body=body.replace('unfold '+name,'unfold TransportPilot.'+name)
body=body.replace(' TransportPilot.projectedQ projectedEntry',' TransportPilot.projectedQ TransportPilot.projectedEntry')
body=body.replace(' TransportPilot.Q_CvS A_CvS',' TransportPilot.Q_CvS TransportPilot.A_CvS')
header='''-- Parameterized algebra pilot only. Not an import replay of the analytic modules.
-- The arbitrary real kernel and real basis matrix are universally quantified.
import CvSFiniteCongruenceV1
open scoped BigOperators ComplexConjugate
open Finset
namespace TransportPilot
noncomputable section
set_option maxRecDepth 4000
set_option maxHeartbeats 800000
variable (πValue : ℝ) (matrix : ℕ → ℝ → ℤ → ℤ → ℝ) (basis : Fin 139 → Fin 139 → ℝ)
def signedFreq (i : Fin 141) : ℤ := (i.val : ℤ) - 70
def atomCenter (i : Fin 139) : ℤ := (i.val : ℤ) - 69
def sinSqSupport (n : ℤ) : Finset ℤ := {n - 1, n, n + 1}
def lowFreq {p : ℕ} (S : Fin p → Finset ℤ) : Finset ℤ := Finset.univ.biUnion S
def sinSqWeight (n : ℤ) (k : ℤ) : ℂ :=
  if k = n then 1 / 2 else if k = n - 1 ∨ k = n + 1 then -1 / 4 else 0
noncomputable def iw (L : ℝ) (k : ℤ) : ℂ := 2 * πValue * Complex.I * k / L
local notation "iw" => iw πValue
noncomputable def atomWeight (i : Fin 139) (k : Fin 141) : ℝ :=
  (if signedFreq k = atomCenter i then (1 / 2 : ℝ)
   else if signedFreq k = atomCenter i - 1 ∨ signedFreq k = atomCenter i + 1
        then (-1 / 4 : ℝ) else 0) *
  (-(2 * πValue * (signedFreq k : ℝ) / (6 / 5 : ℝ)) ^ 2 - 1 / 4)
local notation "atomWeight" => atomWeight πValue
local notation "rCoeff" => basis
noncomputable def transformedCoeff (k : Fin 141) (i : Fin 139) : ℝ :=
  ∑ j : Fin 139, atomWeight j k * rCoeff j i
local notation "transformedCoeff" => transformedCoeff πValue basis
noncomputable def signedEntry (M : ℕ) (i j : Fin 141) : ℝ :=
  matrix M (6 / 5) (signedFreq i) (signedFreq j)
local notation "signedEntry" => signedEntry matrix
noncomputable def projectedEntry (M : ℕ) (i j : Fin 139) : ℝ :=
  ∑ k : Fin 141, ∑ l : Fin 141,
    transformedCoeff k i * transformedCoeff l j * signedEntry M k l
local notation "projectedEntry" => projectedEntry πValue matrix basis
noncomputable def R_basis (v : Fin 139 → ℂ) : Fin 139 → ℂ :=
  fun i => ∑ j : Fin 139, (rCoeff i j : ℂ) * v j
local notation "R_basis" => R_basis basis
noncomputable def projectedQ (M : ℕ) (v : Fin 139 → ℂ) : ℝ :=
  (∑ i : Fin 139, ∑ j : Fin 139,
    v i * (starRingEnd ℂ) (v j) * (projectedEntry M i j : ℂ)).re
local notation "projectedQ" => projectedQ πValue matrix basis
noncomputable def lowCoeff {p : ℕ} (L : ℝ) (S : Fin p → Finset ℤ) (β : Fin p → ℤ → ℂ)
    (c : Fin p → ℂ) (k : ℤ) : ℂ :=
  ∑ i, c i * (if k ∈ S i then β i k * (iw L k * iw L k - 1 / 4) else 0)
local notation "lowCoeff" => lowCoeff πValue
noncomputable def A_CvS (M : ℕ) (LT : ℝ) (n k : ℤ) : ℝ := matrix M LT n k
local notation "A_CvS" => A_CvS matrix
noncomputable def Q_CvS {p : ℕ} (M : ℕ) (LT : ℝ)
    (centers : Fin p → ℤ) (c : Fin p → ℂ) : ℝ :=
  (∑ a ∈ lowFreq (fun i => sinSqSupport (centers i)),
    ∑ b ∈ lowFreq (fun i => sinSqSupport (centers i)),
      lowCoeff LT (fun i => sinSqSupport (centers i))
        (fun i => sinSqWeight (centers i)) c a *
      conj (lowCoeff LT (fun i => sinSqSupport (centers i))
        (fun i => sinSqWeight (centers i)) c b) *
      (A_CvS M LT a b : ℂ)).re
local notation "Q_CvS" => Q_CvS πValue matrix
open AEGIS.CvSFiniteCongruenceV1
'''
footer='\nend\nend TransportPilot\n#check @TransportPilot.hTransport\n#print axioms TransportPilot.hTransport\n'
Path('/workspace/aegis-research-execution/integration/TransportParameterizedPilot.lean').write_text(header+body+footer)
