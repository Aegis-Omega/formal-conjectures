import Mathlib.Data.Complex.BigOperators
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Algebra.BigOperators.Ring.Finset
set_option maxRecDepth 4000
set_option maxHeartbeats 800000
open scoped BigOperators ComplexConjugate
open Finset
namespace AEGIS.CvSMomentBasisV1
def sinSqSupport (n : ℤ) : Finset ℤ := {n - 1, n, n + 1}
end AEGIS.CvSMomentBasisV1
namespace AEGIS.CvSLowBlockMatrixV1
def lowFreq {p : ℕ} (S : Fin p → Finset ℤ) : Finset ℤ := Finset.univ.biUnion S
end AEGIS.CvSLowBlockMatrixV1
namespace AEGIS.CvSProjectedPackedCertificateL12V1
def signedFreq (i : Fin 141) : ℤ := (i.val : ℤ) - 70
def atomCenter (i : Fin 139) : ℤ := (i.val : ℤ) - 69
end AEGIS.CvSProjectedPackedCertificateL12V1
namespace AEGIS.CvSProjectedTransportL12V1
open AEGIS.CvSMomentBasisV1 AEGIS.CvSLowBlockMatrixV1
open AEGIS.CvSProjectedPackedCertificateL12V1

theorem signedFreq_injective : Function.Injective signedFreq := by
  intro i j h
  apply Fin.ext
  simp only [signedFreq] at h
  omega

theorem lowFreq_mem_iff (k : ℤ) :
    k ∈ lowFreq (fun i : Fin 139 => sinSqSupport (atomCenter i)) ↔
      -70 ≤ k ∧ k ≤ 70 := by
  constructor
  · intro hk
    simp only [lowFreq, Finset.mem_biUnion, Finset.mem_univ, true_and] at hk
    obtain ⟨i, hi⟩ := hk
    have h := i.isLt
    simp only [sinSqSupport, Finset.mem_insert, Finset.mem_singleton, atomCenter] at hi
    omega
  · rintro ⟨hlo, hhi⟩
    simp only [lowFreq, Finset.mem_biUnion, Finset.mem_univ, true_and]
    by_cases h : k = -70
    · refine ⟨⟨0, by omega⟩, ?_⟩
      simp [sinSqSupport, atomCenter, h]
    by_cases h' : k = 70
    · refine ⟨⟨138, by omega⟩, ?_⟩
      simp [sinSqSupport, atomCenter, h']
    · have hnonneg : 0 ≤ k + 69 := by omega
      refine ⟨⟨(k + 69).toNat, by omega⟩, ?_⟩
      simp only [sinSqSupport, Finset.mem_insert, Finset.mem_singleton, atomCenter]
      exact Or.inr (Or.inl (by omega))

theorem sum_signedFreq {V : Type*} [AddCommMonoid V] (f : ℤ → V) :
    (∑ k : Fin 141, f (signedFreq k)) =
      ∑ k ∈ lowFreq (fun i : Fin 139 => sinSqSupport (atomCenter i)), f k := by
  apply Finset.sum_bij (fun k _ => signedFreq k)
  · intro k _
    rw [lowFreq_mem_iff]
    have h := k.isLt
    simp only [signedFreq]
    omega
  · intro i _ j _ h
    exact signedFreq_injective h
  · intro k hk
    rw [lowFreq_mem_iff] at hk
    refine ⟨⟨(k + 70).toNat, by omega⟩, Finset.mem_univ _, ?_⟩
    simp only [signedFreq]
    omega
  · intro k _
    rfl
end AEGIS.CvSProjectedTransportL12V1
