# Execution decision

**STRONGEST_VERIFIED_RESULT_WITH_EXACT_REMAINING_OBLIGATION**

The canonical unconditional Riemann Hypothesis was not proved in this session. No result is promoted from finite or conditional evidence to an unconditional theorem.

## New mathematical result

For each fixed actual CvS parameter M, positive interval length L, frequency radius R and tolerance epsilon>0, there is one natural cutoff NP>R such that every later cutoff P, every finite frequency support F within [-R,R], every complex coefficient vector a and every outer Fourier truncation N satisfy

```
sum_{P < |m| <= N} ||crossRow M L F a m||^2
    <= epsilon * (sum_{n in F} ||a n||)^2.
```

`CvSRowTailV1.exists_uniform_rows_tail_cutoff` derives this from the already proved actual analytic row bound and tau bound. Its exact order-zero coefficient is `16*(L/pi)^2*(tauBound M)^2/(P-R)`. The cutoff can depend on M,L,R and epsilon. This is relative l1 control; no dimension-independent l2/physical-energy bound or sign is inferred.

Five residual-transfer lemmas from the earlier recovery commit remain valid. The continuation adds the generic cutoff, the actual identity/cutoff, three weighted-clique/signed-form lemmas, and two reciprocal-pair countertests. Complete statements, hashes, axiom sets and source-context replay status for all 13 named results are in `EXECUTION_RECEIPT.json`.

## Independent challenge and route decision

Separate-agent reviews replayed the generic pilots and challenged empty indices, negative budgets, singular boundary cases, nonsymmetric error rows, repeated atoms, and symmetry-only Li positivity. They found no soundness defect in the scoped statements. This is internal independent reproduction, not external peer review.

No complete RH route passes Gate 2. A has an established exhaustion/limit theorem but lacks an actual all-window producer. B now has a better actual truncation lemma but lacks sufficient Schur/Krein/complement inequalities. C has exact signed identities and a stronger obstruction to overstrong absolute accounting, but no unconditional universal cancellation estimate. D's Li, zero-free and spectral interfaces retain their hard analytic obligations. Return to Stage 1 for the next analytic estimate; no hypothetical constructor was committed.

## Exact remaining mathematical obligation

For every required width, construct genuine certificate data for `window_of_certificate_tail`: the pointwise Krein certificate, trace/slack estimate and a positive complement gap, actual finite cross rows plus tail, and low-block dominance `hlow` for every coefficient vector. Alternatively, prove the existing exact universal signed mixed-defect inequality independently of RH. Parameters and positive constants may depend on the window; an unnecessarily common global constant is not required.

The cutoff only reduces truncation uncertainty. It cannot force the limiting Schur cost to fit its diagonal reserves. The verified toy matrix `[[1,2],[2,1]]` illustrates why positive blocks and zero truncation error do not suffice. The clique lemma `n*d<=S` concerns absolute certificates of arbitrary redundant decompositions; it does not refute existential `hselect` or the signed criterion.

## H140 and preservation

Original Claude files and the original 14-theorem audit remain inaccessible. User screenshots identify H140 as a Hilbert benchmark, not an actual CvS matrix. Its reported kernel success is not independently reproduced here. No matrix data, packing soundness theorem, original hashes, or margins were fabricated.

Source and tests were fast-forward pushed to the existing Feshbach branch. PR #89, protected main, production and billing were unchanged. The unrelated pre-existing untracked proof source was preserved. The historical recovery commit and its all-green CI remain separately recorded.

## Current publication and CI

Commit `f8604fa44e5ca0085ee008568f8d82b96cd25a02`. [Exact-SHA CI 39245617367](https://github.com/tarikskalic33/formal-conjectures/actions/runs/39245617367): **completed / success**.

* krein-ring: completed / success
* krein-slack: completed / success
* compile: completed / success

The sprint reports are frozen at their inspected baseline `251b6636`; their statements that actual integration was not yet run describe that earlier stage. The current receipt above records the later import replay at `f8604fa4`. Historical statuses and sources were retained rather than relabelled as a current-head run.
