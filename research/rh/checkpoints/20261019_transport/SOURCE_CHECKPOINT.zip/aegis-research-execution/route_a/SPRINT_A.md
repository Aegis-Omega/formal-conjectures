# Sprint A: cofinal windows

Decision: **Hold as the primary closure route; retain targeted analytic work.**
The compact-support exhaustion and scalar finite-to-limit passage are already
proved. The missing result is a source-bound certificate producer with the
required quantifiers, rather than another RH equivalence or a generic limit
wrapper. No unconditional RH theorem was obtained in this sprint.

## Exact source and kernel scope

Inspected development source at
`251b6636b1764f5bf243f59807ffc5ebed8ed782` on existing
`proof/rh-feshbach-schur-v1`, and assembly source at
`da0103e7afa0bb0ade1441f87d01e1b9416ef9c4`.
`ROUTE_A_RECEIPT.json` records exact Git blobs, SHA-256 hashes and prior root
receipts. These are two development lines, not interchangeable CI heads.
Lean 4.33.1 and Mathlib
`0df444a360eaa60ab8c11dca51a86af692955474` are the recorded pins.

The assembly receipt at da0103e7, run
https://github.com/tarikskalic33/formal-conjectures/actions/runs/39200032609,
contains kernel-imported roots
`RHFeshbachWeilClosureV2.riemannHypothesis_of_window_schur_families`,
`RHAssemblyV1.narrow_window_schur_family`,
`RHAssemblyV1.narrow_window_schur_norm_family`,
`RHCofinalActualTerminalV1.riemannHypothesis_of_cofinal_lower_certificates`,
`RHNineFacesV13.rh_iff_nat_windows_v13`, and
`RHFourLogThreeActualPrimeV1.actual_four_log_three_weighted_norm_coercive_sharp`.
Their recorded axioms are subsets of `propext`, `Classical.choice`, `Quot.sound`.
This is prior exact-source evidence, not a new native replay of those imports
on 251b6636. The closure-family and assembly-constructor source blobs are
identical on both heads.

`RHConsolidatedV1` has historical, source-bound run evidence at commit
`0f4415fa056e775d39b9c915733568fbdf248fc5`, run 38139018737. The complete
317-module historical source manifest is preserved in the preceding evidence
package. It is not a new replay at the development head.

`RHFeshbachScaledErrorV1` and `RHFeshbachScaledWeilV1` are real source modules
and identical on the two inspected heads. This sprint did not locate selected
root receipts for their declarations or compile their import DAG. Their
status here is **Lean source present, native replay not run**, not PASS.

## The target and exact quantifiers

Let

```
W(L) := forall g : WeilCompactSmoothGV1,
  WeilMomentConditionsV1 g ->
  tsupport (logLift g.1) ⊆ Set.Icc (-L) L ->
  (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re <= 0
```

Here `logLift g t = exp(t/2) * g(exp t)`. Existing
`WeilWindowExhaustionV1.logLift_has_finite_window_v1` gives a finite positive
window for every compactly supported packet. No limiting approximation or
density argument is required for this exhaustion step.

Existing `RHExistingProofFusionV1.rh_iff_pi_nat_windows` gives

```
RiemannHypothesis <-> forall n : Nat, 0 < n -> W((n : Real)*Real.pi)
```

and `RHNineFacesV13.rh_iff_nat_windows_v13` gives the corresponding positive
integer-radius criterion. Monotonicity goes downward: `L1 <= L2` and `W(L2)`
imply `W(L1)`. Proving many smaller windows cannot establish a larger one.
An arbitrary unbounded sequence of certified radii would suffice by the same
compact-support argument; no such source-bound certificate sequence was found.

The current direct packet consumer is
`RHFeshbachWeilClosureV2.riemannHypothesis_of_window_schur_families`:

```
(forall n : Nat, 0 < n ->
  forall g : WeilCompactSmoothGV1,
    WeilMomentConditionsV1 g ->
    LogWindowContainsV1 g ((n : Real)*Real.pi) ->
    PacketSchurFamily g) -> RiemannHypothesis
```

A family requires scalar sequences N,a,re_b,q,nv,nw,beta,c,mu,normSq,
a real upper bound C, and all of:

```
N_j -> infinity
(a_j + 2*re_b_j + q_j) -> the actual canonical zero quadratic of g
normSq_j <= C eventually
0 <= mu_j; 0 <= nw_j; 0 <= beta_j; mu_j < c_j
c_j * nw_j^2 <= q_j
re_b_j^2 <= beta_j * nw_j^2
-N_j^(-4)*normSq_j <= a_j - mu_j*nv_j^2 - beta_j/(c_j-mu_j)
```

The zero sum is indexed by `RiemannNontrivialZeroIndexV2`, with summand
`WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g)` and a real-part conclusion.
The analytic explicit formula has the sign
`arithmetic <= 0` iff `zero quadratic >= 0`; omitting the minus sign would
invalidate the bridge.

`PacketScaledSchurFamily` relaxes the bounded-norm requirement to exactly
`N_j^(-4)*normSq_j -> 0`. This is sufficient even for some growing norms; it
is not available for unrestricted growth. No uniform constant across every
g or every window is logically required: the families and constants may
depend on the packet/window. Requiring one universal bound independent of all
packets would strengthen the current terminal unnecessarily.

## Existing nontrivial parameterized pilot

The verified existing pilot is
`RHFeshbachWeilClosureV2.cofinal_feshbach_unshifted_eventually_bounded_nonnegative`.
It handles arbitrary cofinal N and arbitrary real sequences satisfying the
actual Feshbach lower bounds and eventually bounded norms. Its conclusion is
nonnegativity of the identified limit. It is a substantive parameterized
finite-to-limit theorem, and the verified terminal root above reaches it.

The exact next producer obligation is still

```
forall n > 0, forall admissible moment-zero g in radius n*pi,
  construct PacketSchurFamily g
```

with source identity and every estimate proved. A hypothetical constructor
would merely assume the missing mathematical content. In particular, the
record structure contains scalar data, not a theorem that a chosen numerical
matrix has those scalars. A source-bound construction is essential.

No new pilot file was added: another parameterized wrapper around this
already verified result would not improve the analytic proof chain. No broad
Mathlib rebuild was attempted to reprove an existing logical lemma.

## Uniformity and counterexample analysis

1. **Fixed finite dimensions do not exhaust windows.** The H140 screenshots
identify a Hilbert-matrix benchmark. Even a kernel-certified Hilbert H140
matrix has no established entry identification with the actual CvS form.
Increasing a Hilbert matrix dimension does not certify a Weil window.

2. **Two cofinalities differ.** Taking finite dimension N to infinity at fixed
window L is an approximation problem. Taking window L to infinity exhausts
packet supports. One does not imply the other.

3. **The exact prime cutoff grows with window width.** The ring identity
`RHKreinZetaBridgeV3.zero_quadratic_eq_scertM` requires
`2*r < log(M+1)`. A CvS certificate covering centered half-width r=n*pi
therefore needs full interval LT>=2*n*pi and `M+1 > exp(2*n*pi)`.
`CvSRowTailV1.window_of_certificate_tail` also needs LT<L, a pointwise Krein
certificate, a trace gap, actual finite cross-row bounds plus the analytic
row tail, and a low-block Schur inequality for every coefficient vector.
The `tauBound M` includes a sum of absolute prime-power weights. No
window-uniform control of the complete interacting budgets was found.
Exponential cutoff growth is a computational concern, not a mathematical
counterexample or a proof that no window-dependent construction can work.

4. **Dilation is not a free covariance.** The actual symbol is
`Psi(t)-log(pi)-sum_{k<M} ppw(k)*cos(t*log(k+1))`.
Dilation changes these prime-power frequencies and the digamma term.
No proved identity identifies an arbitrarily widened matrix with a positive
rescaling of the certified local matrix.

5. **Vanishing error alone is insufficient.** For N_j=j+1, choose
normSq_j=N_j^4 and q_j=-1. Then `-N_j^(-4)*normSq_j=q_j` exactly while
q_j tends to -1. Cofinal dimension and the advertised N^-4 coefficient do
not imply nonnegative limit without bounded/convergent norms or vanishing
scaled error. This is an exact mathematical counterexample to that omitted
hypothesis, not to the existing assumption-complete theorem.

6. **Sparse same-mother rows are not an established exhaustive class.** The
verified 4*log(3) weighted theorem has uniform margin 20829/16384 for every
finite n, but requires all atoms to be translates of one mother and mother
radius `min(1/256,1/(4*3^K))`, with K at least the largest 4*index gap.
The radius shrinks with the span. Dimension-free row control does not prove
that every packet has such a reconstruction. Existing
`RHTranslateSpectralObstructionV1.extra_mellin_zero_obstructs_universal_approximation`
proves that an extra common Mellin zero is retained by all translate sums
and Mellin-convergent limits. Multigenerator real-frequency complementarity
alone does not remove common complex zeros. These obstruction sources were
inspected; this sprint did not freshly replay their import DAG.

7. **The strict endpoint is a separate local question.** Historical
`RHConsolidatedV1.windows_below_21_40` proves W(L) for 0<=L<21/40,
not W(21/40). A smooth packet may have topological support touching the
boundary even though its values vanish there. It need not belong to a
strictly smaller window. A possible next analytic lemma is inward
approximation preserving both moments and convergence of the actual Weil
form. `RHLocalMomentCorrectionV1` already proves exact two-moment correction
and vanishing correction coefficients, while
`RHCertifiedApproximationV1.arithmetic_nonpositive_of_certified_limit`
consumes convergence of actual arithmetic values. Neither pointwise Mellin
convergence nor scalar correction identities alone supply the necessary
quadratic-form continuity. No endpoint theorem is asserted here.

## Next decisive mathematical experiment

The least ambitious new analytic target is endpoint closure at fixed L0:
for each moment-zero g supported in [-L0,L0], construct moment-zero p_j
supported in strictly smaller radii L_j<L0 with actual arithmetic values
converging to that of g. Start with L0=21/40. Reuse the two-moment correction
on two fixed interior packets with nonzero moment determinant; prove the
corrected approximants remain in the smaller windows and converge in a
fixed-support smooth topology controlling the explicit formula. This would
close a real local endpoint and test whether stronger continuity estimates
can support cofinal constructions. It would still not prove RH.

For global promotion, require a symbolic certificate-construction mechanism
for every window, or an unbounded explicitly certified sequence, with the
actual low-block, complement and cross inequalities proved together. No
such mechanism emerged in this sprint. Therefore Gate 2 cannot promote
Route A on the basis of the already proved exhaustion theorem.

## Comparative score (0--5, evidence assessment)

| Criterion | Score | Reason |
|---|---:|---|
| Universal interface | 5 | Exact all-packet and all-window consumers exist. |
| Independent analytic progress toward all windows | 1 | Only bounded support ranges are actually certified. |
| Generality of existing pilot | 4 | Arbitrary sequences and packet-indexed limits. |
| Formal feasibility of consumers | 5 | Prior exact-head kernel roots with standard axioms. |
| Resistance to naive extrapolation | 2 | Scaling, sparse-density and norm-growth countertests matter. |
| Reduction of infinite analytic obligations | 1 | Producers remain for arbitrary windows/packets. |
| Non-circularity of consumer proofs | 5 | Missing producer remains explicit. |
| Stability of known global construction constants | 1 | No complete unbounded-window construction exists. |

Discovery: exhaustion is already closed, with weaker scaled-error consumers
also present in source. Evidence: exact declarations, blobs and prior root
receipts above. Challenge: actual source-bound universal producer and mixed
budgets. Status: existing consumers kernel verified at prior assembly head;
new source-only alternatives not replayed; no new universal theorem.
Dependencies: pinned actual explicit-formula and restricted Weil bridges.
Recommendation: hold primary promotion, investigate the fixed-window
endpoint/continuity pilot before expanding certificate generation.
