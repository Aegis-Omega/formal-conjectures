# Universal targets and gates

The complete source types and their immutable provenance are preserved in the four route reports. These are mathematical obligations, not asserted Lean constructors.

A. Construct `PacketSchurFamily g` for every positive integer n and every moment-zero `WeilCompactSmoothGV1` packet g in radius n*pi. Existing `riemannHypothesis_of_window_schur_families` is the non-circular consumer; all compact-support exhaustion and the correctly identified cofinal limit are already formalized. The scalar family must be realized from actual matrices, and retain its norm/scaled-error condition.

B. For every requested width W>0, construct genuine CvS certificate data satisfying `window_of_certificate_tail` with LT>=W. Its input includes the pointwise Krein certificate, trace/slack bound and positive complement gap, finite cross rows plus their tail, and the actual low-block Schur inequality for every coefficient vector. The data and positive constants may depend on W. Sufficiency is proved; necessity of this particular representation has not been shown. The new cutoff controls one truncation term relative to squared l1 coefficient mass; it does not manufacture any positive gap or sign.

C. Prove, without assuming RH, that every moment-zero packet g admits a finite actual reconstruction `g = packetSum 1 gs` with `actualMixedDefect n gs <= -sum_i Re B(gs_i,gs_i)`. The existing iff makes this exactly RH-equivalent. Recomposition alone cannot change the true source sign. A selected reconstruction is sufficient; universal absolute certification of every arbitrary decomposition is invalid in general, as the new weighted-clique obstruction quantifies.

D. Three audited alternatives are (i) positivity of every true Li coefficient, (ii) all-shift actual Mellin detector sign / unit modulus of transport, (iii) zero-freeness in the full half-strip 1/2<Re(s)<1. Each still contains the hard RH-equivalent analytic content; some final Li provider bridges are only source-inspected in this environment. A fourth, complementary Mellin mother construction, avoids a common-zero obstruction but still lacks actual packet realization, appropriate strong-topology density and mixed-mother bounds.

## Gate 2 decision

No full route is promoted. The comparative scores are in `ROUTE_DECISIONS.json`. Continue bounded B/C investigations, retain A as the verified assembly, and hold unsupported alternatives. Return to Stage 1 for a new analytic estimate before expanding universal implementation.

The next decisive estimate must dominate the actual cross/Schur cost by the actual low/complement reserves for every required width (with parameter-dependent constants allowed), or prove the exact universal signed budget independently. Neither an extra RH equivalence, a fixed Hilbert certificate, a denser list of numerical windows, nor the cutoff theorem alone supplies it.

## Discovery protocol

Each route directory contains discovery, immutable evidence, strongest objection, logical/kernel status, dependencies and next experiment. Separate-agent native reproductions are in `review/`. They provide internal independent checks, not external mathematical peer review. No final unconditional theorem or external proof sign-off is asserted.
