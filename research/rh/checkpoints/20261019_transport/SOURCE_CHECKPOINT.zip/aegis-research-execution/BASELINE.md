# AEGIS research baseline

This baseline continues the existing development. It does not assert an unconditional proof of RH.

## Immutable sources and environment

* Repository: `tarikskalic33/formal-conjectures`.
* Existing Feshbach branch base: `9f6abc070b833df36e7fc7476ed306c9fef5ab14`.
* New verified residual-transfer commit: `251b6636b1764f5bf243f59807ffc5ebed8ed782` on the same remote branch, `proof/rh-feshbach-schur-v1`.
* Assembly PR #89: `da0103e7afa0bb0ade1441f87d01e1b9416ef9c4`, unchanged by the recovery commit.
* Lean: `leanprover/lean4:v4.33.1`, actual compiler commit `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`.
* Mathlib: `0df444a360eaa60ab8c11dca51a86af692955474`; local Mathlib worktree clean.
* Pinned configuration files are preserved in `environment/`.

The working checkout is detached at a commit on the existing Feshbach line. No new branch or repository was created. The local PR #89 branch remains intact. The pre-existing untracked `AEGISOverlay/RHSchurRowObstructionV1.lean` was preserved with SHA-256 `354a915be730b80941fb9a5a029bc66b6e0e9a1c017650f728d49ed5f64ee004`.

## Canonical target

Mathlib's existing `RiemannHypothesis` is exactly:

```lean
∀ (s : ℂ) (_ : riemannZeta s = 0)
  (_ : ¬∃ n : ℕ, s = -2 * (n + 1)) (_ : s ≠ 1), s.re = 1 / 2
```

Definition: `Mathlib/NumberTheory/LSeries/RiemannZeta.lean:185`, Git blob `3c92195fce20df7fda41cfd823b3266f83cf3070` at the Mathlib pin above. The official catalog source blob remains `5b1dcd5c46ab4a5f449d7d4a5c5ddce7c89c3542`. Its existing `by sorry` is an open-problem placeholder, not evidence and not an admitted root in this work.

The required final type remains `_root_.RiemannHypothesis`, without an additional producer, unitary-transport, positivity, or zero-location premise.

## Verified reusable evidence

PR #89 run [39200032609](https://github.com/tarikskalic33/formal-conjectures/actions/runs/39200032609) verified 107 selected roots and their 72,684-declaration proof graph, from 324 dependency source snapshots. The classified inventory preserves their complete elaborated types. Of those 324 snapshots, 292 are present as identical Git blobs on the Feshbach recovery commit; external/generated provider snapshots retain their independent provenance. This is not a fresh replay of every source on the current Feshbach branch.

The selected imported-environment census found no closed canonical RH proof in its checked environment. This is a scoped finding, not a claim that no proof exists elsewhere.

The earlier Feshbach source closure run [39223778272](https://github.com/tarikskalic33/formal-conjectures/actions/runs/39223778272) succeeded at the base `9f6abc07`. Its `krein-ring` log contains 110 successful audits. The recovery commit's separate run [39243519309](https://github.com/tarikskalic33/formal-conjectures/actions/runs/39243519309) is tracked in the current receipt; no earlier CI success is attributed to a later SHA.

New `CvSResidualCertificateV1` contains five lemmas with local kernel compilation, warnings as errors, explicit `#check` statements, and `#print axioms`. Each uses only `propext`, `Classical.choice`, and `Quot.sound`. The exact recovery commit's remote `compile` job also passed all five audits and scoped regressions. These results are dimension-parameterized residual transfer theorems with explicit entry-enclosure, symmetric-error, row-budget and centre-coercivity inputs. They do not construct an actual CvS certificate.

## H140 availability

**LOCAL_H140_ARTIFACTS_NOT_ACCESSIBLE.** The indicated Claude scratchpad and original `CvSPackedGramV1.lean`, generator, matrix data, and 14-theorem audit were not recovered from available local paths, remote branch evidence, or named connected Drive searches.

The supplied screenshots identify H140 as a **Hilbert matrix demonstration** of a packed Gram checker. They report 143 seconds for a kernel test, 26 seconds for its generator, and subsequent generated-source wrapping repairs. The original final 14/14 audit and approximately 215-second session validation are not independently reproduced. No H140 matrix coefficients, digit width, residual margin, or original source hashes are known here.

The new residual-transfer file is explicitly reconstructed work. No Hilbert-to-CvS identification is claimed.

## Scope and unresolved obligations

* Existing first-cell and adaptive finite-cell bounds give genuine local analytic positivity on their proved support domains; shrinking or finite-support domains cannot silently become all packets.
* Exact rational LDLT and arbitrary-precision outward interval arithmetic are available. An actual matrix bridge still needs source-derived entry enclosures and a verified shifted-centre margin.
* Existing Feshbach consumers already compose the finite block, cross bound, complement gap, and limiting argument. Their packet/window producer premises are still explicit.
* The exact signed mixed-defect condition is RH-equivalent. The equivalence itself supplies no sign. Existential selection must not be strengthened to every arbitrary decomposition.
* Time-slice unit modulus is equivalent to a zero lying on the critical line for nonzero shift. It is not an unconditional spectral input.
* A successful finite Hilbert, Gram, or Schur certificate does not quantify over all windows, packet reconstructions, or zeros.

Gate 0 is satisfied for classifying and testing these source-bound routes. It does not certify unexecuted APIs. In particular, local direct compilation of the umbrella-importing `RHExactLDLTV1` could not run because the local `Mathlib.olean` umbrella is absent; its earlier remote source replay remains separate evidence. Route pilots must use their true import contexts and report their own kernel results.

Route-specific exact targets, challenges, and pilot receipts are recorded by the four sprints. Advancement through the later gates depends on those results, not on this inventory alone.

## Final continuation receipt

The subsequent commit `f8604fa44e5ca0085ee008568f8d82b96cd25a02` passed all three jobs of exact-SHA CI [39245617367](https://github.com/tarikskalic33/formal-conjectures/actions/runs/39245617367). All 13 new named roots passed kernel and standard-axiom checks, including the two actual CvS roots. The original five-lemma snapshot and frozen sprint reports retain their earlier source identities; `EXECUTION_RECEIPT.json` records this later continuation. Gate2 remains unpassed for a complete RH route.
