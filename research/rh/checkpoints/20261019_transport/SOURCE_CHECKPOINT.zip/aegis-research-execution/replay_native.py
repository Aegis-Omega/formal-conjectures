"""Replay the locally reproducible scoped roots; actual CvS imports use the CI recipe."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import tempfile

parser=argparse.ArgumentParser()
parser.add_argument('repository',type=Path)
args=parser.parse_args()
repo=args.repository.resolve()
receipt=json.loads((Path(__file__).parent/'EXECUTION_RECEIPT.json').read_text())

def run(cmd,env=None):
    p=subprocess.run(cmd,cwd=repo,text=True,capture_output=True,env=env)
    if p.returncode:
        raise SystemExit(p.stdout+p.stderr)
    return p.stdout+p.stderr

assert run(['git','rev-parse','HEAD']).strip()==receipt['exact_commit']
assert run(['git','-C','.lake/packages/mathlib','rev-parse','HEAD']).strip()==receipt['mathlib_commit']
assert 'version 4.33.1' in run(['lake','env','lean','--version'])
for record in receipt['source_manifest']:
    assert hashlib.sha256((repo/record['path']).read_bytes()).hexdigest()==record['sha256']
with tempfile.TemporaryDirectory(prefix='aegis-replay-') as temp:
    sources=['research/rh/feshbach_lean_v1/CvSResidualCertificateV1.lean',
      'research/rh/feasibility_v1/SignedCliqueObstruction.lean',
      'research/rh/feasibility_v1/ReciprocalPairObstruction.lean']
    audits=0
    for index,source in enumerate(sources):
        cmd=['lake','env','lean','-DwarningAsError=true']
        if index==0:
            cmd+=['-o',str(Path(temp)/'CvSResidualCertificateV1.olean')]
        log=run(cmd+[source])
        for name,axioms in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",log):
            assert {a.strip() for a in axioms.split(',') if a.strip()} <= {'propext','Classical.choice','Quot.sound'},name
            audits+=1
    assert audits==11
    env=os.environ.copy()
    env['LEAN_PATH']=temp+':'+run(['lake','env','printenv','LEAN_PATH']).strip()
    run(['lake','env','lean','-DwarningAsError=true',
         'research/rh/feshbach_lean_v1/tests/CvSResidualCertificateTestV1.lean'],env=env)
print('PASS: 11 native named roots and scoped regressions; source hashes and pins match.')
print('The two actual CvS roots require the full source-import recipe in rh-feshbach-schur-v1.yml.')
