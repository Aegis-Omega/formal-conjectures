from pathlib import Path
from urllib.request import urlopen
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).parent
REPO = Path('/workspace/formal-conjectures')
HEAD = 'f8604fa44e5ca0085ee008568f8d82b96cd25a02'
BASE = '9f6abc070b833df36e7fc7476ed306c9fef5ab14'
MATHLIB = '0df444a360eaa60ab8c11dca51a86af692955474'
RUN = 39245617367
API = 'https://api.github.com/repos/tarikskalic33/formal-conjectures'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def digest(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD') == HEAD
assert git('-C', '.lake/packages/mathlib', 'rev-parse', 'HEAD') == MATHLIB
assert not git('-C', '.lake/packages/mathlib', 'status', '--porcelain')
run = json.load(urlopen(API + '/actions/runs/' + str(RUN)))
jobs = json.load(urlopen(API + '/actions/runs/' + str(RUN) + '/jobs'))
assert run['head_sha'] == HEAD
(ROOT / 'integration/run.json').write_text(json.dumps(run, indent=2))
(ROOT / 'integration/jobs.json').write_text(json.dumps(jobs, indent=2))
files = git('diff', '--name-only', BASE, HEAD).splitlines()
manifest = []
for path in files:
    data = (REPO / path).read_bytes()
    assert git('hash-object', path) == git('rev-parse', HEAD + ':' + path)
    remote = urlopen('https://raw.githubusercontent.com/tarikskalic33/formal-conjectures/' + HEAD + '/' + path).read()
    assert data == remote, path
    dest = ROOT / 'integration/sources' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    manifest.append(dict(path=path, sha256=digest(data), git_blob=git('hash-object', path),
                         commit=HEAD, remote_readback_byte_equal=True))

def clean_log(path):
    return re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ?', '', path.read_text(), flags=re.M)

compile_log = clean_log(ROOT / 'integration/exact-head-compile.log')
ring_path = ROOT / 'integration/exact-head-ring.log'
ring_log = clean_log(ring_path) if ring_path.exists() else ''
raw_compile = (ROOT / 'integration/exact-head-compile.log').read_text()
assert HEAD in raw_compile
if ring_path.exists():
    assert HEAD in ring_path.read_text()

groups = {
 'AEGIS.CvSResidualCertificateV1': ('research/rh/feshbach_lean_v1/CvSResidualCertificateV1.lean',
   ['exists_uniform_shifted_cutoff','residual_entry_le','abs_sub_le_of_enclosure',
    'residual_quadratic_le','actual_quadratic_nonneg','actual_hermitian_nonneg'], compile_log),
 'AEGIS.CvSRowTailV1': ('research/rh/feshbach_lean_v1/CvSRowTailV1.lean',
   ['rowTail_zero','exists_uniform_rows_tail_cutoff'], ring_log),
 'AEGIS.RouteC.SignedCliqueObstruction': ('research/rh/feasibility_v1/SignedCliqueObstruction.lean',
   ['clique_floor_le_weighted_ceiling','q16_clique_admission','signed_rank_one_nonpositive'], compile_log),
 'AEGIS.RouteD': ('research/rh/feasibility_v1/ReciprocalPairObstruction.lean',
   ['reciprocal_pair_strict_negative','reciprocal_pair_nonnegative_iff_unit'], compile_log),
}
dependencies = {
 'residual_quadratic_le':['AEGIS.CvSResidualCertificateV1.residual_entry_le'],
 'actual_quadratic_nonneg':['AEGIS.CvSResidualCertificateV1.residual_quadratic_le'],
 'actual_hermitian_nonneg':['AEGIS.CvSResidualCertificateV1.actual_quadratic_nonneg'],
 'rowTail_zero':['AEGIS.CvSRowTailV1.rowTail'],
 'exists_uniform_rows_tail_cutoff':['AEGIS.CvSRowTailV1.rowTail_zero',
   'AEGIS.CvSRowTailV1.rows_tail_le','AEGIS.CvSRowTailV1.tau_abs_le',
   'AEGIS.CvSResidualCertificateV1.exists_uniform_shifted_cutoff'],
 'q16_clique_admission':['AEGIS.RouteC.SignedCliqueObstruction.clique_floor_le_weighted_ceiling'],
 'reciprocal_pair_nonnegative_iff_unit':['AEGIS.RouteD.reciprocal_pair_strict_negative'],
}
roots=[]
for namespace, (path, names, log) in groups.items():
    source=(REPO/path).read_text()
    for short in names:
        name=namespace+'.'+short
        signature=re.search(r'^theorem '+re.escape(short)+r'\b[\s\S]*? := by',source,re.M)
        assert signature,name
        ax=re.search(r"'"+re.escape(name)+r"' depends on axioms:\s*\[([^\]]*)\]",log)
        if ax:
            axioms=[x.strip() for x in ax.group(1).split(',') if x.strip()]
            assert set(axioms)<={'propext','Classical.choice','Quot.sound'},(name,axioms)
            assert 'AXIOM_AUDIT_PASS '+name.removeprefix('AEGIS.')+':' in log,name
        else:
            assert not log,name
            axioms=None
        lines=log.splitlines(); checked=None
        for i,line in enumerate(lines):
            if re.match(r'^@?(?:'+re.escape(name)+'|'+re.escape(short)+r')(?:\s*:|\s*\()',line):
                block=[line]
                for more in lines[i+1:]:
                    if not more.startswith((' ','\t')):
                        break
                    block.append(more)
                checked='\n'.join(block)
                break
        if log:
            assert checked,name
        roots.append(dict(name=name,source=path,source_commit=HEAD,
            source_git_blob=git('hash-object',path),source_sha256=digest((REPO/path).read_bytes()),
            source_statement=signature.group().removesuffix(' := by'),full_checked_statement=checked,
            kernel_status='PASS' if ax else 'NOT_RUN',axiom_status='PASS' if ax else 'NOT_RUN',axioms=axioms,
            named_local_dependencies=dependencies.get(short,[]),
            local_native_context='NOT_RUN_actual_CvS_imports' if namespace.endswith('CvSRowTailV1') else 'PASS',
            independent_review='PASS_by_separate_agent_source_and_scope_review',
            independent_native_reproduction='pilot_only_for_actual_CvS_roots' if namespace.endswith('CvSRowTailV1') else 'PASS'))
assert len(roots)==13
receipt=dict(schema='aegis.rh.executive.execution.v1',
    timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    repository='tarikskalic33/formal-conjectures',branch='proof/rh-feshbach-schur-v1',
    exact_commit=HEAD,base_commit=BASE,prior_verified_commit='251b6636b1764f5bf243f59807ffc5ebed8ed782',
    assembly_pr89_head_unchanged='da0103e7afa0bb0ade1441f87d01e1b9416ef9c4',
    lean_version='4.33.1',mathlib_commit=MATHLIB,new_roots=roots,source_manifest=manifest,
    ci=dict(run={k:run[k] for k in ['id','head_sha','status','conclusion','html_url']},
      jobs=[{k:j[k] for k in ['id','name','status','conclusion']} for j in jobs['jobs']],
      log_hashes={p.name:digest(p.read_bytes()) for p in (ROOT/'integration').glob('exact-head-*.log')}),
    publication=dict(fast_forward=True,push_succeeded=True,readback_byte_equal=True,
      initial_native_push_retry='First attempt had transient credential-read failure; retry succeeded.',
      new_branches=False,force_push=False,merge=False,protected_main_modified=False),
    h140=dict(status='LOCAL_H140_ARTIFACTS_NOT_ACCESSIBLE',kind_reported='Hilbert matrix demonstration',
      original_data_recovered=False,original_source_hashes=None,original_14_audit_reproduced=False,
      actual_CvS_identification=False),
    gates=json.loads((ROOT/'ROUTE_DECISIONS.json').read_text())['gates'],
    strongest_actual_result='One cutoff for actual CvS cross-row tails, all later cutoffs, bounded frequency supports and complex coefficient vectors, relative to squared l1 mass at fixed M,L,R.',
    remaining_obligation='Construct actual all-required-window Krein/trace/complement and low-block Schur bounds, or the exact universal signed mixed-defect producer, with all limit-identification hypotheses. Constants may depend on each window.',
    canonical_RH='NOT_PROVED_IN_THIS_SESSION',decision='STRONGEST_VERIFIED_RESULT_WITH_EXACT_REMAINING_OBLIGATION')
(ROOT/'EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
graph=dict(schema='aegis.rh.research.dependencies.v1',exact_commit=HEAD,
    scope='New named-root local dependency edges, validated baseline source graph references, and separately labelled open research obligations; not a complete Mathlib proof-term export.',
    verified_nodes=roots,
    proof_edges=[dict(theorem=r['name'],depends_on=d) for r in roots for d in r['named_local_dependencies']],
    imported_source_reference='CLASSIFIED_THEOREM_INVENTORY.json: prior_assembly.source_manifest (324 original snapshots with immutable provenance)',
    open_nodes=['actual_all_window_certificate_producer','actual_low_block_schur_dominance',
      'actual_krein_trace_positive_complement_gap_for_each_required_window',
      'universal_actual_signed_budget','unconditional_riemannHypothesis'],
    research_support_edges=[dict(component='exists_uniform_rows_tail_cutoff',supports='tail portion of hfin only',does_not_discharge=['hlow','hcert','hcpos']),
      dict(component='actual_hermitian_nonneg',supports='finite real actual Schur matrix given enclosures and shifted-centre certificate',does_not_discharge=['actual entry enclosures','centre factorization','all-window producer'])],
    existing_conditional_terminals=['AEGIS.CvSRowTailV1.window_of_certificate_tail',
      'AEGIS.RHFeshbachWeilClosureV2.riemannHypothesis_of_window_schur_families',
      'AEGIS.RHOptimizedSchurGlobalJoinV1.rh_iff_one_actual_sharp_signed_budget'])
(ROOT/'DEPENDENCY_GRAPH.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2))
report='''# Execution decision

**STRONGEST_VERIFIED_RESULT_WITH_EXACT_REMAINING_OBLIGATION**

The canonical unconditional Riemann Hypothesis was not proved in this session. No result is promoted from finite or conditional evidence to an unconditional theorem.

## New mathematical result

For each fixed actual CvS parameter M, positive interval length L, frequency radius R and tolerance epsilon>0, there is one natural cutoff NP>R such that every later cutoff P, every finite frequency support F within [-R,R], every complex coefficient vector a and every outer Fourier truncation N satisfy

```
sum_{P < |m| <= N} ||crossRow M L F a m||^2
    <= epsilon * (sum_{n in F} ||a n||)^2.
```

`CvSRowTailV1.exists_uniform_rows_tail_cutoff` derives this from the already proved actual analytic row bound and tau bound. Its exact order-zero coefficient is `16*(L/pi)^2*(tauBound M)^2/(P-R)`. The cutoff can depend on M,L,R and epsilon. This is relative l1 control; no dimension-independent l2/physical-energy bound or sign is inferred.

Five residual-transfer lemmas from the earlier recovery commit remain valid. The continuation adds the generic cutoff, the actual identity/cutoff, three weighted-clique/signed-form lemmas, and two reciprocal-pair countertests. Complete statements, hashes, axiom sets and source-context replay status for all 13 named results are in `EXECUTION_RECEIPT.json`.

## Independent challenge and route decision

Separate-agent reviews replayed the generic pilots and challenged empty indices, negative budgets, singular boundary cases, nonsymmetric error rows, repeated atoms, and symmetry-only Li positivity. They found no soundness defect in the scoped statements. This is internal independent reproduction, not external peer review.

No complete RH route passes Gate 2. A has an established exhaustion/limit theorem but lacks an actual all-window producer. B now has a better actual truncation lemma but lacks sufficient Schur/Krein/complement inequalities. C has exact signed identities and a stronger obstruction to overstrong absolute accounting, but no unconditional universal cancellation estimate. D's Li, zero-free and spectral interfaces retain their hard analytic obligations. Return to Stage 1 for the next analytic estimate; no hypothetical constructor was committed.

## Exact remaining mathematical obligation

For every required width, construct genuine certificate data for `window_of_certificate_tail`: the pointwise Krein certificate, trace/slack estimate and a positive complement gap, actual finite cross rows plus tail, and low-block dominance `hlow` for every coefficient vector. Alternatively, prove the existing exact universal signed mixed-defect inequality independently of RH. Parameters and positive constants may depend on the window; an unnecessarily common global constant is not required.

The cutoff only reduces truncation uncertainty. It cannot force the limiting Schur cost to fit its diagonal reserves. The verified toy matrix `[[1,2],[2,1]]` illustrates why positive blocks and zero truncation error do not suffice. The clique lemma `n*d<=S` concerns absolute certificates of arbitrary redundant decompositions; it does not refute existential `hselect` or the signed criterion.

## H140 and preservation

Original Claude files and the original 14-theorem audit remain inaccessible. User screenshots identify H140 as a Hilbert benchmark, not an actual CvS matrix. Its reported kernel success is not independently reproduced here. No matrix data, packing soundness theorem, original hashes, or margins were fabricated.

Source and tests were fast-forward pushed to the existing Feshbach branch. PR #89, protected main, production and billing were unchanged. The unrelated pre-existing untracked proof source was preserved. The historical recovery commit and its all-green CI remain separately recorded.

'''
report+='## Current publication and CI\n\nCommit `'+HEAD+'`. [Exact-SHA CI '+str(RUN)+']('+run['html_url']+'): **'+run['status']+' / '+str(run['conclusion'])+'**.\n\n'
report+='\n'.join('* '+j['name']+': '+j['status']+' / '+str(j['conclusion']) for j in jobs['jobs'])+'\n'
report+='\nThe sprint reports are frozen at their inspected baseline `251b6636`; their statements that actual integration was not yet run describe that earlier stage. The current receipt above records the later import replay at `f8604fa4`. Historical statuses and sources were retained rather than relabelled as a current-head run.\n'
(ROOT/'FINAL_DECISION.md').write_text(report)
(ROOT/'AEGIS_RH_LEAN_PATCH.diff').write_bytes(subprocess.check_output(['git','diff',BASE,HEAD],cwd=REPO))
print(json.dumps(dict(head=HEAD,ci=run['status'],conclusion=run['conclusion'],
                     roots_pass=sum(r['kernel_status']=='PASS' for r in roots),roots_total=len(roots))))
