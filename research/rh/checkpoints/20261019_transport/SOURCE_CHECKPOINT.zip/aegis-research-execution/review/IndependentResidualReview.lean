import CvSResidualCertificateV1
open scoped BigOperators ComplexConjugate
open AEGIS.CvSResidualCertificateV1

theorem fin_two_univ : (Finset.univ : Finset (Fin 2)) = {0, 1} := by decide

-- The omitted nonnegativity hypothesis on the radius is logically redundant.
theorem radius_nonneg {e r : ℝ} (h : |e| ≤ r) : 0 ≤ r :=
  (abs_nonneg e).trans h

-- In nonempty dimension, the given entry and row contracts rule out ε < 0.
theorem budget_nonneg {ι : Type*} [Fintype ι] [Nonempty ι]
    (E R : ι → ι → ℝ) (ε : ℝ)
    (hE : ∀ i j, |E i j| ≤ R i j)
    (hrow : ∀ i, ∑ j, R i j ≤ ε) : 0 ≤ ε := by
  obtain ⟨i⟩ := ‹Nonempty ι›
  exact (Finset.sum_nonneg fun j _ => radius_nonneg (hE i j)).trans (hrow i)

-- Empty-dimensional input is harmless even with a negative budget.
theorem empty_negative_budget (z : Fin 0 → ℂ) :
    0 ≤ (∑ i : Fin 0, ∑ j : Fin 0,
      conj (z i) * z j * ((-100 : ℝ) : ℂ)).re := by
  apply actual_hermitian_nonneg (fun _ _ => -100) (fun _ _ => -200)
    (fun _ _ => -300) (-1)
  · intro i; exact Fin.elim0 i
  · intro i; exact Fin.elim0 i
  · intro i; exact Fin.elim0 i
  · intro x; simp

-- Both signs of a saturated residual are accepted by the scalar contract.
example : (2 : ℝ) * (-1) * (-3) ≤ 3 * (2 ^ 2 + (-1) ^ 2) / 2 :=
  residual_entry_le 2 (-1) (-3) 3 (by norm_num)

-- The interval-to-radius lemma permits a centre outside the enclosure.
example : |(1 : ℝ) - 10| ≤ max (10 - 0) (2 - 10) :=
  abs_sub_le_of_enclosure 1 10 0 2 (by norm_num) (by norm_num)

-- Construct the actual matrix counterexample to an unsigned row-only bound.
def badResidual (_i j : Fin 2) : ℝ := if j = 0 then 0 else 1
def badVector (i : Fin 2) : ℝ := if i = 0 then 1 else 2

theorem row_only_counterexample :
    (∀ i j, |badResidual i j| ≤ badResidual i j) ∧
    (∀ i, ∑ j, badResidual i j ≤ 1) ∧
    ¬ ((∑ i, ∑ j, badVector i * badVector j * badResidual i j) ≤
      1 * ∑ i, badVector i ^ 2) := by
  constructor
  · intro i j
    simp only [badResidual]
    split_ifs <;> norm_num
  constructor
  · intro i
    norm_num [fin_two_univ, badResidual]
  · norm_num [fin_two_univ, badResidual, badVector]

-- A real nonsymmetric matrix can have nonnegative real quadratic parts
-- while its complex quadratic form is not real. The theorem's .re matters.
def skewPlusId (i j : Fin 2) : ℝ :=
  if i = j then 1 else if i = 0 then 2 else -2
def complexVector (i : Fin 2) : ℂ := if i = 0 then 1 else Complex.I

theorem real_part_is_not_hermitian :
    (∑ i, ∑ j, conj (complexVector i) * complexVector j *
      (skewPlusId i j : ℂ)) = 2 + 4 * Complex.I := by
  norm_num [fin_two_univ, skewPlusId, complexVector]
  ring

#print axioms radius_nonneg
#print axioms budget_nonneg
#print axioms empty_negative_budget
#print axioms row_only_counterexample
#print axioms real_part_is_not_hermitian
