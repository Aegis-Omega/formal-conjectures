import Mathlib.Data.Real.Basic
namespace AEGIS.TransportReviewFailureShapes
namespace Packed
  def Im : Nat := 0
end Packed
namespace ImportedCertificate
  open Packed
  example : Im = 0 := rfl
end ImportedCertificate
namespace Consumer
  open ImportedCertificate
  /-- error: Unknown identifier `Im` -/
  #guard_msgs in
  #check Im
end Consumer

/-- The old direct application has the RHS factors reversed. -/
theorem ratio_commutation (a b kappa : Real) (hkappa : 0 < kappa)
    (h : a ≤ kappa * b) : a / kappa ≤ b := by
  fail_if_success exact (div_le_iff₀ hkappa).2 h
  apply (div_le_iff₀ hkappa).2
  simpa only [mul_comm] using h

/-- Simplifying definitions does not automatically commute the scale factor. -/
theorem scale_commutation (a scale Q : Real) (hscale : 0 < scale)
    (h : a ≤ scale * Q) : a / scale ≤ Q := by
  apply (div_le_iff₀ hscale).2
  fail_if_success simpa using h
  simpa only [mul_comm] using h

#print axioms ratio_commutation
#print axioms scale_commutation
end AEGIS.TransportReviewFailureShapes
