# Reproduction scope

`lean-toolchain`, `lake-manifest.json`, and `lakefile.toml` preserve the active
repository configuration. Their canonical location is the pinned Git commit,
not this documentation copy. No Mathlib definition was changed.

At a checkout of the published commit with its pinned dependencies available,
`python3 replay_native.py /path/to/formal-conjectures` verifies the source hashes
and pins, compiles 11 generic/countertest roots with warnings as errors, audits
their axioms, and compiles the residual regression file. The script does not
change branches or repository sources.

The two actual CvS roots are replayed in the **krein-ring** job of the existing
`.github/workflows/rh-feshbach-schur-v1.yml`. That job uses the pinned provider
recipe and compiles the ring and CvS import closure from sources before the
new row-tail theorem. The current receipt records its actual exact-SHA
result; a local generic pilot must not be substituted for that import replay.

The Git bundle preserves both new commits and requires the existing base
`9f6abc070b833df36e7fc7476ed306c9fef5ab14`. The patch preserves their net
source changes. These are recovery artifacts, not additional repositories.

Original Claude H140 packed code and data are absent. The reproduction
commands therefore reproduce the new research results, not the missing
Hilbert benchmark or its reported 14-theorem audit.
