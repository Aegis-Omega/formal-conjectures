# Source and status layers

* `da0103e7`: unchanged PR #89 assembly, 107 selected kernel roots. The
  classified inventory retains this exact-head evidence and full types.
* `9f6abc07`: existing Feshbach branch baseline, source closure CI success.
* `251b6636`: five new residual-transfer lemmas and recovery report. All
  three jobs of CI `39243519309` passed. The four feasibility sprints and
  initial independent reviews inspected this snapshot and PR #89.
* `f8604fa4`: continuation with the generic cutoff, two actual CvS row-tail
  lemmas, and the C/D countertests. `EXECUTION_RECEIPT.json` records CI
  `39245617367` for this SHA. Only that receipt can certify these later roots.

The route reports are frozen records of each sprint. Their earlier
`NOT_RUN` labels for actual import integration are not rewritten after the
parent's later integration; the final receipt provides the subsequent
source-bound result. Independent review logs identify their own source
hashes and whether reproduction was generic or in the actual CvS context.

No original Claude H140 source, matrix data or audit was recovered. The
screenshots report a Hilbert demonstration. New residual/cutoff/countertest
files are reconstructed research, with exact hashes and separate provenance.

The dependency graph labels local proof edges separately from research
obligations. It is not presented as a complete new Mathlib proof-term dump.
The older complete selected-root graph remains in the independently hashed
PR #89 evidence archive at its own SHA.
