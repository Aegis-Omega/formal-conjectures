-- Native fail-closed finite tests over the exact computational source slice.
-- Full soundness imports are audited separately by exact-commit CI.
import CvSPackedGramV1
open AEGIS.CvSPackedGramV1

theorem empty_rejected : check 16 1 0 0 0 [] [] = false := by decide +kernel
theorem insufficient_base_rejected : check 4 1 1 0 0 [[0]] [[⟨0, 0⟩]] = false := by decide +kernel
theorem negative_out_of_range_rejected : check 16 1 1 0 0 [[-2]] [[⟨0, 0⟩]] = false := by decide +kernel
theorem wrong_factor_shape_rejected : check 16 1 1 0 0 [[0, 0]] [[⟨0, 0⟩]] = false := by decide +kernel
theorem wrong_interval_shape_rejected : check 16 1 1 0 0 [[0]] [[⟨0, 0⟩, ⟨0, 0⟩]] = false := by decide +kernel
theorem excess_residual_rejected : check 16 1 1 1 0 [[0]] [[⟨0, 0⟩]] = false := by decide +kernel
-- A zero-margin certificate can pass; strict positivity is a separate obligation.
theorem zero_margin_accepted : check 1 0 1 0 0 [[0]] [[⟨0, 0⟩]] = true := by decide +kernel
-- Carry collision without the base bound: extracted0 differs from true dot2.
theorem carry_collision_without_bound : (pack 2 [1, 1] * pack 2 [1, 1]) / 2 % 2 = 0 := by decide +kernel
theorem true_dot_nonzero : (1 * 1 + 1 * 1 : Nat) ≠ 0 := by decide +kernel

#print axioms empty_rejected
#print axioms insufficient_base_rejected
#print axioms negative_out_of_range_rejected
#print axioms wrong_factor_shape_rejected
#print axioms wrong_interval_shape_rejected
#print axioms excess_residual_rejected
#print axioms zero_margin_accepted
#print axioms carry_collision_without_bound
#print axioms true_dot_nonzero
