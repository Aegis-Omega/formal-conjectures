from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
from urllib.request import urlopen

ROOT = Path(__file__).parent
REPO = Path('/workspace/formal-conjectures')
BASE = '9f6abc070b833df36e7fc7476ed306c9fef5ab14'
HEAD = '251b6636b1764f5bf243f59807ffc5ebed8ed782'
MATHLIB = '0df444a360eaa60ab8c11dca51a86af692955474'
API = 'https://api.github.com/repos/tarikskalic33/formal-conjectures'
SOURCE = 'research/rh/feshbach_lean_v1/CvSResidualCertificateV1.lean'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

assert git('rev-parse', 'HEAD') == HEAD
assert git('-C', '.lake/packages/mathlib', 'rev-parse', 'HEAD') == MATHLIB
assert not git('-C', '.lake/packages/mathlib', 'status', '--porcelain')
log = (ROOT / 'residual-kernel.log').read_text()
assert 'sorryAx' not in log
types = dict(re.findall(
    r'^@?(AEGIS\.CvSResidualCertificateV1\.\w+)\s+:\s*(.*?)(?=^@?AEGIS|^\x27AEGIS|\Z)',
    log, re.M | re.S))
audits = re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", log)
assert len(types) == len(audits) == 5
local_deps = {
    'residual_entry_le': [], 'abs_sub_le_of_enclosure': [],
    'residual_quadratic_le': ['residual_entry_le'],
    'actual_quadratic_nonneg': ['residual_quadratic_le'],
    'actual_hermitian_nonneg': ['actual_quadratic_nonneg'],
}
roots = []
for name, axs in audits:
    axioms = [x.strip() for x in axs.split(',') if x.strip()]
    assert set(axioms) <= {'propext', 'Classical.choice', 'Quot.sound'}
    roots.append(dict(name=name, full_type=types[name].strip(), source_path=SOURCE,
        source_commit_sha=HEAD, source_sha256=hashlib.sha256((REPO / SOURCE).read_bytes()).hexdigest(),
        local_dependencies=local_deps[name.rsplit('.', 1)[1]],
        kernel_status='PASS', axiom_status='PASS', axioms=axioms,
        actual_h140_or_cvs_instance=False))

manifest = json.loads((ROOT / 'source-manifest.json').read_text())
for rec in manifest:
    data = (REPO / rec['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == rec['sha256']
    assert git('rev-parse', HEAD + ':' + rec['path']) == rec['git_blob_sha']

run = json.load(urlopen(API + '/actions/runs/39243519309'))
jobs = json.load(urlopen(API + '/actions/runs/39243519309/jobs'))
assert run['head_sha'] == HEAD
(ROOT / 'new-ci-run.json').write_text(json.dumps(run, indent=2))
(ROOT / 'new-ci-jobs.json').write_text(json.dumps(jobs, indent=2))
baseline = json.loads((ROOT / 'remote-run-baseline.json').read_text())
assert baseline['head_sha'] == BASE and baseline['conclusion'] == 'success'
published = []
for path in [SOURCE, '.github/workflows/rh-feshbach-schur-v1.yml',
             'research/rh/feshbach_lean_v1/H140_RECOVERY_REPORT.md',
             'research/rh/feshbach_lean_v1/tests/CvSResidualCertificateTestV1.lean']:
    data = urlopen('https://raw.githubusercontent.com/tarikskalic33/formal-conjectures/' + HEAD + '/' + path).read()
    assert data == (REPO / path).read_bytes()
    published.append(dict(path=path, sha256=hashlib.sha256(data).hexdigest(), byte_equal=True))

remote_compile_log = (ROOT / 'exact-head-compile.log').read_text()
assert HEAD in remote_compile_log
remote_audits = [line for line in remote_compile_log.splitlines()
                 if 'AXIOM_AUDIT_PASS CvSResidualCertificateV1.' in line]
assert len(remote_audits) == 5

receipt = dict(
    schema='aegis.h140.recovery.v1', timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    repository='tarikskalic33/formal-conjectures', branch='proof/rh-feshbach-schur-v1',
    base_commit_sha=BASE, exact_commit_sha=HEAD,
    pr89_head_sha='da0103e7afa0bb0ade1441f87d01e1b9416ef9c4',
    recovery_status='LOCAL_H140_ARTIFACTS_NOT_ACCESSIBLE',
    recovered_original_files=[], original_artifact_hashes=None,
    original_artifact_hashes_reason='Original source bytes, generator and audit log are not accessible.',
    original_artifacts_sought=['CvSPackedGramV1.lean', 'packed.lean', 'c40.lean',
        'q16bench scratchpad', 'H140 data and generator', '14-theorem audit and 215-second validation log'],
    recovery_search_scope=['tracked/untracked/ignored checkout artifacts', '/workspace', '/tmp',
        '/home/agent excluding installed dependencies', 'live Feshbach branch tree and history',
        'baseline CI jobs and artifact list', 'GitHub code/commit searches (code search default branches only)',
        'connected Drive filename/text searches for H140 and CvSPackedGramV1'],
    reported_h140=dict(kind='Hilbert matrix checker demonstration (user screenshots)', dimension=140,
        dimension_verified_from_original_data=False, matrix_data=None, construction_parameters=None,
        packing_width=None, signed_packing_proof='NOT_RECOVERED', positivity_margin=None,
        residual_bound=None, kernel_seconds_reported=143, generator_seconds_reported=26,
        final_validation_seconds_reported=215, original_14_theorem_audit='NOT_REPRODUCED'),
    new_reconstruction=dict(files=published, roots=roots, matrix_data_generated=False,
        h140_replayed=False, actual_cvs_matrix_certified=False, normalization_changed=False),
    toolchain=dict(lean_required='4.33.1',
        lean_actual=subprocess.check_output(['lake', 'env', 'lean', '--version'], cwd=REPO, text=True).strip(),
        mathlib_required=MATHLIB, mathlib_actual=git('-C', '.lake/packages/mathlib', 'rev-parse', 'HEAD'),
        mathlib_worktree_clean=True),
    native_checks=[dict(command='lake env lean -DwarningAsError=true -o /workspace/aegis-h140-recovery/CvSResidualCertificateV1.olean ' + SOURCE,
        status='PASS', compiler_output=log),
        dict(command='LEAN_PATH="/workspace/aegis-h140-recovery:$(lake env printenv LEAN_PATH)" lake env lean -DwarningAsError=true research/rh/feshbach_lean_v1/tests/CvSResidualCertificateTestV1.lean',
            status='PASS', compiler_output=(ROOT / 'residual-regression.log').read_text()),
        dict(command='lake env lean research/rh/krein_ring_v1/RHExactLDLTV1.lean', status='FAIL',
            reason='Local Mathlib.olean umbrella unavailable. This is not a mathematical refutation; the existing source passed baseline remote CI.')],
    ci=dict(baseline={k: baseline[k] for k in ['id', 'head_sha', 'status', 'conclusion', 'html_url']},
        new_run={k: run[k] for k in ['id', 'head_sha', 'status', 'conclusion', 'html_url']},
        jobs=[{k: j[k] for k in ['id', 'name', 'status', 'conclusion']} for j in jobs['jobs']],
        exact_head_compile_log_sha256=hashlib.sha256(remote_compile_log.encode()).hexdigest(),
        new_root_remote_audit_lines=remote_audits,
        exact_head_compile_audit_count=remote_compile_log.count('AXIOM_AUDIT_PASS')),
    push=dict(succeeded=True, fast_forward=True, remote_readback_sha=HEAD,
        all_four_changed_files_byte_equal=True, new_branches_created=False, force_push=False,
        local_checkout_mode='detached commit on existing remote development line; local PR89 branch retained',
        unrelated_untracked_source_preserved=dict(path='AEGISOverlay/RHSchurRowObstructionV1.lean',
            sha256='354a915be730b80941fb9a5a029bc66b6e0e9a1c017650f728d49ed5f64ee004')),
    nearest_existing_consumer='AEGIS.CvSRowTailV1.window_of_certificate_tail', consumer_instantiated=False,
    remaining_obligation=dict(
        entry_bridge='Source-derived enclosures for the actual CvS/Weil Schur matrix, with index, basis and normalization identities. The Hilbert benchmark is a different matrix.',
        finite_certificate='epsilon-coercivity of the chosen centre (e.g. exact LDLT of A0 - epsilon I) and symmetric residual entry bounds with every row sum <= epsilon.',
        consumer='Discharge hfin (finite cross rows plus rowTail), hlow (actual low-block dominance for every c), hcpos and genuine Krein/slack premises of window_of_certificate_tail.',
        global_spine='After any fixed finite/window certificate, prove the required cofinal/all-window producer and limiting control.'),
    decision='STRONGEST_VERIFIED_RESULT_WITH_EXACT_REMAINING_OBLIGATION',
    unconditional_riemannHypothesis='NOT_PROVED_IN_THIS_SESSION')
(ROOT / 'H140_RECOVERY_RECEIPT.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
report = (REPO / 'research/rh/feshbach_lean_v1/H140_RECOVERY_REPORT.md').read_text()
report += '\n## Publication receipt\n\nNew source and workflow were committed and fast-forward pushed as `' + HEAD + '`. All four changed files were read back from GitHub byte-for-byte. PR #89 was unchanged.\n\n'
report += 'Exact-SHA CI: [' + str(run['id']) + '](' + run['html_url'] + '), status **' + run['status'] + '**, conclusion **' + str(run['conclusion']) + '**.\n'
report += '\n' + '\n'.join('* ' + j['name'] + ': ' + j['status'] + ' / ' + str(j['conclusion']) for j in jobs['jobs']) + '\n'
(ROOT / 'H140_RECOVERY_REPORT.md').write_text(report)
(ROOT / 'AEGIS_RH_LEAN_PATCH.diff').write_bytes(subprocess.check_output(['git', 'diff', BASE, HEAD], cwd=REPO))
print(json.dumps(dict(head=HEAD, roots=len(roots), ci=receipt['ci']['new_run'], jobs=receipt['ci']['jobs'])))
