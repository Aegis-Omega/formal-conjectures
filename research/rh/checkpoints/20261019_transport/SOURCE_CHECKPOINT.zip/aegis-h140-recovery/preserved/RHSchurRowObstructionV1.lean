/-
Copyright 2026 The Formal Conjectures Authors.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at https://www.apache.org/licenses/LICENSE-2.0
-/
import Mathlib.Tactic.Linarith
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Fintype.BigOperators

open scoped BigOperators

/-! Necessary pairwise bounds for symmetric weighted Schur row certificates.
These bounds apply over every linearly ordered field, including the real
weights in the actual Weil producer. They do not produce mixed estimates.
-/
namespace AEGIS.RHSchurRowObstructionV1
variable {α : Type*} [Field α] [LinearOrder α] [IsStrictOrderedRing α]

/-- Opposite weighted rows force a symmetric cost below their common ceiling,
independently of the positive weights. -/
theorem pair_cost_le_ceiling (c S u v : α) (hu : 0 < u) (hv : 0 < v)
    (h₁ : c * (v / u) ≤ S) (h₂ : c * (u / v) ≤ S) : c ≤ S := by
  have h₁' : c * v ≤ S * u := by
    apply (div_le_iff₀ hu).mp
    simpa only [mul_div_assoc] using h₁
  have h₂' : c * u ≤ S * v := by
    apply (div_le_iff₀ hv).mp
    simpa only [mul_div_assoc] using h₂
  by_contra h
  have hlt : S < c := lt_of_not_ge h
  have hu' := mul_lt_mul_of_pos_right hlt hu
  have hv' := mul_lt_mul_of_pos_right hlt hv
  linarith

/-- Every entry of a symmetric nonnegative cost matrix is bounded by any
common positive-weight Schur row ceiling. This applies to the c and w
parameters of the actual optimized Weil producer in every finite dimension. -/
theorem entry_le_weighted_row_ceiling {ι : Type*} [Fintype ι]
    (c : ι → ι → α) (w : ι → α) (S : α)
    (hc : ∀ i j, 0 ≤ c i j) (hsym : ∀ i j, c i j = c j i)
    (hw : ∀ i, 0 < w i)
    (hrow : ∀ i, ∑ j, c i j * (w j / w i) ≤ S) (i j : ι) :
    c i j ≤ S := by
  have hij : c i j * (w j / w i) ≤ S :=
    (Finset.single_le_sum
      (fun k _ => mul_nonneg (hc i k) (le_of_lt (div_pos (hw k) (hw i))))
      (Finset.mem_univ j)).trans (hrow i)
  have hji : c j i * (w i / w j) ≤ S :=
    (Finset.single_le_sum
      (fun k _ => mul_nonneg (hc j k) (le_of_lt (div_pos (hw k) (hw j))))
      (Finset.mem_univ i)).trans (hrow j)
  rw [hsym j i] at hji
  exact pair_cost_le_ceiling (c i j) S (w i) (w j) (hw i) (hw j) hij hji

/-- No positive weights can certify an entry at least the conservative Q16
coercive diagonal floor against the optimized Schur row ceiling. -/
theorem no_repeated_q16_pair (c u v : α) (hu : 0 < u) (hv : 0 < v)
    (hdiag : (116142 / 65536 : α) ≤ c)
    (h₁ : c * (v / u) ≤ (46688 / 65536 : α))
    (h₂ : c * (u / v) ≤ (46688 / 65536 : α)) : False := by
  have h := pair_cost_le_ceiling c (46688 / 65536) u v hu hv h₁ h₂
  linarith

#print axioms entry_le_weighted_row_ceiling
#print axioms pair_cost_le_ceiling
#print axioms no_repeated_q16_pair
#check @entry_le_weighted_row_ceiling
#check @pair_cost_le_ceiling
#check @no_repeated_q16_pair
end AEGIS.RHSchurRowObstructionV1
