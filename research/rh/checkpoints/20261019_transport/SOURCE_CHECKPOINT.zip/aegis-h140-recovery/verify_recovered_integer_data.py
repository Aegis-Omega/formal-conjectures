"""Independent integer verification only; not Lean and not an analytic enclosure proof."""
import ast,hashlib,json,re,time
from fractions import Fraction
from pathlib import Path
root=Path('/workspace/aegis-h140-recovery')
p=root/'recovered_4fabfb66/HilbCert140.lean';s=p.read_text()
L=ast.literal_eval(s[s.index(':= [')+3:s.index('theorem hilb_check')].strip())
m=re.search(r'theorem hilb_check : check \(2 \^ (\d+)\) (\d+) (\d+) (\d+) (\d+)',s)
assert m
K,B,n,eps,eta=map(int,m.groups());q=int(re.search(r'hilbIv (\d+) '+str(n),s).group(1))
I=[[(2**q//(i+j+1),2**q//(i+j+1)+1) for j in range(n)] for i in range(n)]
def verify(name,n,q,b,B,eps,eta,L,I):
 t=time.monotonic()
 assert n>0 and len(L)==len(I)==n and all(len(r)==n for r in L+I)
 assert all(-B<=x<=B for r in L for x in r)
 assert n*n*(2*B)**2<b
 errors=[]
 for i in range(n):
  e=0
  for j in range(n):
   lo,hi=I[i][j];assert lo<=hi
   center=sum(x*y for x,y in zip(L[i],L[j]))+(eps if i==j else 0)
   e+=max(hi-center,center-lo)
  assert e<=eta,(name,i,e,eta)
  errors.append(e)
 assert eps>eta
 f=Fraction(eps-eta,2**q)
 return {'kind':'independent Python integer verification; not kernel or analytic bridge','dimension':n,'q':q,'base':str(b),'B':str(B),'eps':str(eps),'eta':str(eta),'max_row_error':str(max(errors)),'max_row_error_equals_eta':max(errors)==eta,'positive_margin_numerator':str(f.numerator),'positive_margin_denominator':str(f.denominator),'all_row_errors':[str(x) for x in errors],'strict_packing_bound':True,'margin_strictly_positive':True,'seconds':time.monotonic()-t}
h=verify('Hilbert140',n,q,2**K,B,eps,eta,L,I)
h.update({'packing_base_exponent':K,'certificate_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'input_identity':'actual Hilbert rational matrix, with exact floor/outward unit enclosures'})
(root/'recovered_4fabfb66/H140_INTEGER_RECEIPT.json').write_text(json.dumps(h,indent=2)+'\n')
p=root/'exact_head_8a8e902e/PROJECTED_DATA.json';x=json.loads(p.read_text());c=x['constants'];d=x['data']
a=verify('projected139',139,c['certQ'],c['certBase'],c['certB'],c['certEps'],c['certEta'],d['certL'],d['certI'])
a.update({'input_identity':'provided projected certificate interval table; analytic containment is NOT checked by this integer verifier','certR_upper_triangular':all(d['certR'][i][j]==0 for i in range(139) for j in range(i)),'certR_diagonal_all_nonzero':all(d['certR'][i][i]!=0 for i in range(139))})
(root/'exact_head_8a8e902e/PROJECTED_INTEGER_RECEIPT.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({k:{a:v for a,v in z.items() if a in ['dimension','q','seconds','max_row_error_equals_eta','positive_margin_numerator','packing_base_exponent','margin_strictly_positive']} for k,z in [('H140',h),('projected139',a)]},indent=2))
