import Mathlib.Data.Int.Basic
namespace AEGIS.RHFixIntervalV1
structure Iv where
  lo : ℤ
  hi : ℤ
  deriving DecidableEq, Repr
end AEGIS.RHFixIntervalV1
namespace AEGIS.CvSPackedGramV1
open AEGIS.RHFixIntervalV1
def pack (b : ℕ) : List ℕ → ℕ
  | [] => 0
  | a :: l => a + b * pack b l

def offRow (B : ℕ) (r : List ℤ) : List ℕ := r.map fun x : ℤ => (x + (B : ℤ)).toNat

def gramEntry (b B n : ℕ) (P : ℕ) (s : ℤ) (R : ℕ) (t : ℤ) : ℤ :=
  ((P * R / b ^ (n - 1) % b : ℕ) : ℤ) - B * (s + t) - n * B ^ 2

def errAt (eps : ℤ) (i j : ℕ) (g : ℤ) (I : Iv) : ℤ :=
  max (I.hi - (g + if i = j then eps else 0)) ((g + if i = j then eps else 0) - I.lo)

def rowErr (b B n : ℕ) (eps : ℤ) (i P : ℕ) (s : ℤ) : ℕ → List (ℕ × ℤ) → List Iv → ℤ
  | j, c :: cs, I :: Is =>
    errAt eps i j (gramEntry b B n P s c.1 c.2) I + rowErr b B n eps i P s (j + 1) cs Is
  | _, _, _ => 0

def rowsOk (b B n : ℕ) (eps eta : ℤ) (cols : List (ℕ × ℤ)) :
    ℕ → List (List ℤ) → List (List Iv) → Bool
  | i, r :: rs, Ir :: Irs =>
    decide (rowErr b B n eps i (pack b (offRow B r)) r.sum 0 cols Ir ≤ eta) &&
      rowsOk b B n eps eta cols (i + 1) rs Irs
  | _, _, _ => true

def rowBounded (B n : ℕ) (r : List ℤ) : Bool :=
  decide (r.length = n) && r.all fun x => decide (-(B : ℤ) ≤ x) && decide (x ≤ B)

def check (b B n : ℕ) (eps eta : ℤ) (L : List (List ℤ)) (I : List (List Iv)) : Bool :=
  decide (0 < n) && decide (n * n * (2 * B * (2 * B)) < b) && decide (L.length = n) &&
    decide (I.length = n) && L.all (rowBounded B n) && I.all (fun r => decide (r.length = n)) &&
    rowsOk b B n eps eta (L.map fun r => (pack b (offRow B r).reverse, r.sum)) 0 L I

def hilbIv (q n : ℕ) : List (List Iv) :=
  (List.range n).map fun i => (List.range n).map fun j =>
    ⟨((2 ^ q / (i + j + 1) : ℕ) : ℤ), ((2 ^ q / (i + j + 1) + 1 : ℕ) : ℤ)⟩

end AEGIS.CvSPackedGramV1
