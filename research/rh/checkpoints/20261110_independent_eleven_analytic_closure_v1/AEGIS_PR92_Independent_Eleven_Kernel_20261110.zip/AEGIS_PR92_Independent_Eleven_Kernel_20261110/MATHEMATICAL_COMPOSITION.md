# Existing independent-shape proof: formal composition

The mathematical argument is the previously published direct composition in
commit `c8fb2ffa5d5f12de0bd4627de6835e8e32d63940`. The new sources formalize
its analytic interfaces. They reuse the more recent exact-row and independent
Gram consumer recovered at `b41de11170acc4f92ea5f787dd098da992b37f0a`.
This document makes no claim of a new choice of weights or an RH proof.
Execution acceptance is recorded separately in actual compiler receipts.

Let each `h_i`, `0 <= i <= 10`, be an independently chosen complex smooth
function with compact support in the positive half-line, with

    integral_(0,infinity) h_i(x)/x dx = 0,
    integral_(0,infinity) h_i(x) dx = 0,
    tsupport(t -> exp(t/2) h_i(exp t)) subset [a-1/256,a+1/256].

The support condition uses the actual repository `LogSupportIn` predicate;
the formal proofs use its pointwise consequences, including closed endpoints.
Write `s_i=i log(33/16)`, `p_i=translatePacket h_i s_i`, and
`F=packetSum z p` for arbitrary complex `z_i`. The translation is
`p_i(x)=exp(-s_i/2) h_i(exp(-s_i)x)` and preserves ordinary energy
`E(h)=integral_R |h(x)|^2 dx`. Let `B` be the unchanged sesquilinear
arithmetic Weil form, linear in its first argument.

In these exact conventions, `logLift(p_i)(t)=logLift(h_i)(t-s_i)`.
Thus its closed logarithmic support is contained in
`[a+s_i-1/256,a+s_i+1/256]`. The two moment integrals are multiplied
respectively by `exp(-s_i/2)` and `exp(s_i/2)`, so both remain zero.
The closed endpoints are retained throughout; no prime-window endpoint
is discarded. Each half-width is1/256 and the correlation half-width
is their sum,1/128.

The composed theorem is

    Re B(F,F) <= -(1203957/1136000) sum_i E(h_i)|z_i|^2.       (1)

There is no common-mother or mixed-form hypothesis in (1).

For two fine packets `p,q` at centers `a_p<a_q`, put `d=a_q-a_p`.
For `p=p_i,q=p_j` with `i<j`, this is
`d=(j-i)log(33/16)` with integer `1<=j-i<=10`. Since `33/16>2`, every
such gap is strictly larger than `log2`, hence larger than1/128.
The existing logarithmic correlation is

    X_pq(u)=integral_R logLift(p)(v+u) conjugate(logLift(q)(v)) dv.

Its support lies in `[-d-1/128,-d+1/128]`. The exact existing Mellin
coordinate identity gives

    m^(-1) mixed(p,q,m^(-1)) = m^(-1/2) X_pq(-log m).         (2)

When `d>1/128`, all positive-integer samples vanish. Reciprocal samples
vanish unless `|log m-d|<=1/128`. The independently shaped correlation
bound already in `RHActualMixedDefectV1` is
`||X_pq(u)|| <= (E(p)+E(q))/2`. No positivity of `B` is used.

For the original lattice gaps 1 through 8, the existing eight scalar
von Mangoldt window theorems annihilate every prime-power term. For gap9
the existing integer envelope contains only two nonzero von Mangoldt
samples,673 and677; for gap10 it contains only1399. These statements
apply independently of packet shapes. The bounded prime-power checker
re-exposes the old private scalar exclusions in the new adapter. All
infinite sums are collapsed termwise to their exact finite exceptional
sets, rather than truncated numerically.

By (2), the old integer square comparisons `25^2<=673,677` and
`37^2<=1399`, and the old logarithmic ceilings, the prime norm costs are
`14/25` at gap9 and `8/37` at gap10, times `(E(p)+E(q))/2`.
The existing independent-packet Archimedean bound adds `1/100` times
that same mean. Its center sample is zero by actual support. Consequently

    ||B(p,q)|| <= (c_k/2)(E(p)+E(q)),
    c_9=57/100, c_10=837/3700, c_1=...=c_8=1/100.             (3)

Apply (3) to `r p,q` for every real `r`. Support and both moments survive
scaling, and existing sesquilinearity and energy scaling give

    |r| ||B(p,q)|| <= (c_k/2)(r^2 E(p)+E(q)).

Hence `c_k E(p) r^2-2||B(p,q)||r+c_k E(q)` is nonnegative for every
real `r`. Mathlib's existing discriminant theorem implies

    ||B(p,q)|| <= c_k sqrt(E(p))sqrt(E(q)).                   (4)

This proof includes zero energies and needs neither division nor a
limit of packets. Hermitian symmetry supplies the reverse ordered pair.
Every mixed complex phase is retained.

The original diagonal producer gives `-Re B(p_i,p_i)>=D E(h_i)` with
`D=5671/3200`. The recovered existing independent-eleven consumer uses
the original weights `(427,355,24,24,24,24,24,24,24,355,427)` and its
already available exact weighted-row bound `S=25289/35500`. Supplying
(4) to that consumer gives (1), since

    D-S = 1203957/1136000 > 0.

The actual formal endpoint is
`AEGIS.RHIndependentElevenCompositionV1.actual_independent_eleven_coercive`.
It calls `independent_eleven_exact_coercive_of_actual_cross` after
constructing its actual cross estimates. Its result concerns exactly
these eleven fine windows and arbitrary independent legal shapes and
coefficients. No claim that every legal packet belongs to this family
is made. Canonical RH requires the unrestricted packet class; that
universal inference is not supplied by this result.

The auxiliary prime9 theorem for two arbitrary fine shapes at separation
`2 log3` is separately preserved. It gives the exact signed complex
prime term `(log3/3) X_pq(-2 log3)`, including its original conjugation,
and is not substituted for the full Weil form.
