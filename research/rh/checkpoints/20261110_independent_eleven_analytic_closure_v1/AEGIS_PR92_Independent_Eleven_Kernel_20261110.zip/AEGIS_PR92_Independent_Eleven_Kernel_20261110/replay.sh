#!/usr/bin/env bash
set -euo pipefail
if [[ "$#" != 3 ]]; then
  echo "usage: bash replay.sh LEAN_TOOLCHAIN_DIR PINNED_MATHLIB_GIT_DIR NEW_OUTPUT_DIR" >&2
  exit 2
fi
AEGIS_TOOLCHAIN=$(realpath "$1")
AEGIS_MATHLIB=$(realpath "$2")
AEGIS_OUTPUT=$(realpath -m "$3")
AEGIS_PACKET=$(cd -- "$(dirname -- "$0")" && pwd)
cd "$AEGIS_PACKET"
sha256sum --check SHA256SUMS
[[ "$("$AEGIS_TOOLCHAIN/bin/lean" --githash)" == 819816b2e0a3bf405af45ae5c7af2491d8f5bee6 ]]
[[ "$(git -C "$AEGIS_MATHLIB" rev-parse HEAD)" == 0df444a360eaa60ab8c11dca51a86af692955474 ]]
[[ ! -e "$AEGIS_OUTPUT" ]]
mkdir -- "$AEGIS_OUTPUT"
mkdir -- "$AEGIS_OUTPUT/logs" "$AEGIS_OUTPUT/lib"
AEGIS_LIBRARY_PATH="$AEGIS_OUTPUT/lib:$AEGIS_MATHLIB/.lake/build/lib/lean:$AEGIS_TOOLCHAIN/lib/lean"
for AEGIS_LIB in "$AEGIS_MATHLIB"/.lake/packages/*/.lake/build/lib/lean; do
  [[ -d "$AEGIS_LIB" ]] || continue
  AEGIS_LIBRARY_PATH="$AEGIS_LIBRARY_PATH:$AEGIS_LIB"
done
export LEAN_PATH="$AEGIS_LIBRARY_PATH"
while IFS= read -r AEGIS_MODULE; do
  [[ -n "$AEGIS_MODULE" ]] || continue
  AEGIS_RELATIVE=${AEGIS_MODULE//./\/}
  mkdir -p -- "$(dirname -- "$AEGIS_OUTPUT/lib/$AEGIS_RELATIVE.olean")"
  "$AEGIS_TOOLCHAIN/bin/lean" --trust=0 --threads=2 --memory=12288     --root="$AEGIS_PACKET/closure"     -o "$AEGIS_OUTPUT/lib/$AEGIS_RELATIVE.olean"     "$AEGIS_PACKET/closure/$AEGIS_RELATIVE.lean"     > "$AEGIS_OUTPUT/logs/${AEGIS_MODULE}.log" 2>&1
done < BUILD_ORDER.txt
"$AEGIS_TOOLCHAIN/bin/leanchecker" --verbose RHIndependentElevenCompositionV1   > "$AEGIS_OUTPUT/logs/endpoint-kernel-replay.log" 2>&1
cat "$AEGIS_OUTPUT/logs/RHIndependentElevenTypeAuditV1.log"
echo "Custom-source replay completed. This endpoint is not an unrestricted RH proof."
