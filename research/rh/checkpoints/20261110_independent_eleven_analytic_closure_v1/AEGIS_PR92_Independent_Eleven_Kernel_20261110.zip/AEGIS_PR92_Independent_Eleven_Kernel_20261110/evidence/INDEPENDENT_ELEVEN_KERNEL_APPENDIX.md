# Kernel appendix to the existing independent-eleven composition

Source context: PR92 commit `023e7239e9af3df93fe2456a3be5e7a655a2f8e3`.
This is an execution appendix to the previously written mathematical
composition, not a new mathematical discovery or an RH proof.

The existing `actual_independent_eleven_coercive` source, SHA256
`097c6100a828786151204533d79bc462a7f1551747ce687ed2a10b371bdb6ece`,
compiled successfully at Lean4.33.1 `--trust=0`, compiler
`819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, and Mathlib
`0df444a360eaa60ab8c11dca51a86af692955474`. Its actual full type is
preserved in `ACTUAL_FINAL_TYPE.txt`. The final theorem has only the
original individual fine-window and two-moment hypotheses, with arbitrary
complex coefficients; there is no mixed-bound, prime-bound, selection,
or RH premise. It supplies the mixed estimates to the existing public
`independent_eleven_exact_coercive_of_actual_cross` consumer rather than
reproving that consumer, its row certificate, or its weights.

The successful new-source logs contain23 transitive axiom probes, all with
only `propext`, `Classical.choice`, and `Quot.sound`. The custom closure has
**186 modules:162 source-closed checkpoint reuses and24 fresh successful
compiles**. The earlier child prose counts184/160 were incorrect;
`INDEPENDENT_ELEVEN_COUNT_AMENDMENT.json` records the correction. Every
original driver log and the original aggregate receipt already had the
correct186/162/24 counts and remain unchanged. Compared with the prior
Nov3 F183 plan, the current closure adds `RHDyadicWindowV13`, its imported
`RHFourBlockPrimeEightV3`, and the new final type-audit module. The Mathlib
discriminant import is external and is not included in the custom count.

Only the owned copy of `RHIndependentFineGapNineTenV1.lean` required proof
repairs: the excluded-prime cases now close separately before the existing
bounded-prime-power enumeration, and `norm_num` normalizes the casts after
the three logarithmic-power rewrites. These changes affect proof bodies
only, not theorem statements, domains, arithmetic constants, test sets,
or axioms. Its accepted SHA256 is
`08fdff51d8918619f96156631c4a881dd5172570ec7d5262290d3cab73fc7ce2`.
The original bytes and both rejected attempts are retained, and the exact
diff is `INDEPENDENT_ELEVEN_SOURCE_PATCH.diff`.

## Exact relation to the universal selected Krein producer

The final theorem quantifies over eleven independently chosen legal mothers
whose logarithmic supports lie in the same interval
`[a-1/256,a+1/256]`, then translates them by the fixed shifts
`i log(33/16)`. Therefore it proves the full signed Gram estimate for that
precise union of eleven fine windows. The existing selected Krein producer
instead quantifies over every legal original packet `g`, with no such
spatial restriction. The generic finite moment-zero reconstruction theorem
allows arbitrary numbers and positions of atoms; it does not put an
arbitrary original `g` into these eleven fixed-spaced windows or pay the
additional mixed interactions of multiple such families. Consequently F
cannot directly fill that universal input. Using F for this purpose would
require a proved, compatible reconstruction or other global transport
theorem; this appendix neither assumes one nor asserts its nonexistence
elsewhere in the corpus.

The source-compile receipt, logs, hashes and full types are in
`INDEPENDENT_ELEVEN_KERNEL_RECEIPT.json` and `independent_logs/`.
Any additional independent compiler/checker replay is recorded separately
by its owner and is not inferred from this source-compile appendix.
