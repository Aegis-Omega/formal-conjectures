#!/usr/bin/env python3
"""Bounded local AEGIS execution using existing immutable checkpoints.

No network, GitHub mutation, daemon, billing, new branch or external AI API.
Successful orchestration is separate from proof of the canonical RH target.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
CERT = BASE / 'signed_covariance_continuum_20261030'
INTERP = BASE / 'prime_variance_interpolation_20261030'
LEAN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin/lean')
SUBMISSION = Path('/workspace/aegis-rh-local-continuation-20261022/scripts/rh_submission_from_checkpoint.py')
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
OWNER_MARKER = '.aegis-local-automation-owner.json'
OWNER_SCHEMA = 'aegis.local_automation.output.v1'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(p, obj):
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def need(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def owned_output(path):
    """Recognize only this runner's explicitly marked, isolated /tmp output."""
    try:
        path = Path(path).resolve()
        if path == Path('/tmp') or not path.is_relative_to(Path('/tmp')):
            return False
        marker = json.loads((path / OWNER_MARKER).read_text())
        return marker == {'schema': OWNER_SCHEMA, 'owner': str(HERE),
                          'directory': str(path), 'uid': os.getuid()}
    except (OSError, ValueError, TypeError):
        return False


def prepare_output(path):
    path = Path(path).resolve()
    need(path != Path('/tmp') and path.is_relative_to(Path('/tmp')),
         'OUTPUT_MUST_BE_ISOLATED_UNDER_TMP')
    need(not path.exists() or path.is_dir(), 'OUTPUT_NOT_A_DIRECTORY')
    if path.exists() and any(path.iterdir()):
        need(owned_output(path), 'OUTPUT_NOT_OWNED_BY_THIS_RUNNER')
    else:
        path.mkdir(parents=True, exist_ok=True)
        write(path / OWNER_MARKER, {'schema': OWNER_SCHEMA, 'owner': str(HERE),
                                   'directory': str(path), 'uid': os.getuid()})
    return path


def verify_recorded_object(record, lean_path):
    """Check the actually selected direct cache object, not merely its pathname."""
    command = record.get('command', [])
    need('-o' in command and isinstance(record.get('object_sha256'), str),
         'CACHE_OBJECT_RECEIPT_INCOMPLETE')
    expected = Path(command[command.index('-o') + 1])
    relative = expected.name
    selected = next((Path(root) / relative for root in lean_path.split(':')
                     if (Path(root) / relative).is_file()), None)
    need(selected is not None, 'RUNTIME_CACHE_MISSING ' + relative)
    digest = sha(selected)
    need(digest == record['object_sha256'], 'RUNTIME_CACHE_OBJECT_DRIFT ' + str(selected))
    return {'path': str(selected), 'sha256': digest,
            'receipt_object_path': str(expected)}


def runtime_objects(lean_path):
    # Direct project imports and their known local dependency. This is not a
    # claim to have rehashed/replayed the entire Mathlib/transitive import DAG.
    interpolation = json.loads((INTERP / 'FINAL_RECEIPT.json').read_text())
    smooth = json.loads((BASE / 'prime_orbit_sobolev_20261030/FINAL_RECEIPT.json').read_text())
    dilation = json.loads((BASE / 'double_moment_attempt_20261030/FINAL_RECEIPT.json').read_text())
    records = [interpolation['kernel_replay'],
               smooth['accepted_modules']['PrimeOrbitSmoothV1'],
               dilation['VERIFIED']['accepted_modules']['PrimeOnlyDilationV1']]
    return [verify_recorded_object(r, lean_path) for r in records]


def integrity():
    records = []
    for parent in [CERT, BASE / 'signed_covariance_search_20261030', INTERP]:
        receipt = parent / 'FINAL_RECEIPT.json'
        data = json.loads(receipt.read_text())
        manifest = data.get('file_hashes', {})
        need(isinstance(manifest, dict) and manifest, 'SOURCE_MANIFEST_MISSING ' + str(receipt))
        companion = parent / 'FINAL_RECEIPT.sha256'
        if companion.is_file():
            need(sha(receipt) == companion.read_text().split()[0], 'RECEIPT_DRIFT ' + str(receipt))
        for name, digest in manifest.items():
            need(sha(parent / name) == digest, 'SOURCE_DRIFT ' + str(parent / name))
        records.append({'receipt': str(receipt), 'sha256': sha(receipt),
                        'verified_file_hashes': len(data.get('file_hashes', {}))})
    return records


class Runner:
    def __init__(self, out, refresh=False, lean_path=None, cache_objects=None):
        self.out = out
        self.refresh = refresh
        self.records = []
        self.env = dict(os.environ)
        self.env['LEAN_PATH'] = str(out / 'build') + ':' + (
            lean_path if lean_path is not None else (INTERP / 'LEAN_PATH').read_text().strip())
        self.identity = {'lean_sha256': sha(LEAN), 'lean_path': self.env['LEAN_PATH'],
                         'driver_sha256': sha(HERE / 'run.py'),
                         'submission_helper_sha256': sha(SUBMISSION),
                         'direct_cache_objects': runtime_objects(self.env['LEAN_PATH']) if cache_objects is None else cache_objects,
                         'cache_verification_scope': 'Listed direct objects only; inherited transitive imports are not newly replayed.',
                         'checkpoint_receipts': integrity()}

    def step(self, name, command, cwd, inputs, products, timeout=100,
             extra_env=None, fresh_outputs=(), cacheable=True):
        receipt = self.out / (name + '.json')
        log_path = self.out / (name + '.log')
        env = {**self.env, **(extra_env or {})}
        relevant = ['LEAN_PATH', 'PATH', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONHASHSEED',
                    'PYTHONOPTIMIZE', 'LD_LIBRARY_PATH', 'LANG', 'LC_ALL']
        for binding in self.identity.get('direct_cache_objects', []):
            need(Path(binding['path']).is_file() and sha(binding['path']) == binding['sha256'],
                 'RUNTIME_CACHE_CHANGED_DURING_RUN ' + binding['path'])
        requested = {str(Path(f).resolve()) for f in products}
        fingerprint = {'command': list(map(str, command)), 'inputs': {str(f): sha(f) for f in inputs},
                       'cwd': str(Path(cwd).resolve()), 'requested_products': sorted(requested),
                       'relevant_environment': {k: env.get(k) for k in relevant},
                       'explicit_environment': extra_env or {}, 'runtime': self.identity}
        if receipt.exists() and not self.refresh and cacheable:
            try:
                prior = json.loads(receipt.read_text())
            except (OSError, ValueError):
                prior = {}
            if (prior.get('fingerprint') == fingerprint and not prior.get('timed_out')
                    and prior.get('step_pass') is True and prior.get('exit_code') == 0
                    and set(prior.get('products', {})) == requested
                    and log_path.is_file() and sha(log_path) == prior.get('log_sha256')
                    and all(Path(f).is_file() and sha(f) == digest
                            for f, digest in prior['products'].items())):
                self.records.append({'step': name, 'reused_exact_execution': True,
                                     'receipt': str(receipt), 'exit_code': prior['exit_code']})
                print(name, 'REUSED_EXACT_EXECUTION', flush=True)
                return prior
        for f in fresh_outputs:
            f = Path(f).resolve()
            need(f.is_relative_to(self.out), 'FRESH_OUTPUT_OUTSIDE_OWNED_RUN')
            f.unlink(missing_ok=True)
        t = time.monotonic()
        timed_out = False
        try:
            result = subprocess.run(list(map(str, command)), cwd=cwd, env=env,
                                    capture_output=True, text=True, timeout=timeout)
            code, log = result.returncode, result.stdout + result.stderr
        except subprocess.TimeoutExpired as exc:
            code, timed_out = None, True
            log = ((exc.stdout or b'') + (exc.stderr or b'')).decode(errors='replace')
        log_path.write_text(log)
        actual_products = {str(Path(f).resolve()): sha(f) for f in products if f.is_file()}
        complete = set(actual_products) == requested
        record = {'fingerprint': fingerprint, 'cwd': str(cwd), 'exit_code': code,
                  'timed_out': timed_out, 'seconds': time.monotonic() - t,
                  'products': actual_products, 'complete_products': complete,
                  'log_sha256': sha(log_path), 'step_pass': code == 0 and complete,
                  'attempt_id': env.get('AEGIS_SEARCH_ATTEMPT_ID')}
        write(receipt, record)
        self.records.append({'step': name, 'reused_exact_execution': False,
                             'receipt': str(receipt), 'exit_code': code, 'timed_out': timed_out})
        print(name, 'EXIT', code, 'TIMEOUT', timed_out, flush=True)
        need(code != 0 or complete, 'EXPECTED_PRODUCT_MISSING ' + name)
        return record

    def lean(self, name, source, products=(), timeout=80):
        frontiers = [f for f in products if f.name == 'SEARCH_FRONTIER.json']
        extra_env = {'AEGIS_SEARCH_ATTEMPT_ID': uuid.uuid4().hex,
                     'AEGIS_SEARCH_SOURCE_SHA256': sha(source)} if frontiers else None
        return self.step(name, [LEAN, '-M5632', '-j1', '-DwarningAsError=true', source],
                         source.parent, [source, self.out / 'build/BoundedJoinSearch.olean'],
                         list(products), timeout, extra_env=extra_env,
                         fresh_outputs=frontiers, cacheable=not frontiers)


def search_status(record, frontier, source):
    """A fresh reported failed search is OPEN; execution failures are UNKNOWN."""
    bound = (isinstance(frontier, dict) and record.get('attempt_id') is not None
             and frontier.get('attempt_id') == record['attempt_id']
             and frontier.get('source_sha256') == sha(source))
    if record.get('timed_out') or not bound:
        return 'UNKNOWN_SEARCH_EXECUTION'
    if record['exit_code'] == 0 and frontier.get('status') == 'SEARCH_TERM_FOUND_REQUIRES_KERNEL_GATE':
        return 'SEARCH_TERM_FOUND_REQUIRES_KERNEL_GATE'
    if record['exit_code'] not in (None, 0) and frontier.get('status') == 'BOUNDED_SEARCH_OPEN':
        return 'BOUNDED_SEARCH_OPEN'
    return 'UNKNOWN_SEARCH_EXECUTION'


def load_gate_helpers():
    spec = importlib.util.spec_from_file_location('existing_submission_gate', SUBMISSION)
    module = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = old
    return module


def candidate_gate(runner, path, declaration, label='Candidate'):
    """Check an actual closed RH term, including inferred proof dependencies."""
    helper = load_gate_helpers()
    work = runner.out / label
    work.mkdir(exist_ok=True)
    (work / 'Candidate.lean').write_bytes(path.read_bytes())
    obj = work / 'Candidate.olean'
    first = runner.step(label + '_build',
        [LEAN, '-M5632', '-j1', '-DwarningAsError=true', '-o', obj, 'Candidate.lean'],
        work, [work / 'Candidate.lean'], [obj])
    if first['exit_code'] != 0:
        return {'status': 'UNKNOWN_BUILD_FAILED', 'candidate_sha256': sha(path)}
    # Reuse the existing canonical direct-application probe, naming its root so
    # inferred implicit/instance arguments are included in the final axiom audit.
    probe = helper.make_probe('Candidate', declaration)
    root = 'AEGIS.AutomationGate.closedRH'
    probe = probe.replace('example :', 'theorem ' + root + ' :')
    probe += '#print axioms ' + root + '\n'
    f = work / 'CanonicalGate.lean'
    f.write_text(probe)
    old = runner.env['LEAN_PATH']
    runner.env['LEAN_PATH'] = str(work) + ':' + old
    try:
        result = runner.lean(label + '_canonical_gate', f)
    finally:
        runner.env['LEAN_PATH'] = old
    log = (runner.out / (label + '_canonical_gate.log')).read_text()
    axes = helper.audited_axioms(log, root)
    accepted = result['exit_code'] == 0 and axes is not None and axes <= ALLOWED
    if accepted:
        status = 'CANONICAL_RH_KERNEL_AND_AXIOM_PASS'
    elif result.get('timed_out') or result['exit_code'] is None:
        status = 'UNKNOWN_CANONICAL_GATE_EXECUTION'
    elif result['exit_code'] != 0:
        status = ('REJECTED_OR_OPEN' if 'type mismatch' in log.lower()
                  else 'UNKNOWN_CANONICAL_GATE_EXECUTION')
    elif axes is None:
        status = 'UNKNOWN_CANONICAL_AXIOM_AUDIT'
    else:
        status = 'REJECTED_AXIOMS'
    return {'status': status,
            'candidate': str(path), 'candidate_sha256': sha(path),
            'declaration': declaration, 'exact_canonical_type_checked': result['exit_code'] == 0,
            'axioms': sorted(axes) if axes is not None else None,
            'canonical_RH_closed': accepted}


def run(args):
    out = prepare_output(args.out)
    (out / 'build').mkdir(exist_ok=True)
    runner = Runner(out, args.recompute)
    write(out / 'INPUT_STATE.json', runner.identity)
    work = out / 'continuum'
    work.mkdir(exist_ok=True)
    names = ['rational_core.py', 'covariance_engine.py', 'certify_continuum.py',
             'check_positive_envelope.py', 'generate_lean.py', 'RATIONAL_ETA_STEPS_512.json']
    for name in names:
        (work / name).write_bytes((CERT / name).read_bytes())
    if args.recompute:
        for name, script, output in [('signed_continuum', 'certify_continuum.py', 'CONTINUUM_CERTIFICATE.json'),
                                     ('positive_continuum', 'check_positive_envelope.py', 'SECOND_CONTINUUM_CHECK.json')]:
            r = runner.step(name, [sys.executable, '-O', '-u', work / script], work,
                            [work / n for n in names], [work / output], timeout=100)
            need(r['exit_code'] == 0, name + '_EXECUTION_FAILED')
    else:
        reused = runner.step('reuse_previous_evidence',
            [sys.executable, '-B', '-O', CERT / 'check_evidence.py'], CERT,
            [CERT / n for n in ['check_evidence.py', 'FINAL_RECEIPT.json',
                                'CONTINUUM_CERTIFICATE.json', 'SECOND_CONTINUUM_CHECK.json']], [])
        need(reused['step_pass'], 'PREVIOUS_EVIDENCE_VALIDATION_FAILED')
        for name in ['CONTINUUM_CERTIFICATE.json', 'SECOND_CONTINUUM_CHECK.json']:
            (work / name).write_bytes((CERT / name).read_bytes())
    r = runner.step('generate_scalar_checks', [sys.executable, work / 'generate_lean.py'], work,
        [work / 'generate_lean.py', work / 'CONTINUUM_CERTIFICATE.json', work / 'SECOND_CONTINUUM_CHECK.json'],
        [work / 'ContinuumScalarChecksV1.lean'])
    need(r['exit_code'] == 0, 'SCALAR_GENERATION_FAILED')
    # Scalar replay does not need the search engine object.
    r = runner.step('scalar_kernel', [LEAN, '-M5632', '-j1', '-DwarningAsError=true',
         work / 'ContinuumScalarChecksV1.lean'], work, [work / 'ContinuumScalarChecksV1.lean'],
         [work / 'ContinuumScalarChecksV1.lean'])
    helper = load_gate_helpers()
    scalar_log = (out / 'scalar_kernel.log').read_text()
    for n in ['signedBudgets', 'positiveBudgets', 'signedParameterCover']:
        axes = helper.audited_axioms(scalar_log, 'AEGIS.ContinuumScalarChecksV1.' + n)
        need(r['exit_code'] == 0 and axes is not None and axes <= ALLOWED, 'SCALAR_AXIOM_CHECK_FAILED')
    obj = out / 'build/BoundedJoinSearch.olean'
    r = runner.step('search_engine', [LEAN, '-M5632', '-j1', '-DwarningAsError=true', '-o', obj,
        HERE / 'BoundedJoinSearch.lean'], HERE, [HERE / 'BoundedJoinSearch.lean'], [obj])
    need(r['exit_code'] == 0, 'SEARCH_ENGINE_BUILD_FAILED')
    searches = []
    for label, target, expected in [('PositiveControl', 'True', True),
                                     ('FalseControl', 'False', False),
                                     ('CanonicalSearch', '_root_.RiemannHypothesis', None)]:
        folder = out / label
        folder.mkdir(exist_ok=True)
        source = folder / (label + '.lean')
        source.write_text('import BoundedJoinSearch\nset_option maxHeartbeats 4000000\n'
            'theorem AEGIS.AutomationAttempt.result : ' + target + ' := by\n  aegis_bounded_join\n'
            '#print axioms AEGIS.AutomationAttempt.result\n')
        r = runner.lean(label, source, [folder / 'SEARCH_FRONTIER.json'], timeout=100)
        frontier_path = folder / 'SEARCH_FRONTIER.json'
        try:
            frontier = json.loads(frontier_path.read_text()) if frontier_path.is_file() else None
        except (OSError, ValueError):
            frontier = None
        classification = search_status(r, frontier, source)
        if expected is True:
            axes = helper.audited_axioms((out / (label + '.log')).read_text(),
                                         'AEGIS.AutomationAttempt.result')
            need(classification == 'SEARCH_TERM_FOUND_REQUIRES_KERNEL_GATE'
                 and axes is not None and axes <= ALLOWED, 'POSITIVE_SEARCH_CONTROL_FAILED')
        elif expected is False:
            need(classification == 'BOUNDED_SEARCH_OPEN', 'NEGATIVE_SEARCH_CONTROL_FAILED_OR_UNKNOWN')
        searches.append({'label': label, 'exit_code': r['exit_code'], 'frontier': frontier,
                         'classification': classification,
                         'mathematical_nonexistence_proved': False})
    closure = {'status': searches[-1]['classification'], 'canonical_RH_closed': False}
    if searches[-1]['classification'] == 'SEARCH_TERM_FOUND_REQUIRES_KERNEL_GATE':
        closure = candidate_gate(runner, out / 'CanonicalSearch/CanonicalSearch.lean',
                                 'AEGIS.AutomationAttempt.result', 'FoundProof')
    if args.candidate:
        need(args.declaration is not None, 'CANDIDATE_DECLARATION_REQUIRED')
        closure = candidate_gate(runner, Path(args.candidate).resolve(), args.declaration)
    # Conditional RH cannot pass the unconditional canonical gate.
    conditional = out / 'ConditionalControl.lean'
    conditional.write_text('import WeilRHImpliesFinalSignV13\n'
        'theorem conditional (h : _root_.RiemannHypothesis) : _root_.RiemannHypothesis := h\n')
    bad = candidate_gate(runner, conditional, 'conditional', 'ConditionalControl')
    need(bad['status'] == 'REJECTED_OR_OPEN' and not bad.get('canonical_RH_closed'),
         'CONDITIONAL_CONTROL_FAILED_OR_UNKNOWN')
    final_state = integrity()
    need(final_state == runner.identity['checkpoint_receipts'], 'CHECKPOINT_CHANGED_DURING_RUN')
    result = {'status': 'CANONICAL_RH_KERNEL_AND_AXIOM_PASS' if closure.get('canonical_RH_closed')
              else ('AUTOMATION_EXECUTED_RH_STATUS_UNKNOWN'
                    if closure['status'].startswith('UNKNOWN') else 'AUTOMATION_EXECUTED_RH_OPEN'),
              'pipeline_executed': True, 'canonical_RH_closed': closure.get('canonical_RH_closed', False),
              'checkpoint_integrity': final_state, 'steps': runner.records, 'searches': searches,
              'closure_gate': closure, 'conditional_negative_control': bad,
              'OPEN': ['Universal all-T arithmetic covariance bound for each fixed canonical n.',
                       'Full Lean integral enclosure and variance interpolation, beyond scalar checks.'],
              'UNKNOWN': ['Proofs outside the actually imported and bounded-search environment.'],
              'global_mathematical_absence_claim': False,
              'existing_sources_modified': False, 'network_calls': 0, 'CI_invocations': 0,
              'source_hashes': {f.name: sha(f) for f in [HERE / 'run.py', HERE / 'BoundedJoinSearch.lean', SUBMISSION]}}
    write(out / 'AUTOMATION_RESULT.json', result)
    print(result['status'], flush=True)
    print('RESULT', out / 'AUTOMATION_RESULT.json', flush=True)
    return 0  # orchestration success, never implicitly mathematical closure


def run_discovery(args):
    """Execute the new structural experiment in the existing runner.

    Reuse the preserved continuum evidence without regenerating known expensive
    certificates. Recompile the exact Krein base and the genuinely new theorem.
    """
    checkpoint = Path(args.discovery_checkpoint).resolve()
    out = prepare_output(args.out)
    (out / 'build').mkdir(exist_ok=True)
    lp = (checkpoint / 'LEAN_PATH').read_text().strip()
    inherited = []
    for module in ['RHKreinFactorV13', 'WeilCriterionCompactSmoothV1', 'WeilWindowExhaustionV1']:
        obj = next((Path(d) / (module + '.olean') for d in lp.split(':')
                    if (Path(d) / (module + '.olean')).is_file()), None)
        need(obj is not None, 'UNKNOWN_INHERITED_RUNTIME_MISSING ' + module)
        shadow = out / 'build' / (module + '.olean')
        need(not shadow.exists() or sha(shadow) == sha(obj),
             'INHERITED_RUNTIME_SHADOW_DRIFT ' + str(shadow))
        if shadow.is_file():
            obj = shadow
        inherited.append({'path': str(obj), 'sha256': sha(obj)})
    runner = Runner(out, args.recompute, lean_path=lp, cache_objects=inherited)
    work = out / 'discovery'
    work.mkdir(exist_ok=True)
    names = ['discover_transport.py', 'RHLocalKreinPartitionV1.lean', 'KreinLogScaleTransportV1.lean']
    for name in names:
        (work / name).write_bytes((checkpoint / name).read_bytes())
    original_hashes = {name: sha(work / name) for name in names}
    need(all(sha(checkpoint / n) == h for n, h in original_hashes.items()), 'COPY_SOURCE_DRIFT')
    external = json.loads((checkpoint / 'DISCOVERY_RESULT.json').read_text())['source_bindings']
    for binding in external:
        need(sha(binding['path']) == binding['sha256'], 'DISCOVERY_EXTERNAL_SOURCE_DRIFT ' + binding['path'])
    previous_check = runner.step('reuse_previous_evidence',
        [sys.executable, '-B', '-O', CERT / 'check_evidence.py'], CERT,
        [CERT / n for n in ['check_evidence.py', 'FINAL_RECEIPT.json',
                            'CONTINUUM_CERTIFICATE.json', 'SECOND_CONTINUUM_CHECK.json']], [])
    need(previous_check['step_pass'], 'PREVIOUS_EVIDENCE_VALIDATION_FAILED')
    result = runner.step('structural_discovery',
        [sys.executable, '-B', '-O', work / 'discover_transport.py'], work,
        [work / 'discover_transport.py'] + [Path(x['path']) for x in external], [work / 'DISCOVERY_RESULT.json'])
    need(result['step_pass'], 'STRUCTURAL_DISCOVERY_FAILED')
    helper = load_gate_helpers()
    audits = {}
    for module, roots in [
        ('RHLocalKreinPartitionV1', ['kreinAtom_support', 'kreinAtom_moments']),
        ('KreinLogScaleTransportV1', ['second_deriv_logScale', 'kreinAtom_logScale',
         'raw_path_discrepancy', 'corrected_scale_identity', 'corrected_scale_moments',
         'corrected_scale_support', 'factor_scale_composition'])]:
        source = work / (module + '.lean')
        obj = out / 'build' / (module + '.olean')
        inputs = [source]
        if module == 'KreinLogScaleTransportV1':
            inputs.append(out / 'build/RHLocalKreinPartitionV1.olean')
        record = runner.step(module,
            [LEAN, '-M5632', '-j1', '-DwarningAsError=true', '-o', obj, source],
            work, inputs, [obj])
        need(record['step_pass'], 'DISCOVERY_KERNEL_EXECUTION_FAILED ' + module)
        log = (out / (module + '.log')).read_text()
        for root in roots:
            name = 'AEGIS.' + module + '.' + root
            axes = helper.audited_axioms(log, name)
            need(axes is not None and axes <= ALLOWED, 'DISCOVERY_AXIOM_AUDIT_FAILED ' + name)
            audits[name] = sorted(axes)
    result = {'status': 'DISCOVERY_EXECUTED_KERNEL_TRANSPORT_VERIFIED_RH_OPEN',
        'mode': 'structural_discovery', 'checkpoint': str(checkpoint),
        'driver_sha256': sha(HERE / 'run.py'), 'steps': runner.records,
        'new_kernel_roots': {n: a for n, a in audits.items() if '.KreinLogScaleTransportV1.' in n},
        'discovery_result': str(work / 'DISCOVERY_RESULT.json'),
        'discovery_result_sha256': sha(work / 'DISCOVERY_RESULT.json'),
        'source_hashes': original_hashes, 'runtime_identity': runner.identity,
        'external_source_bindings': external,
        'scope': 'Exact coefficient experiments plus general actual Krein-operator and moment theorems.',
        'full_smooth_counterexample_kernel_verified': False,
        'full_Weil_form_transport_kernel_verified': False,
        'universal_RH_obligations_eliminated': 0, 'canonical_RH_closed': False,
        'OPEN': ['Control the actual complete Weil quadratic defect of corrected scaling.',
                 'Kernel-formalize the explicit smooth bump witness and full spectral defect.'],
        'remote_writes': False, 'expensive_continuum_regenerations': 0}
    need(integrity() == runner.identity['checkpoint_receipts'], 'PREVIOUS_CHECKPOINT_DRIFT')
    need(all(sha(checkpoint / n) == d for n, d in original_hashes.items()), 'DISCOVERY_SOURCE_DRIFT')
    need(all(sha(x['path']) == x['sha256'] for x in external), 'DISCOVERY_EXTERNAL_SOURCE_CHANGED_DURING_RUN')
    graph_source = checkpoint / 'RESEARCH_KNOWLEDGE_GRAPH.json'
    if graph_source.is_file():
        graph = json.loads(graph_source.read_text())
        graph['parent_state_sha256'] = sha(graph_source)
        graph['version'] = graph.get('version', 0) + 1
        graph['execution_evidence'] = {
            'driver_sha256': sha(HERE / 'run.py'),
            'new_kernel_roots': result['new_kernel_roots'],
            'discovery_result_sha256': result['discovery_result_sha256'],
            'step_receipts': runner.records,
            'canonical_RH_closed_by_this_execution': False}
        write(out / 'RESEARCH_KNOWLEDGE_GRAPH.json', graph)
        result['executed_knowledge_graph'] = str(out / 'RESEARCH_KNOWLEDGE_GRAPH.json')
        result['executed_knowledge_graph_sha256'] = sha(out / 'RESEARCH_KNOWLEDGE_GRAPH.json')
    write(out / 'AUTOMATION_RESULT.json', result)
    print(result['status'], flush=True)
    print('RESULT', out / 'AUTOMATION_RESULT.json', flush=True)
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', default='/tmp/aegis-rh-local-automation-20261030/execution')
    ap.add_argument('--recompute', action='store_true', help='Do not reuse matching successful executions')
    ap.add_argument('--candidate', help='Optional local Lean source to compile and check against canonical RH')
    ap.add_argument('--declaration', help='Fully qualified candidate theorem name')
    ap.add_argument('--discovery-checkpoint', help='Execute a source-bound structural experiment and its Lean transport theorem; reuse old certificates')
    args = ap.parse_args()
    try:
        return run_discovery(args) if args.discovery_checkpoint else run(args)
    except Exception as exc:
        out = Path(args.out)
        if owned_output(out):
            write(out / 'AUTOMATION_ERROR.json', {'status': 'EXECUTION_FAILED_OR_UNKNOWN', 'error': str(exc),
                                                 'canonical_RH_closed': False})
        print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
