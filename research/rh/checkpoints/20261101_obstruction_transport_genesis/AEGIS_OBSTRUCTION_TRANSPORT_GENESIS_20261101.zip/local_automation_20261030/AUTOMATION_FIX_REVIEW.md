# Minimal fixes to the unfinished local runner

The old whole-process run is not claimed complete. Its `/tmp` runtime and
outputs disappeared across the environment reset. These changes repair the
existing driver and search metaprogram; they do not add a new proof engine or
assert an RH result.

## Implemented

- Output is restricted to an isolated directory under `/tmp`. A nonempty
  directory must contain this runner's exact owner marker. Error handling
  writes a receipt only into a recognized owned directory.
- A cached step must have the same command, cwd, relevant execution environment,
  input hashes, runtime identity, complete requested-product set, output hashes,
  and actual stdout/stderr log hash. Exit zero with a missing product is a
  failed step. Existing source receipts are checked before and after a run.
- Three direct project `.olean` dependencies are matched against their existing
  object receipts. The object actually selected by `LEAN_PATH` is checked, so
  a shadowing different object is rejected. Missing caches are execution
  blockers, not new mathematical gaps. This check is explicitly narrower than
  a new replay/hash audit of the entire transitive Mathlib import environment.
- Each proof-search attempt has a fresh ID and source hash, exported by the
  Lean tactic. The old frontier is removed before execution. Missing, stale,
  malformed, mismatched, or timed-out frontiers produce `UNKNOWN`, rather
  than being reported as a completed unsuccessful mathematical search.
- The final gate still compiles a named theorem whose type is exactly
  `_root_.RiemannHypothesis`, then audits that wrapper's own dependencies.
  A clean audit printed for some other declaration is insufficient. Timeouts
  and missing audits remain `UNKNOWN`; forbidden axioms are rejected.
- The Lean search pool now stores theorem names/directions. Every application
  gets fresh universe metavariables. Repeated-goal detection distinguishes
  local contexts, and the existing finite search bounds remain in place.
- Loading the existing submission helper does not write Python bytecode into
  the older checkpoint directory.

## Executed verification

Command:

```sh
python -B -O /workspace/aegis-rh-next-local-20261028/local_automation_20261030/test_automation.py
```

Ten lightweight stdlib regression tests passed, exit code 0. They cover stale
frontier rejection, attempt/source/time binding, log tampering, complete
products, cwd/environment cache invalidation, object shadowing/hash mismatch,
unsafe output rejection, scoped exception writes, and canonical-gate policy.
The gate tests deliberately mock compiler output; they verify runner policy
and generated probe text, not any theorem or RH proof. The tests do not run
Lean, the covariance certifiers, or GitHub Actions. Assertions in the tests
use unittest methods and remain active under `python -O`.

## OPEN / UNKNOWN

The modified `BoundedJoinSearch.lean` has not been compiled in this repair
step. Its prior `SEARCH_ENGINE_BUILD.json` refers to the earlier source hash
and must not be treated as verification of this version. A root-owned targeted
Lean compile is still required before claiming build success for it.

Full old-search mode still requires its receipt-bound runtime objects.
The root agent's new concrete obstruction-transport discovery can be connected
as a separate mode without replaying the old expensive certifiers. No such
discovery mode is introduced by this bounded repair.
