import PrimeOrbitAllDerivativesV1
import WeilRHImpliesFinalSignV13
import Mathlib.Tactic
import Lean.Util.CollectAxioms

/-! Bounded composition of imported, axiom-audited theorem terms.
This is proof search, not an assertion that the target has been proved.
The search implementation is metaprogramming; every produced theorem still
has to elaborate and pass the separate canonical-type and axiom gate.
-/

open Lean Meta Elab Tactic

namespace AEGIS.BoundedJoinSearch

private def permitted (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

private partial def lastHead : Expr → Name
  | .forallE _ _ b _ => lastHead b
  | e => e.getAppFn.constName?.getD Name.anonymous

private structure SearchEntry where
  name : Name
  direction : Nat
  head : Name

private def makePool : MetaM (Array SearchEntry) := do
  let env ← getEnv
  let mut pool : Array SearchEntry := #[⟨``True.intro, 0, ``True⟩]
  let entries := env.constants.toList.toArray.qsort
    (fun a b => a.1.toString < b.1.toString)
  for (n, ci) in entries do
    if n.toString.startsWith "AEGIS." && !n.toString.startsWith "AEGIS.BoundedJoinSearch." then
      if let .thmInfo _ := ci then
        let axs ← collectAxioms n
        if axs.all permitted then
          pool := pool.push ⟨n, 0, lastHead ci.type⟩
          -- Closed iff theorems also provide two actual implication terms.
          if ci.type.isAppOfArity ``Iff 2 then
            pool := pool.push ⟨n, 1, lastHead ci.type.appArg!⟩
            pool := pool.push ⟨n, 2, lastHead ci.type.appFn!.appArg!⟩
  return pool

private def freshTerm (name : Name) (direction : Nat) : MetaM Expr := do
  let term ← mkConstWithFreshMVarLevels name
  match direction with
  | 1 => mkAppM ``Iff.mp #[term]
  | 2 => mkAppM ``Iff.mpr #[term]
  | _ => pure term

private partial def search (goal : MVarId) (pool : Array SearchEntry)
    (fuel : Nat) (remaining : IO.Ref Nat) (trace : IO.Ref (Array Json))
    (ancestors : List (Expr × Array FVarId) := []) : MetaM Bool := do
  if ← goal.isAssigned then return true
  let budget ← remaining.get
  if budget == 0 then return false
  remaining.set (budget - 1)
  goal.withContext do
    let ty ← instantiateMVars (← goal.getType)
    let context := (← getLCtx).getFVarIds
    -- Raw expression output does not normalize huge certificate numerals merely
    -- to display a failed branch. The source-bound expression remains recorded.
    let goalText := toString ty
    trace.modify (·.push (Json.mkObj [
      ("goal", toJson goalText), ("depth_remaining", toJson fuel)]))
    try
      withTransparency .reducible goal.assumption
      return true
    catch _ => pure ()
    -- Equal formulas in a genuinely extended local context are distinct states.
    if ancestors.any (fun old => old.1 == ty && old.2 == context) then return false
    if fuel == 0 then return false
    -- Introducing quantified variables does not turn them into global facts.
    if ty.isForall then
      let saved ← saveState
      try
        let (_, child) ← goal.intro1P
        if ← search child pool (fuel - 1) remaining trace ((ty, context) :: ancestors) then return true
      catch _ => pure ()
      saved.restore
    let head := lastHead ty
    for entry in pool do
      if (← remaining.get) == 0 then break
      -- Inspect the theorem's stored conclusion before instantiating its term.
      -- Irrelevant arithmetic certificates must never be normalized by infer/apply.
      if entry.head != head then continue
      let saved ← saveState
      try
        -- Fresh universe metavariables for each application, including siblings.
        let term ← withTransparency .reducible <| freshTerm entry.name entry.direction
        let termTy ← withTransparency .reducible <| inferType term
        if lastHead termTy == head then
          let children ← withTransparency .reducible <| goal.apply term
          let mut ok := true
          for child in children do
            if !(← search child pool (fuel - 1) remaining trace ((ty, context) :: ancestors)) then
              ok := false
              break
          if ok then
            trace.modify (·.push (Json.mkObj [("applied", toJson entry.name.toString)]))
            return true
      catch _ => pure ()
      saved.restore
    return false

elab "aegis_bounded_join" : tactic => liftMetaTactic fun goal => do
  let pool ← makePool
  let remaining ← IO.mkRef 192
  let trace ← IO.mkRef #[]
  let solved ← search goal pool 5 remaining trace
  let attemptId ← IO.getEnv "AEGIS_SEARCH_ATTEMPT_ID"
  let sourceHash ← IO.getEnv "AEGIS_SEARCH_SOURCE_SHA256"
  let record := Json.mkObj [
    ("attempt_id", toJson attemptId), ("source_sha256", toJson sourceHash),
    ("status", toJson (if solved then "SEARCH_TERM_FOUND_REQUIRES_KERNEL_GATE" else "BOUNDED_SEARCH_OPEN")),
    ("pool_terms", toJson pool.size), ("node_budget", toJson (192 : Nat)),
    ("depth_budget", toJson (5 : Nat)), ("nodes_remaining", toJson (← remaining.get)),
    ("scope", toJson "Imported AEGIS theorem terms with only standard axioms, static exact conclusion-head prefilter, reducible application, and closed iff directions. Not exhaustive proof search."),
    ("trace", Json.arr (← trace.get))]
  IO.FS.writeFile "SEARCH_FRONTIER.json" record.pretty
  if solved then return []
  throwError "AEGIS_BOUNDED_SEARCH_OPEN: no composition found within the recorded scope and budget"

end AEGIS.BoundedJoinSearch
