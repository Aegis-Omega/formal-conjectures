"""Lightweight runner regression tests. No Lean or analytic certifier executes.

Gate tests use deliberately mocked compiler output. They test acceptance
policy and exact generated probes, not mathematical proof verification.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.dont_write_bytecode = True
SPEC = importlib.util.spec_from_file_location('local_automation', Path(__file__).with_name('run.py'))
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='aegis-runner-test-', dir='/tmp')
        self.path = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def fake_runner(self):
        r = runner.Runner.__new__(runner.Runner)
        r.out = self.path
        r.refresh = False
        r.records = []
        r.identity = {'test_runtime': True, 'direct_cache_objects': []}
        r.env = dict(os.environ)
        return r

    def test_output_rejects_workspace_root_and_unowned_directory(self):
        with self.assertRaisesRegex(RuntimeError, 'UNDER_TMP'):
            runner.prepare_output('/workspace')
        (self.path / 'existing-proof.txt').write_text('preserve')
        with self.assertRaisesRegex(RuntimeError, 'NOT_OWNED'):
            runner.prepare_output(self.path)
        self.assertEqual((self.path / 'existing-proof.txt').read_text(), 'preserve')
        self.assertFalse((self.path / runner.OWNER_MARKER).exists())

    def test_owned_empty_output_is_resumable(self):
        p = self.path / 'owned'
        self.assertEqual(runner.prepare_output(p), p)
        self.assertTrue(runner.owned_output(p))
        self.assertEqual(runner.prepare_output(p), p)

    def test_exception_never_writes_into_unowned_output(self):
        (self.path / 'old-checkpoint').write_text('keep')
        argv = ['run.py', '--out', str(self.path)]
        with mock.patch.object(sys, 'argv', argv):
            self.assertEqual(runner.main(), 1)
        self.assertFalse((self.path / 'AUTOMATION_ERROR.json').exists())

    def test_stale_frontier_is_deleted_before_failed_attempt(self):
        r = self.fake_runner()
        frontier = self.path / 'SEARCH_FRONTIER.json'
        frontier.write_text('{"status":"BOUNDED_SEARCH_OPEN","attempt_id":"old"}')
        record = r.step('failed', [sys.executable, '-c', 'raise SystemExit(2)'],
                        self.path, [], [frontier], fresh_outputs=[frontier], cacheable=False)
        self.assertFalse(frontier.exists())
        self.assertEqual(record['exit_code'], 2)
        self.assertEqual(runner.search_status(record, None, self.path / 'absent'),
                         'UNKNOWN_SEARCH_EXECUTION')

    def test_search_frontier_must_match_attempt_source_and_execution(self):
        source = self.path / 'source.lean'
        source.write_text('example : True := True.intro\n')
        record = {'attempt_id': 'current', 'exit_code': 1, 'timed_out': False}
        frontier = {'status': 'BOUNDED_SEARCH_OPEN', 'attempt_id': 'old',
                    'source_sha256': runner.sha(source)}
        self.assertEqual(runner.search_status(record, frontier, source), 'UNKNOWN_SEARCH_EXECUTION')
        frontier['attempt_id'] = 'current'
        self.assertEqual(runner.search_status(record, frontier, source), 'BOUNDED_SEARCH_OPEN')
        record['timed_out'] = True
        self.assertEqual(runner.search_status(record, frontier, source), 'UNKNOWN_SEARCH_EXECUTION')

    def test_cache_reuse_requires_untampered_log_all_products_cwd_and_env(self):
        r = self.fake_runner()
        product = self.path / 'product.txt'
        command = [sys.executable, '-c', "from pathlib import Path; Path('product.txt').write_text('ok'); print('actual output')"]
        r.step('cache', command, self.path, [], [product])
        r.step('cache', command, self.path, [], [product])
        self.assertTrue(r.records[-1]['reused_exact_execution'])
        (self.path / 'cache.log').write_text('forged axiom output')
        r.step('cache', command, self.path, [], [product])
        self.assertFalse(r.records[-1]['reused_exact_execution'])
        self.assertIn('actual output', (self.path / 'cache.log').read_text())
        r.env['LEAN_PATH'] = '/tmp/different-cache'
        r.step('cache', command, self.path, [], [product])
        self.assertFalse(r.records[-1]['reused_exact_execution'])
        cwd2 = self.path / 'cwd2'
        cwd2.mkdir()
        r.step('cache', command, cwd2, [], [product])
        self.assertFalse(r.records[-1]['reused_exact_execution'])
        with self.assertRaisesRegex(RuntimeError, 'PRODUCT_MISSING'):
            r.step('missing', [sys.executable, '-c', 'pass'], self.path, [],
                   [self.path / 'not-produced'])

    def test_recorded_object_hash_and_shadowed_module_are_checked(self):
        first = self.path / 'first'
        second = self.path / 'second'
        first.mkdir()
        second.mkdir()
        obj = second / 'Example.olean'
        obj.write_bytes(b'receipt-bound-object')
        record = {'command': ['lean', '-o', str(obj)], 'object_sha256': runner.sha(obj)}
        paths = str(first) + ':' + str(second)
        self.assertEqual(runner.verify_recorded_object(record, paths)['path'], str(obj))
        (first / 'Example.olean').write_bytes(b'shadowed-different-object')
        with self.assertRaisesRegex(RuntimeError, 'OBJECT_DRIFT'):
            runner.verify_recorded_object(record, paths)
        with self.assertRaisesRegex(RuntimeError, 'CACHE_MISSING'):
            runner.verify_recorded_object(record, str(self.path / 'missing-cache'))

    def gate(self, log, code=0, timed_out=False):
        source = self.path / 'input.lean'
        source.write_text('import WeilRHImpliesFinalSignV13\n')
        out = self.path
        case = self

        class Fake:
            def __init__(self):
                self.out = out
                self.env = {'LEAN_PATH': 'inherited'}

            def step(self, *args, **kwargs):
                return {'exit_code': 0}

            def lean(self, name, path):
                probe = path.read_text()
                case.assertIn('theorem AEGIS.AutomationGate.closedRH : _root_.RiemannHypothesis := candidate', probe)
                case.assertIn('#print axioms AEGIS.AutomationGate.closedRH', probe)
                (out / (name + '.log')).write_text(log)
                return {'exit_code': code, 'timed_out': timed_out}

        return runner.candidate_gate(Fake(), source, 'candidate')

    def test_canonical_gate_requires_wrapper_audit_not_only_candidate_log(self):
        candidate_only = "'candidate' does not depend on any axioms\n"
        result = self.gate(candidate_only)
        self.assertFalse(result['canonical_RH_closed'])
        self.assertEqual(result['status'], 'UNKNOWN_CANONICAL_AXIOM_AUDIT')

    def test_canonical_gate_rejects_placeholder_type_failure_and_timeout(self):
        root = 'AEGIS.AutomationGate.closedRH'
        bad = self.gate("'" + root + "' depends on axioms: [sorryAx]\n")
        self.assertFalse(bad['canonical_RH_closed'])
        self.assertEqual(bad['status'], 'REJECTED_AXIOMS')
        failed = self.gate('error: Type mismatch\n', code=1)
        self.assertEqual(failed['status'], 'REJECTED_OR_OPEN')
        self.assertFalse(failed['canonical_RH_closed'])
        timeout = self.gate('', code=None, timed_out=True)
        self.assertEqual(timeout['status'], 'UNKNOWN_CANONICAL_GATE_EXECUTION')
        self.assertFalse(timeout['canonical_RH_closed'])

    def test_mocked_positive_acceptance_policy_is_retained(self):
        result = self.gate("'AEGIS.AutomationGate.closedRH' depends on axioms: [propext, Classical.choice, Quot.sound]\n")
        self.assertTrue(result['canonical_RH_closed'])
        # This is a mock-policy assertion, never an actual proof of RH.


if __name__ == '__main__':
    unittest.main(verbosity=2)
