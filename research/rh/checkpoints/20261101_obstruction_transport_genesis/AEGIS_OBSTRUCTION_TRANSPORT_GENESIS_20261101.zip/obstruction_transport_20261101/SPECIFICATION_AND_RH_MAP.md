# AEGIS obstruction transport: first concrete result

This checkpoint implements the first bounded assignment in the supplied
Mathematical Genesis Engine brief. It is an extension of the existing local
AEGIS work, not a new repository or independent numerical certificate engine.
The first result is a compatibility obstruction and an exact corrected
transport. No historical novelty or new branch of mathematics is claimed.

## Recovered state

The inspected local formal-conjectures HEAD is
`309ca3fa117fa499761f58f64ac371ccd1ff2f63`. The local checkpoint includes newer
isolated proof files; they are not asserted to belong to this Git HEAD.
The remote PR #92 head was not refreshed in this step, so its present
implementation status is UNKNOWN here. SHA256 source identities, rather than
old PR descriptions, bind the statements used below.

The existing results already supply the expensive foundations:

* `RHKreinFactorV13.moment_zero_parametrization`: a compact-support-preserving
  differential factor for both exponential moments.
* `RHLocalKreinPartitionV1.kreinAtom`, `kreinAtom_moments`,
  `kreinAtom_mul`, and `kreinAtom_partition_two`: the actual differential
  convention, moments, cutoff commutator and exact local reconstruction.
* `RHKreinMultiplicativeTransportV1.every_moment_zero_packet_finite_actual_weil_partition`:
  finite decomposition in the actual multiplicative Weil carrier.
* `RHKreinFourierFactorV1.actual_packet_fourier_factor`: the squared angular
  multiplier `(t²+1/4)²` for that same factorization.
* `CvSWindowL118V1.window_L118`: positivity of the full actual form for both
  moment conditions and support width at most 11/8.
* `RHWindowL118ExhaustionV1.rh_iff_windows_above_eleven_sixteenths`:
  the exact wider-window obligation, not its solution.

The factorization and cutoff commutator are existing work, not discoveries
of this checkpoint. Previous receipts and proofs have not been edited.

## Spaces and typed paths

Let V be complex smooth compactly supported functions on the log line.
Let W0 be its subspace with
`M_±(G)=integral exp(±x/2)G(x) dx=0`.
The actual multiplicative carrier is obtained through the existing log lift
`G(t)=exp(t/2)g(exp t)` and its inverse on x>0.

Use the existing operator A=deriv²-1/4, so A=-D0 in the brief's notation.
The scale parameter convention in the Lean file is compression:

    L_s f(x)=f(s*x), s>0.

The symbolic script uses expansion R_s f(x)=f(x/s), hence R_s=L_(1/s).
These are two parameter conventions for the same maps, not conflicting
identities. The diagrams have source V and target V:

    path 1: φ -> L_s φ -> A(L_s φ);
    path 2: φ -> Aφ    -> L_s(Aφ).

Both paths preserve smoothness and compact support, but only the first
always lands in W0. Their exact difference is

    A(L_s φ)-L_s(Aφ)=(s²-1)L_s(φ'').

An equivalent formula gives the useful corrected transport:

    A(L_s φ)=s² L_s(Aφ)+(s²-1)L_s φ/4.

`KreinLogScaleTransportV1` proves these identities, the corrected moments,
support inclusion, and scale composition on factors in Lean, using the
existing `kreinAtom` definition. The parameter-dependent correction is
derived by the chain rule, not fitted to numerical data.

No single-valued inverse A^-1 is newly postulated. The Lean theorem is
explicitly parametrized by an actual compact smooth factor φ. The existing
Green construction gives the canonical ordinary inverse φ=-K*G when
G=Aφ and K(x)=exp(-|x|/2). Thus ordinarily the induced map is

    T_s G = s² L_s G - (s²-1)L_s(K*G)/4.

Its definition on the factor and both moments are kernel-verified here.
The convolution expression is a reuse/ordinary identification, not a new
kernel-checked distribution theorem `D0 K=delta` in this checkpoint.

For the brief's state notation take theta=(J,s,M), with V_theta the actual
moment-zero carrier supported in J, Q_theta the restriction of the complete
Weil form, C_theta the source-bound certificates with their exact domains,
and O_theta the unproved form-transport estimates. A scaling map changes J
and, after correction, the packet itself. A certificate is transported only
after the relevant Q defect is bounded; typing the state does not prove it.
Obstruction pullback here is a preimage of a failed condition. Certificate
fusion is the existing finite decomposition plus its required cross terms.
These are established constructions, not newly invented operations.

## Executed adversarial test

`MOMENT_DILATION_DERIVATION.md` gives a compact smooth witness made from the
original positive eta bump. Set φ(x)=eta(100x), r=11/10, a=2log r, and

    G=φ-(221/110)τ_aφ+τ_(2a)φ.

Both original moments are zero. After R2 expansion they are

    M_+(R2G)=(331/5000)M_1(φ)>0,
    M_-(R2G)=(662/14641)M_-1(φ)>0.

Support widths are bounded by 21/50 and 21/25, respectively, both below
11/8. This falsifies preservation of W0 by plain log dilation even inside
the existing certified width. It does not falsify the window theorem or RH.
The general smooth witness is an ordinary analytic argument; Python checks
its rational factors, not the integrals. The Lean file proves the general
operator correction and its moments, not this entire explicit bump witness.

Retuning the middle coefficient restores both moments without enlarging
support. The script executes this next experiment too. The retuning changes
the packet by `d H`, with `d=-331/12100` and H a shifted R2 bump. Its full
quadratic defect is `2d Re B(R2G,H)+d²Q(H)`. Support and moments do not bound
this actual mixed term.

## Exact full-form obligation, retaining arithmetic terms

The original `RHKreinZetaBridgeV3.zero_quadratic_eq_scertM` identifies Q(g)
with `(1/(2π))*integral S_M(t) Nr_g(t) dt`, under both moments and a support
cutoff. Its exact symbol is

    S_M(t)=Psi(t)-log(pi)
       - sum_(0<=n<M) [2 Lambda(n+1)/sqrt(n+1)] cos(t log(n+1)).

Choose M valid for the original and corrected packets. There is no dropped
prime-power tail: the source theorem proves it vanishes under that support
condition. The ordinary Fourier scaling calculation for corrected compression
g_s gives

    Q(g_s)-Q(g) = (1/(2π))*integral Delta_(s,M)(u) Nr_g(u) du,
    Delta_(s,M)(u) = S_M(su)/s
       * ((s²u²+1/4)/(u²+1/4))² - S_M(u).

This follows from the existing factor multiplier and the change of variables
t=s*u, including its Jacobian. It retains both the archimedean and all
support-relevant prime-power contributions. Its full analytic formalization
and any useful sign estimate remain OPEN. In particular the weight is not
silently declared invariant or nonnegative.

To use a certified compressed packet g_s to prove Q(g)>=0 for a wider
packet g, a sufficient route would be `Q(g)-Q(g_s)>=0`. That means the
displayed defect has the opposite sign, `Q(g_s)-Q(g)<=0`. Neither this sign
nor a substitute universal bound has been proved. The present result removes
zero universal RH obligations; it identifies the exact missing transport
estimate after restoring the carrier.

## Classification and established mathematics

EXISTING MATHEMATICS: constant-coefficient differential commutators, change
of variables for exponential moments, Green inverses for a second-order
operator, and quadratic-form polarization. Relevant verified source APIs
include Mathlib's derivative chain rule (`HasDerivAt.scomp`) and the existing
AEGIS cutoff and Fourier-factor theorems cited above.

NEW FORMALIZATION within this local delta: the exact scaling commutator and
corrected-moment transport using the actual existing Krein atom convention.
This is not a claim of historical originality. No exhaustive literature or
novelty search was executed, so historical originality is UNKNOWN.

REFUTED CANDIDATES: plain scaling commutes with D0; plain scaling preserves
both moments; correcting the moments leaves the packet unchanged.

OPEN: the complete Weil-form defect estimate, full kernel formalization of
the explicit smooth witness and spectral integral transport, and global RH.

The machine-readable graph records these distinctions and sources. It is
an index of evidence, never a replacement for the Lean proof terms.
