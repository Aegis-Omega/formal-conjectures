# Two paths, an exact obstruction, and a repaired carrier

This is existing differential-operator and exponential-moment mathematics
applied to the actual AEGIS log-coordinate carrier. No historical novelty or
RH closure is asserted. `discover_transport.py` performs an exact-rational
symbolic experiment, not numerical integration and not Lean verification.

## Actual carrier and immutable sources

`CvSMomentV1.lean`, lines 19–28, explicitly identifies the repository moments
in log coordinates `G(t)=exp(t/2)*g(exp(t))` as

    M_(+1/2)(G)=integral G(x) exp(x/2) dx = 0,
    M_(-1/2)(G)=integral G(x) exp(-x/2) dx = 0.

The archived `WeilRestrictedCriterionEquivalenceV1.md`, sections 1 and 6,
uses the same exact compact-smooth carrier, the inverse coordinate change
`g(x)=x^(-1/2)G(log x)` for x>0, and a specified nonnegative smooth bump
eta: the normalized `exp(-1/(1-x^2))` on |x|<1, zero outside. This experiment
uses that bump; it does not replace the Weil problem with a discrete model.

`CvSWindowL118V1.window_L118`, line 69, consumes both actual moments and a
log-coordinate support-width bound `2r<=11/8`. These are separate premises.
Exact SHA256 bindings for all three source files are in `DISCOVERY_RESULT.json`.

## The two nonidentical paths

For C^2 functions define `D0 f=f/4-f''`, `R_s f(x)=f(x/s)` with s>0, and
`tau_a f(x)=f(x-a)`. Both paths below start with the same function and land
in functions on the same real line:

    path A: f -> R_s f -> D0(R_s f),
    path B: f -> D0 f -> R_s(D0 f).

The ordinary chain rule gives

    A(f)=R_s(f)/4-s^(-2)R_s(f''),
    B(f)=R_s(f)/4-R_s(f''),
    A(f)-B(f)=(1-s^(-2))R_s(f'').

Equivalently the defect is

    (1-s^(-2))*R_s(f)/4+(s^(-2)-1)*R_s(D0 f).

The signs matter. At s=2 and f(x)=x^2, the discrepancy is exactly 3/2,
not zero. This polynomial falsifies the unrestricted operator commutation
claim. The smooth compact-support witness in the next section addresses the
actual admissible test-function carrier, independently of this polynomial.

Translations commute with D0. The dilation defects satisfy the exact
operator composition identity

    C_(s*t)(f)=C_s(R_t f)+R_s(C_t f), C_s=D0 R_s-R_s D0.

These identities are standard commutator/covariance identities, not a new
curvature invariant. The executable checks them coefficient-by-coefficient
on deterministic rational polynomials and rational parameters. That finite
check challenges the formulas; the general C^2 proof is the chain-rule
argument above.

## A smooth counterexample inside the certified width

For a real compactly supported smooth phi>=0, not identically zero, write
`M_lambda(phi)=integral phi(x)exp(lambda*x)dx`. This number is finite and
strictly positive for every real lambda. Substitution gives

    M_lambda(tau_a phi)=exp(lambda*a) M_lambda(phi),
    M_lambda(R_s phi)=s M_(s*lambda)(phi), s>0.

Let r>1, a=2log r, c=r+r^(-1), and

    G=phi-c*tau_a phi+tau_(2a) phi,
    P(z)=1-c*z+z^2=(z-r)(z-r^(-1)).

Then `M_lambda(G)=M_lambda(phi)*P(exp(lambda*a))`, so both original
moments vanish. Plain dilation, however, gives

    M_(+1/2)(R_2 G)=2 M_1(phi) P(r^2),
    M_(-1/2)(R_2 G)=2 M_(-1)(phi) P(r^(-2)),
    P(r^2)=(r-1)^2(r^2+r+1)>0,
    P(r^(-2))=(r-1)^2(r^2+r+1)/r^4>0.

Thus BOTH required moments become strictly positive. The factor two is the
Jacobian for this unnormalized dilation and is included in the executable.
For r=2 the factors relative to M_1(phi), M_-1(phi) are 14 and 7/8.
For r=11/10 they are exactly 331/5000 and 662/14641.

Take phi(x)=eta(100x), where eta is the archived positive smooth bump.
Its support is [-1/100,1/100]. For r=11/10 the support diameter of G is at
most `4log(11/10)+1/50`. Since log(1+x)<=x for x>-1, it is at most
21/50; the diameter after R2 is at most 21/25<11/8. Therefore G is an
actual smooth moment-zero packet fitting the existing window, and R2 G
also fits the width but fails BOTH moments. The inverse log-coordinate
change yields corresponding actual multiplicative test functions.

This directly separates the two premises of the existing window theorem.
It is not a counterexample to Weil positivity or RH, and no zeta zero is
supplied. It falsifies the proposed plain-dilation transport of admissibility.

The r=1 positive control has P(z)=(z-1)^2 and a=0, so G is the zero
function. The executable labels this degenerate control instead of using it
as a nonzero witness.

## Repairing the moments changes the quadratic problem

Keep the dilated base psi=R2 phi and spacing 2a, but retune the coefficient:

    c2=r^2+r^(-2),
    G_repaired=psi-c2*tau_(2a)psi+tau_(4a)psi.

Its two moments vanish exactly because its filter polynomial has roots
r^2 and r^-2. The correction to R2 G is exactly

    G_repaired-R2 G=(c-c2)*tau_(2a)psi.

For r=11/10, c-c2=-331/12100. Restoring the moments is explicit and does
not enlarge support beyond the same three shifted supports. It nevertheless
changes the test function. If Q is the actual complete Weil quadratic form
and B its Hermitian polarization, with d=c-c2 real and H=tau_(2a)psi, then

    Q(R2 G+dH)-Q(R2 G)=2d Re B(R2 G,H)+d^2 Q(H).

Neither the sign of d nor zero moments of G_repaired controls that cross
term. No translation or dilation invariance of the full Weil form is being
assumed. The precise next obligation is an actual full-form defect estimate
for this corrected transformation, including its prime-power and
archimedean terms. The present result eliminates no universal RH positivity
obligation; it exposes why support rescaling alone cannot reuse the finite
certificate as a universal theorem.

## Verification boundary

The executed Python experiment checks exact rational filter factors,
retuning factors, finite polynomial identities, and support-bound arithmetic.
The general smooth carrier statement uses the explicit ordinary analytic
argument above. Kernel formalization of substitution, positive bump moments,
and the associated actual full Weil quadratic defect remains OPEN here.
