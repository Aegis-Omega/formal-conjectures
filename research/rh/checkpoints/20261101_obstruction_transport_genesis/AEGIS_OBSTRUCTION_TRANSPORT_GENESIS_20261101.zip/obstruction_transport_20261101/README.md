# Executed structural discovery and exact Krein transport

This continues the existing AEGIS checkpoint. It does not regenerate the
known continuum or Gram/Schur numerical certificates.

The concrete result is an exact corrected log-scaling operator with both
moments and support proved in Lean. An explicit smooth example shows that
plain scaling fails both moments even when both supports fit width 11/8.
Restoring moments does not prove preservation of the full Weil-form sign.

Read `SPECIFICATION_AND_RH_MAP.md` for spaces, paths, exact discrepancy,
source reuse, the complete arithmetic-symbol remainder and its OPEN sign.
Read `MOMENT_DILATION_DERIVATION.md` for the compact smooth counterexample.
`RESEARCH_KNOWLEDGE_GRAPH.json` is the evidence index, not a proof term.

Execute the existing local runner in its new discovery mode:

```sh
python -B -O /workspace/aegis-rh-next-local-20261028/local_automation_20261030/run.py \
  --discovery-checkpoint /workspace/aegis-rh-next-local-20261028/obstruction_transport_20261101 \
  --out /tmp/aegis-rh-genesis-20261101
```

It validates prior receipts, executes the exact symbolic experiment, compiles
the source-identical Krein base and new transport theorem, and audits every
listed root. Repeating the command reuses only matching complete outputs,
logs, input hashes and runtime fingerprints. Sources outside the copied script
are also fingerprinted. A missing runtime is an execution blocker, not a
mathematical nonexistence result. No persistent daemon has been installed.

For the symbolic experiment alone:

```sh
python -B -O discover_transport.py
```

For the actual kernel replay, use the recorded Lean 4.33.1 `LEAN_PATH`:

```sh
lean -M5632 -j1 -DwarningAsError=true KreinLogScaleTransportV1.lean
```

The existing cache restoration command and archive hashes are in
`RESTORE_RUNTIME.json`, `SEARCH_RUNTIME_RESTORED.json` and
`DOUBLE_MOMENT_CACHE_ALIGNMENT.json`. The latter records an actual caught
post-reset cache-version mismatch and its repair from the correct previously
verified archive; no protected checkpoint was changed.

`FINAL_RECEIPT.json` identifies the accepted attempt and actual runs. Rejected
Lean elaboration attempts are retained with nonzero exit codes; they are not
accepted proofs. The seven accepted new roots use only propext,
Classical.choice and Quot.sound. The explicit smooth witness and the full
spectral integral transport remain ordinary derivations, not full Lean proofs.

The broader bounded-join mode of the same runner is separately recorded.
Its success status is never interchangeable with proof of canonical RH.
No new canonical RH proof, universal full-form positivity theorem, or
historical mathematical novelty is claimed.
