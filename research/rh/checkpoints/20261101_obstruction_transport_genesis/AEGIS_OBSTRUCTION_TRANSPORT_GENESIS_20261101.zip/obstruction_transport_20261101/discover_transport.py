#!/usr/bin/env python3
"""Exact symbolic experiment on the existing log-coordinate moment carrier.

Standard-library rational arithmetic only. The positive bump and its actual
integral identities are specified in the companion ordinary derivation;
the script verifies their exact filter factors, not integrals numerically.
No claim of a Lean proof, novel mathematics or RH closure is made here.
"""
from fractions import Fraction as Q
from pathlib import Path
from math import comb
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
SOURCE_PATHS = [
    Path('/workspace/aegis-rh-delta-20261023/AEGIS_OCT7_VERIFIED_SOURCES_V2/PrimeCancellationOct7/Sources/WeilRestrictedCriterionEquivalenceV1.md'),
    Path('/workspace/aegis-rh-import-repair-20261023/moment_trace_original_sources/research/rh/feshbach_lean_v1/CvSMomentV1.lean'),
    Path('/workspace/aegis-rh-next-local-20261028/l118_trace_20261029/CvSWindowL118V1.lean'),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def trim(p):
    p = list(map(Q, p))
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return p


def add(p, q):
    return trim([(p[i] if i < len(p) else 0) + (q[i] if i < len(q) else 0)
                 for i in range(max(len(p), len(q)))])


def scale(a, p):
    return trim([a*x for x in p])


def sub(p, q):
    return add(p, scale(Q(-1), q))


def second(p):
    return trim([j*(j-1)*p[j] for j in range(2, len(p))] or [Q(0)])


def d0(p):
    return sub(scale(Q(1,4), p), second(p))


def dilate(s, p):
    require(s > 0, 'positive dilation required')
    return trim([c/s**j for j,c in enumerate(p)])


def translate(a, p):
    # tau_a p(x) = p(x-a).
    result = [Q(0)] * len(p)
    for degree, c in enumerate(p):
        for j in range(degree+1):
            result[j] += c*comb(degree,j)*(-a)**(degree-j)
    return trim(result)


def commutator(s, p):
    return sub(d0(dilate(s,p)), dilate(s,d0(p)))


def filter_factor(c, z):
    return 1-c*z+z*z


def string_poly(p):
    return [str(x) for x in p]


def main():
    bindings = []
    for p in SOURCE_PATHS:
        bindings.append({'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    # The ordinary proof derives the rule for every C^2 function. These exact
    # coefficient tests independently challenge signs, normalizations and the
    # composition law on a deterministic finite family, not just evaluations.
    polys = [trim([Q((degree+3)*(j+2) % 11 - 5, j+1) for j in range(degree+1)])
             for degree in range(9)]
    scales = [Q(1,2), Q(2,3), Q(1), Q(11,10), Q(3,2), Q(2), Q(3)]
    translations = [Q(-2), Q(-1,3), Q(0), Q(2,5), Q(3)]
    checked_commutators = checked_translations = checked_compositions = 0
    for p in polys:
        for s in scales:
            actual = commutator(s,p)
            expected = scale(1-1/s**2, dilate(s,second(p)))
            alternative = add(scale((1-1/s**2)/4, dilate(s,p)),
                              scale(1/s**2-1, dilate(s,d0(p))))
            require(actual == expected == alternative, 'D0-dilation discrepancy identity failed')
            checked_commutators += 1
            for t in scales:
                require(dilate(s,dilate(t,p)) == dilate(s*t,p), 'dilation composition')
                require(commutator(s*t,p) == add(commutator(s,dilate(t,p)),
                                                dilate(s,commutator(t,p))),
                        'commutator composition identity failed')
                checked_compositions += 1
        for a in translations:
            require(d0(translate(a,p)) == translate(a,d0(p)), 'translation covariance failed')
            checked_translations += 1
    # Positive controls and explicit falsifier for the tempting commutation rule.
    require(commutator(Q(1), [0,0,1]) == [Q(0)], 'identity scale control')
    require(commutator(Q(2), [1,2]) == [Q(0)], 'affine function control')
    witness = commutator(Q(2), [0,0,1])
    require(witness == [Q(3,2)], 'noncommutation witness failed')
    rejected = []
    try:
        require(witness == [Q(0)], 'D0 and R2 do not commute: f(x)=x^2')
    except ValueError as exc:
        rejected.append({'candidate': 'D0 commutes with every positive dilation',
                         'rejected': True, 'witness': 'f(x)=x^2, s=2',
                         'exact_discrepancy': str(witness[0]), 'reason': str(exc)})
    else:
        raise ValueError('False commutation candidate was accepted')

    moment_examples = []
    for r in [Q(1), Q(11,10), Q(2)]:
        c = r+1/r
        require(filter_factor(c,r) == filter_factor(c,1/r) == 0, 'original moments not killed')
        positive = filter_factor(c,r*r)
        negative = filter_factor(c,1/(r*r))
        common = (r-1)**2*(r*r+r+1)
        require(positive == common and negative == common/r**4, 'exact dilation factors')
        # R2 has Jacobian 2 in the exponential-moment integral.
        c2 = r*r+1/(r*r)
        require(filter_factor(c2,r*r) == filter_factor(c2,1/(r*r)) == 0,
                'retuned moments not killed')
        if r > 1:
            require(positive > 0 and negative > 0, 'positive bump moment witness not strict')
            try:
                require(positive == negative == 0, 'plain dilation breaks BOTH original exponential moments')
            except ValueError as exc:
                rejected.append({'candidate': 'Plain R2 preserves the moment-zero carrier',
                                 'rejected': True, 'r': str(r), 'reason': str(exc),
                                 'polynomial_positive_factor': str(positive),
                                 'polynomial_negative_factor': str(negative)})
            else:
                raise ValueError('False moment-preservation candidate was accepted')
        moment_examples.append({
            'r': str(r), 'shift_a': '2*log('+str(r)+')', 'middle_coefficient': str(c),
            'source_moment_factors': ['0','0'],
            'R2_positive_moment_over_M_1_phi': str(2*positive),
            'R2_negative_moment_over_M_minus_1_phi': str(2*negative),
            'retuned_middle_coefficient': str(c2),
            'retuning_change_times_shifted_R2_phi': str(c-c2),
            'retuned_moment_factors': ['0','0'],
            'r1_control_is_zero_function': r == 1,
        })
    # For r=11/10, eta(100x) has radius 1/100. log(1+x)<=x
    # bounds the exact support diameter before and after R2. This log bound
    # is an ordinary analytic inequality, not evaluated with floats here.
    source_width_upper = 4*Q(1,10)+Q(2,100)
    target_width_upper = 2*source_width_upper
    require(source_width_upper == Q(21,50), 'source support arithmetic')
    require(target_width_upper == Q(21,25) < Q(11,8), 'small-window support arithmetic')

    result = {
        'status': 'EXACT_RATIONAL_SYMBOLIC_DISCOVERY_PASS',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command': [sys.executable, *sys.argv],
        'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_bindings': bindings,
        'carrier': 'G in C_c^infinity(R) in existing log coordinates, with M_(+1/2)(G)=M_(-1/2)(G)=0',
        'operators': {'D0': 'f/4-f_second_derivative', 'R_s': 'f(x/s), s>0', 'tau_a': 'f(x-a)'},
        'ordinary_analytic_theorem': 'D0(R_s f)-R_s(D0 f)=(1-s^(-2))*R_s(f_second_derivative) for every C^2 f',
        'verified_polynomial_coefficient_instances': checked_commutators,
        'verified_translation_instances': checked_translations,
        'verified_commutator_compositions': checked_compositions,
        'exact_noncommutation_witness': {'f': 'x^2', 's': '2', 'difference_polynomial': string_poly(witness)},
        'smooth_bump_moment_examples': moment_examples,
        'small_window_example': {'r': '11/10', 'phi': 'eta(100*x), using the archived canonical positive smooth bump',
                                'source_support_diameter_upper': str(source_width_upper),
                                'R2_support_diameter_upper': str(target_width_upper),
                                'certified_window_width': '11/8',
                                'both_widths_fit': True,
                                'R2_has_nonzero_both_moments': True,
                                'support_estimate_uses_ordinary_log_one_plus_le_inequality': True},
        'rejected_candidates': rejected,
        'classification': 'EXISTING MATHEMATICS, source-bound obstruction experiment and potential NEW FORMALIZATION; no historical novelty claim',
        'OPEN': ['Kernel formalization of smooth bump moment/change-of-variable identities.',
                 'Quantitative control of the actual complete Weil quadratic defect under moment-preserving retuned dilation.',
                 'Universal positivity/RH; no finite-width result becomes universal from this calculation.'],
        'lean_kernel_verified_by_this_script': False,
        'actual_Weil_quadratic_defect_bounded': False,
        'universal_RH_obligations_eliminated': 0,
        'RH_proved': False,
        'floating_point_acceptance_used': False,
    }
    (ROOT/'DISCOVERY_RESULT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(result['status'])
    print('D0_DILATION_COEFFICIENT_IDENTITIES', checked_commutators)
    print('TRANSLATION_IDENTITIES', checked_translations)
    print('COMMUTATOR_COMPOSITIONS', checked_compositions)
    print('REJECTED_CANDIDATES', len(rejected))
    print('SMOOTH_SMALL_WINDOW_MOMENT_WITNESS_FACTORS', '331/5000', '662/14641')
    print('RH_PROVED', False)


if __name__ == '__main__':
    main()
