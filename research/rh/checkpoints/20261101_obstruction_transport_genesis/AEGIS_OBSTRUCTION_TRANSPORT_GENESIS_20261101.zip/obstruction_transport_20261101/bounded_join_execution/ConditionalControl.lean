import WeilRHImpliesFinalSignV13
theorem conditional (h : _root_.RiemannHypothesis) : _root_.RiemannHypothesis := h
