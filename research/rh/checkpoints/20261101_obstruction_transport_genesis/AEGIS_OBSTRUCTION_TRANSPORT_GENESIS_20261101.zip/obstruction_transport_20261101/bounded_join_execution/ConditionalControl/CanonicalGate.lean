import Candidate

theorem AEGIS.AutomationGate.closedRH : _root_.RiemannHypothesis := conditional
#print axioms conditional
#print axioms AEGIS.AutomationGate.closedRH
