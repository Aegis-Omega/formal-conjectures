import BoundedJoinSearch
set_option maxHeartbeats 4000000
theorem AEGIS.AutomationAttempt.result : _root_.RiemannHypothesis := by
  aegis_bounded_join
#print axioms AEGIS.AutomationAttempt.result
