import RHLocalKreinPartitionV1
import Mathlib.Tactic

/-! Exact log-coordinate scaling transport of the existing Krein atom.
The existing convention is A = deriv² - 1/4 = -D₀. We do not redefine A.
Scaling the factor and scaling the atom are two different paths. Their
discrepancy is explicit. The corrected path preserves both moments.
No invariance or positivity of the complete Weil form is asserted.
-/

open Set MeasureTheory
open scoped ContDiff
set_option autoImplicit false
noncomputable section

namespace AEGIS.KreinLogScaleTransportV1

open AEGIS.RHLocalKreinPartitionV1

def logScale (s : ℝ) (f : ℝ → ℂ) (x : ℝ) : ℂ := f (s * x)

private theorem deriv_logScale (f : ℝ → ℂ) (hf : Differentiable ℝ f) (s : ℝ) :
    deriv (logScale s f) = fun x => (s : ℂ) * deriv f (s * x) := by
  funext x
  change deriv (fun y => f (s * y)) x = _
  simpa only [Function.comp_def, Complex.real_smul, mul_one] using
    ((hf (s * x)).hasDerivAt.scomp x ((hasDerivAt_id x).const_mul s)).deriv

theorem second_deriv_logScale (φ : ℝ → ℂ) (hφ : ContDiff ℝ ∞ φ) (s x : ℝ) :
    deriv (deriv (logScale s φ)) x =
      (s : ℂ)^2 * deriv (deriv φ) (s * x) := by
  have hD := (contDiff_infty_iff_deriv.mp hφ).2
  have hd := hφ.differentiable (by simp)
  have hdd := hD.differentiable (by simp)
  have hcomp : Differentiable ℝ (logScale s (deriv φ)) :=
    hdd.comp (by fun_prop : Differentiable ℝ (fun y : ℝ => s * y))
  rw [deriv_logScale φ hd s]
  change deriv (fun y => (s : ℂ) * logScale s (deriv φ) y) x = _
  rw [((hcomp x).hasDerivAt.const_mul (s : ℂ)).deriv, deriv_logScale (deriv φ) hdd s]
  ring

/-- The exact two-path discrepancy; scaling the atom is not scaling its factor. -/
theorem kreinAtom_logScale (φ : ℝ → ℂ) (hφ : ContDiff ℝ ∞ φ) (s x : ℝ) :
    kreinAtom (logScale s φ) x =
      (s : ℂ)^2 * logScale s (kreinAtom φ) x +
        (((s : ℂ)^2 - 1) / 4) * logScale s φ x := by
  simp only [kreinAtom, second_deriv_logScale φ hφ, logScale]
  ring

/-- The raw paths commute only up to this explicit second-derivative term. -/
theorem raw_path_discrepancy (φ : ℝ → ℂ) (hφ : ContDiff ℝ ∞ φ) (s x : ℝ) :
    kreinAtom (logScale s φ) x - logScale s (kreinAtom φ) x =
      ((s : ℂ)^2 - 1) * deriv (deriv φ) (s * x) := by
  simp only [kreinAtom, second_deriv_logScale φ hφ, logScale]
  ring

/-- Correcting the atom by the factor term gives exactly the scaled-factor atom. -/
theorem corrected_scale_identity (φ : ℝ → ℂ) (hφ : ContDiff ℝ ∞ φ) (s : ℝ) :
    (fun x => (s : ℂ)^2 * logScale s (kreinAtom φ) x +
      (((s : ℂ)^2 - 1) / 4) * logScale s φ x) = kreinAtom (logScale s φ) := by
  funext x
  exact (kreinAtom_logScale φ hφ s x).symm

/-- Both actual exponential moments of the corrected transport vanish. -/
theorem corrected_scale_moments (φ : ℝ → ℂ) (hφ : ContDiff ℝ ∞ φ)
    (hc : HasCompactSupport φ) (s : ℝ) (hs : s ≠ 0) :
    let H := fun x => (s : ℂ)^2 * logScale s (kreinAtom φ) x +
      (((s : ℂ)^2 - 1) / 4) * logScale s φ x
    (∫ x : ℝ, (Real.exp (-x / 2) : ℂ) * H x) = 0 ∧
      (∫ x : ℝ, (Real.exp (x / 2) : ℂ) * H x) = 0 := by
  let H : ℝ → ℂ := fun x => (s : ℂ)^2 * logScale s (kreinAtom φ) x +
    (((s : ℂ)^2 - 1) / 4) * logScale s φ x
  change (∫ x : ℝ, (Real.exp (-x / 2) : ℂ) * H x) = 0 ∧
    (∫ x : ℝ, (Real.exp (x / 2) : ℂ) * H x) = 0
  have hH : H = kreinAtom (logScale s φ) := corrected_scale_identity φ hφ s
  rw [hH]
  have hscaled : ContDiff ℝ ∞ (logScale s φ) :=
    hφ.comp (contDiff_const.mul contDiff_id)
  have hcompact : HasCompactSupport (logScale s φ) :=
    hc.comp_homeomorph (Homeomorph.mulLeft₀ s hs)
  exact kreinAtom_moments (logScale s φ) hscaled hcompact

/-- The corrected transport has support in the scaled original factor support. -/
theorem corrected_scale_support (φ : ℝ → ℂ) (hφ : ContDiff ℝ ∞ φ)
    (s : ℝ) :
    tsupport (fun x => (s : ℂ)^2 * logScale s (kreinAtom φ) x +
      (((s : ℂ)^2 - 1) / 4) * logScale s φ x) ⊆ tsupport (logScale s φ) := by
  rw [corrected_scale_identity φ hφ s]
  exact kreinAtom_support _

/-- Scaling the factor composes without an additional analytic remainder. -/
theorem factor_scale_composition (φ : ℝ → ℂ) (s t : ℝ) :
    kreinAtom (logScale s (logScale t φ)) = kreinAtom (logScale (t * s) φ) := by
  congr 1
  funext x
  simp only [logScale]
  rw [mul_assoc]

end AEGIS.KreinLogScaleTransportV1

#print axioms AEGIS.KreinLogScaleTransportV1.second_deriv_logScale
#print axioms AEGIS.KreinLogScaleTransportV1.kreinAtom_logScale
#print axioms AEGIS.KreinLogScaleTransportV1.raw_path_discrepancy
#print axioms AEGIS.KreinLogScaleTransportV1.corrected_scale_identity
#print axioms AEGIS.KreinLogScaleTransportV1.corrected_scale_moments
#print axioms AEGIS.KreinLogScaleTransportV1.corrected_scale_support
#print axioms AEGIS.KreinLogScaleTransportV1.factor_scale_composition
