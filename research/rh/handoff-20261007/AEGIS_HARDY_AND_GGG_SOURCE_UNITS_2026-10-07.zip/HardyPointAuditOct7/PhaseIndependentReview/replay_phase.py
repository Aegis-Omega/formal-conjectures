from pathlib import Path
import datetime,json,hashlib,os,re,subprocess,time
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
SOURCE=BASE/'PhaseTransport/RHHardyPhaseTransportV1.lean'
PRIOR=BASE/'IndependentReview/KernelReplay/Run-20261007T085834.405997Z'
FIRST=BASE/'PhaseTransport/Run-20261007T090421.735667Z'
CACHE=Path('/workspace/aegis-research/work/GoalContinuation20261001/AnalyticReplay/actual-context-20261003T004616.608552Z/mathlib-only')
PACKAGES=Path('/workspace/aegis-research/provider/.lake/packages')
BIN=Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
NAMES=('pi_rpow_eq_exp','pi_cpow_line_factor','amplitude_eq_pi_rpow_gamma_norm','amplitude_eq_exp_gamma_norm','completed_div_amplitude_eq_normalized','gammaR_phase_zeta_eq_normalized','evaluator_phase_eq_gammaR_div_amplitude','evaluator_phase_zeta_eq_normalized')
ENDPOINTS=tuple('AEGIS.RHHardyPhaseTransportV1.'+n for n in NAMES)
def demand(x,m):
 if not x:raise RuntimeError(m)
def bh(p):
 b=p.read_bytes();return{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
demand(bh(SOURCE)['sha256']=='1c0a0dda1499dec1701e49d0ef7cca585b17f8a7eb2a356e65e23bdba90c0d38','phase source changed')
old=json.loads((PRIOR/'RECEIPT.json').read_text());first=json.loads((FIRST/'RECEIPT.json').read_text())
demand(old['status']=='PASS_SCOPED_SIX_SOURCE_REPLAY' and first['status']=='PASS_SCOPED_PHASE_TRANSPORT','prior replay not PASS')
for row in old['source_bindings']:
 for key in ['fresh_source','original']:
  b=bh(Path(row[key]['path']));demand(b==row[key],'reused source snapshot changed '+row['module'])
modules=[r['module']for r in old['source_bindings']]
used=[]
for row in old['fresh_objects']:
 if Path(row['path']).stem in modules:
  demand(bh(Path(row['path']))==row,'reused object changed');used.append(row)
demand(len(used)==6,'missing fresh six source objects')
run=HERE/('Run-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
for d in [run,run/'lib',run/'logs']:d.mkdir()
copy=run/SOURCE.name;copy.write_bytes(SOURCE.read_bytes())
paths=[run/'lib',PRIOR/'lib',CACHE,CACHE.parent/'package-only']
for package in ['LeanSearchClient','Qq','aesop','batteries','importGraph','plausible','proofwidgets']:
 p=PACKAGES/package/'.lake/build/lib/lean';demand(p.is_dir(),'package path missing');paths.append(p)
env=dict(os.environ);env['PATH']=str(BIN)+os.pathsep+env.get('PATH','');env['LEAN_PATH']=os.pathsep.join(map(str,paths));env['ELAN_TOOLCHAIN']='leanprover/lean4:v4.33.1'
pow_source=PACKAGES/'mathlib/Mathlib/Analysis/SpecialFunctions/Pow/Real.lean';pow_object=CACHE/'Mathlib/Analysis/SpecialFunctions/Pow/Real.olean'
githead=subprocess.run(['git','-C',str(PACKAGES/'mathlib'),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
demand(githead=='0df444a360eaa60ab8c11dca51a86af692955474','wrong Mathlib head')
blob=subprocess.run(['git','-C',str(PACKAGES/'mathlib'),'show',githead+':Mathlib/Analysis/SpecialFunctions/Pow/Real.lean'],capture_output=True,check=True).stdout
demand(pow_source.read_bytes()==blob,'Pow.Real source differs from pinned Git blob')
receipt={'schema':'AEGIS_HARDY_PHASE_INDEPENDENT_KERNEL_REPLAY_V1','status':'RUNNING','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_directory':str(run),'source':bh(SOURCE),'fresh_source':bh(copy),'same_host':True,
 'compiler':bh(BIN/'lean'),'checker':bh(BIN/'leanchecker'),'driver':bh(Path(__file__)),'first_phase_replay':bh(FIRST/'RECEIPT.json'),'reused_six_source_replay':bh(PRIOR/'RECEIPT.json'),'reused_six_source_objects':used,
 'named_Pow_Real_import':{'pinned_source':bh(pow_source),'source_equal_pinned_git_blob':True,'identified_reused_object':bh(pow_object),'source_recompiled_by_this_review':False},
 'mathlib_commit':githead,'full_transitive_source_rebuild':False,'sourcecompiled_this_review':['RHHardyPhaseTransportV1'],'reused_prior_sourcecompiled_local_modules':modules,'LEAN_PATH':env['LEAN_PATH'],
 'limits':{'wall_seconds_per_job':90,'resident_memory_MiB':4096,'RSS_poll_seconds':0.05,'CPU_affinity_count':1,'compiler_threads':1},'jobs':[],'rh_proven':False,'numeric_t60_lower_bound_verified':False,'source_mutations':False,'remote_writes':False}
def save():
 (run/'RECEIPT.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');(HERE/'LATEST_RUN.json').write_text(json.dumps({'run_directory':str(run)},indent=2)+'\n')
def affinity():os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def execute(label,args):
 start=time.monotonic();o=run/'logs'/(label+'.stdout');e=run/'logs'/(label+'.stderr');peak=0;stop=None
 with o.open('wb')as fo,e.open('wb')as fe:
  p=subprocess.Popen(list(map(str,args)),cwd=run,env=env,stdout=fo,stderr=fe,preexec_fn=affinity,start_new_session=True)
  while p.poll()is None:
   try:
    match=re.search(r'^VmRSS:\s+(\d+) kB$',(Path('/proc')/str(p.pid)/'status').read_text(),re.M)
    if match:peak=max(peak,int(match.group(1)))
   except(FileNotFoundError,ProcessLookupError):pass
   if peak>4096*1024:stop='RSS_LIMIT';os.killpg(p.pid,9);break
   if time.monotonic()-start>90:stop='WALL_LIMIT';os.killpg(p.pid,9);break
   time.sleep(.05)
  code=p.wait()
 receipt['jobs'].append({'label':label,'argv':list(map(str,args)),'exit_code':code,'termination':stop,'seconds':time.monotonic()-start,'peak_RSS_KiB':peak,'stdout':bh(o),'stderr':bh(e)});save()
 print(json.dumps({'label':label,'exit_code':code,'termination':stop}),flush=True);demand(code==0 and stop is None,'failed '+label)
 return o.read_text()+e.read_text()
save()
try:
 version=execute('compiler_version',[BIN/'lean','--version']);demand('4.33.1' in version and '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' in version,'compiler pin mismatch');receipt['compiler_version']=version.strip()
 compilelog=execute('compile_phase',[BIN/'lean','--trust=0','-j1','-M4096','-DwarningAsError=true','-o',run/'lib/RHHardyPhaseTransportV1.olean',copy])
 execute('checker_phase',[BIN/'leanchecker','-v','RHHardyPhaseTransportV1'])
 probe=run/'PhaseIndependentEndpoints.lean';probe.write_text('import RHHardyPhaseTransportV1\n\n'+''.join('#check '+n+'\n#print '+n+'\n#print axioms '+n+'\n'for n in ENDPOINTS))
 audit=execute('endpoint_full_type_axiom',[BIN/'lean','--trust=0','-j1','-M4096','-DwarningAsError=true','-o',run/'lib/PhaseIndependentEndpoints.olean',probe])
 execute('checker_endpoints',[BIN/'leanchecker','-v','PhaseIndependentEndpoints'])
 reports={}
 for name,axs in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",compilelog+'\n'+audit):
  a=sorted({v.strip()for v in axs.split(',')if v.strip()});demand(set(a)<={'propext','Classical.choice','Quot.sound'},'unexpected axiom '+name)
  if name in reports:demand(reports[name]==a,'inconsistent axiom reports')
  reports[name]=a
 demand(set(ENDPOINTS)==set(reports),'missing/unexpected endpoint axiom report')
 for n in ENDPOINTS:
  demand(n in audit,'endpoint missing from full type output')
 demand('∀ (t : ℝ)' in audit,'real domain not in printed type')
 demand('sorryAx'not in audit and 'RiemannHypothesis'not in audit,'unexpected target/placeholder')
 receipt['axioms']=reports;receipt['endpoint_full_type_audit_source']=bh(probe);receipt['fresh_objects']=[bh(p)for p in sorted((run/'lib').glob('*.olean'))];receipt['all_real_phase_formula_identity_verified']=True;receipt['numeric_lower_bound_asserted']=False;receipt['status']='PASS_SCOPED_PHASE_REPLAY';save()
 print(json.dumps({'status':receipt['status'],'receipt':bh(run/'RECEIPT.json'),'rh_proven':False}),flush=True)
except Exception as exc:
 receipt['status']='FAILED';receipt['exception']=str(exc);save();raise
