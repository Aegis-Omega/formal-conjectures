from pathlib import Path
import json,hashlib,datetime
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
R=Path(json.loads((HERE/'LATEST_RUN.json').read_text())['run_directory'])
OLD=BASE/'IndependentReview';FIRST=BASE/'PhaseTransport/Run-20261007T090421.735667Z'
SRC=BASE/'PhaseTransport/RHHardyPhaseTransportV1.lean'
def demand(x,m):
 if not x:raise RuntimeError(m)
def bh(p):
 b=p.read_bytes();return{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,d):
 demand(not p.exists(),'refusing overwrite '+str(p));p.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
run=json.loads((R/'RECEIPT.json').read_text());ordinary=json.loads((HERE/'IdentityReview/REVIEW_RECEIPT.json').read_text())
demand(run['status']=='PASS_SCOPED_PHASE_REPLAY','replay failure');demand(ordinary['status']=='PASS_SCOPED_ORDINARY_REVIEW','ordinary review failure')
demand(bh(SRC)['sha256']=='1c0a0dda1499dec1701e49d0ef7cca585b17f8a7eb2a356e65e23bdba90c0d38','source changed')
demand(bh(R/'RECEIPT.json')['sha256']=='d7c472bf61c95c0c06a381dc79c3f0482d3688ef1cb4683cc3bcac2aae0dcef9','run changed')
demand(bh(HERE/'IdentityReview/REVIEW_RECEIPT.json')['sha256']=='2087a5a906e384e92e82546cd750b9e5d63fd3af5b11455e028f0eac52395d38','ordinary review changed')
for j in run['jobs']:demand(j['exit_code']==0 and j['termination'] is None,'failed job')
demand(len(run['axioms'])==8,'wrong endpoint count')
for axioms in run['axioms'].values():demand(set(axioms)<={'propext','Classical.choice','Quot.sound'},'unexpected axiom')
# Verify frozen prior independent snapshots remain byte-bound, without rerunning them.
oldreceipt=json.loads((OLD/'REVIEW_RECEIPT.json').read_text());demand(bh(OLD/'REVIEW_RECEIPT.json')['sha256']=='c2d3bf7252508f3de83fae7d573f678e674bb1a271d2debb05aed8be61a5b168','old receipt changed')
for row in json.loads((OLD/'SOURCE_MANIFEST.json').read_text())['files']:demand(bh(Path(row['path']))==row,'old bound bytes changed '+row['path'])
paths=[p for p in HERE.rglob('*')if p.is_file()and p.name not in {'SOURCE_MANIFEST.json','REVIEW_RECEIPT.json'}]
paths += [HERE/'IdentityReview/SOURCE_MANIFEST.json',HERE/'IdentityReview/REVIEW_RECEIPT.json',SRC,BASE/'PhaseTransport/MATHEMATICAL_REVIEW.md',BASE/'PhaseTransport/RESULT.json',FIRST/'RECEIPT.json',OLD/'REVIEW_RECEIPT.json',OLD/'SOURCE_MANIFEST.json',Path(run['reused_six_source_replay']['path'])]
paths += [Path(v['path'])for v in run['reused_six_source_objects']]
paths += [Path(run['named_Pow_Real_import'][n]['path'])for n in ['pinned_source','identified_reused_object']]
manifest={'schema':'AEGIS_HARDY_PHASE_INDEPENDENT_REVIEW_BINDINGS_V1','scope':'Separate new phase source/review/replay bytes and explicitly reused context identities only; excludes aggregate self/receipt. Fresh/reused compiled objects are labelled by replay receipt, with no full transitive source rebuild claim.','files':[bh(p)for p in sorted(set(paths),key=str)]}
save(HERE/'SOURCE_MANIFEST.json',manifest)
receipt={'schema':'AEGIS_HARDY_PHASE_INDEPENDENT_SOURCE_IDENTITY_REPLAY_REVIEW_V1','status':'PASS_SCOPED','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Unchanged new mathematical phase/amplitude transport source; independent fresh source compilation, full eight-endpoint type/axiom audit, leanchecker, separate ordinary review. No quantitative lower or RH proof.',
 'source':bh(SRC),'manifest':bh(HERE/'SOURCE_MANIFEST.json'),'review':bh(HERE/'REVIEW.md'),'replay':bh(R/'RECEIPT.json'),'ordinary_review':bh(HERE/'IdentityReview/REVIEW_RECEIPT.json'),'old_independent_review_preserved':bh(OLD/'REVIEW_RECEIPT.json'),
 'lean_version':'4.33.1','compiler_commit':'819816b2e0a3bf405af45ae5c7af2491d8f5bee6','mathlib_commit':run['mathlib_commit'],'same_host':True,
 'new_phase_proof_source_compiled':True,'new_endpoint_audit_module_compiled':True,'checker_jobs':2,'full_type_axiom_endpoints':8,'axioms':run['axioms'],'trust':0,'warningAsError':True,
 'cached_Pow_Real_object':run['named_Pow_Real_import'],'previous_six_sourcecompiled_modules_reused':True,'previous_six_source_rebuild_repeated':False,'full_transitive_source_rebuild':False,
 'all_real_phase_expression_equals_normalized_formally_verified':True,'explicit_positive_real_amplitude_branch_factor':'pi^(-1/4)=exp(-log(pi)/4)>0','phase_sign':'exp(-it log(pi)/2)',
 'older_expression_identification_gap_status':'Closed by these new eight formal phase/amplitude identities. Older frozen review remains an unchanged historical snapshot.',
 'Arb_special_function_soundness_Lean_transport':False,'numeric_t60_lower_bound_Lean_theorem':False,'numeric_point_replay_repeated':False,'old22_Git_review_repeated':False,
 'observed_peak_RSS_KiB':max(j['peak_RSS_KiB']for j in run['jobs']),'resident_MiB_limit':4096,'wall_seconds_limit':90,'one_CPU':True,
 'source_or_old_receipt_mutations':False,'remote_writes':False,'rh_proven':False,'final_RH_theorem':None,'unchanged_global_obligation':'AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign for the same detectingPacket, every signed-integer log2/log3 shift and every four-phase value with full real Weil RHS<=0; no unconditional producer supplied here.'}
save(HERE/'REVIEW_RECEIPT.json',receipt)
for p in [HERE/'REVIEW_RECEIPT.json',HERE/'SOURCE_MANIFEST.json']:print(json.dumps(bh(p)))
