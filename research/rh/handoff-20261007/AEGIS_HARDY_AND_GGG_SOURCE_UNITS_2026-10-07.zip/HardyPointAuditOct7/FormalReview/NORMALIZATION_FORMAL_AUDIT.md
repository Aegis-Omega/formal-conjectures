# Hardy Q16.16 t=60: formal replay and object audit

## Exact result

Six supplied modules were freshly compiled with Lean 4.33.1, compiler commit
`819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, using explicit `--trust=0`.
Each fresh object, and a seventh endpoint type/axiom audit object, was separately
accepted by the same toolchain's `leanchecker`. Eleven endpoint axiom reports
contain only `propext`, `Classical.choice`, and `Quot.sound`.

The successful run is `Run-20261007T085543.394114Z`. Its receipt and complete
compiler/checker/type/axiom logs are retained. All jobs remained below the
90-second wall limit and the 4096 MB observed resident-memory limit. Lean also
received `-M4096 -j1`; both compiler and checker used one available CPU.

The replay rebuilds the six packet modules from source. Identified Mathlib and
package objects are reused; it does not rebuild the whole transitive dependency
source closure. The separate dependency identity audit binds resolved objects,
available companion files, and recovered/current source identities. It is a
source-import identity audit, not an OLEAN-header parser or a new soundness theorem.

## Sources and compatibility

The packet's twelve supplied FormalConjectures baseline files match the actual
local Git object `70ed9dd8ccc3365c7b5734b781a17f591a0dde0f` byte-for-byte.
This comparison includes all five baseline proof modules. The new Hardy module
is separately bound to its uploaded bytes. Mathlib's source tree is clean at
`0df444a360eaa60ab8c11dca51a86af692955474`.

The available cache lacks aggregate `Mathlib.olean`. Four baseline modules
therefore use new effective copies replacing only `import Mathlib` with named
Mathlib and tactic imports. The recorded patch includes the actual source modules
for `riemannZeta_conj` and `Real.pi_gt_three`. `RHLambdaLineV1` and
`RHHardyNormalizationV1` are byte-identical to the originals. A byte comparison
after removing import lines confirms that all six modules' remaining bytes,
including every declaration and proof, are unchanged.

The fresh effective modules are:

1. `RHCriticalLineSignV1`;
2. `RHRiemannThetaFormulaV1`;
3. `RHLambdaLineV1`;
4. `RHFixIntervalV1`;
5. `RHThetaTailV1`;
6. `RHHardyNormalizationV1`.

## Mathematical identity

Put `s=1/2+it`, `w=s/2=1/4+it/2`. The actual Mathlib factor is

\[
 \Gamma_{\mathbb R}(s)=\pi^{-s/2}\Gamma(s/2)
 =\pi^{-1/4}e^{-it\log\pi/2}\Gamma(w).
\]

The principal complex power here has no branch ambiguity: the base \(\pi\)
is positive real. Since `Re s=1/2>0`, Mathlib proves
`Gammaℝ s ≠ 0` and `completedRiemannZeta s = Gammaℝ s * riemannZeta s`.
Consequently

\[
 a(t)=\|\Gamma_{\mathbb R}(s)\|
 =\pi^{-1/4}|\Gamma(w)|>0.
\]

The baseline's `Xi` is the meromorphic completed zeta \(\Lambda\), not the
standard entire \(\xi\). Its real-valuedness on the line follows from the
functional equation and conjugation identity, without assuming RH. Thus the
new source-defined real normalization satisfies the paper identity

\[
 \operatorname{normalized}(t)
 =\frac{\Re\Lambda(1/2+it)}{a(t)}
 =\Re\left[e^{-it\log\pi/2}
        \frac{\Gamma(1/4+it/2)}{|\Gamma(1/4+it/2)|}
        \zeta(1/2+it)\right].
\]

This is the formula used by the packet's independent FLINT phase evaluator.
The equality with that phase expression is reconstructed mathematically here
and in the independent written source review. The supplied Lean module itself
does not declare or prove the expanded phase-expression identity.

For comparison, standard entire xi has the opposite sign on the line:
\(\xi(1/2+it)=-(t^2+1/4)\Lambda(1/2+it)/2\).
The theta/Mellin formula's pole correction at \(t=60\) is exactly
\(1/(1/4+60^2)=4/14401\).

## Exact endpoint and remaining assumption

The compiled Hardy endpoint's full mathematical type is

```lean
theorem AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower
    (h : (38466 : ℝ) / 65536 ≤
      AEGIS.RHHardyNormalizationV1.normalized 60) :
    0 < (AEGIS.RHCriticalLineSignV1.Xi 60).re
```

The proof multiplies by the positive amplitude; it does not construct `h`.
Its axiom report has no extra axiom, but `h` remains an explicit argument of
the theorem. An axiom audit never erases this argument.

The packet's numerical claim is an outward enclosure at one point, with
Q16.16 endpoints `[38466,38467]/65536`. The supplied Lean module does not
convert an Arb run/receipt into a proof term of `h`. Fresh compilation therefore
closes normalization and conditional sign transport, not an unconditional
Lean proof of the numerical lower bound.

## Other module scopes

`RHCriticalLineSignV1` gives real completed zeta on the critical line, continuity,
and an interval zero from an assumed endpoint sign change. It does not count all
zeros or exclude off-line zeros. `RHRiemannThetaFormulaV1` proves an exact
theta/Mellin expression using the strong functional-equation pair and actual
Mellin integrability. `RHLambdaLineV1` combines its two conjugate Mellin terms
and retains the pole correction.

`RHFixIntervalV1` proves generic outward fixed-point addition, negation, and
multiplication for real intervals. It supplies no special-function evaluation
certificate. `RHThetaTailV1` proves the nonnegative tail after three theta terms
is at most `4*exp(-16*pi*x)` for the theta variable `x≥1`. That variable is not
a bound on zeta zero height and the result is not a global RH sign theorem.

## Preserved failed attempts

The initial executable orchestration imposed a 4096 MB virtual-address cap.
Lean's thread allocation failed before elaboration even with one worker.
That cap was replaced by observed resident-memory monitoring, retaining
`-M4096`, one CPU, and the wall limit. An original-source attempt also preserved
the missing aggregate `Mathlib.olean` error. The first effective import set
failed because two existing lemmas were not imported. Lean error recovery then
printed `sorryAx`; those failed objects and reports are explicitly rejected and
are never dependencies of the successful run.

A no-argument checker invocation was mistakenly used as a usage probe; it
instead loaded the core environment and was terminated. The separate stop
record identifies that job. Actual target-module checker invocations use
`leanchecker -v <module>` and all seven succeeded. No supplied files were edited.

## RH status

This packet concerns one value on the critical line and exact local analytic
machinery. Even a discharged `h` would establish a positive nonzero value at
that point, not a universal sign statement or RH. No arrow from this point
certificate into the global detecting-packet residual is supplied or asserted.
`rh_proven=false`.
