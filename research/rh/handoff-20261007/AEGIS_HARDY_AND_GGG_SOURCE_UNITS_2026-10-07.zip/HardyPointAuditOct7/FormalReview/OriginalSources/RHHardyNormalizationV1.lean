/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHCriticalLineSignV1

/-!
# Normalize the real completed zeta by a positive Gamma modulus

The amplitude is `‖Gammaℝ (1/2 + it)‖`. Dividing the real completed
zeta by this amplitude preserves its sign. This module uses the same
completed zeta as `RHCriticalLineSignV1`; its name `Xi` denotes Λ.
The point-enclosure hypothesis below is explicit.

Source: https://flintlib.org/doc/acb_dirichlet.html (Hardy Z-functions).
AUTHORITY_EFFECT = NONE.
-/

namespace AEGIS.RHHardyNormalizationV1

open AEGIS.RHCriticalLineSignV1

/-- Positive modulus of the archimedean factor on the critical line. -/
noncomputable def amplitude (t : ℝ) : ℝ := ‖Complex.Gammaℝ (lineAt t)‖

/-- Real completed zeta after division by its positive amplitude. -/
noncomputable def normalized (t : ℝ) : ℝ := (Xi t).re / amplitude t

theorem amplitude_pos (t : ℝ) : 0 < amplitude t := by
  change 0 < ‖Complex.Gammaℝ (lineAt t)‖
  apply norm_pos_iff.mpr
  exact Complex.Gammaℝ_ne_zero_of_re_pos (by rw [lineAt_re]; norm_num)

theorem Xi_re_eq_amplitude_mul (t : ℝ) :
    (Xi t).re = amplitude t * normalized t := by
  rw [normalized, mul_comm]
  exact (div_mul_cancel₀ _ (ne_of_gt (amplitude_pos t))).symm

theorem normalized_pos_iff (t : ℝ) : 0 < normalized t ↔ 0 < (Xi t).re := by
  have ha := amplitude_pos t
  have he := Xi_re_eq_amplitude_mul t
  constructor
  · intro h
    have hp := mul_pos ha h
    rwa [← he] at hp
  · intro h
    by_contra hn
    have hz : normalized t ≤ 0 := le_of_not_gt hn
    have hm := mul_nonpos_of_nonneg_of_nonpos ha.le hz
    rw [← he] at hm
    exact (not_le_of_gt h) hm

/-- Sign transport from an explicit enclosure, without asserting that enclosure. -/
theorem Lambda_60_pos_of_normalized_lower
    (h : (38466 : ℝ) / 65536 ≤ normalized 60) : 0 < (Xi 60).re := by
  apply (normalized_pos_iff 60).mp
  have hl : (0 : ℝ) < 38466 / 65536 := by norm_num
  exact lt_of_lt_of_le hl h

end AEGIS.RHHardyNormalizationV1

#print axioms AEGIS.RHHardyNormalizationV1.amplitude_pos
#print axioms AEGIS.RHHardyNormalizationV1.Xi_re_eq_amplitude_mul
#print axioms AEGIS.RHHardyNormalizationV1.normalized_pos_iff
#print axioms AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower
