# Independent written Hardy normalization review

7 October 2026. Read-only mathematical/source review. No package code, Arb
evaluation, Lean compiler, or kernel replay was executed in this review.
The local Mathlib HEAD is `0df444a360eaa60ab8c11dca51a86af692955474`; the
inspected Mathlib source files have no working-tree diff from that pin.

## Exact mathematical bridge

Let s=1/2+it, w=s/2=1/4+it/2 and gamma=Gamma(w). At this point
Re(s)=1/2>0 and Re(w)=1/4>0, so neither Gamma factor vanishes. The supplied
`RHCriticalLineSignV1.completed_eq_mul` follows from Mathlib's actual
`riemannZeta_def_of_ne_zero` and gives

    Lambda(s)=completedRiemannZeta(s)=GammaR(s)*zeta(s).

Mathlib defines GammaR(s)=pi^(-s/2)*Gamma(s/2). Since pi>0, its principal
complex logarithm is the real log(pi); hence

    GammaR(s)=exp(-log(pi)/4)*exp(-i*t*log(pi)/2)*gamma,
    A(t)=||GammaR(s)||=exp(-log(pi)/4)*|gamma|>0.

Therefore, with the real denominator embedded into the complex numbers,

    Lambda(s)/A(t)
      = exp(-i*t*log(pi)/2)*gamma/|gamma|*zeta(s).

Taking real parts gives exactly the evaluator's Hardy object:

    normalized(t)=Re Lambda(s)/A(t)
      = Re[exp(-i*t*log(pi)/2)*gamma/|gamma|*zeta(s)].

The imported `Xi_im` proves Lambda(s) is real, using conjugation and the
functional equation, without RH. Thus the complex expression on the right
is real as well. Mathlib's possible correction at s=0 is irrelevant here.
The phase has unit modulus and uses angular frequency t; there is no missing
2pi factor or square-root sign choice.

Existing Mathlib ingredients read include `GammaR_def`,
`GammaR_ne_zero_of_re_pos`, `cpow_def_of_ne_zero`, `ofReal_log`, and
`norm_cpow_eq_rpow_re_of_pos`. The bridge is routine composition of these
known facts; it requires no new RH-strength mathematics.

## What the supplied Lean source actually proves

`RHHardyNormalizationV1.lean` defines amplitude as ||GammaR(s)|| and normalized
as Re Lambda(s)/amplitude. Its declared endpoints prove positive amplitude,
Re Lambda=amplitude*normalized, and equivalence of their positive signs.
Its t=60 theorem explicitly assumes

    38466/65536 <= normalized(60).

It does not construct that lower bound, define the FLINT phase expression,
or declare the phase-expression identity above. The imported critical-line
module supplies the zeta/Gamma factorization and reality ingredients, but
the final phase bridge is not assembled in this supplied module. The incoming
kernel receipt is `NOT_EXECUTED`; this review makes no fresh kernel claim.

The Python evaluator's expressions match the exact formulas above. Its
`factor` equals A(t), `phase*zeta` equals the complex Hardy expression, and
`completed` equals Lambda(s). Checking that an imaginary ball or normalization
residual contains zero is a consistency check, not an exact-identity proof.
The Arb-to-Mathlib special-function enclosure is not a Lean proof term.

## Point and sign scope

The incoming Arb receipt reports the single-point outward enclosure
Z(60) in [38466,38467]/65536, at 256-bit computation precision. The 16-bit
fractional format is an export scale, not the computation precision. At that
scale the raw Lambda enclosure is [0,1]/65536, so normalization preserves a
useful numerical sign. No independent numerical replay was performed here.

If that enclosure and its exact-object bridge are accepted, A(60)>0 gives
Lambda(1/2+60i)>0 and zeta(1/2+60i) is nonzero. It provides no interval-wide
positivity, off-line-zero exclusion, universal Weil sign or RH proof.

The repository identifier `Xi` means Lambda. The usual entire xi instead is

    xi(s)=s(s-1)Lambda(s)/2
         =-(t^2+1/4)A(t)Z(t)/2,

so its real sign is opposite on this line. The evaluator's `standard_xi`
formula correctly includes this factor.

## Source identities read

| Source | SHA256 |
|---|---|
| Incoming `RHHardyNormalizationV1.lean` | `372b576a9b65471ecbfdee4445177c94f9939e04393833d63653cc36d991ed19` |
| Incoming `hardy_interval_v1.py` | `c173c3d0bbeb2974a7628ed7bbc6392ab58d50b11aafdf4146ceef69d17fe587` |
| Incoming `RHCriticalLineSignV1.lean` | `a8b0181eac7a0bc05592bb330c4808291e8bdabc88a801e9108f71e17875759c` |
| Pinned Mathlib `RiemannZeta.lean` | `db9f37f08bcce379c502549f604c0e98bf4a39b3a3440606861bbac847f2a1a9` |
| Pinned Mathlib `Gamma/Deligne.lean` | `ea87e1b821adbe190be9655314f5ab3fa299276dd413a1401faa175437726fcb` |

Disposition: the mathematical normalization matches; the supplied formal
t=60 endpoint remains conditional on its numerical lower-bound argument.
No defect in the ordinary normalization formula was found.
