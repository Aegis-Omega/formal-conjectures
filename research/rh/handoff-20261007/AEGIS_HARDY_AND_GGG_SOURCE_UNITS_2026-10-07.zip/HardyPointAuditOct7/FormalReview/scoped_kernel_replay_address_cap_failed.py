#!/usr/bin/env python3
"""Bounded fresh Hardy closure replay; no incoming edit or dependency download."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import re
import resource
import subprocess
import time

OUT = Path(__file__).resolve().parent
SRC = OUT.parent / 'Incoming/AEGIS_Hardy_Q16_T60_V1'
BIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
LEAN = BIN / 'lean'
CHECKER = BIN / 'leanchecker'
CACHE = Path('/workspace/aegis-research/work/GoalContinuation20261001/AnalyticReplay/actual-context-20261003T004616.608552Z/mathlib-only')
PROVIDER = Path('/workspace/aegis-research/provider/.lake/packages')
MODULES = ('RHCriticalLineSignV1', 'RHRiemannThetaFormulaV1', 'RHLambdaLineV1',
           'RHFixIntervalV1', 'RHThetaTailV1', 'RHHardyNormalizationV1')
WALL_SECONDS = 90
MEMORY_MB = 4096
EXPECTED = (
    'AEGIS.RHCriticalLineSignV1.Xi_im',
    'AEGIS.RHCriticalLineSignV1.exists_zero_of_sign_change',
    'AEGIS.RHRiemannThetaFormulaV1.completedRiemannZeta_eq',
    'AEGIS.RHLambdaLineV1.Xi_re_eq',
    'AEGIS.RHFixIntervalV1.Iv.mem_add',
    'AEGIS.RHFixIntervalV1.Iv.mem_mul',
    'AEGIS.RHThetaTailV1.theta_tail_bound',
    'AEGIS.RHHardyNormalizationV1.amplitude_pos',
    'AEGIS.RHHardyNormalizationV1.Xi_re_eq_amplitude_mul',
    'AEGIS.RHHardyNormalizationV1.normalized_pos_iff',
    'AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower')


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def limits():
    available = sorted(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {available[0]})
    cap = MEMORY_MB * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (cap, cap))


def main():
    run = OUT / ('Run-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
    run.mkdir(); (run/'lib').mkdir(); (run/'logs').mkdir(); (run/'EffectiveSources').mkdir()
    paths = [str(run/'lib'), str(CACHE)]
    for package in ('LeanSearchClient','Qq','aesop','batteries','importGraph','plausible','proofwidgets'):
        p = PROVIDER/package/'.lake/build/lib/lean'
        if not p.is_dir(): raise RuntimeError('missing cached package ' + str(p))
        paths.append(str(p))
    env = dict(os.environ)
    env['PATH'] = str(BIN) + os.pathsep + env.get('PATH','')
    env['LEAN_PATH'] = os.pathsep.join(paths)
    env['ELAN_TOOLCHAIN'] = 'leanprover/lean4:v4.33.1'
    receipt = {'schema':'AEGIS_HARDY_BOUNDED_SCOPED_KERNEL_REPLAY_V1',
               'status':'RUNNING','run_directory':str(run), 'jobs':[],
               'LEAN_PATH':env['LEAN_PATH'], 'wall_seconds_per_job':WALL_SECONDS,
               'address_space_MB_per_job':MEMORY_MB,'cpu_affinity_count':1,'compiler_threads':1,
               'compiler_sha256':sha(LEAN),'checker_sha256':sha(CHECKER),
               'baseline_commit':'70ed9dd8ccc3365c7b5734b781a17f591a0dde0f',
               'mathlib_commit':'0df444a360eaa60ab8c11dca51a86af692955474',
               'cached_dependencies_reused':True,'full_mathlib_source_rebuild':False,
               'rh_proven':False,'t60_numeric_enclosure_kernel_verified':False,
               'numeric_lower_bound_is_explicit_hypothesis':True}

    def save():
        (run/'RECEIPT.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
        (OUT/'LATEST_RUN.json').write_text(json.dumps({'run_directory':str(run)},indent=2)+'\n')

    def execute(label, command):
        start=time.monotonic();code=None;timed_out=False
        try:
            p=subprocess.run(command,cwd=run/'EffectiveSources',env=env,
                             capture_output=True,text=True,timeout=WALL_SECONDS,preexec_fn=limits)
            code=p.returncode;stdout=p.stdout;stderr=p.stderr
        except subprocess.TimeoutExpired as e:
            timed_out=True
            stdout=e.stdout or '';stderr=e.stderr or ''
            if isinstance(stdout,bytes):stdout=stdout.decode(errors='replace')
            if isinstance(stderr,bytes):stderr=stderr.decode(errors='replace')
        log=run/'logs'/(label+'.log');log.write_text(stdout+stderr)
        job={'label':label,'argv':[str(c)for c in command],'exit_code':code,
             'timed_out':timed_out,'wall_seconds':time.monotonic()-start,
             'log':str(log),'log_sha256':sha(log)}
        receipt['jobs'].append(job);save()
        print(json.dumps({'label':label,'exit_code':code,'timed_out':timed_out,
                          'wall_seconds':job['wall_seconds']}),flush=True)
        return code==0 and not timed_out,stdout+stderr

    ok, version=execute('compiler_version',[LEAN,'--version'])
    receipt['compiler_version']=version.strip()
    if not ok or '4.33.1' not in version or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in version:
        receipt['status']='COMPILER_PIN_FAILURE';save();return
    execute('compiler_help',[LEAN,'--help'])
    execute('checker_usage',[CHECKER])
    receipt['initial_original_source_attempt']=execute('original_RHCriticalLineSignV1',
        [LEAN,'--trust=0','-j1','-M4096','-DwarningAsError=true','-o',run/'lib/OriginalSign.olean',
         '--root='+str(OUT/'OriginalSources'),OUT/'OriginalSources/RHCriticalLineSignV1.lean'])[0]
    # The unavailable aggregate import is replaced ONLY in new effective copies.
    imports=('import Mathlib.NumberTheory.LSeries.RiemannZeta\n'
             'import Mathlib.Analysis.SpecificLimits.Basic\n'
             'import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds\n'
             'import Mathlib.Tactic\n')
    patches=[];bindings=[]
    for module in MODULES:
        original=OUT/'OriginalSources'/(module+'.lean');text=original.read_text()
        effective=text.replace('import Mathlib\n',imports)
        target=run/'EffectiveSources'/(module+'.lean');target.write_text(effective)
        patches.extend(difflib.unified_diff(text.splitlines(True),effective.splitlines(True),
                      fromfile='OriginalSources/'+original.name,tofile='EffectiveSources/'+target.name))
        bindings.append({'module':module,'original_sha256':sha(original),
                         'effective_sha256':sha(target),'import_only_adapter':text!=effective})
    (run/'IMPORT_COMPATIBILITY.patch').write_text(''.join(patches))
    receipt['source_bindings']=bindings;save()
    succeeded=set(); logs=[]
    deps={'RHLambdaLineV1':{'RHCriticalLineSignV1','RHRiemannThetaFormulaV1'},
          'RHHardyNormalizationV1':{'RHCriticalLineSignV1'}}
    for module in MODULES:
        if not deps.get(module,set())<=succeeded:
            receipt['jobs'].append({'label':'compile_'+module,'status':'SKIPPED_DEPENDENCY_FAILURE'});save();continue
        ok,log=execute('compile_'+module,[LEAN,'--trust=0','-j1','-M4096','-DwarningAsError=true',
                                        '-o',run/'lib'/(module+'.olean'),run/'EffectiveSources'/(module+'.lean')])
        if ok:succeeded.add(module)
        logs.append(log)
    receipt['compiled_modules']=sorted(succeeded)
    if len(succeeded)!=len(MODULES):
        receipt['status']='EFFECTIVE_COMPILE_FAILED';save();return
    for module in MODULES:
        ok,_=execute('checker_'+module,[CHECKER,'-v',module])
        if not ok:receipt['status']='CHECKER_FAILED';save();return
    reports={}
    for name, ax in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",'\n'.join(logs)):
        reports[name]=sorted({x.strip()for x in ax.split(',')if x.strip()})
    receipt['axiom_reports']=reports
    if not set(EXPECTED)<=reports.keys() or any(not set(v)<={'propext','Classical.choice','Quot.sound'}for v in reports.values()):
        receipt['status']='AXIOM_SCOPE_FAILED';save();return
    probe=run/'EffectiveSources'/'EndpointAudit.lean'
    probe.write_text(''.join('import '+m+'\n'for m in MODULES)+'\n'+
                     '\n'.join('#check '+n+'\n#print '+n+'\n#print axioms '+n for n in EXPECTED)+'\n')
    ok,_=execute('endpoint_type_axiom_audit',[LEAN,'--trust=0','-j1','-M4096','-DwarningAsError=true',
                                          '-o',run/'lib/EndpointAudit.olean',probe])
    if not ok:receipt['status']='ENDPOINT_AUDIT_FAILED';save();return
    ok,_=execute('checker_EndpointAudit',[CHECKER,'-v','EndpointAudit'])
    receipt['status']='PASS_SCOPED_EFFECTIVE_CLOSURE'if ok else'ENDPOINT_CHECKER_FAILED'
    receipt['kernel_normalization_verified']=ok
    save()


if __name__=='__main__':main()
