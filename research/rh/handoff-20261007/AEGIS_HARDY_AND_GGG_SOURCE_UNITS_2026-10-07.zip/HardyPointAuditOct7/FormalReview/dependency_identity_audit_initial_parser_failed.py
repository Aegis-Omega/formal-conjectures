#!/usr/bin/env python3
"""Bind the source-import closure and resolved reused objects, without rebuilding it.

This is an identity audit, not a second kernel proof or a claim that source-import
parsing reads the OLEAN header. Actual --trust=0 and leanchecker results are separate.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

HERE = Path(__file__).resolve().parent
RUN = Path(json.loads((HERE / 'LATEST_RUN.json').read_text())['run_directory'])
RECEIPT = json.loads((RUN / 'RECEIPT.json').read_text())
TOOLCHAIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1')
MATHLIB = Path('/workspace/aegis-research/mathlib')
PROVIDER = Path('/workspace/aegis-research/provider/.lake/packages')
OLD = Path('/workspace/aegis-research/work/GoalContinuation20261001/AnalyticReplay')
PATHS = [Path(p) for p in RECEIPT['LEAN_PATH'].split(os.pathsep)]
PATHS.append(TOOLCHAIN / 'lib/lean')
PKG = {'Aesop':'aesop', 'Batteries':'batteries', 'Qq':'Qq',
       'LeanSearchClient':'LeanSearchClient', 'Plausible':'plausible',
       'ProofWidgets':'proofwidgets', 'ImportGraph':'importGraph'}


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1048576): h.update(chunk)
    return h.hexdigest()


def imports(source):
    # Imports are outside comments. Remove nested Lean block comments, preserve lines.
    text=source.read_text(); out=[]; depth=0; i=0
    while i<len(text):
        if text[i:i+2]=='/-':depth+=1;i+=2;continue
        if depth and text[i:i+2]=='-/':depth-=1;i+=2;continue
        if depth:
            if text[i]=='\n':out.append('\n')
            i+=1;continue
        if text[i:i+2]=='--':
            end=text.find('\n',i)
            if end==-1:break
            out.append('\n');i=end+1;continue
        out.append(text[i]);i+=1
    clean=''.join(out)
    result=[] if re.search(r'^\s*prelude\s*$',clean,re.M) else ['Init']
    for m in re.finditer(r'^\s*(?:(?:public|private|meta)\s+)*import\s+([^\n]+)',clean,re.M):
        result.extend(m.group(1).strip().split())
    return sorted(set(result))


def object_for(name):
    rel=Path(*name.split('.')).with_suffix('.olean')
    for base in PATHS:
        path=base/rel
        if path.is_file():return path
    return None


def source_for(name,obj):
    rel=Path(*name.split('.')).with_suffix('.lean')
    fresh=RUN/'EffectiveSources'/rel
    if fresh.is_file():return fresh,'fresh_effective_source'
    # A cached build's own source snapshot is the strongest recovered identity.
    real=obj.resolve() if obj else None
    if real and '/lib/lean/' in str(real):
        prefix=str(real).split('/lib/lean/',1)[0]
        snapshot=Path(prefix)/'sources'/rel
        if snapshot.is_file():return snapshot,'cached_build_source_snapshot'
    head=name.split('.')[0]
    if head=='Mathlib':
        path=MATHLIB/rel
        if path.is_file():return path,'pinned_mathlib_source'
    if head in {'Init','Lean','Std'}:
        path=TOOLCHAIN/'src/lean'/rel
        if path.is_file():return path,'installed_toolchain_source'
    if head in PKG:
        path=PROVIDER/PKG[head]/rel
        if path.is_file():return path,'available_package_source'
    snapshot=OLD/'build-20261001T083533Z/sources'/rel
    if snapshot.is_file():return snapshot,'recovered_historical_source_snapshot'
    return None,'SOURCE_UNAVAILABLE'


def main():
    pending=['EndpointAudit']; records={}; missing_objects=[]; missing_sources=[]
    while pending:
        name=pending.pop()
        if name in records:continue
        obj=object_for(name); src,kind=source_for(name,obj)
        entry={'module':name,'source_kind':kind}
        if obj:
            entry.update({'object_path':str(obj),'object_resolved_path':str(obj.resolve()),
                          'object_sha256':digest(obj),'object_bytes':obj.stat().st_size})
            companions={}
            for suffix in ('.olean.private','.olean.server','.ir'):
                companion=obj.with_suffix(suffix)
                if companion.is_file(): companions[str(companion)] = digest(companion)
            entry['available_object_companion_bindings']=companions
        else:missing_objects.append(name)
        if src:
            entry.update({'source_path':str(src),'source_sha256':digest(src),
                          'imports':imports(src)})
            if name.startswith('Mathlib.'):
                rel=Path(*name.split('.')).with_suffix('.lean')
                original=MATHLIB/rel
                if original.is_file():
                    entry['pinned_mathlib_source_sha256']=digest(original)
                    entry['effective_source_differs_from_pinned_source']=digest(src)!=digest(original)
            pending.extend(entry['imports'])
        else:missing_sources.append(name)
        records[name]=entry
    status='IDENTITIES_RECORDED' if not missing_objects else 'OBJECT_IDENTITY_GAP'
    report={'schema':'AEGIS_HARDY_SOURCE_IMPORT_DEPENDENCY_IDENTITIES_V1',
            'status':status,'mathlib_commit':RECEIPT['mathlib_commit'],
            'fresh_replay_receipt':str(RUN/'RECEIPT.json'),
            'fresh_replay_receipt_sha256':digest(RUN/'RECEIPT.json'),
            'scope':'Parsed source-import closure; resolved actual LEAN_PATH objects and available companions bound. Sources are identified as snapshots/current pinned sources, not claimed rebuilt or binary-source attested by this audit.',
            'module_count':len(records),'missing_objects':sorted(missing_objects),
            'missing_sources':sorted(missing_sources),'modules':dict(sorted(records.items())),
            'full_dependency_source_rebuild':False,'rh_proven':False}
    dest=HERE/'DEPENDENCY_IDENTITIES.json'
    dest.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':status,'modules':len(records),
                      'missing_objects':missing_objects,'missing_sources':missing_sources,
                      'sha256':digest(dest)}))


if __name__=='__main__':main()
