import RHCriticalLineSignV1
import RHRiemannThetaFormulaV1
import RHLambdaLineV1
import RHFixIntervalV1
import RHThetaTailV1
import RHHardyNormalizationV1

#check AEGIS.RHCriticalLineSignV1.Xi_im
#print AEGIS.RHCriticalLineSignV1.Xi_im
#print axioms AEGIS.RHCriticalLineSignV1.Xi_im
#check AEGIS.RHCriticalLineSignV1.exists_zero_of_sign_change
#print AEGIS.RHCriticalLineSignV1.exists_zero_of_sign_change
#print axioms AEGIS.RHCriticalLineSignV1.exists_zero_of_sign_change
#check AEGIS.RHRiemannThetaFormulaV1.completedRiemannZeta_eq
#print AEGIS.RHRiemannThetaFormulaV1.completedRiemannZeta_eq
#print axioms AEGIS.RHRiemannThetaFormulaV1.completedRiemannZeta_eq
#check AEGIS.RHLambdaLineV1.Xi_re_eq
#print AEGIS.RHLambdaLineV1.Xi_re_eq
#print axioms AEGIS.RHLambdaLineV1.Xi_re_eq
#check AEGIS.RHFixIntervalV1.Iv.mem_add
#print AEGIS.RHFixIntervalV1.Iv.mem_add
#print axioms AEGIS.RHFixIntervalV1.Iv.mem_add
#check AEGIS.RHFixIntervalV1.Iv.mem_mul
#print AEGIS.RHFixIntervalV1.Iv.mem_mul
#print axioms AEGIS.RHFixIntervalV1.Iv.mem_mul
#check AEGIS.RHThetaTailV1.theta_tail_bound
#print AEGIS.RHThetaTailV1.theta_tail_bound
#print axioms AEGIS.RHThetaTailV1.theta_tail_bound
#check AEGIS.RHHardyNormalizationV1.amplitude_pos
#print AEGIS.RHHardyNormalizationV1.amplitude_pos
#print axioms AEGIS.RHHardyNormalizationV1.amplitude_pos
#check AEGIS.RHHardyNormalizationV1.Xi_re_eq_amplitude_mul
#print AEGIS.RHHardyNormalizationV1.Xi_re_eq_amplitude_mul
#print axioms AEGIS.RHHardyNormalizationV1.Xi_re_eq_amplitude_mul
#check AEGIS.RHHardyNormalizationV1.normalized_pos_iff
#print AEGIS.RHHardyNormalizationV1.normalized_pos_iff
#print axioms AEGIS.RHHardyNormalizationV1.normalized_pos_iff
#check AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower
#print AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower
#print axioms AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower
