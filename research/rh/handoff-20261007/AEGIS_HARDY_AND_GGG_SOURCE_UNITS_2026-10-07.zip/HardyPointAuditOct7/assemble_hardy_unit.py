"""Freeze the uploaded point packet and current, explicitly scoped replays.

Run only after the participating agents have frozen their source manifests.
No proof flag is inferred from a successful archive or source-copy check.
"""
from pathlib import Path
import hashlib
import json
import shutil

BASE = Path('/workspace/aegis-research/evidence/hardy-q16-t60-oct7')
WORK = Path('/workspace/aegis-research/work')
TARGET = WORK / 'HardyPointAuditOct7'

def demand(condition, message):
    if not condition:
        raise ValueError(message)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

def copy_file(source, relative):
    dest = TARGET / relative
    demand(not dest.exists(), 'refusing overwrite: ' + str(dest))
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
    demand(source.read_bytes() == dest.read_bytes(), 'copy changed bytes')
    demand(source.stat().st_mode & 0o777 == dest.stat().st_mode & 0o777,
           'copy changed file mode')

def copy_source_tree(name):
    source = BASE / name
    demand(source.is_dir(), 'missing frozen review: ' + name)
    for path in sorted(source.rglob('*')):
        if not path.is_file():
            continue
        parts = path.relative_to(source).parts
        if 'lib' in parts or '__pycache__' in parts:
            continue
        demand(not path.is_symlink(), 'symlink in source unit')
        copy_file(path, Path(name) / path.relative_to(source))

demand(not TARGET.exists(), 'source unit already exists; do not overwrite')
demand(digest(WORK / 'CHECKPOINT.md') ==
       '3a333ea557a91bdc8f9724dc18e3d14b4d6561942a246f678b88e4467b2403ff',
       'original checkpoint changed')
demand(digest(WORK / 'aegis_compute.py') ==
       '08f2e0a21242a6762dd18989b83666ca12f1ddf802a88e12291c23f971618b17',
       'original driver changed')
archive = load(BASE / 'ARCHIVE_SOURCE_MANIFEST.json')
zip_path = Path(archive['zip_path'])
demand(digest(zip_path) == archive['zip_sha256'], 'uploaded zip changed')
for row in archive['bindings']:
    path = BASE / 'Incoming' / row['path']
    demand(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'],
           'uploaded source changed: ' + row['path'])
num = load(BASE / 'CURRENT_NUMERIC_REPLAY_RECEIPT.json')
demand(num['receipt_byte_identical'] is True and num['rh_proven'] is False,
       'incorrect numeric scope')
formal_run = Path(load(BASE / 'FormalReview/LATEST_RUN.json')['run_directory'])
formal = load(formal_run / 'RECEIPT.json')
demand(formal['status'] == 'PASS_SCOPED_EFFECTIVE_CLOSURE', 'formal replay failed')
demand(formal['numeric_lower_bound_is_explicit_hypothesis'] is True,
       'numeric premise disappeared')
demand(formal['t60_numeric_enclosure_kernel_verified'] is False,
       'unexpected quantitative formal claim')
# The second agent's review and the additional phase composition have separate
# exact receipts. Their file names are read from a root-authored final pointer.
pointers = load(BASE / 'FINAL_REVIEW_POINTERS.json')
for row in pointers['bindings']:
    path = Path(row['path'])
    demand(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'],
           'frozen review changed: ' + str(path))
independent = load(Path(pointers['independent_review_receipt']))
phase = load(Path(pointers['phase_transport_receipt']))
independent_phase = load(Path(pointers['independent_phase_receipt']))
demand(independent.get('status') == 'PASS_SCOPED', 'independent review failed')
demand(phase.get('status') == 'PASS_SCOPED_PHASE_TRANSPORT',
       'phase composition failed')
demand(independent_phase.get('status') == 'PASS_SCOPED',
       'independent phase replay failed')
demand(pointers['rh_proven'] is False, 'RH was not closed by this point packet')
TARGET.mkdir()
copy_file(zip_path, Path('PACKET.zip'))
for name in ('ARCHIVE_SOURCE_MANIFEST.json', 'CURRENT_NUMERIC_REPLAY_RECEIPT.json',
             'CURRENT_RECEIPT_T60.json', 'HARDY_MATHEMATICAL_REVIEW.md',
             'FINAL_REVIEW_POINTERS.json', 'HARDY_CAUSAL_DAG_ADDENDUM.json'):
    copy_file(BASE / name, Path(name))
for name in ('Incoming', 'NumericLogs', 'FormalReview', 'IndependentReview',
             'PhaseTransport', 'PhaseIndependentReview'):
    copy_source_tree(name)
copy_file(Path(__file__), Path('assemble_hardy_unit.py'))
readme = (BASE / 'FINAL_UNIT_README.md').read_bytes()
(TARGET / 'README.md').write_bytes(readme)
result = {
    'schema': 'AEGIS_CURRENT_HARDY_SOURCE_BOUND_POINT_AUDIT_V1',
    'uploaded_zip_sha256': archive['zip_sha256'],
    'baseline_formal_conjectures_commit': formal['baseline_commit'],
    'mathlib_commit': formal['mathlib_commit'],
    'lean_compiler_commit': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6',
    'lean_version': '4.33.1',
    'point': {'numerator': '60', 'denominator': '1'},
    'outward_Q16_enclosure': num['one_point_enclosure'],
    'numeric_receipt_byte_identical_to_upload': True,
    'numeric_trust': 'python-flint 0.9.0 / Arb special functions',
    'fresh_scoped_six_module_source_replay': True,
    'full_transitive_Mathlib_source_rebuild': False,
    'cached_dependencies_reused_and_identified': True,
    'original_sources_unchanged': True,
    'four_explicit_import_only_adapters': True,
    'exact_evaluator_phase_identity_kernel_verified': True,
    'phase_transport_source_sha256': phase['source_sha256'],
    'quantitative_lower_bound_is_Lean_theorem': False,
    'quantitative_lower_bound_argument':
        '(38466 : Real) / 65536 <= AEGIS.RHHardyNormalizationV1.normalized 60',
    'global_Weil_sign_discharged': False,
    'rh_proven': False,
    'final_RH_theorem': None,
    'unresolved_global_obligation':
        'AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign',
    'source_review_pointer_sha256': digest(BASE / 'FINAL_REVIEW_POINTERS.json'),
    'phase_receipt_sha256': digest(Path(pointers['phase_transport_receipt'])),
    'independent_review_receipt_sha256':
        digest(Path(pointers['independent_review_receipt'])),
    'remote_written': False,
}
(TARGET / 'RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
bindings = []
for path in sorted(TARGET.rglob('*')):
    if path.is_file():
        bindings.append({'path': str(path.relative_to(TARGET)),
                         'bytes': path.stat().st_size,
                         'sha256': digest(path),
                         'mode': oct(path.stat().st_mode & 0o777)})
manifest = {'schema': 'AEGIS_HARDY_FROZEN_SOURCE_UNIT_V1',
            'self_excluded': 'SOURCE_MANIFEST.json',
            'bindings': bindings,
            'build_objects_retained_externally': True,
            'all_lib_directories_excluded': True,
            'rh_proven': False}
(TARGET / 'SOURCE_MANIFEST.json').write_text(
    json.dumps(manifest, sort_keys=True, indent=2) + '\n')
print(json.dumps({'target': str(TARGET), 'file_count': len(bindings) + 1,
                  'manifest_sha256': digest(TARGET / 'SOURCE_MANIFEST.json'),
                  'result_sha256': digest(TARGET / 'RESULT.json'),
                  'rh_proven': False}, indent=2))
