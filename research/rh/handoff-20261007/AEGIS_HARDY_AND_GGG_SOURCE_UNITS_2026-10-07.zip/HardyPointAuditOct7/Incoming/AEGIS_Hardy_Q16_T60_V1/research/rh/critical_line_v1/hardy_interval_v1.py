"""Arb point evaluation of Hardy Z, with exact outward dyadic export.

No binary float enters the certified path. This is an Arb receipt, not a Lean
special-function proof. It is separate from the legacy hardware runtime.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

import flint
from flint import acb, arb, ctx

SCHEMA = "aegis.rh.hardy-point-arb.v1"
EXPECTED_SOURCE_BINDINGS_SHA256 = "8e46a8800e980d1593ef6c8efbef394b210dce1d89e0ecd55a1f27b2e288bc48"


def strict_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result

    def bad_constant(value):
        raise ValueError("non-finite JSON constant: " + value)

    return json.loads(text, object_pairs_hook=pairs, parse_constant=bad_constant)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def rational(value):
    require(isinstance(value, str), "rational input must be a string")
    return Fraction(value)


def endpoint(value):
    require(value.is_finite() and value.is_exact(), "endpoint must be finite and exact")
    mantissa, exponent = map(int, value.man_exp())
    return Fraction(mantissa * (1 << exponent)) if exponent >= 0 else Fraction(mantissa, 1 << -exponent)


def bounds(value):
    require(value.is_finite(), "non-finite ball")
    return endpoint(value.lower()), endpoint(value.upper())


def pack(q):
    return {"numerator": str(q.numerator), "denominator": str(q.denominator)}


def unpack(item):
    require(isinstance(item, dict) and set(item) == {"numerator", "denominator"}, "bad rational object")
    require(all(isinstance(v, str) for v in item.values()), "rational fields must be strings")
    n, d = int(item["numerator"]), int(item["denominator"])
    require(d > 0, "denominator must be positive")
    q = Fraction(n, d)
    require(pack(q) == item, "rational object must be canonical")
    return q


def quantize(lo, hi, fractional_bits):
    require(type(fractional_bits) is int and 0 <= fractional_bits <= 4096, "invalid fractional bits")
    require(lo <= hi, "inverted interval")
    scale = 1 << fractional_bits
    low = (lo.numerator * scale) // lo.denominator
    high = -((-hi.numerator * scale) // hi.denominator)
    return {"fractional_bits": fractional_bits, "lo": str(low), "hi": str(high),
            "sign": "POSITIVE" if low > 0 else "NEGATIVE" if high < 0 else "UNRESOLVED"}


def ball_record(value, fractional_bits):
    lo, hi = bounds(value)
    return {"lower": pack(lo), "upper": pack(hi), "display": value.str(60),
            "dyadic": quantize(lo, hi, fractional_bits)}


def evaluate(t, precision_bits=256, fractional_bits=16):
    require(isinstance(t, Fraction), "t must be exact rational")
    require(type(precision_bits) is int and 128 <= precision_bits <= 4096, "invalid Arb precision")
    require(type(fractional_bits) is int and 0 <= fractional_bits <= 4096, "invalid fractional bits")
    with ctx.workprec(precision_bits):
        tr = arb(t.numerator) / t.denominator
        s = acb(arb(1) / 2, tr)
        gamma = (s / 2).gamma()
        gamma_abs = abs(gamma)
        require(gamma_abs > 0, "cannot exclude zero Gamma modulus")
        log_pi = arb.pi().log()
        factor = (-log_pi / 4).exp() * gamma_abs
        require(factor > 0, "amplitude is not strictly positive")
        zeta = s.zeta()
        # Gamma/|Gamma| chooses the phase directly, with no square-root branch.
        phase = acb(0, -tr * log_pi / 2).exp() * gamma / gamma_abs
        hardy = phase * zeta
        completed = (-s * log_pi / 2).exp() * gamma * zeta
        xi_entire = s * (s - 1) * completed / 2
        residual = completed - factor * hardy
        require(hardy.imag.contains(0), "Hardy imaginary enclosure excludes zero")
        require(completed.imag.contains(0), "completed imaginary enclosure excludes zero")
        require(residual.contains(0), "normalization consistency residual excludes zero")
        correction = Fraction(1, 1) / (Fraction(1, 4) + t * t)
        return {
            "t": pack(t), "t_squared": pack(t * t),
            "precision_bits": precision_bits, "fractional_bits": fractional_bits,
            "hardy_Z": ball_record(hardy.real, fractional_bits),
            "completed_Lambda": ball_record(completed.real, fractional_bits),
            "standard_xi": ball_record(xi_entire.real, fractional_bits),
            "positive_amplitude": ball_record(factor, fractional_bits),
            "correction": pack(correction),
            "correction_dyadic": quantize(correction, correction, fractional_bits),
            "hardy_imag": ball_record(hardy.imag, fractional_bits),
            "completed_imag": ball_record(completed.imag, fractional_bits),
            "normalization_residual": {
                "real": ball_record(residual.real, fractional_bits),
                "imag": ball_record(residual.imag, fractional_bits)},
        }


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_sources(package):
    manifest_path = package / "source_bindings.json"
    require(sha256(manifest_path) == EXPECTED_SOURCE_BINDINGS_SHA256, "trusted source manifest changed")
    manifest = strict_json(manifest_path.read_text())
    require(manifest["formal_head"] == "70ed9dd8ccc3365c7b5734b781a17f591a0dde0f", "wrong formal head")
    for item in manifest["sources"]:
        data = (package / item["local_path"]).read_bytes()
        require(hashlib.sha256(data).hexdigest() == item["sha256"], "source SHA256 mismatch: " + item["path"])
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        require(blob == item["git_blob"], "Git blob mismatch: " + item["path"])
    return sha256(manifest_path)


def generate(t, precision_bits, fractional_bits, package):
    return {
        "schema": SCHEMA,
        "source_bindings_sha256": check_sources(package),
        "evaluator_sha256": sha256(Path(__file__).resolve()),
        "python_flint_version": flint.__version__,
        "status": "ARB_POINT_CERTIFIED",
        "kernel_verified": False,
        "formal_special_function_enclosure": False,
        "authority_effect": "NONE",
        "scope": "ONE_RATIONAL_POINT",
        "evaluation": evaluate(t, precision_bits, fractional_bits),
    }


def verify(receipt, package):
    require(isinstance(receipt, dict) and receipt.get("schema") == SCHEMA, "wrong receipt schema")
    ev = receipt["evaluation"]
    require(isinstance(ev, dict), "bad evaluation")
    t = unpack(ev["t"])
    expected = generate(t, ev["precision_bits"], ev["fractional_bits"], package)
    require(canonical(receipt) == canonical(expected), "receipt differs from exact-source Arb replay")
    return {"status": "ARB_REPLAY_VERIFIED", "kernel_verified": False,
            "t": ev["t"], "dyadic": ev["hardy_Z"]["dyadic"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--t", default="60")
    parser.add_argument("--precision", type=int, default=256)
    parser.add_argument("--fractional-bits", type=int, default=16)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--verify", type=Path)
    args = parser.parse_args()
    package = Path(__file__).resolve().parents[3]
    try:
        result = verify(strict_json(args.verify.read_text()), package) if args.verify else generate(
            rational(args.t), args.precision, args.fractional_bits, package)
        output = json.dumps(result, indent=2, sort_keys=True) + "\n"
        if args.out:
            args.out.write_text(output)
        else:
            print(output, end="")
        return 0
    except (ValueError, KeyError, TypeError, ZeroDivisionError, OSError) as exc:
        print(json.dumps({"status": "REJECTED", "reason": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
