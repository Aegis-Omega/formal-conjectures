# Exact-source fixed-point audit

Observed 2026-10-07. This is a read-only source audit and local execution of existing Python functions; no repository write, Lean compilation, hosted replay, or admission was performed.

| Source | Exact ref | Git blob |
|---|---|---|
| Aegis-Omega/AEGIS-OMEGA: sovereign-omega-v2/python/hardware_config.py | 495bfd85d79abcb2b4f6898fe9c156488492426a | 2a269fc640ce93341480c2a8d764003a381eff7e |
| tarikskalic33/formal-conjectures: research/rh/critical_line_v1/RHFixIntervalV1.lean | 70ed9dd8ccc3365c7b5734b781a17f591a0dde0f | 0ee94b9be264c170986500bc95598eb5a7e365f6 |
| tarikskalic33/formal-conjectures: research/rh/critical_line_v1/fixmirror.py | 70ed9dd8ccc3365c7b5734b781a17f591a0dde0f | f557a641fbd67ee948c8d0c3ea134f79cc62a9b9 |
| tarikskalic33/formal-conjectures: research/rh/critical_line_v1/README.md | 70ed9dd8ccc3365c7b5734b781a17f591a0dde0f | e56f09335fc9b6f185a5a204cc94915420614ed3 |

The default-branch hardware_config.py fetch returned the same Git blob. Each local source file was checked against its Git blob ID using SHA1("blob " + length + NUL + source_bytes).

## Source conclusions

hardware_config.py fixes INT_SHIFT_BITS=16 and INT_SCALE=65536. It supplies point operations and no enclosing error intervals. Its INT_MAX is a sentinel; multiplication and conversion do not enforce signed-32-bit width. It does not declare 60 or 3600 time constants.

RHFixIntervalV1.lean expressly credits the hardware_config.py Q16.16 idea. Its precision p is arbitrary, and its integers are unbounded. It defines Iv.Mem, add, neg, and outward-rounded four-corner multiplication, with proof scripts for mem_add, mem_neg and mem_mul. It contains no reciprocal, division, square-root, log, exp, sin, cos, or analytic integral-enclosure theorem.

fixmirror.py already defaults to P=128, selected by FIXP. It implements rational input conversion and interval reciprocal with asserted domain checks. Its constructor and reciprocal validation disappear with python -O. Float rendering in .f() is display only. Its title states the full numerical enclosure is rigorous **given** the needed enclosure lemmas and is a design for a Lean checker.

## Reproduced point-arithmetic limitations

| Operation | Observed result | Mathematical implication |
|---|---:|---|
| to_fixed(-0.1) | -6553 | Conversion truncates toward zero; exact rational -1/10 outward bounds are [-6554,-6553]. |
| fixed_mul(-1,1) | -1 | Product is floor-rounded only; the exact raw product is -1/65536, between raw endpoints -1 and 0. |
| fixed_div(1,0) | 2147483647 | A finite sentinel cannot enclose an undefined real quotient. |
| fixed_sqrt(-1) | 0 | A negative real square-root input is silently mapped to zero. |
| fixed_sqrt(65535) | 65280 | Full-resolution floor is isqrt(65535*65536)=65535; early integer sqrt loses 255 raw LSBs. |
| fixed_sqrt(2) | 256 | Full-resolution floor is isqrt(2*65536)=362; early integer sqrt loses 106 raw LSBs. |

_log2_fixed converts through Python float/math.log2 with no rigorous error bound. These point functions can be runtime approximations; they should not be used as certified real enclosures.

## Smallest isolated adapter

Keep the hardware inference scale and existing runtime signatures. Add a separate exact rational/integer enclosure module matching RHFixIntervalV1: [lo,hi]*2^-p, outward rational conversion, add, neg, four-corner product; reject reversed intervals, float input and mismatched precision using exceptions that remain active under -O. Only add reciprocal/division with explicit zero exclusion and an independent Lean soundness lemma. Do not claim the adapter certifies analytic functions until their error lemmas and the formula bridge compile.

For t=60, the exact rational correction is 4/14401. At p=16 its raw enclosing interval is [18,19], width 1/65536. A value of order 10^-21 cannot have a strict positive lower endpoint at that scale. Higher precision is already supported by the formal definition and mirror; the current quadrature remainder and tail bounds must also be tightened. Rescaling the final wide interval cannot recover a lost sign; any Hardy normalization must enter the certified formula before evaluation and include its positive scaling proof.

AUTHORITY_EFFECT = NONE.
