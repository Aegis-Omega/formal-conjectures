# Hardy normalizacija i Q16.16 certifikat za t = 60

Napravljen je izvršivi Arb checker koji rigorozno obuhvata vrijednost Hardyjeve
funkcije na racionalnoj tački i izvozi interval sa zaokruživanjem prema van.
Na t = 60 daje:

\[
Z(60)\in[38466,38467]\,2^{-16}>0.
\]

To je tačno racionalni interval
`[0.586944580078125, 0.5869598388671875]`. Arb računa na 256 bitova;
Q16.16 je izlazni format. Ne računamo sve specijalne funkcije na 16 bitova.
Provjereni su i isti interval na 160 i 384 bita, ranije sign tačke
t = 14, 14.3, 20.9, 21.1, te neispravni i izmijenjeni certifikati.
Svih 22 regresija prolazi normalno i pod `python -O`.

## Šta normalizacija radi

Za s = 1/2 + it koristimo

\[
\Lambda(s)=\pi^{-s/2}\Gamma(s/2)\zeta(s),\qquad
A(t)=\pi^{-1/4}|\Gamma(1/4+it/2)|>0,
\]

\[
Z(t)=e^{-it\log\pi/2}
\frac{\Gamma(1/4+it/2)}{|\Gamma(1/4+it/2)|}\zeta(1/2+it),
\qquad \Lambda(1/2+it)=A(t)Z(t).
\]

Gamma/|Gamma| bira fazu direktno; nema izbora znaka kompleksnog kvadratnog korijena.
Na t = 60, A je približno 2.75347·10⁻²¹, a Lambda približno 1.61615·10⁻²¹.
Sirovi Lambda interval pri Q16.16 skali je `[0,1]/65536`: strogi znak se gubi.
Normirani interval ga zadržava.

Ovo koristi posebnu reprezentaciju prije računanja. Dijeljenje već preširokog
Mellin intervala sa A ne može povratiti izgubljeni znak. Normalizacija također
ne uklanja raniji PNT ostatak e^T Delta(T)^2.

Vrijeme se ovdje koristi kao tačno t = 60, pa je t² = 3600 i racionalna
korekcija `1/(1/4+t²) = 4/14401`. Nema 60×60 matrice.

Repo oznaka `RHCriticalLineSignV1.Xi` znači Lambda. Standardna cijela funkcija
xi(s) = s(s−1)Lambda(s)/2 na liniji ima suprotan znak:

\[
\xi(1/2+it)=-\frac{t^2+1/4}{2}A(t)Z(t).
\]

## Pokretanje

Iz ovog direktorija, u Python okruženju sa instaliranim paketom iz requirements.txt:

```bash
python3 -m pip install -r requirements.txt
python3 research/rh/critical_line_v1/hardy_interval_v1.py --t 60 --out receipt_t60.json
python3 research/rh/critical_line_v1/hardy_interval_v1.py --verify receipt_t60.json
python3 -m unittest discover -s tests -v
python3 -O -m unittest discover -s tests -v
```

Provjera koristi ponovljen Arb račun, ne vjeruje samo ispisanom znaku.
Odbija float ulaze, nekanonične racionalne brojeve, pogrešnu preciznost,
izmjenu izvora, izmjenu manifesta, promjenu numeričkih granica ili trust statusa,
duple JSON ključeve, NaN i zamjenu boolean vrijednosti integerom.
Manifest izvora ima digest fiksiran u evaluatoru. Sam evaluator i njegovo
ispravno izvršavanje ostaju trust anchor; hash nije zaštita od zamjene cijelog programa.
Replay traži isti python-flint 0.9.0 i iste serijalizovane rezultate.

## Lean korak

`RHHardyNormalizationV1.lean` daje normalizaciju kroz
`amplitude t = ‖Gammaℝ (lineAt t)‖` i `normalized t = (Xi t).re / amplitude t`.
Dokazni kod za pozitivnost amplitude, faktorizaciju i prijenos znaka je pripremljen.
Numerička donja granica na t = 60 ostaje eksplicitna hipoteza u
`Lambda_60_pos_of_normalized_lower`.

Nova Lean kompilacija nije izvršena: `lake` nije instaliran u ovoj sesiji.
`kernel_receipt.json` to eksplicitno bilježi kao `NOT_EXECUTED`.
Nema tvrdnje KERNEL_VERIFIED za novi modul ili numerički enclosure.

Za provisioniran checkout na tačno `70ed9dd8ccc3365c7b5734b781a17f591a0dde0f`:

```bash
python3 replay_kernel.py --repo /apsolutni/put/do/formal-conjectures --out kernel_receipt.json
```

Replay provjerava Lean 4.33.1, Mathlib pin, byte vezu baseline izvora,
kompajlira šest critical-line modula iz svježe closure putanje i provjerava
`#print axioms`. Nema automatskog preuzimanja, push-a ili deploymenta.
Čak i uspjeh tog replaya dokazuje modul normalizacije i uslovni prijenos znaka;
ne formalizuje Arb specijalne funkcije niti njihov point enclosure.

`changes.patch` dodaje samo Lean modul u isti research direktorij.
Arb evaluator se pokreće kao ovaj samostalni paket, sa `source/` i manifestom.
Paket nije objavljen u GitHub branchu. Postojeći hardware runtime nije promijenjen.

## Izvori i tačan opseg

- Formal-conjectures PR55 head: `70ed9dd8ccc3365c7b5734b781a17f591a0dde0f`.
- Mathlib: `0df444a360eaa60ab8c11dca51a86af692955474`.
- Hardware source: AEGIS-OMEGA `495bfd85d79abcb2b4f6898fe9c156488492426a`,
  `sovereign-omega-v2/python/hardware_config.py`, blob `2a269fc640ce93341480c2a8d764003a381eff7e`.
- Trinaest originalnih fajlova u `source/` provjereno je kroz Git blob hash i SHA256.
- [FLINT Hardy Z dokumentacija](https://flintlib.org/doc/acb_dirichlet.html).
- [python-flint intervali](https://python-flint.readthedocs.io/en/latest/arb.html).
- [Tačan critical-line README](https://github.com/tarikskalic33/formal-conjectures/blob/70ed9dd8ccc3365c7b5734b781a17f591a0dde0f/research/rh/critical_line_v1/README.md).

Rezultat certifikuje znak u jednoj tački u Arb trust modelu.
Iz Z(60)>0 slijedi da zeta nije nula u 1/2+60i.
Ne certifikuje cijeli interval, broj svih nula, Weilovu pozitivnost ili RH.
Sljedeći zatvoriv formalni dug je kernel replay normalizacije, pa dokaz
enclosurea za isti normirani objekt, uz formalnu vezu s evaluatorom.
AUTHORITY_EFFECT = NONE.
