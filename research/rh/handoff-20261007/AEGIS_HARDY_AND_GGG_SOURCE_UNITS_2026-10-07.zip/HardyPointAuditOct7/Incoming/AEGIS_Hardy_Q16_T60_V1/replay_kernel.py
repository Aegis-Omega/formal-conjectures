"""Compile the exact critical-line closure in an already provisioned checkout.

No dependency fetching, branch updates or network actions are performed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

BASELINE = "70ed9dd8ccc3365c7b5734b781a17f591a0dde0f"
MATHLIB = "0df444a360eaa60ab8c11dca51a86af692955474"
SOURCE_BINDINGS_SHA256 = "8e46a8800e980d1593ef6c8efbef394b210dce1d89e0ecd55a1f27b2e288bc48"
MODULES = ["RHCriticalLineSignV1", "RHRiemannThetaFormulaV1", "RHLambdaLineV1",
           "RHFixIntervalV1", "RHThetaTailV1", "RHHardyNormalizationV1"]
EXPECTED = {
    "AEGIS.RHCriticalLineSignV1.Xi_im",
    "AEGIS.RHCriticalLineSignV1.exists_zero_of_sign_change",
    "AEGIS.RHRiemannThetaFormulaV1.completedRiemannZeta_eq",
    "AEGIS.RHLambdaLineV1.Xi_re_eq",
    "AEGIS.RHFixIntervalV1.Iv.mem_add",
    "AEGIS.RHFixIntervalV1.Iv.mem_mul",
    "AEGIS.RHThetaTailV1.theta_tail_bound",
    "AEGIS.RHHardyNormalizationV1.amplitude_pos",
    "AEGIS.RHHardyNormalizationV1.Xi_re_eq_amplitude_mul",
    "AEGIS.RHHardyNormalizationV1.normalized_pos_iff",
    "AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower",
}


def run(command, cwd, env=None):
    result = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True, timeout=3600)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout + result.stderr


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("kernel_receipt.json"))
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    receipt = {"baseline": BASELINE, "mathlib_pin": MATHLIB, "kernel_verified": False,
               "status": "NOT_EXECUTED", "modules": [],
               "special_function_enclosure_formalized": False,
               "t60_numeric_enclosure_kernel_verified": False}
    try:
        if shutil.which("lake") is None:
            raise RuntimeError("lake is not installed")
        repo = args.repo.resolve()
        if run(["git", "rev-parse", "HEAD"], repo).strip() != BASELINE:
            raise RuntimeError("checkout does not match exact baseline")
        if (repo / "lean-toolchain").read_text().strip() != "leanprover/lean4:v4.33.1":
            raise RuntimeError("Lean toolchain pin mismatch")
        if "version 4.33.1" not in run(["lake", "env", "lean", "--version"], repo):
            raise RuntimeError("executed Lean version mismatch")
        manifest = json.loads((repo / "lake-manifest.json").read_text())
        if next(p["rev"] for p in manifest["packages"] if p["name"] == "mathlib") != MATHLIB:
            raise RuntimeError("Mathlib manifest pin mismatch")
        if run(["git", "rev-parse", "HEAD"], repo / ".lake/packages/mathlib").strip() != MATHLIB:
            raise RuntimeError("installed Mathlib checkout pin mismatch")
        binding_path = package / "source_bindings.json"
        if hashlib.sha256(binding_path.read_bytes()).hexdigest() != SOURCE_BINDINGS_SHA256:
            raise RuntimeError("trusted source bindings changed")
        bindings = json.loads(binding_path.read_text())
        for source in bindings["sources"]:
            if source["repository"] != "tarikskalic33/formal-conjectures":
                continue
            if hashlib.sha256((repo / source["path"]).read_bytes()).hexdigest() != source["sha256"]:
                raise RuntimeError("dirty baseline source: " + source["path"])
        lean_path = run(["lake", "env", "printenv", "LEAN_PATH"], repo).strip()
        logs = []
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            env = dict(os.environ, LEAN_PATH=str(work) + os.pathsep + lean_path)
            for module in MODULES:
                source = (package / "research/rh/critical_line_v1" if module == "RHHardyNormalizationV1"
                          else package / "source/formal-conjectures/research/rh/critical_line_v1") / (module + ".lean")
                target = work / source.name
                shutil.copy2(source, target)
                # Use lake's pinned executable and the closure's fresh olean directory.
                log = run(["lake", "env", "lean", "-DwarningAsError=true", "-o",
                           str(work / (module + ".olean")), str(target)], repo, env)
                if re.search(r"\b(sorryAx|Lean\.ofReduceBool|Lean\.trustCompiler)\b", log):
                    raise RuntimeError("nonstandard trust dependency in " + module)
                logs.append(log)
                receipt["modules"].append({"module": module, "sha256": hashlib.sha256(source.read_bytes()).hexdigest()})
        all_logs = "\n".join(logs)
        found = {}
        for name, ax in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", all_logs):
            axioms = {x.strip() for x in ax.split(",") if x.strip()}
            if not axioms <= {"propext", "Classical.choice", "Quot.sound"}:
                raise RuntimeError("nonstandard axioms for " + name)
            found[name] = sorted(axioms)
        if not EXPECTED <= found.keys():
            raise RuntimeError("missing #print axioms entries: " + str(sorted(EXPECTED - found.keys())))
        (args.out.parent / "kernel_output.log").write_text(all_logs)
        receipt.update(status="KERNEL_NORMALIZATION_VERIFIED", kernel_verified=True, axioms=found)
    except (RuntimeError, OSError, StopIteration, subprocess.TimeoutExpired) as exc:
        receipt["reason"] = str(exc)
        if receipt["modules"]:
            receipt["status"] = "KERNEL_REPLAY_FAILED"
    args.out.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": receipt["status"], "reason": receipt.get("reason")}))
    return 0 if receipt["kernel_verified"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
