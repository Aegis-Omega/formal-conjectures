from copy import deepcopy
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / "research/rh/critical_line_v1/hardy_interval_v1.py"
SPEC = importlib.util.spec_from_file_location("hardy", PATH)
h = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(h)


class HardyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.receipt = h.generate(Fraction(60), 256, 16, ROOT)

    def test_t60_exact_time_and_correction(self):
        ev = self.receipt["evaluation"]
        self.assertEqual(h.unpack(ev["t_squared"]), 3600)
        self.assertEqual(h.unpack(ev["correction"]), Fraction(4, 14401))

    def test_positive_q16_hardy_margin(self):
        self.assertEqual(self.receipt["evaluation"]["hardy_Z"]["dyadic"],
                         {"fractional_bits": 16, "lo": "38466", "hi": "38467", "sign": "POSITIVE"})

    def test_raw_completed_loses_strict_sign(self):
        self.assertEqual(self.receipt["evaluation"]["completed_Lambda"]["dyadic"],
                         {"fractional_bits": 16, "lo": "0", "hi": "1", "sign": "UNRESOLVED"})

    def test_entire_xi_reverses_sign(self):
        self.assertLess(h.unpack(self.receipt["evaluation"]["standard_xi"]["upper"]), 0)

    def test_negative_outward_rounding(self):
        q = h.quantize(Fraction(-1, 10), Fraction(-1, 10), 16)
        self.assertEqual((q["lo"], q["hi"]), ("-6554", "-6553"))

    def test_grid_exact_point(self):
        q = h.quantize(Fraction(1, 2), Fraction(1, 2), 16)
        self.assertEqual((q["lo"], q["hi"]), ("32768", "32768"))

    def test_inverted_interval_rejected(self):
        with self.assertRaises(ValueError):
            h.quantize(Fraction(1), Fraction(0), 16)

    def test_float_input_rejected(self):
        with self.assertRaises(ValueError):
            h.rational(0.1)

    def test_bad_precision_rejected(self):
        for precision in [0, 64, True, 4097]:
            with self.subTest(precision=precision), self.assertRaises(ValueError):
                h.evaluate(Fraction(60), precision, 16)

    def test_bad_scale_rejected(self):
        for scale in [-1, True, 4097]:
            with self.subTest(scale=scale), self.assertRaises(ValueError):
                h.evaluate(Fraction(60), 256, scale)

    def test_noncanonical_rational_rejected(self):
        for value in [{"numerator": "2", "denominator": "2"},
                      {"numerator": "1", "denominator": "0"}]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                h.unpack(value)

    def test_exact_receipt_replays(self):
        self.assertEqual(h.verify(self.receipt, ROOT)["status"], "ARB_REPLAY_VERIFIED")

    def test_tampered_sign_rejected(self):
        r = deepcopy(self.receipt)
        r["evaluation"]["hardy_Z"]["dyadic"]["sign"] = "NEGATIVE"
        with self.assertRaises(ValueError):
            h.verify(r, ROOT)

    def test_tampered_lower_rejected(self):
        r = deepcopy(self.receipt)
        r["evaluation"]["hardy_Z"]["lower"] = h.pack(Fraction(1))
        with self.assertRaises(ValueError):
            h.verify(r, ROOT)

    def test_kernel_promotion_rejected(self):
        r = deepcopy(self.receipt)
        r["kernel_verified"] = True
        with self.assertRaises(ValueError):
            h.verify(r, ROOT)

    def test_integer_for_boolean_rejected(self):
        for key in ["kernel_verified", "formal_special_function_enclosure"]:
            r = deepcopy(self.receipt)
            r[key] = 0
            with self.subTest(key=key), self.assertRaises(ValueError):
                h.verify(r, ROOT)

    def test_duplicate_json_key_rejected(self):
        with self.assertRaises(ValueError):
            h.strict_json('{"kernel_verified": true, "kernel_verified": false}')

    def test_nonfinite_json_rejected(self):
        for constant in ["NaN", "Infinity", "-Infinity"]:
            with self.subTest(constant=constant), self.assertRaises(ValueError):
                h.strict_json('{"value": ' + constant + '}')

    def test_manifest_rebinding_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = json.loads((ROOT / "source_bindings.json").read_text())
            manifest["sources"] = []
            (root / "source_bindings.json").write_text(json.dumps(manifest))
            with self.assertRaises(ValueError):
                h.check_sources(root)

    def test_changed_source_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            shutil.copytree(ROOT / "source", root / "source")
            shutil.copy2(ROOT / "source_bindings.json", root / "source_bindings.json")
            (root / "source/formal-conjectures/lean-toolchain").write_text("wrong\n")
            with self.assertRaises(ValueError):
                h.check_sources(root)

    def test_precision_crosscheck(self):
        for precision in [160, 384]:
            ev = h.evaluate(Fraction(60), precision, 16)
            self.assertEqual(ev["hardy_Z"]["dyadic"]["lo"], "38466")
            self.assertEqual(ev["hardy_Z"]["dyadic"]["hi"], "38467")
            a, b = ev["hardy_Z"], self.receipt["evaluation"]["hardy_Z"]
            self.assertLessEqual(h.unpack(a["lower"]), h.unpack(b["upper"]))
            self.assertLessEqual(h.unpack(b["lower"]), h.unpack(a["upper"]))

    def test_existing_sign_samples(self):
        for t, sign in [("14", "NEGATIVE"), ("143/10", "POSITIVE"),
                        ("209/10", "POSITIVE"), ("211/10", "NEGATIVE")]:
            with self.subTest(t=t):
                ev = h.evaluate(Fraction(t), 256, 16)
                self.assertEqual(ev["hardy_Z"]["dyadic"]["sign"], sign)


if __name__ == "__main__":
    unittest.main()
