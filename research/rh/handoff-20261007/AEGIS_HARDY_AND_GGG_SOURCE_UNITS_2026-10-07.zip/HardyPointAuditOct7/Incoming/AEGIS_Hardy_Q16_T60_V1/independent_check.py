"""Independent Arb check of completed zeta/Hardy normalization at t = 60.
Run with python3 independent_check.py in an environment with python-flint.
"""
from flint import arb, acb, ctx


def require(condition):
    if not condition:
        raise ValueError("independent mathematical check failed")


def outward_dyadic(x, p):
    def integer_round_endpoint(endpoint, upward):
        mantissa, exponent = endpoint.man_exp()
        mantissa = int(mantissa)
        exponent = int(exponent) + p
        if exponent >= 0:
            return mantissa << exponent
        denominator = 1 << -exponent
        return -((-mantissa) // denominator) if upward else mantissa // denominator
    return (
        integer_round_endpoint(x.lower(), False),
        integer_round_endpoint(x.upper(), True),
    )


def evaluate(prec=256):
    ctx.prec = prec
    t = arb(60)
    s = acb(arb(1) / 2, t)
    gamma = (s / 2).gamma()
    amplitude = arb.pi() ** (-arb(1) / 4) * abs(gamma)
    # Branch-free unit phase; agrees with exp(i*standard Hardy theta).
    phase = (-acb(0, t / 2) * arb.pi().log()).exp() * gamma / abs(gamma)
    hardy = phase * s.zeta()
    completed = acb(arb.pi()) ** (-s / 2) * gamma * s.zeta()
    xi = s * (s - 1) * completed / 2
    require(hardy.real.lower() > 0)
    require(hardy.imag.contains(0))
    require(amplitude.lower() > 0)
    require(completed.real.lower() > 0)
    require(completed.imag.contains(0))
    require((completed - amplitude * hardy).contains(0))
    require(xi.real.upper() < 0)
    require(outward_dyadic(hardy.real, 16) == (38466, 38467))
    require(outward_dyadic(completed.real, 16) == (0, 1))
    return amplitude, hardy, completed, xi


if __name__ == '__main__':
    for prec in (160, 256, 384):
        amplitude, hardy, completed, xi = evaluate(prec)
        print('bits', prec)
        print('amplitude', amplitude)
        print('Hardy Z', hardy)
        print('completed Lambda', completed)
        print('Xi', xi)
        print('Q16 bounds', outward_dyadic(hardy.real, 16))
