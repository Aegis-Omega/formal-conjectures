from pathlib import Path
import json,hashlib,datetime
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
SRC=BASE/'Incoming/AEGIS_Hardy_Q16_T60_V1'
K=Path(json.loads((HERE/'KernelReplay/LATEST_RUN.json').read_text())['run_directory'])
PRE=BASE/'FormalReview/Run-20261007T085543.394114Z'
def demand(x,m):
 if not x:raise RuntimeError(m)
def bh(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,d):
 demand(not p.exists(),'refusing overwrite '+str(p));p.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
numeric=json.loads((HERE/'Numeric/RESULT.json').read_text());kernel=json.loads((K/'RECEIPT.json').read_text());normal=json.loads((HERE/'NormalizationReview/REVIEW_RECEIPT.json').read_text())
demand(numeric['status']=='PASS','numeric failure');demand(kernel['status']=='PASS_SCOPED_SIX_SOURCE_REPLAY','kernel failure');demand(normal['status']=='PASS_SCOPED','ordinary review failure')
demand(bh(HERE/'NormalizationReview/REVIEW_RECEIPT.json')['sha256']=='acded9c8ad9da28ca8a4cf155b3aa853d98ff007f87459c4a925faba99a9a3d3','changed ordinary receipt')
demand(bh(K/'RECEIPT.json')['sha256']=='afc3c3d234f92c9ad00d521a40d32b62068105f086f40c1184655f121d073e2b','changed kernel receipt')
demand(bh(HERE/'Numeric/RESULT.json')['sha256']=='859383af03d0b679913f39bfecd8ba020bceab14faab1b37adfb1bd6de3f2686','changed numeric receipt')
for j in kernel['jobs']:demand(j['exit_code']==0 and j['termination'] is None,'kernel job failure')
for ax in kernel['axioms'].values():demand(set(ax)<={'propext','Classical.choice','Quot.sound'},'unexpected axioms')
archive=json.loads((BASE/'ARCHIVE_SOURCE_MANIFEST.json').read_text())
for row in archive['bindings']:
 b=bh(BASE/'Incoming'/row['path']);demand(b['sha256']==row['sha256']and b['bytes']==row['bytes'],'incoming bytes changed')
paths=[p for p in HERE.rglob('*')if p.is_file()and p.name not in {'SOURCE_MANIFEST.json','REVIEW_RECEIPT.json'}]
# Child receipt is included, despite its common name.
paths.append(HERE/'NormalizationReview/REVIEW_RECEIPT.json')
paths += [BASE/'ARCHIVE_SOURCE_MANIFEST.json',Path(archive['zip_path']),BASE/'CURRENT_NUMERIC_REPLAY_RECEIPT.json',BASE/'CURRENT_RECEIPT_T60.json',PRE/'RECEIPT.json',PRE/'IMPORT_COMPATIBILITY.patch']
paths += [p for p in SRC.rglob('*')if p.is_file()]
paths += [p for p in (PRE/'EffectiveSources').glob('*.lean')if p.is_file()]
paths=sorted(set(paths),key=str)
manifest={'schema':'AEGIS_HARDY_INDEPENDENT_REVIEW_SOURCE_BINDINGS_V1','scope':'Independent report/replay input and output bytes; includes explicitly labelled fresh compiled replay objects, not a claim of full transitive source rebuild. Aggregate self/receipt excluded to avoid cycles. Child receipt explicitly included.','files':[bh(p)for p in paths]}
save(HERE/'SOURCE_MANIFEST.json',manifest)
receipt={'schema':'AEGIS_HARDY_SOURCE_NUMERIC_FORMAL_INDEPENDENT_REVIEW_V1','status':'PASS_SCOPED','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Hardy normalization ordinary proof review, independently assembled four-precision exact-Arb t60 evaluation, and fresh six-source scoped Lean/checker replay. Not a quantitative Lean special-function enclosure or RH proof.',
 'source_manifest':bh(HERE/'SOURCE_MANIFEST.json'),'review':bh(HERE/'REVIEW.md'),'normalization_review':bh(HERE/'NormalizationReview/REVIEW_RECEIPT.json'),'numeric_review':bh(HERE/'Numeric/RESULT.json'),'kernel_replay':bh(K/'RECEIPT.json'),'direct_library_identity':bh(HERE/'LIBRARY_IDENTITY.json'),
 'uploaded_archive':bh(Path(archive['zip_path'])),'incoming_source_files':27,'incoming_sources_preserved':True,
 'formal_source_commit':'70ed9dd8ccc3365c7b5734b781a17f591a0dde0f','mathlib_commit':'0df444a360eaa60ab8c11dca51a86af692955474','lean_version':'4.33.1','lean_compiler_commit':'819816b2e0a3bf405af45ae5c7af2491d8f5bee6','python_flint_version':'0.9.0',
 'ordinary_identity':'For every real t, s=1/2+it: Lambda(s)=A(t)Z(t), A(t)>0. Standard entire xi(s)=-(t^2+1/4)A(t)Z(t)/2. Repository Xi is explicitly Lambda.',
 'numeric':{'status':'INDEPENDENT_ARB_POINT_RECOMPUTATION_PASS','t':'60','precision_bits':[160,256,384,512],'strict_enclosure':['38466/65536','38467/65536'],'completed_Lambda_positive':True,'standard_xi_negative':True,'display_floats_used_for_decisions':False,'same_Arb_library_and_host':True,'independent_special_function_library':False,'scope':'ONE_RATIONAL_POINT'},
 'formal':{'status':'PASS_SCOPED_SIX_SOURCE_REPLAY','fresh_local_modules':6,'fresh_audit_module':1,'module_checker_jobs':7,'type_axiom_endpoints':11,'all_jobs_exit0':True,'import_only_adapted_modules':4,'uploaded_normalization_source_byte_identical':True,'trust':0,'warningAsError':True,'full_transitive_source_rebuild':False,'identified_imported_dependency_objects_reused':True,'axioms':kernel['axioms'],'observed_peak_RSS_KiB':max(j['peak_observed_RSS_KiB']for j in kernel['jobs'])},
 'quantitative_lower_bound_Lean_theorem':False,'Arb_to_Mathlib_enclosure_transport_Lean_theorem':False,'final_t60_sign_endpoint_explicit_argument':'h : (38466 : Real)/65536 <= AEGIS.RHHardyNormalizationV1.normalized 60',
 'numeric_imag_or_residual_containment_is_not_the_identity_proof':True,'single_point_is_not_universal_positive_sign_or_zero_count':True,
 'prior22_replay_repeated':False,'source_Git_mutations':False,'source_or_incoming_mutations':False,'hardware_QPU_execution':False,'remote_writes':False,'rh_proven':False,'final_RH_theorem':None,
 'unchanged_global_obligation':{'id':'AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign','detector':'AEGIS.RHFixedPacketFrontierV1.detectingPacket','quantifier_scope':'Same fixed detector; every signed-integer log2/log3 shift; all four phases; full real Weil explicit-formula RHS on autocorrelation of the two-point translate <=0.','status':'No unconditional producer supplied by this Hardy-only packet; unsearched sources UNKNOWN.'}}
save(HERE/'REVIEW_RECEIPT.json',receipt)
for p in [HERE/'REVIEW_RECEIPT.json',HERE/'SOURCE_MANIFEST.json',HERE/'REVIEW.md']:print(json.dumps(bh(p)))
