from pathlib import Path
import os,sys,json,hashlib,datetime,subprocess,time,re,difflib
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
SRC=BASE/'Incoming/AEGIS_Hardy_Q16_T60_V1'
BASELINE=BASE/'FormalReview/Run-20261007T085543.394114Z'
BIN=Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
CACHE=Path('/workspace/aegis-research/work/GoalContinuation20261001/AnalyticReplay/actual-context-20261003T004616.608552Z/mathlib-only')
PROVIDER=Path('/workspace/aegis-research/provider/.lake/packages')
MODULES=('RHCriticalLineSignV1','RHRiemannThetaFormulaV1','RHLambdaLineV1','RHFixIntervalV1','RHThetaTailV1','RHHardyNormalizationV1')
ENDPOINTS=('AEGIS.RHCriticalLineSignV1.Xi_im','AEGIS.RHCriticalLineSignV1.exists_zero_of_sign_change','AEGIS.RHRiemannThetaFormulaV1.completedRiemannZeta_eq','AEGIS.RHLambdaLineV1.Xi_re_eq','AEGIS.RHFixIntervalV1.Iv.mem_add','AEGIS.RHFixIntervalV1.Iv.mem_mul','AEGIS.RHThetaTailV1.theta_tail_bound','AEGIS.RHHardyNormalizationV1.amplitude_pos','AEGIS.RHHardyNormalizationV1.Xi_re_eq_amplitude_mul','AEGIS.RHHardyNormalizationV1.normalized_pos_iff','AEGIS.RHHardyNormalizationV1.Lambda_60_pos_of_normalized_lower')
def demand(x,m):
 if not x:raise RuntimeError(m)
def bh(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
baseline=json.loads((BASELINE/'RECEIPT.json').read_text())
demand(baseline['status']=='PASS_SCOPED_EFFECTIVE_CLOSURE','required preceding replay did not pass')
for j in baseline['jobs']:demand(j.get('exit_code')==0,'preceding job unsuccessful')
run=HERE/('Run-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
for d in [run,run/'Sources',run/'lib',run/'logs']:d.mkdir()
paths=[run/'lib',CACHE,CACHE.parent/'package-only']
for pkg in ('LeanSearchClient','Qq','aesop','batteries','importGraph','plausible','proofwidgets'):
 p=PROVIDER/pkg/'.lake/build/lib/lean';demand(p.is_dir(),'missing package '+str(p));paths.append(p)
env=dict(os.environ);env['PATH']=str(BIN)+os.pathsep+env.get('PATH','');env['LEAN_PATH']=os.pathsep.join(map(str,paths));env['ELAN_TOOLCHAIN']='leanprover/lean4:v4.33.1'
receipt={'schema':'AEGIS_INDEPENDENT_HARDY_SIX_SOURCE_KERNEL_REPLAY_V1','status':'RUNNING','run_directory':str(run),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':bh(BASELINE/'RECEIPT.json'),
 'incoming_archive_manifest':bh(BASE/'ARCHIVE_SOURCE_MANIFEST.json'),'compiler':bh(BIN/'lean'),'checker':bh(BIN/'leanchecker'),'driver':bh(Path(__file__)),
 'formal_source_commit':'70ed9dd8ccc3365c7b5734b781a17f591a0dde0f','mathlib_commit':'0df444a360eaa60ab8c11dca51a86af692955474',
 'mathlib_cached_dependencies_reused':True,'full_transitive_source_rebuild':False,'fresh_six_local_source_modules':True,'LEAN_PATH':env['LEAN_PATH'],
 'limits':{'wall_seconds_per_job':90,'RSS_MiB_per_job':4096,'RSS_poll_seconds':0.05,'CPU_affinity_count':1,'compiler_threads':1,'Lean_MiB_option':4096},
 'source_bindings':[],'jobs':[],'rh_proven':False,'numeric_lower_bound_is_explicit_hypothesis':True,'t60_lower_bound_kernel_verified':False,'source_mutations':False,'remote_writes':False}
def save():
 (run/'RECEIPT.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
 (HERE/'LATEST_RUN.json').write_text(json.dumps({'run_directory':str(run)},indent=2)+'\n')
def noimports(b):return b''.join(l for l in b.splitlines(keepends=True) if not l.startswith(b'import '))
patch=[]
for module in MODULES:
 original=SRC/('research/rh/critical_line_v1/'+module+'.lean') if module=='RHHardyNormalizationV1' else SRC/('source/formal-conjectures/research/rh/critical_line_v1/'+module+'.lean')
 effective=BASELINE/'EffectiveSources'/(module+'.lean');o=original.read_bytes();e=effective.read_bytes()
 demand(noimports(o)==noimports(e),'non-import body mutation '+module)
 row=next(x for x in baseline['source_bindings']if x['module']==module)
 demand(bh(original)['sha256']==row['original_sha256'] and bh(effective)['sha256']==row['effective_sha256'],'baseline source binding mismatch '+module)
 p=run/'Sources'/(module+'.lean');p.write_bytes(e)
 receipt['source_bindings'].append({'module':module,'original':bh(original),'effective_preceding':bh(effective),'fresh_source':bh(p),'import_only_difference':o!=e,'non_import_bytes_identical':True})
 patch.extend(difflib.unified_diff(o.decode().splitlines(True),e.decode().splitlines(True),fromfile='Incoming/'+module+'.lean',tofile='Effective/'+module+'.lean'))
(run/'IMPORT_ONLY.patch').write_text(''.join(patch));receipt['import_patch']=bh(run/'IMPORT_ONLY.patch');save()
def affinity():os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def execute(label,args):
 t0=time.monotonic();out=run/'logs'/(label+'.stdout');err=run/'logs'/(label+'.stderr');peak=0;reason=None
 with out.open('wb')as fo,err.open('wb')as fe:
  p=subprocess.Popen(list(map(str,args)),cwd=run/'Sources',env=env,stdout=fo,stderr=fe,preexec_fn=affinity,start_new_session=True)
  while p.poll()is None:
   try:
    v=(Path('/proc')/str(p.pid)/'status').read_text();m=re.search(r'^VmRSS:\s+(\d+) kB$',v,re.M)
    if m:peak=max(peak,int(m.group(1)))
   except (FileNotFoundError,ProcessLookupError):pass
   if peak>4096*1024:reason='RSS_LIMIT';os.killpg(p.pid,9);break
   if time.monotonic()-t0>90:reason='WALL_LIMIT';os.killpg(p.pid,9);break
   time.sleep(.05)
  code=p.wait()
 job={'label':label,'argv':list(map(str,args)),'exit_code':code,'termination':reason,'peak_observed_RSS_KiB':peak,'wall_seconds':time.monotonic()-t0,'stdout':bh(out),'stderr':bh(err)}
 receipt['jobs'].append(job);save();print(json.dumps({'label':label,'exit_code':code,'termination':reason,'seconds':job['wall_seconds']}),flush=True)
 demand(code==0 and reason is None,'failed '+label)
 return out.read_text()+err.read_text()
try:
 version=execute('compiler_version',[BIN/'lean','--version']);demand('4.33.1' in version and '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' in version,'unexpected compiler');receipt['compiler_version']=version.strip()
 helptext=execute('compiler_help',[BIN/'lean','--help']);demand('--trust' in helptext,'trust flag unavailable')
 logs=[]
 for module in MODULES:
  logs.append(execute('compile_'+module,[BIN/'lean','--trust=0','-j1','-M4096','-DwarningAsError=true','-o',run/'lib'/(module+'.olean'),run/'Sources'/(module+'.lean')]))
 for module in MODULES:execute('checker_'+module,[BIN/'leanchecker','-v',module])
 probe=run/'Sources/HardyIndependentEndpoints.lean'
 probe.write_text(''.join('import '+m+'\n'for m in MODULES)+'\n'+''.join('#check '+n+'\n#print '+n+'\n#print axioms '+n+'\n'for n in ENDPOINTS))
 logs.append(execute('endpoint_type_axiom_audit',[BIN/'lean','--trust=0','-j1','-M4096','-DwarningAsError=true','-o',run/'lib/HardyIndependentEndpoints.olean',probe]))
 execute('checker_HardyIndependentEndpoints',[BIN/'leanchecker','-v','HardyIndependentEndpoints'])
 sets={}
 for name,axs in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",'\n'.join(logs)):
  axioms=sorted({x.strip()for x in axs.split(',')if x.strip()});demand(set(axioms)<={'propext','Classical.choice','Quot.sound'},'unexpected axiom '+name)
  if name in sets:demand(sets[name]==axioms,'contradictory printed sets')
  sets[name]=axioms
 demand(set(ENDPOINTS)<=sets.keys(),'missing exact endpoint axiom report')
 endpointlog=(run/'logs/endpoint_type_axiom_audit.stdout').read_text()
 demand('38466 / 65536 ≤ AEGIS.RHHardyNormalizationV1.normalized 60' in endpointlog or '38466 / 65536 ≤ normalized 60' in endpointlog,'expected explicit lower-bound hypothesis not found')
 receipt['axioms']=sets;receipt['endpoint_source']=bh(probe);receipt['fresh_objects']=[bh(p)for p in sorted((run/'lib').glob('*.olean'))];receipt['status']='PASS_SCOPED_SIX_SOURCE_REPLAY';save()
 print(json.dumps({'status':receipt['status'],'receipt':bh(run/'RECEIPT.json'),'fresh_objects':len(receipt['fresh_objects']),'axiom_reports':len(sets),'rh_proven':False}),flush=True)
except Exception as exc:
 receipt['status']='FAILED';receipt['exception_type']=type(exc).__name__;receipt['exception']=str(exc);save();raise
