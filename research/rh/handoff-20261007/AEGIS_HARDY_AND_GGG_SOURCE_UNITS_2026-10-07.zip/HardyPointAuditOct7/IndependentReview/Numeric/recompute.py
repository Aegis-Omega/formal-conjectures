"""Separate exact-Arb point evaluation; never imports the delivered evaluator.
The first path divides completed Lambda's real part by |Gamma_R|.
An independently assembled log-Gamma phase provides a second path.
Every certified decision uses an Arb predicate or exact Fraction integers.
"""
from pathlib import Path
from fractions import Fraction
import datetime,hashlib,json,sys
import flint
from flint import arb,acb,ctx
BASE=Path('/workspace/aegis-research/evidence/hardy-q16-t60-oct7')
OUT=Path(__file__).resolve().parent
SRC=BASE/'Incoming/AEGIS_Hardy_Q16_T60_V1'
def demand(c,m):
 if not c:raise ValueError(m)
def bh(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def q(x):
 demand(x.is_finite() and x.is_exact(),'invalid exact endpoint')
 m,e=x.man_exp();m=int(m);e=int(e)
 return Fraction(m*(1<<e),1) if e>=0 else Fraction(m,1<<(-e))
def qp(v):return {'numerator':str(v.numerator),'denominator':str(v.denominator)}
def record(x):
 a,b=q(x.lower()),q(x.upper());demand(a<=b,'inverted enclosure')
 return {'lower':qp(a),'upper':qp(b),'display_only':x.str(60),
  'Q16_floor_lower':str((a*65536).__floor__()),'Q16_ceil_upper':str((b*65536).__ceil__())}
def overlaps(x,y):
 a,b=q(x.lower()),q(x.upper());c,d=q(y.lower()),q(y.upper())
 return max(a,c)<=min(b,d)
manifest=json.loads((BASE/'ARCHIVE_SOURCE_MANIFEST.json').read_text())
archive=Path(manifest['zip_path']);demand(bh(archive)['sha256']==manifest['zip_sha256'],'uploaded archive changed')
for row in manifest['bindings']:
 p=BASE/'Incoming'/row['path'];b=bh(p)
 demand(b['bytes']==row['bytes'] and b['sha256']==row['sha256'],'incoming source changed '+str(p))
demand(flint.__version__=='0.9.0','unexpected python-flint')
results=[]
for bits in (160,256,384,512):
 with ctx.workprec(bits):
  # Exact t60 and s/2=1/4+30i. No decimal input or float conversion.
  s=acb(arb(1)/2,arb(60));half_s=s/2;pi=acb(arb.pi())
  gamma_R=half_s.gamma()/pi.pow(half_s)
  lambda_s=gamma_R*s.zeta()
  # Modulus via conjugate product differs from delivered |Gamma(s/2)| path.
  modulus_square=(gamma_R*gamma_R.conjugate()).real
  demand(modulus_square>0,'Gamma_R squared norm does not exclude zero')
  amplitude=modulus_square.sqrt()
  normalized=lambda_s.real/amplitude
  theta=half_s.lgamma().imag-arb(30)*arb.pi().log()
  hardy_phase=acb(0,theta).exp()*s.zeta()
  standard_xi=lambda_s*(-arb(14401)/8)
  residual=lambda_s-acb(amplitude)*hardy_phase
  demand(lambda_s.imag.contains(0),'Lambda imaginary part excludes zero')
  demand(hardy_phase.imag.contains(0),'phase Hardy imaginary part excludes zero')
  demand(residual.contains(0),'independent phase normalization inconsistent')
  demand(amplitude>0 and lambda_s.real>0 and standard_xi.real<0,'sign mismatch')
  demand(overlaps(normalized,hardy_phase.real),'two independent routes disjoint')
  lo,hi=q(normalized.lower()),q(normalized.upper())
  demand(Fraction(38466,65536)<lo and hi<Fraction(38467,65536),'strict Q16 enclosure failed')
  entry={'precision_bits':bits,'normalized_completed_division':record(normalized),
   'hardy_loggamma_phase':record(hardy_phase.real),'positive_amplitude':record(amplitude),
   'completed_Lambda_real':record(lambda_s.real),'standard_xi_real':record(standard_xi.real),
   'completed_Lambda_imag':record(lambda_s.imag),'phase_Hardy_imag':record(hardy_phase.imag),
   'normalization_residual_real':record(residual.real),'normalization_residual_imag':record(residual.imag),
   'all_critical_decisions':'Exact Fraction endpoints and outward Arb operations; displayed decimal strings unused.'}
  delivered=json.loads((SRC/'receipt_t60.json').read_text())['evaluation']
  for name,current in [('hardy_Z',normalized),('completed_Lambda',lambda_s.real),('standard_xi',standard_xi.real),('positive_amplitude',amplitude)]:
   old=delivered[name];a=Fraction(int(old['lower']['numerator']),int(old['lower']['denominator']));b=Fraction(int(old['upper']['numerator']),int(old['upper']['denominator']))
   c,d=q(current.lower()),q(current.upper());demand(max(a,c)<=min(b,d),'delivered enclosure disjoint '+name)
  entry['delivered_exact_enclosure_overlap_all_four']=True
  results.append(entry)
result={'schema':'AEGIS_HARDY_INDEPENDENT_ARBITRARY_PRECISION_POINT_REVIEW_V1','status':'PASS',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.executable,'python_flint_version':flint.__version__,
 'scope':'Actual t=60 only. Same Arb special-function library, separate evaluator/source/formula assembly and four precisions; not an independent special-function kernel implementation.',
 't':qp(Fraction(60)),'Q16_strict_enclosure':{'lower':qp(Fraction(38466,65536)),'upper':qp(Fraction(38467,65536))},
 'inputs':[bh(archive),bh(BASE/'ARCHIVE_SOURCE_MANIFEST.json'),bh(SRC/'receipt_t60.json'),bh(SRC/'research/rh/critical_line_v1/hardy_interval_v1.py'),bh(SRC/'research/rh/critical_line_v1/RHHardyNormalizationV1.lean'),bh(Path(__file__))],
 'source_bindings_verified':len(manifest['bindings']),'evaluations':results,
 'numerical_trust':'python-flint0.9.0/Arb outward special-function evaluation. No formal theorem connecting this runtime to Mathlib claimed.',
 'lower_bound_formalized':False,'kernel_verified_by_this_script':False,'rh_proven':False,'source_mutations':False,'remote_writes':False}
path=OUT/'RESULT.json';demand(not path.exists(),'refusing existing result overwrite');path.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':result['status'],'precision_bits':[x['precision_bits'] for x in results],'source_bindings_verified':len(manifest['bindings']),
 'Q16_strict_lower':'38466/65536','Q16_strict_upper':'38467/65536','result':bh(path),'rh_proven':False},indent=2))
