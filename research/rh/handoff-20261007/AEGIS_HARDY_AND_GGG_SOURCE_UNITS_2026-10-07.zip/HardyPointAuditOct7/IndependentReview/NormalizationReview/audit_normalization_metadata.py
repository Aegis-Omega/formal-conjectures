"""Read-only bytes/exact-rational audit; no imported evaluator or compiler."""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import re
import subprocess
import datetime

P = Path('/workspace/aegis-research/evidence/hardy-q16-t60-oct7/Incoming/AEGIS_Hardy_Q16_T60_V1')
M = Path('/workspace/aegis-research/provider/.lake/packages/mathlib')
OUT = Path(__file__).resolve().parent
PIN = '0df444a360eaa60ab8c11dca51a86af692955474'
checks = []
bindings = {}
git_queries = []

def check(name, ok, detail=None):
    checks.append({'name': name, 'ok': bool(ok), 'detail': detail})

def bind(path):
    data = path.read_bytes()
    bindings[str(path)] = {'sha256': hashlib.sha256(data).hexdigest(),
                           'bytes': len(data), 'mode': oct(path.stat().st_mode & 0o777)}
    return data

def git(*args):
    cmd = ['git', '-C', str(M), *args]
    r = subprocess.run(cmd, capture_output=True, check=False)
    git_queries.append({'argv': cmd, 'exit_code': r.returncode,
                        'stdout_sha256': hashlib.sha256(r.stdout).hexdigest(),
                        'stderr': r.stderr.decode(errors='replace')})
    check('git command succeeded: ' + ' '.join(args), r.returncode == 0)
    return r.stdout

def rational(obj):
    check('rational object schema', isinstance(obj, dict) and set(obj) == {'numerator', 'denominator'})
    check('rational fields strings', all(type(x) is str for x in obj.values()))
    q = Fraction(int(obj['numerator']), int(obj['denominator']))
    check('positive rational denominator', int(obj['denominator']) > 0)
    check('canonical rational', str(q.numerator) == obj['numerator'] and str(q.denominator) == obj['denominator'])
    return q

manifest = json.loads(bind(P/'source_bindings.json'))
check('formal source pin', manifest['formal_head'] == '70ed9dd8ccc3365c7b5734b781a17f591a0dde0f')
check('13 original source bindings', len(manifest['sources']) == 13)
for s in manifest['sources']:
    data = bind(P/s['local_path'])
    check('source SHA256: '+s['local_path'], hashlib.sha256(data).hexdigest() == s['sha256'])
    blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    check('source Git blob: '+s['local_path'], blob == s['git_blob'])

norm = bind(P/'research/rh/critical_line_v1/RHHardyNormalizationV1.lean').decode()
code = bind(P/'research/rh/critical_line_v1/hardy_interval_v1.py').decode()
bind(P/'README_BHS.md')
receipt = json.loads(bind(P/'receipt_t60.json'))
kernel = json.loads(bind(P/'kernel_receipt.json'))
check('manifest bound by evaluator constant', re.search(r'EXPECTED_SOURCE_BINDINGS_SHA256 = "([0-9a-f]{64})"', code).group(1) == bindings[str(P/'source_bindings.json')]['sha256'])
check('receipt evaluator binding', receipt['evaluator_sha256'] == bindings[str(P/'research/rh/critical_line_v1/hardy_interval_v1.py')]['sha256'])
check('receipt source manifest binding', receipt['source_bindings_sha256'] == bindings[str(P/'source_bindings.json')]['sha256'])
check('numeric scope ONE_RATIONAL_POINT', receipt['scope'] == 'ONE_RATIONAL_POINT')
check('receipt numeric kernel gate false', receipt['kernel_verified'] is False and receipt['formal_special_function_enclosure'] is False)
check('authority effect NONE', receipt['authority_effect'] == 'NONE')
check('delivered kernel NOT_EXECUTED', kernel['status'] == 'NOT_EXECUTED' and kernel['modules'] == [] and kernel['kernel_verified'] is False)
check('delivered point enclosure kernel gate false', kernel['t60_numeric_enclosure_kernel_verified'] is False and kernel['special_function_enclosure_formalized'] is False)
check('delivered kernel pin', kernel['mathlib_pin'] == PIN)
check('new Lean lower-bound premise explicit', '(h : (38466 : ℝ) / 65536 ≤ normalized 60)' in norm)
check('new Lean normalized uses real completed quotient', 'normalized (t : ℝ) : ℝ := (Xi t).re / amplitude t' in norm)
check('new Lean amplitude actual GammaR modulus', 'amplitude (t : ℝ) : ℝ := ‖Complex.Gammaℝ (lineAt t)‖' in norm)
check('new Lean no sorry/admit/axiom declarations', re.search(r'\b(sorry|admit|axiom)\b', norm) is None)
check('new Lean four source axiom commands', norm.count('#print axioms ') == 4)

head = git('rev-parse', 'HEAD').decode().strip()
check('actual Mathlib HEAD pinned', head == PIN)
for rel in ['Mathlib/Analysis/SpecialFunctions/Gamma/Deligne.lean', 'Mathlib/NumberTheory/LSeries/RiemannZeta.lean']:
    current = bind(M/rel)
    pinned = git('show', PIN+':'+rel)
    check('actual Mathlib source equals pinned Git object: '+rel, current == pinned)
    blob = git('rev-parse', PIN+':'+rel).decode().strip()
    bindings[str(M/rel)]['repository'] = 'leanprover-community/mathlib4'
    bindings[str(M/rel)]['commit'] = PIN
    bindings[str(M/rel)]['git_blob'] = blob

ev = receipt['evaluation']
t = rational(ev['t'])
tsq = rational(ev['t_squared'])
correction = rational(ev['correction'])
check('exact point is 60', t == 60)
check('exact square is 3600', tsq == t*t == 3600)
check('exact pole correction 4/14401', correction == Fraction(1)/(Fraction(1,4)+t*t) == Fraction(4,14401))
check('precision and fractional bits', ev['precision_bits'] == 256 and ev['fractional_bits'] == 16)

ball_count = 0
def walk(obj, label):
    global ball_count
    if isinstance(obj, dict) and {'lower', 'upper', 'dyadic'} <= set(obj):
        ball_count += 1
        lo, hi = rational(obj['lower']), rational(obj['upper'])
        d = obj['dyadic']; b = d['fractional_bits']; scale = 1 << b
        low = (lo.numerator*scale)//lo.denominator
        high = -((-hi.numerator*scale)//hi.denominator)
        sign = 'POSITIVE' if low > 0 else 'NEGATIVE' if high < 0 else 'UNRESOLVED'
        check('ordered recorded rational endpoints: '+label, lo <= hi)
        check('exact outward dyadic conversion: '+label, d == {'fractional_bits': b, 'lo': str(low), 'hi': str(high), 'sign': sign})
        check('dyadic contains recorded rational endpoints: '+label, Fraction(low,scale) <= lo <= hi <= Fraction(high,scale))
        return
    if isinstance(obj, dict):
        for k,v in obj.items(): walk(v,label+'.'+k)
walk(ev, 'evaluation')
check('all 8 recorded balls inspected', ball_count == 8)
lo = rational(ev['hardy_Z']['lower']); hi = rational(ev['hardy_Z']['upper'])
check('recorded Hardy bounds inside claimed Q16 enclosure', Fraction(38466,65536) <= lo <= hi <= Fraction(38467,65536))
check('claimed Hardy Q16 lower is positive', Fraction(38466,65536) > 0)
for name in ['completed_Lambda','positive_amplitude']:
    check('raw '+name+' Q16 unresolved [0,1]', ev[name]['dyadic'] == {'fractional_bits':16,'lo':'0','hi':'1','sign':'UNRESOLVED'})
check('recorded ordinary xi negative endpoints', rational(ev['standard_xi']['upper']) < 0)
check('pole correction exact outward Q16 export', ev['correction_dyadic'] == {'fractional_bits':16, 'lo':'18', 'hi':'19', 'sign':'POSITIVE'} and Fraction(18,65536) <= correction <= Fraction(19,65536))

bind(OUT/'NORMALIZATION_REVIEW.md')
bind(Path(__file__).resolve())
for path, b in list(bindings.items()):
    check('bound input unchanged at finish: '+path, hashlib.sha256(Path(path).read_bytes()).hexdigest() == b['sha256'])

result = {
 'schema':'aegis.hardy.normalization-independent-read-only-review.v1',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'PASS_SCOPED' if all(x['ok'] for x in checks) else 'FAIL',
 'checks_passed':sum(x['ok'] for x in checks), 'checks_total':len(checks),
 'source_bindings':bindings, 'git_queries':git_queries, 'checks':checks,
 'ordinary_paper_identity': 'For every real t, Lambda(1/2+it)=A(t)Z(t), A(t)>0; normalized(t)=Z(t) under the reconstructed evaluator identification.',
 'theta_scope':'Gamma modulus unit phase; standard continuous theta starts at zero, logarithm shifts by 2pi preserve phase; no square root convention.',
 'completed_zeta_scope':'Xi in supplied source means Lambda; ordinary entire xi=-(t^2+1/4)A(t)Z(t)/2; Mathlib Lambda0 is additive pole removal.',
 'point_result_scope':'Recorded exact rational endpoints and outward quantization only. Actual special-function enclosures and original claimed test results were not replayed.',
 'numerical_replay':'NOT_RUN', 'kernel_replay':'NOT_RUN', 'axiom_audit':'NOT_RUN',
 'formal_lower_bound_premise':'(38466 : Real)/65536 <= AEGIS.RHHardyNormalizationV1.normalized 60',
 'formal_enclosure_produced':False, 'formal_hardy_phase_identity_produced':False,
 'rh_proven':False, 'rh_implication_added':False, 'authority_effect':'NONE',
 'defects':[],
 'limitations':['Explicit numerical lower-bound premise remains in Lean endpoint.',
                'Ordinary paper evaluator identity is not a generated Lean proof term.',
                'Numerical evaluator/Arb semantics require separate actual replay; this metadata audit validates no special function.',
                'One positive rational point does not count zeros or imply RH.',
                'Delivered NOT_EXECUTED receipt describes the supplied historical package, not availability of present compilers.']}
(OUT/'REVIEW_RECEIPT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
raw=(OUT/'REVIEW_RECEIPT.json').read_bytes()
summary={'status':result['status'],'checks_passed':result['checks_passed'], 'checks_total':result['checks_total'],
         'receipt_path':str(OUT/'REVIEW_RECEIPT.json'), 'receipt_sha256':hashlib.sha256(raw).hexdigest(),
         'bound_files':len(bindings),'numerical_replay':'NOT_RUN','kernel_replay':'NOT_RUN', 'rh_proven':False}
(OUT/'SUMMARY_RECEIPT.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,sort_keys=True))
raise SystemExit(0 if result['status']=='PASS_SCOPED' else 1)
