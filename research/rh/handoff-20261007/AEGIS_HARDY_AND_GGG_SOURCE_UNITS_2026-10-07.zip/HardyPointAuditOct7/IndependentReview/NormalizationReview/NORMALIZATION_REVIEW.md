# Independent ordinary-mathematical normalization review

This review reads the supplied Hardy packet and the actual Mathlib source at
`0df444a360eaa60ab8c11dca51a86af692955474`. It executes no Arb evaluator,
Lean compiler, kernel replay, package tests, or earlier research program.
The accompanying audit only checks existing bytes and exact rational metadata.

## The identity, with its full domain

For every real t put s = 1/2 + it, w = s/2 = 1/4 + it/2 and G = Gamma(w).
Since Re(w) = 1/4 > 0, G is finite and nonzero. Mathlib's actual definition is

    Complex.Gammaℝ(s) = pi^(-s/2) Gamma(s/2).

The base pi is positive, so its principal complex logarithm is the real log(pi).
Consequently

    pi^(-s/2) = pi^(-1/4) exp(-it log(pi)/2).

In this domain `riemannZeta_def_of_ne_zero` and the nonzero Gamma factor give
Lambda(s) = Gammaℝ(s) zeta(s), with Lambda = `completedRiemannZeta`.
Define

    A(t) = pi^(-1/4) |G| > 0,
    u(t) = exp(-it log(pi)/2) G/|G|,
    Z(t) = u(t) zeta(s).

These are the evaluator's exact formulas. Multiplication and cancellation of
the nonzero |G| give Lambda(s) = A(t) Z(t). Also |u(t)| = 1 and
A(t) = ||Gammaℝ(s)||, exactly the Lean definition `amplitude`.

The functional equation and conjugation give
conj(Lambda(s)) = Lambda(conj(s)) = Lambda(1-s) = Lambda(s).
The supplied `RHCriticalLineSignV1.Xi_conj`/`Xi_im` prove this algebraic step
in the source. Hence Lambda(s) and Z(t) are real for every real t, and

    normalized(t) = Re(Lambda(s))/A(t) = Z(t).

This last equality with the evaluator's phase formula is reconstructed here
as an ordinary mathematical argument. The supplied new Lean file defines
`normalized` by division and does not contain a formal Hardy phase definition
or a Lean proof of that evaluator identification. This review does not claim
it produced such a proof term.

## Theta convention and branches

On Re(w)>0 the nonzero holomorphic Gamma function has a holomorphic logarithm
chosen real at w=1/4. The conventional continuous theta is
Im(log Gamma(1/4+it/2)) - t log(pi)/2, with theta(0)=0.
Its exponential is precisely u(t). Changes of the logarithm by 2 pi i times
an integer leave u(t) unchanged. A pointwise principal argument can jump;
the evaluator computes Gamma/|Gamma| directly and never needs to choose that
jumping argument or a square root. An added phase pi would change Z's sign
and would be a different convention; it is not the formula in this package.

## Lambda, xi, and the pole-removed Mathlib completion

The source name `RHCriticalLineSignV1.Xi` explicitly denotes Lambda(s), not
the conventional entire xi. For xi(s)=s(s-1)Lambda(s)/2, exact multiplication
on the line yields

    xi(1/2+it) = -(t^2+1/4) A(t) Z(t)/2.

Thus its nonzero sign is the opposite of the Hardy Z/Lambda sign for every
real t. The evaluator implements this negative factor correctly.
Mathlib's `completedRiemannZeta₀` is instead the additive pole-removed
completion, and its actual source lemma reads

    Lambda(s) = completedRiemannZeta₀(s) - 1/s - 1/(1-s).

On the line the subtracted sum is 1/(1/4+t^2). These three objects cannot be
interchanged when discussing signs. The package does not interchange them.

## What the t=60 data actually say

The existing receipt declares exact t=60, t^2=3600, correction=4/14401,
Arb precision 256 bits and outward export with 16 fractional bits.
Its recorded rational Hardy bounds lie inside

    [38466/65536, 38467/65536]
      = [0.586944580078125, 0.5869598388671875],

whose lower endpoint is strictly positive. The audit checks that containment
and all the recorded floor/ceiling conversions by Fraction arithmetic only.
It does not establish that the recorded special-function bounds are valid;
that requires the separate actual Arb replay under its stated trust model.

The recorded amplitude and Lambda are approximately 2.75347e-21 and
1.61615e-21. Their Q16 dyadic intervals are both [0,1]/65536, which do not
certify a strictly positive sign. The positive Z interval retains the sign
because the exact normalization is used before coarse export. Dividing an
already overwide Lambda interval cannot restore information it lost.

If the receipt's enclosure is accepted with the exact identity above, it
gives Z(60)>0 and therefore zeta(1/2+60i) != 0. This is one rational point.
It proves no interval-wide nonvanishing, total zero count, exclusion of
off-line zeros, universal Weil positivity, packet sign, or RH. In combination
with a separately established negative endpoint, continuity can give an
existence statement for at least one line zero between the endpoints; t=60
positivity alone does not supply that second sign or a zero-count comparison.

## Formal and numerical boundaries

The new Lean theorem is exactly

    Lambda_60_pos_of_normalized_lower
      (h : (38466 : Real)/65536 <= normalized 60) :
      0 < (Xi 60).re.

The lower bound h is explicit. The provided file does not discharge h or
formalize Arb's Gamma/zeta computations. Its four `#print axioms` commands
are source commands, not output from this review. The delivered
`kernel_receipt.json` says NOT_EXECUTED, modules=[], kernel_verified=false,
and t60_numeric_enclosure_kernel_verified=false. Its historical reason
`lake is not installed` describes that delivered execution scope and is not
a statement about the present environment.

Imaginary balls and the normalization residual containing zero are useful
numerical consistency checks. A ball containing zero by itself proves
neither exact reality nor an identity. Here exact reality follows from the
functional equation and exact normalization follows from the algebra above.
Arb's outward-rounding special-function implementation and the exact executed
evaluator remain the numerical trust anchors. SHA256/Git blob identities
bind bytes; they are not mathematical soundness proofs.

No defect was found in the paper normalization, theta phase, Lambda/xi sign
conventions, or the supplied one-point quantified scope. The limits above
remain explicit: numerical replay and kernel replay are NOT_RUN by this
review; no unconditional t60 enclosure or RH theorem has been added.
