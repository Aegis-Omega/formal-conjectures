# Source-specific Hardy normalization and its exact proof boundary

7 October 2026. Root review of the supplied 27-file Hardy Q16/T60 packet.
All delivered sources remain unchanged. Current Arb replay is separately
recorded; the formal replay is a different obligation and receipt.

For each real t, set s=1/2+it. The packet's completed function is
Lambda(s)=pi^(-s/2) Gamma(s/2) zeta(s). Its repository label Xi denotes
this meromorphic completed function, not the usual entire xi. Because
Re(s/2)=1/4, Gamma(s/2) is finite and nonzero, and

    A(t)=pi^(-1/4)|Gamma(1/4+it/2)|>0,
    Z(t)=exp(-it log(pi)/2) Gamma(s/2)/|Gamma(s/2)| zeta(s),
    Lambda(s)=A(t)Z(t).

This identity is direct multiplication; no complex square-root branch,
choice of Gamma argument, or RH assumption enters it. The actual functional
equation and conjugation give real completed values on this line. Thus
Re Lambda(s)/A(t)=Re Z(t), and the actual Hardy quantity is real. Gamma_R
in the supplied Lean expression includes pi^(-s/2); its norm on the line
is exactly A(t). The phase formula and the external FLINT special-function
implementation are not thereby represented by a new Lean proof term.

The supplied Lean module proves positivity of this amplitude, the exact
real-factorization identity and conditional sign transport. Its last
theorem assumes explicitly

    (38466 : Real)/65536 <= normalized 60.

Successful compilation of that theorem does not supply this lower bound.
The numerical input remains an Arb calculation until a checked mathematical
transport/Lean enclosure is supplied. The original kernel receipt is
NOT_EXECUTED; any current execution has a new independent receipt and must
retain its actual import/cache compatibility scope.

For the current actual python-flint0.9.0 replay, rational t=60 at256bits
reproduces the uploaded receipt byte-for-byte. Its Q16 output is
[38466,38467]/65536, strictly positive. Separate formula evaluations at160,
256 and384bits and22 regression tests in both normal and optimized Python
pass. Outward export uses exact endpoints and integer floor/ceiling; all
special functions are evaluated at high precision before this export.
The evaluator's explicit guards survive optimization. The finite tests
check their stated inputs and rejections, not every real height or formal
soundness of all special functions.

The raw completed value at60 is about1.61615e-21, so its Q16 enclosing
interval is[0,1]/65536. Dividing that already rounded interval by a positive
amplitude keeps its lower endpoint zero. The useful improvement comes from
normalizing the representation before evaluation. The exact correction
1/(1/4+60^2)=4/14401 has Q16 enclosure[18,19]/65536; it is neither a60x60
matrix nor evidence for a whole support/test-function class.

The usual entire function satisfies on this line

    xi(s)=s(s-1)Lambda(s)/2=-(t^2+1/4)A(t)Z(t)/2.

Its sign is consequently reversed. Calling the repository Lambda object
Xi must not hide this distinction. Positivity at60 implies only that the
actual zeta is nonzero at1/2+60i. It does not count all zeros, address
off-line zeros, provide all-shift Weil sign or remove the actual arithmetic
exp(T)Delta(T)^2 remainder established in the prior continuation.

The same fixed-packet DenseFixedPacketSign obligation remains selected.
No global producer follows from this packet in the reconstructed
composition. Other unsearched sources remain unknown. RH_PROVEN=false.

The subsequent source composition has now checked the ordinary phase
identity in Lean itself. `RHHardyPhaseTransportV1.lean`, SHA256
`1c0a0dda1499dec1701e49d0ef7cca585b17f8a7eb2a356e65e23bdba90c0d38`,
proves for every real t that the evaluator's exact exponential/Gamma/zeta
expression is the complex coercion of `normalized t`. It also proves both
amplitude formulas. Its fresh trust-0 compile and leanchecker passed,
with eight standard-only axiom reports. Two earlier failed elaborations
and the routine associativity correction are preserved separately.

This closes the mathematical expression identity previously noted above;
it does not formalize the Arb runtime's special-function enclosures. The
quantitative lower bound at60 still has no Lean proof term, and the
single-point calculation still does not produce the universal Weil sign.
