# Hardy Q16/T60: current verified source composition

The new `AEGIS.RHHardyPhaseTransportV1.evaluator_phase_zeta_eq_normalized`
is an unconditional Lean identity for every real `t`, with
`s = 1/2 + it`:

    exp(-it log(pi)/2) Gamma(s/2)/|Gamma(s/2)| zeta(s)
      = normalized(t).

Both positive-amplitude formulas are checked as well:

    amplitude(t) = pi^(-1/4)|Gamma(s/2)|
                 = exp(-log(pi)/4)|Gamma(s/2)|.

This composes the existing Mathlib continued-zeta product and critical-line
reality facts. It introduces no RH premise and changes no incoming theorem
or definition. Eight phase-transport declarations passed fresh `--trust=0`
compilation, `leanchecker`, and a separate agent's source replay and full
type/axiom audit. Their only axioms are `propext`, `Classical.choice` and
`Quot.sound`. The failed casts/associativity attempts are retained, with the
final corrected source identified separately.

The supplied normalization and five existing companion modules also passed
two fresh scoped source builds and checker runs. Four modules replace the
aggregate `import Mathlib` with named imports; every non-import byte is
identical to the incoming source. The supplied normalization module itself
is byte-identical. The baseline sources match FormalConjectures commit
`70ed9dd8ccc3365c7b5734b781a17f591a0dde0f`. The compiler is Lean4.33.1,
commit `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, and Mathlib is
`0df444a360eaa60ab8c11dca51a86af692955474`.

The current exact-Arb replay reproduces the uploaded t=60 receipt byte for
byte. Its outward Q16 enclosure is `[38466,38467]/65536`, strictly positive.
All22 supplied tests pass in normal Python and under `python -O`. A separate
evaluator, using completed-zeta division and a log-Gamma phase cross-check,
places the value strictly between these endpoints at160,256,384 and512bits.
Both evaluators use the same python-flint0.9.0/Arb special-function library;
this is independently assembled numerical evidence, not a second
special-function kernel implementation.

The exact mathematical expression identity is now a Lean theorem. The Arb
runtime enclosure is not a Lean proof term. In particular,
`Lambda_60_pos_of_normalized_lower` still takes the explicit argument

    h : (38466 : Real)/65536 <= normalized 60.

Its successful kernel audit does not discharge that argument. The interval
certifies one rational height in the stated numerical trust model; it does
not count zeros or control off-line zeros, all shifts, or the full Weil test
class. Repository `Xi` is completed Lambda. The usual entire xi has the
opposite sign on this line because
`xi(s)=-(t^2+1/4)*amplitude(t)*normalized(t)/2`.

`PACKET.zip` and the27 incoming files retain the uploaded bytes. The
incoming `kernel_receipt.json` remains its original `NOT_EXECUTED` snapshot;
current executions have new receipts. Original failed runner/import logs,
including rejected error-recovery `sorryAx` outputs, are retained. Those
failed outputs are not dependencies or positive evidence for the final
eight or eleven audited declarations.

The unit-level `SOURCE_MANIFEST.json` binds exactly the files included here.
Nested historical review manifests preserve their broader original scopes,
including externally retained build objects. All `lib` directories are
excluded from this source unit. Identified imported dependency objects were
reused: the available source/object closure is bound, but Mathlib and the
toolchain were not wholly rebuilt from source. This is scoped replay
evidence and not the final clean transitive RH build.

For another replay, first copy this unit to a new output/work directory.
The actual compiler commands, exact environments, time/RSS limits, source
hashes and outputs are in the final run receipts. The source-build scripts
are `FormalReview/scoped_kernel_replay.py`,
`PhaseTransport/replay_phase_transport.py`, and the independent replay
scripts in their review directories. They require the existing pinned
compiler and the explicitly named dependency context; they do not promise
to recreate missing caches automatically. The point receipt can be checked
read-only with the delivered evaluator:

    python3 Incoming/AEGIS_Hardy_Q16_T60_V1/research/rh/critical_line_v1/hardy_interval_v1.py --verify Incoming/AEGIS_Hardy_Q16_T60_V1/receipt_t60.json

The earlier arithmetic advances and their exact scopes remain preserved in
the preceding logical commits. This point packet supplies no unconditional
producer for `AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign`: the
same detecting packet, every signed-integer log2/log3 shift, all four phases,
and the complete explicit-formula right side must have the required sign.
Unsearched sources remain unknown. `rh_proven=false`; no final RH theorem
is included or claimed. No remote write, push, hosted dispatch or hardware
execution was performed.
