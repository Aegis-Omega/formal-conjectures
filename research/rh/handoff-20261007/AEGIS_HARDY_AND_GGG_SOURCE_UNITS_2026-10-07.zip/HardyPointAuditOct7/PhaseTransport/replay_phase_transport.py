#!/usr/bin/env python3
"""Compile and independently kernel-check only the new phase transport module."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / 'FormalReview/Run-20261007T085543.394114Z'
BIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
LEAN, CHECKER = BIN / 'lean', BIN / 'leanchecker'
SOURCE = ROOT / 'RHHardyPhaseTransportV1.lean'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def affinity():
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})


def main():
    run = ROOT / ('Run-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
    run.mkdir()
    (run / 'lib').mkdir()
    (run / 'logs').mkdir()
    (run / 'RHHardyPhaseTransportV1.lean').write_bytes(SOURCE.read_bytes())
    prior = json.loads((PRIOR / 'RECEIPT.json').read_text())
    env = dict(os.environ)
    env['LEAN_PATH'] = str(run / 'lib') + os.pathsep + prior['LEAN_PATH']
    env['ELAN_TOOLCHAIN'] = 'leanprover/lean4:v4.33.1'
    receipt = {
        'schema': 'AEGIS_HARDY_PHASE_TRANSPORT_SCOPED_REPLAY_V1',
        'status': 'RUNNING', 'run_directory': str(run), 'jobs': [],
        'LEAN_PATH': env['LEAN_PATH'], 'compiler_sha256': sha(LEAN),
        'checker_sha256': sha(CHECKER), 'source_sha256': sha(SOURCE),
        'source_snapshot': str(run / 'RHHardyPhaseTransportV1.lean'),
        'prior_sourcecompiled_closure': str(PRIOR),
        'prior_receipt_sha256': sha(PRIOR / 'RECEIPT.json'),
        'prior_effective_source_hashes': prior['source_bindings'],
        'mathlib_commit': prior['mathlib_commit'],
        'cached_dependencies_reused': True,
        'full_mathlib_source_rebuild': False,
        'wall_seconds_per_job': 90, 'resident_memory_MiB_per_job': 4096,
        'resident_memory_poll_seconds': .05, 'compiler_threads': 1,
        'CPU_affinity_count': 1, 'address_space_limit_used': False,
        'rh_proven': False, 'numeric_enclosure_kernel_verified': False,
        'numeric_lower_bound_asserted': False,
    }

    def save():
        (run / 'RECEIPT.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
        (ROOT / 'LATEST_RUN.json').write_text(json.dumps({'run_directory': str(run)}, indent=2) + '\n')

    def execute(label, argv):
        outpath, errpath = run / 'logs' / (label + '.stdout'), run / 'logs' / (label + '.stderr')
        begin, peak, termination = time.monotonic(), 0, None
        with outpath.open('wb') as out, errpath.open('wb') as err:
            process = subprocess.Popen([str(a) for a in argv], cwd=run,
                env=env, stdout=out, stderr=err, preexec_fn=affinity, start_new_session=True)
            while process.poll() is None:
                try:
                    status = (Path('/proc') / str(process.pid) / 'status').read_text()
                    match = re.search(r'^VmRSS:\s+(\d+) kB$', status, re.M)
                    if match:
                        peak = max(peak, int(match.group(1)))
                except (FileNotFoundError, ProcessLookupError):
                    pass
                if peak > 4096 * 1024:
                    termination = 'RSS_LIMIT'
                    os.killpg(process.pid, 9)
                    break
                if time.monotonic() - begin > 90:
                    termination = 'WALL_LIMIT'
                    os.killpg(process.pid, 9)
                    break
                time.sleep(.05)
            code = process.wait()
        output = outpath.read_text(errors='replace') + errpath.read_text(errors='replace')
        log = run / 'logs' / (label + '.log')
        log.write_text(output)
        receipt['jobs'].append({'label': label, 'argv': [str(a) for a in argv],
            'exit_code': code, 'termination': termination,
            'peak_observed_RSS_KiB': peak, 'wall_seconds': time.monotonic() - begin,
            'stdout_sha256': sha(outpath), 'stderr_sha256': sha(errpath),
            'log': str(log), 'log_sha256': sha(log)})
        save()
        print(json.dumps(receipt['jobs'][-1]), flush=True)
        return code == 0 and termination is None, output

    save()
    ok, version = execute('compiler_version', [LEAN, '--version'])
    receipt['compiler_version'] = version.strip()
    if not ok or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in version:
        receipt['status'] = 'COMPILER_PIN_FAILURE'
        save()
        return
    ok, output = execute('compile_phase_transport', [LEAN, '--trust=0', '-j1', '-M4096',
        '-DwarningAsError=true', '-o', run / 'lib/RHHardyPhaseTransportV1.olean',
        run / 'RHHardyPhaseTransportV1.lean'])
    if not ok:
        receipt['status'] = 'SOURCE_COMPILE_FAILED'
        save()
        return
    receipt['olean_sha256'] = sha(run / 'lib/RHHardyPhaseTransportV1.olean')
    receipt['axiom_report_output'] = output
    ok, _ = execute('checker_phase_transport', [CHECKER, '-v', 'RHHardyPhaseTransportV1'])
    receipt['status'] = 'PASS_SCOPED_PHASE_TRANSPORT' if ok else 'KERNEL_CHECK_FAILED'
    receipt['explicit_exponential_bridge_kernel_verified'] = ok
    receipt['amplitude_identity_kernel_verified'] = ok
    save()


if __name__ == '__main__':
    main()
