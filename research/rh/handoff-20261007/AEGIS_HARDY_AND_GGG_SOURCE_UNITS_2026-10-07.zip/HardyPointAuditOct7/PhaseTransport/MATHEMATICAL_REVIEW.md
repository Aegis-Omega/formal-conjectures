# Ordinary proof and adversarial phase review

Let s = 1/2 + it and g = Gamma(s/2), for real t. Positive pi has principal complex logarithm log(pi), with zero imaginary part. Thus its principal complex power is

    pi^(-s/2) = exp(-(1/4) log(pi)) exp(-it log(pi)/2).

Set p = pi^(-1/4) = exp(-log(pi)/4). Both equalities use the real logarithm, and p > 0. By the definition of the archimedean factor,

    Gamma_R(s) = p exp(-it log(pi)/2) g.

The exponential phase has modulus 1, so

    amplitude(t) = |Gamma_R(s)| = p |g|.

The existing completed-zeta product theorem applies because Re(s)=1/2>0. Dividing Gamma_R(s) zeta(s) by amplitude(t), and cancelling the nonzero real factor p, gives

    exp(-it log(pi)/2) g/|g| zeta(s) = Lambda(s)/amplitude(t).

Existing Xi_im proves Lambda(s) is real on this line, so the last quotient is precisely the complex coercion of normalized(t).

Independent read-only mathematical review confirmed the negative phase sign and this proof. Gamma has no zero or pole here: Re(s/2)=1/4>0. There is no square-root or log-Gamma branch choice: g/|g| determines the unit phase directly. At t=0 the phase is 1. Negative t and zeta zeros cause no exception. The positive pi base excludes the negative-real-axis ambiguity of principal complex powers.

This is an exact identity for the mathematical expression in Incoming/AEGIS_Hardy_Q16_T60_V1/research/rh/critical_line_v1/hardy_interval_v1.py, evaluate. It does not formalize Arb evaluation or establish the numerical enclosure at t=60. In particular, it does not supply the explicit lower-bound hypothesis required by Lambda_60_pos_of_normalized_lower.
