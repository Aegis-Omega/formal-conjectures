# QuantumDNA exact 100 ms phase audit

The actual uploaded packet and its reviewed replay are preserved in
CurrentComparison. HistoricalAuditBeforeAttachment preserves the earlier
scoped source recovery unchanged, including its then-missing period status.
The newly recovered period closes that source-access issue. It does not
recover the original six-site NPZ or prove an RH implication.

For the configured ideal three-site chain, the displayed-period convention
gives 0.9958475177421528; the displayed-J/exact-SI convention gives
0.0908375912952403. Exact conversions give identical phases for 100 ms,
1/10 s, and 10^14 fs within each parameter convention. All figures are
ideal-model extrapolations. Read MATHEMATICAL_AND_SOURCE_REVIEW.md for the
complete mathematical argument and explicit uncertainty assumptions.

The unchanged submitted evaluators were run in separate fresh copies both
normally and under python -O. The two saved output JSONs are reproduced byte
for byte. A separate exact-input checker and another cosine/modulo evaluator
provide scoped independent assembly checks using the same host/Arb library.
No new Lean proof or independent transcendental kernel is claimed.

To reproduce the portable root check with existing python-flint 0.9.0,
create a fresh directory and copy only ROOT_PERIOD_REVIEW_PORTABLE.py,
Incoming, and LibrarySource from CurrentComparison into it. Run
`python3 ROOT_PERIOD_REVIEW_PORTABLE.py` and
`python3 -O ROOT_PERIOD_REVIEW_PORTABLE.py` there. Existing receipt paths
are intentionally refused. No package installation is needed in the
current inspected workspace.

PACKET.zip is the exact original uploaded ZIP. GitBlobReview records actual
retrieval of the known source-audit Git blob, which contains JSON. The new
packet's source_refs identifiers are library IDs. The bounded Git search
does not claim absence of a ZIP from all project history.

The one selected unresolved global mathematical obligation remains
AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign, with the same fixed
detecting packet, all signed-integer log2/log3 shifts, all four phases,
and the full actual Weil RHS. rh_proven=false. No new edge into the RH
equivalence component is obtained from this finite-chain packet.
