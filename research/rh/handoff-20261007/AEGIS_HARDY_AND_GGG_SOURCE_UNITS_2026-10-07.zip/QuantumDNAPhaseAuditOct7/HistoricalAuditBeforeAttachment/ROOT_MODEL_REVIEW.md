# Root reconstruction and exact point checks

The recovered audit, parameter table, converter and solver were read before
accepting any long-time value. The upper coupling is genuinely recorded as
`-0.06200000000000003` in the pinned source audit; it is not an inferred fit
to the user's second number. The original six-site NPZ and comparison ZIP
have not been located in the searched scope. Their absence there does not
establish absence elsewhere.

The paper's six-site reduction is correct for its stated exact-decimal
Hamiltonian. With spatial path eigenvalues sqrt2,0,-sqrt2, its three
two-dimensional Hermitian blocks have eigenvalues mean+gap and mean-gap,
and upper-coordinate spectral weights (1+delta/gap)/2 and
(1-delta/gap)/2. The first-to-third spatial projector weights are1/4,
-1/2,1/4. These are all the modes, including the lower strand and all its
declared couplings. Removing the whole scalar -8 I changes only a common
phase. This reconstructs the stated amplitude and probability without
requiring a very long ODE integration.

I independently implemented that spectral-projector formula and the
three-site cosine formula in a new evaluator which never imports the
other evaluator. At192,256 and320bits, exact-rational inputs and Arb
outward operations prove the strict point enclosures

    0.09083759129524028 < P3(100ms) < 0.09083759129524030,
    0.18099492830375011 < P6_declared(100ms) < 0.18099492830375012,
    0.24520231705939511 < P6_declared(200fs) < 0.24520231705939512.

The same exact time is used for0.1s,100ms and10^14fs. The defining SI
constants h and e were retrieved from the actual NIST Meet the Constants
page. hbar is evaluated as h/(2pi), not the shortened decimal display.
The retained NIST evidence is an MCP text extraction, explicitly distinct
from raw webpage bytes. Failed direct HTTP reads remain recorded.

The first interval reproduces the user's second rounded value only for
the explicitly isolated three-site model and exact audit-display decimal
coupling. It does not identify that model with the original coupled
six-site sweep. The six-site value belongs to a new exact-decimal
reconstruction, consistent with three archived200fs diagnostics but
different from the unrecovered historical binary matrix. The saved-period
value0.99584752 is still not checked without its exact period and evaluator.

The Hamiltonian and hbar perturbation bounds in the independent paper are
valid. Duhamel gives the propagator difference bound. The evolved-density
difference is Hermitian with trace zero, so any effect's expectation
difference is at most half its trace norm; expansion bounds that norm by
twice the operator propagator difference. Minimizing over one scalar
shift of the entire Hermitian matrix therefore gives the stated
measurement bound. Its half-spectral-diameter simplification is correct.
The claimed3.29e-22eV is a sufficient worst-case seven-decimal budget,
not a necessary accuracy for every chosen observable. Failing this bound
does not refute either numerical claim.

The numerical floating-matrix experiment uses a declared reconstructed
binary64 matrix and an explicitly encoded hbar. Centering is an exact
probability invariance mathematically; disagreement between its floating
eigenvalue evaluations exposes algorithmic phase error for that declared
target. It neither changes the missing saved input nor proves that the
original user program has that error. At a zero dephasing rate, a finite
Hermitian system can recur at arbitrarily late times; no decay claim is
inferred from elapsed time alone.

`ROOT_INDEPENDENT_ARB_REVIEW_RECEIPT.json` binds this separate actual
calculation. It uses the same Arb library and host, so this is independent
formula assembly and replay, not an independent special-function kernel.
No qDNA installation/execution, hardware/biological evidence, Lean
kernel theorem or arrow into universal Weil sign/RH is claimed.
