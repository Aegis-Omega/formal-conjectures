"""Independent spectral-projector check of precisely declared auxiliary models.

Never imports the other evaluator or the unavailable original NPZ.
"""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import sys
from flint import arb, acb, fmpq, ctx
import flint

BASE = Path(__file__).resolve().parent
AUDIT = BASE / 'RecoveredSources/genomics/quantum_dna/evidence/source_audit.json'
SHA = '074dd2c4afdafb1991a0917ca3b02e881002e72e92d648681839f7abc887fdf8'

def demand(c, m):
    if not c:
        raise ValueError(m)

def aq(q):
    q = Fraction(q)
    return arb(fmpq(q.numerator, q.denominator))

def exact_endpoint(x):
    demand(x.is_finite() and x.is_exact(), 'inexact endpoint')
    m, e = map(int, x.man_exp())
    return Fraction(m * (1 << e)) if e >= 0 else Fraction(m, 1 << -e)

def record(x):
    lo, hi = exact_endpoint(x.lower()), exact_endpoint(x.upper())
    return {'lower': str(lo), 'upper': str(hi), 'display_only': x.str(60)}

def three(t, j, hbar):
    # Full phase and cosine route, distinct from the supplied sin^4 route.
    full = arb(2).sqrt() * aq(j) * aq(t) / hbar
    return (1 - full.cos()) ** 2 / 4

def six(t, hbar):
    # Spectral projectors for the declared exact-decimal six-site Hamiltonian.
    # Both strand-neighbour cross couplings equal1/250; spatial path modes
    # have eigenvalues +/-sqrt2 and0. Shift the WHOLE matrix by +8 I.
    rt = arb(2).sqrt()
    amplitude = acb(0)
    for lam, weight in ((rt, Fraction(1,4)), (-rt, Fraction(1,4)),
                        (arb(0), Fraction(-1,2))):
        a = aq(Fraction(-31,500)) * lam
        d = aq(Fraction(-4,5)) + aq(Fraction(-33,500)) * lam
        b = aq(Fraction(-3,250)) + aq(Fraction(1,250)) * lam
        mean, delta = (a+d)/2, (a-d)/2
        gap = (delta*delta + b*b).sqrt()
        demand(gap > 0, 'unresolved spectral gap')
        upper = (1+delta/gap)/2
        lower = (1-delta/gap)/2
        u = upper*acb(0, -(mean+gap)*aq(t)/hbar).exp()
        u += lower*acb(0, -(mean-gap)*aq(t)/hbar).exp()
        amplitude += aq(weight) * u
    return (amplitude*amplitude.conjugate()).real

demand(hashlib.sha256(AUDIT.read_bytes()).hexdigest() == SHA,
       'source audit changed')
audit = json.loads(AUDIT.read_text(), parse_float=str)
row = next(r for r in audit['Hamiltonian_observations'] if r['sequence']=='GGG')
coupling = abs(Fraction(row['H12_eV']))
demand(coupling == Fraction('0.06200000000000003'), 'coupling provenance mismatch')
times = [Fraction('0.1')*10**15, Fraction(100)*10**12, Fraction(10**14)]
demand(len(set(times)) == 1, 'unit mismatch')
results = []
for bits in (192, 256, 320):
    with ctx.workprec(bits):
        hbar = aq(Fraction('6.62607015e-34') * 10**15 /
                  Fraction('1.602176634e-19')) / (2*arb.pi())
        p3 = three(times[0], coupling, hbar)
        p6 = six(times[0], hbar)
        p200 = six(Fraction(200), hbar)
        demand(p3 > aq('0.09083759129524028') and
               p3 < aq('0.09083759129524030'), 'three-site strict enclosure')
        demand(p6 > aq('0.18099492830375011') and
               p6 < aq('0.18099492830375012'), 'six-site strict enclosure')
        demand(p200 > aq('0.24520231705939511') and
               p200 < aq('0.24520231705939512'), '200fs strict enclosure')
        results.append({'precision_bits': bits, 'three_site_100ms': record(p3),
                        'six_site_100ms': record(p6), 'six_site_200fs': record(p200),
                        'hbar_eV_fs': record(hbar)})
out = BASE / 'ROOT_INDEPENDENT_ARB_REVIEW_RECEIPT.json'
demand(not out.exists(), 'refusing receipt overwrite')
receipt = {'schema': 'AEGIS_ROOT_DECLARED_GGG_INDEPENDENT_ARB_REVIEW_V1',
           'status': 'PASS_DECLARED_MODELS_ONLY',
           'python': sys.executable, 'python_flint_version': flint.__version__,
           'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'audit_sha256': SHA, 'time_fs': str(times[0]), 'unit_equalities': 2,
           'results': results,
           'independence': 'Separate spectral-projector evaluator, same Arb library/host; no other evaluator imported.',
           'saved_full_NPZ_recovered': False, 'saved_period_row_verified': False,
           'three_site_decimal_coupling_is_binary64': False,
           'six_site_parameters': 'Explicit exact-decimal candidate, not the unavailable stored binary64 model.',
           'RH_connection_established': False, 'rh_proven': False}
out.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'receipt': str(out),
                  'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'strict_P3': ['0.09083759129524028','0.09083759129524030'],
                  'strict_P6_declared': ['0.18099492830375011','0.18099492830375012']},
                 indent=2))
