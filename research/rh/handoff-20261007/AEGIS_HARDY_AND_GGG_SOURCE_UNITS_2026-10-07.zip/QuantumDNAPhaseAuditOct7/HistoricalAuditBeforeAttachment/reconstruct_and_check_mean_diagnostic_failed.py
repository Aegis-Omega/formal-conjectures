#!/usr/bin/env python3
"""Finite checks of DECLARED reconstructions, never the missing archived NPZ.

No qDNA package is installed or executed. Exact-source static review derives the
six-site path-mode formula. Arb checks its finite values with outward rounding.
The three-site upper-chain model is separately and explicitly auxiliary.
"""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal
import hashlib
import json
import math
import sys
import flint
from flint import arb, acb, fmpq, ctx
import mpmath as mp
import numpy as np

HERE=Path(__file__).resolve().parent
PARAM=HERE/'RecoveredSources/genomics/quantum_dna/evidence/Hawke2010_ELM.json'
AUDIT=HERE/'RecoveredSources/genomics/quantum_dna/evidence/source_audit.json'
METRICS=HERE/'RecoveredSources/genomics/quantum_dna/evidence/sweep_metrics.json'
SOURCE_AUDIT_SHA='074dd2c4afdafb1991a0917ca3b02e881002e72e92d648681839f7abc887fdf8'
PLANCK_J_S=Fraction('6.62607015e-34')
ELEMENTARY_C=Fraction('1.602176634e-19')
TIME_UNITS={'s':Fraction(10**15),'ms':Fraction(10**12),'ps':Fraction(10**3),'fs':Fraction(1)}


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def qstr(q):return str(q.numerator)+'/'+str(q.denominator)
def aq(q):return arb(fmpq(q.numerator,q.denominator))


def to_fs(quantity,unit):
    if not isinstance(quantity,(str,int)) or isinstance(quantity,bool):
        raise ValueError('time quantity must be exact string or integer, never float')
    if unit not in TIME_UNITS:raise ValueError('unknown time unit')
    q=Fraction(quantity)
    if q<0:raise ValueError('negative time')
    return q*TIME_UNITS[unit]


def hb_si():return aq(PLANCK_J_S*10**15/ELEMENTARY_C)/(2*arb.pi())


def six_amplitude(t,pars,hb):
    eg,ec,tg,tc,v,d=map(aq,pars)
    def mode(lam):
        # Centering by the complete six-site scalar eg removes a harmless phase.
        a=tg*lam;b=ec-eg+tc*lam;c=v+d*lam
        mu=(a+b)/2;delta=(a-b)/2;r=(delta*delta+c*c).sqrt()
        if not r>0:raise ValueError('unverified nonzero two-mode gap')
        x=r*aq(t)/hb
        return acb(0,-mu*aq(t)/hb).exp()*acb(x.cos(),-delta/r*x.sin())
    rt2=arb(2).sqrt()
    return (mode(rt2)+mode(-rt2))/4-mode(arb(0))/2


def six_probability(t,pars,hb):
    z=six_amplitude(t,pars,hb);p=z.real*z.real+z.imag*z.imag
    if not (p>=0 and p<=1):raise ValueError('point interval failed [0,1] enclosure')
    return p


def three_probability(t,j,hb):
    if j<=0:raise ValueError('positive coupling modulus required')
    return (aq(j)*aq(t)/(arb(2).sqrt()*hb)).sin()**4


def six_matrix(pars):
    eg,ec,tg,tc,v,d=pars
    h=[[Fraction(0)for _ in range(6)]for _ in range(6)]
    for i in range(3):h[i][i]=eg;h[i+3][i+3]=ec;h[i][i+3]=h[i+3][i]=v
    for i in range(2):
        h[i][i+1]=h[i+1][i]=tg;h[i+3][i+4]=h[i+4][i+3]=tc
        h[i][i+4]=h[i+4][i]=d;h[i+1][i+3]=h[i+3][i+1]=d
    return h


def interval(p):return p.str(75,radius=True)


def main():
    if sha(AUDIT)!=SOURCE_AUDIT_SHA:raise ValueError('exact source audit changed')
    params=json.loads(PARAM.read_text(),parse_float=Decimal)
    if params['metadata']['unit']!='100meV' or params['metadata']['tb_model_name']!='ELM':
        raise ValueError('parameter unit/model mismatch')
    raw=params['data']['hole'];scale=Fraction(1,10)
    pars=tuple(Fraction(raw[k])*scale for k in ('E_G','E_C','t_G_G','t_C_C','h_G_C','r+_G_C'))
    if Fraction(raw['r-_C_G'])*scale!=pars[-1]:raise ValueError('cross adjacency coefficients differ')
    audits=json.loads(AUDIT.read_text(),parse_float=Decimal)
    row=next(x for x in audits['Hamiltonian_observations']if x['sequence']=='GGG')
    j=abs(Fraction(row['H12_eV']))
    if abs(Fraction(row['H23_eV']))!=j:raise ValueError('upper-chain couplings differ')
    binary_j=Fraction.from_float(float(row['H12_eV']));binary_j=abs(binary_j)
    times=[to_fs('0.1','s'),to_fs(100,'ms'),to_fs(10**14,'fs')]
    if len(set(times))!=1:raise ValueError('unit equivalent times differ')
    checks={'unit_equalities':2,'negative_input_guards':0}
    for quantity,unit in [(0.1,'s'),('100','unknown'),('-1','fs')]:
        try:to_fs(quantity,unit)
        except ValueError:checks['negative_input_guards']+=1
        else:raise ValueError('malformed time accepted')
    report={'schema':'AEGIS_GGG_DECLARED_RECONSTRUCTIONS_FINITE_CHECK_V1',
        'scope':'NEW declared six-site exact-decimal ELM reconstruction and SEPARATE auxiliary three-site upper chain; missing archived full NPZ is never treated as recovered',
        'original_archived_model_replayed':False,'saved_period_row_replayed':False,
        'rh_proven':False,'hardware_or_biological_evidence':False,
        'source_sha256':sha(Path(__file__)),'parameter_sha256':sha(PARAM),
        'source_audit_sha256':sha(AUDIT),'mpmath_version':mp.__version__,
        'numpy_version':np.__version__,'python_flint_version':flint.__version__,
        'rounding':'Arb outward ball arithmetic; exact rational inputs and Arb pi/sqrt/exp/sin/cos',
        'SI_constants':{'h_J_s':qstr(PLANCK_J_S),'e_C':qstr(ELEMENTARY_C),
            'hbar_eV_fs':'h/e * 10^15 / (2*pi); no displayed hbar decimal substituted'},
        'time_fs':qstr(times[0]),'six_site_parameters_eV':dict(zip(('E_G','E_C','t_GG','t_CC','h_GC','r_GC'),map(qstr,pars))),
        'six_site_H_eV':[[qstr(v)for v in row]for row in six_matrix(pars)],
        'rho0':'|upper G1><upper G1|; diagnostic target upper G3',
        'auxiliary_three_site_coupling_audit_decimal':qstr(j),
        'auxiliary_three_site_coupling_exact_binary64':qstr(binary_j),
        'precisions':[],'checks':checks}
    for precision in (160,224,288):
        ctx.prec=precision;hb=hb_si();entry={'bits':precision,'hbar_eV_fs':interval(hb)}
        entry['six_site_200fs']=interval(six_probability(Fraction(200),pars,hb))
        entry['six_site_100ms']=interval(six_probability(times[0],pars,hb))
        p=three_probability(times[0],j,hb)
        lower=Fraction('0.09083759129524028');upper=Fraction('0.09083759129524030')
        if not(p>aq(lower)and p<aq(upper)):raise ValueError('three-site SI enclosure failed')
        checks['source_decimal_three_site_enclosure']=checks.get('source_decimal_three_site_enclosure',0)+1
        entry['three_site_audit_decimal_100ms']=interval(p)
        entry['three_site_exact_binary64_100ms']=interval(three_probability(times[0],binary_j,hb))
        entry['three_site_raw_parameter_decimal_100ms']=interval(three_probability(times[0],abs(pars[2]),hb))
        hb_printed=aq(Fraction('1.054571817e-34')*10**15/ELEMENTARY_C)
        entry['three_site_printed_hbar_Js_100ms']=interval(three_probability(times[0],j,hb_printed))
        entry['three_site_period_fs']=interval(2*arb.pi()*hb/(arb(2).sqrt()*aq(j)))
        entry['period_count_100ms']=interval(aq(times[0])/(2*arb.pi()*hb/(arb(2).sqrt()*aq(j))))
        report['precisions'].append(entry)
    report['three_site_rational_enclosure']={'lo':qstr(lower),'hi':qstr(upper),'strict':True}
    # Finite sampled mean/maximum, never a continuous-time maximum theorem.
    ctx.prec=224;points=[six_probability(Fraction(i,10),pars,hb_si())for i in range(2001)]
    peak_index=0
    for i,p in enumerate(points):
        if p>points[peak_index]:peak_index=i
        elif i!=peak_index and not p<points[peak_index]:
            raise ValueError('sample maximum undecidable at declared precision')
    sample_mean=sum(points,arb(0))/len(points)
    metrics=json.loads(METRICS.read_text(),parse_float=Decimal)
    saved=next(x for x in metrics if x['sequence']=='GGG'and x['gamma_eV']==0)
    grid_compare={}
    for label,p,field in [('endpoint',points[-1],'target_upper_G3_final_population'),
                          ('maximum',points[peak_index],'target_upper_G3_max_population'),
                          ('mean',sample_mean,'target_upper_G3_mean_population')]:
        discrepancy=p-aq(Fraction(saved[field]));bound=Fraction(1,10**12)
        if not(abs(discrepancy)<aq(bound)):raise ValueError('200fs scalar consistency failed: '+label)
        grid_compare[label]={'reconstructed':interval(p),'archived_display_decimal':str(saved[field]),
                             'difference_interval':interval(discrepancy),'strict_abs_difference_bound':qstr(bound)}
    report['six_site_grid_0_200fs']={'count':2001,'spacing_fs':'1/10','peak_time_fs':qstr(Fraction(peak_index,10)),
        'comparison':grid_compare,'claim':'archived displayed scalar consistency only; no saved density/NPZ byte replay'}
    # Structurally independent dense 6x6 matrix exponential, using existing mpmath.
    mp.mp.dps=100
    mq=lambda q:mp.mpf(q.numerator)/q.denominator
    mh=mq(PLANCK_J_S)*10**15/mq(ELEMENTARY_C)/(2*mp.pi)
    hh=mp.matrix([[mq(x)for x in row]for row in six_matrix(pars)])
    for i in range(6):hh[i,i]-=mq(pars[0])
    mp_results={}
    for t in [Fraction(200),times[0]]:
        u=mp.expm(-1j*hh*mq(t)/mh);p=abs(u[2,0])**2
        ap=six_probability(t,pars,hb_si())
        # This cross-check is diagnostic agreement, not interval proof authority.
        difference=abs(p-mp.mpf(ap.mid().str(90,radius=False)))
        if difference>mp.mpf('1e-50'):raise ValueError('independent dense matrix disagreement')
        mp_results[qstr(t)]={'probability':mp.nstr(p,80),'decimal_precision':100,
                            'abs_disagreement_with_Arb_midpoint':mp.nstr(difference,8)}
    report['independent_matrix_exponential_diagnostic']=mp_results
    # Binary64 algorithm study: same encoded matrix and same encoded hbar each time.
    matrix=np.array([[float(v)for v in row]for row in six_matrix(pars)],dtype=np.float64)
    hb_float=float(mh);float_pars=tuple(Fraction.from_float(float(v))for v in pars)
    float_hb_exact=aq(Fraction.from_float(hb_float))
    exact_encoded=six_probability(times[0],float_pars,float_hb_exact)
    float_rows={}
    for label,mat in [('uncentered_full_matrix',matrix),('subtract_whole_scalar_before_eigh',matrix-pars[0].numerator/pars[0].denominator*np.eye(6))]:
        ev,vec=np.linalg.eigh(mat);amp=sum(vec[2,k]*vec[0,k]*np.exp(-1j*ev[k]*float(times[0])/hb_float)for k in range(6))
        float_rows[label]={'P':float(abs(amp)**2),'method':'numpy.linalg.eigh + binary64 complex phases','spectral_values':[float(x)for x in ev]}
    report['binary64_same_encoded_model_diagnostic']={'exact_encoded_parameters':list(map(qstr,float_pars)),
        'exact_encoded_hbar_eV_fs':qstr(Fraction.from_float(hb_float)),
        'Arb_outward_probability':interval(exact_encoded),'algorithms':float_rows,
        'scope':'Neither row is the absent saved original H/solver; differences expose finite-precision sensitivity for this declared encoded model'}
    report['status']='PASS_DECLARED_RECONSTRUCTIONS_ONLY'
    dest=HERE/('RECONSTRUCTION_RECEIPT_OPTIMIZED.json'if sys.flags.optimize else'RECONSTRUCTION_RECEIPT.json')
    dest.write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':report['status'],'receipt':str(dest),'sha256':sha(dest),
                     'three_site_decimal_interval':report['precisions'][-1]['three_site_audit_decimal_100ms'],
                     'six_site_interval':report['precisions'][-1]['six_site_100ms'],
                     'float_diagnostic':float_rows},sort_keys=True))


if __name__=='__main__':main()
