# GGG at 100 ms: exact units, recovered models, and phase accuracy

## Source recovery and scope

The exact existing AEGIS source is commit
`d766cbf99f0bb1e91300c94bae64c469a5d7d89d`, branch
`feat/quantum-dna-claims-gate-v1`. Eight relevant files are recovered unchanged
with Git blob and SHA256 bindings. Its experiment specification describes a
six-site one-hole extended ladder model (ELM), upper `GGG`, lower `CCC`, starting
at upper G1 and measuring upper G3, for 0–200 fs. The separate 37-state two-particle
reference model is not this sweep.

The source audit explicitly records GGG `H12_eV` and `H23_eV` as
`-0.06200000000000003`. This value was read before testing the user's newer row;
it was not fitted to that row. The audit blob is
`00c415940df653c5787d3cdaec6176f2d70c465a`; recovered SHA256 is
`074dd2c4afdafb1991a0917ca3b02e881002e72e92d648681839f7abc887fdf8`.

The archived source receipt identifies an absent standalone numerical source
commit `b0a840015f92f39ddae65beb7393bf2c91aa816e` and a full saved matrix/states
file `GGG_gamma_0_states.npz`, SHA256
`2cc186e45ecf7f6e1d2bb6525eb41287358b08d830a03583e958e843aa75d843`.
Those exact bytes have not been recovered in the searched local scope. Neither
the newly mentioned comparison ZIP nor its exact saved-period string has been
located there. No claim is made that they do not exist elsewhere.

The original receipt also binds qDNA 1.0.1 wheel SHA256
`3d35c337c5569af508b691b7a0ce37bfe23ffaf8b62f8172f4948dfa1767ff9e`.
That exact wheel was retrieved read-only from PyPI and statically inspected.
It was not installed or executed. Its ELM construction and parameter table
justify the new reconstruction below; they do not identify the absent original
standalone runner's floating-point operation order or saved binary matrix.

## Unit and SI conventions

Exact rational conversions give

\[
 100\,\mathrm{ms}=\tfrac1{10}\,\mathrm{s}=10^{14}\,\mathrm{fs},
 \qquad \frac{10^{14}\,\mathrm{fs}}{200\,\mathrm{fs}}=5\cdot10^{11}.
\]

These three representations give the same mathematical time. The checker uses
strings/integers and `Fraction`, rejecting binary floating-point time inputs,
unknown units, and negative times under both ordinary and optimized Python.

Use exact SI definitions
\(h=6.62607015\cdot10^{-34}\,\mathrm{J\,s}\),
\(e=1.602176634\cdot10^{-19}\,\mathrm C\), and
\(\hbar_{\mathrm{eV\,fs}}=10^{15}h/(2\pi e)\).
The primary NIST page [Meet the Constants](https://www.nist.gov/si-redefinition/meet-constants)
explicitly gives these values. The retained `NISTPrimary` evidence is the actual
MCP-extracted webpage result, not downloaded raw HTTP bytes. Earlier HTTP 403
failures are separately retained. No decimal display of \(\hbar\) is silently
treated as the exact value of \(h/(2\pi)\).

The recovered qDNA converter treats `rad/fs` using \(\hbar\), while `1/fs` uses
\(2\pi\hbar\). These conventions differ by \(2\pi\). Its time options are `fs`
and `ps`; it has no native `s` or `ms` option. `MeSolver` records `t_unit` but
explicitly leaves a TODO to ensure the Hamiltonian and dissipator match it.
Changing a label alone therefore supplies no verified unit conversion.
An external s/ms evaluator must be reviewed separately. The new rational
conversion check here does not certify an unseen wrapper.

## Exact six-site reconstruction

The hole parameter table has unit `100meV`. Interpreting its decimal values
exactly gives, in eV,

\[
 E_G=-8,\quad E_C=-8.8,\quad \tau_G=-0.062,\quad \tau_C=-0.066,
 \quad v=-0.012,\quad d=0.004.
\]

Let \(A\) be the 3-vertex path adjacency matrix. Static qDNA ELM construction
gives the declared six-site Hermitian matrix

\[
 H=\begin{pmatrix}E_G I+\tau_G A&vI+dA\\
                  vI+dA&E_C I+\tau_C A\end{pmatrix}.
\]

The two diagonal hopping conventions in the source both give \(d=0.004\)
for `GGG/CCC`, including the reversed lower-strand direction. The exact 6×6
matrix and initial/measurement definitions are recorded in the numerical
receipt. This is an explicitly declared exact-decimal reconstruction, not the
missing saved binary matrix.

Diagonalize \(A\), whose eigenvalues are \(\lambda=\sqrt2,0,-\sqrt2\).
The tensor spatial change of orthonormal basis reduces \(H\) to three 2×2
Hermitian blocks. Subtract the complete scalar \(E_GI_6\), which changes only
a common phase. For each \(\lambda\), put

\[
 a_\lambda=\tau_G\lambda,\quad
 b_\lambda=E_C-E_G+\tau_C\lambda,\quad
 c_\lambda=v+d\lambda,
\quad \mu_\lambda=(a_\lambda+b_\lambda)/2,
\quad \delta_\lambda=(a_\lambda-b_\lambda)/2,
\quad r_\lambda=\sqrt{\delta_\lambda^2+c_\lambda^2}>0.
\]

Since the centered traceless part squares to \(r_\lambda^2I_2\), its exponential
has upper-to-upper component

\[
 u_\lambda(t)=e^{-i\mu_\lambda t/\hbar}
 \left(\cos(r_\lambda t/\hbar)
       -i\frac{\delta_\lambda}{r_\lambda}\sin(r_\lambda t/\hbar)\right).
\]

The products of the first/third spatial eigenvector coordinates are
\(1/4,-1/2,1/4\). Therefore the exact amplitude and probability are

\[
 F_6(t)=\tfrac14u_{\sqrt2}(t)-\tfrac12u_0(t)
                   +\tfrac14u_{-\sqrt2}(t),\qquad P_6(t)=|F_6(t)|^2.
\]

This closed formula requires no long ODE integration, numerical quadrature, or
asymptotic tail bound. An independent existing mpmath dense 6×6 matrix
exponential at 100 decimal digits agrees with the Arb result within \(10^{-50}\)
at 200 fs and 100 ms. This mpmath agreement is a diagnostic cross-check; Arb
outward intervals carry the finite numerical enclosure.

For this declared exact-decimal model, with exact SI \(h/e\),

\[
 P_6(10^{14}\,\mathrm{fs})
 =0.1809949283037501144952824061591462010594571464\ldots.
\]

This is not a refutation of a different saved-period or saved-matrix model.

## Consistency at the original 200 fs scale

Arb checks the 2001 exact sample times \(i/10\) fs. The new reconstruction
matches three archived displayed diagnostics to strictly less than \(10^{-12}\):

| Diagnostic | Archived display | Exact-decimal reconstruction |
|---|---:|---:|
| Upper G3 at 200 fs | 0.2452023170594009 | 0.2452023170593951… |
| Maximum over the sampled grid | 0.9995589670184082 | 0.9995589670184089… |
| Normalized sampled trapezoidal average | 0.3561418801931714 | 0.3561418801931711… |

The arithmetic mean of the 2001 samples is a different quantity,
0.3560251681883418…, and was initially compared by mistake. That actual rejected
run and source copy are retained. The revised receipt labels the sampled
trapezoidal rule explicitly. Neither average is asserted here to be a certified
continuous-time integral, and the sampled maximum is not a maximum theorem for
every time between samples.

These matches support the reconstruction's model semantics at the archived
scale. They do not recover original density arrays or the long-time binary
matrix/phase convention.

## Auxiliary isolated three-G chain and the user's second row

Remove the lower strand and all its couplings only for this separate auxiliary
model. Its Hamiltonian is \(E I_3+J A\); \(E\) cancels in transition probability.
The same spatial diagonalization now gives

\[
 P_3(t)=\frac{(1-\cos(\sqrt2|J|t/\hbar))^2}{4}
       =\sin^4\left(\frac{|J|t}{\sqrt2\hbar}\right),
 \qquad T=\frac{2\pi\hbar}{\sqrt2|J|}.
\]

The recovered audit's *displayed decimal* \(|J|=0.06200000000000003\), interpreted
as an exact rational, yields

\[
 T=47.16707537466145879000353433743672760863\ldots\,\mathrm{fs},
 \quad t/T=2120122971493.81501155054\ldots,
\]

and at 100 ms the rigorous rational enclosure

\[
 0.09083759129524028<P_3<0.09083759129524030.
\]

This matches the user's `0.09083759` energy/SI row without fitting \(J\).
It is a conditional model identification: the matching computation is an
isolated three-site chain, whereas the original archived QuantumDNA sweep has
six coupled sites. The missing comparison source is needed to establish which
object its rows actually use.

The distinction between exact declared decimals and the stored binary number
already affects the result:

| Auxiliary three-site input | Probability at 100 ms |
|---|---:|
| Exact audit display decimal `0.06200000000000003`, exact SI | 0.090837591295240287… |
| Exact binary64 number obtained from that same display, exact SI | 0.090997455940853333… |
| Raw exact table decimal `0.062`, exact SI | 0.092631694018899142… |
| Audit decimal, printed `hbar=1.054571817e-34 J s` treated as exact | 0.037417139275446309… |

All these are distinct explicitly declared mathematical inputs. None is
silently relabeled as the absent saved original data. The value `0.99584752`
from the saved-period route remains unverified until the exact period string,
its meaning, and evaluator are supplied or recovered. A period approximation
near 47 fs, repeated approximately \(2.12\cdot10^{12}\) times, requires explicit
phase error control.

## Arithmetic precision and adversarial checks

For finite-dimensional Hermitian \(H,H'\), Duhamel's integral gives
\(\|U_H(t)-U_{H'}(t)\|\le |t|\|H-H'\|/\hbar\).
For any density matrix and any effect, the corresponding probability difference
is bounded by the trace distance, hence by that operator difference. A scalar
Hamiltonian shift does not change the channel, so the sharper useful form is

\[
 |P_H(t)-P_{H'}(t)|\le
 \min\left(1,\frac{|t|}{\hbar}
                 \inf_{c\in\mathbb R}\|H-H'-cI\|\right).
\]

At \(t=10^{14}\) fs, an operator residual at most approximately
\(3.29\cdot10^{-22}\) eV is a sufficient worst-case budget for half a unit in
the seventh decimal place. This sufficient condition is not a necessary bound
for every particular matrix/measurement. Only a shift of the **whole** six-site
matrix cancels; shifting the upper strand alone changes relative detuning.

An actual calculation on one explicitly declared binary64 version of the new
six-site matrix illustrates algorithmic error, separately from parameter error.
Arb evaluates its same binary coefficients and binary \(\hbar\) to
\(P=0.18094004921957239389\ldots\). NumPy `eigh` plus binary64 phases gives
0.1458395326906198 without centering, and 0.18005032163302942 after subtracting
the whole scalar before diagonalization. The exact probability is gauge
invariant; these differing numerical outputs expose spectral/large-phase
rounding error. These are actual tests of the declared reconstruction, not
claims about an unseen original evaluator or its output.

Arb was run at 160, 224, and 288 bits with exact rational inputs, outward balls,
and exact-time equality. Ordinary and `python -O` runs returned byte-identical
receipts and rejected the three malformed time cases. The source hashes,
complete inputs, analytic formula, and interval results are retained. This is
not a Lean kernel numerical proof.

Finite closed unitary systems have almost-periodic evolution and can recur.
A long time does not force a transfer probability to zero; this audit never
uses that false inference. Model phases at 100 ms are mathematical
extrapolations of the declared ideal parameters. The archived 200 fs simulation
does not independently validate a physical 100 ms trajectory or biological
effect.

## Exact continuation

Recover the comparison packet's exact saved-period string and executable
measurement definition, or the source-bound primary Hamiltonian/generator and
constants used by that row. The existing numerical receipt identifies the
minimal archived six-site snapshot above. Replay both unit paths with those
same exact inputs before accepting `0.99584752`. This is a concrete input/phase
verification task, not an RH theorem or a universal sign bridge.
`rh_proven=false`.
