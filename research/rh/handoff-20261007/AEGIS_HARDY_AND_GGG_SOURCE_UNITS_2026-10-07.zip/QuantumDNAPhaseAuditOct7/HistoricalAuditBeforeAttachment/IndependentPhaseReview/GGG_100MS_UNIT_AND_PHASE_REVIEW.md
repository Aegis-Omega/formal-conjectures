# Independent GGG 100 ms unit and phase review

Date: 2026-10-07. Status: written mathematical review; no simulation, numerical evaluator, package installation, compiler, or network operation was performed by this reviewer. The scalar claim `P(100 ms) ≈ 0.9958475` has not been verified here. A separate mathematical reviewer, `/root/signed_arithmetic_bridge_oct7/filter_operator_adversary/exact_algebra_review`, independently checked the Duhamel/trace-distance argument, the scalar-gauge refinement, and the auxiliary three-site formulas, with no execution or file edits. This is independent written review, not an independently replayed numerical result.

## Exact source scope

The recovered AEGIS source is repository `Aegis-Omega/AEGIS-OMEGA`, commit `d766cbf99f0bb1e91300c94bae64c469a5d7d89d`. Its audit reports a six-site one-hole model. For GGG it records three equal upper energies `-8.000000000000002 eV`, adjacent upper couplings `-0.06200000000000003 eV`, and maximum interstrand coupling `0.012000000000000004 eV`. The source experiment specification covers 0–200 fs. The audit reads `H_eV` and `rho_qdna` from archived NPZ files, but this review did not inspect those arrays or the standalone run code at reported commit `b0a840015f92f39ddae65beb7393bf2c91aa816e`. Those reported entries alone do not determine the full Hamiltonian.

The next-run contract fixes a localized initial sweep state at site index 0 and distinguishes zero dephasing, with no collapse operators, from positive dephasing. This is a contract specification, not reconstruction of every historical run. Its archived sweep diagnostic is upper-G3 population; the identity of the observable in the user's `P(100 ms)` claim still needs to be bound explicitly.

The separately recovered, statically read qDNA 1.0.1 wheel is bound by SHA256 `3d35c337c5569af508b691b7a0ce37bfe23ffaf8b62f8172f4948dfa1767ff9e`. Its converter uses `scipy.constants.hbar` for angular units `rad/fs`, and `2*pi*hbar` for cyclic-frequency units `1/fs`. Consequently:

- If H is in eV and t in fs, the phase is `H*t/hbar_eV_fs`.
- If the Hamiltonian has already been converted to rad/fs, the phase is `H_rad_fs*t_fs`; dividing by hbar again is wrong.
- Cyclic-frequency and angular-frequency inputs differ by 2π.

`TBHam.unit` changes the stored matrix by floating multiplication. An eV matrix obtained by conversion back from the solver's angular-frequency matrix need not be its exact inverse-conversion target after rounding. A late-time replay must identify the primary matrix actually used in evolution, rather than silently substituting displayed eV entries or an idealized decimal-parameter matrix.

## Exact time and hbar conversion

Exactly, `100 ms = 0.1 s = 10^14 fs`. The archived endpoint 200 fs is `2*10^-13 s`, so the target is `5*10^11` times that endpoint.

Using the exact SI defining constants `h = 6.62607015*10^-34 J s` and `1 eV = 1.602176634*10^-19 J`,

\[
 \hbar_{\rm eV\,fs}
 =\frac{6.62607015}{2\pi\,1.602176634}
 =\frac{1104345025}{534058878\pi}\ \mathrm{eV\,fs}.
\]

Its familiar decimal display is approximately 0.65821195695. This display is not a new interval computation. A source-defined binary `scipy.constants.hbar` is a different exact numerical input unless its approximation error is enclosed and paid for.

## Rigorous unitary and measurement sensitivity

Let H and H' be finite Hermitian matrices, let hbar be positive, and put `U_H(t)=exp(-i*t*H/hbar)`. Duhamel's identity gives

\[
 U_H(t)-U_{H'}(t)
 =-\frac{i}{\hbar}\int_0^t
 U_H(t-s)(H-H')U_{H'}(s)\,ds.
\]

Unitarity of both factors therefore proves

\[
 \|U_H(t)-U_{H'}(t)\|
 \le \min\bigl(2,\ |t|\|H-H'\|/\hbar\bigr).
\]

For any density matrix `rho >= 0`, `tr rho = 1`, and any measurement effect `0 <= E <= I`, define

\[
 p_H(t)=\operatorname{tr}\bigl(E U_H(t)\rho U_H(t)^*\bigr).
\]

Expanding the difference of evolved states gives trace norm at most `2*||U_H-U_H'||`. That difference is Hermitian and has trace zero, so its positive and negative parts each have trace equal to half its trace norm. Since `0 <= E <= I`, the measurement difference is at most that half-norm. This proves the stronger probability estimate

\[
 |p_H(t)-p_{H'}(t)|
 \le \min\bigl(1,\ |t|\|H-H'\|/\hbar\bigr).
 \tag{1}
\]

Only relative energies affect a closed-unitary probability: replacing the *whole* Hamiltonian by `H+cI` multiplies U by one common phase. Thus (1) improves to

\[
 |p_H(t)-p_{H'}(t)|
 \le \min\left(1,\ \frac{|t|}{\hbar}
       \inf_{c\in\mathbb R}\|H-H'-cI\|\right).
 \tag{2}
\]

For Hermitian `H-H'`, this infimum is exactly half its spectral diameter. Equal upper-strand energies permit a common phase removal in an *isolated three-site model*. Removing them from only the upper block of the coupled six-site model changes physical detunings and is not the scalar gauge transformation in (2).

If all 36 entries of a six-site Hamiltonian have absolute perturbation at most eta, then `||H-H'|| <= ||H-H'||_F <= 6*eta`. This is an upper bound, not identification of the actual roundoff error. If the archived binary matrix itself is declared the exact mathematical input, its binary entries have no input uncertainty; the numerical evolution still needs an error bound relative to that exact target.

## What seven decimal places at 100 ms require

For seven-decimal rounding, a natural absolute error budget is `epsilon = 5*10^-8`, together with an enclosure contained in the intended rounding bin. At `t=10^14 fs`, (2) supplies the following *sufficient worst-case* energy-accuracy condition:

\[
 \inf_c\|H-H'-cI\|
 <\frac{\hbar}{2\cdot10^{21}}
 \approx 3.29\cdot10^{-22}\ \mathrm{eV}.
 \tag{3}
\]

This is not a necessary precision for every particular observable. Conserved observables, special states, stationary points, and spectral gap arguments can give much stronger stability. Failure of the bound (3) does not refute `0.9958475`. It means ordinary binary eigensolver accuracy alone has not established that rounded value through this general estimate.

An uncertainty in time satisfies, with `g = inf_c ||H-cI||`,

\[
 |p_H(t+\delta t)-p_H(t)|\le\min(1,|\delta t|g/\hbar).
\]

Thus a sufficient timing budget is `|delta t| < epsilon*hbar/g` when `g>0`. An exact target time of `10^14 fs` avoids input timing uncertainty but still requires phase evaluation with rigorous argument reduction and control of the Hamiltonian's spectral gaps.

If hbar itself changes, the equally rigorous estimate is

\[
 |p_{H,\hbar}(t)-p_{H',\hbar'}(t)|
 \le\min\left(1,|t|\inf_c
 \left\|H/\hbar-H'/\hbar'-cI\right\|\right).
\]

For the same H its sufficient error budget is `|t|*g*|1/hbar-1/hbar'|`. The recovered contract allows hbar within `10^-9` of `0.6582119569`; that checks its approximate physical unit/value, not late-time phases to seven decimals. A passing preflight is not a 100 ms phase certificate.

## Auxiliary exact three-site calculation; not the recovered six-site model

For the explicitly different model

\[
 H_3=E_0I+v\begin{pmatrix}0&1&0\\1&0&1\\0&1&0\end{pmatrix},
 \qquad\theta=\sqrt2 vt/\hbar,
\]

the eigenvalues are `E0`, `E0+sqrt(2)*v`, `E0-sqrt(2)*v`. The normalized eigenvectors are `(1,0,-1)/sqrt(2)` and `(1,+/-sqrt(2),1)/2`. Direct spectral decomposition yields, starting at the first end site,

\[
 p_{1\to1}=\cos^4(\theta/2),\quad
 p_{1\to3}=\sin^4(\theta/2),\quad
 p_{1\to2}=\tfrac12\sin^2\theta.
\]

Starting at the middle site gives `p_2->2 = cos^2 theta`. These formulas have exact recurrence; the propagator modulo its common phase has period `2*pi*hbar/(sqrt(2)*|v|)` for `v != 0`. Total upper-chain population in this isolated auxiliary model is always one. None of these formulas computes a six-site upper-G3 or interstrand-transfer probability.

More generally, a closed finite Hermitian model has probabilities that are finite sums of exponentials of its *energy differences*. They are almost periodic and can recur at arbitrarily late times; commensurate gaps give exact recurrence. Therefore finite dimension and a very long elapsed time do not force probabilities to zero. Positive dephasing is a different dynamics and cannot be assessed by replacing it with this unitary recurrence argument.

## Exact next mathematical input

To assess the claimed scalar, bind the full matrix used by the evolution, its units and conversion constants, the initial density, the measurement effect defining P, gamma/collapse operators if present, and exact target time. For a zero-dephasing claim, an interval-enclosed spectral evaluation of that fully specified six-site target can then establish or reject the seven-decimal value. This review neither computes that value nor identifies a consequence for RH.

## Read-source identities

Paths below are relative to `/workspace/aegis-research/evidence/quantumdna-ggg-100ms-oct7`; hashes were read with `sha256sum`. Historical sources were not changed.

| Source | SHA256 |
|---|---|
| `RECOVERED_SOURCE_BINDINGS.json` | `518236ed0f570cbfc8939b6602276712e2f329ade6f46e6139d070fd8f60b05f` |
| `RecoveredSources/genomics/quantum_dna/evidence/source_audit.json` | `074dd2c4afdafb1991a0917ca3b02e881002e72e92d648681839f7abc887fdf8` |
| `RecoveredSources/genomics/quantum_dna/evidence/source_receipt.json` | `a04849923bfd9876b9a5aa7aeedd367af81b2ea1ff21d04b4fbd402ebc2f047d` |
| `RecoveredSources/genomics/quantum_dna/evidence/source_audit_generator.py` | `2bf9a2675e47c946d57b2845d413e87233968392f587935c9fa7b8b9382bc0fc` |
| `RecoveredSources/genomics/quantum_dna/evidence/experiment_spec.json` | `e2e703e208659eb468a92b336fa5f8a0c41fc2a2ff768ea649fbf84ba044ce61` |
| `RecoveredSources/genomics/quantum_dna/run_contract.py` | `1f6a5f0244c479cd720e8ffb68d440c06401e312a173900b90aa8c50cf1a35cd` |
| `RecoveredSources/genomics/quantum_dna/README.md` | `5a689fa4ef7591290ebafaa10d1150c0255a1f7ec03c93b5663fd09dfa476a4f` |
| `ExternalSources/RETRIEVAL_RECEIPT.json` | `857cb60ac1a5f558b0bbe2e3b37b0047c121168130ac48aaab150d306fa5eaab` |
| `ExternalSources/StaticExtract/qDNA/utils/unit_converter.py` | `ee4463cc43ae7ac6f63520721391459e50535e47e7a61ac602f6090e64070cc5` |
| `ExternalSources/StaticExtract/qDNA/hamiltonian/tb_ham.py` | `481d34882128c65d18cd19ac24e6dee6bf19db8d8c67521521836394fe152096` |
