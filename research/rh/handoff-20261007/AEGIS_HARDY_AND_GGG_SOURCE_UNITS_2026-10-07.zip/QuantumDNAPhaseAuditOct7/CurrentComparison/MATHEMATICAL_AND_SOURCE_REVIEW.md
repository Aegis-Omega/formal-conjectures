# Actual GGG packet and exact 100 ms comparison

The new uploaded ZIP is 32,757 bytes with SHA256
`cd31526cff375182486de992e160c9059de42022a483c55ffbddc58320c39424`.
All 16 raw members are bound in `ARCHIVE_SOURCE_MANIFEST.json`; the original
inner manifest binds the other 15 members. The submitted bytes are preserved.

This packet explicitly selects the **isolated ideal three-site GGG chain**.
Its uniform diagonal is -8.000000000000002 eV, its two identical couplings
are -0.06200000000000003 eV, its displayed first perfect-transfer time is
23.583537687334072 fs, and its displayed recurrence is twice that time.
The original six-site simulation is a separate comparison in the source.
The current calculation must not silently use that six-site observable.

## Exact mathematical identity

Write H = epsilon I + J A with

    A = [[0,1,0], [1,0,1], [0,1,0]].

Direct multiplication gives A^3 = 2 A. Its spectral values are 0, sqrt(2),
and -sqrt(2). For theta = sqrt(2) J t / hbar, spectral interpolation gives

    exp(-i J A t/hbar)
      = I - i sin(theta) A/sqrt(2) + (cos(theta)-1) A^2/2.

The common epsilon phase has modulus one. The (3,1) amplitude is therefore
that common phase times (cos(theta)-1)/2, so

    P13(t) = (1-cos(theta))^2/4
           = sin^4(J t/(sqrt(2) hbar)).

The other populations are (1+cos(theta))^2/4 and sin(theta)^2/2. They sum
identically to one. The first perfect-transfer time is
T = pi hbar/(sqrt(2)|J|); the probability recurrence is 2T. Thus the
period-parameter expression is sin^4(pi t/(2T)). These two descriptions
define the same parameters only when this exact relation holds.

## Two precisely defined parameter conventions

The submitted `compare_100ms.py` reads decimal inputs as exact rationals. Its
100 ms calculation does not round them through binary64. The separate
`compare.py` uses ordinary JSON number parsing for its contextual 60 fs/C6
calculation; that broader parsing policy is not attributed to the 100 ms
evaluator. Exactly 100 ms = 1/10 s = 10^14 fs.

1. Treat the displayed T as exact. At the requested time, rational division
   gives 2,120,122,971,493 whole probability recurrences and an exact remaining
   time of 24.268243952781008 fs. Evaluating the full phase or this reduced
   phase gives the same mathematical probability by periodicity.
   The independently checked strict enclosure is

       0.9958475177421527 < P13 < 0.9958475177421529.

2. Treat the displayed J as exact and use the defining SI constants
   h = 6.62607015e-34 J s and e = 1.602176634e-19 C. Then
   hbar in eV fs is (h * 10^15/e)/(2 pi). The resulting T is
   23.5835376873307293950017672... fs, giving the independently checked bound

       0.09083759129524028 < P13 < 0.09083759129524030.

The difference in the sine argument at 100 ms lies strictly between
0.9440326824959344 and 0.9440326824959345 radians. It is a parameter
consistency issue, not a time-unit inconsistency. The displayed period
implies hbar = 0.658211956950999861... eV fs; SI gives
0.6582119569509065698... eV fs. Both rows are valid calculations of their
explicitly configured ideal model. They are not two contradictory values
for one exactly specified Hamiltonian/hbar pair.

## Actual source and execution checks

The input library object `file_00000000e71c81f4bf78947374be3e7a` was actually
downloaded. Its 5,876 bytes have SHA256
`547b11bf041572bb0cfb2d4d58272abf84f46369551762e67b6bb42f98d42c94`.
The packet's input has exactly one additional final newline and otherwise
identical bytes, so its distinct SHA256 is preserved. JSON values, including
literal decimal strings, agree. The references in this packet are library
IDs; they are not Git blob SHA values.

The actual cited NIST 2022 CODATA PDF was fetched with HTTP 200 and saved as
`NISTReference/all.pdf`, 193,554 bytes, SHA256
`5c4a2c8127a80698d05f4d682bd4cac200dabcd9c2e9dd783661a0aa60f4bb1c`.
Page 1 states both h and e are exact. Its hbar decimals carry an ellipsis;
truncating those printed digits and treating them as the defining constant
would change this very long phase. The calculation instead derives hbar
from h/(2pi). The earlier failed NIST CGI retrievals remain in the earlier
frozen audit and do not describe this successful PDF retrieval.

The original two scripts were statically read before execution. Another
agent executed unchanged scripts in new copies, normally and with python
-O; all four executions passed and reproduced both saved output JSON files
byte for byte. Root separately evaluated the cosine spectral formula,
exact rational phase reduction, and both parameter conventions at 192,
320, and 448 bits using Arb. Root's evaluator does not import either
submitted evaluator. Its normal and optimized executions passed explicit
checks; these checks do not rely on Python assert. All independent numeric
evaluations use the same host and Arb implementation, not an independent
special-function kernel or a Lean numerical proof.

The contextual `compare.py` validator pairs C6 mode data with six expected
values using `zip` without a length check. An isolated empty-table mutation
was actually accepted, normally and with python -O. That falsifies a general
fail-closed input claim for that original guard. The unchanged submitted
source has six entries and its source-bound replay still passes. The new
independent source-bound checker explicitly rejects missing or reordered
objects. The submitted script and all original evidence are preserved.

## Sensitivity and limits

Conditional on rounding T to the nearest 10^-15 fs, T lies within
T_display +/- 5e-16 fs. On that entire interval,

    dP/dT = -2 pi t sin^3(pi t/(2T)) cos(pi t/(2T)) / T^2

is positive, as certified by the interval calculation. Endpoint evaluation
then encloses the whole range inside (0.9958218, 0.9958732). The source does
not guarantee that rounding assumption. A hypothetical relative T interval
of +/-10^-12 has a continuous sine-argument range wider than pi, so its
possible probability range includes all of [0,1]. That is a sensitivity
scenario, not an inferred experimental uncertainty.

The original replay ends at 200 fs; 100 ms is 5e11 times that endpoint.
No saved full-six-site 100 ms sample, physical lifetime, uncertainty bound,
or laboratory validation has been recovered. The source's additional
six-site summaries are not all independently replayed by this packet.

The Hardy ordinate t=60 and C6 dimensionless time are different coordinates.
No operator intertwiner or mapping from either to this physical time is
provided. Finite-chain unitary evolution does not prove boundedness or
positivity of the actual zeta-zero detecting kernel.

## Relation to the preceding scoped audit

The earlier `quantumdna-ggg-100ms-oct7` audit recovered the saved repository
Hamiltonian audit and reproduced the displayed-J/SI row in a declared
three-site model; it had not yet located the saved period. This new source
closes that source-access uncertainty and verifies the period row. It does
not retroactively change the earlier inspected scope or recover the old
full NPZ. The previous exact-decimal six-site reconstruction remains a
separately labeled candidate with its own parameter contract.

No Lean kernel proof is claimed for these new interval computations.
`rh_proven=false`. The selected unresolved RH obligation remains
`AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign`, for the same fixed
detecting packet, every signed-integer log2/log3 shift, and all four phases
of the full actual Weil right side. No new arrow into that global sign
obligation is established by this packet.
