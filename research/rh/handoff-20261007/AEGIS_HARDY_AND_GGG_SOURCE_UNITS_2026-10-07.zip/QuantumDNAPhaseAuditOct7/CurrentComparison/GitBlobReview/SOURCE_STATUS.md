# Git-blob retrieval status

Git-blob retrieval is feasible and has been performed with the real command:

    git -C /workspace/aegis-research/aegis cat-file blob 00c415940df653c5787d3cdaec6176f2d70c465a

The 8,247 bytes were preserved in the run directory as source_audit_FROM_GIT_BLOB.json. SHA256 is 074dd2c4afdafb1991a0917ca3b02e881002e72e92d648681839f7abc887fdf8. Recomputing the Git object ID from raw bytes, and git hash-object without writing, both reproduce the supplied Git SHA. The same blob bytes are available in the fork store. This payload is valid JSON and is not a ZIP archive.

The known source tree at d766cbf99f0bb1e91300c94bae64c469a5d7d89d, the two already available repository HEAD trees, and the existing saved fork filename inventory contain no exact AEGIS_QuantumDNA_v1.zip or AEGIS_Quantum_100ms_Comparison_V1.zip path/object reference. This bounded check does not prove absence from all Git history or from external storage.

The Comparison ZIP itself is already available as an authorized attachment. Its raw bytes are 32,757 bytes, SHA256 cd31526cff375182486de992e160c9059de42022a483c55ffbddc58320c39424; ZIP CRC verification passes. Its calculated content-based Git blob ID would be 9c70dcf58127119e7053d6bebfc9c88c5f156db5, but that object is absent from both local stores. Calculating a Git ID does not establish that Git stores the bytes.

Library/upload identifiers libfile_* and file_* are separate identifiers, not Git SHAs. The file_00000000e71c81f4bf78947374be3e7a reference names the individual quantumdna_pst_enaqt_probe_v1.json input, rather than the original AEGIS_QuantumDNA_v1.zip archive.

The saved script disables Git lazy fetch and makes no Git-object or remote writes. Before this script, a targeted lookup of the calculated Comparison oid caused both partial clones to request that one oid remotely; both returned upload-pack: not our ref. No ZIP or pack was retrieved. Those earlier calls are explicitly distinguished from the script's local-only checks in the receipt.
