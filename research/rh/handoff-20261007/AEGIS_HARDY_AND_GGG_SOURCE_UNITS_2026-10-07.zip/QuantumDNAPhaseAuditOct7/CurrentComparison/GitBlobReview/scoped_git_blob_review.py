#!/usr/bin/env python3
"""Bounded local-only retrieval and provenance review of known QuantumDNA Git objects."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parent
AEGIS = ['git', '-C', '/workspace/aegis-research/aegis']
FORK = ['git', '--git-dir=/workspace/aegis-research/secondary/aegisomega.git']
COMMIT = 'd766cbf99f0bb1e91300c94bae64c469a5d7d89d'
AUDIT = '00c415940df653c5787d3cdaec6176f2d70c465a'
INVENTORY = Path('/workspace/aegis-research/evidence/secondary-aegisomega-filename-inventory-v1.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob_oid(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def main():
    run = ROOT / ('Run-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
    run.mkdir()
    env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
    jobs = []

    def git(label, prefix, args, raw=False):
        command = prefix + args
        result = subprocess.run(command, capture_output=True, env=env, timeout=20)
        stdout, stderr = run / (label + '.stdout'), run / (label + '.stderr')
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        jobs.append({'label': label, 'argv': command, 'exit_code': result.returncode,
            'stdout': str(stdout), 'stdout_sha256': sha(result.stdout),
            'stderr': str(stderr), 'stderr_sha256': sha(result.stderr)})
        return result if raw else result.stdout.decode(errors='replace').strip()

    scopes = []
    matcher = re.compile(r'quantumdna|quantum.?100ms|quantum[_-]dna|\.zip$', re.I)
    exact_zip = re.compile(r'AEGIS_QuantumDNA_v1\.zip|AEGIS_Quantum_100ms_Comparison_V1\.zip', re.I)
    for label, prefix, ref in [('aegis_recover', AEGIS, COMMIT), ('aegis_head', AEGIS, 'HEAD'),
                               ('fork_head', FORK, 'HEAD')]:
        pin = git(label + '_pin', prefix, ['rev-parse', ref])
        result = git(label + '_tree', prefix, ['ls-tree', '-r', pin], raw=True)
        assert result.returncode == 0
        lines = result.stdout.decode().splitlines()
        matched = [line for line in lines if matcher.search(line.split('\t', 1)[-1])]
        scopes.append({'label': label, 'commit': pin, 'tree_file_entries': len(lines),
            'targeted_matches': matched,
            'exact_zip_path_matches': [line for line in lines if exact_zip.search(line)]})

    audit_type = git('audit_type', AEGIS, ['cat-file', '-t', AUDIT])
    audit_result = git('audit_blob_retrieval', AEGIS, ['cat-file', 'blob', AUDIT], raw=True)
    assert audit_result.returncode == 0 and audit_type == 'blob'
    raw = audit_result.stdout
    json.loads(raw)
    assert blob_oid(raw) == AUDIT
    audit_path = run / 'source_audit_FROM_GIT_BLOB.json'
    audit_path.write_bytes(raw)
    fork_result = git('fork_audit_blob_retrieval', FORK, ['cat-file', 'blob', AUDIT], raw=True)
    assert fork_result.returncode == 0 and fork_result.stdout == raw
    git_hash = git('audit_hash_object_no_write', AEGIS, ['hash-object', '--no-filters', str(audit_path)])
    assert git_hash == AUDIT

    inventory_raw = INVENTORY.read_bytes()
    inventory = json.loads(inventory_raw)
    known_entries = [entry for entry in inventory['files']
        if matcher.search(entry.get('path', ''))]
    inventory_zip_hits = [entry for entry in inventory['files']
        if exact_zip.search(entry.get('path', ''))]

    attachment_manifest = EVIDENCE / 'ARCHIVE_SOURCE_MANIFEST.json'
    attachment_manifest_raw = attachment_manifest.read_bytes()
    manifest = json.loads(attachment_manifest_raw)
    archive = Path(manifest['zip_path'])
    archive_raw = archive.read_bytes()
    oid = blob_oid(archive_raw)
    assert sha(archive_raw) == manifest['zip_sha256']
    with zipfile.ZipFile(archive) as z:
        bad_member = z.testzip()
        count = len(z.infolist())
    local_presence = []
    for label, prefix in [('aegis', AEGIS), ('fork', FORK)]:
        result = git(label + '_comparison_zip_oid_local_lookup', prefix,
            ['cat-file', '-t', oid], raw=True)
        local_presence.append({'repository': label, 'object_lookup_exit_code': result.returncode,
            'object_type': result.stdout.decode(errors='replace').strip(),
            'object_present': result.returncode == 0})

    receipt = {
        'schema': 'AEGIS_QUANTUM_SCOPED_GIT_BLOB_REVIEW_V1',
        'status': 'KNOWN_JSON_BLOB_RETRIEVED_ORIGINAL_ZIP_NOT_LOCATED',
        'run_directory': str(run), 'jobs': jobs,
        'scope': 'Two available repository HEAD trees, one known QuantumDNA recovery commit, and the existing saved fork filename inventory. Not an all-history or all-branches search.',
        'source_repo_commit': COMMIT, 'trees': scopes,
        'retrieval': {'git_oid': AUDIT, 'object_type': audit_type,
            'path': str(audit_path), 'bytes': len(raw), 'sha256': sha(raw),
            'computed_git_blob_oid': blob_oid(raw), 'git_hash_object_matches': True,
            'first_four_bytes_hex': raw[:4].hex(), 'valid_json': True,
            'is_zip': zipfile.is_zipfile(audit_path),
            'same_blob_bytes_in_aegis_and_fork': True,
            'source_path_at_commit': 'genomics/quantum_dna/evidence/source_audit.json'},
        'existing_inventory': {'path': str(INVENTORY), 'sha256': sha(inventory_raw),
            'targeted_entries': known_entries, 'exact_zip_path_matches': inventory_zip_hits},
        'comparison_attachment': {'path': str(archive), 'bytes': len(archive_raw),
            'sha256': sha(archive_raw), 'valid_zip': zipfile.is_zipfile(archive),
            'CRC_bad_member': bad_member, 'file_count': count,
            'computed_git_blob_oid': oid,
            'derived_oid_is_not_proof_of_git_presence': True,
            'local_object_lookups': local_presence,
            'attachment_manifest': str(attachment_manifest),
            'attachment_manifest_sha256': sha(attachment_manifest_raw)},
        'library_file_ids_are_not_git_object_ids': True,
        'original_QuantumDNA_zip_git_blob_located': False,
        'comparison_zip_git_blob_located': False,
        'git_lazy_fetch_disabled_for_this_script': True,
        'explicit_fetches': False, 'remote_writes': False, 'git_object_writes': False,
        'original_and_other_evidence_modified': False,
        'prior_ad_hoc_lookup': 'Before this script, the derived Comparison ZIP oid was queried without GIT_NO_LAZY_FETCH; both partial clones attempted a targeted lazy remote lookup and returned upload-pack: not our ref. No ZIP or pack was retrieved. Those lookups are not presented as local-only.',
        'script_sha256': sha(Path(__file__).read_bytes()),
    }
    (run / 'RECEIPT.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    (ROOT / 'LATEST_RUN.json').write_text(json.dumps({'run_directory': str(run)}, indent=2) + '\n')
    print(json.dumps({'status': receipt['status'], 'run_directory': str(run),
        'retrieved_audit_git_oid': AUDIT, 'retrieved_audit_sha256': sha(raw),
        'retrieved_audit_bytes': len(raw), 'audit_is_zip': receipt['retrieval']['is_zip'],
        'comparison_zip_oid': oid, 'local_comparison_zip_presence': local_presence}, indent=2))


if __name__ == '__main__':
    main()
