"""Independent exact-input review of the uploaded three-site GGG comparison.

Uses the cosine spectral formula and rational modulo reduction. Never imports
the packet evaluators. An Arb enclosure is not a Lean proof or measurement.
"""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import sys
import flint
from flint import arb, fmpq, ctx

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'Incoming/AEGIS_Quantum_100ms_Comparison_V1'
LIBRARY = BASE / 'LibrarySource/quantumdna_pst_enaqt_probe_v1.json'

def demand(c, message):
    if not c:
        raise ValueError(message)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def aq(q):
    q = Fraction(q)
    return arb(fmpq(q.numerator, q.denominator))

def endpoint(x):
    demand(x.is_finite() and x.is_exact(), 'endpoint is not an exact dyadic')
    m, e = map(int, x.man_exp())
    return Fraction(m * (1 << e)) if e >= 0 else Fraction(m, 1 << -e)

def rec(x):
    return {'lower': str(endpoint(x.lower())),
            'upper': str(endpoint(x.upper())), 'display_only': x.str(60)}

manifest = json.loads((SOURCE / 'manifest.json').read_text())
members = {str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file()}
demand(members == set(manifest) | {'manifest.json'}, 'missing or surplus archive members')
for name, h in manifest.items():
    demand(sha(SOURCE / name) == h, 'altered packet member: ' + name)
packet = SOURCE / 'input/quantumdna_pst_enaqt_probe_v1.json'
demand(packet.read_bytes() == LIBRARY.read_bytes() + b'\n',
       'library source differs beyond the explicitly added final newline')
dna = json.loads(packet.read_text(), parse_float=str)
demand(dna == json.loads(LIBRARY.read_text(), parse_float=str), 'library JSON differs')
chain = dna['ggg_exact_top_chain']
energy, coupling = Fraction(chain['epsilon_eV']), Fraction(chain['J_eV'])
matrix = [[Fraction(str(x)) for x in row] for row in chain['matrix_eV']]
demand(matrix == [[energy, coupling, 0], [coupling, energy, coupling],
                  [0, coupling, energy]], 'wrong uniform chain')
period = Fraction(chain['predicted_first_perfect_transfer_time_fs'])
demand(period > 0 and Fraction(chain['predicted_recurrence_period_fs']) == 2*period,
       'invalid first-PST or recurrence period')
times = [Fraction('0.1')*10**15, Fraction(100)*10**12, Fraction(10**14)]
demand(len(set(times)) == 1, 'unit conversion differs')
time = times[0]
cycles = time // (2*period)
remainder = time - cycles*2*period
demand(cycles == 2120122971493 and
       remainder == Fraction('24.268243952781008'), 'exact cycle reduction differs')
rows = []
for bits in (192, 320, 448):
    with ctx.workprec(bits):
        # Endpoint amplitude of exp(-i J A t / hbar) is (cos(theta)-1)/2.
        phase = arb.pi()*aq(time/period)
        full = (1-phase.cos())**2/4
        reduced = (1-(arb.pi()*aq(remainder/period)).cos())**2/4
        demand(full > aq('0.9958475177421527') and
               full < aq('0.9958475177421529'), 'saved-period strict enclosure failed')
        demand(full.overlaps(reduced), 'full and modulo probabilities disagree')
        hbar = aq(Fraction('6.62607015e-34')*10**15 /
                  Fraction('1.602176634e-19'))/(2*arb.pi())
        energy_phase = arb(2).sqrt()*aq(abs(coupling)*time)/hbar
        si = (1-energy_phase.cos())**2/4
        demand(si > aq('0.09083759129524028') and
               si < aq('0.09083759129524030'), 'SI strict enclosure failed')
        half_phase_difference = (energy_phase-phase)/2
        demand(half_phase_difference > aq('0.9440326824959344') and
               half_phase_difference < aq('0.9440326824959345'), 'phase difference differs')
        half_unit = Fraction(1, 2*10**15)
        lo, hi = period-half_unit, period+half_unit
        pb = aq(lo).union(aq(hi))
        argument = arb.pi()*aq(time)/(2*pb)
        derivative = -2*arb.pi()*aq(time)/pb**2*argument.sin()**3*argument.cos()
        demand(derivative > 0, 'conditional rounding interval not monotone')
        lower = (1-(arb.pi()*aq(time/lo)).cos())**2/4
        upper = (1-(arb.pi()*aq(time/hi)).cos())**2/4
        demand(lower > aq('0.9958218') and upper < aq('0.9958732'),
               'conditional rounding enclosure failed')
        err = Fraction(1, 10**12)
        width = arb.pi()*aq(time)/2*aq(1/(period*(1-err))-1/(period*(1+err)))
        demand(width > arb.pi(), 'hypothetical phase interval shorter than one period')
        rows.append({'bits': bits, 'saved_period_probability': rec(full),
                     'exact_modulo_probability': rec(reduced),
                     'energy_SI_probability': rec(si),
                     'sine_argument_difference_radians': rec(half_phase_difference),
                     'conditional_rounding_derivative_per_fs': rec(derivative),
                     'conditional_rounding_lower_endpoint': rec(lower),
                     'conditional_rounding_upper_endpoint': rec(upper),
                     'hypothetical_relative_error_phase_width': rec(width)})
destination = BASE / ('ROOT_PERIOD_REVIEW_PORTABLE_OPTIMIZED_RECEIPT.json' if sys.flags.optimize
                      else 'ROOT_PERIOD_REVIEW_PORTABLE_RECEIPT.json')
demand(not destination.exists(), 'refusing to overwrite a receipt')
result = {'schema': 'AEGIS_INDEPENDENT_EXACT_PERIOD_COMPARISON_REVIEW_V1',
          'status': 'PASS_CONFIGURED_THREE_SITE_MODEL',
          'source_sha256': sha(Path(__file__)), 'python': sys.executable,
          'python_flint_version': flint.__version__, 'optimized': bool(sys.flags.optimize),
          'inner_manifest_bound_members': len(manifest),
          'packet_input_sha256': sha(packet), 'library_input_sha256': sha(LIBRARY),
          'library_file_id': 'file_00000000e71c81f4bf78947374be3e7a',
          'library_raw_bytes_equal': False, 'only_added_final_newline': True,
          'library_json_equal': True, 'time_fs': str(time),
          'first_PST_fs': str(period), 'completed_cycles': cycles,
          'exact_remainder_fs': str(remainder), 'results': rows,
          'independence': 'Separate evaluator, same host and Arb library; packet code never imported.',
          'rounding_diagnostic_requires_unverified_nearest_rounding_assumption': True,
          'relative_error_scenario_is_hypothetical': True,
          'full_six_site_long_time_prediction_verified': False,
          'parameter_uncertainty_guarantee_recovered': False,
          'Lean_kernel_check': 'NOT_RUN', 'RH_connection_established': False,
          'rh_proven': False, 'remote_written': False}
destination.write_text(json.dumps(result, sort_keys=True, indent=2)+'\n')
print(json.dumps({'status': result['status'], 'receipt': str(destination),
                  'sha256': sha(destination), 'source_sha256': result['source_sha256']}, indent=2))
