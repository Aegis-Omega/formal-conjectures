# Fresh scoped replay of the actual 100 ms packet

This review read the two submitted evaluators, the exact three-site model,
saved outputs, C6 source, and both submitted explanatory reports before running
the code. The original input packet and all earlier frozen audit units remain
unchanged. Only copied evaluators and inputs in this review directory were run.

The actual received packet establishes that its selected object is the
**isolated ideal three-site GGG chain**. Its declared decimal parameters are
epsilon = -8.000000000000002 eV and J = -0.06200000000000003 eV. Its declared
first perfect-transfer time is T = 23.583537687334072 fs. This newly recovered
period is a genuine source field; it was not chosen by fitting the reported
100 ms probability. The earlier audit's narrower source-access uncertainty is
updated here without changing its preserved bytes or old search scope.

## Mathematical target and parameter conventions

For H = epsilon I + J A, with A the three-site path adjacency, direct
multiplication gives A^3 = 2A. Its spectral values are 0 and +/-sqrt(2).
Therefore, for theta = sqrt(2) J t / hbar,

    exp(-i J A t/hbar)
      = I - i sin(theta) A/sqrt(2) + (cos(theta)-1) A^2/2.

Starting at site 1, the populations are

    P11 = (1+cos(theta))^2/4,
    P12 = sin(theta)^2/2,
    P13 = (1-cos(theta))^2/4 = sin^4(theta/2).

The common epsilon phase cancels, and these populations sum exactly to one.
The first transfer time is pi*hbar/(sqrt(2)*abs(J)); the probability recurrence
is twice that first transfer time. Thus P13 = sin^4(pi*t/(2T)) is the same
energy-defined model only if the exact relation between T, J, and hbar holds.

The packet deliberately compares two exact parameter conventions:

| Convention | Fresh checked P13 at exactly 100 ms |
| --- | --- |
| Printed T taken literally as exact | 0.9958475177421528... |
| Printed J taken literally, hbar derived from exact SI h and e | 0.0908375912952403... |

In either convention, 100 ms = 1/10 s = 10^14 fs exactly. Converting T or
angular frequency into the same unit preserves the phase exactly. The two
columns differ because the printed T does not coincide with the SI-derived T,
not because time-unit conversion changes a probability.

The saved period implies hbar = sqrt(2)*abs(J)*T/pi in eV fs. The second
column uses hbar = h/(2*pi*eV_J), with h = 6.62607015e-34 J s and
eV_J = 1.602176634e-19 J/eV. The independently checked saved diagnostics give
SI T minus displayed T approximately -3.342604998232831e-12 fs and a
sine-argument difference approximately 0.9440326824959344 radians at 100 ms.
The source supplies no physical uncertainty guarantee for either printed
parameter. Arb controls arithmetic error for these configured inputs.

## Actual execution and interval checks

`run_reviewed_evaluators.py` first checks the reviewed source SHA256 values,
then creates fresh normal and optimized replay copies. The original
`compare.py` and `compare_100ms.py` each exited zero under ordinary Python
and `python -O`. Both output JSON files are byte-identical to the submitted
outputs and identical between optimization modes:

- comparison.json: fdc0a55037106e8bb201898dbfce29ce153199eb5fd9d1e45fcf9e440008c471
- comparison_100ms.json: 69d062acb15361eb799e905e3b51168c391d1948302beb361473836e493455c0

`verify_configured_comparison.py` separately parses the supplied model's
decimal tokens directly as exact rational numbers. It does not import either
submitted evaluator. At 384, 448, and 512 Arb bits it evaluates the independent
half-angle population formulas

    P11 = cos(u)^4, P12 = 2*sin(u)^2*cos(u)^2, P13 = sin(u)^4.

Its 132 checks include containment of fresh narrow intervals in the submitted
256-bit bounds for every population and both conventions in all three units,
all saved phases and parameter diagnostics, exact rational cycle reduction,
population conservation, conditional endpoint/hull bounds, and the stipulated
sensitivity width. This is stronger than using interval overlap alone for
the submitted point bounds. Normal and optimized checker receipts are
byte-identical, and their ten explicit negative guards pass without `assert`.
Actual commands, exits, stdout, and stderr are in CheckerExecution/EXECUTION.json.

The initial 90-check receipts were preserved under InitialCheckerReplay when
the checker was expanded to verify phases and parameter diagnostics. They are
historical preliminary executions, not the final checker/source binding.
The original 90-check source bytes were reconstructed by reversing the four
recorded additions and verified against those actual earlier receipt hashes.
This is explicitly a reconstruction, not a freshly found old snapshot or an
additional execution; the relocated archive copy retains its original source
bytes and original relative-path layout assumptions.

The exact recurrence count is 2,120,122,971,493. Its remaining time is exactly
1516765247048813/62500000000000 fs = 24.268243952781008 fs. Periodicity explains
agreement of the full and rationally reduced phase; numerical overlap is a
diagnostic for this separately established exact identity.

All these interval replays use the same installed python-flint 0.9.0/Arb
implementation. They are not an independent special-function kernel or a
Lean rational numerical proof. No compiler execution or RH proof is claimed.

## Paid conditional uncertainty

Under the additional hypothesis that displayed T is nearest-rounded to
1e-15 fs, its uncertainty interval is T +/- 5e-16 fs. The derivative is

    dP/dT = -2*pi*t*sin(u)^3*cos(u)/T^2, u = pi*t/(2T).

The fresh interval check establishes positive derivative on the complete
stipulated interval. A separate reviewer also gives an exact integer/rational
proof: t/(2T) has fractional part between .51 and .52, and the entire period
perturbation changes that ratio by less than 1/21160. Thus the sine argument
modulo pi stays strictly between pi/2 and pi, where sin(u)^3*cos(u) < 0.
Endpoint values and their interval convex hull enclose the full monotone range,
approximately [0.99582180736, 0.99587314919]. The source does not guarantee the
rounding hypothesis; the review never converts it into a measured error bar.

A different hypothetical uncertainty T*(1 +/- eta), eta=1e-12, yields a
continuous sine-argument interval of width

    pi*t*eta / (T*(1-eta^2)) > pi,

because t*eta = 100 fs and T < 24 fs. Since sin^4 has period pi and attains
zero and one in every full period, the possible image is exactly [0,1]. This
is a conditional range theorem, not an inference that the actual physical
parameters have this uncertainty.

## Actual guard falsifier and scoped correction

The original `compare.py` compares C6 mode values using `zip(actual, spectrum)`
without first checking the number of source modes. In an isolated copied
input, replacing `mode_table` by an empty list makes every comparison vacuous.
Both normal and optimized original evaluator runs still exit zero. The actual
logs and altered-input hash are preserved in OriginalC6GuardFalsifier.

This falsifies the standalone evaluator's general source-cardinality guard;
it does not falsify the C6 identity or the untouched submitted outputs. Its
output still hashes the altered input, so a correctly pinned external source
binding would reject this changed source. The new scoped verifier explicitly
requires all six ordered modes and rejects the same missing-mode family. It
also rejects a missing three-site matrix row, altered hopping, zero period,
missing/reordered time rows, wrong probability bounds, a zero denominator,
false full-six-site authority, and promotion of conditional uncertainty.

`compare_100ms.py` reads decimal tokens without binary64. The older general
`compare.py` uses ordinary JSON floats and `Fraction(str(float))`; the current
period token round-trips unchanged, but this is not a general exact-decimal
parsing guarantee. The final independent point checker uses exact tokens.

## Limits and recovered source scope

The new source is a three-site ideal model, distinct from the reported coupled
six-site short-time simulation. No original full-six-site 100 ms sample,
physical lifetime, or experimental long-time validation is established.
The source replay ends at 200 fs, while the target is 5e11 times that endpoint.
The packet's additional six-site statistics, QER historical replay, and copied
Hardy point receipt are not newly replayed by this work.

The library source references are library file IDs rather than Git blob IDs.
Root separately retrieved the minimal library source, identified its sole
additional/omitted final-newline distinction, and obtained the cited NIST PDF.
Those actual retrievals and primary-read receipts remain in the parent audit
directory, bound separately by root. Earlier unsuccessful searches remain
preserved with their historical scope.

Neither the dimensionless C6 time nor the Hardy spectral ordinate is given a
map to physical seconds or to this ideal-chain generator. Finite-dimensional
unitary recurrence and positive populations cannot prove the full actual
Weil detecting-kernel sign. This packet adds no unconditional edge into the
RH-equivalence component. `rh_proven=false`.

IndependentMathReview contains the separate ordinary mathematical review and
exact derivative/range arguments; it does not claim fresh numeric execution.
Reproducing the final checker in a new output file requires only the already
available Python/flint environment:

    python3 verify_configured_comparison.py /absolute/path/to/new-receipt.json
    python3 -O verify_configured_comparison.py /absolute/path/to/other-new-receipt.json

The checker refuses to overwrite prior receipts. The original evaluator-copy
orchestration also refuses to overwrite prior replay directories.
