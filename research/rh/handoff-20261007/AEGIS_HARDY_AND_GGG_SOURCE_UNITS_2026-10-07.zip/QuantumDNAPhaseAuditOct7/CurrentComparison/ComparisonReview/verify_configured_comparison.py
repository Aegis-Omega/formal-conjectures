"""A scoped independent exact-input/Arb verifier; no physical or RH authority."""
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import sys

import flint
from flint import arb, ctx

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "Incoming/AEGIS_Quantum_100ms_Comparison_V1"
DNA_HASH = "24b7d6aef26173b6d78b3ae1586b5f3d73aa55a287908b92846bf60b35817b8d"
UNITS = ("seconds", "milliseconds", "femtoseconds")
LABELS = ("P_1to1", "P_1to2", "P_1to3")
PRECISIONS = (384, 448, 512)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text(), parse_float=str)

def exact(record):
    require(isinstance(record, dict) and set(record) == {"numerator", "denominator"}, "invalid rational record")
    n, d = record["numerator"], record["denominator"]
    require(isinstance(n, str) and isinstance(d, str), "rational integers must be strings")
    require(re.fullmatch(r"-?(0|[1-9][0-9]*)", n) is not None, "noncanonical rational numerator")
    require(re.fullmatch(r"[1-9][0-9]*", d) is not None, "nonpositive rational denominator")
    value = Fraction(int(n), int(d))
    require(str(value.numerator) == n and str(value.denominator) == d, "rational fraction is not reduced")
    return value

def packed(value):
    return {"numerator": str(value.numerator), "denominator": str(value.denominator)}

def endpoint(value):
    m, e = map(int, value.man_exp())
    return Fraction(m << e) if e >= 0 else Fraction(m, 1 << -e)

def bounds(value):
    return endpoint(value.lower()), endpoint(value.upper())

def interval(record):
    require(isinstance(record, dict) and {"lower", "upper"}.issubset(record), "missing interval endpoints")
    lo, hi = exact(record["lower"]), exact(record["upper"])
    require(lo <= hi, "reversed interval endpoints")
    return lo, hi

def contains_saved(record, fresh, message):
    lo, hi = interval(record)
    fl, fh = bounds(fresh)
    require(lo <= fl and fh <= hi, message)

def ball(value):
    return arb(value.numerator) / value.denominator

def validate_model(dna):
    chain = dna["ggg_exact_top_chain"]
    epsilon, j = Fraction(chain["epsilon_eV"]), Fraction(chain["J_eV"])
    m = chain["matrix_eV"]
    require(isinstance(m, list) and len(m) == 3 and all(isinstance(row, list) and len(row) == 3 for row in m), "matrix must be exactly three by three")
    matrix = [[Fraction(str(x)) for x in row] for row in m]
    expected = [[epsilon, j, Fraction(0)], [j, epsilon, j], [Fraction(0), j, epsilon]]
    require(matrix == expected, "matrix is not declared uniform three-site chain")
    require(j != 0, "zero coupling is not the source model")
    tp = Fraction(chain["predicted_first_perfect_transfer_time_fs"])
    recurrence = Fraction(chain["predicted_recurrence_period_fs"])
    require(tp > 0 and recurrence == 2 * tp, "invalid first-PST/recurrence convention")
    return tp, abs(j)

def validate_c6(source):
    table = source["mode_table"]
    expected = (Fraction(0), Fraction(1, 2), Fraction(3, 2), Fraction(2), Fraction(3, 2), Fraction(1, 2))
    require(len(table) == 6 and [row["k"] for row in table] == list(range(6)), "missing, duplicate, or reordered C6 modes")
    for row, e in zip(table, expected):
        require(abs(Fraction(str(row["laplacian_eigenvalue"])) - e) <= Fraction(1, 10**14), "C6 value beyond source tolerance")

def half_angle_populations(u):
    # Independent half-angle evaluator, as opposed to source's full-angle cos.
    sine, cosine = u.sin(), u.cos()
    return (cosine**4, 2 * sine**2 * cosine**2, sine**4)

def check(dna, result):
    tp, j = validate_model(dna)
    tfs = Fraction(10**14)
    times = (Fraction(1, 10), Fraction(100), tfs)
    periods = (tp / 10**15, tp / 10**12, tp)
    seconds_per_unit = (Fraction(1), Fraction(1, 1000), Fraction(1, 10**15))
    require(result["source_sha256"] == DNA_HASH, "wrong source binding")
    require(result["model"] == "archived ideal uniform three-site QuantumDNA GGG chain", "wrong object")
    require(result["formula"] == "P_1to3(t)=sin^4(pi*t/(2*T_PST))" and result["input_policy"] == "take the printed source T_PST decimal literally as exact configured parameter", "wrong formula or input interpretation")
    require(result["authority_effect"] == "NONE", "authority was promoted")
    require(exact(result["first_PST_fs"]) == tp and exact(result["recurrence_fs"]) == 2 * tp, "wrong recorded period")
    rows = result["unit_rows"]
    si = result["energy_SI_parameter_comparison"]
    sirows = si["unit_rows"]
    require(len(rows) == 3 and [r["unit"] for r in rows] == list(UNITS), "wrong period-model unit rows")
    require(len(sirows) == 3 and [r["unit"] for r in sirows] == list(UNITS), "wrong SI-model unit rows")
    for row, sir, time, period, scale in zip(rows, sirows, times, periods, seconds_per_unit):
        require(exact(row["time"]) == time and exact(row["first_PST_in_same_unit"]) == period, "wrong unit input")
        require(exact(row["time_divided_by_first_PST"]) == tfs / tp, "time/period phase mismatch")
        require(exact(sir["time"]) == time and exact(sir["seconds_per_unit"]) == scale and time * scale == Fraction(1, 10), "SI phase unit mismatch")
        require(set(row["populations"]) == set(LABELS) and set(sir["populations"]) == set(LABELS), "missing population")
        for pop in list(row["populations"].values()) + list(sir["populations"].values()):
            lo, hi = interval(pop)
            require(0 <= lo <= hi <= 1, "invalid probability enclosure")
    cycles = (tfs / (2 * tp)).numerator // (tfs / (2 * tp)).denominator
    remainder = tfs - cycles * 2 * tp
    require(result["completed_probability_periods"] == cycles and exact(result["exact_time_remainder_fs"]) == remainder and 0 <= remainder < 2 * tp, "wrong exact cycle reduction")
    scope = result["scope"]
    for key in ("raw_sample_at_100ms_available", "full6_prediction_at_100ms_established", "physical_parameter_uncertainty_provided", "laboratory_measurement", "C6_physical_frequency_scale_provided", "RH_ordinate_to_seconds_map_provided"):
        require(scope[key] is False, "scope promotion: " + key)
    require(scope["ideal_model_extrapolation"] is True, "extrapolation omitted")
    require(scope["source_replay_time_range_fs"] == [0, 200] and scope["target_time_fs"] == 10**14 and scope["target_divided_by_source_max_time"] == 5 * 10**11, "time-domain scope changed")
    round_record = result["printed_period_rounding_diagnostic"]
    sensitivity = result["explicit_sensitivity_scenario"]
    require(round_record["assumption"] == "source period rounded to nearest 1e-15 fs; not source-guaranteed", "rounding assumption lost")
    require(sensitivity["assumption"] == "hypothetical relative period uncertainty +/-1e-12", "sensitivity assumption lost")
    half_ulp = Fraction(1, 2 * 10**15)
    lo, hi = tp - half_ulp, tp + half_ulp
    require(exact(round_record["period_interval_fs"]["lower"]) == lo and exact(round_record["period_interval_fs"]["upper"]) == hi, "wrong conditional input uncertainty")
    require(exact(sensitivity["possible_endpoint_probability"]["lower"]) == 0 and exact(sensitivity["possible_endpoint_probability"]["upper"]) == 1, "wrong probability range")
    h, e = Fraction("6.62607015e-34"), Fraction("1.602176634e-19")
    require(exact(si["h_exact_Js"]) == h and exact(si["electronvolt_exact_J"]) == e and exact(si["source_printed_J_eV"]) == -j, "wrong exact SI/model parameters")
    checks = 0
    evidence = []
    for precision in PRECISIONS:
        with ctx.workprec(precision):
            u_period = arb.pi() * ball(tfs / (2 * tp))
            hb = ball(h / e) / (2 * arb.pi())
            u_si = ball(j * Fraction(1, 10)) / (arb(2).sqrt() * hb)
            p_period, p_si = half_angle_populations(u_period), half_angle_populations(u_si)
            for row, sir in zip(rows, sirows):
                contains_saved(row["relative_eigenphase_radians"], 2 * u_period, "saved period eigenphase is wrong")
                contains_saved(sir["relative_eigenphase_radians"], 2 * u_si, "saved SI eigenphase is wrong")
                checks += 2
                for label, a, b in zip(LABELS, p_period, p_si):
                    contains_saved(row["populations"][label], a, "fresh period-model enclosure is not inside saved interval")
                    contains_saved(sir["populations"][label], b, "fresh SI-model enclosure is not inside saved interval")
                    checks += 2
            si_tp = arb.pi() * hb / (arb(2).sqrt() * ball(j)) * 10**15
            parameter_values = (
                (result["probability_period_count_at_100ms"], ball(tfs / (2 * tp))),
                (result["relative_eigenfrequency_radians_per_second"], arb.pi() / ball(tp / 10**15)),
                (si["hbar_SI_eVs"], hb),
                (si["hbar_inferred_from_printed_period_eVfs"], arb(2).sqrt() * ball(tp * j) / arb.pi()),
                (si["SI_first_PST_fs"], si_tp),
                (si["SI_first_PST_minus_source_first_PST_fs"], si_tp - ball(tp)),
                (si["SI_relative_eigenfrequency_radians_per_second"], 2 * u_si / ball(Fraction(1, 10))),
                (si["half_relative_eigenphase_difference_at_100ms_radians"], u_si - u_period),
            )
            for saved, fresh_value in parameter_values:
                contains_saved(saved, fresh_value, "saved parameter diagnostic misses fresh enclosure")
                checks += 1
            reduced = half_angle_populations(arb.pi() * ball(remainder / (2 * tp)))
            for a, b in zip(p_period, reduced):
                require(a.overlaps(b), "exact cycle reduction independent evaluation failed")
                checks += 1
            for p in (p_period, p_si):
                require((sum(p) - 1).contains(0), "independent population conservation failed")
                checks += 1
            pb = ball(lo).union(ball(hi))
            ub = arb.pi() * ball(tfs) / (2 * pb)
            slope = -2 * arb.pi() * ball(tfs) * ub.sin()**3 * ub.cos() / pb**2
            require(slope > 0 and round_record["positive_period_derivative_certified"] is True, "conditional monotonicity failed")
            require(interval(round_record["period_derivative_interval_per_fs"])[0] > 0, "saved derivative interval is not strictly positive")
            lower_pop = half_angle_populations(arb.pi() * ball(tfs / (2 * lo)))[2]
            upper_pop = half_angle_populations(arb.pi() * ball(tfs / (2 * hi)))[2]
            contains_saved(round_record["lower_period_endpoint_probability"], lower_pop, "conditional lower endpoint mismatch")
            contains_saved(round_record["upper_period_endpoint_probability"], upper_pop, "conditional upper endpoint mismatch")
            contains_saved(round_record["endpoint_probability_enclosure"], lower_pop, "conditional hull misses lower endpoint")
            contains_saved(round_record["endpoint_probability_enclosure"], upper_pop, "conditional hull misses upper endpoint")
            checks += 5
            r = Fraction(1, 10**12)
            width = arb.pi() * ball(tfs / 2 * (1 / (tp * (1 - r)) - 1 / (tp * (1 + r))))
            require(width > arb.pi(), "hypothetical sensitivity does not span sin-fourth period")
            contains_saved(sensitivity["sine_argument_interval_width_radians"], width, "sensitivity width enclosure wrong")
            checks += 2
            evidence.append({"precision_bits":precision, "P_period":str(p_period[2]), "P_SI":str(p_si[2]),
                             "conditional_derivative_positive":True, "hypothetical_width_exceeds_pi":True})
    return {"arb_checks":checks, "higher_precision_half_angle_evaluations":evidence,
            "exact_completed_cycles":cycles, "exact_remainder_fs":packed(remainder)}

def rejected(operation):
    try:
        operation()
    except (ValueError, KeyError, TypeError, ZeroDivisionError):
        return True
    return False

def main():
    source = SOURCE / "input/quantumdna_pst_enaqt_probe_v1.json"
    require(digest(source) == DNA_HASH, "unexpected source bytes")
    dna = load(source)
    result = load(SOURCE / "comparison_100ms.json")
    validate_c6(load(SOURCE / "input/same_operator_vortex_markov_heat_quantum_v1.json"))
    fresh = check(dna, result)
    negatives = {}
    m = deepcopy(dna); m["ggg_exact_top_chain"]["matrix_eV"].pop()
    negatives["missing_matrix_row"] = rejected(lambda: validate_model(m))
    m = deepcopy(dna); m["ggg_exact_top_chain"]["matrix_eV"][0][1] = "-0.062"
    negatives["changed_hopping"] = rejected(lambda: validate_model(m))
    m = deepcopy(dna); m["ggg_exact_top_chain"]["predicted_first_perfect_transfer_time_fs"] = "0"
    negatives["zero_period"] = rejected(lambda: validate_model(m))
    c6 = load(SOURCE / "input/same_operator_vortex_markov_heat_quantum_v1.json"); c6["mode_table"].pop()
    negatives["missing_C6_mode_original_zip_guard_gap"] = rejected(lambda: validate_c6(c6))
    m = deepcopy(result); m["unit_rows"].pop()
    negatives["missing_time_row"] = rejected(lambda: check(dna, m))
    m = deepcopy(result); m["unit_rows"].reverse()
    negatives["reordered_time_rows"] = rejected(lambda: check(dna, m))
    m = deepcopy(result); m["unit_rows"][0]["populations"]["P_1to3"]["lower"] = packed(Fraction(0)); m["unit_rows"][0]["populations"]["P_1to3"]["upper"] = packed(Fraction(1, 2))
    negatives["wrong_probability_interval"] = rejected(lambda: check(dna, m))
    m = deepcopy(result); m["scope"]["full6_prediction_at_100ms_established"] = True
    negatives["false_full6_authority"] = rejected(lambda: check(dna, m))
    m = deepcopy(result); m["printed_period_rounding_diagnostic"]["assumption"] = "guaranteed"
    negatives["promoted_period_uncertainty"] = rejected(lambda: check(dna, m))
    m = deepcopy(result); m["first_PST_fs"]["denominator"] = "0"
    negatives["zero_rational_denominator"] = rejected(lambda: check(dna, m))
    require(all(negatives.values()), "negative guard failed")
    receipt = {"status":"SCOPED_EXACT_INPUT_AND_ARB_RECEIPT_PASS", "source_sha256":DNA_HASH,
               "saved_comparison_sha256":digest(SOURCE / "comparison_100ms.json"),
               "checker_sha256":digest(Path(__file__)), "python_flint_version":flint.__version__,
               **fresh, "negative_guards":negatives, "source_guarantees_period_uncertainty":False,
               "ideal_three_site_model_only":True, "empirical_100ms_validation":False,
               "full6_prediction":False, "rh_proven":False,
               "trust_scope":"ordinary exact-rational Python guards and python-flint Arb; no Lean kernel claim"}
    output = Path(sys.argv[1]) if len(sys.argv) == 2 else ROOT / "CHECKER_RECEIPT.json"
    require(not output.exists(), "refusing to replace prior receipt")
    output.write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"status":receipt["status"], "arb_checks":fresh["arb_checks"], "negative_guards":len(negatives)}))

if __name__ == "__main__":
    main()
