"""Run byte-identical reviewed evaluator copies; never modify the input archive."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "Incoming/AEGIS_Quantum_100ms_Comparison_V1"
EXPECTED = {
    "compare.py": "dd06e5cb25a12916f97e2025fbbbcdb65bf35ca8ac055223e6c8428d2a446696",
    "compare_100ms.py": "767bb3cd0d378bafd207ee9eae30d52090cf0eef4bb6130bed306d3f8aa91140",
    "input/quantumdna_pst_enaqt_probe_v1.json": "24b7d6aef26173b6d78b3ae1586b5f3d73aa55a287908b92846bf60b35817b8d",
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    for rel, expected in EXPECTED.items():
        if digest(SOURCE / rel) != expected:
            raise ValueError("reviewed source changed: " + rel)
    jobs = []
    for name, flags in (("Normal", []), ("Optimized", ["-O"])):
        target = ROOT / "NumericReplay" / name
        if target.exists():
            raise ValueError("refusing to overwrite replay directory: " + str(target))
        target.mkdir(parents=True)
        for filename in ("compare.py", "compare_100ms.py"):
            shutil.copyfile(SOURCE / filename, target / filename)
        shutil.copytree(SOURCE / "input", target / "input")
        for evaluator in ("compare.py", "compare_100ms.py"):
            command = [sys.executable, *flags, str(target / evaluator)]
            result = subprocess.run(command, capture_output=True, text=True, timeout=90)
            (target / (evaluator + ".stdout.txt")).write_text(result.stdout)
            (target / (evaluator + ".stderr.txt")).write_text(result.stderr)
            jobs.append({"mode": name, "command": command, "exit_code": result.returncode,
                         "source_sha256": digest(target / evaluator)})
            if result.returncode:
                (ROOT / "EVALUATOR_REPLAY_RECEIPT.json").write_text(json.dumps({"status":"FAIL", "jobs": jobs},indent=2)+"\n")
                raise RuntimeError("reviewed evaluator failed")
    comparisons = []
    for output in ("comparison.json", "comparison_100ms.json"):
        original = SOURCE / output
        normal = ROOT / "NumericReplay/Normal" / output
        optimized = ROOT / "NumericReplay/Optimized" / output
        comparisons.append({"filename": output, "source_sha256": digest(original),
                            "normal_sha256": digest(normal), "optimized_sha256": digest(optimized),
                            "normal_optimized_byte_identical": normal.read_bytes() == optimized.read_bytes(),
                            "original_normal_byte_identical": original.read_bytes() == normal.read_bytes(),
                            "original_normal_json_equal": json.loads(original.read_text()) == json.loads(normal.read_text())})
        if normal.read_bytes() != optimized.read_bytes():
            raise ValueError("normal and optimized output disagree")
    for rel, expected in EXPECTED.items():
        if digest(SOURCE / rel) != expected:
            raise ValueError("original source mutated")
    receipt = {"status":"REVIEWED_EVALUATORS_REPLAY_PASS", "python":sys.version,
               "jobs":jobs, "output_comparisons":comparisons,
               "input_archive_modified":False, "numerical_scope":"configured ideal three-site model only",
               "independent_formula_replay":"separate checker pending", "rh_proven":False}
    (ROOT / "EVALUATOR_REPLAY_RECEIPT.json").write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
    print(json.dumps(receipt,indent=2,sort_keys=True))

if __name__ == "__main__":
    main()
