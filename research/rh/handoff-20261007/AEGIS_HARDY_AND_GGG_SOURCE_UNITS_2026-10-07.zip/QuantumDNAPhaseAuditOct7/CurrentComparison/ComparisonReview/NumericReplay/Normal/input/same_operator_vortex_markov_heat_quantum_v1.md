# Same operator: vortex -> Markov -> heat -> quantum

Start from the AEGIS six-cycle shift `P`:

`1 -> 2 -> 4 -> 8 -> 7 -> 5 -> 1`.

Abstracting only the cycle order gives `P^6=I`.

Define:

`M=(P+P^-1)/2`

`L=I-M`

`K_t=exp(-tL)`

`U_t=exp(-itL)`.

These are respectively symmetric Markov transport, a cycle Laplacian, heat diffusion and quantum/unitary propagation.

## Exact shared spectral basis

All are diagonalized by the same six Fourier characters `exp(2πikx/6)`.

| k | P phase | M | L |
|---:|---:|---:|---:|
| 0 | 0π | 1 | 0 |
| 1 | 0.333π | 0.5 | 0.5 |
| 2 | 0.667π | -0.5 | 1.5 |
| 3 | 1π | -1 | 2 |
| 4 | 1.33π | -0.5 | 1.5 |
| 5 | 1.67π | 0.5 | 0.5 |

`||P^6-I|| = 0.000e+00`
largest DFT off-diagonal residual across the five operators = 2.817e-15

## Meaning

The 'tower' is the common character/eigenmode index k.
The 'vortex' is deterministic phase rotation under P.
The Markov version replaces the phase by cos(theta_k).
Heat turns Laplacian eigenvalues into decays `exp(-t lambda_k)`.
Quantum evolution turns the same eigenvalues into phases `exp(-it lambda_k)`.

So in this finite model these are not merely analogous mechanisms: they are functional calculi of one underlying shift operator.
