# QGI phase-winding tower v1

Using the archived algebraic counterfactual:

`phi = (m g^2 T^3 / hbar) * r(r-2)/3`

## Exact structure

- Cubic time scaling: `phi(aT)=a^3 phi(T)`.
- Reflection symmetry: `f(2-r)=f(r)`.
- QGI/reply vs comment difference: `2r(r-1)/3`, hence exact degeneracy at `r=0` and `r=1`.

## Spectral/phase closure tower

Imposing `|phi|=2πn` gives:

`T_n = [2π n hbar/(m g^2 |f(r)|)]^(1/3)`.

So the closure times form a cube-root tower `T_n ∝ n^(1/3)`.

| r | n=1 T (ms) | n=2 | n=4 | n=8 |
|---:|---:|---:|---:|---:|
| 0.5 | 0.571853 | 0.720490 | 0.907761 | 1.143707 |
| 1.0 | 0.519563 | 0.654609 | 0.824755 | 1.039126 |
| 1.5 | 0.571853 | 0.720490 | 0.907761 | 1.143707 |
| 2.5 | 0.482320 | 0.607685 | 0.765635 | 0.964640 |

Boundary: this is an exact consequence of the archived counterfactual formula, not an empirical validation of quantum gravity.
