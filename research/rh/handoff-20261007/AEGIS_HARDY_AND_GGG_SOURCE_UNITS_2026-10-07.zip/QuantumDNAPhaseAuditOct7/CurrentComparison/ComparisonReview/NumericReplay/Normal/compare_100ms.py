"""Replay the archived ideal GGG model at one time in three exact units.

This is a mathematical extrapolation of a configured model. It is not a
measurement, a full-six-state replay, or a physically validated long-time result.
"""
from fractions import Fraction
import hashlib
import json
from pathlib import Path

from flint import arb, ctx

from compare import packed, record

ROOT = Path(__file__).resolve().parent


def ball(q):
    return arb(q.numerator) / q.denominator


def from_phase(phase):
    # Spectral evolution of H-epsilon*I for the uniform three-site chain:
    # eigenphases are 0 and +/-phase. Removing the common phase preserves P.
    c, s = phase.cos(), phase.sin()
    p_survival = ((1 + c) / 2) ** 2
    p_middle = s ** 2 / 2
    p_endpoint = ((c - 1) / 2) ** 2
    independent_endpoint = (phase / 2).sin() ** 4
    if not (p_endpoint - independent_endpoint).contains(0):
        raise ValueError("spectral and sine-fourth calculations disagree")
    if not (p_survival + p_middle + p_endpoint - 1).contains(0):
        raise ValueError("population conservation failed")
    return phase, (p_survival, p_middle, p_endpoint)


def evaluate(time, period):
    return from_phase(arb.pi() * ball(time / period))


def main():
    source = ROOT / "input/quantumdna_pst_enaqt_probe_v1.json"
    # Decimal strings are exact inputs; avoid a binary64 conversion in replay.
    dna = json.loads(source.read_text(), parse_float=str)
    chain = dna["ggg_exact_top_chain"]
    matrix = [[Fraction(str(x)) for x in row] for row in chain["matrix_eV"]]
    epsilon, signed_j = Fraction(chain["epsilon_eV"]), Fraction(chain["J_eV"])
    expected = [[epsilon, signed_j, Fraction(0)],
                [signed_j, epsilon, signed_j],
                [Fraction(0), signed_j, epsilon]]
    if matrix != expected:
        raise ValueError("source Hamiltonian differs from the ideal uniform chain")
    period_fs = Fraction(chain["predicted_first_perfect_transfer_time_fs"])
    source_recurrence_fs = Fraction(chain["predicted_recurrence_period_fs"])
    if source_recurrence_fs != 2 * period_fs:
        raise ValueError("source recurrence is not twice its first PST time")
    specifications = {
        "seconds": (Fraction(1, 10), period_fs / 10**15),
        "milliseconds": (Fraction(100), period_fs / 10**12),
        "femtoseconds": (Fraction(10**14), period_fs),
    }
    ratios = {unit: t / tp for unit, (t, tp) in specifications.items()}
    if len(set(ratios.values())) != 1:
        raise ValueError("exact time-to-period ratios differ across units")
    if specifications["milliseconds"][0] / 1000 != specifications["seconds"][0]:
        raise ValueError("millisecond conversion failed")
    if specifications["seconds"][0] * 10**15 != specifications["femtoseconds"][0]:
        raise ValueError("femtosecond conversion failed")
    ratio = ratios["seconds"]
    cycle_ratio = ratio / 2
    completed_cycles = cycle_ratio.numerator // cycle_ratio.denominator
    residual_fs = Fraction(10**14) - completed_cycles * 2 * period_fs
    if not 0 <= residual_fs < 2 * period_fs:
        raise ValueError("exact period reduction failed")
    rows = []
    with ctx.workprec(256):
        baseline = None
        for unit, (time, period) in specifications.items():
            phase, pops = evaluate(time, period)
            if baseline is None:
                baseline = pops
            if any(not (x - y).contains(0) for x, y in zip(pops, baseline)):
                raise ValueError("unit-change probability check failed")
            rows.append({"unit": unit, "time": packed(time),
                         "first_PST_in_same_unit": packed(period),
                         "time_divided_by_first_PST": packed(time / period),
                         "relative_eigenphase_radians": record(phase),
                         "populations": {label: record(value) for label, value in
                                         zip(("P_1to1", "P_1to2", "P_1to3"), pops)}})
        reference = baseline
        _, reduced_pops = evaluate(residual_fs, period_fs)
        if any(not (a-b).contains(0) for a, b in zip(reference, reduced_pops)):
            raise ValueError("direct phase and exact period reduction disagree")
        cycles = record(ball(ratio / 2))
        omega = record(arb.pi() / ball(specifications["seconds"][1]))
        # A diagnostic conditional on nearest rounding to the last printed
        # decimal place. The source has not supplied an uncertainty guarantee.
        half_last_place = Fraction(1, 2 * 10**15)
        lo, hi = period_fs - half_last_place, period_fs + half_last_place
        bounded_period = arb(chain["predicted_first_perfect_transfer_time_fs"], "5e-16")
        uncertain_phase = arb.pi() * arb(10**14) / (2 * bounded_period)
        derivative = (-2 * arb.pi() * arb(10**14) / bounded_period**2
                      * uncertain_phase.sin()**3 * uncertain_phase.cos())
        if not derivative > 0:
            raise ValueError("printed-period probability monotonicity not certified")
        lower_probability = evaluate(Fraction(10**14), lo)[1][2]
        upper_probability = evaluate(Fraction(10**14), hi)[1][2]
        rounding_probability = lower_probability.union(upper_probability)
        rounding = {
            "assumption": "source period rounded to nearest 1e-15 fs; not source-guaranteed",
            "period_interval_fs": {"lower": packed(lo), "upper": packed(hi)},
            "endpoint_probability_enclosure": record(rounding_probability),
            "positive_period_derivative_certified": True,
            "period_derivative_interval_per_fs": record(derivative),
            "lower_period_endpoint_probability": record(lower_probability),
            "upper_period_endpoint_probability": record(upper_probability),
        }
        # Explicit sensitivity scenario, not an inferred measurement error.
        rel_error = Fraction(1, 10**12)
        phase_interval_width = (arb.pi() * ball(Fraction(10**14)) / 2
                                * (1 / ball(period_fs * (1 - rel_error))
                                   - 1 / ball(period_fs * (1 + rel_error))))
        if not phase_interval_width > arb.pi():
            raise ValueError("sensitivity range does not span a probability period")
        sensitivity = {
            "assumption": "hypothetical relative period uncertainty +/-1e-12",
            "sine_argument_interval_width_radians": record(phase_interval_width),
            "possible_endpoint_probability": {"lower": packed(Fraction(0)),
                                              "upper": packed(Fraction(1))},
            "reason": "continuous phase interval spans more than one sin^4 period pi",
        }
        # SI h and elementary charge are exact defining constants, verified
        # against NIST's 2022 CODATA extensive listing on 2026-10-07.
        h_Js = Fraction("6.62607015e-34")
        electronvolt_J = Fraction("1.602176634e-19")
        hbar_eVs = ball(h_Js / electronvolt_J) / (2 * arb.pi())
        coupling_eV = abs(Fraction(chain["J_eV"]))
        omega_si = arb(2).sqrt() * ball(coupling_eV) / hbar_eVs
        first_PST_si_fs = arb.pi() / omega_si * 10**15
        si_rows = []
        si_baseline = None
        for unit, seconds_per_unit in (("seconds", Fraction(1)),
                                       ("milliseconds", Fraction(1, 1000)),
                                       ("femtoseconds", Fraction(1, 10**15))):
            time = specifications[unit][0]
            phase_si, si_pops = from_phase(omega_si * ball(seconds_per_unit) * ball(time))
            if si_baseline is None:
                si_baseline = si_pops
            if any(not (x-y).contains(0) for x, y in zip(si_baseline, si_pops)):
                raise ValueError("SI energy model differs across time units")
            si_rows.append({"unit": unit, "time": packed(time),
                            "seconds_per_unit": packed(seconds_per_unit),
                            "relative_eigenphase_radians": record(phase_si),
                            "populations": {label: record(value) for label, value in
                                            zip(("P_1to1", "P_1to2", "P_1to3"), si_pops)}})
        source_phase = evaluate(*specifications["seconds"])[0]
        si_phase = omega_si * ball(Fraction(1, 10))
        parameter_comparison = {
            "source_printed_J_eV": packed(-coupling_eV),
            "h_exact_Js": packed(h_Js), "electronvolt_exact_J": packed(electronvolt_J),
            "hbar_formula_eVs": "h_Js/(2*pi*electronvolt_J)",
            "hbar_SI_eVs": record(hbar_eVs),
            "hbar_inferred_from_printed_period_eVfs": record(
                arb(2).sqrt() * ball(period_fs * coupling_eV) / arb.pi()),
            "SI_first_PST_fs": record(first_PST_si_fs),
            "SI_first_PST_minus_source_first_PST_fs": record(first_PST_si_fs - ball(period_fs)),
            "SI_relative_eigenfrequency_radians_per_second": record(omega_si),
            "half_relative_eigenphase_difference_at_100ms_radians": record((si_phase-source_phase)/2),
            "source_constants_reference": {
                "title": "NIST 2022 CODATA Fundamental Physical Constants, extensive listing",
                "url": "https://physics.nist.gov/cuu/pdf/all.pdf", "page": 1,
                "checked_date": "2026-10-07",
            },
            "unit_rows": si_rows,
            "interpretation": "two parameter conventions, not two physical times; both preserve unit invariance",
        }
    with ctx.workprec(512):
        _, high_precision = evaluate(*specifications["seconds"])
        if any(not a.overlaps(b) for a, b in zip(reference, high_precision)):
            raise ValueError("256-bit and 512-bit probability intervals do not overlap")
        hb512 = ball(h_Js / electronvolt_J) / (2 * arb.pi())
        _, si512 = from_phase(arb(2).sqrt()*ball(coupling_eV)*ball(Fraction(1, 10))/hb512)
        if any(not a.overlaps(b) for a, b in zip(si_baseline, si512)):
            raise ValueError("SI 256-bit and 512-bit intervals do not overlap")
    result = {
        "schema": "aegis.quantum-time-unit-comparison.v1", "date": "2026-10-07",
        "status": "CONFIGURED_IDEAL_MODEL_COMPARISON_COMPLETE",
        "source_file": source.name,
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "model": "archived ideal uniform three-site QuantumDNA GGG chain",
        "formula": "P_1to3(t)=sin^4(pi*t/(2*T_PST))",
        "input_policy": "take the printed source T_PST decimal literally as exact configured parameter",
        "first_PST_fs": packed(period_fs), "recurrence_fs": packed(2 * period_fs),
        "relative_eigenfrequency_radians_per_second": omega,
        "probability_period_count_at_100ms": cycles,
        "completed_probability_periods": completed_cycles,
        "exact_time_remainder_fs": packed(residual_fs),
        "unit_rows": rows,
        "energy_SI_parameter_comparison": parameter_comparison,
        "checks": {
            "source_matrix_matches_uniform_chain": True,
            "time_conversion_exact": True, "time_to_period_ratios_exactly_equal": True,
            "spectral_formula_vs_sine_fourth_overlap": True,
            "population_conservation_contains_one": True,
            "256_bit_vs_512_bit_interval_overlap": True,
            "exact_modulo_period_vs_direct_phase_overlap": True,
            "SI_time_unit_probabilities_overlap": True,
            "SI_256_bit_vs_512_bit_interval_overlap": True,
        },
        "printed_period_rounding_diagnostic": rounding,
        "explicit_sensitivity_scenario": sensitivity,
        "scope": {
            "source_replay_time_range_fs": [0, 200],
            "target_time_fs": 10**14,
            "target_divided_by_source_max_time": 500000000000,
            "ideal_model_extrapolation": True,
            "raw_sample_at_100ms_available": False,
            "full6_prediction_at_100ms_established": False,
            "physical_parameter_uncertainty_provided": False,
            "laboratory_measurement": False,
            "C6_physical_frequency_scale_provided": False,
            "RH_ordinate_to_seconds_map_provided": False,
        },
        "C6_at_100ms_with_unspecified_scale": {
            "omega0_units": "radians per second",
            "formula": "P00(0.1s;omega0)=[cos(0.1*omega0)+2*cos(0.05*omega0)]^2/9",
            "equivalent_millisecond_formula": "[cos(100*(omega0/1000))+2*cos(50*(omega0/1000))]^2/9",
            "single_numerical_probability_established": False,
        },
        "authority_effect": "NONE",
    }
    destination = ROOT / "comparison_100ms.json"
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"],
                      "P13": rows[0]["populations"]["P_1to3"]["display"],
                      "P13_source_J_and_SI_hbar": si_rows[0]["populations"]["P_1to3"]["display"],
                      "all_unit_ratios_exactly_equal": True,
                      "model_extrapolation": True}))


if __name__ == "__main__":
    main()
