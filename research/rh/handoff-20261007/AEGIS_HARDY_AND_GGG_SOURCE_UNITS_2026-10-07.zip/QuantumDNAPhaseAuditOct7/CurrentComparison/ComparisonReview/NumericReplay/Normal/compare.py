"""Compare archived AEGIS quantum models with the prior Hardy point receipt.

New point evaluations are labelled as derived; no empirical data is generated.
"""
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import zipfile

from flint import arb, ctx

ROOT = Path(__file__).resolve().parent


def q(value):
    return Fraction(str(value))


def packed(value):
    return {"numerator": str(value.numerator), "denominator": str(value.denominator)}


def exact_endpoint(value):
    m, e = map(int, value.man_exp())
    return Fraction(m << e) if e >= 0 else Fraction(m, 1 << -e)


def record(value):
    return {"display": value.str(40), "lower": packed(exact_endpoint(value.lower())),
            "upper": packed(exact_endpoint(value.upper()))}


def main():
    c6 = json.loads((ROOT / "input/same_operator_vortex_markov_heat_quantum_v1.json").read_text())
    dna = json.loads((ROOT / "input/quantumdna_pst_enaqt_probe_v1.json").read_text())
    hardy = json.loads((ROOT / "input/receipt_t60.json").read_text())
    spectrum = [Fraction(0), Fraction(1, 2), Fraction(3, 2), Fraction(2), Fraction(3, 2), Fraction(1, 2)]
    actual = [r["laplacian_eigenvalue"] for r in c6["mode_table"]]
    if any(abs(q(a) - e) > Fraction(1, 10**14) for a, e in zip(actual, spectrum)):
        raise ValueError("archived spectrum differs from declared exact C6 spectrum")
    mean = sum(spectrum) / 6
    variance = sum(x*x for x in spectrum) / 6 - mean*mean
    coefficients = defaultdict(Fraction)
    for x in spectrum:
        for y in spectrum:
            coefficients[abs(x-y)] += Fraction(1, 36)
    if sum(coefficients.values()) != 1 or variance != Fraction(1, 2):
        raise ValueError("exact spectral consistency check failed")
    milliseconds = Fraction(100)
    seconds = milliseconds / 1000
    if seconds != Fraction(1, 10):
        raise ValueError("time unit conversion failed")
    outputs = []
    with ctx.workprec(256):
        for time in [60, 3600]:
            t = arb(time)
            centered = (t.cos() + 2*(t/2).cos()) / 3
            probability = centered*centered
            independent = arb(0)
            for gap, weight in coefficients.items():
                independent += (arb(weight.numerator)/weight.denominator) * (t*gap.numerator/gap.denominator).cos()
            if not (independent-probability).contains(0):
                raise ValueError("spectral autocorrelation identity replay failed")
            outputs.append({"t":time,"units":"dimensionless C6 evolution time",
                            "origin":"new evaluation of archived declared operator",
                            "centered_amplitude":record(centered),"return_probability":record(probability)})
        tp = dna["ggg_exact_top_chain"]["predicted_first_perfect_transfer_time_fs"]
        # The decimal parameter is taken literally from the saved model summary;
        # its physical/parameter uncertainty is not bounded by Arb rounding.
        transfer = (arb.pi()*60/(2*arb(str(tp)))).sin()**4
        quantum_dna = {"t":60,"units":"femtoseconds","first_PST_fs_from_source":tp,
                       "ideal_endpoint_transfer":record(transfer),
                       "origin":"new evaluation of archived ideal-chain formula; not raw full6 sample",
                       "input_parameter_uncertainty_propagated":False}
    result = {
        "schema":"aegis.hardy-quantum-comparison.v1","date":"2026-10-07",
        "user_time_unit_correction":{
            "milliseconds":packed(milliseconds),"seconds":packed(seconds),
            "minutes_60_in_seconds":packed(Fraction(60)*60),
            "phase_invariance":"omega_per_second * (100/1000) = (omega_per_second/1000) * 100",
            "quantum_evolution":"U(t)=exp(-i*H*t/hbar)",
            "physical_time_target_seconds":packed(seconds),
            "RH_ordinate_to_physical_seconds_mapping_established":False,
            "C6_energy_scale_to_seconds_mapping_established":False,
            "physical_evolution_at_100ms_compared":True,
            "100ms_model_receipt":"comparison_100ms.json",
            "100ms_empirical_validation_established":False},
        "hardy": {"t":60,"coordinate":"RH spectral ordinate", "hardy_Z":hardy["evaluation"]["hardy_Z"],
                  "origin":"previous 256-bit Arb point receipt"},
        "c6":{"spectrum":[packed(x) for x in spectrum],"mean":packed(mean),"variance":packed(variance),
              "centered_amplitude_formula":"(cos(t)+2*cos(t/2))/3",
              "return_probability_formula":"((cos(t)+2*cos(t/2))/3)^2",
              "recurrence_period":"4*pi in C6 evolution units",
              "short_time_survival":"1-t^2/2+O(t^4)",
              "autocorrelation_cosine_coefficients":[{"gap":packed(x),"weight":packed(coefficients[x])} for x in sorted(coefficients)],
              "evaluations":outputs,"source_mode_table_time_inferred":1.234},
        "quantumDNA":quantum_dna,
        "comparison":{"shared_algebra":"spectral phase sums; modulus-square produces difference-frequency autocorrelation",
                      "observable_identity_established":False,"operator_intertwiner_established":False,
                      "time_unit_identification_established":False,"physical_measurements_used":False},
        "inputs_sha256":{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/'input').iterdir()) if f.is_file()},
        "authority_effect":"NONE"}
    (ROOT/"comparison.json").write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({"status":"COMPARISON_COMPLETE","variance":packed(variance),"c6_t60":outputs[0]["return_probability"]["display"],
                      "c6_t3600":outputs[1]["return_probability"]["display"],"quantumDNA_ideal_60fs":quantum_dna["ideal_endpoint_transfer"]["display"]}))


if __name__ == "__main__":
    main()
