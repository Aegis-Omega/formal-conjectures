# Independent mathematical review of the 100 ms comparison

Date: 2026-10-07. Scope: the incoming ideal-chain comparison, exact time/phase conventions, and its two conditional sensitivity statements. No incoming code, catalog, simulator, numerical evaluator, compiler, or network operation was executed. Historical and incoming files were not modified. SHA256 utilities and source reads do not constitute numerical replay.

**Conclusion:** no mathematical defect was found in the scoped ideal-three-site formulas, unit conversions, distinction between parameter conventions, derivative formula, or conditional full-range uncertainty argument. The printed point probabilities and endpoint Arb intervals remain archived numerical results, not freshly replayed results of this review. The package does not establish a six-site 100 ms prediction or an RH conclusion.

## 1. What the source and checker identify

The incoming probe gives the upper-chain matrix

\[
 H_3=\epsilon I+J\begin{pmatrix}0&1&0\\1&0&1\\0&1&0\end{pmatrix},\qquad
 \epsilon=-8.000000000000002\ {m eV},\quad
 J=-0.06200000000000003\ {m eV}.
\]

`compare_100ms.py` uses `json.loads(..., parse_float=str)` and `Fraction` to interpret those printed decimals exactly. Its direct matrix equality checks that this supplied matrix has equal diagonal entries, equal adjacent couplings, and no end-to-end coupling. This establishes the supplied *ideal three-site input*, not reconstruction of the original six-site Hamiltonian or original binary NPZ entries. The probe's short-time six-site correlation, RMSE, peaks and infinite-time mean are source claims not independently reconstructed here.

For an initial end-site state, the spectrum of `H_3-epsilon*I` is `0, +/-sqrt(2)*J`. With `theta=sqrt(2)*J*t/hbar`, direct spectral decomposition gives

\[
 P_{1\to1}=\frac{(1+\cos\theta)^2}{4},\quad
 P_{1\to2}=\frac{\sin^2\theta}{2},\quad
 P_{1\to3}=\frac{(1-\cos\theta)^2}{4}
             =\sin^4(\theta/2).
\]

These three probabilities sum exactly to one. Changing the sign of J changes theta's sign but none of these probabilities. The common epsilon phase cancels. Nonzero interstrand couplings in a six-site model cannot be removed by this argument.

## 2. First-transfer time, recurrence and time units

For the energy-defined chain,

\[
 T_{\rm PST}=\frac{\pi\hbar}{\sqrt2|J|},\qquad
 P_{1\to3}(t)=\sin^4\left(\frac{\pi t}{2T_{\rm PST}}\right).
\]

The probability period is `2*T_PST`. It is not `T_PST`, and the angular eigenfrequency is `pi/T_PST`. The script and prose preserve these distinctions and check the printed recurrence equals twice the printed first-transfer time.

Exactly `100 ms = 1/10 s = 10^14 fs`. Dividing the first-transfer time by `10^15` for seconds or `10^12` for milliseconds preserves the exact ratio `t/T_PST`. The code's three rational ratios are therefore identical independently of any trigonometric evaluator.

The two numerical columns intentionally specify different parameter conventions:

1. The first takes the printed `T_PST=23.583537687334072 fs` as an exact frequency parameter. Given the printed J, it implicitly defines `hbar_T=sqrt(2)*|J|*T_PST/pi` in eV fs.
2. The second takes the printed J as exact and defines `hbar=h/(2*pi*eV_J)` from exact SI constants, computing phase `sqrt(2)*|J|*t_seconds/hbar_eV_seconds`.

They agree only if the inferred hbar equals the specified hbar. They are not two unit descriptions of an identical exact generator. The prose explicitly recognizes this. The archived values near 0.9958475 and 0.0908376 therefore do not contradict time-unit invariance. This review did not reevaluate either value.

For a C6 generator whose physical angular scale is an unspecified `Omega0` rad/s, the stated return probability

\[
 [\cos(0.1\Omega_0)+2\cos(0.05\Omega_0)]^2/9
\]

has the same form in milliseconds after replacing `Omega0` by `Omega0/1000`. Without that scale there is no unique numerical C6 probability at 100 ms. An RH ordinate of 60 supplies no physical time map.

## 3. Independent exact check of the rounding-interval monotonicity

Fix `t=10^14 fs`, `T0=23.583537687334072 fs`, and `delta=5*10^-16 fs`. These are assumptions about an ideal configured period; nearest rounding is not established as the source's physical uncertainty model.

With `x(T)=pi*t/(2T)`, differentiation gives

\[
 P'(T)=-\frac{2\pi t}{T^2}\sin^3 x(T)\cos x(T).
 \tag{1}
\]

The derivative implemented in the incoming script is precisely (1). Its positive sign throughout the quoted interval can also be established without using the archived Arb result. Set

\[
 a=2947942210916759,\quad
 N=6250000000000000000000000000,\quad
 M=2120122971493,\quad R=1516765247048813.
\]

Direct integer multiplication gives `N-M*a=R` and

\[
 51a=150345052756754709
 <100R=151676524704881300
 <52a=153292994967671468.
\]

Since `T0=a/(125000000000000)`, these identities prove

\[
 \frac{t}{2T_0}=M+R/a,\qquad 0.51<R/a<0.52.
\]

Both `T0` and every `T` in `[T0-delta,T0+delta]` exceed 23 fs. Consequently

\[
 \left|\frac{t}{2T}-\frac{t}{2T_0}\right|
 \le\frac{t\delta}{2TT_0}
 <\frac{1}{21160}<0.001.
\]

After subtracting `M*pi`, the sine argument belongs to `(0.509*pi,0.521*pi)`, which lies strictly between `pi/2` and `pi`. The product `sin^3(x)*cos(x)` is pi-periodic and negative on that interval. Thus (1) is strictly positive throughout the complete rounding interval.

The exact remainder is also established by the same integer identity:

\[
 t-2MT_0=R/(62500000000000)
          =24.268243952781008\ {m fs},
\]

which lies between zero and `2*T0`. This is a written exact-arithmetic argument, not a newly executed numerical replay.

The resulting probability range is exactly `[P(T0-delta),P(T0+delta)]`. Outward endpoint enclosures and their **convex hull** enclose the entire range. `arb.union` must mean the interval/ball hull for this use; a plain set union of disjoint endpoint intervals would be insufficient. The archived output is one enclosing ball, consistent with that intended interval operation. This review does not execute or independently verify the installed library implementation.

## 4. Why the hypothetical relative uncertainty really permits [0,1]

For `eta=10^-12`, varying the exact configured period continuously over `[T0*(1-eta),T0*(1+eta)]` yields a sine-argument interval of exact length

\[
 \Delta x=\frac{\pi t\eta}{T_0(1-\eta^2)}.
\]

Here `t*eta=100 fs`, while `T0*(1-eta^2)<T0<24 fs`; hence `Delta x>pi`. Since `sin^4(x)` has period pi, is continuous, and attains both zero and one during every full period, its image on that phase interval is exactly `[0,1]`.

This is an actual range result conditional on continuous period uncertainty of the stated size, not an inference of physical uncertainty from the input's decimal printing. The weaker nearest-printing interval in Section 3 does not imply `[0,1]`. The incoming prose keeps these assumptions separate.

## 5. Evidence and scope limits

The script's mathematical interval recipe is sound under the usual outward Arb operation semantics and hull operation described above. Its overlap checks at 256/512 bits, direct/reduced phase, spectral/sine formula, and three units are diagnostics; alone they do not prove an identity or connect the generator to the six-site source. The relevant identities have separate exact mathematical arguments in this review.

The included JSON reports the 256/512-bit checks. The prose reports an independent mpmath computation. Neither was freshly executed here, and the supplied mpmath claim is not treated as this reviewer's replay receipt. The checker hashes below identify the read sources, not certification of historical execution.

A separate mathematical reviewer, `/root/signed_arithmetic_bridge_oct7/filter_operator_adversary/exact_algebra_review`, independently confirmed (1), the conditional endpoint-hull reasoning and the analytic full-range argument, without execution or file edits. Numerical replay and original six-site provenance remain separate tasks. No mathematical implication to RH has been identified.

## Read-source identities

Paths are relative to `/workspace/aegis-research/evidence/quantum-100ms-comparison-oct7/Incoming/AEGIS_Quantum_100ms_Comparison_V1`.

| Source | SHA256 |
|---|---|
| `compare_100ms.py` | `767bb3cd0d378bafd207ee9eae30d52090cf0eef4bb6130bed306d3f8aa91140` |
| `compare.py` | `dd06e5cb25a12916f97e2025fbbbcdb65bf35ca8ac055223e6c8428d2a446696` |
| `input/quantumdna_pst_enaqt_probe_v1.json` | `24b7d6aef26173b6d78b3ae1586b5f3d73aa55a287908b92846bf60b35817b8d` |
| `POREDJENJE_100ms_BHS.md` | `b5a51956f0b53bc9536876dc3c8a5d64839d64f68adc9ff5cc76d5fb59e639ae` |
| `comparison_100ms.json` | `69d062acb15361eb799e905e3b51168c391d1948302beb361473836e493455c0` |
