# Konkretno poređenje kvantnog modela na 100 ms

Izračunato je isto vrijeme zapisano u tri jedinice:

\[
100\,\mathrm{ms}=0{,}1\,\mathrm{s}=10^{14}\,\mathrm{fs}.
\]

Za sačuvani idealni tročlani QuantumDNA GGG model:

\[
P_{1\to3}(t)=\sin^4\!\left(\frac{\pi t}{2T_{\rm PST}}\right)
=\sin^4\!\left(\frac{|J|t}{\sqrt2\hbar}\right).
\]

Sačuvani sažetak navodi J = −0.06200000000000003 eV i
T_PST = 23.583537687334072 fs. Obje formule predstavljaju isti idealni model
ako su parametri međusobno dosljedni. Sažetak ne navodi eksplicitno ħ.
Zbog veoma dugog vremena poređene su dvije precizno definisane konvencije.

| Zapis istog vremena | Doslovni sačuvani decimalni T_PST: P₁→₃ | Doslovni sačuvani decimalni J i tačni SI ħ: P₁→₃ |
|---|---:|---:|
| 0,1 s | 0,9958475177421528 | 0,0908375912952403 |
| 100 ms | 0,9958475177421528 | 0,0908375912952403 |
| 10¹⁴ fs | 0,9958475177421528 | 0,0908375912952403 |

**Pretvaranje jedinica čuva fazu i vjerovatnoću u oba računa.** Razlika između
kolona dolazi iz konvencije parametara, a ne iz vremenskih jedinica.

Prva kolona tretira sačuvani ispis perioda kao tačan konfiguracijski parametar.
Period vjerovatnoće je 47.167075374668144 fs. Do 100 ms protekne
2 120 122 971 493 cijelih perioda; tačan ostatak je 24.268243952781008 fs.
I direktni fazni račun i račun nakon tačnog reduciranja vremena modulo period
daju isti rezultat u intervalima zaokruživanja.

Druga kolona računa ħ = h/(2π E_eV) u eV·s, gdje je
h = 6.62607015 × 10⁻³⁴ J·s i E_eV = 1.602176634 × 10⁻¹⁹ J/eV.
Pretvorba 1 eV = 1.602176634 × 10⁻¹⁹ J slijedi iz tačne SI vrijednosti
elementarnog naboja e = 1.602176634 × 10⁻¹⁹ C.
Izvor konstanti: [NIST, 2022 CODATA, str. 1](https://physics.nist.gov/cuu/pdf/all.pdf),
provjeren 7. oktobra 2026.
Odatle ħ = 0.6582119569509065698073512… eV·fs i
T_PST = 23.5835376873307293950017672… fs za sačuvani J.
Sačuvani decimalni period implicira ħ = 0.658211956950999861… eV·fs;
to je izvedena vrijednost, a ne potvrđen izvorni parametar koda.
Mala razlika parametara akumulira se u približno 0,944 rad argumenta sinusa
na 100 ms. Nijedan rezultat u tabeli nije laboratorijsko mjerenje.

## Preciznost i provjera

Račun koristi tačne racionalne pretvorbe i Arb intervale na 256 bita,
sa ponovnom provjerom na 512 bita. Provjerene su tri vremenske jedinice,
spektralna i sin⁴ formula, zbir tri populacije jednak 1 i tačna redukcija modulo
sačuvani period. Nezavisni mpmath račun na 100 decimalnih mjesta potvrdio je
obje kolone. Ulazni decimalni parametri ne prolaze kroz binary64.

Ako se za period dodatno pretpostavi zaokruživanje na posljednju ispisanu
decimalu, T_PST ± 5 × 10⁻¹⁶ fs, rezultat prve kolone je približno u rasponu
[0,9958218, 0,9958732]. Izvor ne garantuje ovu nesigurnost; to je eksplicitna
provjera osjetljivosti. Već hipotetička relativna nesigurnost perioda ±10⁻¹²
obuhvata puni raspon vjerovatnoće [0,1] na 100 ms.

## Domet zaključka

Izvorna puna šestodimenzionalna simulacija poređena je s idealnim modelom
na 0–200 fs: korelacija 0.999527592043865, RMSE 0.01114227278921669.
100 ms je 5 × 10¹¹ puta dalje od kraja tog prozora. Tabela je ekstrapolacija
idealnog modela i ne potvrđuje punu simulaciju ili fizički sistem na 100 ms.

Za sačuvani C6 operator nema navedene frekvencijske skale u rad/s. Njegovo
tačno poređenje na 100 ms zato ostaje funkcija te skale:

\[
P_{00}(0{,}1\mathrm{s};\Omega_0)
=\frac{[\cos(0{,}1\Omega_0)+2\cos(0{,}05\Omega_0)]^2}{9}.
\]

U milisekundama ista formula koristi Ω_ms = Ω₀/1000 i t = 100.
RH spektralni parametar t=60 nema u izvoru mapu na fizičke sekunde.

`comparison_100ms.json` sadrži tačne ulaze, intervalne izlaze, obje konvencije
parametara, provjere i hash izvornog sažetka. Reprodukcija:

```bash
python3 -m pip install python-flint==0.9.0
python3 compare_100ms.py
```
