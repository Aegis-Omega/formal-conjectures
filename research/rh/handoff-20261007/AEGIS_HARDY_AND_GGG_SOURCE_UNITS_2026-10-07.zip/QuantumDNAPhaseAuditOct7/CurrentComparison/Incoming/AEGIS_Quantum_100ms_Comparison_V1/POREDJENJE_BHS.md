# Poređenje sa sačuvanim kvantnim podacima

## Operatorova korekcija: 100 ms = 0,1 s

Konkretna fizička vremenska koordinata je 100 ms, odnosno 0,1 s.
I 60 minuta = 3600 sekundi je pretvaranje jedinica, a ne kvadriranje vremena.
Treba očuvati bezdimenzijsku fazu:

\[
\phi=Et/\hbar=\omega t,\qquad
\omega_{\rm s}\cdot0.1=\omega_{\rm ms}\cdot100,
\quad \omega_{\rm ms}=\omega_{\rm s}/1000.
\]

Tako oba zapisa daju istu kvantnu evoluciju `U=exp(-iHt/hbar)`.
Tačna racionalna provjera 100/1000=1/10 ugrađena je u `compare.py`.
Ako posmatramo t², 10000 ms² = 0,01 s²: faktor vremena se mora transformisati
zajedno s koeficijentom njegove formule.

Broj t=60 u prethodnom Hardy računu je RH spectral ordinate. C6 t je modelska
evolucijska koordinata, sa neodređenom fizičkom energy/time skalom. Njihovo
povezivanje s 0,1 fizičkom sekundom još nema zadatu mapu.
Zato naredna tabela dokumentuje modele i spektralnu strukturu. Konkretni račun
idealnog QuantumDNA modela na 100 ms, u tri jedinice i dvije konvencije
parametara, nalazi se u `POREDJENJE_100ms_BHS.md` i `comparison_100ms.json`.
Taj novi račun je matematička ekstrapolacija sa izvornog prozora 0–200 fs.

Upoređeni su postojeći AEGIS C6 operator, QuantumDNA GGG numerički sažetak,
QER stvarni arhivirani replay korpus i prethodni Hardy certifikat.
Novi t=60 račun koristi objavljene modele, bez podešavanja parametara prema Hardy vrijednosti.

| Objekt / observable | Koordinata | Vrijednost |
|---|---|---:|
| Hardy Z, normirana realna vrijednost | RH spectral ordinate t=60 | 0.5869504907 |
| C6 amplituda nakon uklanjanja zajedničke faze | model time t=60 | −0.2146366935 |
| C6 vjerovatnoća povratka | model time t=60 | 0.0460689102 |
| C6 vjerovatnoća povratka | model time t=3600 | 0.1150115132 |
| QuantumDNA GGG idealni endpoint transfer | fizička modelska koordinata 60 fs | 0.3239029500 |

C6 i QuantumDNA redovi na t=60 su novi računi iz arhiviranih modela,
ne novi laboratorijski podaci. QuantumDNA red koristi navedeni idealni lanac;
ne predstavlja raw sample pune šestodimenzionalne simulacije.
Za QuantumDNA je doslovno preuzet sačuvani T_PST=23.583537687334072 fs.
Arb obuhvata grešku računanja za taj decimalni parametar, ne njegovu fizičku nesigurnost.
Jednak broj 60 ne identifikuje RH ordinate, C6 model time i femtosekunde.

## Tačna veza koju poređenje izdvaja

Sačuvani C6 Laplacian ima spektar

\[
\lambda=(0,1/2,3/2,2,3/2,1/2).
\]

Za lokalizirano početno stanje, svaki Fourier mode ima težinu 1/6:

\[
a(t)=\frac16\sum_k e^{-it\lambda_k}
=e^{-it}\frac{\cos t+2\cos(t/2)}3.
\]

Spektar je simetričan oko sredine 1. Uklanjanje zajedničke faze e^(−it)
ostavlja realnu cosine sumu. To je konkretna usporedba sa prethodnim
Hardy korakom: prvo izdvojiti normalizaciju/fazu, zatim analizirati realni objekt.
U Hardy slučaju pozitivni Gamma modul prenosi znak; u C6 slučaju uklanjamo
unitarnu zajedničku fazu. To nisu isti multiplikatori.

Kvantna vjerovatnoća nastaje kvadriranjem modula:

\[
P(t)=|a(t)|^2
=\sum_{j,k}w_jw_k\cos(t(\lambda_j-\lambda_k)).
\]

Za ovaj postojeći spektar to daje tačno

\[
P(t)=\frac5{18}
+\frac29[\cos(t/2)+\cos t+\cos(3t/2)]
+\frac1{18}\cos(2t).
\]

Frekvencije su razlike eigenvalues: to je Fourier/autocorrelation mehanizam
koji se javlja i kad se u Weil/Parseval računu pojavljuje |g_hat|².
Ovdje smo ga egzaktno izveli za C6 i nezavisno provjerili njegove dvije
reprezentacije u Arb-u na t=60 i t=3600.
To identificira zajedničku algebru. Ne identificira njihove spektralne mjere
niti daje operator map između C6 i RH.

## Zašto se pojavljuje t²

Egzaktna sredina C6 energije je 1, drugi moment 3/2 i varijansa 1/2.
Zato kratkovremenski razvoj vjerovatnoće povratka počinje kao

\[
P(t)=1-\operatorname{Var}(L)t^2+O(t^4)
=1-\frac{t^2}{2}+O(t^4).
\]

Ovo je konkretan kvantni izvor kvadrata vremena. Razvoj je lokalni oko nule;
na 60 koristimo punu cosine formulu. Tačan period povratka ovog C6 modela je
4π, a P(60) i P(3600) su različiti.

U QuantumDNA idealnom GGG lancu endpoint transfer ima drugi početni red:

\[
P_{1\to3}(t)=\sin^4\left(\frac{\pi t}{2T_{\rm PST}}\right)=O(t^4).
\]

Prema tome početna potencija vremena zavisi i od observablea: survival i
endpoint transfer ne moraju imati isti prvi nenulti član.

Najvažniji znak u samom poređenju: C6 realna normirana amplituda na 60 je
negativna, dok je njena vjerovatnoća pozitivna. Pozitivan modulus-square
ne dokazuje pozitivan znak realne amplitude.

## Šta potvrđuju postojeći podaci

QuantumDNA sažetak već prijavljuje korelaciju pune GGG simulacije sa idealnom
krivuljom 0.9995275920, RMSE 0.0111422728 i prvi peak na 23.5 fs sa
P=0.9989975722. To opravdava poređenje s navedenom idealnom formulom,
uz prijavljenu razliku idealnog i punog modela.

QER V3.1 poređenje stvarnih arhiviranih finite-bath CSV replaya ima 240 starih
i 240 novih redova, 0 numeričkih i 0 kategorijskih mismatcheva u deklarisanom
comparatoru, max apsolutnu numeričku razliku 2.2737367544·10⁻¹³ i 23
winner-label drifta koji su posebno prihvaćeni kao numeričke nule.
To je još jedan konkretan razlog za intervale/zero guard pri interpretaciji znaka.
Finite-bath arhiva ima vremena 0, 0.5, 1, 2, 4; u njoj nema t=60 samplea.

## Izvori i reproduciranje

- same_operator_vortex_markov_heat_quantum_v1.json, sačuvan 2026-10-04.
- quantumdna_pst_enaqt_probe_v1.json, sačuvan 2026-10-04.
- AEGIS_QUANTUM_FRONTIER_QER_V3_1_REAL_CORPUS_REGRESSION.zip,
  evidence/actual-replay-comparison-v1.json.
- AEGIS_QUANTUM_FRESH_REPLAY_EVIDENCE_V1.zip, finite_bath_exact/scan.csv.
- AEGIS_Hardy_Q16_T60_V1/receipt_t60.json, prethodni Arb certifikat.

`comparison.json` ima tačne dyadic Arb granice, racionalne spectral/cosine
koeficijente, jedinice i hash ulaznih datoteka.
`source_refs.json` veže ulaze za njihove sačuvane identitete.

```bash
python3 -m pip install python-flint==0.9.0
python3 compare.py
```

Najmanji naredni dokazni korak je prenijeti ovu tačnu difference-frequency
autocorrelation strukturu na konkretni g/h par iz #693, kroz njegov otvoreni
Parseval/Fubini identitet. Na ovom poređenju nije potvrđena jednakost C6 i RH operatora.
AUTHORITY_EFFECT = NONE.
