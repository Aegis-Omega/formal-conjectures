"""Freeze historical and newly recovered QuantumDNA inputs without rewriting them."""
from pathlib import Path
import hashlib
import json
import shutil

BASE = Path(__file__).resolve().parent
OLD = BASE.parent / 'quantumdna-ggg-100ms-oct7'
WORK = BASE.parent.parent / 'work'
TARGET = WORK / 'QuantumDNAPhaseAuditOct7'

def demand(c, m):
    if not c:
        raise ValueError(m)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load(p):
    return json.loads(p.read_text())

def copy(p, relative):
    q = TARGET / relative
    demand(not q.exists() and not p.is_symlink(), 'duplicate or symlink source')
    q.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, q)
    demand(q.read_bytes() == p.read_bytes() and
           q.stat().st_mode & 0o777 == p.stat().st_mode & 0o777,
           'source copy changed bytes or mode')

demand(not TARGET.exists(), 'refusing frozen-unit overwrite')
demand(sha(WORK / 'CHECKPOINT.md') ==
       '3a333ea557a91bdc8f9724dc18e3d14b4d6561942a246f678b88e4467b2403ff',
       'original checkpoint changed')
demand(sha(WORK / 'aegis_compute.py') ==
       '08f2e0a21242a6762dd18989b83666ca12f1ddf802a88e12291c23f971618b17',
       'original driver changed')
old_manifest = load(OLD / 'SOURCE_MANIFEST.json')
demand(sha(OLD / 'SOURCE_MANIFEST.json') ==
       'ad4cf85a536621d1d5baa12ebdb1153b15dd796eaf29cdc2f779815e17d3be9d',
       'historical frozen manifest changed')
old_paths = {r['path'] for r in old_manifest['files']}
actual_old = {str(p.relative_to(OLD)) for p in OLD.rglob('*') if p.is_file()}
demand(actual_old == old_paths | {'SOURCE_MANIFEST.json'}, 'historical member scope changed')
for r in old_manifest['files']:
    p = OLD / r['path']
    demand(p.stat().st_size == r['bytes'] and sha(p) == r['sha256'],
           'historical source changed: ' + r['path'])
archive = load(BASE / 'ARCHIVE_SOURCE_MANIFEST.json')
zip_path = Path(archive['zip_path'])
demand(sha(zip_path) == archive['zip_sha256'], 'new uploaded ZIP changed')
for r in archive['bindings']:
    p = BASE / 'Incoming' / r['path']
    demand(p.stat().st_size == r['bytes'] and sha(p) == r['sha256'], 'new raw member changed')
review = load(BASE / 'ComparisonReview/RESULT.json')
demand(review['rh_proven'] is False, 'quantum point packet cannot close RH')
demand(review['status'] == 'SCOPED_REPLAY_AND_EXACT_INPUT_INTERVAL_CHECKS_PASS',
       'independent comparison review failed')
demand(sha(BASE / 'ComparisonReview/RESULT.json') ==
       '9612368d618c0dddc42bdc28664609a4ae46d253568a7e86463d335b41ab90ee',
       'independent frozen receipt changed')
demand(sha(BASE / 'ComparisonReview/SOURCE_MANIFEST.json') ==
       '87d7ae17c55ee72f248a4a35afa7c604d3fdf0dab4daa27d6da55ce83535e8ce',
       'independent frozen manifest changed')
review_manifest = load(BASE / 'ComparisonReview/SOURCE_MANIFEST.json')
for row in review_manifest['files']:
    p = BASE / 'ComparisonReview' / row['path']
    demand(p.stat().st_size == row['bytes'] and sha(p) == row['sha256'],
           'frozen independent source changed: ' + row['path'])
for row in review_manifest['external_read_source_bindings']:
    p = Path(row['path'])
    demand(p.stat().st_size == row['bytes'] and sha(p) == row['sha256'],
           'independent external read source changed: ' + row['path'])
for name in ('ROOT_PERIOD_REVIEW_PORTABLE_RECEIPT.json',
             'ROOT_PERIOD_REVIEW_PORTABLE_OPTIMIZED_RECEIPT.json'):
    r = load(BASE / name)
    demand(r['status'] == 'PASS_CONFIGURED_THREE_SITE_MODEL' and r['rh_proven'] is False,
           'root period review failed')
    demand(sha(BASE / 'ROOT_PERIOD_REVIEW_PORTABLE.py') == r['source_sha256'],
           'root portable checker changed')
TARGET.mkdir()
copy(zip_path, Path('PACKET.zip'))
for p in sorted(OLD.rglob('*')):
    if p.is_file():
        copy(p, Path('HistoricalAuditBeforeAttachment') / p.relative_to(OLD))
for p in sorted(BASE.rglob('*')):
    if not p.is_file() or '__pycache__' in p.relative_to(BASE).parts:
        continue
    copy(p, Path('CurrentComparison') / p.relative_to(BASE))
readme = '''# QuantumDNA exact 100 ms phase audit

The actual uploaded packet and its reviewed replay are preserved in
CurrentComparison. HistoricalAuditBeforeAttachment preserves the earlier
scoped source recovery unchanged, including its then-missing period status.
The newly recovered period closes that source-access issue. It does not
recover the original six-site NPZ or prove an RH implication.

For the configured ideal three-site chain, the displayed-period convention
gives 0.9958475177421528; the displayed-J/exact-SI convention gives
0.0908375912952403. Exact conversions give identical phases for 100 ms,
1/10 s, and 10^14 fs within each parameter convention. All figures are
ideal-model extrapolations. Read MATHEMATICAL_AND_SOURCE_REVIEW.md for the
complete mathematical argument and explicit uncertainty assumptions.

The unchanged submitted evaluators were run in separate fresh copies both
normally and under python -O. The two saved output JSONs are reproduced byte
for byte. A separate exact-input checker and another cosine/modulo evaluator
provide scoped independent assembly checks using the same host/Arb library.
No new Lean proof or independent transcendental kernel is claimed.

To reproduce the portable root check with existing python-flint 0.9.0,
create a fresh directory and copy only ROOT_PERIOD_REVIEW_PORTABLE.py,
Incoming, and LibrarySource from CurrentComparison into it. Run
`python3 ROOT_PERIOD_REVIEW_PORTABLE.py` and
`python3 -O ROOT_PERIOD_REVIEW_PORTABLE.py` there. Existing receipt paths
are intentionally refused. No package installation is needed in the
current inspected workspace.

PACKET.zip is the exact original uploaded ZIP. GitBlobReview records actual
retrieval of the known source-audit Git blob, which contains JSON. The new
packet's source_refs identifiers are library IDs. The bounded Git search
does not claim absence of a ZIP from all project history.

The one selected unresolved global mathematical obligation remains
AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign, with the same fixed
detecting packet, all signed-integer log2/log3 shifts, all four phases,
and the full actual Weil RHS. rh_proven=false. No new edge into the RH
equivalence component is obtained from this finite-chain packet.
'''
(TARGET / 'README.md').write_text(readme)
result = {'schema': 'AEGIS_QUANTUMDNA_RECOVERED_PERIOD_SOURCE_BOUND_AUDIT_V1',
          'status': 'PASS_SCOPED_CONFIGURED_MODEL_AND_SOURCE_RECOVERY',
          'uploaded_zip_sha256': archive['zip_sha256'],
          'new_packet_ideal_three_site_object_identified': True,
          'user_period_row_0_99584752_verified_for_exact_printed_period': True,
          'user_energy_SI_row_0_09083759_verified_for_exact_printed_coupling': True,
          'all_three_time_units_exactly_equal': True,
          'same_exact_generator_for_both_parameter_conventions': False,
          'source_uncertainty_guarantee_recovered': False,
          'six_site_saved_NPZ_recovered': False,
          'full_six_site_100ms_prediction_verified': False,
          'physical_measurement': False,
          'current_NIST_cited_PDF_primary_verified': True,
          'historical_negative_access_scope_preserved': True,
          'current_library_original_source_verified': True,
          'library_packet_raw_difference': 'packet adds exactly one final newline',
          'library_original_input_sha256':
              '547b11bf041572bb0cfb2d4d58272abf84f46369551762e67b6bb42f98d42c94',
          'source_audit_git_blob': '00c415940df653c5787d3cdaec6176f2d70c465a',
          'source_audit_recovery_commit': 'd766cbf99f0bb1e91300c94bae64c469a5d7d89d',
          'independent_review_receipt_sha256': sha(BASE / 'ComparisonReview/RESULT.json'),
          'root_portable_review_receipt_sha256': sha(BASE / 'ROOT_PERIOD_REVIEW_PORTABLE_RECEIPT.json'),
          'root_portable_source_sha256': sha(BASE / 'ROOT_PERIOD_REVIEW_PORTABLE.py'),
          'new_Lean_replay': 'NOT_RUN', 'new_RH_causal_edge': False,
          'global_Weil_sign_discharged': False, 'rh_proven': False,
          'unresolved_global_obligation': 'AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign',
          'hosted_checks_changed': False, 'remote_written': False}
(TARGET / 'RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2)+'\n')
bindings = []
for p in sorted(TARGET.rglob('*')):
    if p.is_file():
        bindings.append({'path': str(p.relative_to(TARGET)), 'bytes': p.stat().st_size,
                         'sha256': sha(p), 'mode': oct(p.stat().st_mode & 0o777)})
manifest = {'schema': 'AEGIS_QUANTUMDNA_FROZEN_SOURCE_UNIT_V1',
            'self_excluded': 'SOURCE_MANIFEST.json', 'bindings': bindings,
            'historical_unit_copied_exactly_including_its_bound_cache': True,
            'new_python_caches_excluded': True, 'rh_proven': False}
(TARGET / 'SOURCE_MANIFEST.json').write_text(json.dumps(manifest, sort_keys=True, indent=2)+'\n')
print(json.dumps({'target': str(TARGET), 'file_count': len(bindings)+1,
                  'manifest_sha256': sha(TARGET/'SOURCE_MANIFEST.json'),
                  'result_sha256': sha(TARGET/'RESULT.json'), 'rh_proven': False}, indent=2))
