# Independent second execution and semantic review

Scope: the existing zero-centre analytic coefficient and the new compatibility
adapter. This review does not inspect or certify the unidentified v33 ZIP,
its rational verifier, its 349-entry manifest, or its analytic target. It does
not produce an unconditional global Weil sign or a proof of RH.

## Actual execution

I executed the unchanged `replay_compatibility.py` once. It created the fresh
directory `scoped-replay-20261007T052918.634006Z`. The pinned Lean 4.33.1
compiler, commit `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, compiled the adapter
with explicit `--trust=0`; the separate pinned `leanchecker -v` then replayed
that module. Both commands exited zero. Their raw stdout and stderr are
preserved at the actual executed paths, alongside the raw second receipt.

Raw second receipt SHA256:
`728f5b3e713e950bfde6df034cb733e39458961a88cb0ea47e691d4e3c23ae20`.

I inspected all four printed endpoint types and their actual axiom reports.
Every endpoint depends only on `propext`, `Classical.choice`, and `Quot.sound`.
The adapter source and emitted OLEAN match the first execution byte for byte.
The object SHA256 is
`b105cb174093797ae824057d88e342f28fecbbc6c43919521f482cab18b5eb55`.
No `sorryAx` or new mathematical axiom appears in these endpoint reports.

The execution uses identified imported objects from the existing coherent
first-cell context. It does not rebuild the full transitive source closure,
and it is an independent agent execution on the same host and engine rather
than an independent implementation. The bound Mathlib pin is
`0df444a360eaa60ab8c11dca51a86af692955474`.

## Mathematical target and proof reuse

The recovered source defines `firstCenter = 0`. Its `exactJetCoefficient c k`
is `1/k!` times the ordinary `k`th derivative of the actual correction symbol
at `c`. The existing premise-free `firstJet_one_exact` proves equality to
`firstJet 1`, which that source defines as zero. The analytic argument is
sound: an even differentiable real function has derivative zero at zero;
the source supplies actual correction-symbol evenness and C8 regularity.
The adapter's `simpa [firstJet]` preserves this object and normalization.

The reported rational interval has midpoint
`347860160497148/10^15` and half-width `1/10^15`, strictly below `1/10^12`.
These arithmetic facts are correct. The interval lies strictly above zero.
Consequently it cannot enclose this recovered zero-centre coefficient, and
its midpoint is farther than `1/10^12` from that coefficient. Both exact
statements appear in the freshly compiled Lean endpoints; no floating-point
decision is used.

This is an object-compatibility rejection, not a falsification of v33. The
user's text does not supply the formula, centre, correction-data identity,
or normalization. An older recovered version under the same namespace has
`firstCenter = 75/8192` and a different k=1 decimal approximation under an
explicit enclosure premise. The source-bound snapshots distinguish these
versions; no claim equating either one to the unidentified v33 object is
permitted.

## Provenance and comparison

`audit_second_replay.py` checks the actual logs and exit codes, four axiom
lists, all declared input hashes, shared inputs between the two runs, fresh
source/object equality, the historical analytic source snapshot against its
bound origin and receipt, three provided source snapshots, and the exact
rational interval arithmetic. Its JSON receipt records the source bindings
and scopes. The parent report was read at its current final bytes and bound
in that receipt.

The raw execution receipt correctly retains `v33_available: false`,
`v33_kernel_audit: "NOT_RUN"`, and `rh_proven: false`. The independent review
preserves those limits. No old result, shared Lean source, branch, or remote
repository was modified by this review. The existing zero-centre theorem
remains verified and is reused; the requested v33 Taylor/Lagrange port still
requires its exact target and certificate snapshot.
