#!/usr/bin/env python3
"""Read-only comparison of two actual scoped replays; not a v33 or RH audit."""
import hashlib
import json
import subprocess
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
FIRST = BASE / 'scoped-replay-20261007T052807.216296Z'
SECOND = BASE / 'scoped-replay-20261007T052918.634006Z'
PRIOR = Path('/workspace/aegis-research/work/GoalContinuation20261001/AnalyticReplay/actual-context-20261003T004616.608552Z')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

bindings = {}
checks = []
def bind(path):
    path = Path(path)
    bindings[str(path)] = sha(path)
    return path
def check(name, condition, **details):
    checks.append({'name': name, 'pass': bool(condition), **details})

receipts = []
for directory in [FIRST, SECOND]:
    receipt = json.loads(bind(directory / 'RECEIPT.json').read_text())
    receipts.append(receipt)
    check('actual_pass_receipt_' + directory.name, receipt['status'] == 'PASS')
    check('inputs_unchanged_' + directory.name,
          all(Path(p).is_file() and sha(p) == h for p, h in receipt['input_bindings'].items()),
          count=len(receipt['input_bindings']))
    for p, h in receipt['input_bindings'].items():
        bindings[p] = h
    for job in receipt['jobs']:
        check(directory.name + '_' + job['name'] + '_exit_zero', job['exit_code'] == 0)
        for stream in ['stdout', 'stderr']:
            path = bind(directory / (job['name'] + '.' + stream + '.txt'))
            check(directory.name + '_' + job['name'] + '_' + stream + '_bound',
                  sha(path) == job[stream + '_sha256'])
    compile_job = next(j for j in receipt['jobs'] if j['name'] == 'compile')
    checker_job = next(j for j in receipt['jobs'] if j['name'] == 'leanchecker')
    check('literal_trust_zero_' + directory.name, '--trust=0' in compile_job['command'])
    check('pinned_checker_' + directory.name,
          checker_job['command'][0] == '/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin/leanchecker')
    check('four_endpoint_axioms_' + directory.name,
          len(receipt['axiom_reports']) == 4 and
          all(set(a['axioms']) == {'propext', 'Classical.choice', 'Quot.sound'}
              for a in receipt['axiom_reports']))
    bind(directory / 'lib' / 'K1TargetCompatibilityOct7.olean')

first, second = receipts
common = set(first['input_bindings']) & set(second['input_bindings'])
check('common_input_hashes_identical',
      all(first['input_bindings'][p] == second['input_bindings'][p] for p in common),
      count=len(common))
check('fresh_source_bytes_identical',
      (FIRST / 'source' / 'K1TargetCompatibilityOct7.lean').read_bytes() ==
      (SECOND / 'source' / 'K1TargetCompatibilityOct7.lean').read_bytes())
check('fresh_object_hashes_identical',
      first['fresh_object_sha256'] == second['fresh_object_sha256'],
      sha256=second['fresh_object_sha256'])
check('compile_stdout_bytes_identical',
      (FIRST / 'compile.stdout.txt').read_bytes() == (SECOND / 'compile.stdout.txt').read_bytes())
check('checker_stdout_bytes_identical',
      (FIRST / 'leanchecker.stdout.txt').read_bytes() == (SECOND / 'leanchecker.stdout.txt').read_bytes())
check('same_endpoint_reports', first['axiom_reports'] == second['axiom_reports'])
check('scope_guards_fail_closed',
      second['v33_available'] is False and second['v33_kernel_audit'] == 'NOT_RUN'
      and second['rh_proven'] is False)

# Match the read analytic proof source to the already bound historical receipt.
prior = json.loads(bind(PRIOR / 'receipt.json').read_text())
record = next(r for r in prior['records'] if r.get('module_name') == 'RHKreinFirstCellV1')
source = bind(PRIOR / 'sources' / 'RHKreinFirstCellV1.lean')
origin = bind(record['source_origin'])
check('historical_origin_source_matches_record', sha(origin) == record['source_sha256'])
check('historical_effective_snapshot_matches_record',
      sha(source) == record['source_snapshot_sha256'])
check('historical_imported_object_matches_record',
      sha(PRIOR / 'lib' / 'RHKreinFirstCellV1.olean') == record['olean_sha256'])
check('historical_snapshot_is_origin_plus_reported_probes',
      source.read_bytes() == origin.read_bytes() + record['appended_probes'].encode())

bind(BASE / 'K1_V33_SOURCE_AND_TARGET_AUDIT.md')
snapshots = json.loads(bind(BASE / 'ExistingSourceSnapshots' / 'SOURCE_BINDINGS.json').read_text())
for item in snapshots['entries']:
    original = bind(item['original_path'])
    snapshot = bind(item['snapshot'])
    check('existing_snapshot_bound_' + snapshot.name,
          sha(original) == sha(snapshot) == item['sha256'])
frozen = json.loads(bind(BASE / 'ExistingSourceSnapshots' / 'FROZEN_GIT_BINDINGS.json').read_text())
for item in frozen['sources']:
    repo = '/workspace/aegis-research/work'
    target = item['frozen_commit'] + ':' + item['path']
    raw = subprocess.run(['git', '-C', repo, 'show', target], capture_output=True, check=False)
    blob = subprocess.run(['git', '-C', repo, 'rev-parse', target], capture_output=True, check=False)
    check('actual_frozen_git_source_' + item['path'],
          raw.returncode == 0 and
          hashlib.sha256(raw.stdout).hexdigest() == item['actual_sha256'],
          command=['git', '-C', repo, 'show', target])
    check('actual_frozen_git_blob_' + item['path'],
          blob.returncode == 0 and blob.stdout.decode().strip() == item['git_ls_tree'].split()[2],
          command=['git', '-C', repo, 'rev-parse', target])

lo = Fraction(347860160497147, 10**15)
mid = Fraction(347860160497148, 10**15)
hi = Fraction(347860160497149, 10**15)
radius = Fraction(1, 10**12)
check('reported_interval_positive', 0 < lo < mid < hi)
check('reported_interval_radius_is_10_minus_15', hi - mid == mid - lo == Fraction(1, 10**15))
check('reported_interval_within_requested_radius', hi - mid < radius)
check('zero_outside_reported_interval', not (lo < 0 < hi))
check('zero_midpoint_distance_exceeds_requested_radius', abs(mid) > radius)

bindings[str(Path(__file__).resolve())] = sha(__file__)
bind(HERE / 'INDEPENDENT_SEMANTIC_REVIEW.md')
receipt = {
    'schema': 'aegis.k1-existing-target-compatibility.independent-second-review.v1',
    'status': 'PASS' if all(c['pass'] for c in checks) else 'FAIL',
    'first_actual_replay_receipt': str(FIRST / 'RECEIPT.json'),
    'second_actual_replay_receipt': str(SECOND / 'RECEIPT.json'),
    'actual_second_execution': True,
    'four_endpoint_types_semantically_reviewed': True,
    'input_bindings': bindings,
    'checks': checks,
    'v33_identified': False,
    'v33_kernel_audit': 'NOT_RUN',
    'rh_proven': False,
    'independent_rh_replay': False,
    'clean_transitive_source_build': False,
    'scope': 'Independent agent actually executed the unchanged adapter once in a unique fresh directory. Source and emitted object hashes match the first execution. Existing real analytic zero-centre k=1 proof is reused. The user-reported unidentified v33 formula and its 349-file/ZIP replay are not audited or identified with this coefficient. Imported objects are reused and identified; the full transitive source closure was not rebuilt.',
}
out = HERE / 'INDEPENDENT_SECOND_REPLAY_RECEIPT.json'
out.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': receipt['status'], 'checks': len(checks),
                  'passed': sum(c['pass'] for c in checks), 'receipt': str(out),
                  'sha256': sha(out), 'source_bindings': len(bindings)}, sort_keys=True))
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
