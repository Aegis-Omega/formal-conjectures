import RHKreinFirstCellV1

set_option autoImplicit false
noncomputable section

namespace AEGIS.K1TargetCompatibilityOct7

open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinFirstCellV1

/- This audits the already proved zero-centre object.  It does not identify
the unprovided v33 formula with that object. -/
theorem reused_zero_center_k1 : exactJetCoefficient firstCenter 1 = 0 := by
  simpa [firstJet] using firstJet_one_exact

theorem reported_interval_is_not_zero_center_k1 :
    ¬ ((347860160497147 / 1000000000000000 : ℝ) <
        exactJetCoefficient firstCenter 1 ∧
      exactJetCoefficient firstCenter 1 <
        (347860160497149 / 1000000000000000 : ℝ)) := by
  rw [reused_zero_center_k1]
  norm_num

theorem reported_midpoint_is_not_zero_center_k1 :
    (1 / 1000000000000 : ℝ) <
      |exactJetCoefficient firstCenter 1 -
        (347860160497148 / 1000000000000000 : ℝ)| := by
  rw [reused_zero_center_k1]
  norm_num

end AEGIS.K1TargetCompatibilityOct7

#print AEGIS.RHKreinFirstCellV1.firstCenter
#check AEGIS.RHKreinFirstCellV1.firstJet_one_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_one_exact
#check AEGIS.K1TargetCompatibilityOct7.reused_zero_center_k1
#check AEGIS.K1TargetCompatibilityOct7.reported_interval_is_not_zero_center_k1
#check AEGIS.K1TargetCompatibilityOct7.reported_midpoint_is_not_zero_center_k1
#print axioms AEGIS.K1TargetCompatibilityOct7.reused_zero_center_k1
#print axioms AEGIS.K1TargetCompatibilityOct7.reported_interval_is_not_zero_center_k1
#print axioms AEGIS.K1TargetCompatibilityOct7.reported_midpoint_is_not_zero_center_k1
