/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinCellAnalyticBridgeV1
import AEGISOverlay.RHKreinFiniteIntervalKernelV1

/-!
# First serialized cell reduction

This file instantiates the generic M8-to-cell bridge on the actual first cell
of the 2199-cell payload. Exact arithmetic closes the cell geometry, the
degree-seven polynomial lower bound and the final weighted budget. The retained
premises are three concrete even Taylor-jet coefficient enclosures; the symbol,
zeroth coefficient, and all odd coefficients are produced in this file.

The decimal rationals below are candidate Taylor coefficients.  The zeroth
and all odd coefficients are proved exact here; only the three positive even
coefficients remain enclosure premises.  No all-cells, pointwise, or RH claim
is made.

AUTHORITY_EFFECT = NONE.
-/

open scoped BigOperators

set_option autoImplicit false
set_option maxHeartbeats 200000
noncomputable section

namespace AEGIS.RHKreinFirstCellV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinCorrectionM8BoundV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1

/-- The literal first entry of the committed 2199-cell payload. -/
def firstCell : FiniteCellV1 :=
  ⟨0, 75 / 4096, 114511397055347687⟩

theorem firstCell_mem : firstCell ∈ finiteCells := by
  unfold finiteCells
  exact List.mem_cons.mpr (Or.inl rfl)

def firstCenter : ℝ := 0
def firstRadius : ℝ := 75 / 4096

/-- Twelve-decimal centers for the eight normalized Taylor coefficients. -/
def firstJet : ℕ → ℝ
  | 0 => 25181386563 / 62500000000
  | 1 => 0
  | 2 => 2243764096193 / 1000000000000
  | 3 => 0
  | 4 => 2096414380799 / 1000000000000
  | 5 => 0
  | 6 => -190744442117 / 1000000000000
  | 7 => 0
  | _ => 0

def firstJetError (_ : ℕ) : ℝ := 1 / 1000000000000

/-- A decimal rational strictly below the sign-aware polynomial lower bound
for `firstJet` on this nonnegative cell. -/
def firstPolynomialLower : ℝ := 4029021849 / 10000000000

/-- The exact M8 remainder plus the eight enclosure radii used by the bridge. -/
def firstTaylorError : ℝ :=
  (serializedM8Q : ℝ) * firstRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * firstRadius ^ k

private theorem firstTaylorError_le :
    firstTaylorError ≤ (1001 / 1000000000 : ℝ) := by
  norm_num [firstTaylorError, firstRadius, firstJetError, serializedM8Q,
    Finset.sum_range_succ]

private theorem firstGroundBudget :
    (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
        (lowerValue firstCell : ℝ) ≤
      (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
        ((-3177232903 / 500000000 : ℝ) - 1 / 16) +
      (firstPolynomialLower - 1001 / 1000000000) := by
  norm_num [firstCell, lowerValue, firstPolynomialLower]

private theorem firstCell_cover (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    |t - firstCenter| ≤ firstRadius := by
  norm_num [firstCell, firstCenter, firstRadius] at hlo hhi ⊢
  rw [abs_le]
  constructor <;> linarith

private theorem firstPolynomialLower_le (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    firstPolynomialLower ≤ jetPolynomial7 firstJet firstCenter t := by
  have hx := firstCell_cover t hlo hhi
  have ht0 : 0 ≤ t := by norm_num [firstCell] at hlo; exact hlo
  have htr : t ≤ firstRadius := by
    norm_num [firstCell, firstRadius] at hhi ⊢
    exact hhi
  have hp6 : t ^ 6 ≤ firstRadius ^ 6 := pow_le_pow_left₀ ht0 htr 6
  have h6 := mul_le_mul_of_nonpos_left hp6
    (by norm_num [firstJet] : firstJet 6 ≤ 0)
  have h2 : 0 ≤ firstJet 2 * t ^ 2 :=
    mul_nonneg (by norm_num [firstJet]) (sq_nonneg t)
  have h4 : 0 ≤ firstJet 4 * t ^ 4 :=
    mul_nonneg (by norm_num [firstJet]) (by positivity)
  norm_num [firstPolynomialLower, firstRadius, firstCenter, firstJet,
    jetPolynomial7, Finset.sum_range_succ] at h2 h4 h6 ⊢
  linarith only [h2, h4, h6]

private theorem firstCell_weight_le (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    (t ^ 2 + 1 / 4) ^ 2 ≤
      (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) := by
  norm_num [firstCell] at hlo hhi
  nlinarith [sq_nonneg t,
    mul_nonneg (sub_nonneg.mpr hhi) (add_nonneg hlo (by norm_num : (0 : ℝ) ≤ 75 / 4096))]

/-! The 128-term endpoint is split into small exact-arithmetic blocks.  This
keeps kernel replay bounded: no single `norm_num` invocation constructs the
enormous reduced denominator of the full partial sum. -/

private theorem firstDigammaPartialLower :
    (-3644384222938337 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 128, quarterTerm 0 n := by
  have h0 : (-1778990475942809 / 500000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm 0 n := by
    norm_num [quarterTerm]
  have h1 : (-45751803709751 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h2 : (-3083795298877 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h3 : (-1935164358237 / 250000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 24 32, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h4 : (-4654313362753 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 32 40, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h5 : (-155349765201 / 50000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 40 48, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h6 : (-2221295982913 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 48 56, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h7 : (-1667071562231 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 56 64, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h8 : (-1297262096897 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 64 72, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h9 : (-1038219382249 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 72 80, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h10 : (-849722915773 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 80 88, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h11 : (-177072106951 / 250000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 88 96, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h12 : (-599452985397 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 96 104, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h13 : (-51391311861 / 100000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 104 112, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h14 : (-445463229723 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 112 120, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h15 : (-77967009453 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 120 128, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 120 ≤ 128 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 112 ≤ 120 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 104 ≤ 112 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 96 ≤ 104 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 88 ≤ 96 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 80 ≤ 88 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 72 ≤ 80 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 64 ≤ 72 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 56 ≤ 64 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 48 ≤ 56 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 40 ≤ 48 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 32 ≤ 40 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 24 ≤ 32 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15]

private theorem firstDigammaLower (t : ℝ) :
    (-371022478788819736651 / 87723000000000000000 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_quarter_certificate_lower 0 128
  have hpartial := firstDigammaPartialLower
  have hzero :
      (-371022478788819736651 / 87723000000000000000 : ℝ) ≤
        (Complex.digamma ((1 / 4 : ℂ) + ((0 : ℝ) : ℂ) * Complex.I / 2)).re := by
    norm_num at hcert ⊢
    linarith only [hcert, hpartial]
  exact hzero.trans (digamma_quarter_mono_of_sq_le 0 t (by simpa using sq_nonneg t))

private theorem firstLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by
    nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem firstPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The symbol premise for the first cell, now produced entirely by Lean from
the proved digamma series, monotonicity, and rational transcendental bounds. -/
theorem firstCell_symbol_lower (t : ℝ) :
    (-3177232903 / 500000000 : ℝ) ≤ symbol t := by
  have hd := firstDigammaLower t
  have hlp := firstLogPiUpper
  have hamp := firstPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
/-- At center zero the sinc/cosine expression collapses to exact rational
coefficient arithmetic, so the zeroth Taylor coefficient needs no enclosure. -/
theorem firstJet_zero_exact :
    exactJetCoefficient firstCenter 0 = firstJet 0 := by
  norm_num [exactJetCoefficient, firstCenter, firstJet, correctionSymbol,
    hatCoefficient, splineCoefficient, Fin.sum_univ_succ]

private theorem deriv_zero_of_even
    (f : ℝ → ℝ) (hf : DifferentiableAt ℝ f 0)
    (heven : ∀ x, f (-x) = f x) : deriv f 0 = 0 := by
  have hneg : HasDerivAt Neg.neg (-1) (0 : ℝ) := hasDerivAt_neg 0
  have hfnegzero : HasDerivAt f (deriv f 0) (-0) := by
    simpa only [neg_zero] using hf.hasDerivAt
  have hcomp : HasDerivAt (f ∘ Neg.neg) (deriv f 0 * (-1)) 0 :=
    hfnegzero.comp 0 hneg
  have heq : (f ∘ Neg.neg) = f := by
    funext x
    exact heven x
  rw [heq] at hcomp
  have hu := hcomp.unique hf.hasDerivAt
  linarith

private theorem deriv_odd_of_even
    (f : ℝ → ℝ) (hf : Differentiable ℝ f)
    (heven : ∀ x, f (-x) = f x) : ∀ x, deriv f (-x) = -deriv f x := by
  intro x
  have hneg : HasDerivAt Neg.neg (-1) x := hasDerivAt_neg x
  have hfneg : HasDerivAt f (deriv f (-x)) (-x) := (hf (-x)).hasDerivAt
  have hcomp : HasDerivAt (f ∘ Neg.neg) (deriv f (-x) * (-1)) x :=
    hfneg.comp x hneg
  have heq : (f ∘ Neg.neg) = f := by
    funext y
    exact heven y
  rw [heq] at hcomp
  have hu := hcomp.unique (hf x).hasDerivAt
  linarith

private theorem deriv_even_of_odd
    (f : ℝ → ℝ) (hf : Differentiable ℝ f)
    (hodd : ∀ x, f (-x) = -f x) : ∀ x, deriv f (-x) = deriv f x := by
  intro x
  have hneg : HasDerivAt Neg.neg (-1) x := hasDerivAt_neg x
  have hfneg : HasDerivAt f (deriv f (-x)) (-x) := (hf (-x)).hasDerivAt
  have hcomp : HasDerivAt (f ∘ Neg.neg) (deriv f (-x) * (-1)) x :=
    hfneg.comp x hneg
  have heq : (f ∘ Neg.neg) = fun y => -f y := by
    funext y
    exact hodd y
  rw [heq] at hcomp
  have hu := hcomp.unique (hf x).hasDerivAt.neg
  linarith

/-- For an even C⁸ real function, the third, fifth, and seventh derivatives
at the origin vanish. -/
theorem odd_iteratedDerivs_zero_of_even
    (f : ℝ → ℝ) (hf : ContDiff ℝ 8 f)
    (heven : ∀ x, f (-x) = f x) :
    iteratedDeriv 3 f 0 = 0 ∧ iteratedDeriv 5 f 0 = 0 ∧
      iteratedDeriv 7 f 0 = 0 := by
  have hd (k : ℕ) (hk : k ≤ 7) : Differentiable ℝ (deriv^[k] f) := by
    have hsum : 8 - k + k = 8 := Nat.sub_add_cancel (by omega)
    have hc : ContDiff ℝ (8 - k : ℕ) (deriv^[k] f) := by
      apply ContDiff.iterate_deriv' (8 - k) k
      rw [hsum]
      exact hf
    apply hc.differentiable
    exact_mod_cast (show 8 - k ≠ 0 by omega)
  have h1 := deriv_odd_of_even f (by simpa using hd 0 (by omega)) heven
  have h2 := deriv_even_of_odd (deriv f) (by simpa using hd 1 (by omega)) h1
  have h3 := deriv_odd_of_even (deriv (deriv f))
    (by simpa [Function.iterate_succ_apply] using hd 2 (by omega)) h2
  have h4 := deriv_even_of_odd (deriv (deriv (deriv f)))
    (by simpa [Function.iterate_succ_apply] using hd 3 (by omega)) h3
  have h5 := deriv_odd_of_even (deriv (deriv (deriv (deriv f))))
    (by simpa [Function.iterate_succ_apply] using hd 4 (by omega)) h4
  have h6 := deriv_even_of_odd (deriv (deriv (deriv (deriv (deriv f)))))
    (by simpa [Function.iterate_succ_apply] using hd 5 (by omega)) h5
  have h7 := deriv_odd_of_even (deriv (deriv (deriv (deriv (deriv (deriv f))))))
    (by simpa [Function.iterate_succ_apply] using hd 6 (by omega)) h6
  have h3zero : deriv (deriv (deriv f)) 0 = 0 := by
    have h := h3 0
    norm_num at h
    linarith
  have h5zero : deriv (deriv (deriv (deriv (deriv f)))) 0 = 0 := by
    have h := h5 0
    norm_num at h
    linarith
  have h7zero : deriv (deriv (deriv (deriv (deriv (deriv (deriv f)))))) 0 = 0 := by
    have h := h7 0
    norm_num at h
    linarith
  simpa [iteratedDeriv_eq_iterate, Function.iterate_succ_apply] using
    And.intro h3zero (And.intro h5zero h7zero)

/-- Evenness and C⁸ regularity force the normalized first Taylor coefficient
at the origin to vanish exactly. -/
theorem firstJet_one_exact :
    exactJetCoefficient firstCenter 1 = firstJet 1 := by
  have hdiff : DifferentiableAt ℝ correctionSymbol 0 :=
    (correctionSymbol_contDiff_eight.differentiable (by norm_num)).differentiableAt
  have hderiv : deriv correctionSymbol 0 = 0 :=
    deriv_zero_of_even correctionSymbol hdiff correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, iteratedDeriv_one, hderiv]

/-- Evenness closes the normalized third Taylor coefficient exactly. -/
theorem firstJet_three_exact :
    exactJetCoefficient firstCenter 3 = firstJet 3 := by
  have h := odd_iteratedDerivs_zero_of_even correctionSymbol
    correctionSymbol_contDiff_eight correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, h.1]

/-- Evenness closes the normalized fifth Taylor coefficient exactly. -/
theorem firstJet_five_exact :
    exactJetCoefficient firstCenter 5 = firstJet 5 := by
  have h := odd_iteratedDerivs_zero_of_even correctionSymbol
    correctionSymbol_contDiff_eight correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, h.2.1]

/-- Evenness closes the normalized seventh Taylor coefficient exactly. -/
theorem firstJet_seven_exact :
    exactJetCoefficient firstCenter 7 = firstJet 7 := by
  have h := odd_iteratedDerivs_zero_of_even correctionSymbol
    correctionSymbol_contDiff_eight correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, h.2.2]

/-- The first real serialized cell is sound once the three even indices
`k = 2, 4, 6` are kernel-produced.  Its symbol lower bound, zeroth coefficient,
and all odd coefficients are closed above. -/
theorem firstCell_sound_of_jet_enclosures
    (hjet : ∀ k ∈ Finset.range 8,
      k ≠ 0 → k ≠ 1 → k ≠ 3 → k ≠ 5 → k ≠ 7 →
        |exactJetCoefficient firstCenter k - firstJet k| ≤ firstJetError k) :
    CellAnalyticSoundV1 firstCell := by
  apply cellAnalyticSound_of_jet_enclosures firstCell firstCenter firstRadius
    firstPolynomialLower firstJet firstJetError
  · norm_num [firstRadius]
  · exact firstCell_cover
  · intro k hk
    by_cases hk0 : k = 0
    · subst k
      rw [firstJet_zero_exact]
      norm_num [firstJetError]
    · by_cases hk1 : k = 1
      · subst k
        rw [firstJet_one_exact]
        norm_num [firstJetError]
      · by_cases hk3 : k = 3
        · subst k
          rw [firstJet_three_exact]
          norm_num [firstJetError]
        · by_cases hk5 : k = 5
          · subst k
            rw [firstJet_five_exact]
            norm_num [firstJetError]
          · by_cases hk7 : k = 7
            · subst k
              rw [firstJet_seven_exact]
              norm_num [firstJetError]
            · exact hjet k hk hk0 hk1 hk3 hk5 hk7
  · exact firstPolynomialLower_le
  · intro t hlo hhi
    have hw := firstCell_weight_le t hlo hhi
    have hs := firstCell_symbol_lower t
    have hwp : 0 ≤ (t ^ 2 + 1 / 4) ^ 2 := sq_nonneg _
    have hsMul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) hwp
    have hsNonpos : (-3177232903 / 500000000 : ℝ) - 1 / 16 ≤ 0 := by
      norm_num
    have hweightSymbol :
        (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
            ((-3177232903 / 500000000 : ℝ) - 1 / 16) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) := by
      exact (mul_le_mul_of_nonpos_right hw hsNonpos).trans hsMul
    have hlowerNonneg : (0 : ℝ) ≤ lowerValue firstCell := by
      norm_num [firstCell, lowerValue]
    have hlowerWeight :
        (t ^ 2 + 1 / 4) ^ 2 * lowerValue firstCell ≤
          (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) * lowerValue firstCell :=
      mul_le_mul_of_nonneg_right hw hlowerNonneg
    have hground := firstGroundBudget
    have herror :
        firstPolynomialLower - 1001 / 1000000000 ≤
          firstPolynomialLower - firstTaylorError := by
      linarith [firstTaylorError_le]
    calc
      (t ^ 2 + 1 / 4) ^ 2 * lowerValue firstCell ≤
          (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) * lowerValue firstCell := hlowerWeight
      _ ≤ (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
            ((-3177232903 / 500000000 : ℝ) - 1 / 16) +
          (firstPolynomialLower - 1001 / 1000000000) := hground
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (firstPolynomialLower - firstTaylorError) :=
        add_le_add hweightSymbol herror
      _ = (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (firstPolynomialLower - ((serializedM8Q : ℝ) * firstRadius ^ 8 / 40320 +
            ∑ k ∈ Finset.range 8, firstJetError k * firstRadius ^ k)) := by
        rfl

end AEGIS.RHKreinFirstCellV1

#print axioms AEGIS.RHKreinFirstCellV1.firstCell_sound_of_jet_enclosures
#print axioms AEGIS.RHKreinFirstCellV1.firstCell_symbol_lower
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_zero_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_one_exact
#print axioms AEGIS.RHKreinFirstCellV1.odd_iteratedDerivs_zero_of_even
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_three_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_five_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_seven_exact
