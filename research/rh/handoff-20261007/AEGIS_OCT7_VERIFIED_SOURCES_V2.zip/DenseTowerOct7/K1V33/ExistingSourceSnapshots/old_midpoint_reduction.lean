/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinCellAnalyticBridgeV1
import AEGISOverlay.RHKreinFiniteIntervalKernelV1

/-!
# First serialized cell reduction

This file instantiates the generic M8-to-cell bridge on the actual first cell
of the 2199-cell payload. Exact arithmetic closes the cell geometry, the
degree-seven polynomial lower bound and the final weighted budget. The retained
premises are one concrete symbol lower bound and eight concrete Taylor-jet
coefficient enclosures.

The decimal rationals below are not asserted as enclosures. They are the
centers of the eight explicit premises. No all-cells, pointwise, or RH claim
is made.

AUTHORITY_EFFECT = NONE.
-/

open scoped BigOperators

set_option autoImplicit false
set_option maxHeartbeats 200000
noncomputable section

namespace AEGIS.RHKreinFirstCellV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinCorrectionM8BoundV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1

/-- The literal first entry of the committed 2199-cell payload. -/
def firstCell : FiniteCellV1 :=
  ⟨0, 75 / 4096, 114511397055347687⟩

theorem firstCell_mem : firstCell ∈ finiteCells := by
  unfold finiteCells
  exact List.mem_cons.mpr (Or.inl rfl)

def firstCenter : ℝ := 75 / 8192
def firstRadius : ℝ := 75 / 8192

/-- Twelve-decimal centers for the eight normalized Taylor coefficients. -/
def firstJet : ℕ → ℝ
  | 0 => 403090269870 / 1000000000000
  | 1 => 41090982624 / 1000000000000
  | 2 => 2244818392630 / 1000000000000
  | 3 => 76770059721 / 1000000000000
  | 4 => 2096174510847 / 1000000000000
  | 5 => -10482250793 / 1000000000000
  | 6 => -190981743074 / 1000000000000
  | 7 => -7403311519 / 1000000000000
  | _ => 0

def firstJetError (_ : ℕ) : ℝ := 1 / 1000000000000

/-- A decimal rational strictly below the exact triangle-inequality lower
bound for `firstJet` on the cell.  Keeping this as a single rational avoids
re-normalizing the expanded seven-term expression in every downstream use. -/
def firstPolynomialLower : ℝ := 4025258385 / 10000000000

/-- The exact M8 remainder plus the eight enclosure radii used by the bridge. -/
def firstTaylorError : ℝ :=
  (serializedM8Q : ℝ) * firstRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * firstRadius ^ k

private theorem firstTaylorError_le :
    firstTaylorError ≤ (391 / 100000000000 : ℝ) := by
  norm_num [firstTaylorError, firstRadius, firstJetError, serializedM8Q,
    Finset.sum_range_succ]

private theorem firstGroundBudget :
    (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
        (lowerValue firstCell : ℝ) ≤
      (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
        ((-3177232903 / 500000000 : ℝ) - 1 / 16) +
      (firstPolynomialLower - 391 / 100000000000) := by
  norm_num [firstCell, lowerValue, firstPolynomialLower]

private theorem firstCell_cover (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    |t - firstCenter| ≤ firstRadius := by
  norm_num [firstCell, firstCenter, firstRadius] at hlo hhi ⊢
  rw [abs_le]
  constructor <;> linarith

private theorem firstPolynomialLower_le (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    firstPolynomialLower ≤ jetPolynomial7 firstJet firstCenter t := by
  have hx := firstCell_cover t hlo hhi
  let d : ℝ := t - firstCenter
  have hd : |d| ≤ firstRadius := by simpa [d] using hx
  have hterm (k : ℕ) :
      -(|firstJet k| * firstRadius ^ k) ≤ firstJet k * d ^ k := by
    apply neg_le_of_abs_le
    rw [abs_mul, abs_pow]
    exact mul_le_mul_of_nonneg_left
      (pow_le_pow_left₀ (abs_nonneg d) hd k) (abs_nonneg (firstJet k))
  have h1 := hterm 1
  have h2 := hterm 2
  have h3 := hterm 3
  have h4 := hterm 4
  have h5 := hterm 5
  have h6 := hterm 6
  have h7 := hterm 7
  norm_num [firstPolynomialLower, firstRadius, firstJet, jetPolynomial7,
    Finset.sum_range_succ, d] at h1 h2 h3 h4 h5 h6 h7 ⊢
  linarith

private theorem firstCell_weight_le (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    (t ^ 2 + 1 / 4) ^ 2 ≤
      (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) := by
  norm_num [firstCell] at hlo hhi
  nlinarith [sq_nonneg t,
    mul_nonneg (sub_nonneg.mpr hhi) (add_nonneg hlo (by norm_num : (0 : ℝ) ≤ 75 / 4096))]

/-- The first real serialized cell is sound once the displayed symbol lower
bound and eight Taylor coefficient enclosures are kernel-produced. -/
theorem firstCell_sound_of_jet_enclosures
    (hsymbol : ∀ t : ℝ, (firstCell.lo : ℝ) ≤ t → t ≤ (firstCell.hi : ℝ) →
      (-3177232903 / 500000000 : ℝ) ≤ symbol t)
    (hjet : ∀ k ∈ Finset.range 8,
      |exactJetCoefficient firstCenter k - firstJet k| ≤ firstJetError k) :
    CellAnalyticSoundV1 firstCell := by
  apply cellAnalyticSound_of_jet_enclosures firstCell firstCenter firstRadius
    firstPolynomialLower firstJet firstJetError
  · norm_num [firstRadius]
  · exact firstCell_cover
  · exact hjet
  · exact firstPolynomialLower_le
  · intro t hlo hhi
    have hw := firstCell_weight_le t hlo hhi
    have hs := hsymbol t hlo hhi
    have hwp : 0 ≤ (t ^ 2 + 1 / 4) ^ 2 := sq_nonneg _
    have hsMul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) hwp
    have hsNonpos : (-3177232903 / 500000000 : ℝ) - 1 / 16 ≤ 0 := by
      norm_num
    have hweightSymbol :
        (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
            ((-3177232903 / 500000000 : ℝ) - 1 / 16) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) := by
      exact (mul_le_mul_of_nonpos_right hw hsNonpos).trans hsMul
    have hlowerNonneg : (0 : ℝ) ≤ lowerValue firstCell := by
      norm_num [firstCell, lowerValue]
    have hlowerWeight :
        (t ^ 2 + 1 / 4) ^ 2 * lowerValue firstCell ≤
          (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) * lowerValue firstCell :=
      mul_le_mul_of_nonneg_right hw hlowerNonneg
    have hground := firstGroundBudget
    have herror :
        firstPolynomialLower - 391 / 100000000000 ≤
          firstPolynomialLower - firstTaylorError := by
      linarith [firstTaylorError_le]
    calc
      (t ^ 2 + 1 / 4) ^ 2 * lowerValue firstCell ≤
          (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) * lowerValue firstCell := hlowerWeight
      _ ≤ (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
            ((-3177232903 / 500000000 : ℝ) - 1 / 16) +
          (firstPolynomialLower - 391 / 100000000000) := hground
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (firstPolynomialLower - firstTaylorError) :=
        add_le_add hweightSymbol herror
      _ = (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (firstPolynomialLower - ((serializedM8Q : ℝ) * firstRadius ^ 8 / 40320 +
            ∑ k ∈ Finset.range 8, firstJetError k * firstRadius ^ k)) := by
        rfl

end AEGIS.RHKreinFirstCellV1

#print axioms AEGIS.RHKreinFirstCellV1.firstCell_sound_of_jet_enclosures
