# v33 report: source and target audit

The user reports an exact-rational verifier enclosing a `k=1` formula in

\[
 (347860160497147,347860160497149)/10^{15}.
\]

The arithmetic midpoint is `347860160497148/10^15`, and the interval's
half-width is `1/10^15`. This is indeed narrower than `1/10^12`.
The report also says that 349/349 source hashes and a ZIP passed, while the
Lean kernel and axiom audit were `NOT_RUN`.

These are **reported results**, not replayed v33 results in this runner.
The message provides no actual attachment path or file ID for v33. The
previous `/tmp/codex-remote-attachments` tree does not exist in this runner.
A targeted ZIP-name search over `/workspace` and `/tmp` found three older
generated PR53 ZIPs, not `AEGIS_PR53_first_cell_reduction.zip` v33.
A targeted exact numeric-string search in available Lean, Python, Markdown
and JSON proof scopes found no `347860160497` target before this new audit.
Mathematical literature, compiled libraries and Git internals were excluded
from that content search. These findings are scoped source-recovery facts,
not claims that v33 does not exist elsewhere or that its calculation is false.

Read-only GitHub sampling returned formal-conjectures PR #53 head
`81bcd289cd6df73901fc97168b00a3b04376eac9`. Its exact tree and six relevant
M8, correction, Taylor and finite-interval modules were fetched and bound in
`PublicPR53/SOURCE_RECOVERY.json`. The sampled tree has no `FirstCell` module,
and the six fetched modules do not contain the reported number. This is not
an exhaustive branch/history search. No remote source or workflow changed.

## Reused existing analytic proof

The actual recovered zero-centre source is

`PR53TrigTaylorIntegration/Inputs/3/research/rh/m8_kernel_v1/RHKreinFirstCellV1.lean`.

It defines `AEGIS.RHKreinFirstCellV1.firstCenter = 0` and proves, without
external coefficient premises,

```
AEGIS.RHKreinFirstCellV1.firstJet_one_exact :
  exactJetCoefficient firstCenter 1 = firstJet 1
```

where `firstJet 1 = 0`. Its proof uses the actual correction symbol's
evenness and C8 regularity, then its real derivative at zero and the actual
normalization by `1!`. It is a real analytic coefficient theorem, not a
Python assertion or a proof about an arbitrary decimal constant.

The older recovered midpoint source under the same namespace has
`firstCenter = 75/8192` and decimal centre `firstJet 1 = 41090982624/10^12`.
That decimal centre in the older reduction is an explicit enclosure premise,
not a premise-free coefficient theorem in that source. Different source
versions must not be imported as the same object. The user report does not
identify its formula, cell centre, correction data or normalization, so no
identification of its `0.347860...` with either recovered object is asserted.

## Executed scoped integration

`K1TargetCompatibilityOct7.lean` reuses the existing analytic theorem.
It proves that the recovered zero-centre coefficient is exactly zero and
therefore cannot be enclosed by the reported strictly positive interval.
The rejection is conditional on selecting **that recovered coefficient**;
it is not a refutation of the unidentified v33 formula.

The first fresh scoped compilation and separate pinned `leanchecker` both
passed. It printed the full existing and new endpoint types and axiom lists.
Every endpoint uses only `propext`, `Classical.choice` and `Quot.sound`.
Compiler: Lean 4.33.1, commit
`819816b2e0a3bf405af45ae5c7af2491d8f5bee6`.
Mathlib pin: `0df444a360eaa60ab8c11dca51a86af692955474`.

```
python3 DenseTowerOct7/K1V33/replay_compatibility.py
```

The replay uses source-bound imported objects from the previously audited
coherent first-cell context. It does not rebuild Mathlib or the entire
transitive source closure. The fresh source has no `sorry`, new axioms,
unsafe execution, or native proof shortcuts. It is an object-compatibility
audit; it supplies no new global RH sign producer.

A separate agent executed the unchanged replay script a second time in a
fresh directory. Its compiler and kernel checker also exited zero, with the
same four axiom reports. Both fresh OLEANs have SHA256
`b105cb174093797ae824057d88e342f28fecbbc6c43919521f482cab18b5eb55`.
The raw receipts are:

- `scoped-replay-20261007T052807.216296Z/RECEIPT.json`, SHA256
  `f74bf5bc42706c791456c43a432cef70cfd0cfc137b2901875da0f2ebdbbd1c4`;
- `scoped-replay-20261007T052918.634006Z/RECEIPT.json`, SHA256
  `728f5b3e713e950bfde6df034cb733e39458961a88cb0ea47e691d4e3c23ae20`.

This is an independent agent execution on the same host and pinned engine,
with the same identified imports. It is not an independent v33 replay.

The v33 kernel audit remains **NOT_RUN** and v33 source availability remains
**NOT_LOCATED_IN_SEARCHED_SCOPE**. The existing zero-centre k1 proof remains
**KERNEL_VERIFIED** under its own exact source identity. Its earlier theorem
is reused instead of mathematically reproved.

## Minimal missing v33 snapshot

To execute the requested v33 Taylor/Lagrange port, the missing input is the
actual ZIP bytes, or the exact extracted target formula and analytic object
definitions together with its verifier, rational certificate, 349-entry
source manifest and replay receipt. The formula must identify the coefficient
order, expansion centre, correction-data hash, Fourier normalization and
factorial convention. A bare numerical interval cannot supply those bindings.

This source-access gap does not suspend the root's independent work on
`DenseFixedPacketSign`. No further finite-cell certificate production is
presented as an unconditional globalization theorem.
