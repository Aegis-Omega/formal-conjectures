#!/usr/bin/env python3
"""Independent read-only checks; outputs live only beside this script."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import ast
import hashlib
import json
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
WORK = BASE.parent.parent
checks = []
bindings = {}

def digest(b):
    return hashlib.sha256(b).hexdigest()

def read(name):
    p = BASE / name
    b = p.read_bytes()
    bindings[str(p.resolve().relative_to(WORK))] = {'sha256': digest(b), 'bytes': len(b)}
    return b

def data(name):
    return json.loads(read(name))

def check(name, condition, detail=None):
    checks.append({'check': name, 'passed': bool(condition), 'detail': detail})
    if not condition:
        raise ValueError(name + ': ' + str(detail))

graph = data('IMPORT_GRAPH.json')
restored = data('RESTORED_SOURCE_RECEIPT.json')
transfer = data('TRANSFER_RECEIPT.json')
access = data('ACCESS_BINDINGS.json')
chunks = data('CHUNK_ACCESS_BINDINGS.json')
receipt = data('ORIGINAL_BUDGET_REPLAY_RECEIPT.json')
source_pins = data('SOURCE_PINS.json')
data('TRANSFER_CHECKPOINT.json')
read('README.md')
read('MODULE_INDEX.md')
read('restore_readable_sources.py')

reported_refs = {r['reference']: r for r in transfer['files']}
check('library_page_identity', access['page_id'] == chunks['page_id'] == 'page_8e07dec567bc8191af925d27a4f0e2b2')
check('access_binding_counts', len(access['bindings']) == 14 and len(chunks['bindings']) == 11)
unreported_access = []
for item in access['bindings'] + chunks['bindings']:
    b = read(item['file'])
    check('access:' + item['file'], digest(b) == item['sha256'] and len(b) == item['byte_size'] and item['reference'].startswith('library-file:'))
    if item['reference'] in reported_refs:
        r = reported_refs[item['reference']]
        check('original_transfer_binding:' + item['file'], item['sha256'] == r['sha256'] and item['byte_size'] == r['byte_size'])
    else:
        unreported_access.append(item['file'])

metadata = {r['module']: r for r in graph['modules']}
restored_rows = {r['module']: r for r in restored['modules']}
check('graph_module_count', len(metadata) == len(graph['modules']) == 155 == restored['module_count'])
check('restoration_script_binding', restored['script_sha256'] == digest(read('restore_readable_sources.py')))
check('restoration_graph_binding', restored['import_graph_sha256'] == digest(read('IMPORT_GRAPH.json')))
check('restoration_scope_flags', not restored['archive_bytes_downloaded'] and not restored['full_546_file_manifest_replayed'] and not restored['lean_kernel_replayed_by_this_script'] and not restored['rh_proven'])

# A stateful line scan, independent of the original regex restoration.
parts = {}
for item in chunks['bindings']:
    lines = read(item['file']).decode().splitlines(keepends=True)
    i = 0
    while i < len(lines):
        if not lines[i].startswith('## '):
            i += 1
            continue
        module = lines[i][3:].strip()
        i += 1
        header = []
        while i < len(lines) and lines[i].rstrip('\n') != '~~~~~~lean':
            header.append(lines[i].strip())
            i += 1
        check('chunk_code_fence:' + module, i < len(lines))
        i += 1
        code = []
        while i < len(lines) and lines[i].rstrip('\n') != '~~~~~~':
            code.append(lines[i])
            i += 1
        check('chunk_closing_fence:' + module, i < len(lines))
        i += 1
        path_line = next(s for s in header if s.startswith('Path: '))
        sha_line = next(s for s in header if s.startswith('Full file SHA256: '))
        range_line = next(s for s in header if s.startswith('Original source lines: '))
        path = path_line.split('`')[1]
        full_sha = sha_line.split('`')[1]
        lo, hi = map(int, range_line.split(': ')[1].split('–'))
        check('chunk_metadata:' + module, module in metadata and metadata[module]['path'] == path and metadata[module]['sha256'] == full_sha and lo >= 1 and hi >= lo and len(code) == hi-lo+1)
        parts.setdefault(module, []).append((lo, hi, ''.join(code), item['file']))
check('chunk_module_set', set(parts) == set(metadata) == set(restored_rows))

def uncomment(text):
    out = []; i = 0; depth = 0; quoted = False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == '/-': depth += 1; i += 2; continue
            if pair == '-/': depth -= 1; i += 2; continue
            out.append('\n' if text[i] == '\n' else ' '); i += 1; continue
        if not quoted and pair == '/-': depth = 1; i += 2; out.append('  '); continue
        if not quoted and pair == '--':
            end = text.find('\n', i)
            if end < 0: break
            out.append('\n'); i = end+1; continue
        ch = text[i]
        if ch == '"' and (i == 0 or text[i-1] != '\\'): quoted = not quoted
        out.append(ch); i += 1
    if depth: raise ValueError('unterminated Lean comment')
    return ''.join(out)

imports = {}
trailing_newline_adjustments = []
total_parts = 0
for module in sorted(metadata):
    row = metadata[module]; segments = sorted(parts[module]); cursor = 1; texts = []
    for lo, hi, text, chunk in segments:
        check('line_continuity:' + module + ':' + str(lo), cursor == lo)
        cursor = hi+1; texts.append(text); total_parts += 1
    b = ''.join(texts).encode()
    if digest(b) != row['sha256'] and b.endswith(b'\n') and digest(b[:-1]) == row['sha256']:
        b = b[:-1]; trailing_newline_adjustments.append(module)
    actual = read('Restored/' + row['path'])
    rr = restored_rows[module]
    blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
    check('source_identity:' + module, b == actual and digest(b) == row['sha256'] == rr['sha256'] and blob == row['git_blob'] == rr['git_blob'] and len(b) == rr['bytes'])
    clean = uncomment(b.decode())
    imp = []
    for line in clean.splitlines():
        m = re.match(r'^\s*(?:public\s+|private\s+)?(?:meta\s+)?import\s+(.+)$', line)
        if m: imp.extend(m.group(1).split())
    imports[module] = imp
    check('actual_imports:' + module, imp == row['imports'], {'actual': imp, 'recorded': row['imports']})
    check('source_parts:' + module, sorted(set(row['readable_source_parts'])) == sorted({int(Path(s[3]).stem.rsplit('_',1)[1]) for s in segments}) and rr['parts'] == sorted({s[3] for s in segments}))

external_actual = {x for xs in imports.values() for x in xs if x not in metadata}
check('external_import_set', external_actual == set(graph['external_imports']) and len(external_actual) == 142)
reachable = set()
def walk(m, stack=()):
    if m in stack: raise ValueError('local import cycle: ' + str(stack + (m,)))
    if m in reachable: return
    reachable.add(m)
    for n in imports[m]:
        if n in metadata: walk(n, stack+(m,))
for root in graph['roots']:
    check('declared_root:' + root, root in metadata)
    walk(root)
check('root_closure_complete', len(graph['roots']) == 27 and reachable == set(metadata) and graph['needed'] == [] and graph['closure_complete'] and not graph['lean_kernel_replayed'])

inp = data('source-input.json')
reference = data('source-receipt.json')
original_result = data('rational-result.json')
prior_normal = data('ORIGINAL_BUDGET_REPLAY.json')
prior_optimized = data('ORIGINAL_BUDGET_REPLAY_OPTIMIZED.json')

def vector(text, name):
    m = re.search(r'def '+name+r'\b[^\n]*\n\s*!\[(.*?)\]', text, re.S)
    if m is None: raise ValueError('vector not found: ' + name)
    return [F(s.strip()) for s in m.group(1).split(',')]

public_symbol_path = '../PR53Lane/Public53/sources/AEGISOverlay/RHKreinExplicitCorrectionV1.lean'
public_cells_path = '../PR53Lane/Public53/sources/AEGISOverlay/RHKreinFiniteCertificateDataV1.lean'
public_symbol = read(public_symbol_path).decode()
public_cells = read(public_cells_path).decode()
restored_symbol = read('Restored/source/AEGISOverlay/RHKreinExplicitCorrectionV1.lean').decode()
check('explicit_correction_compatibility_scope', restored_symbol == public_symbol.replace('  change HasCompactSupport (∑ i, f i)\n', '  rw [← Finset.sum_fn]\n',1))
for name, field, count in [('hatCoefficient','hat_coefficients',199),('splineCoefficient','spline_coefficients',5)]:
    check('exact_input_vector:' + name, len(inp[field]) == count and [F(x) for x in inp[field]] == vector(public_symbol,name) == vector(restored_symbol,name))
cell_text = public_cells.split('def finiteCells : List FiniteCellV1 := [',1)[1].split(']',1)[0]
cell_rows = re.findall(r'⟨\s*([^,]+),\s*([^,]+),\s*([^⟩]+)⟩', cell_text)
check('serialized_cell_count_and_selected15', len(cell_rows) == 2199 and [F(x) for x in cell_rows[14]] == [F(x) for x in inp['cell']] == [F(2475,32768),F(1275,16384),F(292616690003685633)])
c = F(inp['center']); alpha = F(inp['spline_frequency'])
check('exact_midpoint_frequency_target', c == (F(inp['cell'][0])+F(inp['cell'][1]))/2 == F(5025,65536) and alpha == F(1619,2000) and F(inp['target_center']) == F(347860160497,10**12) and F(inp['target_radius']) == F(1,10**12) and inp['cell_index_zero_based'] == 14)
max_hat_phase = max(abs(c*F(j+41,50)) for j in range(199))
e16 = lambda x: abs(x)**16*F(17, factorial(16)*16)
e8sinc = lambda x: abs(x)**7*F(9,factorial(8)*8)
check('fixed_input_all_named_taylor_budgets', max_hat_phase == F(48039,131072) and max_hat_phase <= F(3,8) and e16(max_hat_phase) <= F(1,10**20) and e16(c*alpha) <= F(1,10**25) and e8sinc(c/100) <= F(1,10**26) and e8sinc(c/2000) <= F(1,10**34) and 0 < c/2000 < c/100 < 1)
reduction = read('RHKreinFifteenthCellReductionV1.lean').decode()
formula = read('RHKreinFifteenthCellK1FormulaV1.lean').decode()
kernel = read('../Cell15Concrete/AnalyticError/RHKreinCell15AnalyticErrorOct7.lean').decode()
phases = read('../Cell15Concrete/RHKreinCell15PhasesOct7.lean').decode()
check('source_cell15_identity_literals', '5025 / 65536' in reduction and '347860160497 / 1000000000000' in reduction and 'fifteenthCenter_k1_enclosure' in kernel and '347860160497 / 10 ^ (12 : ℕ)' in kernel and '5025 / 65536' in phases)
check('formula_recovery_full_structure', all(s in formula for s in ['hatColumnDerivative', 'edgeColumnDerivative', 'fifteenthCorrectionDerivativeFormula', '^ 18', '^ 19']))

fields = ['center','target','candidate_enclosure','enclosure_width','minimum_margin_inside_target','inside_target','reference_degree53_enclosure_inside_candidate']
script = BASE/'check_existing_taylor_budget.py'
script_bytes = read('check_existing_taylor_budget.py')
check('original_evaluator_source_binding', digest(script_bytes) == receipt['original_source_sha256'] == '9c8b71e6ee1a134caff2362dd9ec90f85e3ed1454185a7434db01e39589e755e')
for optimized in [False, True]:
    out = HERE/('VALID_INPUT_OPTIMIZED.json' if optimized else 'VALID_INPUT_NORMAL.json')
    cmd = [sys.executable] + (['-O'] if optimized else []) + [str(script),'--input',str(BASE/'source-input.json'),'--reference-receipt',str(BASE/'source-receipt.json'),'--output',str(out)]
    run = subprocess.run(cmd, capture_output=True,text=True)
    check('fresh_original_evaluator_exit:' + str(optimized), run.returncode == 0, {'command':cmd,'stdout':run.stdout,'stderr':run.stderr})
    fresh = json.loads(out.read_bytes())
    for field in fields:
        check('seven_math_fields:' + str(optimized) + ':' + field, fresh[field] == original_result[field] == prior_normal[field] == prior_optimized[field])
    check('fixed_valid_input_enclosure:' + str(optimized), F(fresh['minimum_margin_inside_target']) > 0 and F(fresh['enclosure_width']) > 0 and not fresh['lean_proven'] and not fresh['rh_proven'])

guard_probe = '''import importlib.util,json,sys
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location("original",sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result={}
for name,thunk in [("reversed",lambda:m.I(2,1)),("cross_zero_reciprocal",lambda:m.I(-1,1).inv())]:
 try:
  v=thunk();result[name]={"accepted":True,"interval":[str(v.lo),str(v.hi)]}
 except Exception as e:result[name]={"accepted":False,"exception":type(e).__name__}
print(json.dumps(result,sort_keys=True))
'''
guard_results = {}
for optimized in [False,True]:
    cmd=[sys.executable]+(['-O'] if optimized else [])+['-c',guard_probe,str(script)]
    run=subprocess.run(cmd,capture_output=True,text=True)
    check('guard_probe_executed:' + str(optimized),run.returncode==0,run.stderr)
    guard_results[str(optimized)]=json.loads(run.stdout)
check('guard_defect_reproduced', all(not r['accepted'] and r['exception']=='AssertionError' for r in guard_results['False'].values()) and all(r['accepted'] for r in guard_results['True'].values()) and guard_results['True']['cross_zero_reciprocal']['interval']==['-1','1'])
(HERE/'ASSERT_GUARD_PROBE.json').write_text(json.dumps({'commands_scope':'import unchanged original evaluator in normal/-O Python; controlled malformed interval probes','results':guard_results},indent=2,sort_keys=True)+'\n')
tree=ast.parse(script_bytes)
float_calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='float']
decimal_def=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='decimal')
check('float_only_in_display_converter', len(float_calls)==1 and float_calls[0] in list(ast.walk(decimal_def)))
parents={child:node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
decimal_calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='decimal']
display_keys=[]
for call in decimal_calls:
    current=call
    while current in parents and not isinstance(parents[current],ast.Dict):
        current=parents[current]
    enclosing=parents.get(current)
    if not isinstance(enclosing,ast.Dict): raise ValueError('decimal used outside result display dictionary')
    key=enclosing.keys[enclosing.values.index(current)]
    if not isinstance(key,ast.Constant) or not isinstance(key.value,str): raise ValueError('nonliteral decimal display field')
    display_keys.append(key.value)
check('decimal_calls_only_display_fields', len(decimal_calls)==4 and all(k.endswith('_decimal') for k in display_keys),display_keys)
check('fraction_decisions_literal', 'passes = target_box.lo <= derivative.lo and derivative.hi <= target_box.hi' in script_bytes.decode() and 'margin = min(derivative.lo - target_box.lo, target_box.hi - derivative.hi)' in script_bytes.decode())
candidate=[F(x) for x in original_result['candidate_enclosure']]
fine=[F(x) for x in reference['certified_outer_enclosure']]
check('reference_inclusion_direction', candidate[0] < fine[0] < fine[1] < candidate[1] and fine == [F(347860160497147,10**15),F(347860160497149,10**15)] and reference['lean_kernel_replay']=='NOT_RUN')
check('received_transfer_report_is_not_new_replay', transfer['result']['source_manifest_files_verified']==546 and not transfer['result']['lean_kernel_replayed'])
check('source_pins_mathlib_lean', source_pins['mathlib']=='0df444a360eaa60ab8c11dca51a86af692955474' and source_pins['lean_toolchain']=='leanprover/lean4:v4.33.1')

report={'schema':'aegis.library.transfer.independent.source-review.v1','status':'PASS_FOR_SCOPED_FIXED_INPUT_AND_SOURCE_BINDINGS','checks':checks,'check_count':len(checks),'source_bindings':bindings,'module_count':155,'source_parts':total_parts,'readable_chunks':11,'external_import_count':142,'root_count':27,'single_trailing_newline_restorations':trailing_newline_adjustments,'access_entries_not_in_original_27_file_list':unreported_access,'findings':[{'id':'ASSERT_GUARDS_DISABLED_UNDER_OPTIMIZATION','status':'REPRODUCED','scope':'generic original interval validator; supplied fixed input is independently domain-checked here'},{'id':'WIDE_RESULT_CONTAINS_FINE_REFERENCE','status':'CONFIRMED','scope':'original evaluator does not itself prove the narrower reported outer enclosure'}],'archive_bytes_retrieved_by_this_review':False,'full_546_file_manifest_read':False,'zip_pass_claim':False,'fresh_lean_kernel_replay_by_this_review':False,'remote_library_retrieval_by_this_review':False,'rh_proven':False}
(HERE/'AUDIT_RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'modules':155,'source_bindings':len(bindings),'rh_proven':False},sort_keys=True))
