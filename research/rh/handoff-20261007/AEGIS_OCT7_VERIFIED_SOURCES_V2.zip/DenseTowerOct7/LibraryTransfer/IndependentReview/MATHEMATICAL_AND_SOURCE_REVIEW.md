# Independent review of the recovered Library transfer

The recovered readable sources and the supplied fixed-input rational computation pass this scoped review. This review neither retrieves the original ZIP archives nor recompiles the restored Lean closure. Its fresh executions are the unchanged original rational evaluator, in normal and optimized Python, and separate malformed-interval probes.

## What was actually recovered and checked

The local access records bind 14 text files and 11 readable chunks to Library file references on `page_8e07dec567bc8191af925d27a4f0e2b2`. Each file's bytes, length and SHA256 match its access record. For the 24 entries also enumerated in the imported 27-file transfer receipt, the original reference, size and digest agree. The new transfer-receipt file itself has its own access binding rather than being listed recursively inside that receipt. This reviewer did not perform a second remote Library retrieval.

An independent stateful scan reconstructs all 155 local Lean modules from 156 source pieces. Every declared line interval is consecutive from line 1, with no missing or overlapping interval; the reconstructed source equals its restored file and matches both recorded SHA256 and Git blob identity. One module, `WeilThreeBlockTranslatedPacketsV22`, requires removal of a single readable-fence trailing newline, uniquely justified by the original full-file digest. All other bytes match directly.

After removing nested Lean comments and line comments, all 155 actual import lists equal the recorded graph lists. All modules are reachable from the 27 declared roots; their local import graph is acyclic and their remaining direct imports are exactly the 142 recorded external module names. This is a source graph check, not a Lean parser proof, materialization of the external libraries, or kernel replay. The transfer's claim about a prior 546-file manifest remains an imported report: that manifest and the archive bytes were not read here. No ZIP PASS is asserted.

The recovered effective correction source differs from public PR53 only by the recorded compact-support proof compatibility line (`change ...` replaced by `rw [← Finset.sum_fn]`). All 199 exact hat coefficients and five exact spline coefficients match the original input and public PR53 vectors. Source pins distinguish the transfer baseline `e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121`, PR53 `81bcd289cd6df73901fc97168b00a3b04376eac9`, and PR54 `b59c358df750dc8b953cc4a352acabc58cd61593`; this review makes no new assertion about the external RH target pin. The recorded Mathlib and Lean pins remain `0df444a360eaa60ab8c11dca51a86af692955474` and `leanprover/lean4:v4.33.1`.

## Actual scalar target and derivative

The selected serialized cell is zero-based entry 14, one-based cell 15:

\[
 (a,b,m)=(2475/32768,\ 1275/16384,\ 292616690003685633),\qquad
 c=(a+b)/2=5025/65536.
\]

The public table contains 2,199 entries; this audit validates entry 15, not the other 2,198 entries. The original target is the first jet at this midpoint, within radius \(10^{-12}\) of \(347860160497/10^{12}\).

Writing \(u_j=(j+41)/50\), \(\beta=1619/2000\), and \(D(x)=(x\cos x-\sin x)/x^2\), the source's correction has the form

\[
 F(t)=\frac1{25}\operatorname{sinc}(t/100)^2 A(t)
       +\operatorname{sinc}(t/2000)^{19} B(t),
\]

where \(A\) contains all 199 weighted cosines, while \(B\) contains all five weighted polynomial times parity-selected sine/cosine columns. Its full derivative is

\[
 F'(c)=\frac1{25}(2SS'A+S^2A')+19H^{18}H'B+H^{19}B',
\]

with \(S=\operatorname{sinc}(c/100)\), \(S'=D(c/100)/100\), \(H=\operatorname{sinc}(c/2000)\), \(H'=D(c/2000)/2000\). The original evaluator's quotient formulas `cos(c/d)/c - d*sin(c/d)/c²` equal \(D(c/d)/d\). Its sums retain all 199 hats, all five columns, their polynomial derivatives, their phase derivatives, and both sinc factors with powers 18 and 19. The recovered original K1 formula has this same complete structure. The derivative-to-first-jet identification is stated and proved in the recovered Lean source, but this review does not newly compile that source.

For the supplied input the maximum hat phase is exactly \(48039/131072<3/8\), the spline phase is \(325419/5242880\), and the two sinc arguments are \(201/262144\) and \(201/5242880\). Exact arithmetic verifies that the degree-15 trigonometric error \(|x|^{16}17/(16!16)\) is at most the supplied uniform budgets \(10^{-20}\) and \(10^{-25}\). The degree-6 sinc error \(|x|^7/35840\) is at most \(10^{-26}\) and \(10^{-34}\), respectively. Every reciprocal denominator used on this fixed input is nonzero. These checks discharge the concrete analytic-budget premises separately from the evaluator's generic input-validation limitations.

## Fresh original computation and its limits

The original evaluator source SHA256 is `9c8b71e6ee1a134caff2362dd9ec90f85e3ed1454185a7434db01e39589e755e`. Fresh unchanged normal and `python -O` executions reproduce exactly all seven original mathematical fields: centre, target, rational enclosure, rational width, rational target margin, target-inclusion decision, and reported-reference-inclusion decision. Its enclosure is approximately

\[
 [0.347860160497127757,\ 0.347860160497167725],
\]

with width approximately \(3.99506276289551618\times10^{-14}\) and positive target margin approximately \(8.32281639288260481\times10^{-13}\). These displayed decimals are illustrative floating conversions. Every comparison and stored mathematical endpoint is a `Fraction`. Static call checks locate the only `float` conversion inside `decimal`, whose four call sites populate display-only result fields.

The reported finer reference interval
\[
 (347860160497147,\ 347860160497149)/10^{15}
\]
lies *inside* the evaluator's wider enclosure. This inclusion does not prove the finer interval: its input receipt reports that interval and says `lean_kernel_replay = NOT_RUN`. The separate new sine-degree-17 ordinary reconstruction and the new first-jet kernel endpoint have their own source-bound evidence; they must not be attributed to this original wider computation. This review reads the new endpoint statement `AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure` and checks its midpoint and target agree. Its fresh kernel and original-namespace wrapper audits are separate work, not executions performed by this review.

## Reproduced generic checker defect

The original interval class uses `assert` for ordered endpoints and for excluding zero before reciprocation. Both guards disappear under `-O`. Normal Python rejects `I(2,1)` and `I(-1,1).inv()` with `AssertionError`; optimized Python accepts both and reports `[-1,1]` for the latter reciprocal, which cannot enclose inversion across zero. `ASSERT_GUARD_PROBE.json` records these actual separate executions.

The original command also accepts unpinned arbitrary JSON without proving coefficient counts, source identity or the adequacy of its fixed error budgets for changed phases. It is therefore an implementation-planning evaluator, not a fail-closed universal certificate checker. This does not refute the correct supplied-input result: the concrete counts, source identity, domains and budgets are independently checked above. A hardened generic checker would need explicit validation independent of Python assertion optimization; the frozen original script was preserved.

No universal sign, complete cell-15 jet vector, all-cell certificate, support globalization, detecting-packet sign, or RH conclusion follows from this scalar calculation. `rh_proven` remains false.

## Reproduction

From `/workspace/aegis-research/work`, run:

```sh
python3 DenseTowerOct7/LibraryTransfer/IndependentReview/audit_library_transfer.py
```

The audit reads inspected sources and writes only its own review directory. Its final execution passes 1,210 scoped checks against 191 source bindings. The execution receipt records an earlier audit-script `KeyError` caused by using a nonexistent pin key; that local auditor was corrected to the actual `mathlib` key. No recovered source or frozen previous report was changed.
