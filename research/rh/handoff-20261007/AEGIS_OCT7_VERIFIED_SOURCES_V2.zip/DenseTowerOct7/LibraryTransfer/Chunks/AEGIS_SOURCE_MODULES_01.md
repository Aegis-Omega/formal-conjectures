# AEGIS source modules 1

Exact pinned or operator archive source. Compilation was not performed during transfer.

## research.rh.finite_m8_v1.RHKreinM8FiniteWindowV1

Path: `source/research/rh/finite_m8_v1/RHKreinM8FiniteWindowV1.lean`

Original source lines: 1–276

Full file SHA256: `18134e7c8683ad12940d03ee7596bdbf763d6f6d5279e1f363bf306465ea3294`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/
import AEGISOverlay.RHKreinCorrectionM8BoundV1

/-!
# Finite-window eighth-derivative majorant for the actual correction symbol

This keeps the existing coefficients and Fourier convention. On |t| <= T,
Leibniz differentiation of t^j times the undifferentiated spline transform
replaces the global 2000^j cost by an exact degree-j polynomial in T.
No finite-cell soundness, pointwise positivity or RH is asserted.
AUTHORITY_EFFECT = NONE.
-/
open Set MeasureTheory Complex FourierTransform
open scoped BigOperators
set_option autoImplicit false
noncomputable section
namespace AEGIS.RHKreinM8FiniteWindowV1
open AEGIS.RHKreinExplicitCorrectionV1 AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinCorrectionM8BoundV1 AEGIS.RHKreinFourierTaylorBoundV1
open AEGIS.RHKreinSplineSupportV1 AEGIS.RHKreinSplineContinuityV1
open AEGIS.RHKreinSplineL1NormV1 AEGIS.RHKreinSplineDerivativesV1

/-- The fixed right support endpoint of the certificate's spline. -/
def radius : ℝ := 819 / 1000

def baseSpline : ℝ → ℂ := spline19 (4 / 5) (1 / 1000)
def splineFourier : ℝ → ℂ := angularFourier baseSpline

private theorem base_moments : HasMomentsUpToEight baseSpline :=
  hasMomentsUpToEight_of_continuous_compact _
    (spline19_continuous _ (by norm_num)) (spline19_hasCompactSupport _ _)

private theorem splineFourier_contDiff : ContDiff ℝ 8 splineFourier :=
  (fourier_contDiff_eight _ base_moments).comp (contDiff_const.mul contDiff_id)

/-- Exact angular normalization for every derivative order consumed by Leibniz. -/
theorem angular_derivative_norm_le_moment (f : ℝ → ℂ) (hf : HasMomentsUpToEight f)
    (n : ℕ) (hn : n ≤ 8) (t : ℝ) :
    ‖iteratedDeriv n (angularFourier f) t‖ ≤ ∫ x : ℝ, |x| ^ n * ‖f x‖ := by
  have hc : ContDiff ℝ n (𝓕 f) :=
    (fourier_contDiff_eight f hf).of_le (by exact_mod_cast hn)
  have hd : iteratedDeriv n (𝓕 f) =
      𝓕 (fun x : ℝ => (-2 * Real.pi * Complex.I * (x : ℂ)) ^ n • f x) := by
    apply Real.iteratedDeriv_fourier (N := (8 : ℕ∞))
    · intro k hk
      exact hf k (by exact_mod_cast hk)
    · exact_mod_cast hn
  have he : iteratedDeriv n (angularFourier f) = fun t =>
      angularScale ^ n •
        𝓕 (fun x : ℝ => (-2 * Real.pi * Complex.I * (x : ℂ)) ^ n • f x)
          (angularScale * t) := by
    unfold angularFourier
    rw [iteratedDeriv_comp_const_smul hc angularScale, hd]
  have hm (x : ℝ) : ‖((-2 * Real.pi * Complex.I * (x : ℂ)) ^ n) • f x‖ =
      (2 * Real.pi) ^ n * (|x| ^ n * ‖f x‖) := by
    norm_num [norm_smul, norm_pow, norm_mul, Complex.norm_real,
      Real.norm_eq_abs, abs_of_pos Real.pi_pos, mul_pow]
    ring
  have hs : |angularScale| ^ n * (2 * Real.pi) ^ n = 1 := by
    rw [← mul_pow]
    have h : |angularScale| * (2 * Real.pi) = 1 := by
      simp only [angularScale, abs_neg, abs_inv,
        abs_of_pos (by positivity : 0 < 2 * Real.pi)]
      exact inv_mul_cancel₀ (by positivity)
    rw [h, one_pow]
  rw [he, norm_smul, Real.norm_eq_abs, abs_pow]
  calc
    _ ≤ |angularScale| ^ n * ∫ x : ℝ,
        ‖((-2 * Real.pi * Complex.I * (x : ℂ)) ^ n) • f x‖ := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact VectorFourier.norm_fourierIntegral_le_integral_norm
        Real.fourierChar volume (innerₗ ℝ) _ _
    _ = ∫ x : ℝ, |x| ^ n * ‖f x‖ := by
      simp_rw [hm]
      rw [integral_const_mul, ← mul_assoc, hs, one_mul]

/-- The undifferentiated spline transform costs only radius^n at order n. -/
theorem splineFourier_derivative_le (n : ℕ) (hn : n ≤ 8) (t : ℝ) :
    ‖iteratedDeriv n splineFourier t‖ ≤ radius ^ n := by
  have hi : Integrable baseSpline := spline19_integrable _ _
  have hw : Integrable (fun x : ℝ => |x| ^ n * ‖baseSpline x‖) := by
    simpa only [Real.norm_eq_abs] using norm_moment_integrable _ base_moments n hn
  have hb (x : ℝ) : |x| ^ n * ‖baseSpline x‖ ≤ radius ^ n * ‖baseSpline x‖ := by
    by_cases hz : baseSpline x = 0
    · simp [hz]
    · have hx := spline19_support (4 / 5) (1 / 1000) x hz
      have hx0 : 0 ≤ x := by linarith [hx.1]
      have hxR : x ≤ radius := by dsimp [radius]; norm_num at hx ⊢; linarith [hx.2]
      rw [abs_of_nonneg hx0]
      gcongr
  have hmass : (∫ x : ℝ, ‖baseSpline x‖) ≤ 1 := by
    simpa [baseSpline] using
      (spline19_derivative_L1 (4 / 5) (h := 1 / 1000) (by norm_num) 0 (by norm_num)).2
  calc
    ‖iteratedDeriv n splineFourier t‖ ≤ ∫ x : ℝ, |x| ^ n * ‖baseSpline x‖ :=
      angular_derivative_norm_le_moment _ base_moments n hn t
    _ ≤ ∫ x : ℝ, radius ^ n * ‖baseSpline x‖ := integral_mono hw (hi.norm.const_mul _) hb
    _ = radius ^ n * ∫ x : ℝ, ‖baseSpline x‖ := integral_const_mul _ _
    _ ≤ radius ^ n * 1 := mul_le_mul_of_nonneg_left hmass (by unfold radius; positivity)
    _ = radius ^ n := mul_one _

private theorem complex_monomial_derivative (j k : ℕ) (t : ℝ) :
    iteratedDeriv k (fun x : ℝ => (x : ℂ) ^ j) t =
      (j.descFactorial k : ℂ) * (t : ℂ) ^ (j - k) := by
  have hc : ContDiff ℝ k (fun x : ℝ => x ^ j) := by fun_prop
  have he : (fun x : ℝ => (x : ℂ) ^ j) =
      Complex.ofRealCLM ∘ (fun x : ℝ => x ^ j) := by ext x; simp
  rw [he]
  change iteratedFDeriv ℝ k (Complex.ofRealCLM ∘ (fun x : ℝ => x ^ j)) t
    (fun _ => 1) = _
  rw [Complex.ofRealCLM.iteratedFDeriv_comp_left hc.contDiffAt le_rfl]
  change ((iteratedDeriv k (fun x : ℝ => x ^ j) t : ℝ) : ℂ) = _
  rw [iteratedDeriv_pow]
  push_cast
  rfl

/-- Exact Leibniz polynomial; descending factorials make k > j terms zero. -/
def edgeBudget (j : ℕ) (T : ℝ) : ℝ :=
  ∑ k ∈ Finset.range 9,
    (Nat.choose 8 k : ℝ) * (j.descFactorial k : ℝ) * T ^ (j - k) * radius ^ (8 - k)

/-- The polynomial-times-transform bound before taking real parts or phases. -/
theorem monomial_spline_eighth_le (j : ℕ) (T t : ℝ) (hT : 0 ≤ T) (ht : |t| ≤ T) :
    ‖iteratedDeriv 8 (fun t : ℝ => (t : ℂ) ^ j * splineFourier t) t‖ ≤ edgeBudget j T := by
  have hp : ContDiff ℝ 8 (fun x : ℝ => (x : ℂ) ^ j) :=
    Complex.ofRealCLM.contDiff.pow j
  rw [iteratedDeriv_fun_mul hp.contDiffAt splineFourier_contDiff.contDiffAt]
  apply (norm_sum_le _ _).trans
  unfold edgeBudget
  apply Finset.sum_le_sum
  intro k hk
  have hnorm : ‖iteratedDeriv k (fun x : ℝ => (x : ℂ) ^ j) t‖ =
      (j.descFactorial k : ℝ) * |t| ^ (j - k) := by
    rw [complex_monomial_derivative]
    simp only [norm_mul, norm_pow, Complex.norm_natCast, Complex.norm_real, Real.norm_eq_abs]
  simp only [norm_mul, Complex.norm_natCast, hnorm]
  have hF := splineFourier_derivative_le (8 - k) (by omega) t
  have hpow : |t| ^ (j - k) ≤ T ^ (j - k) := pow_le_pow_left₀ (abs_nonneg t) ht _
  have hR : 0 ≤ radius ^ (8 - k) := by unfold radius; positivity
  calc
    _ ≤ (Nat.choose 8 k : ℝ) * ((j.descFactorial k : ℝ) * T ^ (j - k)) *
        radius ^ (8 - k) := by gcongr
    _ = _ := by ring

private theorem edge_angular (j : Fin 5) :
    angularFourier (edgePacket j) = fun t : ℝ =>
      (-Complex.I) ^ j.val * ((t : ℂ) ^ j.val * splineFourier t) := by
  funext t
  simp only [edgePacket, splineFourier, baseSpline, angularFourier, angularScale_mul]
  rw [spline19_derivative_fourier _ (by norm_num) _ (by omega),
    spline19_fourier _ (by norm_num)]
  rw [mul_pow]
  ring

private theorem edge_angular_contDiff (j : Fin 5) :
    ContDiff ℝ 8 (angularFourier (edgePacket j)) := by
  rw [edge_angular]
  have hp : ContDiff ℝ 8 (fun t : ℝ => (t : ℂ) ^ j.val) :=
    Complex.ofRealCLM.contDiff.pow j.val
  exact contDiff_const.mul (hp.mul splineFourier_contDiff)

/-- Exact unit-modulus phases are harmless; no extra factor two is introduced. -/
theorem edge_real_eighth_le (j : Fin 5) (T t : ℝ) (hT : 0 ≤ T) (ht : |t| ≤ T) :
    |iteratedDeriv 8 (realAngular (edgePacket j)) t| ≤ edgeBudget j.val T := by
  have hc := edge_angular_contDiff j
  have he : iteratedDeriv 8 (realAngular (edgePacket j)) t =
      (iteratedDeriv 8 (angularFourier (edgePacket j)) t).re := by
    change iteratedFDeriv ℝ 8 (Complex.reCLM ∘ angularFourier (edgePacket j)) t
      (fun _ => 1) = _
    rw [Complex.reCLM.iteratedFDeriv_comp_left hc.contDiffAt (by norm_num)]
    rfl
  rw [he]
  apply (Complex.abs_re_le_norm _).trans
  rw [edge_angular, iteratedDeriv_const_mul_field, norm_mul, norm_pow]
  simp only [norm_neg, Complex.norm_I, one_pow, one_mul]
  exact monomial_spline_eighth_le j.val T t hT ht

private theorem sum_eighth_bound {ι : Type*} [Fintype ι]
    (f : ι → ℝ → ℝ) (a B : ι → ℝ) (hc : ∀ i, ContDiff ℝ 8 (f i))
    (t : ℝ) (hb : ∀ i, |iteratedDeriv 8 (f i) t| ≤ B i) :
    |iteratedDeriv 8 (fun t => ∑ i, a i * f i t) t| ≤ ∑ i, |a i| * B i := by
  rw [iteratedDeriv_fun_sum (fun i _ => (contDiff_const.mul (hc i)).contDiffAt)]
  simp_rw [iteratedDeriv_const_mul_field]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro i _
  rw [abs_mul]
  exact mul_le_mul_of_nonneg_left (hb i) (abs_nonneg _)

/-- Existing hat budget plus the improved finite-window spline budget. -/
def finiteM8 (T : ℝ) : ℝ :=
  (∑ j : Fin 199, 2 * (1 / 50) * |(hatCoefficient j : ℝ)| *
    (hatCenter j + 1 / 50) ^ 8) +
  ∑ j : Fin 5, |(splineCoefficient j : ℝ)| * edgeBudget j.val T

/-- Unconditional finite-window bound for the actual, unchanged correctionSymbol. -/
theorem correctionSymbol_eighth_le_finiteWindow (T t : ℝ) (hT : 0 ≤ T) (ht : |t| ≤ T) :
    |iteratedDeriv 8 correctionSymbol t| ≤ finiteM8 T := by
  have hm (j : Fin 199) : HasMomentsUpToEight (hatPacket j) :=
    hasMomentsUpToEight_of_continuous_compact _ (hatPacket_continuous j) (hatPacket_compact j)
  have ch (j : Fin 199) := realAngular_contDiff _ (hm j)
  have ce (j : Fin 5) : ContDiff ℝ 8 (realAngular (edgePacket j)) :=
    Complex.reCLM.contDiff.comp (edge_angular_contDiff j)
  have bh (j : Fin 199) : |iteratedDeriv 8 (realAngular (hatPacket j)) t| ≤
      (1 / 50) * (hatCenter j + 1 / 50) ^ 8 :=
    (realAngular_eighth_le_moment _ (hm j) t).trans (hatPacket_weighted_eighth_L1 j).2
  rw [correctionSymbol_eq_columns,
    iteratedDeriv_fun_add (ContDiff.sum (fun j _ => contDiff_const.mul (ch j))).contDiffAt
      (ContDiff.sum (fun j _ => contDiff_const.mul (ce j))).contDiffAt]
  apply (abs_add_le _ _).trans
  refine (add_le_add (sum_eighth_bound _ _ _ ch t bh)
    (sum_eighth_bound _ _ _ ce t (fun j => edge_real_eighth_le j T t hT ht))).trans_eq ?_
  unfold finiteM8
  congr 1
  · apply Finset.sum_congr rfl
    intro j _
    rw [abs_mul]
    norm_num
    ring
  · apply Finset.sum_congr rfl
    intro j _
    simp only [abs_mul, abs_pow, abs_neg, abs_one, one_pow, mul_one]

set_option maxRecDepth 16384 in
set_option maxHeartbeats 16000000 in
/-- Exact finite-window rational, with the hat sum eliminated via the proved global identity. -/
theorem finiteM8_three_hundred_eq :
    finiteM8 300 =
      (138411104278141883145249511099127907904956837 /
        5000000000000000000000000000000000 : ℝ) := by
  have he : finiteM8 300 = m8Real -
      (∑ j : Fin 5, |(splineCoefficient j : ℝ)| * 2000 ^ j.val * (819 / 1000) ^ 8) +
      ∑ j : Fin 5, |(splineCoefficient j : ℝ)| * edgeBudget j.val 300 := by
    unfold finiteM8 m8Real
    ring
  rw [he, m8Real_eq_certificateM8Q, certificateM8_eq_serialized_v1]
  norm_num [serializedM8Q, splineCoefficient, edgeBudget, radius,
    Fin.sum_univ_succ, Finset.sum_range_succ, Nat.descFactorial, Nat.choose]

/-- The 300-window majorant is rigorously over 115 times smaller than the global one. -/
theorem finiteM8_improvement_factor :
    115 * finiteM8 300 < (serializedM8Q : ℝ) ∧
      (serializedM8Q : ℝ) < 116 * finiteM8 300 := by
  rw [finiteM8_three_hundred_eq]
  norm_num [serializedM8Q]

theorem correctionSymbol_eighth_le_window300 (t : ℝ) (ht : |t| ≤ 300) :
    |iteratedDeriv 8 correctionSymbol t| ≤
      (138411104278141883145249511099127907904956837 /
        5000000000000000000000000000000000 : ℝ) := by
  simpa only [finiteM8_three_hundred_eq] using
    correctionSymbol_eighth_le_finiteWindow 300 t (by norm_num) ht

end AEGIS.RHKreinM8FiniteWindowV1
#print axioms AEGIS.RHKreinM8FiniteWindowV1.angular_derivative_norm_le_moment
#print axioms AEGIS.RHKreinM8FiniteWindowV1.splineFourier_derivative_le
#print axioms AEGIS.RHKreinM8FiniteWindowV1.monomial_spline_eighth_le
#print axioms AEGIS.RHKreinM8FiniteWindowV1.edge_real_eighth_le
#print axioms AEGIS.RHKreinM8FiniteWindowV1.correctionSymbol_eighth_le_finiteWindow
#print axioms AEGIS.RHKreinM8FiniteWindowV1.finiteM8_three_hundred_eq
#print axioms AEGIS.RHKreinM8FiniteWindowV1.finiteM8_improvement_factor
#print axioms AEGIS.RHKreinM8FiniteWindowV1.correctionSymbol_eighth_le_window300
~~~~~~

## AEGISOverlay.RHKreinCorrectionM8BoundV1

Path: `source/AEGISOverlay/RHKreinCorrectionM8BoundV1.lean`

Original source lines: 1–320

Full file SHA256: `4bd2732bb99d4109061ee26e2d24a9cd751d7821ceddb9789711d762c338069e`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/81bcd289cd6df73901fc97168b00a3b04376eac9/research/rh/m8_kernel_v1/RHKreinCorrectionM8BoundV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinCorrectionSymbolV1
import AEGISOverlay.RHKreinM8CertificateV1
import AEGISOverlay.RHKreinSplineL1NormV1
import AEGISOverlay.RHKreinSplineDerivativesV1
import AEGISOverlay.RHKreinFourierTaylorBoundV1

/-!
# The analytic M8 bound for the exact order-19 correction symbol

Every row is a genuine compactly supported function. We differentiate its
angular Fourier transform, bound the eighth moment, and sum the exact
coefficient budgets. The one-sided rows represent the real correction symbol;
they are not asserted to equal the Hermitian time-domain correction.

No pointwise positivity, cell soundness or RH is assumed or concluded.
AUTHORITY_EFFECT = NONE.
-/

open Set MeasureTheory Complex FourierTransform
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinCorrectionM8BoundV1

open AEGIS.RHKreinExplicitCorrectionV1 AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinSplineSupportV1 AEGIS.RHKreinSplineContinuityV1
open AEGIS.RHKreinSplineL1NormV1 AEGIS.RHKreinSplineDerivativesV1
open AEGIS.RHKreinFourierTaylorBoundV1

def realAngular (f : ℝ → ℂ) (t : ℝ) : ℝ := (angularFourier f t).re

theorem realAngular_contDiff (f : ℝ → ℂ) (hf : HasMomentsUpToEight f) :
    ContDiff ℝ 8 (realAngular f) := by
  have hc : ContDiff ℝ 8 (angularFourier f) :=
    (fourier_contDiff_eight f hf).comp (contDiff_const.mul contDiff_id)
  exact Complex.reCLM.contDiff.comp hc

/-- The angular scaling cancels exactly: there is no residual 2*pi factor. -/
theorem angular_eighth_norm_le_moment (f : ℝ → ℂ) (hf : HasMomentsUpToEight f)
    (t : ℝ) :
    ‖iteratedDeriv 8 (angularFourier f) t‖ ≤ ∫ x : ℝ, |x| ^ 8 * ‖f x‖ := by
  have hn (x : ℝ) :
      ‖((-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8) • f x‖ =
        (2 * Real.pi) ^ 8 * (|x| ^ 8 * ‖f x‖) := by
    norm_num [norm_smul, norm_pow, norm_mul, Complex.norm_real,
      Real.norm_eq_abs, abs_of_pos Real.pi_pos]
    ring
  have hs : |angularScale| ^ 8 * (2 * Real.pi) ^ 8 = 1 := by
    rw [← mul_pow]
    have h : |angularScale| * (2 * Real.pi) = 1 := by
      simp only [angularScale, abs_neg, abs_inv,
        abs_of_pos (by positivity : 0 < 2 * Real.pi)]
      exact inv_mul_cancel₀ (by positivity)
    rw [h, one_pow]
  calc
    ‖iteratedDeriv 8 (angularFourier f) t‖ ≤
        |angularScale| ^ 8 * ∫ x : ℝ,
          ‖((-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8) • f x‖ :=
      angular_eighth_derivative_norm_le f hf t
    _ = ∫ x : ℝ, |x| ^ 8 * ‖f x‖ := by
      simp_rw [hn]
      rw [integral_const_mul, ← mul_assoc, hs, one_mul]

/-- Taking the real part commutes with the eighth ordinary derivative. -/
theorem realAngular_eighth_le_moment (f : ℝ → ℂ) (hf : HasMomentsUpToEight f)
    (t : ℝ) :
    |iteratedDeriv 8 (realAngular f) t| ≤ ∫ x : ℝ, |x| ^ 8 * ‖f x‖ := by
  have hc : ContDiff ℝ 8 (angularFourier f) :=
    (fourier_contDiff_eight f hf).comp (contDiff_const.mul contDiff_id)
  have he : iteratedDeriv 8 (realAngular f) t =
      (iteratedDeriv 8 (angularFourier f) t).re := by
    change iteratedFDeriv ℝ 8 (Complex.reCLM ∘ angularFourier f) t (fun _ => 1) = _
    rw [Complex.reCLM.iteratedFDeriv_comp_left hc.contDiffAt (by norm_num)]
    rfl
  rw [he]
  exact (Complex.abs_re_le_norm _).trans (angular_eighth_norm_le_moment f hf t)

/-- Positive triangular hat of the original width and center. -/
def hatPacket (j : Fin 199) (x : ℝ) : ℂ :=
  (1 / 50 : ℂ) * splineCore (1 / 50) 1 (x - hatCenter j)

theorem hatPacket_continuous (j : Fin 199) : Continuous (hatPacket j) := by
  have hc := (splineCore_contDiff (by norm_num : (0 : ℝ) ≤ 1 / 50) 0).continuous
  exact continuous_const.mul (hc.comp (continuous_id.sub continuous_const))

theorem hatPacket_compact (j : Fin 199) : HasCompactSupport (hatPacket j) := by
  have hs := (splineCore_hasCompactSupport (1 / 50) 1).comp_homeomorph
    (Homeomorph.addRight (-hatCenter j))
  have ht : HasCompactSupport (fun x : ℝ => splineCore (1 / 50) 1 (x - hatCenter j)) := by
    simpa [Function.comp_def, sub_eq_add_neg] using hs
  exact ht.mul_left

private theorem hatPacket_integrable (j : Fin 199) : Integrable (hatPacket j) :=
  (hatPacket_continuous j).integrable_of_hasCompactSupport (hatPacket_compact j)

/-- Its L1 mass is bounded by its width, not by an unproved pointwise surrogate. -/
theorem hatPacket_L1_le (j : Fin 199) : (∫ x : ℝ, ‖hatPacket j x‖) ≤ 1 / 50 := by
  have hn (x : ℝ) : ‖hatPacket j x‖ =
      (1 / 50 : ℝ) * ‖splineCore (1 / 50) 1 (x - hatCenter j)‖ := by
    simp only [hatPacket, norm_mul]
    norm_num
  calc
    (∫ x : ℝ, ‖hatPacket j x‖) =
        (1 / 50 : ℝ) * ∫ x : ℝ, ‖splineCore (1 / 50) 1 x‖ := by
      simp_rw [hn]
      rw [integral_const_mul,
        integral_sub_right_eq_self (fun x : ℝ => ‖splineCore (1 / 50) 1 x‖) (hatCenter j)]
    _ ≤ (1 / 50 : ℝ) * 1 :=
      mul_le_mul_of_nonneg_left (integral_norm_splineCore_le_one (by norm_num) 1) (by norm_num)
    _ = 1 / 50 := mul_one _

/-- The exact hat part of the certificate's eighth-moment budget. -/
theorem hatPacket_weighted_eighth_L1 (j : Fin 199) :
    Integrable (fun x : ℝ => |x| ^ 8 * ‖hatPacket j x‖) ∧
      (∫ x : ℝ, |x| ^ 8 * ‖hatPacket j x‖) ≤
        (1 / 50) * (hatCenter j + 1 / 50) ^ 8 := by
  have hi := hatPacket_integrable j
  have hb (x : ℝ) : |x| ^ 8 * ‖hatPacket j x‖ ≤
      (hatCenter j + 1 / 50) ^ 8 * ‖hatPacket j x‖ := by
    by_cases hz : hatPacket j x = 0
    · simp [hz]
    · have hz' : splineCore (1 / 50) 1 (x - hatCenter j) ≠ 0 := by
        intro h
        exact hz (by rw [hatPacket, h, mul_zero])
      have hx := splineCore_support (1 / 50) 1 (x - hatCenter j) hz'
      norm_num at hx
      have hj : (0 : ℝ) ≤ j.val := Nat.cast_nonneg _
      have hc : (1 / 50 : ℝ) ≤ hatCenter j := by unfold hatCenter; linarith
      have hx0 : 0 ≤ x := by linarith [hx.1]
      rw [abs_of_nonneg hx0]
      gcongr
      linarith [hx.2]
  have hmeas : AEStronglyMeasurable (fun x : ℝ => |x| ^ 8 * ‖hatPacket j x‖) volume :=
    (continuous_abs.pow 8).aestronglyMeasurable.mul hi.norm.aestronglyMeasurable
  have hw : Integrable (fun x : ℝ => |x| ^ 8 * ‖hatPacket j x‖) := by
    refine (hi.norm.const_mul ((hatCenter j + 1 / 50) ^ 8)).mono' hmeas ?_
    exact Filter.Eventually.of_forall fun x => by
      rw [Real.norm_eq_abs, abs_of_nonneg (by positivity)]
      exact hb x
  refine ⟨hw, ?_⟩
  calc
    (∫ x : ℝ, |x| ^ 8 * ‖hatPacket j x‖) ≤
        ∫ x : ℝ, (hatCenter j + 1 / 50) ^ 8 * ‖hatPacket j x‖ :=
      integral_mono hw (hi.norm.const_mul _) hb
    _ = (hatCenter j + 1 / 50) ^ 8 * ∫ x : ℝ, ‖hatPacket j x‖ := integral_const_mul _ _
    _ ≤ (hatCenter j + 1 / 50) ^ 8 * (1 / 50) :=
      mul_le_mul_of_nonneg_left (hatPacket_L1_le j) (by positivity)
    _ = (1 / 50) * (hatCenter j + 1 / 50) ^ 8 := mul_comm _ _

def edgePacket (j : Fin 5) : ℝ → ℂ := deriv^[j.val] (spline19 (4 / 5) (1 / 1000))

private theorem edgePacket_continuous (j : Fin 5) : Continuous (edgePacket j) :=
  (spline19_derivative_contDiff (4 / 5) (by norm_num) j.val (by omega)).continuous

private theorem edgePacket_compact (j : Fin 5) : HasCompactSupport (edgePacket j) := by
  apply HasCompactSupport.intro (K := Icc (4 / 5) (4 / 5 + 19 * (1 / 1000))) isCompact_Icc
  intro x hx
  by_contra hn
  exact hx (spline19_derivative_support (4 / 5) (1 / 1000) j.val (subset_closure hn))

private theorem hat_moments (j : Fin 199) : HasMomentsUpToEight (hatPacket j) :=
  hasMomentsUpToEight_of_continuous_compact _ (hatPacket_continuous j) (hatPacket_compact j)

private theorem edge_moments (j : Fin 5) : HasMomentsUpToEight (edgePacket j) :=
  hasMomentsUpToEight_of_continuous_compact _ (edgePacket_continuous j) (edgePacket_compact j)

private theorem fourier_const_mul (f : ℝ → ℂ) (c : ℂ) (ξ : ℝ) :
    𝓕 (fun x => c * f x) ξ = c * 𝓕 f ξ := by
  rw [Real.fourier_real_eq_integral_exp_smul, Real.fourier_real_eq_integral_exp_smul]
  simp only [smul_eq_mul]
  rw [← integral_const_mul]
  congr 1
  funext x
  ring

private theorem realAngular_hat (j : Fin 199) (t : ℝ) :
    realAngular (hatPacket j) t =
      (1 / 50) * Real.sinc (t / 100) ^ 2 * Real.cos (t * hatCenter j) := by
  unfold realAngular angularFourier hatPacket
  rw [angularScale_mul, fourier_const_mul, fourier_translate_angular,
    splineCore_fourier (by norm_num : (0 : ℝ) < 1 / 50)]
  rw [show (1 / 50 : ℝ) * t / 2 = t / 100 by ring]
  norm_num [← Complex.ofReal_pow, Complex.mul_re, Complex.mul_im, Complex.exp_re]
  ring

private theorem realAngular_edge (j : Fin 5) (t : ℝ) :
    (-1 : ℝ) ^ (j.val / 2) * realAngular (edgePacket j) t =
      Real.sinc (t / 2000) ^ 19 * t ^ j.val *
        (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
         else Real.sin (t * (1619 / 2000))) := by
  unfold realAngular angularFourier edgePacket
  rw [angularScale_mul, spline19_derivative_fourier _ (by norm_num) _ (by omega)]
  rw [show (4 / 5 : ℝ) + 19 * (1 / 1000) / 2 = 1619 / 2000 by norm_num,
    show (1 / 1000 : ℝ) * t / 2 = t / 2000 by ring]
  have hr (z : ℂ) (r : ℝ) : (z * (r : ℂ) ^ 19).re = z.re * r ^ 19 := by
    rw [← Complex.ofReal_pow]
    simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero]
  rw [hr]
  calc
    _ = Real.sinc (t / 2000) ^ 19 *
        ((-1 : ℝ) ^ (j.val / 2) *
          (((-Complex.I * (t : ℂ)) ^ j.val) *
            Complex.exp (((t * (1619 / 2000) : ℝ) : ℂ) * Complex.I)).re) := by ring
    _ = _ := by rw [certificate_derivative_parity]; ring

/-- Equality to the actual extracted correctionSymbol, with both scaling factors. -/
theorem correctionSymbol_eq_columns : correctionSymbol = fun t : ℝ =>
    (∑ j : Fin 199, (2 * (hatCoefficient j : ℝ)) * realAngular (hatPacket j) t) +
      ∑ j : Fin 5, ((splineCoefficient j : ℝ) * (-1 : ℝ) ^ (j.val / 2)) *
        realAngular (edgePacket j) t := by
  funext t
  unfold correctionSymbol
  simp_rw [mul_assoc (splineCoefficient _ : ℝ), realAngular_hat, realAngular_edge]
  simp only [Finset.mul_sum]
  congr 1 <;> apply Finset.sum_congr rfl <;> intro j _ <;> ring

private theorem columns_contDiff {ι : Type*} [Fintype ι]
    (f : ι → ℝ → ℝ) (a : ι → ℝ) (hc : ∀ i, ContDiff ℝ 8 (f i)) :
    ContDiff ℝ 8 (fun t => ∑ i, a i * f i t) :=
  ContDiff.sum (fun i _ => contDiff_const.mul (hc i))

private theorem column_sum_eighth_bound {ι : Type*} [Fintype ι]
    (f : ι → ℝ → ℝ) (a B : ι → ℝ) (hc : ∀ i, ContDiff ℝ 8 (f i))
    (hb : ∀ i t, |iteratedDeriv 8 (f i) t| ≤ B i) (t : ℝ) :
    |iteratedDeriv 8 (fun t => ∑ i, a i * f i t) t| ≤ ∑ i, |a i| * B i := by
  rw [iteratedDeriv_fun_sum (fun i _ => (contDiff_const.mul (hc i)).contDiffAt)]
  simp_rw [iteratedDeriv_const_mul_field]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro i _
  rw [abs_mul]
  exact mul_le_mul_of_nonneg_left (hb i t) (abs_nonneg _)

def m8Real : ℝ :=
  (∑ j : Fin 199, 2 * (1 / 50) * |(hatCoefficient j : ℝ)| *
    (hatCenter j + 1 / 50) ^ 8) +
  ∑ j : Fin 5, |(splineCoefficient j : ℝ)| * 2000 ^ j.val * (819 / 1000) ^ 8

theorem correctionSymbol_contDiff_eight : ContDiff ℝ 8 correctionSymbol := by
  rw [correctionSymbol_eq_columns]
  exact (columns_contDiff _ _ (fun j => realAngular_contDiff _ (hat_moments j))).add
    (columns_contDiff _ _ (fun j => realAngular_contDiff _ (edge_moments j)))

/-- Full analytic eighth-derivative bound for the exact real correction symbol. -/
theorem correctionSymbol_eighth_derivative_le (t : ℝ) :
    |iteratedDeriv 8 correctionSymbol t| ≤ m8Real := by
  have ch (j : Fin 199) := realAngular_contDiff _ (hat_moments j)
  have ce (j : Fin 5) := realAngular_contDiff _ (edge_moments j)
  have bh (j : Fin 199) (t : ℝ) : |iteratedDeriv 8 (realAngular (hatPacket j)) t| ≤
      (1 / 50) * (hatCenter j + 1 / 50) ^ 8 :=
    (realAngular_eighth_le_moment _ (hat_moments j) t).trans (hatPacket_weighted_eighth_L1 j).2
  have be (j : Fin 5) (t : ℝ) : |iteratedDeriv 8 (realAngular (edgePacket j)) t| ≤
      2000 ^ j.val * (819 / 1000) ^ 8 :=
    (realAngular_eighth_le_moment _ (edge_moments j) t).trans
      (certificate_spline_columns_weighted_eighth_L1 j).2
  rw [correctionSymbol_eq_columns,
    iteratedDeriv_fun_add (columns_contDiff _ _ ch).contDiffAt (columns_contDiff _ _ ce).contDiffAt]
  apply (abs_add_le _ _).trans
  refine (add_le_add (column_sum_eighth_bound _ _ _ ch bh t)
    (column_sum_eighth_bound _ _ _ ce be t)).trans_eq ?_
  unfold m8Real
  congr 1
  · apply Finset.sum_congr rfl
    intro j _
    rw [abs_mul]
    norm_num
    ring
  · apply Finset.sum_congr rfl
    intro j _
    simp only [abs_mul, abs_pow, abs_neg, abs_one, one_pow, mul_one]
    ring

/-- Rational arithmetic and the analytic real budget describe exactly the same number. -/
theorem m8Real_eq_certificateM8Q : m8Real = (certificateM8Q : ℝ) := by
  unfold m8Real certificateM8Q hatCenter hatCenterQ
  push_cast
  apply congrArg₂ (fun x y : ℝ => x + y)
  · rfl
  · apply Finset.sum_congr rfl
    intro j _
    rw [mul_div_assoc, ← div_pow]
    norm_num

/-- The serialized rational M8 is an unconditional bound at every real frequency.
No finite-cell lower endpoint is used as a premise. -/
theorem correctionSymbol_eighth_derivative_le_serialized (t : ℝ) :
    |iteratedDeriv 8 correctionSymbol t| ≤ (serializedM8Q : ℝ) := by
  have h := correctionSymbol_eighth_derivative_le t
  rwa [m8Real_eq_certificateM8Q, certificateM8_eq_serialized_v1] at h

end AEGIS.RHKreinCorrectionM8BoundV1

#print axioms AEGIS.RHKreinCorrectionM8BoundV1.realAngular_contDiff
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.angular_eighth_norm_le_moment
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.realAngular_eighth_le_moment
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.hatPacket_L1_le
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.hatPacket_weighted_eighth_L1
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.correctionSymbol_eq_columns
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.correctionSymbol_contDiff_eight
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.correctionSymbol_eighth_derivative_le
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.m8Real_eq_certificateM8Q
#print axioms AEGIS.RHKreinCorrectionM8BoundV1.correctionSymbol_eighth_derivative_le_serialized
~~~~~~

## AEGISOverlay.RHKreinCorrectionSymbolV1

Path: `source/AEGISOverlay/RHKreinCorrectionSymbolV1.lean`

Original source lines: 1–17

Full file SHA256: `751ec9c55c7d745d138461e1d7814a89c836eb1ce3caccf83b26287ff488d6c6`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/81bcd289cd6df73901fc97168b00a3b04376eac9/research/rh/m8_kernel_v1/CorrectionSymbolAdapter.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinExplicitCorrectionV1
~~~~~~

## AEGISOverlay.RHKreinExplicitCorrectionV1

Path: `source/AEGISOverlay/RHKreinExplicitCorrectionV1.lean`

Original source lines: 1–622

Full file SHA256: `590251d42663552cfc909ec14a10aba7e58f2a5874ce13d3ef8b8b80527bc174`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinExplicitCorrectionV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinSplineDerivativesV1
import RHKreinGenuineCertificateV1

/-!
# The exact genuine-function correction for the order-19 certificate

The rational coefficients are copied exactly from
`research/rh/krein_order19_v1/certificate.json`. The 199 hat columns are
translated order-two normalized box convolutions multiplied by their width.
The five edge columns are ordinary derivatives of the genuine order-19 spline.
Hermitian reflection and the factors `(-1)^(j/2)/2` give exactly the sine/cosine
convention of the certificate. The pointwise symbol inequality is an explicit
remaining hypothesis, not a numerical premise asserted as a theorem.
-/

open Set MeasureTheory Complex FourierTransform
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinExplicitCorrectionV1

open AEGIS.RHKreinSplineSupportV1 AEGIS.RHKreinSplineContinuityV1
open AEGIS.RHKreinSplineFourierIntegrableV1 AEGIS.RHKreinSplineDerivativesV1

/-- Exact rational hat coefficients in increasing center order. -/
def hatCoefficient : Fin 199 → ℚ :=
  ![-100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -190093321285891/2500000000,
    100000,
    100000,
    100000,
    100000,
    29666418987513/2500000000,
    -100000,
    -100000,
    -100000,
    -117731535372369/2500000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    50425751969473/2000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    515177348963881/10000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    100000,
    100000,
    100000,
    -51422462806047/1000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -116660983646653/1250000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -166526644754763/10000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -118048813499739/1250000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    2953816304371/1000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    7920263226739/1000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -164690278619151/10000000000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    6934524025071/80000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    730856184163993/10000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    414340348739593/10000000000,
    100000,
    100000,
    100000,
    100000,
    378057512105339/10000000000,
    -100000,
    -100000,
    -100000,
    -618999438984917/10000000000,
    100000,
    100000,
    -100000,
    -100000,
    -101839738853771/2500000000,
    100000,
    100000,
    100000,
    100000,
    86995914959651/1000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    100000,
    100000,
    -25574621798421/400000000,
    -100000,
    -469702038657277/10000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -247976924265647/5000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    296561423630109/10000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -373908230082811/5000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -186287944404417/10000000000,
    100000,
    100000,
    100000,
    100000,
    -16872084697291/5000000000,
    -100000,
    -100000,
    -100000,
    200108515493551/10000000000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    -100000,
    -100000,
    730445128203157/10000000000,
    100000,
    100000,
    19841790224691/2000000000,
    -47556077772879/5000000000,
    100000,
    -886028847662807/10000000000,
    -100000,
    -100000,
    110857698784947/10000000000,
    100000,
    100000,
    -431069777588841/5000000000]

/-- Exact rational derivative coefficients in derivative order zero through four. -/
def splineCoefficient : Fin 5 → ℚ :=
  ![234102120892757/5000000000,
    -12240399939171/2500000000,
    -2918648959121/10000000000,
    123578990441/10000000000,
    9711997751/10000000000]

def hatCenter (j : Fin 199) : ℝ := ((j.val : ℝ) + 41) / 50

/-- The explicit angular Fourier correction used by the exact certificate. -/
def correctionSymbol (t : ℝ) : ℝ :=
  (2 / 50) * Real.sinc (t / 100) ^ 2 *
    (∑ j : Fin 199, (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j)) +
  Real.sinc (t / 2000) ^ 19 *
    (∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
      (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
       else Real.sin (t * (1619 / 2000))))

private def reflected (f : ℝ → ℂ) (x : ℝ) : ℂ :=
  f x + (starRingEnd ℂ) (f (-x))

private theorem reflected_continuous {f : ℝ → ℂ} (hf : Continuous f) :
    Continuous (reflected f) :=
  hf.add (continuous_conj.comp (hf.comp continuous_neg))

private theorem reflected_integrable {f : ℝ → ℂ} (hf : Integrable f) :
    Integrable (reflected f) := by
  have hi : Integrable (fun x : ℝ => (starRingEnd ℂ) (f (-x))) := by
    simpa using (Complex.conjLIE.toContinuousLinearMap).integrable_comp hf.comp_neg
  exact hf.add hi

private theorem reflected_hasCompactSupport {f : ℝ → ℂ}
    (hf : HasCompactSupport f) : HasCompactSupport (reflected f) := by
  have hneg : HasCompactSupport (fun x : ℝ => f (-x)) := by
    have h := hf.comp_homeomorph (Homeomorph.neg ℝ)
    simpa [Function.comp_def] using h
  have hconj : HasCompactSupport (fun x : ℝ => (starRingEnd ℂ) (f (-x))) := by
    have h := hneg.comp_left (map_zero (starRingEnd ℂ))
    simpa [Function.comp_def] using h
  unfold reflected
  exact hf.add hconj

private theorem fourier_add (f g : ℝ → ℂ) (hf : Integrable f) (hg : Integrable g)
    (ξ : ℝ) : 𝓕 (fun x => f x + g x) ξ = 𝓕 f ξ + 𝓕 g ξ := by
  exact congrArg (fun F : ℝ → ℂ => F ξ)
    (VectorFourier.fourierIntegral_add (e := Real.fourierChar)
      (L := innerₗ ℝ) Real.continuous_fourierChar continuous_inner hf hg)

private theorem fourier_const_mul (f : ℝ → ℂ) (c : ℂ) (ξ : ℝ) :
    𝓕 (fun x => c * f x) ξ = c * 𝓕 f ξ := by
  rw [Real.fourier_real_eq_integral_exp_smul, Real.fourier_real_eq_integral_exp_smul]
  simp only [smul_eq_mul]
  rw [← integral_const_mul]
  congr 1
  funext x
  ring

private theorem fourier_sum {ι : Type*} [Fintype ι] (f : ι → ℝ → ℂ)
    (hf : ∀ j, Integrable (f j)) (ξ : ℝ) :
    𝓕 (fun x => ∑ j, f j x) ξ = ∑ j, 𝓕 (f j) ξ := by
  simp only [Real.fourier_eq, Finset.smul_sum]
  exact integral_finsetSum _ (fun j _ => (Real.fourierIntegral_convergent_iff ξ).2 (hf j))

private theorem reflected_fourier {f : ℝ → ℂ} (hf : Integrable f) (ξ : ℝ) :
    𝓕 (reflected f) ξ = 𝓕 f ξ + (starRingEnd ℂ) (𝓕 f ξ) := by
  have hi : Integrable (fun x : ℝ => (starRingEnd ℂ) (f (-x))) := by
    simpa using (Complex.conjLIE.toContinuousLinearMap).integrable_comp hf.comp_neg
  change 𝓕 (fun x : ℝ => f x + (starRingEnd ℂ) (f (-x))) ξ =
    𝓕 f ξ + (starRingEnd ℂ) (𝓕 f ξ)
  rw [fourier_add f _ hf hi, AEGIS.RHKreinPairingV13.fourier_conj_neg]

private theorem reflected_fourier_integrable {f : ℝ → ℂ}
    (hf : Integrable f) (hF : Integrable (𝓕 f)) : Integrable (𝓕 (reflected f)) := by
  have hi : Integrable (fun ξ : ℝ => (starRingEnd ℂ) (𝓕 f ξ)) := by
    simpa using (Complex.conjLIE.toContinuousLinearMap).integrable_comp hF
  exact (hF.add hi).congr (Filter.Eventually.of_forall fun ξ => (reflected_fourier hf ξ).symm)

private theorem angular_integrable_iff (f : ℝ → ℂ)
    (hf : Integrable (fun t : ℝ => f (-t / (2 * Real.pi)))) : Integrable f := by
  have hp : -(2 * Real.pi) ≠ 0 := neg_ne_zero.mpr (by positivity)
  have hi := hf.comp_mul_right' hp
  convert hi using 1
  funext ξ
  field_simp [Real.pi_ne_zero]

/-- One ordinary triangular hat represented by convolution of normalized boxes. -/
def positiveHat (j : Fin 199) (x : ℝ) : ℂ :=
  (1 / 50 : ℂ) * splineCore (1 / 50) 1 (x - hatCenter j)

private theorem positiveHat_continuous (j : Fin 199) : Continuous (positiveHat j) := by
  have hc := (splineCore_contDiff (by norm_num : (0 : ℝ) ≤ 1 / 50) 0).continuous
  exact continuous_const.mul (hc.comp (continuous_id.sub continuous_const))

private theorem positiveHat_integrable (j : Fin 199) : Integrable (positiveHat j) :=
  ((splineCore_integrable (1 / 50) 1).comp_sub_right (hatCenter j)).const_mul _

private theorem positiveHat_hasCompactSupport (j : Fin 199) :
    HasCompactSupport (positiveHat j) := by
  have hb := splineCore_hasCompactSupport (1 / 50) 1
  have ht : HasCompactSupport
      (fun x : ℝ => splineCore (1 / 50) 1 (x - hatCenter j)) := by
    have h := hb.comp_homeomorph (Homeomorph.addRight (-hatCenter j))
    simpa [Function.comp_def, sub_eq_add_neg] using h
  unfold positiveHat
  exact ht.mul_left

private theorem positiveHat_fourier (j : Fin 199) (t : ℝ) :
    𝓕 (positiveHat j) (-t / (2 * Real.pi)) =
      (1 / 50 : ℂ) * Complex.exp (((t * hatCenter j : ℝ) : ℂ) * Complex.I) *
        (Real.sinc (t / 100) : ℂ) ^ 2 := by
  unfold positiveHat
  rw [fourier_const_mul, fourier_translate_angular,
    splineCore_fourier (by norm_num : (0 : ℝ) < 1 / 50)]
  rw [show (1 / 50 : ℝ) * t / 2 = t / 100 by ring]
  ring

private theorem positiveHat_fourier_integrable (j : Fin 199) :
    Integrable (𝓕 (positiveHat j)) := by
  apply angular_integrable_iff
  have hs : Integrable (fun t : ℝ => (Real.sinc (t / 100) : ℂ) ^ 2) := by
    simpa only [div_eq_mul_inv] using
      (sinc_pow_integrable 2 (by norm_num)).comp_mul_right' (by norm_num : (100 : ℝ)⁻¹ ≠ 0)
  have he : Integrable (fun t : ℝ =>
      Complex.exp (((t * hatCenter j : ℝ) : ℂ) * Complex.I) *
        (Real.sinc (t / 100) : ℂ) ^ 2) := by
    refine hs.norm.mono' ?_ ?_
    · have hc : Continuous (fun t : ℝ =>
          Complex.exp (((t * hatCenter j : ℝ) : ℂ) * Complex.I) *
            (Real.sinc (t / 100) : ℂ) ^ 2) := by fun_prop
      exact hc.aestronglyMeasurable
    · exact Filter.Eventually.of_forall fun t => by simp [Complex.norm_exp]
  exact (he.const_mul (1 / 50 : ℂ)).congr (Filter.Eventually.of_forall fun t => by
    simpa [mul_assoc] using (positiveHat_fourier j t).symm)

private theorem positiveHat_zero (j : Fin 199) {x : ℝ} (hx : |x| < 4 / 5) :
    positiveHat j x = 0 := by
  have hz : splineCore (1 / 50) 1 (x - hatCenter j) = 0 := by
    by_contra hn
    have hs := (splineCore_support (1 / 50) 1 (x - hatCenter j) hn).1
    have hj : (0 : ℝ) ≤ j.val := Nat.cast_nonneg _
    dsimp [hatCenter] at hs
    norm_num at hs
    linarith [le_abs_self x]
  have hz' : splineCore (50⁻¹ : ℝ) 1 (x - hatCenter j) = 0 := by
    simpa only [one_div] using hz
  simp [positiveHat, one_div, hz']

/-- The Hermitian pair of triangular hats centered at opposite locations. -/
def hatColumn (j : Fin 199) : ℝ → ℂ := reflected (positiveHat j)

/-- The normalized genuine derivative column, including its parity sign. -/
def splineColumn (j : Fin 5) (x : ℝ) : ℂ :=
  ((-1 : ℂ) ^ (j.val / 2) / 2) *
    reflected (deriv^[j.val] (spline19 (4 / 5) (1 / 1000))) x

private theorem edge_integrable (j : Fin 5) :
    Integrable (deriv^[j.val] (spline19 (4 / 5) (1 / 1000))) :=
  spline19_derivative_integrable _ (by norm_num) _ (by omega)

private theorem edge_zero (j : Fin 5) {x : ℝ} (hx : |x| < 4 / 5) :
    deriv^[j.val] (spline19 (4 / 5) (1 / 1000)) x = 0 := by
  by_contra hn
  have hs := (spline19_derivative_support (4 / 5) (1 / 1000) j.val
    (subset_closure hn)).1
  linarith [le_abs_self x]

private theorem hatColumn_fourier_re (j : Fin 199) (t : ℝ) :
    (𝓕 (hatColumn j) (-t / (2 * Real.pi))).re =
      (2 / 50) * Real.sinc (t / 100) ^ 2 * Real.cos (t * hatCenter j) := by
  rw [hatColumn, reflected_fourier (positiveHat_integrable j), positiveHat_fourier]
  norm_num [← Complex.ofReal_pow, Complex.add_re, Complex.conj_re, Complex.mul_re,
    Complex.mul_im, Complex.exp_re]
  ring

private theorem splineColumn_fourier_re (j : Fin 5) (t : ℝ) :
    (𝓕 (splineColumn j) (-t / (2 * Real.pi))).re =
      Real.sinc (t / 2000) ^ 19 * t ^ j.val *
        (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
         else Real.sin (t * (1619 / 2000))) := by
  unfold splineColumn
  rw [fourier_const_mul, reflected_fourier (edge_integrable j),
    spline19_derivative_fourier _ (by norm_num) _ (by omega)]
  have hc : (4 / 5 : ℝ) + 19 * (1 / 1000) / 2 = 1619 / 2000 := by norm_num
  have hs : (1 / 1000 : ℝ) * t / 2 = t / 2000 := by ring
  rw [hc, hs]
  have he (z : ℂ) (r : ℝ) :
      (((-1 : ℂ) ^ (j.val / 2) / 2) * (z * (r : ℂ) ^ 19 +
        (starRingEnd ℂ) (z * (r : ℂ) ^ 19))).re =
      r ^ 19 * (((-1 : ℂ) ^ (j.val / 2) / 2) *
        (z + (starRingEnd ℂ) z)).re := by
    have hz : ((-1 : ℂ) ^ (j.val / 2) / 2) *
        (z * (r : ℂ) ^ 19 + (starRingEnd ℂ) (z * (r : ℂ) ^ 19)) =
        ((r ^ 19 : ℝ) : ℂ) *
          (((-1 : ℂ) ^ (j.val / 2) / 2) * (z + (starRingEnd ℂ) z)) := by
      simp only [map_mul, map_pow, Complex.conj_ofReal]
      push_cast
      ring
    calc
      _ = (((r ^ 19 : ℝ) : ℂ) *
          (((-1 : ℂ) ^ (j.val / 2) / 2) *
            (z + (starRingEnd ℂ) z))).re := congrArg Complex.re hz
      _ = _ := by
        simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
          zero_mul, sub_zero]
  rw [he, certificate_reflected_derivative_parity]
  ring

/-- A finite linear combination of genuine compactly supported functions. -/
def correction (x : ℝ) : ℂ :=
  (∑ j : Fin 199, ((hatCoefficient j : ℝ) : ℂ) * hatColumn j x) +
    ∑ j : Fin 5, ((splineCoefficient j : ℝ) : ℂ) * splineColumn j x

private theorem hatColumn_integrable (j : Fin 199) : Integrable (hatColumn j) :=
  reflected_integrable (positiveHat_integrable j)

private theorem splineColumn_integrable (j : Fin 5) : Integrable (splineColumn j) :=
  (reflected_integrable (edge_integrable j)).const_mul _

private theorem hatColumn_hasCompactSupport (j : Fin 199) :
    HasCompactSupport (hatColumn j) :=
  reflected_hasCompactSupport (positiveHat_hasCompactSupport j)

private theorem edge_hasCompactSupport (j : Fin 5) :
    HasCompactSupport (deriv^[j.val] (spline19 (4 / 5) (1 / 1000))) := by
  apply HasCompactSupport.intro
    (K := Set.Icc (4 / 5) (4 / 5 + 19 * (1 / 1000))) isCompact_Icc
  intro x hx
  by_contra hn
  exact hx (spline19_derivative_support (4 / 5) (1 / 1000) j.val
    (subset_closure hn))

private theorem splineColumn_hasCompactSupport (j : Fin 5) :
    HasCompactSupport (splineColumn j) := by
  unfold splineColumn
  exact (reflected_hasCompactSupport (edge_hasCompactSupport j)).mul_left

set_option maxHeartbeats 2000000 in
private theorem finiteSum_hasCompactSupport {ι : Type*} [Fintype ι]
    (f : ι → ℝ → ℂ) (hf : ∀ i, HasCompactSupport (f i)) :
    HasCompactSupport (fun x : ℝ => ∑ i, f i x) := by
  classical
  rw [← Finset.sum_fn]
  exact (HasCompactSupport.addSubmonoid ℝ ℂ).sum_mem (fun i _ => hf i)

/-- The correction is continuous despite containing derivative columns. -/
theorem correction_continuous : Continuous correction := by
  have hh (j : Fin 199) : Continuous (hatColumn j) :=
    reflected_continuous (positiveHat_continuous j)
  have hs (j : Fin 5) : Continuous (splineColumn j) := by
    have hc := (spline19_derivative_contDiff (4 / 5)
      (by norm_num : (0 : ℝ) ≤ 1 / 1000) j.val (by omega)).continuous
    exact continuous_const.mul (reflected_continuous hc)
  unfold correction
  exact (continuous_finsetSum _ fun j _ => continuous_const.mul (hh j)).add
    (continuous_finsetSum _ fun j _ => continuous_const.mul (hs j))

/-- Lebesgue integrability of the concrete correction. -/
theorem correction_integrable : Integrable correction := by
  exact (integrable_finsetSum _ fun j _ =>
    (hatColumn_integrable j).const_mul ((hatCoefficient j : ℝ) : ℂ)).add
    (integrable_finsetSum _ fun j _ =>
      (splineColumn_integrable j).const_mul ((splineCoefficient j : ℝ) : ℂ))

set_option maxHeartbeats 2000000 in
/-- The explicit correction is genuinely compactly supported. -/
theorem correction_hasCompactSupport : HasCompactSupport correction := by
  have hh : HasCompactSupport (fun x : ℝ =>
      ∑ j : Fin 199, ((hatCoefficient j : ℝ) : ℂ) * hatColumn j x) := by
    apply finiteSum_hasCompactSupport
    intro j
    exact (hatColumn_hasCompactSupport j).mul_left
  have hs : HasCompactSupport (fun x : ℝ =>
      ∑ j : Fin 5, ((splineCoefficient j : ℝ) : ℂ) * splineColumn j x) := by
    apply finiteSum_hasCompactSupport
    intro j
    exact (splineColumn_hasCompactSupport j).mul_left
  unfold correction
  exact hh.add hs

/-- The correction vanishes on the entire forbidden window. -/
theorem correction_zero_in_window (x : ℝ) (hx : |x| < 4 / 5) : correction x = 0 := by
  have hn : |-x| < 4 / 5 := by simpa using hx
  have hh (j : Fin 199) : hatColumn j x = 0 := by
    simp [hatColumn, reflected, positiveHat_zero j hx, positiveHat_zero j hn]
  have hs (j : Fin 5) : splineColumn j x = 0 := by
    have hxp :
        deriv^[j.val] (spline19 (4 / 5) (1000⁻¹ : ℝ)) x = 0 := by
      simpa only [one_div] using (edge_zero j hx)
    have hxn :
        deriv^[j.val] (spline19 (4 / 5) (1000⁻¹ : ℝ)) (-x) = 0 := by
      simpa only [one_div] using (edge_zero j hn)
    unfold splineColumn reflected
    simp only [one_div]
    rw [hxp, hxn]
    simp
  simp [correction, hh, hs]

private theorem correction_fourier (ξ : ℝ) :
    𝓕 correction ξ =
      (∑ j : Fin 199, ((hatCoefficient j : ℝ) : ℂ) * 𝓕 (hatColumn j) ξ) +
        ∑ j : Fin 5, ((splineCoefficient j : ℝ) : ℂ) * 𝓕 (splineColumn j) ξ := by
  unfold correction
  rw [fourier_add _ _ (integrable_finsetSum _ fun j _ =>
    (hatColumn_integrable j).const_mul _) (integrable_finsetSum _ fun j _ =>
      (splineColumn_integrable j).const_mul _),
    fourier_sum _ (fun j => (hatColumn_integrable j).const_mul _),
    fourier_sum _ (fun j => (splineColumn_integrable j).const_mul _)]
  simp only [fourier_const_mul]

/-- The actual Fourier transform of the correction is integrable. -/
theorem correction_fourier_integrable : Integrable (𝓕 correction) := by
  have hh (j : Fin 199) : Integrable (𝓕 (hatColumn j)) :=
    reflected_fourier_integrable (positiveHat_integrable j) (positiveHat_fourier_integrable j)
  have hs (j : Fin 5) : Integrable (𝓕 (splineColumn j)) := by
    have hi := reflected_fourier_integrable (edge_integrable j)
      (spline19_derivative_fourier_integrable (4 / 5)
        (by norm_num : (0 : ℝ) < 1 / 1000) j.val (by omega))
    exact (hi.const_mul _).congr (Filter.Eventually.of_forall fun ξ => by
      exact (fourier_const_mul _ _ ξ).symm)
  exact ((integrable_finsetSum _ fun j _ => (hh j).const_mul ((hatCoefficient j : ℝ) : ℂ)).add
    (integrable_finsetSum _ fun j _ => (hs j).const_mul ((splineCoefficient j : ℝ) : ℂ))).congr
      (Filter.Eventually.of_forall fun ξ => (correction_fourier ξ).symm)

/-- The exact analytic expression is propositionally bound to the actual
Mathlib Fourier transform, including all reflection and parity factors. -/
theorem correction_fourier_re (t : ℝ) :
    (𝓕 correction (-t / (2 * Real.pi))).re = correctionSymbol t := by
  rw [correction_fourier, Complex.add_re, Complex.re_sum, Complex.re_sum]
  have hh (j : Fin 199) :
      (((hatCoefficient j : ℝ) : ℂ) * 𝓕 (hatColumn j) (-t / (2 * Real.pi))).re =
      (hatCoefficient j : ℝ) * ((2 / 50) * Real.sinc (t / 100) ^ 2 *
        Real.cos (t * hatCenter j)) := by
    simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
    rw [hatColumn_fourier_re]
  have hs (j : Fin 5) :
      (((splineCoefficient j : ℝ) : ℂ) * 𝓕 (splineColumn j) (-t / (2 * Real.pi))).re =
      (splineCoefficient j : ℝ) * (Real.sinc (t / 2000) ^ 19 * t ^ j.val *
        (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
         else Real.sin (t * (1619 / 2000)))) := by
    simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
    rw [splineColumn_fourier_re]
  simp only [hh, hs, correctionSymbol, Finset.mul_sum]
  congr 1 <;> apply Finset.sum_congr rfl <;> intro j _ <;> ring

/-- This proposition is precisely the remaining pointwise analytic certificate. -/
def PointwiseCertificate : Prop :=
  ∀ t : ℝ, 0 ≤ (t ^ 2 + 1 / 4) ^ 2 *
    (AEGIS.RHKreinPrimeSymbolV1.symbol t - 1 / 16) + correctionSymbol t

/-- The explicit certificate implies a `1/16` margin for every actual moment-zero
packet with logarithmic half-width at most `2/5`. -/
theorem actual_zero_quadratic_margin (hcert : PointwiseCertificate)
    (g : WeilCompactSmoothGV1) (r a : ℝ) (hr0 : 0 ≤ r) (hr : r ≤ 2 / 5)
    (hw : AEGIS.RHDyadicDiagonalV13.HalfWidthAt g r a)
    (hm : WeilMomentConditionsV1 g) :
    (1 / 16) * AEGIS.WeilDisjointEnergyV2.energy g.1 ≤
      (∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho).re := by
  have hlog : 1 < Real.log 3 := by
    apply (Real.lt_log_iff_exp_lt (by norm_num : (0 : ℝ) < 3)).2
    exact lt_trans Real.exp_one_lt_d9 (by norm_num)
  apply AEGIS.RHKreinGenuineCertificateV1.zero_quadratic_margin_from_genuine_certificate
    g r a (1 / 16) hr0 hw (by linarith) hm correction
    correction_continuous correction_integrable correction_fourier_integrable
  · intro u hu
    exact correction_zero_in_window u (by linarith)
  · intro t
    rw [correction_fourier_re]
    exact hcert t

end AEGIS.RHKreinExplicitCorrectionV1

#print axioms AEGIS.RHKreinExplicitCorrectionV1.correction_continuous
#print axioms AEGIS.RHKreinExplicitCorrectionV1.correction_integrable
#print axioms AEGIS.RHKreinExplicitCorrectionV1.correction_hasCompactSupport
#print axioms AEGIS.RHKreinExplicitCorrectionV1.correction_zero_in_window
#print axioms AEGIS.RHKreinExplicitCorrectionV1.correction_fourier_integrable
#print axioms AEGIS.RHKreinExplicitCorrectionV1.correction_fourier_re
#print axioms AEGIS.RHKreinExplicitCorrectionV1.actual_zero_quadratic_margin
~~~~~~

## AEGISOverlay.RHKreinSplineDerivativesV1

Path: `source/AEGISOverlay/RHKreinSplineDerivativesV1.lean`

Original source lines: 1–153

Full file SHA256: `9c87e11940c372114de1a3948b3f0ff83feba1b5b54a0bcc832abcb97eba05e7`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinSplineDerivativesV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinSplineContinuityV1
import AEGISOverlay.RHKreinSplineFourierIntegrableV1
import Mathlib.Analysis.Calculus.Deriv.Support
import Mathlib.Analysis.Fourier.FourierTransformDeriv

/-!
# Genuine derivative columns for the order-19 Krein spline

The concrete spline is C17. Every derivative through order seventeen is
continuous, compactly supported on the same interval, integrable, and has
an integrable Fourier transform. Its exact angular Fourier multiplier is
`(-i*t)^j`. In particular these statements cover all five derivative columns
used in the rational certificate. No distributional derivative is used.
-/

open Set MeasureTheory FourierTransform

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSplineDerivativesV1

open AEGIS.RHKreinSplineSupportV1 AEGIS.RHKreinSplineContinuityV1
open AEGIS.RHKreinSplineFourierIntegrableV1

theorem spline19_derivative_contDiff (L : ℝ) {h : ℝ} (hh : 0 ≤ h)
    (j : ℕ) (hj : j ≤ 17) :
    ContDiff ℝ (17 - j : ℕ) (deriv^[j] (spline19 L h)) := by
  apply ContDiff.iterate_deriv' (17 - j) j
  simpa [Nat.sub_add_cancel hj] using spline19_contDiff L hh

private theorem compact_derivative_iterate (f : ℝ → ℂ) (hf : HasCompactSupport f) (j : ℕ) :
    HasCompactSupport (deriv^[j] f) := by
  induction j with
  | zero => exact hf
  | succ j ih => simpa only [Function.iterate_succ_apply'] using ih.deriv

private theorem tsupport_derivative_iterate (f : ℝ → ℂ) (j : ℕ) :
    tsupport (deriv^[j] f) ⊆ tsupport f := by
  induction j with
  | zero => exact Subset.rfl
  | succ j ih =>
    simpa only [Function.iterate_succ_apply'] using tsupport_deriv_subset.trans ih

/-- Every ordinary derivative remains supported on the same closed interval. -/
theorem spline19_derivative_support (L h : ℝ) (j : ℕ) :
    tsupport (deriv^[j] (spline19 L h)) ⊆ Icc L (L + 19 * h) := by
  apply (tsupport_derivative_iterate (spline19 L h) j).trans
  exact closure_minimal (fun x hx => spline19_support L h x hx) isClosed_Icc

/-- The certificate's derivative columns are integrable genuine functions. -/
theorem spline19_derivative_integrable (L : ℝ) {h : ℝ} (hh : 0 ≤ h)
    (j : ℕ) (hj : j ≤ 17) :
    Integrable (deriv^[j] (spline19 L h)) :=
  (spline19_derivative_contDiff L hh j hj).continuous.integrable_of_hasCompactSupport
    (compact_derivative_iterate (spline19 L h) (spline19_hasCompactSupport L h) j)

/-- The exact angular Fourier formula for the actual ordinary derivatives. -/
theorem spline19_derivative_fourier (L : ℝ) {h : ℝ} (hh : 0 < h)
    (j : ℕ) (hj : j ≤ 17) (t : ℝ) :
    𝓕 (deriv^[j] (spline19 L h)) (-t / (2 * Real.pi)) =
      (-Complex.I * (t : ℂ)) ^ j *
        Complex.exp (((t * (L + 19 * h / 2) : ℝ) : ℂ) * Complex.I) *
          (Real.sinc (h * t / 2) : ℂ) ^ 19 := by
  revert hj
  induction j with
  | zero =>
    intro _
    simpa only [Function.iterate_zero_apply, pow_zero, one_mul] using spline19_fourier L hh t
  | succ j ih =>
    intro hj
    have hj' : j ≤ 17 := by omega
    have hc1 : ContDiff ℝ 1 (deriv^[j] (spline19 L h)) :=
      (spline19_derivative_contDiff L hh.le j hj').of_le (by
        exact_mod_cast (show 1 ≤ 17 - j by omega))
    have hd : Differentiable ℝ (deriv^[j] (spline19 L h)) :=
      (contDiff_one_iff_deriv.mp hc1).1
    have hi := spline19_derivative_integrable L hh.le j hj'
    have hi' : Integrable (deriv (deriv^[j] (spline19 L h))) := by
      simpa only [Function.iterate_succ_apply'] using
        spline19_derivative_integrable L hh.le (j + 1) hj
    rw [Function.iterate_succ_apply', Real.fourier_deriv hi hd hi']
    dsimp only
    rw [ih hj']
    simp only [smul_eq_mul]
    have hr : 2 * Real.pi * (-t / (2 * Real.pi)) = -t := by
      field_simp [Real.pi_ne_zero]
    have hc : (2 * (Real.pi : ℂ) * Complex.I * ((-t / (2 * Real.pi) : ℝ) : ℂ)) =
        -Complex.I * (t : ℂ) := by
      calc
        (2 * (Real.pi : ℂ) * Complex.I * ((-t / (2 * Real.pi) : ℝ) : ℂ)) =
            ((2 * Real.pi * (-t / (2 * Real.pi)) : ℝ) : ℂ) * Complex.I := by
          push_cast
          ring
        _ = (-t : ℝ) * Complex.I := by rw [hr]
        _ = -Complex.I * (t : ℂ) := by push_cast; ring
    rw [hc, pow_succ]
    ring

/-- All derivative columns consumed by the certificate have integrable Fourier
transforms; the stronger range `j ≤ 17` follows from the same sinc bound. -/
theorem spline19_derivative_fourier_integrable (L : ℝ) {h : ℝ} (hh : 0 < h)
    (j : ℕ) (hj : j ≤ 17) :
    Integrable (𝓕 (deriv^[j] (spline19 L h))) := by
  have hsum : j + (19 - j) = 19 := by omega
  have hs : Integrable (fun t : ℝ => (t : ℂ) ^ j * (Real.sinc (h * t / 2) : ℂ) ^ 19) := by
    have hh2 : h / 2 ≠ 0 := by positivity
    simpa only [hsum, div_mul_eq_mul_div] using
      weighted_sinc_scaled_integrable (h / 2) hh2 j (19 - j) (by omega)
  have he : (fun t : ℝ => 𝓕 (deriv^[j] (spline19 L h)) (-t / (2 * Real.pi))) =
      (fun t : ℝ => (-Complex.I * (t : ℂ)) ^ j *
        Complex.exp (((t * (L + 19 * h / 2) : ℝ) : ℂ) * Complex.I) *
          (Real.sinc (h * t / 2) : ℂ) ^ 19) :=
    funext (spline19_derivative_fourier L hh j hj)
  have hi : Integrable (fun t : ℝ =>
      𝓕 (deriv^[j] (spline19 L h)) (-t / (2 * Real.pi))) := by
    rw [he]
    refine hs.norm.mono' ?_ ?_
    · have hc : Continuous (fun t : ℝ => (-Complex.I * (t : ℂ)) ^ j *
          Complex.exp (((t * (L + 19 * h / 2) : ℝ) : ℂ) * Complex.I) *
            (Real.sinc (h * t / 2) : ℂ) ^ 19) := by fun_prop
      exact hc.aestronglyMeasurable
    · exact Filter.Eventually.of_forall (fun t => by
        simp [norm_pow, Complex.norm_exp])
  have hp : -(2 * Real.pi) ≠ 0 := neg_ne_zero.mpr (by positivity)
  have hi' := hi.comp_mul_right' hp
  convert hi' using 1
  funext ξ
  field_simp [Real.pi_ne_zero]

end AEGIS.RHKreinSplineDerivativesV1

#print axioms AEGIS.RHKreinSplineDerivativesV1.spline19_derivative_contDiff
#print axioms AEGIS.RHKreinSplineDerivativesV1.spline19_derivative_support
#print axioms AEGIS.RHKreinSplineDerivativesV1.spline19_derivative_integrable
#print axioms AEGIS.RHKreinSplineDerivativesV1.spline19_derivative_fourier
#print axioms AEGIS.RHKreinSplineDerivativesV1.spline19_derivative_fourier_integrable
~~~~~~

## AEGISOverlay.RHKreinSplineContinuityV1

Path: `source/AEGISOverlay/RHKreinSplineContinuityV1.lean`

Original source lines: 1–133

Full file SHA256: `43f19e594e9e3c661530042fd4201ac5ee006ffeb8eec0a421bfb459f729b64f`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinSplineContinuityV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinSplineSupportV1
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Analysis.Calculus.ContDiff.Deriv

/-!
# Continuity of the genuine order-19 spline

Convolution by a normalized interval is a difference of two primitives of
an integrable function. This proves continuity of the concrete spline
without assuming continuity of the interval indicator.
-/

open Set MeasureTheory FourierTransform Convolution

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSplineContinuityV1

open AEGIS.RHKreinSplineSupportV1 AEGIS.RHBoxFourierComplementarityV1

/-- A convolution with the normalized box is its moving interval average. -/
theorem convolution_normalizedBox (f : ℝ → ℂ) {h : ℝ} (hh : 0 ≤ h) (x : ℝ) :
    (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) x =
      (h : ℂ)⁻¹ * ∫ u in (x - h / 2)..(x + h / 2), f u := by
  rw [convolution_def]
  simp only [ContinuousLinearMap.mul_apply']
  have he : (fun u => f u * normalizedBox h (x - u)) =
      (fun u => (h : ℂ)⁻¹ * (Ico (x - h / 2) (x + h / 2)).indicator f u) := by
    funext u
    by_cases hu : u ∈ Ico (x - h / 2) (x + h / 2)
    · have hv : x - u ∈ Ioc (-(h / 2)) (h / 2) := by
        constructor <;> linarith [hu.1, hu.2]
      simp [normalizedBox, boxProfile, hu, hv, mul_comm]
    · have hv : x - u ∉ Ioc (-(h / 2)) (h / 2) := by
        intro hv
        exact hu ⟨by linarith [hv.2], by linarith [hv.1]⟩
      simp [normalizedBox, boxProfile, hu, hv]
  rw [he, integral_const_mul, integral_indicator measurableSet_Ico,
    integral_Ico_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le (by linarith : x - h / 2 ≤ x + h / 2)]

/-- A single averaging step sends every integrable function to a continuous function. -/
theorem continuous_convolution_normalizedBox (f : ℝ → ℂ) (hf : Integrable f)
    {h : ℝ} (hh : 0 ≤ h) :
    Continuous (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) := by
  have he : (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) =
      (fun x => (h : ℂ)⁻¹ *
        ((∫ u in (0 : ℝ)..(x + h / 2), f u) -
          ∫ u in (0 : ℝ)..(x - h / 2), f u)) := by
    funext x
    rw [convolution_normalizedBox f hh x,
      intervalIntegral.integral_interval_sub_left hf.intervalIntegrable hf.intervalIntegrable]
  rw [he]
  exact continuous_const.mul
    (((hf.continuous_primitive 0).comp (continuous_id.add_const (h / 2))).sub
      ((hf.continuous_primitive 0).comp (continuous_id.sub continuous_const)))

/-- The actual order-19 spline satisfies the continuity hypothesis of Krein pairing. -/
theorem spline19_continuous (L : ℝ) {h : ℝ} (hh : 0 ≤ h) :
    Continuous (spline19 L h) := by
  have hc : Continuous (splineCore h 18) :=
    continuous_convolution_normalizedBox (splineCore h 17) (splineCore_integrable h 17) hh
  exact hc.comp (continuous_id.sub continuous_const)

/-- An interval primitive gains one finite order of differentiability. -/
theorem primitive_contDiff (n : ℕ) (f : ℝ → ℂ) (hf : ContDiff ℝ n f) :
    ContDiff ℝ (n + 1 : ℕ) (fun x => ∫ u in (0 : ℝ)..x, f u) := by
  rw [show ((n + 1 : ℕ) : WithTop ℕ∞) = n + 1 from rfl]
  refine contDiff_succ_iff_deriv.2
    ⟨intervalIntegral.differentiable_integral_of_continuous hf.continuous, by simp, ?_⟩
  have he : deriv (fun x => ∫ u in (0 : ℝ)..x, f u) = f := by
    funext x
    exact (hf.continuous.integral_hasStrictDerivAt 0 x).hasDerivAt.deriv
  rw [he]
  exact hf

/-- Every box averaging step gains one finite derivative. -/
theorem contDiff_convolution_normalizedBox (n : ℕ) (f : ℝ → ℂ)
    (hf : Integrable f) (hc : ContDiff ℝ n f) {h : ℝ} (hh : 0 ≤ h) :
    ContDiff ℝ (n + 1 : ℕ) (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) := by
  have he : (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) =
      (fun x => (h : ℂ)⁻¹ *
        ((∫ u in (0 : ℝ)..(x + h / 2), f u) -
          ∫ u in (0 : ℝ)..(x - h / 2), f u)) := by
    funext x
    rw [convolution_normalizedBox f hh x,
      intervalIntegral.integral_interval_sub_left hf.intervalIntegrable hf.intervalIntegrable]
  rw [he]
  exact contDiff_const.mul
    (((primitive_contDiff n f hc).comp (contDiff_id.add contDiff_const)).sub
      ((primitive_contDiff n f hc).comp (contDiff_id.sub contDiff_const)))

/-- The convolution of `n+2` boxes has `n` continuous derivatives. -/
theorem splineCore_contDiff {h : ℝ} (hh : 0 ≤ h) (n : ℕ) :
    ContDiff ℝ n (splineCore h (n + 1)) := by
  induction n with
  | zero =>
    exact contDiff_zero.2
      (continuous_convolution_normalizedBox (splineCore h 0) (splineCore_integrable h 0) hh)
  | succ n ih =>
    exact contDiff_convolution_normalizedBox n (splineCore h (n + 1))
      (splineCore_integrable h (n + 1)) ih hh

/-- The actual order-19 spline is `C^17`; it is not asserted to be smooth. -/
theorem spline19_contDiff (L : ℝ) {h : ℝ} (hh : 0 ≤ h) :
    ContDiff ℝ 17 (spline19 L h) := by
  have hc : ContDiff ℝ 17 (splineCore h 18) := splineCore_contDiff hh 17
  exact hc.comp (contDiff_id.sub contDiff_const)

end AEGIS.RHKreinSplineContinuityV1

#print axioms AEGIS.RHKreinSplineContinuityV1.convolution_normalizedBox
#print axioms AEGIS.RHKreinSplineContinuityV1.continuous_convolution_normalizedBox
#print axioms AEGIS.RHKreinSplineContinuityV1.spline19_continuous
#print axioms AEGIS.RHKreinSplineContinuityV1.spline19_contDiff
~~~~~~

## AEGISOverlay.RHKreinSplineSupportV1

Path: `source/AEGISOverlay/RHKreinSplineSupportV1.lean`

Original source lines: 1–224

Full file SHA256: `515ed3c9a3d2b57e9548b489ac17cdd407210e6585e584cedefa1e5cd042542d`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinSplineSupportV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHBoxFourierComplementarityV1
import Mathlib.Analysis.Fourier.Convolution

/-!
# The genuine convolution spline used in the Krein certificate

The order-19 cardinal spline is the convolution of nineteen normalized
interval indicators. This module proves its integrability, exact support
enclosure, and actual Mathlib Fourier transform at angular frequency.
The positive translated copy is supported on `[L, L + 19*h]` and its transform
is `exp(i*t*(L + 19*h/2)) * sinc(h*t/2)^19`.

These statements bind the certificate's spline convention to a genuine
function. They do not assert the differentiability or certificate inequality.
-/

open Set MeasureTheory FourierTransform Convolution
open scoped Pointwise

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSplineSupportV1

open AEGIS.RHBoxFourierComplementarityV1

/-- The interval density with integral one when `h > 0`. -/
def normalizedBox (h : ℝ) (x : ℝ) : ℂ :=
  (h : ℂ)⁻¹ * boxProfile (h / 2) x

/-- `splineCore h n` has order `n+1`, so order nineteen is index eighteen. -/
def splineCore (h : ℝ) : ℕ → ℝ → ℂ
  | 0 => normalizedBox h
  | n + 1 => splineCore h n ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h

/-- The positive copy appearing in the rational order-19 certificate. -/
def spline19 (L h : ℝ) (x : ℝ) : ℂ :=
  splineCore h 18 (x - (L + 19 * h / 2))

theorem normalizedBox_integrable (h : ℝ) : Integrable (normalizedBox h) := by
  have hi : IntegrableOn (fun _ : ℝ => (1 : ℂ)) (Icc (-(h / 2)) (h / 2)) :=
    integrableOn_const isCompact_Icc.measure_ne_top
  have hb : Integrable (boxProfile (h / 2)) := by
    exact (hi.mono_set Ioc_subset_Icc_self).integrable_indicator measurableSet_Ioc
  exact hb.const_mul _

theorem splineCore_integrable (h : ℝ) (n : ℕ) : Integrable (splineCore h n) := by
  induction n with
  | zero => exact normalizedBox_integrable h
  | succ n ih => exact ih.integrable_convolution _ (normalizedBox_integrable h)

theorem normalizedBox_support (h x : ℝ) (hx : normalizedBox h x ≠ 0) :
    x ∈ Icc (-(h / 2)) (h / 2) := by
  have hb : boxProfile (h / 2) x ≠ 0 := by
    intro hz
    exact hx (by simp [normalizedBox, hz])
  have hx' : x ∈ Ioc (-(h / 2)) (h / 2) := by
    by_contra hn
    exact hb (by simp [boxProfile, hn])
  exact ⟨hx'.1.le, hx'.2⟩

theorem splineCore_support (h : ℝ) (n : ℕ) (x : ℝ) (hx : splineCore h n x ≠ 0) :
    x ∈ Icc (-((n : ℝ) + 1) * h / 2) (((n : ℝ) + 1) * h / 2) := by
  induction n generalizing x with
  | zero =>
    simpa only [Nat.cast_zero, zero_add, neg_mul, one_mul, neg_div] using
      normalizedBox_support h x hx
  | succ n ih =>
    have hs := support_convolution_subset (ContinuousLinearMap.mul ℂ ℂ)
      (f := splineCore h n) (g := normalizedBox h) hx
    rcases hs with ⟨y, hy, z, hz, rfl⟩
    have hy' := ih y hy
    have hz' := normalizedBox_support h z hz
    simp only [Nat.cast_add, Nat.cast_one]
    constructor <;> nlinarith [hy'.1, hy'.2, hz'.1, hz'.2]

/-- Every finite normalized-box convolution has compact support in its
explicit interval enclosure. -/
theorem splineCore_hasCompactSupport (h : ℝ) (n : ℕ) :
    HasCompactSupport (splineCore h n) := by
  apply HasCompactSupport.intro
    (K := Icc (-((n : ℝ) + 1) * h / 2) (((n : ℝ) + 1) * h / 2))
    isCompact_Icc
  intro x hx
  by_contra hn
  exact hx (splineCore_support h n x hn)

theorem spline19_support (L h x : ℝ) (hx : spline19 L h x ≠ 0) :
    x ∈ Icc L (L + 19 * h) := by
  have hs := splineCore_support h 18 (x - (L + 19 * h / 2)) hx
  norm_num at hs
  constructor <;> linarith [hs.1, hs.2]

theorem spline19_integrable (L h : ℝ) : Integrable (spline19 L h) := by
  exact (splineCore_integrable h 18).comp_sub_right (L + 19 * h / 2)

theorem spline19_hasCompactSupport (L h : ℝ) : HasCompactSupport (spline19 L h) := by
  apply HasCompactSupport.intro (K := Icc L (L + 19 * h)) isCompact_Icc
  intro x hx
  by_contra hn
  exact hx (spline19_support L h x hn)

private theorem fourier_const_mul (f : ℝ → ℂ) (c : ℂ) (ξ : ℝ) :
    𝓕 (fun x => c * f x) ξ = c * 𝓕 f ξ := by
  rw [Real.fourier_real_eq_integral_exp_smul, Real.fourier_real_eq_integral_exp_smul]
  simp only [smul_eq_mul]
  rw [← integral_const_mul]
  congr 1
  funext x
  ring

theorem normalizedBox_fourier {h : ℝ} (hh : 0 < h) (t : ℝ) :
    𝓕 (normalizedBox h) (-t / (2 * Real.pi)) = (Real.sinc (h * t / 2) : ℂ) := by
  unfold normalizedBox
  rw [fourier_const_mul, fourier_boxProfile_scaled (by positivity : 0 ≤ h / 2)]
  have hh' : (h : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hh.ne'
  rw [show h / 2 * t = h * t / 2 by ring]
  push_cast
  field_simp [hh']

theorem splineCore_fourier {h : ℝ} (hh : 0 < h) (n : ℕ) (t : ℝ) :
    𝓕 (splineCore h n) (-t / (2 * Real.pi)) =
      (Real.sinc (h * t / 2) : ℂ) ^ (n + 1) := by
  induction n with
  | zero => simpa only [splineCore, zero_add, pow_one] using normalizedBox_fourier hh t
  | succ n ih =>
    rw [splineCore, Real.fourier_mul_convolution_eq (splineCore_integrable h n)
      (normalizedBox_integrable h), ih, normalizedBox_fourier hh t]
    exact (pow_succ _ (n + 1)).symm

private theorem angular_fourier (f : ℝ → ℂ) (t : ℝ) :
    𝓕 f (-t / (2 * Real.pi)) =
      ∫ x : ℝ, Complex.exp (((t * x : ℝ) : ℂ) * Complex.I) * f x := by
  rw [Real.fourier_real_eq_integral_exp_smul]
  have he (x : ℝ) : -2 * Real.pi * x * (-t / (2 * Real.pi)) = t * x := by
    field_simp [Real.pi_ne_zero]
  simp only [he, smul_eq_mul]

theorem fourier_translate_angular (f : ℝ → ℂ) (c t : ℝ) :
    𝓕 (fun x => f (x - c)) (-t / (2 * Real.pi)) =
      Complex.exp (((t * c : ℝ) : ℂ) * Complex.I) * 𝓕 f (-t / (2 * Real.pi)) := by
  rw [angular_fourier, angular_fourier]
  rw [← integral_add_right_eq_self
    (fun x : ℝ => Complex.exp (((t * x : ℝ) : ℂ) * Complex.I) * f (x - c)) c]
  simp only [add_sub_cancel_right]
  rw [← integral_const_mul]
  congr 1
  funext x
  rw [show (((t * (x + c) : ℝ) : ℂ) * Complex.I) =
    (((t * c : ℝ) : ℂ) * Complex.I) + (((t * x : ℝ) : ℂ) * Complex.I) by
      push_cast
      ring, Complex.exp_add]
  ring

/-- The exact Fourier convention consumed by the order-19 certificate. -/
theorem spline19_fourier (L : ℝ) {h : ℝ} (hh : 0 < h) (t : ℝ) :
    𝓕 (spline19 L h) (-t / (2 * Real.pi)) =
      Complex.exp (((t * (L + 19 * h / 2) : ℝ) : ℂ) * Complex.I) *
        (Real.sinc (h * t / 2) : ℂ) ^ 19 := by
  unfold spline19
  rw [fourier_translate_angular, splineCore_fourier hh]

/-- The convolution normalization gives total mass exactly one. -/
theorem spline19_integral (L : ℝ) {h : ℝ} (hh : 0 < h) :
    (∫ x : ℝ, spline19 L h x) = 1 := by
  simpa [Real.fourier_real_eq_integral_exp_smul] using spline19_fourier L hh 0

/-- The certificate's spline vanishes throughout the forbidden open window. -/
theorem spline19_zero_in_window {L h : ℝ} (x : ℝ) (hx : |x| < L) :
    spline19 L h x = 0 := by
  by_contra hn
  have hs := (spline19_support L h x hn).1
  have ha := le_abs_self x
  linarith

/-- The five derivative columns use signs `+,+,-,-,+`. This is the exact
angular-frequency algebra; derivative regularity is a separate obligation. -/
theorem certificate_derivative_parity (j : Fin 5) (c t : ℝ) :
    (-1 : ℝ) ^ (j.val / 2) *
      (((-Complex.I * (t : ℂ)) ^ j.val) *
        Complex.exp (((t * c : ℝ) : ℂ) * Complex.I)).re =
      t ^ j.val * (if j.val % 2 = 0 then Real.cos (t * c) else Real.sin (t * c)) := by
  fin_cases j <;>
    norm_num [pow_succ, Complex.mul_re, Complex.mul_im, Complex.exp_re, Complex.exp_im]

/-- The certificate's factor `1/2` exactly cancels the doubled real part from
Hermitian reflection, with the derivative parity signs included. -/
theorem certificate_reflected_derivative_parity (j : Fin 5) (c t : ℝ) :
    (((-1 : ℂ) ^ (j.val / 2) / 2) *
      (((-Complex.I * (t : ℂ)) ^ j.val) *
          Complex.exp (((t * c : ℝ) : ℂ) * Complex.I) +
        (starRingEnd ℂ) (((-Complex.I * (t : ℂ)) ^ j.val) *
          Complex.exp (((t * c : ℝ) : ℂ) * Complex.I)))).re =
      t ^ j.val * (if j.val % 2 = 0 then Real.cos (t * c) else Real.sin (t * c)) := by
  fin_cases j <;>
    norm_num [pow_succ, Complex.mul_re, Complex.mul_im, Complex.exp_re, Complex.exp_im] <;>
    ring

end AEGIS.RHKreinSplineSupportV1

#print axioms AEGIS.RHKreinSplineSupportV1.splineCore_hasCompactSupport
#print axioms AEGIS.RHKreinSplineSupportV1.spline19_integrable
#print axioms AEGIS.RHKreinSplineSupportV1.spline19_support
#print axioms AEGIS.RHKreinSplineSupportV1.spline19_hasCompactSupport
#print axioms AEGIS.RHKreinSplineSupportV1.spline19_fourier
#print axioms AEGIS.RHKreinSplineSupportV1.spline19_integral
#print axioms AEGIS.RHKreinSplineSupportV1.certificate_derivative_parity
#print axioms AEGIS.RHKreinSplineSupportV1.certificate_reflected_derivative_parity
~~~~~~

## AEGISOverlay.RHBoxFourierComplementarityV1

Path: `source/AEGISOverlay/RHBoxFourierComplementarityV1.lean`

Original source lines: 1–109

Full file SHA256: `263cb73b76f109f0ba9cc1509f6abd027c4adb6179905a6c538603c635075463`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHBoxFourierComplementarityV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHMultiGeneratorComplementarityV1
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Analysis.Fourier.FourierTransform
import Mathlib.Topology.Algebra.Support

/-!
# Complementarity for actual Fourier transforms of compact interval profiles

This module binds sinc complementarity to the Mathlib Fourier transform,
with angular frequency t represented by -t/(2π). The profiles have compact
support but are not smooth Weil packets. No approximation or sign theorem
is asserted.
-/

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHBoxFourierComplementarityV1

open AEGIS.RHMultiGeneratorComplementarityV1

open MeasureTheory FourierTransform

/-- The compactly supported interval profile used in the generator experiment. -/
def boxProfile (a : ℝ) : ℝ → ℂ :=
  Set.indicator (Set.Ioc (-a) a) (fun _ => 1)

/-- The interval profiles have genuine compact support. -/
theorem boxProfile_hasCompactSupport (a : ℝ) : HasCompactSupport (boxProfile a) := by
  apply HasCompactSupport.intro (K := Set.Icc (-a) a) isCompact_Icc
  intro u hu
  have hu' : u ∉ Set.Ioc (-a) a := fun h => hu ⟨h.1.le, h.2⟩
  simp [boxProfile, hu']

/-- The angular-frequency integral of an interval is its sinc symbol. -/
theorem box_angular_integral (a t : ℝ) :
    (∫ u in -a..a, Complex.exp (((t * u : ℝ) : ℂ) * Complex.I)) =
      2 * (a : ℂ) * (Real.sinc (a * t) : ℂ) := by
  by_cases ht : t = 0
  · subst t
    simp
    ring
  change (∫ u in -a..a, (fun v : ℝ => Complex.exp ((v : ℂ) * Complex.I)) (t * u)) = _
  rw [intervalIntegral.integral_comp_mul_left
    (fun v : ℝ => Complex.exp ((v : ℂ) * Complex.I)) ht, mul_neg,
    integral_exp_mul_I_eq_sinc]
  simp only [Complex.real_smul, Complex.ofReal_inv, Complex.ofReal_mul]
  rw [mul_comm t a]
  have htc : (t : ℂ) ≠ 0 := by exact_mod_cast ht
  field_simp [htc]

/-- The actual Mathlib Fourier transform of the compact interval profile,
with the same angular-frequency conversion as the critical Mellin bridge. -/
theorem fourier_boxProfile_scaled {a : ℝ} (ha : 0 ≤ a) (t : ℝ) :
    𝓕 (boxProfile a) (-t / (2 * Real.pi)) =
      2 * (a : ℂ) * (Real.sinc (a * t) : ℂ) := by
  rw [Real.fourier_real_eq_integral_exp_smul]
  have hphase (u : ℝ) : -2 * Real.pi * u * (-t / (2 * Real.pi)) = t * u := by
    field_simp [Real.pi_ne_zero]
  simp_rw [hphase]
  have hfun :
      (fun u : ℝ => Complex.exp (((t * u : ℝ) : ℂ) * Complex.I) • boxProfile a u) =
      Set.indicator (Set.Ioc (-a) a)
        (fun u : ℝ => Complex.exp (((t * u : ℝ) : ℂ) * Complex.I)) := by
    funext u
    by_cases hu : u ∈ Set.Ioc (-a) a <;> simp [boxProfile, hu]
  rw [hfun, MeasureTheory.integral_indicator measurableSet_Ioc,
    ← intervalIntegral.integral_of_le (by linarith : -a ≤ a)]
  exact box_angular_integral a t

/-- Two genuine compact-supported interval profiles have no common Fourier
zero at any real angular frequency. They are not smooth Weil packets. -/
theorem log23_box_fourier_no_common_zero (t : ℝ) :
    ¬ (𝓕 (boxProfile (Real.log 2)) (-t / (2 * Real.pi)) = 0 ∧
      𝓕 (boxProfile (Real.log 3)) (-t / (2 * Real.pi)) = 0) := by
  have h2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have h3 : 0 < Real.log (3 : ℝ) := Real.log_pos (by norm_num)
  have h2c : (Real.log (2 : ℝ) : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt h2
  have h3c : (Real.log (3 : ℝ) : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt h3
  rw [fourier_boxProfile_scaled h2.le, fourier_boxProfile_scaled h3.le]
  rintro ⟨hA, hB⟩
  apply log23_sinc_no_common_zero t
  constructor
  · have hA' := (mul_eq_zero.mp hA).resolve_left (mul_ne_zero (by norm_num) h2c)
    exact_mod_cast hA'
  · have hB' := (mul_eq_zero.mp hB).resolve_left (mul_ne_zero (by norm_num) h3c)
    exact_mod_cast hB'

#print axioms AEGIS.RHBoxFourierComplementarityV1.fourier_boxProfile_scaled
#print axioms AEGIS.RHBoxFourierComplementarityV1.log23_box_fourier_no_common_zero
#print axioms AEGIS.RHBoxFourierComplementarityV1.boxProfile_hasCompactSupport

end AEGIS.RHBoxFourierComplementarityV1
~~~~~~

## AEGISOverlay.RHMultiGeneratorComplementarityV1

Path: `source/AEGISOverlay/RHMultiGeneratorComplementarityV1.lean`

Original source lines: 1–153

Full file SHA256: `f9aa8d5531f68fb869cc02dc74146c6385303420236b6a679b14806030dfa8d8`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHMultiGeneratorComplementarityV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import FormalConjectures.Millennium.RHSnowflakeLog23
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Sinc

/-!
# Complementary sinc symbols at irrationally related scales

An irrational scale ratio prevents two sinc symbols from sharing a real zero.
Positive integer powers and the positive real moment multiplier preserve this
property. The resulting two symbols admit an explicit continuous spectral
Bézout identity.

The conclusions concern these explicit real-frequency symbols. They do not
assert that finite-order splines are smooth Weil packets, or that the
translation span is dense in a topology controlling compact support and Mellin
evaluation. No positivity of the Weil form is assumed or concluded.
-/

set_option autoImplicit false

noncomputable section

namespace AEGIS.RHMultiGeneratorComplementarityV1

/-- Sinc zeros at two scales force a rational ratio of the scales. -/
theorem sinc_no_common_zero_of_irrational {a b : ℝ}
    (hirr : Irrational (a / b)) (t : ℝ) :
    ¬ (Real.sinc (a * t) = 0 ∧ Real.sinc (b * t) = 0) := by
  rintro ⟨ha, hb⟩
  have hat : a * t ≠ 0 := by
    intro h
    simp [h] at ha
  have hbt : b * t ≠ 0 := by
    intro h
    simp [h] at hb
  have hb0 : b ≠ 0 := fun h => hbt (by simp [h])
  have ht0 : t ≠ 0 := fun h => hbt (by simp [h])
  have hsinA : Real.sin (a * t) = 0 := by
    rw [Real.sinc_of_ne_zero hat] at ha
    exact (div_eq_zero_iff.mp ha).resolve_right hat
  have hsinB : Real.sin (b * t) = 0 := by
    rw [Real.sinc_of_ne_zero hbt] at hb
    exact (div_eq_zero_iff.mp hb).resolve_right hbt
  obtain ⟨m, hm⟩ := Real.sin_eq_zero_iff.mp hsinA
  obtain ⟨n, hn⟩ := Real.sin_eq_zero_iff.mp hsinB
  have hn0 : (n : ℝ) ≠ 0 := by
    intro h
    apply hbt
    simpa [h] using hn.symm
  have hprod : (a * (n : ℝ) - (m : ℝ) * b) * t = 0 := by
    nlinarith [congrArg (fun x : ℝ => (n : ℝ) * x) hm,
      congrArg (fun x : ℝ => (m : ℝ) * x) hn]
  have hcross : a * (n : ℝ) = (m : ℝ) * b :=
    sub_eq_zero.mp ((mul_eq_zero.mp hprod).resolve_right ht0)
  apply hirr
  refine ⟨(m : ℚ) / (n : ℚ), ?_⟩
  push_cast
  exact (div_eq_div_iff hn0 hb0).2 hcross.symm

/-- The log-2 and log-3 sinc symbols have no common real zero. -/
theorem log23_sinc_no_common_zero (t : ℝ) :
    ¬ (Real.sinc (Real.log 2 * t) = 0 ∧
      Real.sinc (Real.log 3 * t) = 0) :=
  sinc_no_common_zero_of_irrational
    RHSnowflakeLog23.irrational_log_two_div_log_three t

/-- Explicit real symbol with the angular-frequency moment multiplier.
The finite power is a spline symbol, not a definition of a smooth Weil packet. -/
def momentSplineSymbol (order : ℕ) (scale t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) * Real.sinc (scale * t) ^ order

/-- The moment multiplier introduces no real zero. -/
theorem momentSplineSymbol_eq_zero_iff {order : ℕ} (horder : order ≠ 0)
    (scale t : ℝ) :
    momentSplineSymbol order scale t = 0 ↔ Real.sinc (scale * t) = 0 := by
  have hmult : t ^ 2 + 1 / 4 ≠ 0 := by nlinarith [sq_nonneg t]
  simp only [momentSplineSymbol, mul_eq_zero, hmult, false_or]
  exact pow_eq_zero_iff horder

/-- Complementarity holds at every positive spline order, including order 19. -/
theorem log23_momentSpline_no_common_zero {order : ℕ} (horder : order ≠ 0)
    (t : ℝ) :
    ¬ (momentSplineSymbol order (Real.log 2) t = 0 ∧
      momentSplineSymbol order (Real.log 3) t = 0) := by
  simpa only [momentSplineSymbol_eq_zero_iff horder] using log23_sinc_no_common_zero t

/-- Each finite-order moment spline symbol is continuous. -/
theorem continuous_momentSplineSymbol (order : ℕ) (scale : ℝ) :
    Continuous (momentSplineSymbol order scale) := by
  unfold momentSplineSymbol
  exact ((continuous_id.pow 2).add continuous_const).mul
    ((Real.continuous_sinc.comp (continuous_const.mul continuous_id)).pow order)

/-- A complementary pair has a strictly positive squared-symbol denominator. -/
theorem log23_spectral_denominator_pos {order : ℕ} (horder : order ≠ 0) (t : ℝ) :
    0 < momentSplineSymbol order (Real.log 2) t ^ 2 +
      momentSplineSymbol order (Real.log 3) t ^ 2 := by
  have h := log23_momentSpline_no_common_zero horder t
  have hA := sq_nonneg (momentSplineSymbol order (Real.log 2) t)
  have hB := sq_nonneg (momentSplineSymbol order (Real.log 3) t)
  by_contra! hnot
  have hAz : momentSplineSymbol order (Real.log 2) t = 0 := by nlinarith
  have hBz : momentSplineSymbol order (Real.log 3) t = 0 := by nlinarith
  exact h ⟨hAz, hBz⟩

/-- Continuous real multipliers reconstruct the constant symbol exactly.
This is a spectral identity, not a compact-support approximation theorem. -/
theorem log23_continuous_spectral_bezout {order : ℕ} (horder : order ≠ 0) :
    ∃ A B : ℝ → ℝ, Continuous A ∧ Continuous B ∧
      ∀ t : ℝ, A t * momentSplineSymbol order (Real.log 2) t +
        B t * momentSplineSymbol order (Real.log 3) t = 1 := by
  let F := momentSplineSymbol order (Real.log 2)
  let G := momentSplineSymbol order (Real.log 3)
  have hF : Continuous F := continuous_momentSplineSymbol order _
  have hG : Continuous G := continuous_momentSplineSymbol order _
  have hden : Continuous (fun t => F t ^ 2 + G t ^ 2) :=
    (hF.pow 2).add (hG.pow 2)
  have hne : ∀ t, F t ^ 2 + G t ^ 2 ≠ 0 :=
    fun t => ne_of_gt (log23_spectral_denominator_pos horder t)
  refine ⟨fun t => F t / (F t ^ 2 + G t ^ 2),
    fun t => G t / (F t ^ 2 + G t ^ 2),
    hF.div hden hne, hG.div hden hne, ?_⟩
  intro t
  field_simp [hne t]
  ring

/-- Order 19 is one instance of the all-orders complementarity theorem. -/
theorem order19_log23_continuous_spectral_bezout :
    ∃ A B : ℝ → ℝ, Continuous A ∧ Continuous B ∧
      ∀ t : ℝ, A t * momentSplineSymbol 19 (Real.log 2) t +
        B t * momentSplineSymbol 19 (Real.log 3) t = 1 :=
  log23_continuous_spectral_bezout (by norm_num)

#print axioms AEGIS.RHMultiGeneratorComplementarityV1.sinc_no_common_zero_of_irrational
#print axioms AEGIS.RHMultiGeneratorComplementarityV1.log23_momentSpline_no_common_zero
#print axioms AEGIS.RHMultiGeneratorComplementarityV1.order19_log23_continuous_spectral_bezout

end AEGIS.RHMultiGeneratorComplementarityV1
~~~~~~

## FormalConjectures.Millennium.RHSnowflakeLog23

Path: `source/FormalConjectures/Millennium/RHSnowflakeLog23.lean`

Original source lines: 1–131

Full file SHA256: `b4df3ae12327c658f0dc8cf7591cf1ed6cb012db6b694aab4cdfa902a0e8af8b`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/FormalConjectures/Millennium/RHSnowflakeLog23.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import Mathlib.Topology.Instances.AddCircle.DenseSubgroup
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Algebra.Group.Nat.Even
import Mathlib.Algebra.Ring.Parity
import Mathlib.Tactic

/-!
# RH snowflake log-2/log-3 globalization bridge

This file proves the arithmetic-topological part of a candidate globalization
lane for the Riemann Hypothesis formalization: the logarithmic scales generated
by 2 and 3 are rationally independent, hence the additive subgroup they
generate is dense in the real log-coordinate line.

This is not itself a proof of the Riemann Hypothesis.  Its intended use is to
combine the existing dyadic translation tower with a second, hexagonal/
Eisenstein scale before proving continuity and positivity closure on finite
log-windows.
-/

open Set

set_option autoImplicit false

namespace RHSnowflakeLog23

/-- The logarithmic scales supplied by the dyadic and Eisenstein/hexagonal
lanes are rationally independent.  The proof is elementary: a rational
relation would force a positive power of 2 to equal a positive power of 3. -/
theorem irrational_log_two_div_log_three :
    Irrational (Real.log 2 / Real.log 3) := by
  intro hrat
  rcases hrat with ⟨q, hq⟩
  have hlog2 : 0 < Real.log (2 : ℝ) := Real.log_pos (by norm_num)
  have hlog3 : 0 < Real.log (3 : ℝ) := Real.log_pos (by norm_num)
  have hratio : 0 < Real.log (2 : ℝ) / Real.log (3 : ℝ) :=
    div_pos hlog2 hlog3
  have hqposR : (0 : ℝ) < (q : ℝ) := by
    rw [hq]
    exact hratio
  have hqpos : 0 < q := by exact_mod_cast hqposR
  have hnumpos : 0 < q.num := Rat.num_pos.mpr hqpos
  have hdenR : (q.den : ℝ) ≠ 0 := by
    exact_mod_cast q.den_ne_zero
  have hlog3ne : Real.log (3 : ℝ) ≠ 0 := ne_of_gt hlog3
  have hqcast :
      ((q.num : ℤ) : ℝ) / (q.den : ℝ) =
        Real.log (2 : ℝ) / Real.log (3 : ℝ) := by
    simpa [Rat.cast_def] using hq
  have hcross :
      ((q.num : ℤ) : ℝ) * Real.log (3 : ℝ) =
        Real.log (2 : ℝ) * (q.den : ℝ) :=
    (div_eq_div_iff hdenR hlog3ne).mp hqcast
  have hnumAbsInt : (q.num.natAbs : ℤ) = q.num :=
    Int.natAbs_of_nonneg hnumpos.le
  have hnumAbsR : (q.num.natAbs : ℝ) = ((q.num : ℤ) : ℝ) := by
    have hcast := congrArg (fun z : ℤ => (z : ℝ)) hnumAbsInt
    simpa only [Int.cast_natCast] using hcast
  have hlogpow :
      Real.log ((2 : ℝ) ^ q.den) =
        Real.log ((3 : ℝ) ^ q.num.natAbs) := by
    rw [Real.log_pow, Real.log_pow, hnumAbsR]
    nlinarith [hcross]
  have heqR : (2 : ℝ) ^ q.den = (3 : ℝ) ^ q.num.natAbs :=
    Real.log_injOn_pos
      (Set.mem_Ioi.mpr (by positivity))
      (Set.mem_Ioi.mpr (by positivity))
      hlogpow
  have heqN : 2 ^ q.den = 3 ^ q.num.natAbs := by
    exact_mod_cast heqR
  have heven : Even (2 ^ q.den) := by
    rw [Nat.even_pow]
    exact ⟨by norm_num, q.den_ne_zero⟩
  have hodd : Odd (3 ^ q.num.natAbs) :=
    (show Odd (3 : ℕ) by norm_num).pow
  have hoddL : Odd (2 ^ q.den) := by
    rw [heqN]
    exact hodd
  exact (Nat.not_even_iff_odd.mpr hoddL) heven

/-- The additive subgroup generated by the two logarithmic prime scales. -/
def SnowflakeShiftGroup : AddSubgroup ℝ :=
  AddSubgroup.closure {Real.log 2, Real.log 3}

/-- The dyadic + hexagonal shift group is dense in the real log-coordinate
line.  This is the topological ingredient absent from the dyadic tower alone. -/
theorem snowflake_shift_group_dense :
    Dense (SnowflakeShiftGroup : Set ℝ) := by
  simpa [SnowflakeShiftGroup] using
    (dense_addSubgroupClosure_pair_iff.mpr irrational_log_two_div_log_three)

/-- A continuous real-valued quantity that is nonnegative on the snowflake
shift group is nonnegative everywhere.  This is the exact closure principle
needed once a translation-kernel quadratic value is shown continuous. -/
theorem snowflake_nonnegative_of_continuous
    (Q : ℝ → ℝ) (hQ : Continuous Q)
    (hnonneg : ∀ x : ℝ, x ∈ SnowflakeShiftGroup → 0 ≤ Q x) :
    ∀ x : ℝ, 0 ≤ Q x := by
  have hclosed : IsClosed {x : ℝ | 0 ≤ Q x} :=
    isClosed_Ici.preimage hQ
  have hsub : (SnowflakeShiftGroup : Set ℝ) ⊆ {x : ℝ | 0 ≤ Q x} := by
    intro x hx
    exact hnonneg x hx
  have hclosure :
      closure (SnowflakeShiftGroup : Set ℝ) ⊆ {x : ℝ | 0 ≤ Q x} :=
    closure_minimal hsub hclosed
  intro x
  apply hclosure
  simp [snowflake_shift_group_dense.closure_eq]

#print axioms RHSnowflakeLog23.irrational_log_two_div_log_three
#print axioms RHSnowflakeLog23.snowflake_shift_group_dense
#print axioms RHSnowflakeLog23.snowflake_nonnegative_of_continuous

end RHSnowflakeLog23
~~~~~~

## AEGISOverlay.RHKreinSplineFourierIntegrableV1

Path: `source/AEGISOverlay/RHKreinSplineFourierIntegrableV1.lean`

Original source lines: 1–155

Full file SHA256: `3454ecb6f16d119b0c4423d972a6d4ea1445f59051b2ec66844f79535754553b`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinSplineFourierIntegrableV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinSplineSupportV1
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals

/-!
# Fourier integrability of the concrete Krein spline

For every integer power at least two, `|sinc(x)|^n ≤ 2/(1+x²)`.
The rational majorant is integrable on the whole real line. Applying the
already-proved exact spline Fourier formula and its frequency scaling
establishes the actual Fourier-integrability hypothesis of Krein pairing.
-/

open MeasureTheory FourierTransform

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSplineFourierIntegrableV1

open AEGIS.RHKreinSplineSupportV1

/-- A global integrable rational majorant for every sinc power of order at least two. -/
theorem sinc_pow_rational_bound (n : ℕ) (hn : 2 ≤ n) (x : ℝ) :
    |Real.sinc x| ^ n ≤ 2 / (1 + x ^ 2) := by
  have hs : (Real.sinc x) ^ 2 ≤ 1 := by
    simpa only [sq_abs] using
      (pow_le_one₀ (abs_nonneg (Real.sinc x)) (Real.abs_sinc_le_one x) :
        |Real.sinc x| ^ 2 ≤ 1)
  have hi : x * Real.sinc x = Real.sin x := by
    by_cases hx : x = 0
    · simp [hx]
    · rw [Real.sinc_of_ne_zero hx]
      field_simp
  have hi2 : x ^ 2 * (Real.sinc x) ^ 2 = (Real.sin x) ^ 2 := by
    calc
      x ^ 2 * (Real.sinc x) ^ 2 = (x * Real.sinc x) ^ 2 := by ring
      _ = (Real.sin x) ^ 2 := by rw [hi]
  have hsin : (Real.sin x) ^ 2 ≤ 1 := by
    nlinarith [Real.sin_sq_add_cos_sq x, sq_nonneg (Real.cos x)]
  have hsbound : (Real.sinc x) ^ 2 ≤ 2 / (1 + x ^ 2) := by
    apply (le_div_iff₀ (by positivity : 0 < 1 + x ^ 2)).2
    nlinarith
  have hk : |Real.sinc x| ^ (n - 2) ≤ 1 :=
    pow_le_one₀ (abs_nonneg (Real.sinc x)) (Real.abs_sinc_le_one x)
  calc
    |Real.sinc x| ^ n = |Real.sinc x| ^ 2 * |Real.sinc x| ^ (n - 2) := by
      rw [← pow_add]
      congr 1
      omega
    _ ≤ |Real.sinc x| ^ 2 * 1 := mul_le_mul_of_nonneg_left hk (sq_nonneg _)
    _ = (Real.sinc x) ^ 2 := by rw [mul_one, sq_abs]
    _ ≤ 2 / (1 + x ^ 2) := hsbound

/-- The sinc powers are integrable with respect to Lebesgue measure, not just
on a finite interval. -/
theorem sinc_pow_integrable (n : ℕ) (hn : 2 ≤ n) :
    Integrable (fun x : ℝ => (Real.sinc x : ℂ) ^ n) := by
  refine (integrable_inv_one_add_sq.const_mul (2 : ℝ)).mono' ?_ ?_
  · exact ((Complex.continuous_ofReal.comp Real.continuous_sinc).pow n).aestronglyMeasurable
  · exact Filter.Eventually.of_forall (fun x => by
      simpa only [norm_pow, Complex.norm_real, Real.norm_eq_abs, div_eq_mul_inv] using
        sinc_pow_rational_bound n hn x)

/-- Polynomially weighted sinc powers remain integrable when two powers
remain after cancelling against the polynomial weight. -/
theorem weighted_sinc_pow_integrable (j n : ℕ) (hn : 2 ≤ n) :
    Integrable (fun x : ℝ => (x : ℂ) ^ j * (Real.sinc x : ℂ) ^ (j + n)) := by
  have he (x : ℝ) : (x : ℂ) * (Real.sinc x : ℂ) = (Real.sin x : ℂ) := by
    have hr : x * Real.sinc x = Real.sin x := by
      by_cases hx : x = 0
      · simp [hx]
      · rw [Real.sinc_of_ne_zero hx]
        field_simp
    exact_mod_cast hr
  have hf : (fun x : ℝ => (x : ℂ) ^ j * (Real.sinc x : ℂ) ^ (j + n)) =
      (fun x : ℝ => (Real.sin x : ℂ) ^ j * (Real.sinc x : ℂ) ^ n) := by
    funext x
    rw [pow_add, ← mul_assoc, ← mul_pow, he]
  rw [hf]
  refine (sinc_pow_integrable n hn).norm.mono' ?_ ?_
  · have hc : Continuous (fun x : ℝ =>
        (Real.sin x : ℂ) ^ j * (Real.sinc x : ℂ) ^ n) := by fun_prop
    exact hc.aestronglyMeasurable
  · exact Filter.Eventually.of_forall (fun x => by
      rw [norm_mul]
      have hb : ‖(Real.sin x : ℂ) ^ j‖ ≤ 1 := by
        simpa only [norm_pow, Complex.norm_real, Real.norm_eq_abs] using
          (pow_le_one₀ (abs_nonneg (Real.sin x)) (Real.abs_sin_le_one x) :
            |Real.sin x| ^ j ≤ 1)
      simpa only [one_mul] using mul_le_mul_of_nonneg_right hb
        (norm_nonneg ((Real.sinc x : ℂ) ^ n)))

/-- The polynomially weighted integrability is preserved under any nonzero scale. -/
theorem weighted_sinc_scaled_integrable (a : ℝ) (ha : a ≠ 0)
    (j n : ℕ) (hn : 2 ≤ n) :
    Integrable (fun t : ℝ => (t : ℂ) ^ j * (Real.sinc (a * t) : ℂ) ^ (j + n)) := by
  have hi := (weighted_sinc_pow_integrable j n hn).comp_mul_left' ha
  have hac : (a : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr ha
  have hi' := hi.const_mul ((a : ℂ)⁻¹ ^ j)
  convert hi' using 1
  funext t
  simp only [Complex.ofReal_mul]
  rw [← mul_assoc, ← mul_pow]
  rw [← mul_assoc, inv_mul_cancel₀ hac, one_mul]

/-- Integrability at angular frequency follows from the exact Fourier formula. -/
theorem spline19_fourier_scaled_integrable (L : ℝ) {h : ℝ} (hh : 0 < h) :
    Integrable (fun t : ℝ => 𝓕 (spline19 L h) (-t / (2 * Real.pi))) := by
  have hs : Integrable (fun t : ℝ => (Real.sinc (h * t / 2) : ℂ) ^ 19) := by
    have hh2 : h / 2 ≠ 0 := by positivity
    simpa only [div_mul_eq_mul_div] using
      (sinc_pow_integrable 19 (by norm_num)).comp_mul_left' hh2
  have he : (fun t : ℝ => 𝓕 (spline19 L h) (-t / (2 * Real.pi))) =
      (fun t => Complex.exp (((t * (L + 19 * h / 2) : ℝ) : ℂ) * Complex.I) *
        (Real.sinc (h * t / 2) : ℂ) ^ 19) := funext (spline19_fourier L hh)
  rw [he]
  refine hs.norm.mono' ?_ ?_
  · have hc : Continuous (fun t : ℝ =>
        Complex.exp (((t * (L + 19 * h / 2) : ℝ) : ℂ) * Complex.I) *
          (Real.sinc (h * t / 2) : ℂ) ^ 19) := by
      fun_prop
    exact hc.aestronglyMeasurable
  · exact Filter.Eventually.of_forall (fun t => by
      simp [Complex.norm_exp])

/-- The actual Mathlib Fourier transform of the genuine order-19 spline is integrable. -/
theorem spline19_fourier_integrable (L : ℝ) {h : ℝ} (hh : 0 < h) :
    Integrable (𝓕 (spline19 L h)) := by
  have hp : -(2 * Real.pi) ≠ 0 := neg_ne_zero.mpr (by positivity)
  have hi := (spline19_fourier_scaled_integrable L hh).comp_mul_right' hp
  convert hi using 1
  funext ξ
  field_simp [Real.pi_ne_zero]

end AEGIS.RHKreinSplineFourierIntegrableV1

#print axioms AEGIS.RHKreinSplineFourierIntegrableV1.sinc_pow_rational_bound
#print axioms AEGIS.RHKreinSplineFourierIntegrableV1.sinc_pow_integrable
#print axioms AEGIS.RHKreinSplineFourierIntegrableV1.spline19_fourier_integrable
~~~~~~

## RHKreinGenuineCertificateV1

Path: `source/RHKreinGenuineCertificateV1.lean`

Original source lines: 1–184

Full file SHA256: `c1a9a19a87c84c19cc1d699143a7d39463bb18555ef4b7851fe0fa547aea2842`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinGenuineCertificateV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFourierFactorV1
import RHKreinCertificateTransferV1

/-!
# Genuine Krein certificate consumer for the actual Weil quadratic

This module constructs the moment factor and both spectral masses, and
proves correction integrability and zero pairing from the existing Krein
theorem. The certificate inputs are only a genuine function H with the
stated regularity/support and a pointwise weighted symbol inequality.
No evenness assumption is needed: the second mass uses the reflected factor.
-/

open Set MeasureTheory Complex FourierTransform
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinGenuineCertificateV1

open AEGIS.RHKreinFourierFactorV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinCertificateTransferV1
open AEGIS.RHDyadicDiagonalV13
open AEGIS.WeilDisjointEnergyV2

private theorem angular_integrable {f : ℝ → ℂ} (hf : Integrable f) :
    Integrable (fun t : ℝ => f (-t / (2 * Real.pi))) := by
  have hne : (-(2 * Real.pi))⁻¹ ≠ 0 :=
    inv_ne_zero (neg_ne_zero.mpr (mul_ne_zero (by norm_num) Real.pi_ne_zero))
  have h := hf.comp_mul_right' hne
  have he : (fun t : ℝ => f (-t / (2 * Real.pi))) =
      (fun t : ℝ => f (t * (-(2 * Real.pi))⁻¹)) := by
    funext t
    congr 1
    rw [div_eq_mul_inv, inv_neg]
    ring
  rw [he]
  exact h

private theorem spectral_pair_integrable (G H : ℝ → ℂ)
    (hG : Integrable G) (hFH : Integrable (𝓕 H)) :
    Integrable (fun ξ : ℝ => (Complex.normSq (𝓕 G ξ) : ℂ) * 𝓕 H ξ) := by
  have hc : Continuous (𝓕 G) := by
    change Continuous (VectorFourier.fourierIntegral Real.fourierChar volume (innerₗ ℝ) G)
    exact VectorFourier.fourierIntegral_continuous (e := Real.fourierChar)
      (μ := volume) (L := innerₗ ℝ) Real.continuous_fourierChar continuous_inner hG
  have hn : Continuous (fun ξ : ℝ => (Complex.normSq (𝓕 G ξ) : ℂ)) :=
    Complex.continuous_ofReal.comp (Complex.continuous_normSq.comp hc)
  have hb : ∀ ξ : ℝ, ‖(Complex.normSq (𝓕 G ξ) : ℂ)‖ ≤ (∫ x : ℝ, ‖G x‖) ^ 2 := by
    intro ξ
    have hbound : ‖𝓕 G ξ‖ ≤ ∫ x : ℝ, ‖G x‖ := by
      change ‖VectorFourier.fourierIntegral Real.fourierChar volume (innerₗ ℝ) G ξ‖ ≤
        ∫ x : ℝ, ‖G x‖
      exact VectorFourier.norm_fourierIntegral_le_integral_norm
        Real.fourierChar volume (innerₗ ℝ) G ξ
    rw [Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Complex.normSq_nonneg _), Complex.normSq_eq_norm_sq]
    have hn0 : 0 ≤ ∫ x : ℝ, ‖G x‖ := integral_nonneg (fun x => norm_nonneg _)
    nlinarith [norm_nonneg (𝓕 G ξ)]
  exact hFH.bdd_mul hn.aestronglyMeasurable (Filter.Eventually.of_forall hb)

/-- The real correction integral is integrable and zero; the existing
complex pairing theorem is the sole source of the vanishing claim. -/
theorem real_angular_krein_pairing (G : ℝ → ℂ) (a b : ℝ)
    (hG : Integrable G) (hs : ∀ y, G y ≠ 0 → y ∈ Ioo a b)
    (H : ℝ → ℂ) (hHc : Continuous H) (hH : Integrable H) (hFH : Integrable (𝓕 H))
    (hHs : ∀ u, |u| < b - a → H u = 0) :
    Integrable (fun t : ℝ => (𝓕 H (-t / (2 * Real.pi))).re *
      Complex.normSq (𝓕 G (-t / (2 * Real.pi)))) ∧
    (∫ t : ℝ, (𝓕 H (-t / (2 * Real.pi))).re *
      Complex.normSq (𝓕 G (-t / (2 * Real.pi)))) = 0 := by
  have hi := angular_integrable (spectral_pair_integrable G H hG hFH)
  have he : ∀ t : ℝ,
      ((Complex.normSq (𝓕 G (-t / (2 * Real.pi))) : ℂ) *
        𝓕 H (-t / (2 * Real.pi))).re =
      (𝓕 H (-t / (2 * Real.pi))).re * Complex.normSq (𝓕 G (-t / (2 * Real.pi))) := by
    intro t
    simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
    ring
  have hri := hi.re
  simp only [RCLike.re_to_complex] at hri
  refine ⟨hri.congr (Filter.Eventually.of_forall he), ?_⟩
  have hz := congrArg Complex.re (angular_krein_pairing G a b hG hs H hHc hH hFH hHs)
  have hre := (integral_re hi).symm
  simp only [RCLike.re_to_complex] at hre
  rw [hre] at hz
  simpa only [he, Complex.zero_re] using hz

theorem fourier_reflection (G : ℝ → ℂ) (ξ : ℝ) :
    𝓕 (fun x => G (-x)) ξ = 𝓕 G (-ξ) := by
  rw [Real.fourier_real_eq_integral_exp_smul, Real.fourier_real_eq_integral_exp_smul]
  rw [← integral_neg_eq_self (fun x : ℝ =>
    Complex.exp (((-2 * Real.pi * x * ξ : ℝ) : ℂ) * I) • G (-x))]
  apply integral_congr_ae
  filter_upwards [] with x
  simp only [neg_neg]
  congr 2
  push_cast
  ring

/-- A genuine certificate with support outside the packet-difference window
implies a margin for the actual canonical zero quadratic. The factor, mass,
integrability, reflection and correction-pairing obligations are discharged. -/
theorem zero_quadratic_margin_from_genuine_certificate
    (g : WeilCompactSmoothGV1) (r a m : ℝ) (hr0 : 0 ≤ r)
    (hw : HalfWidthAt g r a) (hr : 2 * r < Real.log 3)
    (hm : WeilMomentConditionsV1 g)
    (H : ℝ → ℂ) (hHc : Continuous H) (hH : Integrable H) (hFH : Integrable (𝓕 H))
    (hHs : ∀ u : ℝ, |u| < 2 * r → H u = 0)
    (hcert : ∀ t : ℝ, 0 ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - m) +
      (𝓕 H (-t / (2 * Real.pi))).re) :
    m * energy g.1 ≤
      (∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho).re := by
  obtain ⟨χ, hc, hs, hi, hf⟩ :=
    actual_packet_fourier_factor g (a - r) (a + r) (by linarith) hw hm
  let χn : ℝ → ℂ := fun x => χ (-x)
  let ρ : ℝ → ℝ := fun t => Complex.normSq (𝓕 χ (-t / (2 * Real.pi))) +
    Complex.normSq (𝓕 χn (-t / (2 * Real.pi)))
  let C : ℝ → ℝ := fun t => (𝓕 H (-t / (2 * Real.pi))).re
  have hχs : ∀ y, χ y ≠ 0 → y ∈ Ioo (a - r) (a + r) :=
    AEGIS.RHKreinFactorV13.ne_zero_mem_Ioo χ hc.continuous (a - r) (a + r) hs
  have hχns : ∀ y, χn y ≠ 0 → y ∈ Ioo (-(a + r)) (-(a - r)) := by
    intro y hy
    have h := hχs (-y) hy
    constructor <;> linarith [h.1, h.2]
  have hχni : Integrable χn := hi.comp_neg
  have hfirst := real_angular_krein_pairing χ (a - r) (a + r) hi hχs
    H hHc hH hFH (fun u hu => hHs u (by linarith))
  have hsecond := real_angular_krein_pairing χn (-(a + r)) (-(a - r)) hχni hχns
    H hHc hH hFH (fun u hu => hHs u (by linarith))
  have hρ : ∀ t : ℝ, 0 ≤ ρ t := by
    intro t
    exact add_nonneg (Complex.normSq_nonneg _) (Complex.normSq_nonneg _)
  have hmass : ∀ t : ℝ, criticalSpectralMass g t = (t ^ 2 + 1 / 4) ^ 2 * ρ t := by
    intro t
    unfold criticalSpectralMass
    rw [hf t, hf (-t)]
    dsimp [ρ, χn]
    rw [fourier_reflection]
    have he : -(-t / (2 * Real.pi)) = -(-t) / (2 * Real.pi) := by ring
    rw [he]
    ring
  have hsplit : ∀ t : ℝ, C t * ρ t =
      (𝓕 H (-t / (2 * Real.pi))).re * Complex.normSq (𝓕 χ (-t / (2 * Real.pi))) +
      (𝓕 H (-t / (2 * Real.pi))).re * Complex.normSq (𝓕 χn (-t / (2 * Real.pi))) := by
    intro t
    dsimp [C, ρ]
    ring
  have hCi : Integrable (fun t : ℝ => C t * ρ t) :=
    (hfirst.1.add hsecond.1).congr (Filter.Eventually.of_forall fun t => by
      change (𝓕 H (-t / (2 * Real.pi))).re *
          Complex.normSq (𝓕 χ (-t / (2 * Real.pi))) +
        (𝓕 H (-t / (2 * Real.pi))).re *
          Complex.normSq (𝓕 χn (-t / (2 * Real.pi))) = C t * ρ t
      exact (hsplit t).symm)
  have hCz : (∫ t : ℝ, C t * ρ t) = 0 := by
    simp_rw [hsplit]
    rw [integral_add hfirst.1 hsecond.1, hfirst.2, hsecond.2, add_zero]
  exact zero_quadratic_margin_of_weighted_certificate g r a m hw hr hm
    ρ C hρ hmass hCi hCz hcert

end AEGIS.RHKreinGenuineCertificateV1

#print axioms AEGIS.RHKreinGenuineCertificateV1.real_angular_krein_pairing
#print axioms AEGIS.RHKreinGenuineCertificateV1.fourier_reflection
#print axioms AEGIS.RHKreinGenuineCertificateV1.zero_quadratic_margin_from_genuine_certificate
~~~~~~

## RHKreinFourierFactorV1

Path: `source/RHKreinFourierFactorV1.lean`

Original source lines: 1–138

Full file SHA256: `6c202ad22b658e909d0f8f8f7ed87d3791089749792eeb04a75283446ffa084e`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinFourierFactorV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinSymbolIntegrationV1
import RHKreinFactorV13
import Mathlib.Analysis.Fourier.FourierTransformDeriv

/-!
# Fourier multiplier and angular Krein pairing

The derivative factor is transported to angular frequency with the exact
Mathlib scaling. The actual existing Krein pairing is transported by the
same change of variables. Neither theorem consumes a numerical certificate.
-/

open Set MeasureTheory Complex FourierTransform
open scoped ContDiff
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFourierFactorV1

/-- The Jacobian for angular frequency is exactly 2*pi in this direction. -/
theorem angular_integral (f : ℝ → ℂ) :
    (∫ t : ℝ, f (-t / (2 * Real.pi))) = (2 * Real.pi : ℂ) * ∫ ξ : ℝ, f ξ := by
  have he : (fun t : ℝ => f (-t / (2 * Real.pi))) =
      (fun t : ℝ => f (t / (-(2 * Real.pi)))) := by
    funext t
    congr 1
    ring
  rw [he, Measure.integral_comp_div]
  rw [abs_neg, abs_of_pos (by positivity : (0 : ℝ) < 2 * Real.pi), Complex.real_smul]
  push_cast
  rfl

/-- The genuine-function Krein correction pairs to zero with angular Fourier
mass. All support and integrability hypotheses match the existing theorem. -/
theorem angular_krein_pairing (G : ℝ → ℂ) (a b : ℝ) (hG : Integrable G)
    (hsupp : ∀ y, G y ≠ 0 → y ∈ Set.Ioo a b)
    (H : ℝ → ℂ) (hHc : Continuous H) (hH : Integrable H) (hFH : Integrable (𝓕 H))
    (hHs : ∀ u, |u| < b - a → H u = 0) :
    (∫ t : ℝ, (Complex.normSq (𝓕 G (-t / (2 * Real.pi))) : ℂ) *
      𝓕 H (-t / (2 * Real.pi))) = 0 := by
  have h := AEGIS.RHKreinPairingV13.krein_pairing G a b hG hsupp H hHc hH hFH hHs
  rw [angular_integral (fun ξ => (Complex.normSq (𝓕 G ξ) : ℂ) * 𝓕 H ξ), h, mul_zero]

/-- Fourier linearity on the particular integrable differential expression. -/
theorem fourier_differential_factor (χ : ℝ → ℂ)
    (hχ : Integrable χ) (hχ' : Integrable (deriv χ))
    (hχ'' : Integrable (deriv (deriv χ)))
    (hdχ : Differentiable ℝ χ) (hdχ' : Differentiable ℝ (deriv χ)) (t : ℝ) :
    𝓕 (fun x => deriv (deriv χ) x - (1 / 4 : ℂ) * χ x) (-t / (2 * Real.pi)) =
      -(((t ^ 2 + 1 / 4 : ℝ) : ℂ)) * 𝓕 χ (-t / (2 * Real.pi)) := by
  have hlin := VectorFourier.fourierIntegral_add
    (e := Real.fourierChar) (μ := volume) (L := innerₗ ℝ)
    Real.continuous_fourierChar continuous_inner hχ'' (hχ.const_mul (-1 / 4 : ℂ))
  have hscaled := VectorFourier.fourierIntegral_const_smul
    Real.fourierChar volume (innerₗ ℝ) χ (-1 / 4 : ℂ)
  have hF : 𝓕 (fun x => deriv (deriv χ) x - (1 / 4 : ℂ) * χ x) =
      fun ξ => 𝓕 (deriv (deriv χ)) ξ - (1 / 4 : ℂ) * 𝓕 χ ξ := by
    funext ξ
    simpa only [Real.fourier_eq, VectorFourier.fourierIntegral, innerₗ_apply_apply,
      Pi.add_apply, Pi.smul_apply, smul_eq_mul,
      neg_div, neg_mul, ← sub_eq_add_neg] using congrFun (hlin.trans
        (congrArg (fun v => VectorFourier.fourierIntegral Real.fourierChar volume
          (innerₗ ℝ) (deriv (deriv χ)) + v) hscaled)) ξ
  rw [hF, Real.fourier_deriv hχ' hdχ' hχ'', Real.fourier_deriv hχ hdχ hχ']
  simp only [smul_eq_mul]
  have hp : (Real.pi : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr Real.pi_ne_zero
  push_cast
  field_simp [hp]
  simp only [Complex.I_sq]
  ring

/-- Every actual moment-zero packet has a smooth compactly supported factor
on the same window, with the exact squared angular Fourier multiplier. -/
theorem actual_packet_fourier_factor
    (g : WeilCompactSmoothGV1) (a b : ℝ) (hab : a ≤ b)
    (hs : tsupport (AEGIS.WeilLogCoordinateIsometryV21.logLift g.1) ⊆ Icc a b)
    (hm : WeilMomentConditionsV1 g) :
    ∃ χ : ℝ → ℂ, ContDiff ℝ ∞ χ ∧ tsupport χ ⊆ Icc a b ∧ Integrable χ ∧
      ∀ t : ℝ,
        Complex.normSq (𝓕 (AEGIS.WeilLogCoordinateIsometryV21.logLift g.1)
          (-t / (2 * Real.pi))) =
        (t ^ 2 + 1 / 4) ^ 2 * Complex.normSq (𝓕 χ (-t / (2 * Real.pi))) := by
  let G := AEGIS.WeilLogCoordinateIsometryV21.logLift g.1
  have hG : ContDiff ℝ ∞ G := by
    have hg := g.2.1
    unfold G AEGIS.WeilLogCoordinateIsometryV21.logLift
    exact (Complex.ofRealCLM.contDiff.comp (contDiff_id.div_const (2 : ℝ)).exp).mul
      (hg.comp Real.contDiff_exp)
  have hp : (∫ u : ℝ, (Real.exp (u / 2) : ℂ) * G u) = 0 := by
    change (∫ u : ℝ, (Real.exp (u / 2) : ℂ) * AEGIS.RHKreinFactorV13.lift g.1 u) = 0
    rw [AEGIS.RHKreinFactorV13.lift_moment_plus]
    exact hm.2
  have hn : (∫ u : ℝ, (Real.exp (-u / 2) : ℂ) * G u) = 0 := by
    change (∫ u : ℝ, (Real.exp (-u / 2) : ℂ) * AEGIS.RHKreinFactorV13.lift g.1 u) = 0
    rw [AEGIS.RHKreinFactorV13.lift_moment_minus]
    exact hm.1
  obtain ⟨χ, hc, hcs, heq⟩ :=
    AEGIS.RHKreinFactorV13.moment_zero_parametrization G a b hab hG hs hn hp
  have hcompact : HasCompactSupport χ :=
    isCompact_Icc.of_isClosed_subset (isClosed_tsupport χ) hcs
  have hc' := (contDiff_infty_iff_deriv.mp hc).2
  have hc'' := (contDiff_infty_iff_deriv.mp hc').2
  have hi : Integrable χ := hc.continuous.integrable_of_hasCompactSupport hcompact
  have hi' : Integrable (deriv χ) :=
    hc'.continuous.integrable_of_hasCompactSupport hcompact.deriv
  have hi'' : Integrable (deriv (deriv χ)) :=
    hc''.continuous.integrable_of_hasCompactSupport hcompact.deriv.deriv
  refine ⟨χ, hc, hcs, hi, fun t => ?_⟩
  have hfun : G = fun u => deriv (deriv χ) u - (1 / 4 : ℂ) * χ u := funext heq
  change Complex.normSq (𝓕 G (-t / (2 * Real.pi))) = _
  rw [hfun, fourier_differential_factor χ hi hi' hi''
    (contDiff_infty_iff_deriv.mp hc).1 (contDiff_infty_iff_deriv.mp hc').1]
  rw [Complex.normSq_mul, Complex.normSq_neg, Complex.normSq_ofReal]
  ring

end AEGIS.RHKreinFourierFactorV1

#print axioms AEGIS.RHKreinFourierFactorV1.angular_integral
#print axioms AEGIS.RHKreinFourierFactorV1.angular_krein_pairing
#print axioms AEGIS.RHKreinFourierFactorV1.fourier_differential_factor

#print axioms AEGIS.RHKreinFourierFactorV1.actual_packet_fourier_factor
~~~~~~

## RHKreinSymbolIntegrationV1

Path: `source/RHKreinSymbolIntegrationV1.lean`

Original source lines: 1–820

Full file SHA256: `88e9c16b5c4dff59b0f39d34f453667f69c3484b4544375944d844fb60382b63`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinSymbolIntegrationV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import WeilFixedLineCompletedGammaV10
import WeilAutocorrelationExplicitFormulaV10
import RHKreinCriticalLineBridgeV1

/-!
# Critical-line Archimedean identity for the actual Weil form

The V10 Gauss integral proofs require only a positive real part. This module
extends their stated `1 < c` domain to `0 < c`, using the same integrable
majorant and the same repository paired Mellin profile. It then specializes
to `c = 1/2` and the actual multiplicative autocorrelation. No positivity,
pointwise symbol certificate, or RH conclusion is assumed or asserted.

Source: AEGIS-OMEGA `2c3d041b633147ec97c7ef753aa9d157a47bb9f5`,
`WeilFixedLineGammaFubiniV10`, `WeilFixedLineGammaAssemblyV10`, and
`WeilFixedLineCompletedGammaV10`.
-/

open Set Filter Topology MeasureTheory Complex FourierTransform
open scoped Topology
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaFubiniV10

open AEGIS.WeilDigammaIntegralReductionV1

def WeilGaussFixedLineKernelV10
    (f : WeilCompactSmoothGV1) (c : ℝ) (p : ℝ × ℝ) : ℂ :=
  gaussIntegrand
      ((((c : ℂ) + (p.1 : ℂ) * I) / 2))
      p.2 *
    WeilPairedMellinProfileV5 f c p.1

private theorem one_sub_exp_neg_lower_v10 {u : ℝ} (hu : 0 < u) :
    u / (1 + u) ≤ 1 - Real.exp (-u) := by
  have h1u : 0 < 1 + u := by linarith
  have hexp : 1 + u ≤ Real.exp u := by
    simpa [add_comm] using Real.add_one_le_exp u
  have hinv : Real.exp (-u) ≤ 1 / (1 + u) := by
    rw [Real.exp_neg]
    simpa [one_div] using one_div_le_one_div_of_le h1u hexp
  calc
    u / (1 + u) = 1 - 1 / (1 + u) := by
      field_simp [h1u.ne']
      ring
    _ ≤ 1 - Real.exp (-u) := sub_le_sub_left hinv 1

private theorem gauss_denominator_norm_lower_v10 {u : ℝ} (hu : 0 < u) :
    u / (1 + u) ≤
      ‖1 - Complex.exp (-(u : ℂ))‖ := by
  have hexplt : Real.exp (-u) < 1 :=
    Real.exp_lt_one_iff.mpr (by linarith)
  have hnorm :
      ‖1 - Complex.exp (-(u : ℂ))‖ =
        1 - Real.exp (-u) := by
    rw [← Complex.ofReal_neg, ← Complex.ofReal_exp, ← Complex.ofReal_one,
      ← Complex.ofReal_sub, Complex.norm_real]
    exact Real.norm_of_nonneg (sub_nonneg.mpr hexplt.le)
  rw [hnorm]
  exact one_sub_exp_neg_lower_v10 hu

private theorem half_line_shift_norm_le_v10 (c t : ℝ) :
    ‖(((c : ℂ) + (t : ℂ) * I) / 2) - 1‖
      ≤ |c / 2 - 1| + |t| := by
  have hsplit :
      (((c : ℂ) + (t : ℂ) * I) / 2) - 1 =
        ((c / 2 - 1 : ℝ) : ℂ) +
          ((t / 2 : ℝ) : ℂ) * I := by
    apply Complex.ext <;> simp
  rw [hsplit]
  calc
    ‖((c / 2 - 1 : ℝ) : ℂ) + ((t / 2 : ℝ) : ℂ) * I‖
        ≤ ‖((c / 2 - 1 : ℝ) : ℂ)‖ +
            ‖((t / 2 : ℝ) : ℂ) * I‖ := norm_add_le _ _
    _ = |c / 2 - 1| + |t / 2| := by
        rw [Complex.norm_real, norm_mul, Complex.norm_I, mul_one, Complex.norm_real,
          Real.norm_eq_abs, Real.norm_eq_abs]
    _ ≤ |c / 2 - 1| + |t| := by
        have ht : |t / 2| ≤ |t| := by
          rw [abs_div]
          norm_num
        linarith

/-- Global Gauss-kernel majorant on the fixed line. -/
theorem gauss_fixed_line_norm_le_v10
    (c t : ℝ) {u : ℝ} (hc : 0 < c) (hu : 0 < u) :
    ‖gaussIntegrand
        ((((c : ℂ) + (t : ℂ) * I) / 2)) u‖
      ≤
      2 * (1 + |c / 2 - 1| + |t|) *
        (1 + u) *
        Real.exp (-(min 1 (c / 2) * u)) := by
  let z : ℂ := (((c : ℂ) + (t : ℂ) * I) / 2)
  let m : ℝ := min 1 (c / 2)
  have hm : 0 < m := by
    dsimp [m]
    exact lt_min one_pos (by linarith)
  have hzre : z.re = c / 2 := by
    dsimp [z]
    simp
  have hnum :=
    norm_exp_diff_le z hu
  have hzbound :
      1 + ‖z - 1‖ ≤ 1 + |c / 2 - 1| + |t| := by
    dsimp [z]
    linarith [half_line_shift_norm_le_v10 c t]
  have hnum' :
      ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
        ≤
        2 * (1 + |c / 2 - 1| + |t|) *
          u * Real.exp (-(m * u)) := by
    calc
      ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
          ≤ 2 * (1 + ‖z - 1‖) * u *
              Real.exp (-(min 1 z.re * u)) := hnum
      _ ≤ 2 * (1 + |c / 2 - 1| + |t|) * u *
              Real.exp (-(m * u)) := by
          rw [hzre]
          dsimp [m]
          gcongr
  have hden :=
    gauss_denominator_norm_lower_v10 hu
  have hsmallpos : 0 < u / (1 + u) := by positivity
  have hdenpos :
      0 < ‖1 - Complex.exp (-(u : ℂ))‖ :=
    hsmallpos.trans_le hden
  unfold gaussIntegrand
  rw [norm_div]
  calc
    ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖ /
          ‖1 - Complex.exp (-(u : ℂ))‖
        ≤
      (2 * (1 + |c / 2 - 1| + |t|) *
          u * Real.exp (-(m * u))) /
        (u / (1 + u)) := by
          apply div_le_div₀
          · positivity
          · exact hnum'
          · exact hsmallpos
          · exact hden
    _ =
      2 * (1 + |c / 2 - 1| + |t|) *
        (1 + u) * Real.exp (-(m * u)) := by
          field_simp [hu.ne', (by linarith : (1 + u) ≠ 0)]
    _ =
      2 * (1 + |c / 2 - 1| + |t|) *
        (1 + u) *
        Real.exp (-(min 1 (c / 2) * u)) := by rfl

private theorem gamma_u_majorant_integrable_v10
    (c : ℝ) (hc : 0 < c) :
    Integrable
      (fun u : ℝ =>
        (1 + u) * Real.exp (-(min 1 (c / 2) * u)))
      (volume.restrict (Ioi (0 : ℝ))) := by
  let m : ℝ := min 1 (c / 2)
  have hm : 0 < m := by
    dsimp [m]
    exact lt_min one_pos (by linarith)
  have h0 :
      IntegrableOn
        (fun u : ℝ => Real.exp (-m * u))
        (Ioi (0 : ℝ)) := by
    simpa [neg_mul] using
      (integrableOn_exp_mul_Ioi (a := -m) (by linarith) 0)
  have h1 :
      IntegrableOn
        (fun u : ℝ => u * Real.exp (-(m * u)))
        (Ioi (0 : ℝ)) := by
    have hI :=
      integrableOn_rpow_mul_exp_neg_mul_rpow (s := 1) (p := 1) (b := m)
        (by norm_num) (by norm_num) hm
    refine hI.congr_fun (fun u _ => ?_) measurableSet_Ioi
    simp [Real.rpow_one]
  refine (h0.add h1).congr (Filter.Eventually.of_forall fun u => ?_)
  simp only [Pi.add_apply, m, neg_mul]
  ring

private theorem gamma_t_majorant_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) :
    Integrable
      (fun t : ℝ =>
        (1 + |c / 2 - 1| + |t|) *
          ‖WeilPairedMellinProfileV5 f c t‖) := by
  have hH :=
    weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c
  let A : ℝ := 1 + |c / 2 - 1|
  have h0 :
      Integrable
        (fun t : ℝ =>
          A * ‖WeilPairedMellinProfileV5 f c t‖) :=
    hH.1.norm.const_mul A
  have h1 :
      Integrable
        (fun t : ℝ =>
          |t| * ‖WeilPairedMellinProfileV5 f c t‖) :=
    hH.2.1
  refine (h0.add h1).congr (Filter.Eventually.of_forall fun t => ?_)
  simp only [Pi.add_apply, A]
  ring

/-- Absolute product-integrability of the Gauss kernel against the actual V5
paired Mellin profile. -/
theorem weil_gauss_fixed_line_kernel_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 0 < c) :
    Integrable
      (WeilGaussFixedLineKernelV10 f c)
      (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
  let T : ℝ → ℝ := fun t =>
    (1 + |c / 2 - 1| + |t|) *
      ‖WeilPairedMellinProfileV5 f c t‖
  let U : ℝ → ℝ := fun u =>
    (1 + u) * Real.exp (-(min 1 (c / 2) * u))
  have hT : Integrable T := by
    exact gamma_t_majorant_integrable_v10 f c
  have hU :
      Integrable U (volume.restrict (Ioi (0 : ℝ))) := by
    exact gamma_u_majorant_integrable_v10 c hc
  have hmajor :
      Integrable
        (fun p : ℝ × ℝ => 2 * T p.1 * U p.2)
        (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
    exact (hT.const_mul 2).mul_prod hU
  have hmeas :
      AEStronglyMeasurable
        (WeilGaussFixedLineKernelV10 f c)
        (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
    unfold WeilGaussFixedLineKernelV10
    have hH :=
      (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
    have hHm :
        AEStronglyMeasurable
          (fun p : ℝ × ℝ =>
            WeilPairedMellinProfileV5 f c p.1)
          (volume.prod (volume.restrict (Ioi (0 : ℝ)))) :=
      hH.aestronglyMeasurable.comp_fst
    have hGm :
        AEStronglyMeasurable
          (fun p : ℝ × ℝ =>
            gaussIntegrand
              ((((c : ℂ) + (p.1 : ℂ) * I) / 2)) p.2)
          (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
      apply Measurable.aestronglyMeasurable
      unfold gaussIntegrand
      fun_prop
    exact hGm.mul hHm
  refine hmajor.mono' hmeas ?_
  have hpos_ae :
      ∀ᵐ p : ℝ × ℝ ∂(volume.prod (volume.restrict (Ioi (0 : ℝ)))), 0 < p.2 := by
    change ∀ᵐ p : ℝ × ℝ ∂(volume.prod (volume.restrict (Ioi (0 : ℝ)))),
        p ∈ Prod.snd ⁻¹' Ioi (0 : ℝ)
    rw [Measure.ae_prod_mem_iff_ae_ae_mem
      (measurable_snd measurableSet_Ioi)]
    exact Filter.Eventually.of_forall (fun _ => by
      rw [ae_restrict_iff' measurableSet_Ioi]
      exact Filter.Eventually.of_forall (fun u hu => hu))
  filter_upwards [hpos_ae] with p hp
  have hu : 0 < p.2 := hp
  unfold WeilGaussFixedLineKernelV10
  rw [norm_mul]
  have hg :=
    gauss_fixed_line_norm_le_v10 c p.1 hc hu
  calc
      ‖gaussIntegrand
          ((((c : ℂ) + (p.1 : ℂ) * I) / 2)) p.2‖ *
          ‖WeilPairedMellinProfileV5 f c p.1‖
        ≤
        (2 * (1 + |c / 2 - 1| + |p.1|) *
          (1 + p.2) *
          Real.exp (-(min 1 (c / 2) * p.2))) *
          ‖WeilPairedMellinProfileV5 f c p.1‖ := by
          gcongr
    _ = 2 * T p.1 * U p.2 := by
          simp [T, U]
          ring

/-- The actual Gauss-kernel t/u Fubini swap. -/
theorem weil_gauss_fixed_line_fubini_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 0 < c) :
    (∫ t : ℝ,
      ∫ u : ℝ in Ioi (0 : ℝ),
        WeilGaussFixedLineKernelV10 f c (t, u)) =
      ∫ u : ℝ in Ioi (0 : ℝ),
        ∫ t : ℝ,
          WeilGaussFixedLineKernelV10 f c (t, u) := by
  have hprod :=
    weil_gauss_fixed_line_kernel_integrable_v10 f c hc
  simpa [Function.uncurry_def] using
    (integral_integral_swap
      (μ := volume) (ν := volume.restrict (Ioi (0 : ℝ)))
      (f := fun t u => WeilGaussFixedLineKernelV10 f c (t, u))
      hprod)

end AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaFubiniV10


namespace AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaAssemblyV10

open AEGIS.WeilDigammaIntegralReductionV1
open AEGIS.WeilDigammaSeriesHalfPlaneV1
open AEGIS.WeilFixedLineGammaCoreV10
open AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaFubiniV10

local notation "γ" => Real.eulerMascheroniConstant

private theorem paired_exp_profile_integrable_v10
    (f : WeilCompactSmoothGV1) (c u : ℝ) :
    Integrable
      (fun t : ℝ =>
        Complex.exp
          (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))) *
          WeilPairedMellinProfileV5 f c t) := by
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  let C : ℝ := Real.exp (-(c * (u / 2)))
  have hC : 0 ≤ C := (Real.exp_pos _).le
  have hmajor :
      Integrable
        (fun t : ℝ =>
          C * ‖WeilPairedMellinProfileV5 f c t‖) :=
    hH.norm.const_mul C
  have hExpCont :
      Continuous
        (fun t : ℝ =>
          Complex.exp
            (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ)))) := by
    fun_prop
  have hmeas :
      AEStronglyMeasurable
        (fun t : ℝ =>
          Complex.exp
            (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))) *
            WeilPairedMellinProfileV5 f c t) :=
    hExpCont.aestronglyMeasurable.mul hH.aestronglyMeasurable
  refine hmajor.mono' hmeas (Filter.Eventually.of_forall fun t => ?_)
  rw [norm_mul, Complex.norm_exp]
  have hre :
      (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))).re =
        -(c * (u / 2)) := by
    simp
  rw [hre]

/-- Evaluate the u-integral first using the newly source-closed Gauss formula. -/
theorem weil_gauss_kernel_inner_u_v10
    (f : WeilCompactSmoothGV1) (c t : ℝ) (hc : 0 < c) :
    (∫ u : ℝ in Ioi (0 : ℝ),
      WeilGaussFixedLineKernelV10 f c (t, u)) =
      (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
        WeilPairedMellinProfileV5 f c t := by
  have hz :
      0 <
        ((((c : ℂ) + (t : ℂ) * I) / 2)).re := by
    simp
    linarith
  unfold WeilGaussFixedLineKernelV10
  dsimp only
  rw [integral_mul_const]
  rw [← gauss_digamma_integral_v1
    ((((c : ℂ) + (t : ℂ) * I) / 2)) hz]

/-- Evaluate the normalized t-integral of the Gauss kernel at fixed u. -/
theorem weil_gauss_kernel_inner_t_normalized_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) {u : ℝ}
    (hu : 0 < u) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        WeilGaussFixedLineKernelV10 f c (t, u)) =
      (Complex.exp (-(u : ℂ)) * (2 * f.1 1) -
        (WeilPairedTestV8 f).1 (Real.exp (u / 2))) /
        (1 - Complex.exp (-(u : ℂ))) := by
  let H : ℝ → ℂ := WeilPairedMellinProfileV5 f c
  let E : ℝ → ℂ := fun t =>
    Complex.exp
      (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ)))
  let a : ℂ := Complex.exp (-(u : ℂ))
  let d : ℂ := 1 - Complex.exp (-(u : ℂ))
  have hd : d ≠ 0 := by
    have hlt : Real.exp (-u) < 1 := Real.exp_lt_one_iff.mpr (by linarith)
    dsimp [d]
    rw [← Complex.ofReal_neg, ← Complex.ofReal_exp, ← Complex.ofReal_one,
      ← Complex.ofReal_sub]
    exact_mod_cast (sub_pos.mpr hlt).ne'
  have hH : Integrable H := by
    exact (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  have hE : Integrable (fun t => E t * H t) := by
    exact paired_exp_profile_integrable_v10 f c u
  have h1 : Integrable (fun t => (a / d) * H t) :=
    hH.const_mul (a / d)
  have h2 : Integrable (fun t => (1 / d) * (E t * H t)) :=
    hE.const_mul (1 / d)
  have hshape :
      (fun t : ℝ => WeilGaussFixedLineKernelV10 f c (t, u)) =
        fun t => (a / d) * H t - (1 / d) * (E t * H t) := by
    funext t
    unfold WeilGaussFixedLineKernelV10 gaussIntegrand
    dsimp only
    have hexp :
        Complex.exp (-((((c : ℂ) + (t : ℂ) * I) / 2)) * (u : ℂ)) = E t := by
      dsimp [E]
      congr 1
      push_cast
      ring
    rw [hexp]
    dsimp [H, a, d]
    field_simp
  rw [hshape, integral_sub h1 h2, integral_const_mul, integral_const_mul]
  have hHnorm :=
    weil_paired_profile_integral_one_v10 f c
  have hEnorm :=
    weil_paired_profile_exp_half_integral_v10 f c u
  rw [← hHnorm, ← hEnorm]
  have hd' : (1 - Complex.exp (-(u : ℂ))) ≠ 0 := hd
  have hpi : ((Real.pi : ℝ) : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr Real.pi_ne_zero
  simp only [H, E, a, d]
  field_simp
  congr 2
  funext t
  ring_nf

/-- Fubini plus both inner evaluations: the normalized fixed-line
`ψ+γ` contribution equals the exact u-space paired-test integral. -/
theorem weil_fixed_line_digamma_plus_gamma_log_integral_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 0 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t) =
      ∫ u : ℝ in Ioi (0 : ℝ),
        (Complex.exp (-(u : ℂ)) * (2 * f.1 1) -
          (WeilPairedTestV8 f).1 (Real.exp (u / 2))) /
          (1 - Complex.exp (-(u : ℂ))) := by
  have hfub :=
    weil_gauss_fixed_line_fubini_v10 f c hc
  have hleft :
      (∫ t : ℝ,
        ∫ u : ℝ in Ioi (0 : ℝ),
          WeilGaussFixedLineKernelV10 f c (t, u)) =
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t := by
    apply integral_congr_ae
    exact Filter.Eventually.of_forall (fun t =>
      weil_gauss_kernel_inner_u_v10 f c t hc)
  rw [hleft] at hfub
  calc
    (1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t
      =
      (1 / (2 * Real.pi) : ℂ) *
        ∫ u : ℝ in Ioi (0 : ℝ),
          ∫ t : ℝ,
            WeilGaussFixedLineKernelV10 f c (t, u) := by
        rw [hfub]
    _ =
      ∫ u : ℝ in Ioi (0 : ℝ),
        (Complex.exp (-(u : ℂ)) * (2 * f.1 1) -
          (WeilPairedTestV8 f).1 (Real.exp (u / 2))) /
          (1 - Complex.exp (-(u : ℂ))) := by
        rw [← integral_const_mul]
        apply setIntegral_congr_fun measurableSet_Ioi
        intro u hu
        rw [mem_Ioi] at hu
        exact weil_gauss_kernel_inner_t_normalized_v10 f c hu

end AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaAssemblyV10


namespace AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaXSpaceV10
open AEGIS.WeilFixedLineGammaXSpaceV10
open AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaAssemblyV10
local notation "γ" => Real.eulerMascheroniConstant

theorem half_fixed_line_digamma_plus_gamma_eq_arch_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 0 < c) :
    (1 / 2 : ℂ) *
      ((1 / (2 * Real.pi) : ℂ) *
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) =
      -WeilArchimedeanIntegralV1 f.1 -
        ((2 * Real.log 2 : ℝ) : ℂ) * f.1 1 := by
  have hlog :=
    weil_fixed_line_digamma_plus_gamma_log_integral_v10 f c hc
  have hlog' :
      ((1 / (2 * Real.pi) : ℂ) *
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) =
        ∫ u : ℝ in Ioi (0 : ℝ),
          WeilGammaLogIntegrandV10 f u := by
    simpa [WeilGammaLogIntegrandV10] using hlog
  rw [hlog']
  rw [half_gamma_log_integral_eq_x_integral_v10]
  exact gamma_x_integral_eq_arch_v10 f

end AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaXSpaceV10


namespace AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineCompletedGammaV10

open AEGIS.WeilFixedLineGammaCoreV10
open AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaFubiniV10
open AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaAssemblyV10
open AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineGammaXSpaceV10

local notation "γ" => Real.eulerMascheroniConstant

open AEGIS.WeilFixedLineCompletedGammaV10

private theorem log_four_pi_normalization_v10 :
    2 * Real.log 2 + Real.log Real.pi =
      Real.log (4 * Real.pi) := by
  have hlog4 : Real.log (4 : ℝ) = 2 * Real.log 2 := by
    calc
      Real.log (4 : ℝ) = Real.log ((2 : ℝ) * 2) := by norm_num
      _ = Real.log 2 + Real.log 2 := by
        rw [Real.log_mul] <;> norm_num
      _ = 2 * Real.log 2 := by ring
  calc
    2 * Real.log 2 + Real.log Real.pi
      = Real.log 4 + Real.log Real.pi := by rw [hlog4]
    _ = Real.log (4 * Real.pi) := by
      rw [Real.log_mul] <;> positivity

private theorem digamma_plus_gamma_profile_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 0 < c) :
    Integrable
      (fun t : ℝ =>
        (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t) := by
  have hprod :=
    weil_gauss_fixed_line_kernel_integrable_v10 f c hc
  have hinner :
      Integrable
        (fun t : ℝ =>
          ∫ u : ℝ in Ioi (0 : ℝ),
            WeilGaussFixedLineKernelV10 f c (t, u)) :=
    hprod.integral_prod_left
  exact hinner.congr
    (Filter.Eventually.of_forall fun t =>
      weil_gauss_kernel_inner_u_v10 f c t hc)

private theorem completed_gamma_pointwise_split_v10
    (f : WeilCompactSmoothGV1) (c t : ℝ) :
    WeilCompletedGammaFactorV10 c t *
        WeilPairedMellinProfileV5 f c t =
      (1 / 2 : ℂ) *
        ((Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t) -
      (1 / 2 : ℂ) *
        (((Real.log Real.pi + γ : ℝ) : ℂ) *
          WeilPairedMellinProfileV5 f c t) := by
  unfold WeilCompletedGammaFactorV10
  push_cast
  ring

/-- Public integrability surface for the completed-gamma contribution.
This exposes an obligation already discharged internally by the Gauss-kernel
product-integrability proof. -/
theorem weil_fixed_line_completed_gamma_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 0 < c) :
    Integrable
      (fun t : ℝ =>
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t) := by
  have hplus :=
    digamma_plus_gamma_profile_integrable_v10 f c hc
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  have hA :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            ((Complex.digamma
              ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
              WeilPairedMellinProfileV5 f c t)) :=
    hplus.const_mul (1 / 2 : ℂ)
  have hB :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            (((Real.log Real.pi + γ : ℝ) : ℂ) *
              WeilPairedMellinProfileV5 f c t)) := by
    exact
      (hH.const_mul (((Real.log Real.pi + γ : ℝ) : ℂ))).const_mul
        (1 / 2 : ℂ)
  exact (hA.sub hB).congr
    (Filter.Eventually.of_forall fun t =>
      (completed_gamma_pointwise_split_v10 f c t).symm)

/-- Exact repository-native completed-gamma contribution. -/
theorem weil_fixed_line_completed_gamma_eq_archimedean_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 0 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t) =
      -WeilArchimedeanConstantV1 * f.1 1 -
        WeilArchimedeanIntegralV1 f.1 := by
  have hplus :=
    digamma_plus_gamma_profile_integrable_v10 f c hc
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  have hA :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            ((Complex.digamma
              ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
              WeilPairedMellinProfileV5 f c t)) :=
    hplus.const_mul (1 / 2 : ℂ)
  have hB :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            (((Real.log Real.pi + γ : ℝ) : ℂ) *
              WeilPairedMellinProfileV5 f c t)) := by
    exact
      (hH.const_mul (((Real.log Real.pi + γ : ℝ) : ℂ))).const_mul
        (1 / 2 : ℂ)
  have hsplit :
      (∫ t : ℝ,
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t) =
      (∫ t : ℝ,
        (1 / 2 : ℂ) *
          ((Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t)) -
      (∫ t : ℝ,
        (1 / 2 : ℂ) *
          (((Real.log Real.pi + γ : ℝ) : ℂ) *
            WeilPairedMellinProfileV5 f c t)) := by
    calc
      (∫ t : ℝ,
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t)
        =
      ∫ t : ℝ,
        ((1 / 2 : ℂ) *
          ((Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) -
        (1 / 2 : ℂ) *
          (((Real.log Real.pi + γ : ℝ) : ℂ) *
            WeilPairedMellinProfileV5 f c t)) := by
          apply integral_congr_ae
          exact Filter.Eventually.of_forall
            (fun t => completed_gamma_pointwise_split_v10 f c t)
      _ = _ := integral_sub hA hB
  rw [hsplit, integral_const_mul, integral_const_mul,
    integral_const_mul]
  have hhalf :=
    half_fixed_line_digamma_plus_gamma_eq_arch_v10 f c hc
  have hprofile :=
    weil_paired_profile_integral_one_v10 f c
  have hlognorm := log_four_pi_normalization_v10
  unfold WeilArchimedeanConstantV1
  calc
    (1 / (2 * Real.pi) : ℂ) *
      (((1 / 2 : ℂ) *
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) -
        (1 / 2 : ℂ) *
          (((Real.log Real.pi + γ : ℝ) : ℂ) *
            ∫ t : ℝ, WeilPairedMellinProfileV5 f c t))
      =
      ((1 / 2 : ℂ) *
        ((1 / (2 * Real.pi) : ℂ) *
          ∫ t : ℝ,
            (Complex.digamma
              ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
              WeilPairedMellinProfileV5 f c t)) -
      (1 / 2 : ℂ) *
        (((Real.log Real.pi + γ : ℝ) : ℂ) *
          ((1 / (2 * Real.pi) : ℂ) *
            ∫ t : ℝ, WeilPairedMellinProfileV5 f c t)) := by
          ring
    _ =
      (-WeilArchimedeanIntegralV1 f.1 -
        ((2 * Real.log 2 : ℝ) : ℂ) * f.1 1) -
      (((Real.log Real.pi + γ : ℝ) : ℂ) * f.1 1) := by
          rw [hhalf, hprofile]
          ring
    _ =
      -(((Real.log (4 * Real.pi) + γ : ℝ) : ℂ)) * f.1 1 -
        WeilArchimedeanIntegralV1 f.1 := by
          rw [← hlognorm]
          push_cast
          ring

end AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineCompletedGammaV10

namespace AEGIS.RHKreinSymbolIntegrationV1

open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.RHKreinCriticalLineBridgeV1
open AEGIS.WeilFixedLineCompletedGammaV10

/-- The two actual critical-line autocorrelation Mellin values, expressed
using Mathlib's Fourier convention. -/
def criticalSpectralMass (g : WeilCompactSmoothGV1) (t : ℝ) : ℝ :=
  Complex.normSq (𝓕 (logLift g.1) (-t / (2 * Real.pi))) +
    Complex.normSq (𝓕 (logLift g.1) (-(-t) / (2 * Real.pi)))

/-- The Archimedean part of the angular-frequency numerical symbol. -/
def archSymbol (t : ℝ) : ℝ :=
  (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * I / 2)).re - Real.log Real.pi

theorem paired_autocorrelation_eq_criticalSpectralMass
    (g : WeilCompactSmoothGV1) (t : ℝ) :
    WeilPairedMellinProfileV5 (WeilAutocorrelationCompactSmoothV1 g) (1 / 2) t =
      (criticalSpectralMass g t : ℂ) := by
  change mellin (WeilAutocorrelationV1 g) (((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) +
    mellin (WeilAutocorrelationV1 g)
      (((1 - 1 / 2 : ℝ) : ℂ) + ((-t : ℝ) : ℂ) * I) = _
  rw [show (1 - 1 / 2 : ℝ) = 1 / 2 by norm_num,
    autocorrelation_mellin_critical_normSq_v1 g t,
    autocorrelation_mellin_critical_normSq_v1 g (-t)]
  simp only [criticalSpectralMass, Complex.ofReal_add]

theorem completed_gamma_critical_real (t : ℝ) :
    (WeilCompletedGammaFactorV10 (1 / 2) t).re = (1 / 2) * archSymbol t := by
  have hz : ((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) / 2) =
      (1 / 4 : ℂ) + (t : ℂ) * I / 2 := by push_cast; ring
  simp only [WeilCompletedGammaFactorV10, hz, archSymbol]
  simp
  ring

/-- The actual arithmetic form, with its Archimedean part represented on the
critical line. The prime sum is unchanged. -/
theorem actual_arithmetic_eq_prime_sub_critical_gamma
    (g : WeilCompactSmoothGV1) :
    WeilExplicitRightSideV1 (WeilAutocorrelationV1 g) =
      WeilPrimeSumV1 (WeilAutocorrelationV1 g) -
        (1 / (2 * Real.pi) : ℂ) *
          ∫ t : ℝ, WeilCompletedGammaFactorV10 (1 / 2) t *
            (criticalSpectralMass g t : ℂ) := by
  have h := WeilFixedLineCompletedGammaV10.weil_fixed_line_completed_gamma_eq_archimedean_v10
    (WeilAutocorrelationCompactSmoothV1 g) (1 / 2) (by norm_num)
  simp_rw [paired_autocorrelation_eq_criticalSpectralMass] at h
  change (1 / (2 * Real.pi) : ℂ) *
      (∫ t : ℝ, WeilCompletedGammaFactorV10 (1 / 2) t *
        (criticalSpectralMass g t : ℂ)) =
    -WeilArchimedeanConstantV1 * WeilAutocorrelationV1 g 1 -
      WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g) at h
  rw [h]
  unfold WeilExplicitRightSideV1
  ring

/-- Exact real Archimedean symbol identity for the actual repository form.
The factor `1/(4*pi)` multiplies the sum of both frequency masses. -/
theorem actual_arithmetic_real_eq_prime_sub_archSymbol
    (g : WeilCompactSmoothGV1) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re =
      (WeilPrimeSumV1 (WeilAutocorrelationV1 g)).re -
        (1 / (4 * Real.pi)) *
          ∫ t : ℝ, archSymbol t * criticalSpectralMass g t := by
  have hI := WeilFixedLineCompletedGammaV10.weil_fixed_line_completed_gamma_integrable_v10
    (WeilAutocorrelationCompactSmoothV1 g) (1 / 2) (by norm_num)
  simp_rw [paired_autocorrelation_eq_criticalSpectralMass] at hI
  have hpoint : ∀ t : ℝ,
      (WeilCompletedGammaFactorV10 (1 / 2) t *
        (criticalSpectralMass g t : ℂ)).re =
      (1 / 2) * (archSymbol t * criticalSpectralMass g t) := by
    intro t
    rw [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero,
      completed_gamma_critical_real]
    ring
  have hreal :
      (∫ t : ℝ, WeilCompletedGammaFactorV10 (1 / 2) t *
        (criticalSpectralMass g t : ℂ)).re =
      (1 / 2) * ∫ t : ℝ, archSymbol t * criticalSpectralMass g t := by
    have hre := (integral_re hI).symm
    simp only [RCLike.re_to_complex] at hre
    rw [hre]
    simp_rw [hpoint]
    rw [integral_const_mul]
  rw [actual_arithmetic_eq_prime_sub_critical_gamma]
  rw [Complex.sub_re, Complex.mul_re]
  have hscalar : (1 / (2 * Real.pi) : ℂ) = ((1 / (2 * Real.pi) : ℝ) : ℂ) := by
    push_cast
    rfl
  rw [hscalar, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero, hreal]
  ring

end AEGIS.RHKreinSymbolIntegrationV1

#print axioms AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineCompletedGammaV10.weil_fixed_line_completed_gamma_eq_archimedean_v10
#print axioms AEGIS.RHKreinSymbolIntegrationV1.actual_arithmetic_eq_prime_sub_critical_gamma
#print axioms AEGIS.RHKreinSymbolIntegrationV1.actual_arithmetic_real_eq_prime_sub_archSymbol
~~~~~~

## WeilFixedLineCompletedGammaV10

Path: `source/WeilFixedLineCompletedGammaV10.lean`

Original source lines: 1–230

Full file SHA256: `99ad2a46996a0adcf68e99288c8eebc0c5c12787d88b5675712464e8512b9dc6`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineCompletedGammaV10.lean

~~~~~~lean
import WeilFixedLineGammaXSpaceV10
import WeilFixedLineGammaFubiniV10

/-!
AEGIS Ω — completed-gamma fixed-line normalization V10.

This is the repository-native closure of the gamma/digamma term in the
logarithmic derivative of the completed xi function:

  -1/2 log pi + 1/2 psi(s/2).

Using the source-closed Gauss integral, V10 Fubini closure, x-space
normalization, and the existing paired-profile integral at 1, the normalized
fixed-line integral is exactly

  - WeilArchimedeanConstantV1 * f(1)
  - WeilArchimedeanIntegralV1 f.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology MeasureTheory Complex
open scoped Topology

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilFixedLineCompletedGammaV10

open AEGIS.WeilFixedLineGammaCoreV10
open AEGIS.WeilFixedLineGammaFubiniV10
open AEGIS.WeilFixedLineGammaAssemblyV10
open AEGIS.WeilFixedLineGammaXSpaceV10

local notation "γ" => Real.eulerMascheroniConstant

def WeilCompletedGammaFactorV10 (c t : ℝ) : ℂ :=
  -(((Real.log Real.pi : ℝ) : ℂ) / 2) +
    (1 / 2 : ℂ) *
      Complex.digamma ((((c : ℂ) + (t : ℂ) * I) / 2))

private theorem log_four_pi_normalization_v10 :
    2 * Real.log 2 + Real.log Real.pi =
      Real.log (4 * Real.pi) := by
  have hlog4 : Real.log (4 : ℝ) = 2 * Real.log 2 := by
    calc
      Real.log (4 : ℝ) = Real.log ((2 : ℝ) * 2) := by norm_num
      _ = Real.log 2 + Real.log 2 := by
        rw [Real.log_mul] <;> norm_num
      _ = 2 * Real.log 2 := by ring
  calc
    2 * Real.log 2 + Real.log Real.pi
      = Real.log 4 + Real.log Real.pi := by rw [hlog4]
    _ = Real.log (4 * Real.pi) := by
      rw [Real.log_mul] <;> positivity

private theorem digamma_plus_gamma_profile_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    Integrable
      (fun t : ℝ =>
        (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t) := by
  have hprod :=
    weil_gauss_fixed_line_kernel_integrable_v10 f c hc
  have hinner :
      Integrable
        (fun t : ℝ =>
          ∫ u : ℝ in Ioi (0 : ℝ),
            WeilGaussFixedLineKernelV10 f c (t, u)) :=
    hprod.integral_prod_left
  exact hinner.congr
    (Filter.Eventually.of_forall fun t =>
      weil_gauss_kernel_inner_u_v10 f c t hc)

private theorem completed_gamma_pointwise_split_v10
    (f : WeilCompactSmoothGV1) (c t : ℝ) :
    WeilCompletedGammaFactorV10 c t *
        WeilPairedMellinProfileV5 f c t =
      (1 / 2 : ℂ) *
        ((Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t) -
      (1 / 2 : ℂ) *
        (((Real.log Real.pi + γ : ℝ) : ℂ) *
          WeilPairedMellinProfileV5 f c t) := by
  unfold WeilCompletedGammaFactorV10
  push_cast
  ring

/-- Public integrability surface for the completed-gamma contribution.
This exposes an obligation already discharged internally by the Gauss-kernel
product-integrability proof. -/
theorem weil_fixed_line_completed_gamma_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    Integrable
      (fun t : ℝ =>
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t) := by
  have hplus :=
    digamma_plus_gamma_profile_integrable_v10 f c hc
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  have hA :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            ((Complex.digamma
              ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
              WeilPairedMellinProfileV5 f c t)) :=
    hplus.const_mul (1 / 2 : ℂ)
  have hB :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            (((Real.log Real.pi + γ : ℝ) : ℂ) *
              WeilPairedMellinProfileV5 f c t)) := by
    exact
      (hH.const_mul (((Real.log Real.pi + γ : ℝ) : ℂ))).const_mul
        (1 / 2 : ℂ)
  exact (hA.sub hB).congr
    (Filter.Eventually.of_forall fun t =>
      (completed_gamma_pointwise_split_v10 f c t).symm)

/-- Exact repository-native completed-gamma contribution. -/
theorem weil_fixed_line_completed_gamma_eq_archimedean_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t) =
      -WeilArchimedeanConstantV1 * f.1 1 -
        WeilArchimedeanIntegralV1 f.1 := by
  have hplus :=
    digamma_plus_gamma_profile_integrable_v10 f c hc
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  have hA :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            ((Complex.digamma
              ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
              WeilPairedMellinProfileV5 f c t)) :=
    hplus.const_mul (1 / 2 : ℂ)
  have hB :
      Integrable
        (fun t : ℝ =>
          (1 / 2 : ℂ) *
            (((Real.log Real.pi + γ : ℝ) : ℂ) *
              WeilPairedMellinProfileV5 f c t)) := by
    exact
      (hH.const_mul (((Real.log Real.pi + γ : ℝ) : ℂ))).const_mul
        (1 / 2 : ℂ)
  have hsplit :
      (∫ t : ℝ,
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t) =
      (∫ t : ℝ,
        (1 / 2 : ℂ) *
          ((Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t)) -
      (∫ t : ℝ,
        (1 / 2 : ℂ) *
          (((Real.log Real.pi + γ : ℝ) : ℂ) *
            WeilPairedMellinProfileV5 f c t)) := by
    calc
      (∫ t : ℝ,
        WeilCompletedGammaFactorV10 c t *
          WeilPairedMellinProfileV5 f c t)
        =
      ∫ t : ℝ,
        ((1 / 2 : ℂ) *
          ((Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) -
        (1 / 2 : ℂ) *
          (((Real.log Real.pi + γ : ℝ) : ℂ) *
            WeilPairedMellinProfileV5 f c t)) := by
          apply integral_congr_ae
          exact Filter.Eventually.of_forall
            (fun t => completed_gamma_pointwise_split_v10 f c t)
      _ = _ := integral_sub hA hB
  rw [hsplit, integral_const_mul, integral_const_mul,
    integral_const_mul]
  have hhalf :=
    half_fixed_line_digamma_plus_gamma_eq_arch_v10 f c hc
  have hprofile :=
    weil_paired_profile_integral_one_v10 f c
  have hlognorm := log_four_pi_normalization_v10
  unfold WeilArchimedeanConstantV1
  calc
    (1 / (2 * Real.pi) : ℂ) *
      (((1 / 2 : ℂ) *
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) -
        (1 / 2 : ℂ) *
          (((Real.log Real.pi + γ : ℝ) : ℂ) *
            ∫ t : ℝ, WeilPairedMellinProfileV5 f c t))
      =
      ((1 / 2 : ℂ) *
        ((1 / (2 * Real.pi) : ℂ) *
          ∫ t : ℝ,
            (Complex.digamma
              ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
              WeilPairedMellinProfileV5 f c t)) -
      (1 / 2 : ℂ) *
        (((Real.log Real.pi + γ : ℝ) : ℂ) *
          ((1 / (2 * Real.pi) : ℂ) *
            ∫ t : ℝ, WeilPairedMellinProfileV5 f c t)) := by
          ring
    _ =
      (-WeilArchimedeanIntegralV1 f.1 -
        ((2 * Real.log 2 : ℝ) : ℂ) * f.1 1) -
      (((Real.log Real.pi + γ : ℝ) : ℂ) * f.1 1) := by
          rw [hhalf, hprofile]
          ring
    _ =
      -(((Real.log (4 * Real.pi) + γ : ℝ) : ℂ)) * f.1 1 -
        WeilArchimedeanIntegralV1 f.1 := by
          rw [← hlognorm]
          push_cast
          ring

end AEGIS.WeilFixedLineCompletedGammaV10

#print axioms AEGIS.WeilFixedLineCompletedGammaV10.weil_fixed_line_completed_gamma_eq_archimedean_v10
~~~~~~

## WeilFixedLineGammaXSpaceV10

Path: `source/WeilFixedLineGammaXSpaceV10.lean`

Original source lines: 1–258

Full file SHA256: `0a3ad7a92770bc59c47b9265bcb711b95561d88064a62f34a09a152f32797928`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineGammaXSpaceV10.lean

~~~~~~lean
import WeilArchimedeanCorrectionV10
import WeilFixedLineGammaAssemblyV10
import WeilArchimedeanConvergenceV1
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-!
AEGIS Ω — fixed-line gamma x-space normalization V10.

This module performs the two remaining changes of variables in the normalized
gamma term:

  u = 2v,   x = exp v.

It then uses the repository's existing rational Archimedean integrand identity
and the exact correction integral

  ∫_1^∞ dx / (x(x+1)) = log 2

to obtain the repository-native Archimedean expression.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology MeasureTheory Complex
open scoped Topology

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilFixedLineGammaXSpaceV10

open AEGIS.WeilArchimedeanCorrectionV10
open AEGIS.WeilFixedLineGammaAssemblyV10

local notation "γ" => Real.eulerMascheroniConstant

/-- The exact u-space integrand produced by V10 Fubini assembly. -/
def WeilGammaLogIntegrandV10
    (f : WeilCompactSmoothGV1) (u : ℝ) : ℂ :=
  (Complex.exp (-(u : ℂ)) * (2 * f.1 1) -
      (WeilPairedTestV8 f).1 (Real.exp (u / 2))) /
    (1 - Complex.exp (-(u : ℂ)))

/-- The x-space integrand after u=2v and x=exp(v), including the Jacobian. -/
def WeilGammaXIntegrandV10
    (f : WeilCompactSmoothGV1) (x : ℝ) : ℂ :=
  (((2 : ℂ) * f.1 1) / (x : ℂ) -
      (x : ℂ) * (WeilPairedTestV8 f).1 x) /
    ((x : ℂ) ^ 2 - 1)

/-- The elementary x-space correction separated from the repository
Archimedean integrand. -/
def WeilGammaCorrectionXIntegrandV10
    (f : WeilCompactSmoothGV1) (x : ℝ) : ℂ :=
  ((2 : ℂ) * f.1 1) *
    ((1 / (x * (x + 1)) : ℝ) : ℂ)

/-- Pointwise identity underlying u=2v, x=exp(v). -/
theorem gamma_log_two_mul_eq_exp_smul_x_v10
    (f : WeilCompactSmoothGV1) {v : ℝ} (hv : 0 < v) :
    WeilGammaLogIntegrandV10 f (2 * v) =
      Real.exp v • WeilGammaXIntegrandV10 f (Real.exp v) := by
  let x : ℝ := Real.exp v
  have hxpos : 0 < x := by
    dsimp [x]
    positivity
  have hxgt : 1 < x := by
    dsimp [x]
    have h := Real.exp_lt_exp.mpr hv
    rwa [Real.exp_zero] at h
  have hxC0 : (x : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hxpos.ne'
  have hx2gt : (1 : ℝ) < x ^ 2 := by
    nlinarith
  have hx2neR : x ^ 2 ≠ 1 := ne_of_gt hx2gt
  have hx2neC : (x : ℂ) ^ 2 ≠ 1 := by
    exact_mod_cast hx2neR
  have hxden : (x : ℂ) ^ 2 - 1 ≠ 0 := sub_ne_zero.mpr hx2neC
  have hexpnegR :
      Real.exp (-(2 * v)) = (x⁻¹) ^ 2 := by
    dsimp [x]
    rw [show -(2 * v) = (-v) + (-v) by ring, Real.exp_add,
      Real.exp_neg]
    ring
  have hexpneg :
      Complex.exp (-(((2 * v : ℝ) : ℂ))) =
        ((x : ℂ)⁻¹) ^ 2 := by
    have hcast :=
      congrArg (fun r : ℝ => (r : ℂ)) hexpnegR
    simpa only [Complex.ofReal_exp, Complex.ofReal_neg,
      Complex.ofReal_mul, Complex.ofReal_ofNat,
      Complex.ofReal_inv, Complex.ofReal_pow] using hcast
  have hexphalf :
      Real.exp ((2 * v) / 2) = x := by
    dsimp [x]
    congr 1
    ring
  unfold WeilGammaLogIntegrandV10 WeilGammaXIntegrandV10
  rw [hexpneg, hexphalf, Complex.real_smul]
  have hxe : Real.exp v = x := rfl
  rw [hxe]
  have hxden' : (-1 + (x : ℂ) ^ 2) ≠ 0 := by
    rw [show (-1 + (x : ℂ) ^ 2) = (x : ℂ) ^ 2 - 1 by ring]
    exact hxden
  have hxinv : (1 - ((x : ℂ)⁻¹) ^ 2) ≠ 0 := by
    rw [show (1 - ((x : ℂ)⁻¹) ^ 2) = ((x : ℂ) ^ 2 - 1) / (x : ℂ) ^ 2 by
      field_simp]
    exact div_ne_zero hxden (pow_ne_zero 2 hxC0)
  field_simp

/-- Half of the u-integral is exactly the x-space integral. -/
theorem half_gamma_log_integral_eq_x_integral_v10
    (f : WeilCompactSmoothGV1) :
    (1 / 2 : ℂ) *
        (∫ u : ℝ in Ioi (0 : ℝ), WeilGammaLogIntegrandV10 f u) =
      ∫ x : ℝ in Ioi (1 : ℝ), WeilGammaXIntegrandV10 f x := by
  have hscale :=
    integral_comp_mul_left_Ioi'
      (WeilGammaLogIntegrandV10 f) 0
      (show (0 : ℝ) < 2 by norm_num)
  simp only [mul_zero, Complex.real_smul] at hscale
  calc
    (1 / 2 : ℂ) *
        (∫ u : ℝ in Ioi (0 : ℝ), WeilGammaLogIntegrandV10 f u)
      =
        ∫ v : ℝ in Ioi (0 : ℝ),
          WeilGammaLogIntegrandV10 f (2 * v) := by
            rw [← hscale]
            push_cast
            ring
    _ =
        ∫ v : ℝ in Ioi (0 : ℝ),
          Real.exp v • WeilGammaXIntegrandV10 f (Real.exp v) := by
            apply setIntegral_congr_fun measurableSet_Ioi
            intro v hv
            exact gamma_log_two_mul_eq_exp_smul_x_v10 f hv
    _ =
        ∫ x : ℝ in Ioi (1 : ℝ),
          WeilGammaXIntegrandV10 f x := by
            simpa using integral_comp_exp_Ioi
              (WeilGammaXIntegrandV10 f) 0

/-- Repository-native decomposition of the x-space gamma integrand. -/
theorem gamma_x_integrand_eq_neg_arch_sub_correction_v10
    (f : WeilCompactSmoothGV1) {x : ℝ} (hx : 1 < x) :
    WeilGammaXIntegrandV10 f x =
      -WeilArchimedeanIntegrandV1 f.1 x -
        WeilGammaCorrectionXIntegrandV10 f x := by
  have hx0 : x ≠ 0 := by linarith
  have hx1 : x + 1 ≠ 0 := by linarith
  have hx2 : x ^ 2 - 1 ≠ 0 := by nlinarith
  rw [WeilGammaXIntegrandV10,
    weil_archimedean_integrand_rational_v1 f.1 hx,
    weil_paired_test_apply_v8]
  unfold WeilReciprocalFnV8 WeilGammaCorrectionXIntegrandV10
  push_cast
  have hx0C : (x : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hx0
  have hx1C : (x : ℂ) + 1 ≠ 0 := by exact_mod_cast hx1
  have hx2C : (x : ℂ) ^ 2 - 1 ≠ 0 := by exact_mod_cast hx2
  have hx2C' : (-1 + (x : ℂ) ^ 2) ≠ 0 := by
    rw [show (-1 + (x : ℂ) ^ 2) = (x : ℂ) ^ 2 - 1 by ring]
    exact hx2C
  have hx1C' : (1 + (x : ℂ)) ≠ 0 := by rw [add_comm]; exact hx1C
  field_simp
  ring

theorem gamma_correction_x_integrable_v10
    (f : WeilCompactSmoothGV1) :
    IntegrableOn
      (WeilGammaCorrectionXIntegrandV10 f)
      (Ioi (1 : ℝ)) := by
  unfold WeilGammaCorrectionXIntegrandV10
  exact
    (integrableOn_one_div_mul_one_add_v10.ofReal.const_mul
      ((2 : ℂ) * f.1 1))

theorem gamma_correction_x_integral_v10
    (f : WeilCompactSmoothGV1) :
    (∫ x : ℝ in Ioi (1 : ℝ),
      WeilGammaCorrectionXIntegrandV10 f x) =
      ((2 * Real.log 2 : ℝ) : ℂ) * f.1 1 := by
  unfold WeilGammaCorrectionXIntegrandV10
  rw [integral_const_mul]
  have hI :
      (∫ a : ℝ in Ioi (1 : ℝ), (((1 / (a * (a + 1)) : ℝ)) : ℂ)) =
        (((∫ a : ℝ in Ioi (1 : ℝ), 1 / (a * (a + 1))) : ℝ) : ℂ) :=
    integral_ofReal
  rw [hI, integral_one_div_mul_one_add_v10]
  push_cast
  ring

/-- Exact evaluation of the x-space integrand. -/
theorem gamma_x_integral_eq_arch_v10
    (f : WeilCompactSmoothGV1) :
    (∫ x : ℝ in Ioi (1 : ℝ), WeilGammaXIntegrandV10 f x) =
      -WeilArchimedeanIntegralV1 f.1 -
        ((2 * Real.log 2 : ℝ) : ℂ) * f.1 1 := by
  have harch :=
    weil_compact_smooth_archimedean_integrable_v1 f
  have hcorr :=
    gamma_correction_x_integrable_v10 f
  calc
    (∫ x : ℝ in Ioi (1 : ℝ), WeilGammaXIntegrandV10 f x)
      =
      ∫ x : ℝ in Ioi (1 : ℝ),
        (-WeilArchimedeanIntegrandV1 f.1 x -
          WeilGammaCorrectionXIntegrandV10 f x) := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro x hx
          exact
            gamma_x_integrand_eq_neg_arch_sub_correction_v10
              f hx
    _ =
      (∫ x : ℝ in Ioi (1 : ℝ),
        -WeilArchimedeanIntegrandV1 f.1 x) -
      (∫ x : ℝ in Ioi (1 : ℝ),
        WeilGammaCorrectionXIntegrandV10 f x) := by
          exact integral_sub harch.neg hcorr
    _ =
      -WeilArchimedeanIntegralV1 f.1 -
        ((2 * Real.log 2 : ℝ) : ℂ) * f.1 1 := by
          rw [integral_neg, gamma_correction_x_integral_v10]
          rfl

/-- The normalized half of the (digamma + Euler constant) contribution is
exactly the negative repository Archimedean integral plus the log-2
normalization correction. -/
theorem half_fixed_line_digamma_plus_gamma_eq_arch_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    (1 / 2 : ℂ) *
      ((1 / (2 * Real.pi) : ℂ) *
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) =
      -WeilArchimedeanIntegralV1 f.1 -
        ((2 * Real.log 2 : ℝ) : ℂ) * f.1 1 := by
  have hlog :=
    weil_fixed_line_digamma_plus_gamma_log_integral_v10 f c hc
  have hlog' :
      ((1 / (2 * Real.pi) : ℂ) *
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t) =
        ∫ u : ℝ in Ioi (0 : ℝ),
          WeilGammaLogIntegrandV10 f u := by
    simpa [WeilGammaLogIntegrandV10] using hlog
  rw [hlog']
  rw [half_gamma_log_integral_eq_x_integral_v10]
  exact gamma_x_integral_eq_arch_v10 f

end AEGIS.WeilFixedLineGammaXSpaceV10

#print axioms AEGIS.WeilFixedLineGammaXSpaceV10.gamma_log_two_mul_eq_exp_smul_x_v10
#print axioms AEGIS.WeilFixedLineGammaXSpaceV10.half_gamma_log_integral_eq_x_integral_v10
#print axioms AEGIS.WeilFixedLineGammaXSpaceV10.gamma_x_integrand_eq_neg_arch_sub_correction_v10
#print axioms AEGIS.WeilFixedLineGammaXSpaceV10.gamma_x_integral_eq_arch_v10
#print axioms AEGIS.WeilFixedLineGammaXSpaceV10.half_fixed_line_digamma_plus_gamma_eq_arch_v10
~~~~~~

## WeilArchimedeanCorrectionV10

Path: `source/WeilArchimedeanCorrectionV10.lean`

Original source lines: 1–116

Full file SHA256: `1e4ed77283f55c78ee7ce7ffd3bd018cbeff7217760e7a0e0ad577f278c927d2`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilArchimedeanCorrectionV10.lean

~~~~~~lean
import WeilFixedLineGammaAssemblyV10
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-!
AEGIS Ω — elementary Archimedean correction integral V10.

This file closes the last scalar correction used in the normalized gamma term:

  ∫_{1}^{∞} dx / (x (x + 1)) = log 2.

The antiderivative is log x - log (x+1), whose limit at +∞ is zero by
`Real.tendsto_log_comp_add_sub_log 1`.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter MeasureTheory
open scoped Topology

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilArchimedeanCorrectionV10

private theorem correction_antideriv_v10 (x : ℝ) (hx : 1 ≤ x) :
    HasDerivAt
      (fun y : ℝ => Real.log y - Real.log (y + 1))
      (1 / x - 1 / (x + 1)) x := by
  have hx0 : x ≠ 0 := by linarith
  have hx1 : x + 1 ≠ 0 := by linarith
  have hlogx := Real.hasDerivAt_log hx0
  have hlogx1 :
      HasDerivAt (fun y : ℝ => Real.log (y + 1)) (1 / (x + 1)) x := by
    simpa using ((hasDerivAt_id' x).add_const 1).log hx1
  exact (hlogx.sub hlogx1).congr_deriv (by simp [one_div])

private theorem correction_deriv_nonneg_v10 {x : ℝ} (hx : 1 < x) :
    0 ≤ 1 / x - 1 / (x + 1) := by
  rw [sub_nonneg]
  exact one_div_le_one_div_of_le (by linarith) (by linarith)

private theorem correction_antideriv_tendsto_zero_v10 :
    Tendsto
      (fun x : ℝ => Real.log x - Real.log (x + 1))
      atTop (𝓝 0) := by
  have h := (Real.tendsto_log_comp_add_sub_log 1).neg
  simpa only [neg_sub, neg_zero] using h


/-- Integrability of the scalar correction, obtained from the same monotone-FTC
argument used for its exact value. -/
theorem integrableOn_one_div_mul_one_add_v10 :
    IntegrableOn
      (fun x : ℝ => 1 / (x * (x + 1)))
      (Ioi (1 : ℝ)) := by
  have hderiv :
      ∀ x ∈ Ici (1 : ℝ),
        HasDerivAt
          (fun y : ℝ => Real.log y - Real.log (y + 1))
          (1 / x - 1 / (x + 1)) x :=
    fun x hx => correction_antideriv_v10 x hx
  have hpos :
      ∀ x ∈ Ioi (1 : ℝ), 0 ≤ 1 / x - 1 / (x + 1) :=
    fun x hx => correction_deriv_nonneg_v10 hx
  have hdiff :
      IntegrableOn
        (fun x : ℝ => 1 / x - 1 / (x + 1))
        (Ioi (1 : ℝ)) :=
    integrableOn_Ioi_deriv_of_nonneg'
      hderiv hpos correction_antideriv_tendsto_zero_v10
  refine IntegrableOn.congr_fun hdiff ?_ measurableSet_Ioi
  intro x hx
  have hx0 : x ≠ 0 := by
    rw [mem_Ioi] at hx
    linarith
  have hx1 : x + 1 ≠ 0 := by
    rw [mem_Ioi] at hx
    linarith
  field_simp [hx0, hx1]
  ring

/-- Exact tail correction. -/
theorem integral_one_div_mul_one_add_v10 :
    (∫ x : ℝ in Ioi (1 : ℝ), 1 / (x * (x + 1))) =
      Real.log 2 := by
  have hbase :=
    integral_Ioi_of_hasDerivAt_of_nonneg'
      (a := (1 : ℝ))
      (g := fun x : ℝ => Real.log x - Real.log (x + 1))
      (g' := fun x : ℝ => 1 / x - 1 / (x + 1))
      (l := (0 : ℝ))
      (fun x hx => correction_antideriv_v10 x hx)
      (fun x hx => correction_deriv_nonneg_v10 hx)
      correction_antideriv_tendsto_zero_v10
  have hpoint :
      ∀ x ∈ Ioi (1 : ℝ),
        1 / x - 1 / (x + 1) = 1 / (x * (x + 1)) := by
    intro x hx
    have hx' : (1 : ℝ) < x := hx
    have hx0 : x ≠ 0 := by linarith
    have hx1 : x + 1 ≠ 0 := by linarith
    field_simp [hx0, hx1]
    ring
  calc
    (∫ x : ℝ in Ioi (1 : ℝ), 1 / (x * (x + 1))) =
        ∫ x : ℝ in Ioi (1 : ℝ), (1 / x - 1 / (x + 1)) := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro x hx
          exact (hpoint x hx).symm
    _ = 0 - (Real.log 1 - Real.log (1 + 1)) := hbase
    _ = Real.log 2 := by norm_num

end AEGIS.WeilArchimedeanCorrectionV10

#print axioms AEGIS.WeilArchimedeanCorrectionV10.integral_one_div_mul_one_add_v10
~~~~~~

## WeilFixedLineGammaAssemblyV10

Path: `source/WeilFixedLineGammaAssemblyV10.lean`

Original source lines: 1–205

Full file SHA256: `865cd8a226b348f1b82847a47d229b36ee57098ea55019fd015340fb59ed7985`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineGammaAssemblyV10.lean

~~~~~~lean
import WeilFixedLineGammaFubiniV10
import WeilArchimedeanConvergenceV1

/-!
AEGIS Ω — normalized fixed-line gamma assembly V10.

This module evaluates both iterated integrals from
`WeilFixedLineGammaFubiniV10`.

* u-first: Gauss's digamma integral (now sourced from the pinned Mathlib
  trust surface through the new digamma-series completion);
* t-first: the V10 paired-profile Mellin inversion identities.

The result is the exact logarithmic-u representation of the normalized gamma
term.  The remaining child is only the x=exp(u/2) rewrite plus the elementary
constant aggregation into `WeilArchimedeanConstantV1`.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology MeasureTheory Complex
open scoped Topology

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilFixedLineGammaAssemblyV10

open AEGIS.WeilDigammaIntegralReductionV1
open AEGIS.WeilDigammaSeriesHalfPlaneV1
open AEGIS.WeilFixedLineGammaCoreV10
open AEGIS.WeilFixedLineGammaFubiniV10

local notation "γ" => Real.eulerMascheroniConstant

private theorem paired_exp_profile_integrable_v10
    (f : WeilCompactSmoothGV1) (c u : ℝ) :
    Integrable
      (fun t : ℝ =>
        Complex.exp
          (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))) *
          WeilPairedMellinProfileV5 f c t) := by
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  let C : ℝ := Real.exp (-(c * (u / 2)))
  have hC : 0 ≤ C := (Real.exp_pos _).le
  have hmajor :
      Integrable
        (fun t : ℝ =>
          C * ‖WeilPairedMellinProfileV5 f c t‖) :=
    hH.norm.const_mul C
  have hExpCont :
      Continuous
        (fun t : ℝ =>
          Complex.exp
            (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ)))) := by
    fun_prop
  have hmeas :
      AEStronglyMeasurable
        (fun t : ℝ =>
          Complex.exp
            (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))) *
            WeilPairedMellinProfileV5 f c t) :=
    hExpCont.aestronglyMeasurable.mul hH.aestronglyMeasurable
  refine hmajor.mono' hmeas (Filter.Eventually.of_forall fun t => ?_)
  rw [norm_mul, Complex.norm_exp]
  have hre :
      (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))).re =
        -(c * (u / 2)) := by
    simp
  rw [hre]

/-- Evaluate the u-integral first using the newly source-closed Gauss formula. -/
theorem weil_gauss_kernel_inner_u_v10
    (f : WeilCompactSmoothGV1) (c t : ℝ) (hc : 1 < c) :
    (∫ u : ℝ in Ioi (0 : ℝ),
      WeilGaussFixedLineKernelV10 f c (t, u)) =
      (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
        WeilPairedMellinProfileV5 f c t := by
  have hz :
      0 <
        ((((c : ℂ) + (t : ℂ) * I) / 2)).re := by
    simp
    linarith
  unfold WeilGaussFixedLineKernelV10
  dsimp only
  rw [integral_mul_const]
  rw [← gauss_digamma_integral_v1
    ((((c : ℂ) + (t : ℂ) * I) / 2)) hz]

/-- Evaluate the normalized t-integral of the Gauss kernel at fixed u. -/
theorem weil_gauss_kernel_inner_t_normalized_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) {u : ℝ}
    (hc : 1 < c) (hu : 0 < u) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        WeilGaussFixedLineKernelV10 f c (t, u)) =
      (Complex.exp (-(u : ℂ)) * (2 * f.1 1) -
        (WeilPairedTestV8 f).1 (Real.exp (u / 2))) /
        (1 - Complex.exp (-(u : ℂ))) := by
  let H : ℝ → ℂ := WeilPairedMellinProfileV5 f c
  let E : ℝ → ℂ := fun t =>
    Complex.exp
      (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ)))
  let a : ℂ := Complex.exp (-(u : ℂ))
  let d : ℂ := 1 - Complex.exp (-(u : ℂ))
  have hd : d ≠ 0 := by
    have hlt : Real.exp (-u) < 1 := Real.exp_lt_one_iff.mpr (by linarith)
    dsimp [d]
    rw [← Complex.ofReal_neg, ← Complex.ofReal_exp, ← Complex.ofReal_one,
      ← Complex.ofReal_sub]
    exact_mod_cast (sub_pos.mpr hlt).ne'
  have hH : Integrable H := by
    exact (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  have hE : Integrable (fun t => E t * H t) := by
    exact paired_exp_profile_integrable_v10 f c u
  have h1 : Integrable (fun t => (a / d) * H t) :=
    hH.const_mul (a / d)
  have h2 : Integrable (fun t => (1 / d) * (E t * H t)) :=
    hE.const_mul (1 / d)
  have hshape :
      (fun t : ℝ => WeilGaussFixedLineKernelV10 f c (t, u)) =
        fun t => (a / d) * H t - (1 / d) * (E t * H t) := by
    funext t
    unfold WeilGaussFixedLineKernelV10 gaussIntegrand
    dsimp only
    have hexp :
        Complex.exp (-((((c : ℂ) + (t : ℂ) * I) / 2)) * (u : ℂ)) = E t := by
      dsimp [E]
      congr 1
      push_cast
      ring
    rw [hexp]
    dsimp [H, a, d]
    field_simp
  rw [hshape, integral_sub h1 h2, integral_const_mul, integral_const_mul]
  have hHnorm :=
    weil_paired_profile_integral_one_v10 f c
  have hEnorm :=
    weil_paired_profile_exp_half_integral_v10 f c u
  rw [← hHnorm, ← hEnorm]
  have hd' : (1 - Complex.exp (-(u : ℂ))) ≠ 0 := hd
  have hpi : ((Real.pi : ℝ) : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr Real.pi_ne_zero
  simp only [H, E, a, d]
  field_simp
  congr 2
  funext t
  ring_nf

/-- Fubini plus both inner evaluations: the normalized fixed-line
`ψ+γ` contribution equals the exact u-space paired-test integral. -/
theorem weil_fixed_line_digamma_plus_gamma_log_integral_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t) =
      ∫ u : ℝ in Ioi (0 : ℝ),
        (Complex.exp (-(u : ℂ)) * (2 * f.1 1) -
          (WeilPairedTestV8 f).1 (Real.exp (u / 2))) /
          (1 - Complex.exp (-(u : ℂ))) := by
  have hfub :=
    weil_gauss_fixed_line_fubini_v10 f c hc
  have hleft :
      (∫ t : ℝ,
        ∫ u : ℝ in Ioi (0 : ℝ),
          WeilGaussFixedLineKernelV10 f c (t, u)) =
        ∫ t : ℝ,
          (Complex.digamma
            ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
            WeilPairedMellinProfileV5 f c t := by
    apply integral_congr_ae
    exact Filter.Eventually.of_forall (fun t =>
      weil_gauss_kernel_inner_u_v10 f c t hc)
  rw [hleft] at hfub
  calc
    (1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (Complex.digamma
          ((((c : ℂ) + (t : ℂ) * I) / 2)) + (γ : ℂ)) *
          WeilPairedMellinProfileV5 f c t
      =
      (1 / (2 * Real.pi) : ℂ) *
        ∫ u : ℝ in Ioi (0 : ℝ),
          ∫ t : ℝ,
            WeilGaussFixedLineKernelV10 f c (t, u) := by
        rw [hfub]
    _ =
      ∫ u : ℝ in Ioi (0 : ℝ),
        (Complex.exp (-(u : ℂ)) * (2 * f.1 1) -
          (WeilPairedTestV8 f).1 (Real.exp (u / 2))) /
          (1 - Complex.exp (-(u : ℂ))) := by
        rw [← integral_const_mul]
        apply setIntegral_congr_fun measurableSet_Ioi
        intro u hu
        rw [mem_Ioi] at hu
        exact weil_gauss_kernel_inner_t_normalized_v10 f c hc hu

end AEGIS.WeilFixedLineGammaAssemblyV10

#print axioms AEGIS.WeilFixedLineGammaAssemblyV10.weil_gauss_kernel_inner_u_v10
#print axioms AEGIS.WeilFixedLineGammaAssemblyV10.weil_gauss_kernel_inner_t_normalized_v10
#print axioms AEGIS.WeilFixedLineGammaAssemblyV10.weil_fixed_line_digamma_plus_gamma_log_integral_v10
~~~~~~

## WeilFixedLineGammaFubiniV10

Path: `source/WeilFixedLineGammaFubiniV10.lean`

Original source lines: 1–314

Full file SHA256: `7a49f9160639482592b94507dabb6591e29971f7d95cab69b13ef4f7395771f1`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineGammaFubiniV10.lean

~~~~~~lean
import WeilFixedLineGammaCoreV10
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.Analysis.SpecialFunctions.Gamma.Basic

/-!
AEGIS Ω — Gauss-kernel fixed-line Fubini closure V10.

For c > 1 this module proves absolute product-integrability of

  gaussIntegrand ((c + it)/2) u * H_c(t)

on R_t × (0,∞)_u, where H_c is the actual V5 paired Mellin profile.

The key global estimate avoids a small/large-u case split.  For u>0,

  1 - exp(-u) >= u/(1+u),

and the existing AEGIS exponential-difference estimate yields

  ‖gaussIntegrand ((c+it)/2) u‖
    <= 2 (1 + |c/2-1| + |t|) (1+u) exp(-m u),

with m=min(1,c/2)>0.

Thus the majorant factors into:
* the existing V5 A0/A1 t-moments;
* the integrable u-profile (1+u) exp(-m u).

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology MeasureTheory Complex
open scoped Topology

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilFixedLineGammaFubiniV10

open AEGIS.WeilDigammaIntegralReductionV1

def WeilGaussFixedLineKernelV10
    (f : WeilCompactSmoothGV1) (c : ℝ) (p : ℝ × ℝ) : ℂ :=
  gaussIntegrand
      ((((c : ℂ) + (p.1 : ℂ) * I) / 2))
      p.2 *
    WeilPairedMellinProfileV5 f c p.1

private theorem one_sub_exp_neg_lower_v10 {u : ℝ} (hu : 0 < u) :
    u / (1 + u) ≤ 1 - Real.exp (-u) := by
  have h1u : 0 < 1 + u := by linarith
  have hexp : 1 + u ≤ Real.exp u := by
    simpa [add_comm] using Real.add_one_le_exp u
  have hinv : Real.exp (-u) ≤ 1 / (1 + u) := by
    rw [Real.exp_neg]
    simpa [one_div] using one_div_le_one_div_of_le h1u hexp
  calc
    u / (1 + u) = 1 - 1 / (1 + u) := by
      field_simp [h1u.ne']
      ring
    _ ≤ 1 - Real.exp (-u) := sub_le_sub_left hinv 1

private theorem gauss_denominator_norm_lower_v10 {u : ℝ} (hu : 0 < u) :
    u / (1 + u) ≤
      ‖1 - Complex.exp (-(u : ℂ))‖ := by
  have hexplt : Real.exp (-u) < 1 :=
    Real.exp_lt_one_iff.mpr (by linarith)
  have hnorm :
      ‖1 - Complex.exp (-(u : ℂ))‖ =
        1 - Real.exp (-u) := by
    rw [← Complex.ofReal_neg, ← Complex.ofReal_exp, ← Complex.ofReal_one,
      ← Complex.ofReal_sub, Complex.norm_real]
    exact Real.norm_of_nonneg (sub_nonneg.mpr hexplt.le)
  rw [hnorm]
  exact one_sub_exp_neg_lower_v10 hu

private theorem half_line_shift_norm_le_v10 (c t : ℝ) :
    ‖(((c : ℂ) + (t : ℂ) * I) / 2) - 1‖
      ≤ |c / 2 - 1| + |t| := by
  have hsplit :
      (((c : ℂ) + (t : ℂ) * I) / 2) - 1 =
        ((c / 2 - 1 : ℝ) : ℂ) +
          ((t / 2 : ℝ) : ℂ) * I := by
    apply Complex.ext <;> simp <;> ring
  rw [hsplit]
  calc
    ‖((c / 2 - 1 : ℝ) : ℂ) + ((t / 2 : ℝ) : ℂ) * I‖
        ≤ ‖((c / 2 - 1 : ℝ) : ℂ)‖ +
            ‖((t / 2 : ℝ) : ℂ) * I‖ := norm_add_le _ _
    _ = |c / 2 - 1| + |t / 2| := by
        rw [Complex.norm_real, norm_mul, Complex.norm_I, mul_one, Complex.norm_real,
          Real.norm_eq_abs, Real.norm_eq_abs]
    _ ≤ |c / 2 - 1| + |t| := by
        have ht : |t / 2| ≤ |t| := by
          rw [abs_div]
          norm_num
        linarith

/-- Global Gauss-kernel majorant on the fixed line. -/
theorem gauss_fixed_line_norm_le_v10
    (c t : ℝ) {u : ℝ} (hc : 1 < c) (hu : 0 < u) :
    ‖gaussIntegrand
        ((((c : ℂ) + (t : ℂ) * I) / 2)) u‖
      ≤
      2 * (1 + |c / 2 - 1| + |t|) *
        (1 + u) *
        Real.exp (-(min 1 (c / 2) * u)) := by
  let z : ℂ := (((c : ℂ) + (t : ℂ) * I) / 2)
  let m : ℝ := min 1 (c / 2)
  have hm : 0 < m := by
    dsimp [m]
    exact lt_min one_pos (by linarith)
  have hzre : z.re = c / 2 := by
    dsimp [z]
    simp
  have hnum :=
    norm_exp_diff_le z hu
  have hzbound :
      1 + ‖z - 1‖ ≤ 1 + |c / 2 - 1| + |t| := by
    dsimp [z]
    linarith [half_line_shift_norm_le_v10 c t]
  have hnum' :
      ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
        ≤
        2 * (1 + |c / 2 - 1| + |t|) *
          u * Real.exp (-(m * u)) := by
    calc
      ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
          ≤ 2 * (1 + ‖z - 1‖) * u *
              Real.exp (-(min 1 z.re * u)) := hnum
      _ ≤ 2 * (1 + |c / 2 - 1| + |t|) * u *
              Real.exp (-(m * u)) := by
          rw [hzre]
          dsimp [m]
          gcongr
  have hden :=
    gauss_denominator_norm_lower_v10 hu
  have hsmallpos : 0 < u / (1 + u) := by positivity
  have hdenpos :
      0 < ‖1 - Complex.exp (-(u : ℂ))‖ :=
    hsmallpos.trans_le hden
  unfold gaussIntegrand
  rw [norm_div]
  calc
    ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖ /
          ‖1 - Complex.exp (-(u : ℂ))‖
        ≤
      (2 * (1 + |c / 2 - 1| + |t|) *
          u * Real.exp (-(m * u))) /
        (u / (1 + u)) := by
          apply div_le_div₀
          · positivity
          · exact hnum'
          · exact hsmallpos
          · exact hden
    _ =
      2 * (1 + |c / 2 - 1| + |t|) *
        (1 + u) * Real.exp (-(m * u)) := by
          field_simp [hu.ne', (by linarith : (1 + u) ≠ 0)]
    _ =
      2 * (1 + |c / 2 - 1| + |t|) *
        (1 + u) *
        Real.exp (-(min 1 (c / 2) * u)) := by rfl

private theorem gamma_u_majorant_integrable_v10
    (c : ℝ) (hc : 1 < c) :
    Integrable
      (fun u : ℝ =>
        (1 + u) * Real.exp (-(min 1 (c / 2) * u)))
      (volume.restrict (Ioi (0 : ℝ))) := by
  let m : ℝ := min 1 (c / 2)
  have hm : 0 < m := by
    dsimp [m]
    exact lt_min one_pos (by linarith)
  have h0 :
      IntegrableOn
        (fun u : ℝ => Real.exp (-m * u))
        (Ioi (0 : ℝ)) := by
    simpa [neg_mul] using
      (integrableOn_exp_mul_Ioi (a := -m) (by linarith) 0)
  have h1 :
      IntegrableOn
        (fun u : ℝ => u * Real.exp (-(m * u)))
        (Ioi (0 : ℝ)) := by
    have hI :=
      integrableOn_rpow_mul_exp_neg_mul_rpow (s := 1) (p := 1) (b := m)
        (by norm_num) (by norm_num) hm
    refine hI.congr_fun (fun u _ => ?_) measurableSet_Ioi
    simp [Real.rpow_one]
  refine (h0.add h1).congr (Filter.Eventually.of_forall fun u => ?_)
  simp only [Pi.add_apply, m, neg_mul]
  ring

private theorem gamma_t_majorant_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) :
    Integrable
      (fun t : ℝ =>
        (1 + |c / 2 - 1| + |t|) *
          ‖WeilPairedMellinProfileV5 f c t‖) := by
  have hH :=
    weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c
  let A : ℝ := 1 + |c / 2 - 1|
  have h0 :
      Integrable
        (fun t : ℝ =>
          A * ‖WeilPairedMellinProfileV5 f c t‖) :=
    hH.1.norm.const_mul A
  have h1 :
      Integrable
        (fun t : ℝ =>
          |t| * ‖WeilPairedMellinProfileV5 f c t‖) :=
    hH.2.1
  refine (h0.add h1).congr (Filter.Eventually.of_forall fun t => ?_)
  simp only [Pi.add_apply, A]
  ring

/-- Absolute product-integrability of the Gauss kernel against the actual V5
paired Mellin profile. -/
theorem weil_gauss_fixed_line_kernel_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    Integrable
      (WeilGaussFixedLineKernelV10 f c)
      (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
  let T : ℝ → ℝ := fun t =>
    (1 + |c / 2 - 1| + |t|) *
      ‖WeilPairedMellinProfileV5 f c t‖
  let U : ℝ → ℝ := fun u =>
    (1 + u) * Real.exp (-(min 1 (c / 2) * u))
  have hT : Integrable T := by
    exact gamma_t_majorant_integrable_v10 f c
  have hU :
      Integrable U (volume.restrict (Ioi (0 : ℝ))) := by
    exact gamma_u_majorant_integrable_v10 c hc
  have hmajor :
      Integrable
        (fun p : ℝ × ℝ => 2 * T p.1 * U p.2)
        (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
    exact (hT.const_mul 2).mul_prod hU
  have hmeas :
      AEStronglyMeasurable
        (WeilGaussFixedLineKernelV10 f c)
        (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
    unfold WeilGaussFixedLineKernelV10
    have hH :=
      (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
    have hHm :
        AEStronglyMeasurable
          (fun p : ℝ × ℝ =>
            WeilPairedMellinProfileV5 f c p.1)
          (volume.prod (volume.restrict (Ioi (0 : ℝ)))) :=
      hH.aestronglyMeasurable.comp_fst
    have hGm :
        AEStronglyMeasurable
          (fun p : ℝ × ℝ =>
            gaussIntegrand
              ((((c : ℂ) + (p.1 : ℂ) * I) / 2)) p.2)
          (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
      apply Measurable.aestronglyMeasurable
      unfold gaussIntegrand
      fun_prop
    exact hGm.mul hHm
  refine hmajor.mono' hmeas ?_
  have hpos_ae :
      ∀ᵐ p : ℝ × ℝ ∂(volume.prod (volume.restrict (Ioi (0 : ℝ)))), 0 < p.2 := by
    change ∀ᵐ p : ℝ × ℝ ∂(volume.prod (volume.restrict (Ioi (0 : ℝ)))),
        p ∈ Prod.snd ⁻¹' Ioi (0 : ℝ)
    rw [Measure.ae_prod_mem_iff_ae_ae_mem
      (measurable_snd measurableSet_Ioi)]
    exact Filter.Eventually.of_forall (fun _ => by
      rw [ae_restrict_iff' measurableSet_Ioi]
      exact Filter.Eventually.of_forall (fun u hu => hu))
  filter_upwards [hpos_ae] with p hp
  have hu : 0 < p.2 := hp
  unfold WeilGaussFixedLineKernelV10
  rw [norm_mul]
  have hg :=
    gauss_fixed_line_norm_le_v10 c p.1 hc hu
  calc
      ‖gaussIntegrand
          ((((c : ℂ) + (p.1 : ℂ) * I) / 2)) p.2‖ *
          ‖WeilPairedMellinProfileV5 f c p.1‖
        ≤
        (2 * (1 + |c / 2 - 1| + |p.1|) *
          (1 + p.2) *
          Real.exp (-(min 1 (c / 2) * p.2))) *
          ‖WeilPairedMellinProfileV5 f c p.1‖ := by
          gcongr
    _ = 2 * T p.1 * U p.2 := by
          simp [T, U]
          ring

/-- The actual Gauss-kernel t/u Fubini swap. -/
theorem weil_gauss_fixed_line_fubini_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    (∫ t : ℝ,
      ∫ u : ℝ in Ioi (0 : ℝ),
        WeilGaussFixedLineKernelV10 f c (t, u)) =
      ∫ u : ℝ in Ioi (0 : ℝ),
        ∫ t : ℝ,
          WeilGaussFixedLineKernelV10 f c (t, u) := by
  have hprod :=
    weil_gauss_fixed_line_kernel_integrable_v10 f c hc
  simpa [Function.uncurry_def] using
    (integral_integral_swap
      (μ := volume) (ν := volume.restrict (Ioi (0 : ℝ)))
      (f := fun t u => WeilGaussFixedLineKernelV10 f c (t, u))
      hprod)

end AEGIS.WeilFixedLineGammaFubiniV10

#print axioms AEGIS.WeilFixedLineGammaFubiniV10.gauss_fixed_line_norm_le_v10
#print axioms AEGIS.WeilFixedLineGammaFubiniV10.weil_gauss_fixed_line_kernel_integrable_v10
#print axioms AEGIS.WeilFixedLineGammaFubiniV10.weil_gauss_fixed_line_fubini_v10
~~~~~~

## WeilFixedLineGammaCoreV10

Path: `source/WeilFixedLineGammaCoreV10.lean`

Original source lines: 1–100

Full file SHA256: `0198de6ad1460d837e3913bb3528af97824f9f381cddffb1e5ef428a02efd140`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineGammaCoreV10.lean

~~~~~~lean
import WeilReciprocalPairedTestV8
import WeilDigammaSeriesHalfPlaneV1

/-!
AEGIS Ω — fixed-line gamma normalization core V10.

This module binds the already proved V6 Mellin inversion theorem to the actual
V5 paired Mellin profile through the concrete V8 reciprocal-paired test.

It proves the two fixed-line evaluations consumed by the normalized gamma
term:

  (2π)⁻¹ ∫ H(c+it) dt = 2 f(1)

and, for every real u,

  (2π)⁻¹ ∫ exp (-(c+it)u/2) H(c+it) dt
    = q(exp(u/2)),

where q(x)=f(x)+x⁻¹ f(x⁻¹).

No new Fubini exchange is performed here.  The remaining V10 gamma step is
precisely the product-integrability/swap for the Gauss kernel.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology MeasureTheory Complex
open scoped Topology

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilFixedLineGammaCoreV10

/-- The normalized integral of the actual paired Mellin profile is exactly
the paired test at x=1, hence 2 f(1). -/
theorem weil_paired_profile_integral_one_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ, WeilPairedMellinProfileV5 f c t) =
      2 * f.1 1 := by
  have h :=
    weil_compact_smooth_mellin_inversion_exp_line_v6
      (WeilPairedTestV8 f) c 0
  have hprofile :
      ∀ t : ℝ,
        WeilFixedLineMellinV6 (WeilPairedTestV8 f) c t =
          WeilPairedMellinProfileV5 f c t := by
    intro t
    exact weil_paired_test_fixed_line_profile_v8 f c t
  simp_rw [hprofile] at h
  simp [WeilPairedTestV8, WeilReciprocalFnV8] at h ⊢
  rw [h]
  ring

/-- Mellin inversion for the actual paired profile at x=exp(u/2). -/
theorem weil_paired_profile_exp_half_integral_v10
    (f : WeilCompactSmoothGV1) (c u : ℝ) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        Complex.exp
          (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))) *
          WeilPairedMellinProfileV5 f c t) =
      (WeilPairedTestV8 f).1 (Real.exp (u / 2)) := by
  have h :=
    weil_compact_smooth_mellin_inversion_exp_line_v6
      (WeilPairedTestV8 f) c (u / 2)
  have hprofile :
      ∀ t : ℝ,
        WeilFixedLineMellinV6 (WeilPairedTestV8 f) c t =
          WeilPairedMellinProfileV5 f c t := by
    intro t
    exact weil_paired_test_fixed_line_profile_v8 f c t
  simp_rw [hprofile] at h
  exact h

/-- Expanded form of the previous theorem in terms of the original test and
its reciprocal partner. -/
theorem weil_paired_profile_exp_half_integral_expanded_v10
    (f : WeilCompactSmoothGV1) (c u : ℝ) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        Complex.exp
          (-(((c : ℂ) + (t : ℂ) * I) * ((u / 2 : ℝ) : ℂ))) *
          WeilPairedMellinProfileV5 f c t) =
      f.1 (Real.exp (u / 2)) +
        ((Real.exp (-(u / 2)) : ℝ) : ℂ) *
          f.1 (Real.exp (-(u / 2))) := by
  rw [weil_paired_profile_exp_half_integral_v10 f c u]
  simp only [WeilPairedTestV8, WeilReciprocalFnV8]
  have hinv : (Real.exp (u / 2))⁻¹ = Real.exp (-(u / 2)) := by
    rw [← Real.exp_neg]
  rw [hinv]

end AEGIS.WeilFixedLineGammaCoreV10

#print axioms AEGIS.WeilFixedLineGammaCoreV10.weil_paired_profile_integral_one_v10
#print axioms AEGIS.WeilFixedLineGammaCoreV10.weil_paired_profile_exp_half_integral_v10
#print axioms AEGIS.WeilFixedLineGammaCoreV10.weil_paired_profile_exp_half_integral_expanded_v10
~~~~~~

## WeilReciprocalPairedTestV8

Path: `source/WeilReciprocalPairedTestV8.lean`

Original source lines: 1–193

Full file SHA256: `cc7976c6417fcd1d32fa98139b6bec9356d78f0690b046e6ca85bb294e96f41f`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilReciprocalPairedTestV8.lean

~~~~~~lean
import WeilFixedLineXSpaceTailV7
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Tactic

/-!
AEGIS Ω — reciprocal paired Mellin test closure v8.

For an existing compact-smooth positive-support test f, define

  f#(x) = x⁻¹ f(x⁻¹),    q = f + f#.

This module proves:
- f# remains in the exact existing `WeilCompactSmoothGV1` carrier;
- M f#(s) = M f(1-s);
- q remains in the carrier;
- M q(s) = M f(s) + M f(1-s);
- on s=c+it this is exactly the existing V5 paired Mellin profile.

No paired-zero Cauchy-kernel evaluation, zero-sum assembly, gamma/digamma
normalization, explicit-formula completion, arithmetic sign, global Weil
positivity, or RH conclusion is asserted here.
-/

open Set Filter Topology Complex MeasureTheory
open scoped ContDiff BigOperators

set_option autoImplicit false

noncomputable section

def WeilReciprocalFnV8
    (f : WeilCompactSmoothGV1) (x : ℝ) : ℂ :=
  ((x⁻¹ : ℝ) : ℂ) * f.1 x⁻¹

def WeilReciprocalSupportEnvelopeV8
    (f : WeilCompactSmoothGV1) : Set ℝ :=
  (fun x : ℝ => x⁻¹) '' tsupport f.1

theorem weil_reciprocal_support_envelope_compact_v8
    (f : WeilCompactSmoothGV1) :
    IsCompact (WeilReciprocalSupportEnvelopeV8 f) := by
  apply f.2.2.1.image_of_continuousOn
  exact continuousOn_inv₀.mono (fun x hx =>
    ne_of_gt (f.2.2.2 hx))

theorem weil_reciprocal_support_envelope_positive_v8
    (f : WeilCompactSmoothGV1) :
    WeilReciprocalSupportEnvelopeV8 f ⊆ Ioi 0 := by
  rintro x ⟨y, hy, rfl⟩
  change 0 < y⁻¹
  exact inv_pos.mpr (f.2.2.2 hy)

theorem weil_reciprocal_tsupport_subset_v8
    (f : WeilCompactSmoothGV1) :
    tsupport (WeilReciprocalFnV8 f) ⊆
      WeilReciprocalSupportEnvelopeV8 f := by
  apply closure_minimal ?_
    (weil_reciprocal_support_envelope_compact_v8 f).isClosed
  intro x hx
  have hfne : f.1 x⁻¹ ≠ 0 := by
    intro hz
    apply hx
    simp [WeilReciprocalFnV8, hz]
  refine ⟨x⁻¹, subset_tsupport _ hfne, ?_⟩
  exact inv_inv x

theorem weil_reciprocal_hasCompactSupport_v8
    (f : WeilCompactSmoothGV1) :
    HasCompactSupport (WeilReciprocalFnV8 f) :=
  (weil_reciprocal_support_envelope_compact_v8 f).of_isClosed_subset
    (isClosed_tsupport _) (weil_reciprocal_tsupport_subset_v8 f)

theorem weil_reciprocal_tsupport_positive_v8
    (f : WeilCompactSmoothGV1) :
    tsupport (WeilReciprocalFnV8 f) ⊆ Ioi 0 :=
  (weil_reciprocal_tsupport_subset_v8 f).trans
    (weil_reciprocal_support_envelope_positive_v8 f)

theorem weil_reciprocal_contDiff_v8
    (f : WeilCompactSmoothGV1) :
    ContDiff ℝ ∞ (WeilReciprocalFnV8 f) := by
  rw [contDiff_iff_contDiffAt]
  intro x
  by_cases hx : x = 0
  · subst x
    have hK := weil_reciprocal_support_envelope_compact_v8 f
    have h0K : (0 : ℝ) ∉ WeilReciprocalSupportEnvelopeV8 f := by
      rintro ⟨y, hy, hiy⟩
      have hy0 : y ≠ 0 := ne_of_gt (f.2.2.2 hy)
      exact (inv_ne_zero hy0) hiy
    have hnhd :
        (WeilReciprocalSupportEnvelopeV8 f)ᶜ ∈ 𝓝 (0 : ℝ) :=
      hK.isClosed.isOpen_compl.mem_nhds h0K
    have heq :
        WeilReciprocalFnV8 f =ᶠ[𝓝 (0 : ℝ)] (fun _ : ℝ => (0 : ℂ)) := by
      filter_upwards [hnhd] with y hy
      apply image_eq_zero_of_notMem_tsupport
      intro hts
      exact hy (weil_reciprocal_tsupport_subset_v8 f hts)
    exact contDiffAt_const.congr_of_eventuallyEq heq
  · have hinv :
        ContDiffAt ℝ ∞ (fun y : ℝ => y⁻¹) x :=
      contDiffAt_inv ℝ hx
    have hcoef :
        ContDiffAt ℝ ∞ (fun y : ℝ => ((y⁻¹ : ℝ) : ℂ)) x :=
      Complex.ofRealCLM.contDiff.contDiffAt.comp x hinv
    have hcomp :
        ContDiffAt ℝ ∞ (fun y : ℝ => f.1 y⁻¹) x :=
      f.2.1.contDiffAt.comp x hinv
    exact hcoef.mul hcomp

def WeilReciprocalCompactSmoothV8
    (f : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  ⟨WeilReciprocalFnV8 f,
    weil_reciprocal_contDiff_v8 f,
    weil_reciprocal_hasCompactSupport_v8 f,
    weil_reciprocal_tsupport_positive_v8 f⟩

theorem weil_reciprocal_compact_smooth_coe_v8
    (f : WeilCompactSmoothGV1) :
    (WeilReciprocalCompactSmoothV8 f).1 = WeilReciprocalFnV8 f := rfl

theorem weil_reciprocal_mellin_v8
    (f : WeilCompactSmoothGV1) (s : ℂ) :
    mellin (WeilReciprocalFnV8 f) s =
      mellin f.1 (1 - s) := by
  have hshift :=
    mellin_cpow_smul
      (fun x : ℝ => f.1 x⁻¹) s (-1 : ℂ)
  calc
    mellin (WeilReciprocalFnV8 f) s =
        mellin
          (fun x : ℝ =>
            ((x : ℂ) ^ (-1 : ℂ)) * f.1 x⁻¹) s := by
      congr 1
      funext x
      simp [WeilReciprocalFnV8, Complex.cpow_neg_one]
    _ = mellin (fun x : ℝ => f.1 x⁻¹) (s + (-1 : ℂ)) := by
      simpa only [smul_eq_mul] using hshift
    _ = mellin f.1 (-(s + (-1 : ℂ))) := by
      rw [mellin_comp_inv]
    _ = mellin f.1 (1 - s) := by
      congr 1
      ring

def WeilPairedTestV8
    (f : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  ⟨fun x => f.1 x + WeilReciprocalFnV8 f x,
    f.2.1.add (weil_reciprocal_contDiff_v8 f),
    f.2.2.1.add (weil_reciprocal_hasCompactSupport_v8 f),
    (tsupport_add f.1 (WeilReciprocalFnV8 f)).trans
      (union_subset f.2.2.2 (weil_reciprocal_tsupport_positive_v8 f))⟩

@[simp] theorem weil_paired_test_apply_v8
    (f : WeilCompactSmoothGV1) (x : ℝ) :
    (WeilPairedTestV8 f).1 x =
      f.1 x + WeilReciprocalFnV8 f x := rfl

theorem weil_paired_test_mellin_v8
    (f : WeilCompactSmoothGV1) (s : ℂ) :
    mellin (WeilPairedTestV8 f).1 s =
      mellin f.1 s + mellin f.1 (1 - s) := by
  have hf :=
    weil_compact_smooth_mellin_convergent_all_v1 f s
  have hr :=
    weil_compact_smooth_mellin_convergent_all_v1
      (WeilReciprocalCompactSmoothV8 f) s
  have hadd :=
    hasMellin_add hf hr
  calc
    mellin (WeilPairedTestV8 f).1 s =
        mellin f.1 s + mellin (WeilReciprocalFnV8 f) s := by
      simpa [WeilPairedTestV8,
        weil_reciprocal_compact_smooth_coe_v8] using hadd.2
    _ = mellin f.1 s + mellin f.1 (1 - s) := by
      rw [weil_reciprocal_mellin_v8]

theorem weil_paired_test_fixed_line_profile_v8
    (f : WeilCompactSmoothGV1) (c t : ℝ) :
    mellin (WeilPairedTestV8 f).1
        ((c : ℂ) + (t : ℂ) * I) =
      WeilPairedMellinProfileV5 f c t := by
  rw [weil_paired_test_mellin_v8]
  rw [weil_paired_mellin_profile_eq_one_sub_v5]

end

#print axioms weil_reciprocal_support_envelope_compact_v8
#print axioms weil_reciprocal_tsupport_subset_v8
#print axioms weil_reciprocal_contDiff_v8
#print axioms weil_reciprocal_mellin_v8
#print axioms weil_paired_test_mellin_v8
#print axioms weil_paired_test_fixed_line_profile_v8
~~~~~~

## WeilFixedLineXSpaceTailV7

Path: `source/WeilFixedLineXSpaceTailV7.lean`

Original source lines: 1–88

Full file SHA256: `566099516733f1661662a2e3f6b8c709b9c514aba612ea906ba0cca9fa6b6283`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineXSpaceTailV7.lean

~~~~~~lean
import WeilFixedLineKernelIntegralV6
import Mathlib.MeasureTheory.Integral.IntegralEqImproper
import Mathlib.Tactic

/-!
AEGIS Ω — fixed-line x-space Mellin tail rewrite v7.

This child of the GREEN V6 kernel-integral lane performs exactly the remaining
change of variables x = exp(v) in the KI identity:

  ∫_{v>0} exp(a v) f(exp v) dv
    = ∫_{x>1} x^(a-1) f(x) dx.

It then composes that equality with the V6 fixed-line Cauchy/Mellin identity.
No paired-zero evaluation, zero-sum reindexing, gamma/digamma normalization,
whole explicit formula, arithmetic sign, global Weil positivity, or RH
conclusion is asserted here.
-/

open Set Filter Topology Complex MeasureTheory
open scoped BigOperators

set_option autoImplicit false

noncomputable section

private theorem weil_exp_real_cpow_sub_one_v7
    (a : ℂ) (v : ℝ) :
    (((Real.exp v : ℝ) : ℂ) *
      (((Real.exp v : ℝ) : ℂ) ^ (a - 1))) =
      Complex.exp (a * (v : ℂ)) := by
  have hx : (((Real.exp v : ℝ) : ℂ) ≠ 0) := by
    exact Complex.ofReal_ne_zero.mpr (Real.exp_ne_zero v)
  rw [Complex.cpow_def_of_ne_zero hx]
  have hlog :
      Complex.log (((Real.exp v : ℝ) : ℂ)) = (v : ℂ) := by
    rw [← Complex.ofReal_log (Real.exp_pos v).le, Real.log_exp]
  rw [hlog, Complex.ofReal_exp, ← Complex.exp_add]
  congr 1
  ring

/-- Exact x = exp(v) rewrite of the logarithmic KI tail. -/
theorem weil_fixed_line_log_tail_eq_x_tail_v7
    (f : WeilCompactSmoothGV1) (a : ℂ) :
    (∫ v : ℝ in Ioi (0 : ℝ),
      Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v)) =
      ∫ x : ℝ in Ioi (1 : ℝ),
        ((x : ℂ) ^ (a - 1)) * f.1 x := by
  have h :=
    integral_comp_exp_Ioi
      (fun x : ℝ => ((x : ℂ) ^ (a - 1)) * f.1 x) 0
  calc
    (∫ v : ℝ in Ioi (0 : ℝ),
      Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v))
        =
      ∫ v : ℝ in Ioi (0 : ℝ),
        Real.exp v •
          ((((Real.exp v : ℝ) : ℂ) ^ (a - 1)) *
            f.1 (Real.exp v)) := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro v hv
          change
            Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v) =
              ((Real.exp v : ℝ) : ℂ) *
                ((((Real.exp v : ℝ) : ℂ) ^ (a - 1)) *
                  f.1 (Real.exp v))
          rw [← mul_assoc, weil_exp_real_cpow_sub_one_v7]
    _ =
      ∫ x : ℝ in Ioi (1 : ℝ),
        ((x : ℂ) ^ (a - 1)) * f.1 x := by
          simpa [Complex.real_smul] using h

/-- V6 KI identity rewritten on the actual x>1 Mellin tail. -/
theorem weil_fixed_line_kernel_integral_x_tail_v7
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
          WeilFixedLineMellinV6 f c t) =
      ∫ x : ℝ in Ioi (1 : ℝ),
        ((x : ℂ) ^ (a - 1)) * f.1 x := by
  rw [weil_fixed_line_kernel_integral_log_v6 f c a ha]
  exact weil_fixed_line_log_tail_eq_x_tail_v7 f a

end

#print axioms weil_fixed_line_log_tail_eq_x_tail_v7
#print axioms weil_fixed_line_kernel_integral_x_tail_v7
~~~~~~

## WeilFixedLineKernelIntegralV6

Path: `source/WeilFixedLineKernelIntegralV6.lean`

Original source lines: 1–326

Full file SHA256: `f778b1c9ec2873ea812e9dae27207f6c9cc94306a05cc9ec636645751c411648`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineKernelIntegralV6.lean

~~~~~~lean
import WeilPairedMellinProfileV5
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.Tactic

/-!
AEGIS Ω — fixed-line Laplace/Mellin kernel integral v6.

This is the machine-checkable KI step from the fixed-line proof note.  For
s=c+it and Re a<c,

  1/(s-a) = ∫_0^∞ exp (-(s-a)v) dv,

and the product with the actual Mellin transform is absolutely integrable on
R_t × (0,∞)_v.  Fubini plus Mellin inversion then yields the exact log-coordinate
kernel identity

  (1/(2π)) ∫_R F(c+it)/(c+it-a) dt
    = ∫_0^∞ exp(a v) f(exp v) dv.

No zero-sum reindexing, gamma/digamma evaluation, explicit-formula assembly,
arithmetic sign, global Weil positivity, or RH conclusion is asserted here.
-/

open Set Filter Topology Complex MeasureTheory
open scoped BigOperators

set_option autoImplicit false

noncomputable section

def WeilFixedLineMellinV6
    (f : WeilCompactSmoothGV1) (c t : ℝ) : ℂ :=
  mellin f.1 ((c : ℂ) + (t : ℂ) * I)

def WeilFixedLineLaplaceKernelV6
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (p : ℝ × ℝ) : ℂ :=
  Complex.exp
      (-((((c : ℂ) + (p.1 : ℂ) * I) - a) * (p.2 : ℂ))) *
    WeilFixedLineMellinV6 f c p.1

private theorem weil_fixed_line_laplace_factor_norm_v6
    (c t v : ℝ) (a : ℂ) :
    ‖Complex.exp
      (-((((c : ℂ) + (t : ℂ) * I) - a) * (v : ℂ)))‖ =
      Real.exp (-((c - a.re) * v)) := by
  rw [Complex.norm_exp]
  congr 1
  simp

/-- The fixed-line Cauchy kernel is a convergent Laplace integral. -/
theorem weil_fixed_line_laplace_kernel_integral_v6
    (c t : ℝ) (a : ℂ) (ha : a.re < c) :
    (∫ v : ℝ in Ioi (0 : ℝ),
      Complex.exp
        (-((((c : ℂ) + (t : ℂ) * I) - a) * (v : ℂ)))) =
      1 / (((c : ℂ) + (t : ℂ) * I) - a) := by
  have hb :
      (-(((c : ℂ) + (t : ℂ) * I) - a)).re < 0 := by
    simp
    linarith
  rw [show
      (fun v : ℝ =>
        Complex.exp (-((((c : ℂ) + (t : ℂ) * I) - a) * (v : ℂ)))) =
      (fun v : ℝ =>
        Complex.exp
          ((-(((c : ℂ) + (t : ℂ) * I) - a)) * (v : ℂ))) by
        funext v
        congr 1
        ring]
  have hden :
      ((c : ℂ) + (t : ℂ) * I) - a ≠ 0 := by
    intro h
    have hre := congrArg Complex.re h
    simp at hre
    linarith
  rw [integral_exp_mul_complex_Ioi hb 0]
  simp only [ofReal_zero, mul_zero, Complex.exp_zero]
  field_simp [hden]

private theorem weil_fixed_line_laplace_kernel_integrable_v6
    (c t : ℝ) (a : ℂ) (ha : a.re < c) :
    IntegrableOn
      (fun v : ℝ =>
        Complex.exp
          (-((((c : ℂ) + (t : ℂ) * I) - a) * (v : ℂ))))
      (Ioi (0 : ℝ)) := by
  have hb :
      (-(((c : ℂ) + (t : ℂ) * I) - a)).re < 0 := by
    simp
    linarith
  rw [show
      (fun v : ℝ =>
        Complex.exp (-((((c : ℂ) + (t : ℂ) * I) - a) * (v : ℂ)))) =
      (fun v : ℝ =>
        Complex.exp
          ((-(((c : ℂ) + (t : ℂ) * I) - a)) * (v : ℂ))) by
        funext v
        congr 1
        ring]
  exact integrableOn_exp_mul_complex_Ioi hb 0

/-- Absolute product-integrability needed for the actual t/v Fubini swap. -/
theorem weil_fixed_line_laplace_mellin_product_integrable_v6
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    Integrable
      (WeilFixedLineLaplaceKernelV6 f c a)
      (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
  let F : ℝ → ℂ := fun t => WeilFixedLineMellinV6 f c t
  let δ : ℝ := c - a.re
  have hδ : 0 < δ := by
    dsimp [δ]
    linarith
  have hF : Integrable F := by
    dsimp [F, WeilFixedLineMellinV6]
    exact weil_compact_smooth_mellin_vertical_integrable_all_v1 f c
  have hv :
      Integrable (fun v : ℝ => Real.exp (-δ * v))
        (volume.restrict (Ioi (0 : ℝ))) := by
    exact integrableOn_exp_mul_Ioi (a := -δ) (by linarith) 0
  have hmajor :
      Integrable
        (fun p : ℝ × ℝ =>
          ‖F p.1‖ * Real.exp (-δ * p.2))
        (volume.prod (volume.restrict (Ioi (0 : ℝ)))) :=
    hF.norm.mul_prod hv
  have hFmeas :
      AEStronglyMeasurable
        (fun p : ℝ × ℝ => F p.1)
        (volume.prod (volume.restrict (Ioi (0 : ℝ)))) :=
    hF.aestronglyMeasurable.comp_fst
  have hexp :
      Continuous (fun p : ℝ × ℝ =>
        Complex.exp
          (-((((c : ℂ) + (p.1 : ℂ) * I) - a) * (p.2 : ℂ)))) := by
    fun_prop
  have hmeas :
      AEStronglyMeasurable
        (WeilFixedLineLaplaceKernelV6 f c a)
        (volume.prod (volume.restrict (Ioi (0 : ℝ)))) := by
    exact hexp.aestronglyMeasurable.mul hFmeas
  refine hmajor.mono' hmeas
    (Filter.Eventually.of_forall fun p => ?_)
  unfold WeilFixedLineLaplaceKernelV6
  rw [norm_mul, weil_fixed_line_laplace_factor_norm_v6]
  dsimp [F, δ]
  rw [neg_mul]
  exact le_of_eq (mul_comm _ _)

/-- Fubini exchange for the fixed-line Laplace/Mellin kernel. -/
theorem weil_fixed_line_laplace_mellin_fubini_v6
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    (∫ t : ℝ,
      ∫ v : ℝ in Ioi (0 : ℝ),
        WeilFixedLineLaplaceKernelV6 f c a (t, v)) =
      ∫ v : ℝ in Ioi (0 : ℝ),
        ∫ t : ℝ,
          WeilFixedLineLaplaceKernelV6 f c a (t, v) := by
  have hprod :=
    weil_fixed_line_laplace_mellin_product_integrable_v6 f c a ha
  simpa [Function.uncurry_def] using
    (integral_integral_swap
      (μ := volume) (ν := volume.restrict (Ioi (0 : ℝ)))
      (f := fun t v => WeilFixedLineLaplaceKernelV6 f c a (t, v))
      hprod)

/-- Evaluate the v-integral first: this is exactly the Cauchy kernel
F(c+it)/(c+it-a). -/
theorem weil_fixed_line_laplace_mellin_left_v6
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    (∫ t : ℝ,
      ∫ v : ℝ in Ioi (0 : ℝ),
        WeilFixedLineLaplaceKernelV6 f c a (t, v)) =
      ∫ t : ℝ,
        (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
          WeilFixedLineMellinV6 f c t := by
  apply integral_congr_ae
  filter_upwards [] with t
  change
    (∫ v : ℝ in Ioi (0 : ℝ),
      Complex.exp
        (-((((c : ℂ) + (t : ℂ) * I) - a) * (v : ℂ))) *
        WeilFixedLineMellinV6 f c t) =
      (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
        WeilFixedLineMellinV6 f c t
  rw [integral_mul_const]
  rw [weil_fixed_line_laplace_kernel_integral_v6 c t a ha]

private theorem weil_exp_real_cpow_neg_line_v6
    (c t v : ℝ) :
    (((Real.exp v : ℝ) : ℂ) ^
      (-((c : ℂ) + (t : ℂ) * I))) =
      Complex.exp
        (-(((c : ℂ) + (t : ℂ) * I) * (v : ℂ))) := by
  have hx : (((Real.exp v : ℝ) : ℂ) ≠ 0) := by
    exact Complex.ofReal_ne_zero.mpr (Real.exp_ne_zero v)
  rw [Complex.cpow_def_of_ne_zero hx]
  have hlog :
      Complex.log (((Real.exp v : ℝ) : ℂ)) = (v : ℂ) := by
    rw [← Complex.ofReal_log (Real.exp_pos v).le, Real.log_exp]
  rw [hlog]
  congr 1
  ring

/-- Mellin inversion specialized to x=exp(v), in the exact integrand shape
used by the Laplace kernel. -/
theorem weil_compact_smooth_mellin_inversion_exp_line_v6
    (f : WeilCompactSmoothGV1) (c v : ℝ) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        Complex.exp
          (-(((c : ℂ) + (t : ℂ) * I) * (v : ℂ))) *
          WeilFixedLineMellinV6 f c t) =
      f.1 (Real.exp v) := by
  have h :=
    weil_compact_smooth_mellin_inversion_v1
      f c (x := Real.exp v) (Real.exp_pos v)
  rw [mellinInv] at h
  simp only [smul_eq_mul] at h
  simp_rw [weil_exp_real_cpow_neg_line_v6] at h
  simpa [WeilFixedLineMellinV6] using h

private theorem weil_fixed_line_laplace_factor_split_v6
    (c t v : ℝ) (a : ℂ) :
    Complex.exp
      (-((((c : ℂ) + (t : ℂ) * I) - a) * (v : ℂ))) =
      Complex.exp (a * (v : ℂ)) *
        Complex.exp
          (-(((c : ℂ) + (t : ℂ) * I) * (v : ℂ))) := by
  rw [← Complex.exp_add]
  congr 1
  ring

/-- Evaluate the t-integral after Fubini using the already verified Mellin
inversion theorem. -/
theorem weil_fixed_line_laplace_mellin_right_v6
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) :
    ((1 / (2 * Real.pi) : ℂ) *
      (∫ v : ℝ in Ioi (0 : ℝ),
        ∫ t : ℝ,
          WeilFixedLineLaplaceKernelV6 f c a (t, v))) =
      ∫ v : ℝ in Ioi (0 : ℝ),
        Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v) := by
  rw [← integral_const_mul]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro v hv
  change
    (1 / (2 * Real.pi) : ℂ) *
        (∫ t : ℝ, WeilFixedLineLaplaceKernelV6 f c a (t, v)) =
      Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v)
  have hinter :
      (∫ t : ℝ,
        WeilFixedLineLaplaceKernelV6 f c a (t, v)) =
        Complex.exp (a * (v : ℂ)) *
          ∫ t : ℝ,
            Complex.exp
              (-(((c : ℂ) + (t : ℂ) * I) * (v : ℂ))) *
              WeilFixedLineMellinV6 f c t := by
    rw [← integral_const_mul]
    apply integral_congr_ae
    filter_upwards [] with t
    unfold WeilFixedLineLaplaceKernelV6
    rw [weil_fixed_line_laplace_factor_split_v6]
    ring
  change
    (1 / (2 * Real.pi) : ℂ) *
        (∫ t : ℝ, WeilFixedLineLaplaceKernelV6 f c a (t, v)) =
      Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v)
  rw [hinter]
  have hinv :=
    weil_compact_smooth_mellin_inversion_exp_line_v6 f c v
  calc
    (1 / (2 * Real.pi) : ℂ) *
        (Complex.exp (a * (v : ℂ)) *
          ∫ t : ℝ,
            Complex.exp
              (-(((c : ℂ) + (t : ℂ) * I) * (v : ℂ))) *
              WeilFixedLineMellinV6 f c t)
        =
      Complex.exp (a * (v : ℂ)) *
        ((1 / (2 * Real.pi) : ℂ) *
          ∫ t : ℝ,
            Complex.exp
              (-(((c : ℂ) + (t : ℂ) * I) * (v : ℂ))) *
              WeilFixedLineMellinV6 f c t) := by ring
    _ = Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v) := by
      rw [hinv]

/-- The machine-checked KI identity in logarithmic coordinates. -/
theorem weil_fixed_line_kernel_integral_log_v6
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
          WeilFixedLineMellinV6 f c t) =
      ∫ v : ℝ in Ioi (0 : ℝ),
        Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v) := by
  calc
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
          WeilFixedLineMellinV6 f c t)
        =
      (1 / (2 * Real.pi) : ℂ) *
        (∫ t : ℝ,
          ∫ v : ℝ in Ioi (0 : ℝ),
            WeilFixedLineLaplaceKernelV6 f c a (t, v)) := by
              rw [weil_fixed_line_laplace_mellin_left_v6 f c a ha]
    _ =
      (1 / (2 * Real.pi) : ℂ) *
        (∫ v : ℝ in Ioi (0 : ℝ),
          ∫ t : ℝ,
            WeilFixedLineLaplaceKernelV6 f c a (t, v)) := by
              rw [weil_fixed_line_laplace_mellin_fubini_v6 f c a ha]
    _ =
      ∫ v : ℝ in Ioi (0 : ℝ),
        Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v) :=
      weil_fixed_line_laplace_mellin_right_v6 f c a

end

#print axioms weil_fixed_line_laplace_kernel_integral_v6
#print axioms weil_fixed_line_laplace_mellin_product_integrable_v6
#print axioms weil_fixed_line_laplace_mellin_fubini_v6
#print axioms weil_compact_smooth_mellin_inversion_exp_line_v6
#print axioms weil_fixed_line_kernel_integral_log_v6
~~~~~~

## WeilPairedMellinProfileV5

Path: `source/WeilPairedMellinProfileV5.lean`

Original source lines: 1–170

Full file SHA256: `e254e69e06accbd2a7ce93fc0ae027c21f76e952ef93d0cb9a4672549d164f57`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPairedMellinProfileV5.lean

~~~~~~lean
import WeilFixedLineFubiniSwapV4
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.Tactic

/-!
AEGIS Ω — concrete paired Mellin fixed-line profile v5.

#543 closes the abstract FZ/Fubini assembly for an arbitrary vertical profile H
satisfying L1 moments through order two.  This module binds that abstract H to
the actual paired Mellin profile used in the fixed-line proof:

  H_f,c(t) = M f(c+it) + M f(1-c-it).

The second summand is the vertical line 1-c composed with t ↦ -t.  Lebesgue
measure is invariant under negation, so the already kernel-verified Schwartz
moment bounds transfer directly.

No kernel integral evaluation, gamma/digamma normalization, arithmetic sign,
global Weil positivity, or RH conclusion is asserted here.
-/

open Set Filter Topology Complex MeasureTheory
open scoped BigOperators

set_option autoImplicit false

noncomputable section

/-- The exact paired Mellin profile appearing in the fixed-line Hadamard proof. -/
def WeilPairedMellinProfileV5
    (f : WeilCompactSmoothGV1) (c t : ℝ) : ℂ :=
  mellin f.1 ((c : ℂ) + (t : ℂ) * I) +
    mellin f.1 (((1 - c : ℝ) : ℂ) + ((-t : ℝ) : ℂ) * I)

/-- Algebraic identification with F(s)+F(1-s) on the line s=c+it. -/
theorem weil_paired_mellin_profile_eq_one_sub_v5
    (f : WeilCompactSmoothGV1) (c t : ℝ) :
    WeilPairedMellinProfileV5 f c t =
      mellin f.1 ((c : ℂ) + (t : ℂ) * I) +
        mellin f.1 (1 - ((c : ℂ) + (t : ℂ) * I)) := by
  unfold WeilPairedMellinProfileV5
  congr 2
  push_cast
  ring

private theorem paired_mellin_line_neg_integrable_v5
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    Integrable (fun t : ℝ =>
      mellin f.1 ((σ : ℂ) + ((-t : ℝ) : ℂ) * I)) := by
  have h : Integrable (fun t : ℝ =>
      mellin f.1 ((σ : ℂ) + (t : ℂ) * I)) := by
    exact weil_compact_smooth_mellin_vertical_integrable_all_v1 f σ
  have hcomp :=
    (Measure.measurePreserving_neg (volume : Measure ℝ)).integrable_comp_of_integrable h
  simpa [Function.comp_def] using hcomp

private theorem paired_mellin_line_neg_abs_moment_one_v5
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    Integrable (fun t : ℝ =>
      |t| * ‖mellin f.1 ((σ : ℂ) + ((-t : ℝ) : ℂ) * I)‖) := by
  have h := weil_compact_smooth_mellin_vertical_abs_moment_one_v2 f σ
  have hcomp :=
    (Measure.measurePreserving_neg (volume : Measure ℝ)).integrable_comp_of_integrable h
  simpa [Function.comp_def] using hcomp

private theorem paired_mellin_line_neg_abs_moment_two_v5
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    Integrable (fun t : ℝ =>
      |t| ^ 2 * ‖mellin f.1 ((σ : ℂ) + ((-t : ℝ) : ℂ) * I)‖) := by
  have h := weil_compact_smooth_mellin_vertical_abs_moment_two_v3 f σ
  have hcomp :=
    (Measure.measurePreserving_neg (volume : Measure ℝ)).integrable_comp_of_integrable h
  simpa [Function.comp_def] using hcomp

/-- The concrete paired Mellin profile satisfies exactly the abstract
A0/A1/A2 contract consumed by the fixed-line FZ/Fubini theorem. -/
theorem weil_paired_mellin_profile_has_vertical_norm_moments_two_v5
    (f : WeilCompactSmoothGV1) (c : ℝ) :
    HasVerticalNormMomentsTwoV3 (WeilPairedMellinProfileV5 f c) := by
  let F₁ : ℝ → ℂ := fun t =>
    mellin f.1 ((c : ℂ) + (t : ℂ) * I)
  let F₂ : ℝ → ℂ := fun t =>
    mellin f.1 (((1 - c : ℝ) : ℂ) + ((-t : ℝ) : ℂ) * I)

  have h0₁ : Integrable F₁ := by
    dsimp [F₁]
    exact weil_compact_smooth_mellin_vertical_integrable_all_v1 f c
  have h0₂ : Integrable F₂ := by
    dsimp [F₂]
    exact paired_mellin_line_neg_integrable_v5 f (1 - c)
  have h0 : Integrable (WeilPairedMellinProfileV5 f c) := by
    apply (h0₁.add h0₂).congr
    filter_upwards [] with t
    rfl

  have h1₁ : Integrable (fun t : ℝ => |t| * ‖F₁ t‖) := by
    dsimp [F₁]
    exact weil_compact_smooth_mellin_vertical_abs_moment_one_v2 f c
  have h1₂ : Integrable (fun t : ℝ => |t| * ‖F₂ t‖) := by
    dsimp [F₂]
    exact paired_mellin_line_neg_abs_moment_one_v5 f (1 - c)
  have h1major :
      Integrable (fun t : ℝ => |t| * ‖F₁ t‖ + |t| * ‖F₂ t‖) :=
    h1₁.add h1₂
  have h1meas :
      AEStronglyMeasurable
        (fun t : ℝ => |t| * ‖WeilPairedMellinProfileV5 f c t‖) := by
    exact continuous_abs.aestronglyMeasurable.mul h0.norm.aestronglyMeasurable
  have h1 :
      Integrable (fun t : ℝ =>
        |t| * ‖WeilPairedMellinProfileV5 f c t‖) := by
    refine h1major.mono' h1meas
      (Filter.Eventually.of_forall fun t => ?_)
    rw [Real.norm_eq_abs,
      abs_of_nonneg (mul_nonneg (abs_nonneg t) (norm_nonneg _))]
    have htri : ‖F₁ t + F₂ t‖ ≤ ‖F₁ t‖ + ‖F₂ t‖ := norm_add_le _ _
    have hmul := mul_le_mul_of_nonneg_left htri (abs_nonneg t)
    simpa [WeilPairedMellinProfileV5, F₁, F₂, mul_add] using hmul

  have h2₁ : Integrable (fun t : ℝ => |t| ^ 2 * ‖F₁ t‖) := by
    dsimp [F₁]
    exact weil_compact_smooth_mellin_vertical_abs_moment_two_v3 f c
  have h2₂ : Integrable (fun t : ℝ => |t| ^ 2 * ‖F₂ t‖) := by
    dsimp [F₂]
    exact paired_mellin_line_neg_abs_moment_two_v5 f (1 - c)
  have h2major :
      Integrable (fun t : ℝ =>
        |t| ^ 2 * ‖F₁ t‖ + |t| ^ 2 * ‖F₂ t‖) :=
    h2₁.add h2₂
  have h2meas :
      AEStronglyMeasurable
        (fun t : ℝ => |t| ^ 2 *
          ‖WeilPairedMellinProfileV5 f c t‖) := by
    exact (continuous_abs.pow 2).aestronglyMeasurable.mul
      h0.norm.aestronglyMeasurable
  have h2 :
      Integrable (fun t : ℝ =>
        |t| ^ 2 * ‖WeilPairedMellinProfileV5 f c t‖) := by
    refine h2major.mono' h2meas
      (Filter.Eventually.of_forall fun t => ?_)
    rw [Real.norm_eq_abs,
      abs_of_nonneg (mul_nonneg (sq_nonneg |t|) (norm_nonneg _))]
    have htri : ‖F₁ t + F₂ t‖ ≤ ‖F₁ t‖ + ‖F₂ t‖ := norm_add_le _ _
    have hmul := mul_le_mul_of_nonneg_left htri (sq_nonneg |t|)
    simpa [WeilPairedMellinProfileV5, F₁, F₂, mul_add] using hmul

  exact ⟨h0, h1, h2⟩

/-- Concrete specialization of #543's abstract fixed-line assembly to the
actual paired Mellin profile F(s)+F(1-s). -/
theorem riemannXi_paired_mellin_logDeriv_fixed_line_integral_v5
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    (∫ t : ℝ,
      (2 * _root_.logDeriv LiCriterion.riemannXi
        ((c : ℂ) + (t : ℂ) * I)) *
          WeilPairedMellinProfileV5 f c t) =
      ∑' ρ : LiCriterion.NontrivialZero,
        ∫ t : ℝ,
          ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            WeilPairedZeroKernelV3 c t ρ) *
              WeilPairedMellinProfileV5 f c t := by
  exact riemannXi_paired_logDeriv_fixed_line_integral_v4
    (WeilPairedMellinProfileV5 f c) c hc
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c)

end

#print axioms weil_paired_mellin_profile_eq_one_sub_v5
#print axioms weil_paired_mellin_profile_has_vertical_norm_moments_two_v5
#print axioms riemannXi_paired_mellin_logDeriv_fixed_line_integral_v5
~~~~~~

