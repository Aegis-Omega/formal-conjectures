# AEGIS source modules 11

Exact pinned or operator archive source. Compilation was not performed during transfer.

## AEGISOverlay.RHKreinDigammaLowerBoundV1

Path: `source/AEGISOverlay/RHKreinDigammaLowerBoundV1.lean`

Original source lines: 1–200

Full file SHA256: `37577feb54ea093f81219a28498f863624aff9d2ee9ff7018d5979c4076fb219`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinDigammaLowerBoundV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import WeilDigammaSeriesHalfPlaneV1
import RHEulerGammaV13
import Mathlib.Tactic

/-!
# Exact finite lower bound for the actual quarter-line digamma function

This is the rational-tail inequality used in
`research/rh/krein_order19_v1/certify.py`. It follows from the repository's
proved series for Mathlib's `Complex.digamma`. A telescoping minorant bounds
the entire tail; there is no numerical premise and no finite-grid inference.
-/

open Filter Complex
open scoped Topology BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinDigammaLowerBoundV1

open AEGIS.WeilDigammaIntegralReductionV1
open AEGIS.WeilDigammaSeriesRealV1
open AEGIS.WeilDigammaSeriesHalfPlaneV1

/-- The exact rational summand in the real quarter-line digamma series. -/
def quarterTerm (t : ℝ) (n : ℕ) : ℝ :=
  1 / ((n : ℝ) + 1) -
    ((n : ℝ) + 1 / 4) / (((n : ℝ) + 1 / 4) ^ 2 + t ^ 2 / 4)

/-- The argument of Mathlib's actual digamma function. -/
def quarterPoint (t : ℝ) : ℂ := (1 / 4 : ℂ) + (t : ℂ) * I / 2

private theorem quarterPoint_re (t : ℝ) : (quarterPoint t).re = 1 / 4 := by
  simp [quarterPoint]

/-- This finite summand is the real part of the already-proved complex series. -/
theorem quarterTerm_eq_seriesTerm_re (t : ℝ) (n : ℕ) :
    quarterTerm t n = (seriesTerm (quarterPoint t) n).re := by
  have hfirst : (1 / ((n : ℂ) + 1)).re = 1 / ((n : ℝ) + 1) := by
    have hcast : (n : ℂ) + 1 = (((n : ℝ) + 1 : ℝ) : ℂ) := by push_cast; rfl
    rw [hcast]
    norm_cast
  have hzre : (quarterPoint t + n).re = (n : ℝ) + 1 / 4 := by
    simp [quarterPoint]
    ring
  have hzim : (quarterPoint t + n).im = t / 2 := by simp [quarterPoint]
  have hsq : normSq (quarterPoint t + n) = ((n : ℝ) + 1 / 4) ^ 2 + t ^ 2 / 4 := by
    rw [Complex.normSq_apply, hzre, hzim]
    ring
  have hsecond : (1 / (quarterPoint t + n)).re =
      ((n : ℝ) + 1 / 4) / (((n : ℝ) + 1 / 4) ^ 2 + t ^ 2 / 4) := by
    rw [one_div, Complex.inv_re, hzre, hsq]
  simp only [quarterTerm, seriesTerm, Complex.sub_re, hfirst, hsecond]

private theorem quarterTerm_lower (t : ℝ) (n : ℕ) :
    -(3 / 4 : ℝ) / ((n : ℝ) + 1 / 4) ^ 2 ≤ quarterTerm t n := by
  let x : ℝ := (n : ℝ) + 1 / 4
  have hx : 0 < x := by dsimp [x]; positivity
  have hd : 0 < (n : ℝ) + 1 := by positivity
  have hrecip : x / (x ^ 2 + t ^ 2 / 4) ≤ 1 / x := by
    calc
      x / (x ^ 2 + t ^ 2 / 4) ≤ x / x ^ 2 :=
        div_le_div_of_nonneg_left hx.le (sq_pos_of_pos hx) (by nlinarith [sq_nonneg t])
      _ = 1 / x := by field_simp
  have hprod : x ^ 2 ≤ ((n : ℝ) + 1) * x := by dsimp [x]; nlinarith
  have hb := div_le_div_of_nonneg_left (by norm_num : (0 : ℝ) ≤ 3 / 4)
    (sq_pos_of_pos hx) hprod
  have heq : 1 / ((n : ℝ) + 1) - 1 / x =
      -(3 / 4 : ℝ) / (((n : ℝ) + 1) * x) := by
    dsimp [x]
    field_simp
    ring
  change -(3 / 4 : ℝ) / x ^ 2 ≤
    1 / ((n : ℝ) + 1) - x / (x ^ 2 + t ^ 2 / 4)
  simp only [neg_div] at heq ⊢
  linarith

private theorem reciprocal_square_telescoper (q x : ℝ)
    (hq : 0 < q) (hqx : q ≤ x) :
    1 / x ^ 2 ≤ (1 + 1 / q) * (1 / x - 1 / (x + 1)) := by
  have hx : 0 < x := lt_of_lt_of_le hq hqx
  have hx1 : 0 < x + 1 := by linarith
  have hxq : x ≤ x ^ 2 / q := by
    apply (le_div_iff₀ hq).2
    nlinarith [mul_nonneg hx.le (sub_nonneg.mpr hqx)]
  have heq : (1 + 1 / q) * (1 / x - 1 / (x + 1)) =
      (1 + 1 / q) / (x * (x + 1)) := by
    field_simp
    ring
  rw [heq]
  apply (div_le_div_iff₀ (sq_pos_of_pos hx) (mul_pos hx hx1)).2
  simp only [div_eq_mul_inv, one_mul] at hxq ⊢
  nlinarith

/-- A telescoping lower bound for each term of the omitted tail. -/
theorem quarterTerm_telescoping_lower (t : ℝ) (N n : ℕ) (hN : N ≤ n) :
    -(3 / 4 : ℝ) * (1 + 1 / ((N : ℝ) + 1 / 4)) *
      (1 / ((n : ℝ) + 1 / 4) - 1 / ((n : ℝ) + 1 / 4 + 1)) ≤
        quarterTerm t n := by
  have hrecip := reciprocal_square_telescoper
    ((N : ℝ) + 1 / 4) ((n : ℝ) + 1 / 4)
    (by positivity) (by
      have hcast : (N : ℝ) ≤ n := Nat.cast_le.mpr hN
      linarith)
  have hmul := mul_le_mul_of_nonneg_left hrecip (by norm_num : (0 : ℝ) ≤ 3 / 4)
  have hterm := quarterTerm_lower t n
  simp only [div_eq_mul_inv] at hmul hterm ⊢
  nlinarith only [hmul, hterm]

private theorem finite_tail_lower (t : ℝ) (N k : ℕ) :
    (∑ n ∈ Finset.range N, quarterTerm t n) -
        (3 / 4 : ℝ) * (1 + 1 / ((N : ℝ) + 1 / 4)) / ((N : ℝ) + 1 / 4) +
        (3 / 4 : ℝ) * (1 + 1 / ((N : ℝ) + 1 / 4)) /
          ((N + k : ℕ) + 1 / 4 : ℝ) ≤
      ∑ n ∈ Finset.range (N + k), quarterTerm t n := by
  induction k with
  | zero => simp
  | succ k ih =>
    have ht := quarterTerm_telescoping_lower t N (N + k) (by omega)
    rw [Nat.add_succ, Finset.sum_range_succ]
    push_cast at ht ih ⊢
    rw [show (N : ℝ) + k + 1 + 1 / 4 = (N : ℝ) + k + 1 / 4 + 1 by ring]
    simp only [div_eq_mul_inv] at ht ih ⊢
    nlinarith only [ht, ih]

private theorem quarter_partial_sums_tendsto (t : ℝ) :
    Tendsto (fun k : ℕ => ∑ n ∈ Finset.range k, quarterTerm t n)
      atTop (𝓝 ((Complex.digamma (quarterPoint t)).re + Real.eulerMascheroniConstant)) := by
  have hz : 0 < (quarterPoint t).re := by rw [quarterPoint_re]; norm_num
  have hs : Summable (seriesTerm (quarterPoint t)) :=
    (summable_norm_seriesTerm_v1 (quarterPoint t) hz).of_norm
  have hc := hs.hasSum.tendsto_sum_nat
  rw [← digamma_series_halfPlane_v1 (quarterPoint t) hz] at hc
  have hr := Complex.continuous_re.continuousAt.tendsto.comp hc
  simpa only [Function.comp_def, Complex.re_sum, ← quarterTerm_eq_seriesTerm_re,
    Complex.add_re, Complex.ofReal_re] using hr

/-- Exact finite lower bound with the true Euler constant. -/
theorem digamma_quarter_finite_lower (t : ℝ) (N : ℕ) :
    -Real.eulerMascheroniConstant + (∑ n ∈ Finset.range N, quarterTerm t n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma (quarterPoint t)).re := by
  have hshift : Tendsto (fun k : ℕ => N + k) atTop atTop := by
    refine tendsto_atTop.2 (fun b => ?_)
    filter_upwards [eventually_ge_atTop b] with k hk
    omega
  have hlim := (quarter_partial_sums_tendsto t).comp hshift
  have hbound : ∀ k : ℕ,
      (∑ n ∈ Finset.range N, quarterTerm t n) -
        (3 / 4 : ℝ) * (1 + 1 / ((N : ℝ) + 1 / 4)) / ((N : ℝ) + 1 / 4) ≤
        ∑ n ∈ Finset.range (N + k), quarterTerm t n := by
    intro k
    have h := finite_tail_lower t N k
    have hp : 0 ≤ (3 / 4 : ℝ) * (1 + 1 / ((N : ℝ) + 1 / 4)) /
        ((N + k : ℕ) + 1 / 4 : ℝ) := by positivity
    linarith
  have h := ge_of_tendsto' hlim hbound
  have heq : (3 / 4 : ℝ) * (1 + 1 / ((N : ℝ) + 1 / 4)) /
      ((N : ℝ) + 1 / 4) =
      (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) + 1 / ((N : ℝ) + 1 / 4) ^ 2) := by
    field_simp
  rw [heq] at h
  linarith

/-- The exact all-real-frequency lower bound consumed by the rational
order-19 certificate, using the kernel-proved upper bound for Euler's constant. -/
theorem digamma_quarter_certificate_lower (t : ℝ) (N : ℕ) :
    -(5792 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm t n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * I / 2)).re := by
  have h := digamma_quarter_finite_lower t N
  have hg := AEGIS.RHEulerGammaV13.gamma_lt
  dsimp [quarterPoint] at h
  linarith

end AEGIS.RHKreinDigammaLowerBoundV1

#print axioms AEGIS.RHKreinDigammaLowerBoundV1.quarterTerm_eq_seriesTerm_re
#print axioms AEGIS.RHKreinDigammaLowerBoundV1.quarterTerm_telescoping_lower
#print axioms AEGIS.RHKreinDigammaLowerBoundV1.digamma_quarter_finite_lower
#print axioms AEGIS.RHKreinDigammaLowerBoundV1.digamma_quarter_certificate_lower
~~~~~~

## RHEulerGammaV13

Path: `source/RHEulerGammaV13.lean`

Original source lines: 1–63

Full file SHA256: `d38a34e6626e3750afe6a672274ba8c0be8dbcebc7d41c85da64c6afb01517f5`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/RHEulerGammaV13.lean

~~~~~~lean
import Mathlib

/-!
AEGIS Ω — a sharp enclosure of Euler's constant, V13.

`0.5752 < γ < 0.5792`. Mathlib's stated `1/2 < γ < 2/3` is too coarse for the margins `0.02 … 0.1` of
the Fourier-side (Krein) certificate in `RH_STATUS.md`, where `γ` enters additively through
`Re ψ(1/4 + iξ/2) = −γ + Σ (1/(n+1) − Re 1/(n + 1/4 + iξ/2))`.

Proof: Mathlib's monotone sandwich `H_n − log(n+1) < γ < H_n − log n`, taken at `n = 256`.
- `H₂₅₆` is enclosed as an exact rational sum.
- `log 256 = 8·log 2` is bounded by `Real.log_two_gt_d9` and `Real.log_two_lt_d9`.
- `log 257 ≤ log 256 + 1/256` follows from `log x ≤ x − 1`.

Not RH. AUTHORITY_EFFECT = NONE.
-/

open Real
set_option autoImplicit false

namespace AEGIS.RHEulerGammaV13

set_option maxRecDepth 100000 in
theorem harmonic_256_bounds :
    (6124344 / 1000000 : ℚ) < harmonic 256 ∧ harmonic 256 < (6124345 / 1000000 : ℚ) := by
  constructor <;> simp only [harmonic, Finset.sum_range_succ, Finset.sum_range_zero] <;> norm_num

theorem log_256 : Real.log 256 = 8 * Real.log 2 := by
  rw [show (256 : ℝ) = 2 ^ 8 by norm_num, Real.log_pow]; norm_num

/-- `γ < 0.5792`, from `γ < H₂₅₆ − log 256` and `log 2 > 0.6931471803`. -/
theorem gamma_lt : eulerMascheroniConstant < 5792 / 10000 := by
  have h := eulerMascheroniConstant_lt_eulerMascheroniSeq' 256
  simp only [eulerMascheroniSeq', show (256 : ℕ) ≠ 0 by norm_num, if_false] at h
  have hH : (harmonic 256 : ℝ) < 6124345 / 1000000 := by
    have h' := (Rat.cast_lt (K := ℝ)).mpr harmonic_256_bounds.2
    push_cast at h'; exact h'
  have hl : (Real.log ((256 : ℕ) : ℝ)) = 8 * Real.log 2 := by push_cast; exact log_256
  have h2 := Real.log_two_gt_d9
  rw [hl] at h
  norm_num at h2
  linarith

/-- `0.5752 < γ`, from `H₂₅₆ − log 257 < γ` and `log 257 ≤ log 256 + 1/256`. -/
theorem lt_gamma : (5752 / 10000 : ℝ) < eulerMascheroniConstant := by
  have h := eulerMascheroniSeq_lt_eulerMascheroniConstant 256
  unfold eulerMascheroniSeq at h
  have hH : (6124344 / 1000000 : ℝ) < (harmonic 256 : ℝ) := by
    have h' := (Rat.cast_lt (K := ℝ)).mpr harmonic_256_bounds.1
    push_cast at h'; exact h'
  rw [show ((256 : ℕ) : ℝ) + 1 = 257 by norm_num] at h
  have h257 : Real.log 257 ≤ 8 * Real.log 2 + 1 / 256 := by
    have hq : Real.log ((257 : ℝ) / 256) ≤ (257 : ℝ) / 256 - 1 := Real.log_le_sub_one_of_pos (by norm_num)
    rw [Real.log_div (by norm_num) (by norm_num), log_256] at hq
    linarith
  have h2 := Real.log_two_lt_d9
  norm_num at h2
  linarith

end AEGIS.RHEulerGammaV13

#print axioms AEGIS.RHEulerGammaV13.gamma_lt
#print axioms AEGIS.RHEulerGammaV13.lt_gamma
~~~~~~

## RHKreinSecondCellReductionV1

Path: `source/RHKreinSecondCellReductionV1.lean`

Original source lines: 1–95

Full file SHA256: `37d8da4328ef03e500dc3a0922e9a3427c414f805ef26528f7e5782585893d5b`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinSymmetricCellProducerV1

/-!
# Generated reduction for serialized cell 1 (zero-based)

This is the first concrete consumer of the generic symmetric-cell producer.
Exact arithmetic closes the geometry, polynomial floor, M8 error, weight, and
ground budget.  Only the eight jet enclosures and uniform symbol enclosure are
retained as explicit analytic premises.

AUTHORITY_EFFECT = NONE.
-/

set_option autoImplicit false
set_option maxHeartbeats 200000
noncomputable section

namespace AEGIS.RHKreinSecondCellReductionV1

open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinSymmetricCellProducerV1

def secondCell : FiniteCellV1 :=
  ⟨75 / 4096, 225 / 8192, 123598475210567660⟩

def secondCenter : ℝ := 375 / 16384
def secondRadius : ℝ := 75 / 16384

def secondJet : ℕ → ℝ
  | 0 => 80815639731 / 200000000000
  | 1 => 102811909419 / 1000000000000
  | 2 => 2250352788951 / 1000000000000
  | 3 => 191886691311 / 1000000000000
  | 4 => 2094913562929 / 1000000000000
  | 5 => -26262597593 / 1000000000000
  | 6 => -6007036577 / 31250000000
  | 7 => -18448316629 / 1000000000000
  | _ => 0

def secondJetError (_ : ℕ) : ℝ := 1 / 1000000000000
def secondSymbolLower : ℝ := -793621747503 / 125000000000
def secondWeightUpper : ℝ := 283176232721281 / 4503599627370496

/-- Exact second-cell reduction.  The hypotheses say precisely what the
remaining kernel enclosure generator must prove. -/
theorem secondCell_sound_of_enclosures
    (hjet : ∀ k ∈ Finset.range 8,
      |exactJetCoefficient secondCenter k - secondJet k| ≤ secondJetError k)
    (hsymbol : ∀ t : ℝ, (secondCell.lo : ℝ) ≤ t → t ≤ (secondCell.hi : ℝ) →
      secondSymbolLower ≤ AEGIS.RHKreinPrimeSymbolV1.symbol t) :
    CellAnalyticSoundV1 secondCell := by
  apply cellAnalyticSound_of_symmetric_jet_box secondCell secondCenter secondRadius
    secondJet secondJetError secondSymbolLower secondWeightUpper
  · norm_num [secondRadius]
  · intro t hlo hhi
    norm_num [secondCell, secondCenter, secondRadius] at hlo hhi ⊢
    rw [abs_le]
    constructor <;> linarith
  · exact hjet
  · exact hsymbol
  · intro t hlo hhi
    norm_num [secondCell, secondWeightUpper] at hlo hhi ⊢
    have ht0 : 0 ≤ t := by linarith
    nlinarith [sq_nonneg t,
      mul_nonneg (sub_nonneg.mpr hhi)
        (add_nonneg ht0 (by norm_num : (0 : ℝ) ≤ 225 / 8192))]
  · norm_num [secondCell, lowerValue]
  · norm_num [secondSymbolLower]
  · norm_num [secondCell, secondRadius, secondJet, secondJetError,
      secondSymbolLower, secondWeightUpper, lowerValue,
      symmetricPolynomialFloor, symmetricTaylorError,
      AEGIS.RHKreinM8CertificateV1.serializedM8Q,
      Finset.sum_range_succ]

end AEGIS.RHKreinSecondCellReductionV1

#print axioms AEGIS.RHKreinSecondCellReductionV1.secondCell_sound_of_enclosures
~~~~~~

## RHKreinSymmetricCellProducerV1

Path: `source/RHKreinSymmetricCellProducerV1.lean`

Original source lines: 1–133

Full file SHA256: `ec5e379dcf14d6b3856e2d37a2ae6979e2d6da21a6c4d06eec923ad3fadaa65c`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinCellAnalyticBridgeV1

/-!
# Generic symmetric-cell producer for the M8 certificate

This file packages the reusable exact part of the per-cell proof.  Given a
centered radius enclosure, eight jet enclosures, a uniform symbol lower bound,
and one rational ground-budget inequality, the kernel proves
`CellAnalyticSoundV1 c`.

The deliberately conservative polynomial floor

`q 0 - sum k=1..7 |q k| * radius^k`

works without sign analysis.  It is intended as a code-generation target for
the remaining serialized cells.  This theorem does not manufacture the
transcendental jet or symbol enclosures and does not assert all-cell or RH
closure.

AUTHORITY_EFFECT = NONE.
-/

open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSymmetricCellProducerV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1

/-- A sign-independent rational floor for a degree-seven centered jet. -/
def symmetricPolynomialFloor (q : ℕ → ℝ) (radius : ℝ) : ℝ :=
  q 0 - ∑ k ∈ Finset.range 7, |q (k + 1)| * radius ^ (k + 1)

/-- The complete M8-plus-jet error attached to a symmetric cell. -/
def symmetricTaylorError (radius : ℝ) (e : ℕ → ℝ) : ℝ :=
  (serializedM8Q : ℝ) * radius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, e k * radius ^ k

private theorem symmetricPolynomialFloor_le
    (q : ℕ → ℝ) (center radius t : ℝ)
    (ht : |t - center| ≤ radius) :
    symmetricPolynomialFloor q radius ≤ jetPolynomial7 q center t := by
  unfold symmetricPolynomialFloor jetPolynomial7
  conv_rhs => rw [Finset.sum_range_succ']
  simp only [pow_zero, mul_one]
  apply sub_le_iff_le_add.mp
  have hterm : ∀ k ∈ Finset.range 7,
      -(q (k + 1) * (t - center) ^ (k + 1)) ≤
        |q (k + 1)| * radius ^ (k + 1) := by
    intro k hk
    have hpow : |t - center| ^ (k + 1) ≤ radius ^ (k + 1) :=
      pow_le_pow_left₀ (abs_nonneg _) ht _
    have habs : |q (k + 1) * (t - center) ^ (k + 1)| ≤
        |q (k + 1)| * radius ^ (k + 1) := by
      rw [abs_mul, abs_pow]
      exact mul_le_mul_of_nonneg_left hpow (abs_nonneg _)
    apply le_of_abs_le
    simpa only [abs_neg] using habs
  have hsum := Finset.sum_le_sum hterm
  have hsum' :
      -(∑ k ∈ Finset.range 7, q (k + 1) * (t - center) ^ (k + 1)) ≤
        ∑ k ∈ Finset.range 7, |q (k + 1)| * radius ^ (k + 1) := by
    simpa only [Finset.sum_neg_distrib] using hsum
  linarith

/-- Generic kernel producer for a cell centered in a symmetric radius box.

Only `hjet` and `hsymbol` contain cell-specific analytic content.  The other
premises are exact rational geometry/budget checks suitable for generated
`norm_num` proofs. -/
theorem cellAnalyticSound_of_symmetric_jet_box
    (c : FiniteCellV1) (center radius : ℝ) (q e : ℕ → ℝ)
    (symbolLower weightUpper : ℝ)
    (hradius : 0 ≤ radius)
    (hcover : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      |t - center| ≤ radius)
    (hjet : ∀ k ∈ Finset.range 8, |exactJetCoefficient center k - q k| ≤ e k)
    (hsymbol : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      symbolLower ≤ symbol t)
    (hweight : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      (t ^ 2 + 1 / 4) ^ 2 ≤ weightUpper)
    (hlower : 0 ≤ (lowerValue c : ℝ))
    (hsymbolNonpos : symbolLower - 1 / 16 ≤ 0)
    (hground : weightUpper * (lowerValue c : ℝ) ≤
      weightUpper * (symbolLower - 1 / 16) +
        (symmetricPolynomialFloor q radius - symmetricTaylorError radius e)) :
    CellAnalyticSoundV1 c := by
  apply cellAnalyticSound_of_jet_enclosures c center radius
    (symmetricPolynomialFloor q radius) q e hradius hcover hjet
  · intro t hlo hhi
    exact symmetricPolynomialFloor_le q center radius t (hcover t hlo hhi)
  · intro t hlo hhi
    have hw0 : 0 ≤ (t ^ 2 + 1 / 4) ^ 2 := sq_nonneg _
    have hlhs : (t ^ 2 + 1 / 4) ^ 2 * (lowerValue c : ℝ) ≤
        weightUpper * (lowerValue c : ℝ) :=
      mul_le_mul_of_nonneg_right (hweight t hlo hhi) hlower
    have hneg : weightUpper * (symbolLower - 1 / 16) ≤
        (t ^ 2 + 1 / 4) ^ 2 * (symbolLower - 1 / 16) :=
      mul_le_mul_of_nonpos_right (hweight t hlo hhi) hsymbolNonpos
    have hsym : (t ^ 2 + 1 / 4) ^ 2 * (symbolLower - 1 / 16) ≤
        (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) :=
      mul_le_mul_of_nonneg_left (sub_le_sub_right (hsymbol t hlo hhi) _) hw0
    change (t ^ 2 + 1 / 4) ^ 2 * (lowerValue c : ℝ) ≤
      (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
        (symmetricPolynomialFloor q radius - symmetricTaylorError radius e)
    linarith

end AEGIS.RHKreinSymmetricCellProducerV1

#print axioms AEGIS.RHKreinSymmetricCellProducerV1.cellAnalyticSound_of_symmetric_jet_box
~~~~~~

## RHKreinEighthCellCompositionV1

Path: `source/RHKreinEighthCellCompositionV1.lean`

Original source lines: 1–172

Full file SHA256: `8c86919663cab4b77707b5647d9da749dfd81ace97032ec6dd38736c1803902b`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinSeventhCellCompositionV1

/-!
# Compose the existing zero jet into the eighth serialized cell

The sixth-left symbol floor is valid at every later nonnegative frequency.
Together with the existing zero jet and the exact PR54 finite-window M8 bound,
it closes serialized cell index 7 without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinEighthCellCompositionV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSeventhCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1
open AEGIS.RHKreinSixthCellReductionV1

/-- The literal eighth entry of the unchanged committed payload. -/
def eighthCell : FiniteCellV1 :=
  ⟨825 / 16384, 225 / 4096, 120083874866890649⟩

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 225 / 4096
private def symbolFloor : ℝ := sixthSymbolLower
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue eighthCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 10000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    eighthCell, sixthSymbolLower, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, eighthCell,
        sixthSymbolLower, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, eighthCell,
        sixthSymbolLower, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The eighth serialized lower bound follows from the already proved zero jet,
finite-window M8 theorem, and sixth-left symbol floor. -/
theorem eighthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 eighthCell := by
  apply cellAnalyticSound_of_correction_lower eighthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [eighthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [eighthCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [eighthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [eighthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 10000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := by
      dsimp only [symbolFloor]
      apply symbol_lower_of_sixthLeft_le
      norm_num [eighthCell] at hlo ⊢
      linarith
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue eighthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first eight unchanged serialized cell results compose as a tuple. -/
theorem first_eight_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 sixthCell ∧ CellAnalyticSoundV1 seventhCell ∧
      CellAnalyticSoundV1 eighthCell :=
  ⟨first_seven_cells_sound.1, first_seven_cells_sound.2.1,
    first_seven_cells_sound.2.2.1, first_seven_cells_sound.2.2.2.1,
    first_seven_cells_sound.2.2.2.2.1, first_seven_cells_sound.2.2.2.2.2.1,
    first_seven_cells_sound.2.2.2.2.2.2,
    eighthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinEighthCellCompositionV1

#print axioms AEGIS.RHKreinEighthCellCompositionV1.eighthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinEighthCellCompositionV1.first_eight_cells_sound
~~~~~~

## RHKreinSeventhCellCompositionV1

Path: `source/RHKreinSeventhCellCompositionV1.lean`

Original source lines: 1–169

Full file SHA256: `d4fed8e710727d5b9d8a25e01aefacb84946a5d52c7c23e43d48f5d93ffdce6f`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinSixthCellCompositionV1

/-!
# Compose the existing zero jet into the seventh serialized cell

The sixth-left symbol floor is valid at every later nonnegative frequency.
Together with the existing zero jet and the exact PR54 finite-window M8 bound,
it closes serialized cell index 6 without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinSeventhCellCompositionV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1
open AEGIS.RHKreinSixthCellReductionV1

/-- The literal seventh entry of the unchanged committed payload. -/
def seventhCell : FiniteCellV1 :=
  ⟨375 / 8192, 825 / 16384, 152314342263794501⟩

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 825 / 16384
private def symbolFloor : ℝ := sixthSymbolLower
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue seventhCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 2000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    seventhCell, sixthSymbolLower, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, seventhCell,
        sixthSymbolLower, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, seventhCell,
        sixthSymbolLower, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The seventh serialized lower bound follows from the already proved zero jet,
finite-window M8 theorem, and sixth-left symbol floor. -/
theorem seventhCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 seventhCell := by
  apply cellAnalyticSound_of_correction_lower seventhCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [seventhCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [seventhCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [seventhCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [seventhCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 2000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := by
      dsimp only [symbolFloor]
      apply symbol_lower_of_sixthLeft_le
      norm_num [seventhCell] at hlo ⊢
      linarith
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue seventhCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first seven unchanged serialized cell results compose as a tuple. -/
theorem first_seven_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 sixthCell ∧ CellAnalyticSoundV1 seventhCell :=
  ⟨first_six_cells_sound.1, first_six_cells_sound.2.1,
    first_six_cells_sound.2.2.1, first_six_cells_sound.2.2.2.1,
    first_six_cells_sound.2.2.2.2.1, first_six_cells_sound.2.2.2.2.2,
    seventhCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinSeventhCellCompositionV1

#print axioms AEGIS.RHKreinSeventhCellCompositionV1.seventhCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinSeventhCellCompositionV1.first_seven_cells_sound
~~~~~~

## RHKreinSixthCellCompositionV1

Path: `source/RHKreinSixthCellCompositionV1.lean`

Original source lines: 1–203

Full file SHA256: `65720703bd33030bdddab674b1c89127880af9266b6edfd356f2a5e06c449b86`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFifthCellCompositionV1
import RHKreinSixthCellReductionV1
import research.rh.finite_m8_v1.RHKreinM8FiniteWindowV1

/-!
# Compose the existing zero jet into the sixth serialized cell

The finite-window eighth-derivative theorem from PR54 is stated for the same
`correctionSymbol` and uses the same Lean and Mathlib pins as PR53.  Its exact
bound on `|t| ≤ 300` is strong enough to reuse the already proved zero-centered
jet through the sixth cell.  Thus no new midpoint-jet assumptions are needed.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinSixthCellCompositionV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinCorrectionM8BoundV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinFifthCellCompositionV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8FiniteWindowV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellReductionV1

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 375 / 8192
private def symbolFloor : ℝ := sixthSymbolLower
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue sixthCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

/-- The PR54 finite-window bound gives a local Taylor remainder on `[0, x]`.
The proof consumes the actual intermediate point returned by Lagrange's theorem,
so it does not strengthen the finite-window theorem to a global claim. -/
theorem correction_taylor7_remainder_window300 (x : ℝ)
    (hx0 : 0 ≤ x) (hx300 : x ≤ 300) :
    |correctionSymbol x - centeredTaylorEval correctionSymbol 7 0 x| ≤
      finiteM8Q * |x| ^ 8 / 40320 := by
  by_cases h0x : (0 : ℝ) = x
  · subst x
    rw [centeredTaylorEval_self correctionSymbol 7 0
      (correctionSymbol_contDiff_eight.contDiffAt.of_le (by norm_num))]
    simp
  · obtain ⟨y, hy, hrem⟩ :=
      taylor_mean_remainder_lagrange_iteratedDeriv
        (f := correctionSymbol) (x := x) (x₀ := 0) (n := 7)
        h0x correctionSymbol_contDiff_eight.contDiffOn
    have htaylor :
        taylorWithinEval correctionSymbol 7 (Set.uIcc 0 x) 0 x =
          centeredTaylorEval correctionSymbol 7 0 x := by
      apply taylorWithinEval_eq_centeredTaylor
      · exact uniqueDiffOn_uIcc h0x
      · exact Set.left_mem_uIcc
      · exact correctionSymbol_contDiff_eight.contDiffAt.of_le (by norm_num)
    have hyIoo : y ∈ Set.Ioo (0 : ℝ) x := by
      simpa only [Set.uIoo_of_le hx0] using hy
    have hyIcc : y ∈ Set.Icc (0 : ℝ) x := ⟨hyIoo.1.le, hyIoo.2.le⟩
    have hy300 : |y| ≤ (300 : ℝ) := by
      rw [abs_of_nonneg hyIcc.1]
      exact hyIcc.2.trans hx300
    have hMy : |iteratedDeriv 8 correctionSymbol y| ≤ finiteM8Q := by
      simpa only [finiteM8Q] using correctionSymbol_eighth_le_window300 y hy300
    rw [← htaylor, hrem, abs_div, abs_mul, abs_pow]
    have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
    have hpow : 0 ≤ |x| ^ 8 := pow_nonneg (abs_nonneg _) _
    norm_num
    exact div_le_div_of_nonneg_right
      (mul_le_mul hMy le_rfl hpow hM0) (by norm_num)

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (9 / 10000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    sixthCell, sixthSymbolLower, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, sixthCell,
        sixthSymbolLower, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, sixthCell,
        sixthSymbolLower, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The sixth serialized lower bound follows from the existing zero jet and the
PR54 finite-window M8 theorem, with no new jet enclosure assumptions. -/
theorem sixthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 sixthCell := by
  apply cellAnalyticSound_of_correction_lower sixthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [sixthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [sixthCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [sixthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [sixthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 9 / 10000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := sixthCell_symbol_lower t hlo hhi
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue sixthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first six unchanged serialized cell results compose as a tuple. -/
theorem first_six_cells_sound :
    CellAnalyticSoundV1 firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 sixthCell :=
  ⟨first_five_cells_sound.1, first_five_cells_sound.2.1,
    first_five_cells_sound.2.2.1, first_five_cells_sound.2.2.2.1,
    first_five_cells_sound.2.2.2.2, sixthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinSixthCellCompositionV1

#print axioms AEGIS.RHKreinSixthCellCompositionV1.sixthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinSixthCellCompositionV1.first_six_cells_sound
~~~~~~

## RHKreinSixthCellReductionV1

Path: `source/RHKreinSixthCellReductionV1.lean`

Original source lines: 1–185

Full file SHA256: `425f4a067cfd1f6da59b47bcdffaeca055d94a8902a27a362cb035272666903e`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
import RHEulerGammaSharpV1

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinSixthCellReductionV1

open AEGIS.RHEulerGammaSharpV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinSymmetricCellProducerV1

def sixthCell : FiniteCellV1 :=
  ⟨675 / 16384, 375 / 8192, 185364967441091393⟩

def sixthCenter : ℝ := 1425 / 32768
def sixthRadius : ℝ := 75 / 32768

def sixthJet : ℕ → ℝ
  | 0 => 81430602793 / 200000000000
  | 1 => 6120033693 / 31250000000
  | 2 => 2267541861021 / 1000000000000
  | 3 => 91089266727 / 250000000000
  | 4 => 2090978186049 / 1000000000000
  | 5 => -50233923383 / 1000000000000
  | 6 => -49015745241 / 250000000000
  | 7 => -34698979791 / 1000000000000
  | _ => 0

def sixthJetError (_ : ℕ) : ℝ := 1 / 1000000000000
def sixthSymbolLower : ℝ := -3163405140307 / 500000000000
def sixthWeightUpper : ℝ := 286213344101281 / 4503599627370496

private def sixthLeft : ℝ := 675 / 16384

private theorem digamma_sharp_lower_of_sq_le (s t : ℝ) (N : ℕ)
    (hst : s ^ 2 ≤ t ^ 2) :
    -(5773 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hs := digamma_quarter_finite_lower s N
  have hm := digamma_quarter_mono_of_sq_le s t hst
  have hg := gamma_lt_5773
  dsimp [quarterPoint] at hs
  linarith only [hs, hm, hg]

private theorem sixthDigammaPartialLower :
    (-718379247872759 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm sixthLeft n := by
  have h0 : (-11033526878269 / 3125000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm sixthLeft n := by
    norm_num [sixthLeft, quarterTerm]
  have h1 : (-45749140284757 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm sixthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [sixthLeft, quarterTerm]
  have h2 : (-7709249016479 / 500000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm sixthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [sixthLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm sixthLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm sixthLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2]

private theorem sixthDigammaLower (t : ℝ) (hst : sixthLeft ^ 2 ≤ t ^ 2) :
    (-21007 / 5000 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_sharp_lower_of_sq_le sixthLeft t 24 hst
  have hpartial := sixthDigammaPartialLower
  norm_num [sixthLeft] at hcert ⊢
  have hpartial' : (-718379247872759 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm (675 / 16384) n := by
    simpa [sixthLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem sixthLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem sixthPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The sixth-left symbol floor remains valid at every later nonnegative
frequency; the former cell-local theorem used no upper endpoint hypothesis. -/
theorem symbol_lower_of_sixthLeft_le (t : ℝ) (hleft : (675 / 16384 : ℝ) ≤ t) :
    sixthSymbolLower ≤ symbol t := by
  have hleft' : sixthLeft ≤ t := by simpa [sixthLeft] using hleft
  have ht0 : 0 ≤ t := by
    have hleft0 : 0 ≤ sixthLeft := by norm_num [sixthLeft]
    linarith
  have hst : sixthLeft ^ 2 ≤ t ^ 2 := by
    have hleft0 : 0 ≤ sixthLeft := by norm_num [sixthLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft') (add_nonneg ht0 hleft0)]
  have hd := sixthDigammaLower t hst
  have hlp := sixthLogPiUpper
  have hamp := sixthPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num [sixthSymbolLower] at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

theorem sixthCell_symbol_lower (t : ℝ)
    (hlo : (sixthCell.lo : ℝ) ≤ t) (_hhi : t ≤ (sixthCell.hi : ℝ)) :
    sixthSymbolLower ≤ symbol t := by
  apply symbol_lower_of_sixthLeft_le
  simpa [sixthCell] using hlo

/-- Exact sixth-cell reduction.  Every rational, symbol, and M8 obligation is
closed; only the eight midpoint jet enclosures remain explicit. -/
theorem sixthCell_sound_of_midpoint_jets
    (hjet : ∀ k ∈ Finset.range 8,
      |exactJetCoefficient sixthCenter k - sixthJet k| ≤ sixthJetError k) :
    CellAnalyticSoundV1 sixthCell := by
  apply cellAnalyticSound_of_symmetric_jet_box sixthCell sixthCenter sixthRadius
    sixthJet sixthJetError sixthSymbolLower sixthWeightUpper
  · norm_num [sixthRadius]
  · intro t hlo hhi
    norm_num [sixthCell, sixthCenter, sixthRadius] at hlo hhi ⊢
    rw [abs_le]
    constructor <;> linarith
  · exact hjet
  · exact sixthCell_symbol_lower
  · intro t hlo hhi
    norm_num [sixthCell, sixthWeightUpper] at hlo hhi ⊢
    have ht0 : 0 ≤ t := by linarith
    nlinarith [sq_nonneg t,
      mul_nonneg (sub_nonneg.mpr hhi)
        (add_nonneg ht0 (by norm_num : (0 : ℝ) ≤ 375 / 8192))]
  · norm_num [sixthCell, lowerValue]
  · norm_num [sixthSymbolLower]
  · norm_num [sixthCell, sixthRadius, sixthJet, sixthJetError,
      sixthSymbolLower, sixthWeightUpper, lowerValue,
      symmetricPolynomialFloor, symmetricTaylorError,
      AEGIS.RHKreinM8CertificateV1.serializedM8Q,
      Finset.sum_range_succ]

end AEGIS.RHKreinSixthCellReductionV1

#print axioms AEGIS.RHKreinSixthCellReductionV1.sixthCell_symbol_lower
#print axioms AEGIS.RHKreinSixthCellReductionV1.symbol_lower_of_sixthLeft_le
#print axioms AEGIS.RHKreinSixthCellReductionV1.sixthCell_sound_of_midpoint_jets
~~~~~~

## RHKreinEleventhCellCompositionV1

Path: `source/RHKreinEleventhCellCompositionV1.lean`

Original source lines: 1–284

Full file SHA256: `dfca6732ec3db5a3a4849c7f2e25400b25a1b80792d1be148d0d5250c0b24b67`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinTenthCellCompositionV1

/-!
# Compose existing analytic components into the eleventh serialized cell

The inherited ninth-left symbol floor is too coarse for serialized cell index
10.  Re-anchoring the existing exact digamma producer at the new left endpoint
gives the stronger floor `-63/10`.  The existing zero jet and exact PR54
finite-window M8 bound then close the cell without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinEleventhCellCompositionV1

open AEGIS.RHEulerGammaSharpV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinTenthCellCompositionV1

/-- The literal eleventh entry of the unchanged committed payload. -/
def eleventhCell : FiniteCellV1 :=
  ⟨525 / 8192, 1125 / 16384, 28428513002117230⟩

private def eleventhLeft : ℝ := 525 / 8192
private def eleventhSymbolLower : ℝ := -63 / 10

private theorem digamma_sharp_lower_of_sq_le (s t : ℝ) (N : ℕ)
    (hst : s ^ 2 ≤ t ^ 2) :
    -(5773 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hs := digamma_quarter_finite_lower s N
  have hm := digamma_quarter_mono_of_sq_le s t hst
  have hg := gamma_lt_5773
  dsimp [quarterPoint] at hs
  linarith only [hs, hm, hg]

private theorem eleventhDigammaPartialLower :
    (-3553819375255386 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm eleventhLeft n := by
  have h0 : (-3492656197598817 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm eleventhLeft n := by
    norm_num [eleventhLeft, quarterTerm]
  have h1 : (-45745358918680 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm eleventhLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [eleventhLeft, quarterTerm]
  have h2 : (-15417818737889 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm eleventhLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [eleventhLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm eleventhLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm eleventhLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2]

private theorem eleventhDigammaLower (t : ℝ) (hst : eleventhLeft ^ 2 ≤ t ^ 2) :
    (-1041 / 250 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_sharp_lower_of_sq_le eleventhLeft t 24 hst
  have hpartial := eleventhDigammaPartialLower
  norm_num [eleventhLeft] at hcert ⊢
  have hpartial' : (-3553819375255386 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm (525 / 8192) n := by
    simpa [eleventhLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem eleventhLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem eleventhPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The new left-endpoint symbol floor remains valid at every later
nonnegative frequency. -/
theorem symbol_lower_of_eleventhLeft_le (t : ℝ) (hleft : (525 / 8192 : ℝ) ≤ t) :
    eleventhSymbolLower ≤ symbol t := by
  have hleft' : eleventhLeft ≤ t := by simpa [eleventhLeft] using hleft
  have ht0 : 0 ≤ t := by
    have hleft0 : 0 ≤ eleventhLeft := by norm_num [eleventhLeft]
    linarith
  have hst : eleventhLeft ^ 2 ≤ t ^ 2 := by
    have hleft0 : 0 ≤ eleventhLeft := by norm_num [eleventhLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft') (add_nonneg ht0 hleft0)]
  have hd := eleventhDigammaLower t hst
  have hlp := eleventhLogPiUpper
  have hamp := eleventhPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num [eleventhSymbolLower] at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 1125 / 16384
private def weightedCoefficient : ℝ :=
  eleventhSymbolLower - 1 / 16 - (lowerValue eleventhCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 5000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, eleventhSymbolLower,
    eleventhCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, eleventhSymbolLower,
        eleventhCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, eleventhSymbolLower,
        eleventhCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The eleventh serialized lower bound follows from existing analytic producers. -/
theorem eleventhCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 eleventhCell := by
  apply cellAnalyticSound_of_correction_lower eleventhCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [eleventhCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [eleventhCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [eleventhCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [eleventhCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 5000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : eleventhSymbolLower ≤ symbol t := by
      apply symbol_lower_of_eleventhLeft_le
      simpa [eleventhCell] using hlo
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue eleventhCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (eleventhSymbolLower - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first eleven unchanged serialized cell results compose as a tuple. -/
theorem first_eleven_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinNinthCellCompositionV1.ninthCell ∧
      CellAnalyticSoundV1 tenthCell ∧ CellAnalyticSoundV1 eleventhCell :=
  ⟨first_ten_cells_sound.1, first_ten_cells_sound.2.1,
    first_ten_cells_sound.2.2.1, first_ten_cells_sound.2.2.2.1,
    first_ten_cells_sound.2.2.2.2.1, first_ten_cells_sound.2.2.2.2.2.1,
    first_ten_cells_sound.2.2.2.2.2.2.1,
    first_ten_cells_sound.2.2.2.2.2.2.2.1,
    first_ten_cells_sound.2.2.2.2.2.2.2.2.1,
    first_ten_cells_sound.2.2.2.2.2.2.2.2.2,
    eleventhCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinEleventhCellCompositionV1

#print axioms AEGIS.RHKreinEleventhCellCompositionV1.symbol_lower_of_eleventhLeft_le
#print axioms AEGIS.RHKreinEleventhCellCompositionV1.eleventhCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinEleventhCellCompositionV1.first_eleven_cells_sound
~~~~~~

## RHKreinTenthCellCompositionV1

Path: `source/RHKreinTenthCellCompositionV1.lean`

Original source lines: 1–172

Full file SHA256: `910e6de06ac54035cc9993d7f244f4a887ec6b2a4be77f18c7e8fee61f8c0d11`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinNinthCellCompositionV1

/-!
# Compose existing analytic components into the tenth serialized cell

The ninth-left symbol floor is valid throughout this later cell.  Together with
the existing zero jet and exact PR54 finite-window M8 bound, it closes serialized
cell index 9 without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinTenthCellCompositionV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinNinthCellCompositionV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1

/-- The literal tenth entry of the unchanged committed payload. -/
def tenthCell : FiniteCellV1 :=
  ⟨975 / 16384, 525 / 8192, 58131795665423643⟩

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 525 / 8192
private def symbolFloor : ℝ := -631 / 100
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue tenthCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 5000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    tenthCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, tenthCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, tenthCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The tenth serialized lower bound follows from existing analytic producers. -/
theorem tenthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 tenthCell := by
  apply cellAnalyticSound_of_correction_lower tenthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [tenthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [tenthCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [tenthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [tenthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 5000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := by
      change (-631 / 100 : ℝ) ≤ symbol t
      exact symbol_lower_of_ninthLeft_le t (by
        norm_num [tenthCell] at hlo ⊢
        linarith)
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue tenthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first ten unchanged serialized cell results compose as a tuple. -/
theorem first_ten_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 ninthCell ∧ CellAnalyticSoundV1 tenthCell :=
  ⟨first_nine_cells_sound.1, first_nine_cells_sound.2.1,
    first_nine_cells_sound.2.2.1, first_nine_cells_sound.2.2.2.1,
    first_nine_cells_sound.2.2.2.2.1, first_nine_cells_sound.2.2.2.2.2.1,
    first_nine_cells_sound.2.2.2.2.2.2.1,
    first_nine_cells_sound.2.2.2.2.2.2.2.1,
    first_nine_cells_sound.2.2.2.2.2.2.2.2,
    tenthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinTenthCellCompositionV1

#print axioms AEGIS.RHKreinTenthCellCompositionV1.tenthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinTenthCellCompositionV1.first_ten_cells_sound
~~~~~~

## RHKreinNinthCellCompositionV1

Path: `source/RHKreinNinthCellCompositionV1.lean`

Original source lines: 1–279

Full file SHA256: `2ffe79d59d394a0ae4c7243954b0f16447485b24bf59ad7405876c98b491d833`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinEighthCellCompositionV1

/-!
# Compose existing analytic components into the ninth serialized cell

The inherited sixth-left symbol floor is too coarse for serialized cell index 8.
Re-anchoring the existing exact digamma producer at the new left endpoint gives
the stronger floor `-631/100`.  The existing zero jet and exact PR54 finite-window
M8 bound then close the cell without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinNinthCellCompositionV1

open AEGIS.RHEulerGammaSharpV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinEighthCellCompositionV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1
open AEGIS.RHKreinSixthCellReductionV1
open AEGIS.RHKreinSymbolIntegrationV1

/-- The literal ninth entry of the unchanged committed payload. -/
def ninthCell : FiniteCellV1 :=
  ⟨225 / 4096, 975 / 16384, 88686499373536390⟩

private def ninthLeft : ℝ := 225 / 4096
private def ninthSymbolLower : ℝ := -631 / 100

private theorem digamma_sharp_lower_of_sq_le (s t : ℝ) (N : ℕ)
    (hst : s ^ 2 ≤ t ^ 2) :
    -(5773 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hs := digamma_quarter_finite_lower s N
  have hm := digamma_quarter_mono_of_sq_le s t hst
  have hg := gamma_lt_5773
  dsimp [quarterPoint] at hs
  linarith only [hs, hm, hg]

private theorem ninthDigammaPartialLower :
    (-3570947816460014 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm ninthLeft n := by
  have h0 : (-3509782621814915 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm ninthLeft n := by
    norm_num [ninthLeft, quarterTerm]
  have h1 : (-45747068747994 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm ninthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [ninthLeft, quarterTerm]
  have h2 : (-15418125897105 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm ninthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [ninthLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm ninthLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm ninthLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2]

private theorem ninthDigammaLower (t : ℝ) (hst : ninthLeft ^ 2 ≤ t ^ 2) :
    (-4181 / 1000 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_sharp_lower_of_sq_le ninthLeft t 24 hst
  have hpartial := ninthDigammaPartialLower
  norm_num [ninthLeft] at hcert ⊢
  have hpartial' : (-3570947816460014 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm (225 / 4096) n := by
    simpa [ninthLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem ninthLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem ninthPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The new left-endpoint symbol floor remains valid at every later
nonnegative frequency. -/
theorem symbol_lower_of_ninthLeft_le (t : ℝ) (hleft : (225 / 4096 : ℝ) ≤ t) :
    ninthSymbolLower ≤ symbol t := by
  have hleft' : ninthLeft ≤ t := by simpa [ninthLeft] using hleft
  have ht0 : 0 ≤ t := by
    have hleft0 : 0 ≤ ninthLeft := by norm_num [ninthLeft]
    linarith
  have hst : ninthLeft ^ 2 ≤ t ^ 2 := by
    have hleft0 : 0 ≤ ninthLeft := by norm_num [ninthLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft') (add_nonneg ht0 hleft0)]
  have hd := ninthDigammaLower t hst
  have hlp := ninthLogPiUpper
  have hamp := ninthPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num [ninthSymbolLower] at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 975 / 16384
private def weightedCoefficient : ℝ :=
  ninthSymbolLower - 1 / 16 - (lowerValue ninthCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 2000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, ninthSymbolLower,
    ninthCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, ninthSymbolLower, ninthCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, ninthSymbolLower, ninthCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The ninth serialized lower bound follows from existing analytic producers. -/
theorem ninthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 ninthCell := by
  apply cellAnalyticSound_of_correction_lower ninthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [ninthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [ninthCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [ninthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [ninthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 2000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : ninthSymbolLower ≤ symbol t := by
      apply symbol_lower_of_ninthLeft_le
      simpa [ninthCell] using hlo
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue ninthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (ninthSymbolLower - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first nine unchanged serialized cell results compose as a tuple. -/
theorem first_nine_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 eighthCell ∧ CellAnalyticSoundV1 ninthCell :=
  ⟨first_eight_cells_sound.1, first_eight_cells_sound.2.1,
    first_eight_cells_sound.2.2.1, first_eight_cells_sound.2.2.2.1,
    first_eight_cells_sound.2.2.2.2.1, first_eight_cells_sound.2.2.2.2.2.1,
    first_eight_cells_sound.2.2.2.2.2.2.1,
    first_eight_cells_sound.2.2.2.2.2.2.2,
    ninthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinNinthCellCompositionV1

#print axioms AEGIS.RHKreinNinthCellCompositionV1.symbol_lower_of_ninthLeft_le
#print axioms AEGIS.RHKreinNinthCellCompositionV1.ninthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinNinthCellCompositionV1.first_nine_cells_sound
~~~~~~

## RHKreinFifteenthCellK0CompositionV1

Path: `source/RHKreinFifteenthCellK0CompositionV1.lean`

Original source lines: 1–78

Full file SHA256: `89f232c3ef99c34f6e6d4b4cc43ebbf87185492eaff515141f092b8a08865e67`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFifteenthCellK0V1

/-!
# Compose the fifteenth-cell k=0 enclosure

Exactly the seven nonzero midpoint jets remain explicit premises. No global RH
or admission statement is introduced.
-/

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFifteenthCellK0CompositionV1

open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinFifteenthCellReductionV1
open AEGIS.RHKreinFifteenthCellK0V1

theorem fifteenthCell_sound_of_midpoint_jets_except_zero
    (hjet : ∀ k ∈ Finset.Ico 1 8,
      |exactJetCoefficient fifteenthCenter k - fifteenthJet k| ≤
        fifteenthJetError k) :
    CellAnalyticSoundV1 fifteenthCell := by
  apply fifteenthCell_sound_of_midpoint_jets
  intro k hk
  by_cases hk0 : k = 0
  · simpa [hk0] using fifteenthCenter_k0_enclosure
  · apply hjet k
    simp only [Finset.mem_Ico]
    simp only [Finset.mem_range] at hk
    omega

theorem first_fifteen_cells_sound_of_midpoint_jets_except_zero
    (hjet : ∀ k ∈ Finset.Ico 1 8,
      |exactJetCoefficient fifteenthCenter k - fifteenthJet k| ≤
        fifteenthJetError k) :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinNinthCellCompositionV1.ninthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTenthCellCompositionV1.tenthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEleventhCellCompositionV1.eleventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTwelfthCellCompositionV1.twelfthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirteenthCellCompositionV1.thirteenthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourteenthCellCompositionV1.fourteenthCell ∧
      CellAnalyticSoundV1 fifteenthCell := by
  apply first_fifteen_cells_sound_of_midpoint_jets
  intro k hk
  by_cases hk0 : k = 0
  · simpa [hk0] using fifteenthCenter_k0_enclosure
  · apply hjet k
    simp only [Finset.mem_Ico]
    simp only [Finset.mem_range] at hk
    omega

end AEGIS.RHKreinFifteenthCellK0CompositionV1

#print axioms AEGIS.RHKreinFifteenthCellK0CompositionV1.fifteenthCell_sound_of_midpoint_jets_except_zero
#print axioms AEGIS.RHKreinFifteenthCellK0CompositionV1.first_fifteen_cells_sound_of_midpoint_jets_except_zero
~~~~~~

## RHKreinFifteenthCellK0V1

Path: `source/RHKreinFifteenthCellK0V1.lean`

Original source lines: 1–379

Full file SHA256: `2e6933488f60afd398a6ef9514fa11858edf76434bbc902d8f9dbb4c93e2cc50`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFifteenthCellReductionV1
import RHKreinSincIntervalV1

/-!
# Fifteenth-cell zeroth centered Taylor-jet enclosure

This module proves the first of the eight analytic jet premises retained by
`RHKreinFifteenthCellReductionV1`. The proof evaluates the unchanged explicit
correction at `5025/65536` using degree-fifteen sine/cosine Taylor polynomials,
the existing exact sinc primitive, and exact rational error propagation.

No symbol enclosure, complete cell theorem, all-cells theorem, or RH statement
is concluded.

AUTHORITY_EFFECT = NONE.
-/

set_option autoImplicit false
set_option maxHeartbeats 12000000
set_option maxRecDepth 32768
noncomputable section

namespace AEGIS.RHKreinFifteenthCellK0V1

open AEGIS.RHKreinFifteenthCellReductionV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinSincIntervalV1
open scoped BigOperators

private def cosPolynomial15 (x : ℝ) : ℝ :=
  1 - x ^ 2 / 2 + x ^ 4 / 24 - x ^ 6 / 720 +
    x ^ 8 / 40320 - x ^ 10 / 3628800 + x ^ 12 / 479001600 -
      x ^ 14 / 87178291200

private def sinPolynomial15 (x : ℝ) : ℝ :=
  x - x ^ 3 / 6 + x ^ 5 / 120 - x ^ 7 / 5040 +
    x ^ 9 / 362880 - x ^ 11 / 39916800 + x ^ 13 / 6227020800 -
      x ^ 15 / 1307674368000

private theorem expIPartial_sixteen_re (x : ℝ) :
    (expIPartial 16 x).re = cosPolynomial15 x := by
  norm_num [expIPartial, cosPolynomial15, Finset.sum_range_succ,
    pow_succ, Complex.mul_re]
  ring

private theorem expIPartial_sixteen_im (x : ℝ) :
    (expIPartial 16 x).im = sinPolynomial15 x := by
  norm_num [expIPartial, sinPolynomial15, Finset.sum_range_succ,
    pow_succ, Complex.mul_im]
  ring

private theorem fifteenth_hat_cos_error (j : Fin 199) :
    |Real.cos (fifteenthCenter * hatCenter j) -
        cosPolynomial15 (fifteenthCenter * hatCenter j)| ≤
      (1 / 100000000000000000000 : ℝ) := by
  let x : ℝ := fifteenthCenter * hatCenter j
  have hjNat : j.val ≤ 198 := by omega
  have hj : (j.val : ℝ) ≤ 198 := by exact_mod_cast hjNat
  have hx0 : 0 ≤ x := by
    dsimp [x]
    unfold fifteenthCenter hatCenter
    positivity
  have hxub : x ≤ (3 / 8 : ℝ) := by
    dsimp [x]
    unfold fifteenthCenter hatCenter
    norm_num
    linarith
  have hx1 : |x| ≤ 1 := by
    rw [abs_of_nonneg hx0]
    exact hxub.trans (by norm_num)
  have h := cos_expIPartial_error 16 x (by norm_num) hx1
  rw [expIPartial_sixteen_re] at h
  have habs : |x| ≤ (3 / 8 : ℝ) := by
    simpa [abs_of_nonneg hx0] using hxub
  have hp := pow_le_pow_left₀ (abs_nonneg x) habs 16
  refine h.trans ?_
  calc
    |x| ^ 16 * (((Nat.succ 16 : ℕ) : ℝ) *
        ((Nat.factorial 16 : ℕ) * 16 : ℝ)⁻¹) ≤
        (3 / 8 : ℝ) ^ 16 * (((Nat.succ 16 : ℕ) : ℝ) *
          ((Nat.factorial 16 : ℕ) * 16 : ℝ)⁻¹) := by
      exact mul_le_mul_of_nonneg_right hp (by positivity)
    _ ≤ (1 / 100000000000000000000 : ℝ) := by norm_num

private theorem edgePhase_eq :
    fifteenthCenter * (1619 / 2000 : ℝ) =
      (325419 / 5242880 : ℝ) := by
  norm_num [fifteenthCenter]

private theorem fifteenth_edge_cos_error :
    |Real.cos (fifteenthCenter * (1619 / 2000 : ℝ)) -
        cosPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 10000000000000000000000000 : ℝ) := by
  rw [edgePhase_eq]
  have h := cos_expIPartial_error 16 (325419 / 5242880 : ℝ)
    (by norm_num) (by norm_num)
  rw [expIPartial_sixteen_re] at h
  exact h.trans (by norm_num)

private theorem fifteenth_edge_sin_error :
    |Real.sin (fifteenthCenter * (1619 / 2000 : ℝ)) -
        sinPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 10000000000000000000000000 : ℝ) := by
  rw [edgePhase_eq]
  have h := sin_expIPartial_error 16 (325419 / 5242880 : ℝ)
    (by norm_num) (by norm_num)
  rw [expIPartial_sixteen_im] at h
  exact h.trans (by norm_num)

private theorem fifteenth_hat_sinc_error :
    |Real.sinc (fifteenthCenter / 100) -
        sincPolynomial7 (fifteenthCenter / 100)| ≤
      (1 / 100000000000000000000000000 : ℝ) := by
  have hphase : fifteenthCenter / 100 = (201 / 262144 : ℝ) := by
    norm_num [fifteenthCenter]
  have h := sinc_expIPartial_error 8 (fifteenthCenter / 100)
    (by norm_num) (by norm_num [fifteenthCenter]) (by norm_num [fifteenthCenter])
  rw [hphase] at h ⊢
  have hp :
      (expIPartial 8 (201 / 262144 : ℝ)).im / (201 / 262144 : ℝ) =
        sincPolynomial7 (201 / 262144 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

private theorem fifteenth_edge_sinc_error :
    |Real.sinc (fifteenthCenter / 2000) -
        sincPolynomial7 (fifteenthCenter / 2000)| ≤
      (1 / 10000000000000000000000000000000000 : ℝ) := by
  have hphase : fifteenthCenter / 2000 = (201 / 5242880 : ℝ) := by
    norm_num [fifteenthCenter]
  have h := sinc_expIPartial_error 8 (fifteenthCenter / 2000)
    (by norm_num) (by norm_num [fifteenthCenter]) (by norm_num [fifteenthCenter])
  rw [hphase] at h ⊢
  have hp :
      (expIPartial 8 (201 / 5242880 : ℝ)).im / (201 / 5242880 : ℝ) =
        sincPolynomial7 (201 / 5242880 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

private def hatApproxSum : ℝ :=
  ∑ j : Fin 199, (hatCoefficient j : ℝ) *
    cosPolynomial15 (fifteenthCenter * hatCenter j)

private def edgePhase (j : Fin 5) : ℝ :=
  if j.val % 2 = 0 then Real.cos (fifteenthCenter * (1619 / 2000))
  else Real.sin (fifteenthCenter * (1619 / 2000))

private def edgePhaseApprox (j : Fin 5) : ℝ :=
  if j.val % 2 = 0 then cosPolynomial15 (fifteenthCenter * (1619 / 2000))
  else sinPolynomial15 (fifteenthCenter * (1619 / 2000))

private def edgeApproxSum : ℝ :=
  ∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
    edgePhaseApprox j

private def fifteenthCorrectionApprox : ℝ :=
  (2 / 50) * sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum +
    sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum

private def hatSumError : ℝ :=
  (∑ j : Fin 199, |(hatCoefficient j : ℝ)|) *
    (1 / 100000000000000000000 : ℝ)

private def edgeSumError : ℝ :=
  ∑ j : Fin 5, |(splineCoefficient j : ℝ) * fifteenthCenter ^ j.val| *
    (1 / 10000000000000000000000000 : ℝ)

private def fifteenthK0ErrorBudget : ℝ :=
  (2 / 50) * (hatSumError +
    |hatApproxSum| * (2 / 100000000000000000000000000 : ℝ)) +
  (edgeSumError +
    |edgeApproxSum| * (19 / 10000000000000000000000000000000000 : ℝ))

private theorem hatSum_error :
    |(∑ j : Fin 199, (hatCoefficient j : ℝ) *
        Real.cos (fifteenthCenter * hatCenter j)) - hatApproxSum| ≤
      hatSumError := by
  unfold hatApproxSum hatSumError
  rw [← Finset.sum_sub_distrib, Finset.sum_mul]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro j _
  rw [← mul_sub, abs_mul]
  exact mul_le_mul_of_nonneg_left (fifteenth_hat_cos_error j) (abs_nonneg _)

private theorem edgePhase_error (j : Fin 5) :
    |edgePhase j - edgePhaseApprox j| ≤
      (1 / 10000000000000000000000000 : ℝ) := by
  fin_cases j
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_cos_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_sin_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_cos_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_sin_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_cos_error

private theorem edgeSum_error :
    |(∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
        edgePhase j) - edgeApproxSum| ≤ edgeSumError := by
  unfold edgeApproxSum edgeSumError
  rw [← Finset.sum_sub_distrib]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro j _
  rw [← mul_sub, abs_mul]
  exact mul_le_mul_of_nonneg_left (edgePhase_error j) (abs_nonneg _)

private theorem product_error_unit {x x' y y' ex ey : ℝ}
    (hx : |x| ≤ 1) (hdx : |x - x'| ≤ ex) (hdy : |y - y'| ≤ ey)
    (hex : 0 ≤ ex) :
    |x * y - x' * y'| ≤ ey + |y'| * ex := by
  calc
    |x * y - x' * y'| =
        |x * (y - y') + (x - x') * y'| := by congr 1; ring
    _ ≤ |x * (y - y')| + |(x - x') * y'| := abs_add_le _ _
    _ = |x| * |y - y'| + |x - x'| * |y'| := by rw [abs_mul, abs_mul]
    _ ≤ 1 * ey + ex * |y'| := by
      exact add_le_add
        (mul_le_mul hx hdy (abs_nonneg _) (by norm_num))
        (mul_le_mul hdx le_rfl (abs_nonneg _) hex)
    _ = ey + |y'| * ex := by ring

private theorem hatSincSq_error :
    |Real.sinc (fifteenthCenter / 100) ^ 2 -
        sincPolynomial7 (fifteenthCenter / 100) ^ 2| ≤
      (2 / 100000000000000000000000000 : ℝ) := by
  have ha := Real.abs_sinc_le_one (fifteenthCenter / 100)
  have hp : |sincPolynomial7 (fifteenthCenter / 100)| ≤ 1 := by
    norm_num [fifteenthCenter, sincPolynomial7]
  have hm : max |Real.sinc (fifteenthCenter / 100)|
      |sincPolynomial7 (fifteenthCenter / 100)| ≤ 1 := max_le ha hp
  have hpow : max |Real.sinc (fifteenthCenter / 100)|
      |sincPolynomial7 (fifteenthCenter / 100)| ^ (2 - 1) ≤ 1 := by
    simpa using hm
  calc
    |Real.sinc (fifteenthCenter / 100) ^ 2 -
        sincPolynomial7 (fifteenthCenter / 100) ^ 2| ≤
      |Real.sinc (fifteenthCenter / 100) -
          sincPolynomial7 (fifteenthCenter / 100)| * (2 : ℝ) *
        max |Real.sinc (fifteenthCenter / 100)|
          |sincPolynomial7 (fifteenthCenter / 100)| ^ (2 - 1) :=
      abs_pow_sub_pow_le _ _ _
    _ ≤ (1 / 100000000000000000000000000 : ℝ) * 2 * 1 := by
      exact mul_le_mul
        (mul_le_mul fifteenth_hat_sinc_error le_rfl (by norm_num) (by positivity))
        hpow (by positivity) (by positivity)
    _ = (2 / 100000000000000000000000000 : ℝ) := by norm_num

private theorem edgeSincPow_error :
    |Real.sinc (fifteenthCenter / 2000) ^ 19 -
        sincPolynomial7 (fifteenthCenter / 2000) ^ 19| ≤
      (19 / 10000000000000000000000000000000000 : ℝ) := by
  have ha := Real.abs_sinc_le_one (fifteenthCenter / 2000)
  have hp : |sincPolynomial7 (fifteenthCenter / 2000)| ≤ 1 := by
    norm_num [fifteenthCenter, sincPolynomial7]
  have hm : max |Real.sinc (fifteenthCenter / 2000)|
      |sincPolynomial7 (fifteenthCenter / 2000)| ≤ 1 := max_le ha hp
  have hpow : max |Real.sinc (fifteenthCenter / 2000)|
      |sincPolynomial7 (fifteenthCenter / 2000)| ^ (19 - 1) ≤ 1 := by
    calc
      _ ≤ 1 ^ (19 - 1) := pow_le_pow_left₀ (by positivity) hm _
      _ = 1 := by norm_num
  calc
    |Real.sinc (fifteenthCenter / 2000) ^ 19 -
        sincPolynomial7 (fifteenthCenter / 2000) ^ 19| ≤
      |Real.sinc (fifteenthCenter / 2000) -
          sincPolynomial7 (fifteenthCenter / 2000)| * (19 : ℝ) *
        max |Real.sinc (fifteenthCenter / 2000)|
          |sincPolynomial7 (fifteenthCenter / 2000)| ^ (19 - 1) :=
      abs_pow_sub_pow_le _ _ _
    _ ≤ (1 / 10000000000000000000000000000000000 : ℝ) * 19 * 1 := by
      exact mul_le_mul
        (mul_le_mul fifteenth_edge_sinc_error le_rfl (by norm_num) (by positivity))
        hpow (by positivity) (by positivity)
    _ = (19 / 10000000000000000000000000000000000 : ℝ) := by norm_num

private theorem correctionApprox_error :
    |correctionSymbol fifteenthCenter - fifteenthCorrectionApprox| ≤
      fifteenthK0ErrorBudget := by
  let hatActual : ℝ :=
    ∑ j : Fin 199, (hatCoefficient j : ℝ) *
      Real.cos (fifteenthCenter * hatCenter j)
  let edgeActual : ℝ :=
    ∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
      edgePhase j
  have hhatSum : |hatActual - hatApproxSum| ≤ hatSumError := by
    simpa [hatActual] using hatSum_error
  have hedgeSum : |edgeActual - edgeApproxSum| ≤ edgeSumError := by
    simpa [edgeActual] using edgeSum_error
  have hhatPow : |Real.sinc (fifteenthCenter / 100) ^ 2| ≤ 1 := by
    rw [abs_pow]
    exact (pow_le_pow_left₀ (abs_nonneg _) (Real.abs_sinc_le_one _) 2).trans
      (by norm_num)
  have hedgePow : |Real.sinc (fifteenthCenter / 2000) ^ 19| ≤ 1 := by
    rw [abs_pow]
    exact (pow_le_pow_left₀ (abs_nonneg _) (Real.abs_sinc_le_one _) 19).trans
      (by norm_num)
  have hhat := product_error_unit hhatPow hatSincSq_error hhatSum (by norm_num)
  have hedge := product_error_unit hedgePow edgeSincPow_error hedgeSum (by norm_num)
  unfold correctionSymbol fifteenthCorrectionApprox fifteenthK0ErrorBudget
  change
    |(2 / 50) * Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual +
        Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
      ((2 / 50) * sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum +
        sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum)| ≤ _
  have hdecomp :
      (2 / 50) * Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual +
          Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
        ((2 / 50) * sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum +
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum) =
      (2 / 50) * (Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual -
          sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum) +
        (Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum) := by
    ring
  calc
    _ ≤ |(2 / 50) * (Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual -
          sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum)| +
        |Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum| := by
      rw [hdecomp]
      exact abs_add_le _ _
    _ = (2 / 50) *
          |Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual -
            sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum| +
        |Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum| := by
      rw [abs_mul, abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 2 / 50)]
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hhat (by norm_num)) hedge

private theorem rational_budget :
    |fifteenthCorrectionApprox - fifteenthJet 0| + fifteenthK0ErrorBudget ≤
      (1 / 1000000000000 : ℝ) := by
  norm_num [fifteenthCorrectionApprox, fifteenthK0ErrorBudget, hatSumError,
    edgeSumError, hatApproxSum, edgeApproxSum, edgePhaseApprox,
    fifteenthCenter, fifteenthJet, sincPolynomial7, cosPolynomial15,
    sinPolynomial15, hatCenter, hatCoefficient, splineCoefficient,
    Fin.sum_univ_succ]

/-- Kernel-checked zeroth centered-jet premise for serialized fifteenth cell. -/
theorem fifteenthCenter_k0_enclosure :
    |exactJetCoefficient fifteenthCenter 0 - fifteenthJet 0| ≤
      fifteenthJetError 0 := by
  have htriangle :
      |correctionSymbol fifteenthCenter - fifteenthJet 0| ≤
        |correctionSymbol fifteenthCenter - fifteenthCorrectionApprox| +
          |fifteenthCorrectionApprox - fifteenthJet 0| := by
    simpa only [sub_add_sub_cancel] using
      abs_add_le (correctionSymbol fifteenthCenter - fifteenthCorrectionApprox)
        (fifteenthCorrectionApprox - fifteenthJet 0)
  have h := htriangle.trans (add_le_add correctionApprox_error
    (le_refl |fifteenthCorrectionApprox - fifteenthJet 0|))
  simp only [exactJetCoefficient, iteratedDeriv_zero, Nat.factorial_zero,
    Nat.cast_one, inv_one, one_mul, fifteenthJetError]
  exact h.trans (by linarith [rational_budget])
end AEGIS.RHKreinFifteenthCellK0V1

#print axioms AEGIS.RHKreinFifteenthCellK0V1.fifteenthCenter_k0_enclosure
~~~~~~

## RHKreinFifteenthCellReductionV1

Path: `source/RHKreinFifteenthCellReductionV1.lean`

Original source lines: 1–333

Full file SHA256: `d599c6a9d0edefe1db27533e1f167f7f2e6d3dafc29e9346f17ea9d6d54c25dc`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFourteenthCellCompositionV1

/-!
# Reduce the fifteenth serialized cell to eight exact midpoint-jet enclosures

The zero-centered Taylor budget is negative on serialized cell index 14, even
after re-anchoring the 24-term symbol certificate at its left endpoint.  This
file instead uses the exact midpoint and radius of the unchanged payload cell.
A 128-term rational digamma certificate closes the uniform symbol bound, and
all geometry, M8, weight, stored-bound, and ground-budget goals are discharged.
The only remaining assumptions are the eight displayed midpoint jet
enclosures; no admission or global RH assumption is introduced.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinFifteenthCellReductionV1

open AEGIS.RHEulerGammaSharpV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinSymmetricCellProducerV1
open AEGIS.RHKreinFourteenthCellCompositionV1

/-- The literal fifteenth entry of the unchanged committed payload. -/
def fifteenthCell : FiniteCellV1 :=
  ⟨2475 / 32768, 1275 / 16384, 292616690003685633⟩

def fifteenthCenter : ℝ := 5025 / 65536
def fifteenthRadius : ℝ := 75 / 65536

def fifteenthJet : ℕ → ℝ
  | 0 => 416165963423 / 1000000000000
  | 1 => 347860160497 / 1000000000000
  | 2 => 1158807525507 / 500000000000
  | 3 => 8015489529 / 12500000000
  | 4 => 51983766003 / 25000000000
  | 5 => -5642042579 / 62500000000
  | 6 => -207036090341 / 1000000000000
  | 7 => -7422888411 / 125000000000
  | _ => 0

def fifteenthJetError (_ : ℕ) : ℝ := 1 / 1000000000000
def fifteenthSymbolLower : ℝ := -313119 / 50000
def fifteenthWeightUpper : ℝ := 4724429978091121 / 72057594037927936

private def fifteenthLeft : ℝ := 2475 / 32768

private theorem digamma_sharp_lower_of_sq_le (s t : ℝ) (N : ℕ)
    (hst : s ^ 2 ≤ t ^ 2) :
    -(5773 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hs := digamma_quarter_finite_lower s N
  have hm := digamma_quarter_mono_of_sq_le s t hst
  have hg := gamma_lt_5773
  dsimp [quarterPoint] at hs
  linarith only [hs, hm, hg]

private theorem fifteenthDigammaPartialLower :
    (-3554195705385069 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 128, quarterTerm fifteenthLeft n := by
  have h0 : (-173390210722991 / 50000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm fifteenthLeft n := by
    norm_num [fifteenthLeft, quarterTerm]
  have h1 : (-457428517343 / 10000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h2 : (-15417368337031 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h3 : (-7740100980503 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 24 32, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h4 : (-4654057375687 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 32 40, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h5 : (-77671419533 / 25000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 40 48, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h6 : (-2221212677807 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 48 56, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h7 : (-104188599871 / 62500000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 56 64, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h8 : (-51889006137 / 40000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 64 72, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h9 : (-129774123421 / 125000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 72 80, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h10 : (-424851702411 / 500000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 80 88, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h11 : (-88534199949 / 125000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 88 96, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h12 : (-11988829061 / 20000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 96 104, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h13 : (-102780794621 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 104 112, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h14 : (-55681981889 / 125000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 112 120, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  have h15 : (-389829014191 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 120 128, quarterTerm fifteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifteenthLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 120 ≤ 128 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 112 ≤ 120 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 104 ≤ 112 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 96 ≤ 104 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 88 ≤ 96 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 80 ≤ 88 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 72 ≤ 80 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 64 ≤ 72 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 56 ≤ 64 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 48 ≤ 56 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 40 ≤ 48 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 32 ≤ 40 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 24 ≤ 32 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifteenthLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2, h3, h4, h5, h6, h7,
    h8, h9, h10, h11, h12, h13, h14, h15]

private theorem fifteenthDigammaLower (t : ℝ)
    (hst : fifteenthLeft ^ 2 ≤ t ^ 2) :
    (-413739 / 100000 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_sharp_lower_of_sq_le fifteenthLeft t 128 hst
  have hpartial := fifteenthDigammaPartialLower
  norm_num [fifteenthLeft] at hcert ⊢
  have hpartial' : (-3554195705385069 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 128, quarterTerm (2475 / 32768) n := by
    simpa [fifteenthLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem fifteenthLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem fifteenthPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The 128-term exact certificate gives a uniform symbol floor from the
fifteenth cell's left endpoint onward. -/
theorem symbol_lower_of_fifteenthLeft_le (t : ℝ)
    (hleft : (2475 / 32768 : ℝ) ≤ t) :
    fifteenthSymbolLower ≤ symbol t := by
  have hleft' : fifteenthLeft ≤ t := by simpa [fifteenthLeft] using hleft
  have ht0 : 0 ≤ t := by
    have hleft0 : 0 ≤ fifteenthLeft := by norm_num [fifteenthLeft]
    linarith
  have hst : fifteenthLeft ^ 2 ≤ t ^ 2 := by
    have hleft0 : 0 ≤ fifteenthLeft := by norm_num [fifteenthLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft') (add_nonneg ht0 hleft0)]
  have hd := fifteenthDigammaLower t hst
  have hlp := fifteenthLogPiUpper
  have hamp := fifteenthPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num [fifteenthSymbolLower] at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

theorem fifteenthCell_symbol_lower (t : ℝ)
    (hlo : (fifteenthCell.lo : ℝ) ≤ t)
    (_hhi : t ≤ (fifteenthCell.hi : ℝ)) :
    fifteenthSymbolLower ≤ symbol t := by
  apply symbol_lower_of_fifteenthLeft_le
  simpa [fifteenthCell] using hlo

/-- Exact fifteenth-cell reduction.  Every rational, symbol, geometry, and M8
obligation is closed; only the eight midpoint jet enclosures remain explicit. -/
theorem fifteenthCell_sound_of_midpoint_jets
    (hjet : ∀ k ∈ Finset.range 8,
      |exactJetCoefficient fifteenthCenter k - fifteenthJet k| ≤
        fifteenthJetError k) :
    CellAnalyticSoundV1 fifteenthCell := by
  apply cellAnalyticSound_of_symmetric_jet_box fifteenthCell
    fifteenthCenter fifteenthRadius fifteenthJet fifteenthJetError
    fifteenthSymbolLower fifteenthWeightUpper
  · norm_num [fifteenthRadius]
  · intro t hlo hhi
    norm_num [fifteenthCell, fifteenthCenter, fifteenthRadius] at hlo hhi ⊢
    rw [abs_le]
    constructor <;> linarith
  · exact hjet
  · exact fifteenthCell_symbol_lower
  · intro t hlo hhi
    norm_num [fifteenthCell, fifteenthWeightUpper] at hlo hhi ⊢
    have ht0 : 0 ≤ t := by linarith
    nlinarith [sq_nonneg t,
      mul_nonneg (sub_nonneg.mpr hhi)
        (add_nonneg ht0 (by norm_num : (0 : ℝ) ≤ 1275 / 16384))]
  · norm_num [fifteenthCell, lowerValue]
  · norm_num [fifteenthSymbolLower]
  · norm_num [fifteenthCell, fifteenthRadius, fifteenthJet,
      fifteenthJetError, fifteenthSymbolLower, fifteenthWeightUpper,
      lowerValue, symmetricPolynomialFloor, symmetricTaylorError,
      AEGIS.RHKreinM8CertificateV1.serializedM8Q,
      Finset.sum_range_succ]

/-- The previous fourteen premise-free results and the exact fifteenth-cell
reduction compose without weakening any theorem statement. -/
theorem first_fifteen_cells_sound_of_midpoint_jets
    (hjet : ∀ k ∈ Finset.range 8,
      |exactJetCoefficient fifteenthCenter k - fifteenthJet k| ≤
        fifteenthJetError k) :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinNinthCellCompositionV1.ninthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTenthCellCompositionV1.tenthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEleventhCellCompositionV1.eleventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTwelfthCellCompositionV1.twelfthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirteenthCellCompositionV1.thirteenthCell ∧
      CellAnalyticSoundV1 fourteenthCell ∧ CellAnalyticSoundV1 fifteenthCell :=
  ⟨first_fourteen_cells_sound.1, first_fourteen_cells_sound.2.1,
    first_fourteen_cells_sound.2.2.1, first_fourteen_cells_sound.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.2.2.2.2.2.2.1,
    first_fourteen_cells_sound.2.2.2.2.2.2.2.2.2.2.2.2.2,
    fifteenthCell_sound_of_midpoint_jets hjet⟩

end AEGIS.RHKreinFifteenthCellReductionV1

#print axioms AEGIS.RHKreinFifteenthCellReductionV1.symbol_lower_of_fifteenthLeft_le
#print axioms AEGIS.RHKreinFifteenthCellReductionV1.fifteenthCell_sound_of_midpoint_jets
#print axioms AEGIS.RHKreinFifteenthCellReductionV1.first_fifteen_cells_sound_of_midpoint_jets
~~~~~~

## RHKreinFourteenthCellCompositionV1

Path: `source/RHKreinFourteenthCellCompositionV1.lean`

Original source lines: 1–293

Full file SHA256: `46c5c4462947e98d38d1d8fa510d0771e16fd04b00e928b1ecc6b78643ab78eb`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinThirteenthCellCompositionV1

/-!
# Compose existing analytic components into the fourteenth serialized cell

The inherited thirteenth-left symbol floor is too coarse for serialized cell index
13.  Re-anchoring the existing exact digamma producer at the new left endpoint
gives the stronger floor `-3918/625`.  The existing zero jet and exact PR54
finite-window M8 bound then close the cell without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinFourteenthCellCompositionV1

open AEGIS.RHEulerGammaSharpV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinEleventhCellCompositionV1
open AEGIS.RHKreinTenthCellCompositionV1
open AEGIS.RHKreinTwelfthCellCompositionV1
open AEGIS.RHKreinThirteenthCellCompositionV1

/-- The literal fourteenth entry of the unchanged committed payload. -/
def fourteenthCell : FiniteCellV1 :=
  ⟨75 / 1024, 2475 / 32768, 297477874163111897⟩

private def fourteenthLeft : ℝ := 75 / 1024
private def fourteenthSymbolLower : ℝ := -3918 / 625

private theorem digamma_sharp_lower_of_sq_le (s t : ℝ) (N : ℕ)
    (hst : s ^ 2 ≤ t ^ 2) :
    -(5773 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hs := digamma_quarter_finite_lower s N
  have hm := digamma_quarter_mono_of_sq_le s t hst
  have hg := gamma_lt_5773
  dsimp [quarterPoint] at hs
  linarith only [hs, hm, hg]

private theorem fourteenthDigammaPartialLower :
    (-3534235577783948 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm fourteenthLeft n := by
  have h0 : (-3473074727409374 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm fourteenthLeft n := by
    norm_num [fourteenthLeft, quarterTerm]
  have h1 : (-45743386050562 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm fourteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fourteenthLeft, quarterTerm]
  have h2 : (-15417464324012 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm fourteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fourteenthLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm fourteenthLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fourteenthLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2]

private theorem fourteenthDigammaLower (t : ℝ) (hst : fourteenthLeft ^ 2 ≤ t ^ 2) :
    (-20719 / 5000 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_sharp_lower_of_sq_le fourteenthLeft t 24 hst
  have hpartial := fourteenthDigammaPartialLower
  norm_num [fourteenthLeft] at hcert ⊢
  have hpartial' : (-3534235577783948 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm (75 / 1024) n := by
    simpa [fourteenthLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem fourteenthLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem fourteenthPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The new left-endpoint symbol floor remains valid at every later
nonnegative frequency. -/
theorem symbol_lower_of_fourteenthLeft_le (t : ℝ) (hleft : (75 / 1024 : ℝ) ≤ t) :
    fourteenthSymbolLower ≤ symbol t := by
  have hleft' : fourteenthLeft ≤ t := by simpa [fourteenthLeft] using hleft
  have ht0 : 0 ≤ t := by
    have hleft0 : 0 ≤ fourteenthLeft := by norm_num [fourteenthLeft]
    linarith
  have hst : fourteenthLeft ^ 2 ≤ t ^ 2 := by
    have hleft0 : 0 ≤ fourteenthLeft := by norm_num [fourteenthLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft') (add_nonneg ht0 hleft0)]
  have hd := fourteenthDigammaLower t hst
  have hlp := fourteenthLogPiUpper
  have hamp := fourteenthPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num [fourteenthSymbolLower] at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 2475 / 32768
private def weightedCoefficient : ℝ :=
  fourteenthSymbolLower - 1 / 16 - (lowerValue fourteenthCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 100000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, fourteenthSymbolLower,
    fourteenthCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, fourteenthSymbolLower,
        fourteenthCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, fourteenthSymbolLower,
        fourteenthCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The fourteenth serialized lower bound follows from existing analytic producers. -/
theorem fourteenthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 fourteenthCell := by
  apply cellAnalyticSound_of_correction_lower fourteenthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [fourteenthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [fourteenthCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [fourteenthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [fourteenthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 100000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : fourteenthSymbolLower ≤ symbol t := by
      apply symbol_lower_of_fourteenthLeft_le
      simpa [fourteenthCell] using hlo
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue fourteenthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (fourteenthSymbolLower - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first fourteen unchanged serialized cell results compose as a tuple. -/
theorem first_fourteen_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinNinthCellCompositionV1.ninthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTenthCellCompositionV1.tenthCell ∧
      CellAnalyticSoundV1 eleventhCell ∧ CellAnalyticSoundV1 twelfthCell ∧
      CellAnalyticSoundV1 thirteenthCell ∧ CellAnalyticSoundV1 fourteenthCell :=
  ⟨first_thirteen_cells_sound.1, first_thirteen_cells_sound.2.1,
    first_thirteen_cells_sound.2.2.1, first_thirteen_cells_sound.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.2.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.2.2.2.2.2.2.1,
    first_thirteen_cells_sound.2.2.2.2.2.2.2.2.2.2.2.2,
    fourteenthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinFourteenthCellCompositionV1

#print axioms AEGIS.RHKreinFourteenthCellCompositionV1.symbol_lower_of_fourteenthLeft_le
#print axioms AEGIS.RHKreinFourteenthCellCompositionV1.fourteenthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinFourteenthCellCompositionV1.first_fourteen_cells_sound
~~~~~~

## RHKreinThirteenthCellCompositionV1

Path: `source/RHKreinThirteenthCellCompositionV1.lean`

Original source lines: 1–290

Full file SHA256: `5eb84f39e87fba191bdaef30ecb357f466e22a92d25c579711c0f50d603ddfdd`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinTwelfthCellCompositionV1

/-!
# Compose existing analytic components into the thirteenth serialized cell

The inherited twelfth-left symbol floor is too coarse for serialized cell index
12.  Re-anchoring the existing exact digamma producer at the new left endpoint
gives the stronger floor `-3137/500`.  The existing zero jet and exact PR54
finite-window M8 bound then close the cell without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinThirteenthCellCompositionV1

open AEGIS.RHEulerGammaSharpV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinEleventhCellCompositionV1
open AEGIS.RHKreinTenthCellCompositionV1
open AEGIS.RHKreinTwelfthCellCompositionV1

/-- The literal thirteenth entry of the unchanged committed payload. -/
def thirteenthCell : FiniteCellV1 :=
  ⟨2325 / 32768, 75 / 1024, 302493041933652027⟩

private def thirteenthLeft : ℝ := 2325 / 32768
private def thirteenthSymbolLower : ℝ := -3137 / 500

private theorem digamma_sharp_lower_of_sq_le (s t : ℝ) (N : ℕ)
    (hst : s ^ 2 ≤ t ^ 2) :
    -(5773 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hs := digamma_quarter_finite_lower s N
  have hm := digamma_quarter_mono_of_sq_le s t hst
  have hg := gamma_lt_5773
  dsimp [quarterPoint] at hs
  linarith only [hs, hm, hg]

private theorem thirteenthDigammaPartialLower :
    (-3539357825991139 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm thirteenthLeft n := by
  have h0 : (-3478196364706334 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm thirteenthLeft n := by
    norm_num [thirteenthLeft, quarterTerm]
  have h1 : (-45743903927213 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm thirteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [thirteenthLeft, quarterTerm]
  have h2 : (-15417557357592 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm thirteenthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [thirteenthLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm thirteenthLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm thirteenthLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2]

private theorem thirteenthDigammaLower (t : ℝ) (hst : thirteenthLeft ^ 2 ≤ t ^ 2) :
    (-4149 / 1000 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_sharp_lower_of_sq_le thirteenthLeft t 24 hst
  have hpartial := thirteenthDigammaPartialLower
  norm_num [thirteenthLeft] at hcert ⊢
  have hpartial' : (-3539357825991139 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm (2325 / 32768) n := by
    simpa [thirteenthLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem thirteenthLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem thirteenthPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The new left-endpoint symbol floor remains valid at every later
nonnegative frequency. -/
theorem symbol_lower_of_thirteenthLeft_le (t : ℝ) (hleft : (2325 / 32768 : ℝ) ≤ t) :
    thirteenthSymbolLower ≤ symbol t := by
  have hleft' : thirteenthLeft ≤ t := by simpa [thirteenthLeft] using hleft
  have ht0 : 0 ≤ t := by
    have hleft0 : 0 ≤ thirteenthLeft := by norm_num [thirteenthLeft]
    linarith
  have hst : thirteenthLeft ^ 2 ≤ t ^ 2 := by
    have hleft0 : 0 ≤ thirteenthLeft := by norm_num [thirteenthLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft') (add_nonneg ht0 hleft0)]
  have hd := thirteenthDigammaLower t hst
  have hlp := thirteenthLogPiUpper
  have hamp := thirteenthPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num [thirteenthSymbolLower] at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 75 / 1024
private def weightedCoefficient : ℝ :=
  thirteenthSymbolLower - 1 / 16 - (lowerValue thirteenthCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 10000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, thirteenthSymbolLower,
    thirteenthCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, thirteenthSymbolLower,
        thirteenthCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, thirteenthSymbolLower,
        thirteenthCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The thirteenth serialized lower bound follows from existing analytic producers. -/
theorem thirteenthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 thirteenthCell := by
  apply cellAnalyticSound_of_correction_lower thirteenthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [thirteenthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [thirteenthCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [thirteenthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [thirteenthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 10000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : thirteenthSymbolLower ≤ symbol t := by
      apply symbol_lower_of_thirteenthLeft_le
      simpa [thirteenthCell] using hlo
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue thirteenthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (thirteenthSymbolLower - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first thirteen unchanged serialized cell results compose as a tuple. -/
theorem first_thirteen_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinNinthCellCompositionV1.ninthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTenthCellCompositionV1.tenthCell ∧
      CellAnalyticSoundV1 eleventhCell ∧ CellAnalyticSoundV1 twelfthCell ∧
      CellAnalyticSoundV1 thirteenthCell :=
  ⟨first_twelve_cells_sound.1, first_twelve_cells_sound.2.1,
    first_twelve_cells_sound.2.2.1, first_twelve_cells_sound.2.2.2.1,
    first_twelve_cells_sound.2.2.2.2.1, first_twelve_cells_sound.2.2.2.2.2.1,
    first_twelve_cells_sound.2.2.2.2.2.2.1,
    first_twelve_cells_sound.2.2.2.2.2.2.2.1,
    first_twelve_cells_sound.2.2.2.2.2.2.2.2.1,
    first_twelve_cells_sound.2.2.2.2.2.2.2.2.2.1,
    first_twelve_cells_sound.2.2.2.2.2.2.2.2.2.2.1,
    first_twelve_cells_sound.2.2.2.2.2.2.2.2.2.2.2,
    thirteenthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinThirteenthCellCompositionV1

#print axioms AEGIS.RHKreinThirteenthCellCompositionV1.symbol_lower_of_thirteenthLeft_le
#print axioms AEGIS.RHKreinThirteenthCellCompositionV1.thirteenthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinThirteenthCellCompositionV1.first_thirteen_cells_sound
~~~~~~

## RHKreinTwelfthCellCompositionV1

Path: `source/RHKreinTwelfthCellCompositionV1.lean`

Original source lines: 1–287

Full file SHA256: `51454526532d54e1571937af3c5b96846c025fdbd39c1117e5fbc7317bc39957`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinEleventhCellCompositionV1

/-!
# Compose existing analytic components into the twelfth serialized cell

The inherited ninth-left symbol floor is too coarse for serialized cell index
11.  Re-anchoring the existing exact digamma producer at the new left endpoint
gives the stronger floor `-157/25`.  The existing zero jet and exact PR54
finite-window M8 bound then close the cell without new analytic assumptions.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 8000000
noncomputable section

namespace AEGIS.RHKreinTwelfthCellCompositionV1

open AEGIS.RHEulerGammaSharpV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinSixthCellCompositionV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinEleventhCellCompositionV1
open AEGIS.RHKreinTenthCellCompositionV1

/-- The literal twelfth entry of the unchanged committed payload. -/
def twelfthCell : FiniteCellV1 :=
  ⟨1125 / 16384, 2325 / 32768, 307663815114748177⟩

private def twelfthLeft : ℝ := 1125 / 16384
private def twelfthSymbolLower : ℝ := -157 / 25

private theorem digamma_sharp_lower_of_sq_le (s t : ℝ) (N : ℕ)
    (hst : s ^ 2 ≤ t ^ 2) :
    -(5773 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hs := digamma_quarter_finite_lower s N
  have hm := digamma_quarter_mono_of_sq_le s t hst
  have hg := gamma_lt_5773
  dsimp [quarterPoint] at hs
  linarith only [hs, hm, hg]

private theorem twelfthDigammaPartialLower :
    (-3544329981296926 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm twelfthLeft n := by
  have h0 : (-3483167928494988 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm twelfthLeft n := by
    norm_num [twelfthLeft, quarterTerm]
  have h1 : (-45744405364170 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm twelfthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [twelfthLeft, quarterTerm]
  have h2 : (-15417647437768 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm twelfthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [twelfthLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm twelfthLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm twelfthLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2]

private theorem twelfthDigammaLower (t : ℝ) (hst : twelfthLeft ^ 2 ≤ t ^ 2) :
    (-2077 / 500 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_sharp_lower_of_sq_le twelfthLeft t 24 hst
  have hpartial := twelfthDigammaPartialLower
  norm_num [twelfthLeft] at hcert ⊢
  have hpartial' : (-3544329981296926 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm (1125 / 16384) n := by
    simpa [twelfthLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem twelfthLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem twelfthPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The new left-endpoint symbol floor remains valid at every later
nonnegative frequency. -/
theorem symbol_lower_of_twelfthLeft_le (t : ℝ) (hleft : (1125 / 16384 : ℝ) ≤ t) :
    twelfthSymbolLower ≤ symbol t := by
  have hleft' : twelfthLeft ≤ t := by simpa [twelfthLeft] using hleft
  have ht0 : 0 ≤ t := by
    have hleft0 : 0 ≤ twelfthLeft := by norm_num [twelfthLeft]
    linarith
  have hst : twelfthLeft ^ 2 ≤ t ^ 2 := by
    have hleft0 : 0 ≤ twelfthLeft := by norm_num [twelfthLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft') (add_nonneg ht0 hleft0)]
  have hd := twelfthDigammaLower t hst
  have hlp := twelfthLogPiUpper
  have hamp := twelfthPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num [twelfthSymbolLower] at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

private def finiteM8Q : ℝ :=
  138411104278141883145249511099127907904956837 /
    5000000000000000000000000000000000

private def reuseRadius : ℝ := 2325 / 32768
private def weightedCoefficient : ℝ :=
  twelfthSymbolLower - 1 / 16 - (lowerValue twelfthCell : ℝ)
private def reuseError : ℝ :=
  finiteM8Q * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem correction_lower_from_existing_zero_jet (t : ℝ)
    (ht0 : 0 ≤ t) (htr : t ≤ reuseRadius) :
    jetPolynomial7 firstJet firstCenter t - reuseError ≤ correctionSymbol t := by
  have ht300 : t ≤ (300 : ℝ) := htr.trans (by norm_num [reuseRadius])
  have hbase := correction_taylor7_remainder_window300 t ht0 ht300
  have hM0 : 0 ≤ finiteM8Q := by norm_num [finiteM8Q]
  have hpow : |t| ^ 8 ≤ reuseRadius ^ 8 := by
    rw [abs_of_nonneg ht0]
    exact pow_le_pow_left₀ ht0 htr 8
  have hrem :
      |correctionSymbol t - centeredTaylorEval correctionSymbol 7 firstCenter t| ≤
        finiteM8Q * reuseRadius ^ 8 / 40320 := by
    rw [firstCenter]
    refine hbase.trans ?_
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hpow hM0) (by norm_num)
  have hcover : |t - firstCenter| ≤ reuseRadius := by
    rw [firstCenter, sub_zero, abs_of_nonneg ht0]
    exact htr
  have hjet := jetPolynomial7_error firstCenter t reuseRadius
    firstJet firstJetError hcover existing_zero_jet_enclosures
  rw [centeredTaylor_eq_exactJet] at hrem
  rw [abs_le] at hrem hjet
  dsimp only [reuseError]
  linarith only [hrem.1, hjet.1]

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 10000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, twelfthSymbolLower,
    twelfthCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, finiteM8Q, firstJetError, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, twelfthSymbolLower,
        twelfthCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, twelfthSymbolLower,
        twelfthCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The twelfth serialized lower bound follows from existing analytic producers. -/
theorem twelfthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 twelfthCell := by
  apply cellAnalyticSound_of_correction_lower twelfthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [twelfthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [twelfthCell, reuseRadius] using hhi
    exact correction_lower_from_existing_zero_jet t ht0 htr
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [twelfthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [twelfthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 10000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : twelfthSymbolLower ≤ symbol t := by
      apply symbol_lower_of_twelfthLeft_le
      simpa [twelfthCell] using hlo
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue twelfthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (twelfthSymbolLower - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first twelve unchanged serialized cell results compose as a tuple. -/
theorem first_twelve_cells_sound :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinNinthCellCompositionV1.ninthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTenthCellCompositionV1.tenthCell ∧
      CellAnalyticSoundV1 eleventhCell ∧ CellAnalyticSoundV1 twelfthCell :=
  ⟨first_eleven_cells_sound.1, first_eleven_cells_sound.2.1,
    first_eleven_cells_sound.2.2.1, first_eleven_cells_sound.2.2.2.1,
    first_eleven_cells_sound.2.2.2.2.1, first_eleven_cells_sound.2.2.2.2.2.1,
    first_eleven_cells_sound.2.2.2.2.2.2.1,
    first_eleven_cells_sound.2.2.2.2.2.2.2.1,
    first_eleven_cells_sound.2.2.2.2.2.2.2.2.1,
    first_eleven_cells_sound.2.2.2.2.2.2.2.2.2.1,
    first_eleven_cells_sound.2.2.2.2.2.2.2.2.2.2,
    twelfthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinTwelfthCellCompositionV1

#print axioms AEGIS.RHKreinTwelfthCellCompositionV1.symbol_lower_of_twelfthLeft_le
#print axioms AEGIS.RHKreinTwelfthCellCompositionV1.twelfthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinTwelfthCellCompositionV1.first_twelve_cells_sound
~~~~~~

## RHKreinSincIntervalV1

Path: `source/RHKreinSincIntervalV1.lean`

Original source lines: 1–108

Full file SHA256: `28ce3bd88cca60f69a375ea040f0afecccd493ce6d0f49d9bd57be978eabb6e1`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinFiniteIntervalKernelV1
import AEGISOverlay.RHKreinExplicitCorrectionV1

/-!
# Kernel-side sinc interval primitive

This module turns the existing exact Taylor enclosure for `sin x` into an
exact enclosure for `sinc x` at a positive rational phase.  It is the missing
reusable division step needed by the first-cell `k = 0` correction-symbol
certificate.  No numerical certificate and no RH claim is included.

AUTHORITY_EFFECT = NONE.
-/

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSincIntervalV1

open AEGIS.RHKreinFiniteIntervalKernelV1

/-- Divide the sine Taylor error by a strictly positive phase to obtain a
rigorous sinc error.  For a fixed rational `x` and `n`, the right side is
entirely exact rational arithmetic. -/
theorem sinc_expIPartial_error (n : ℕ) (x : ℝ)
    (hn : 0 < n) (hx0 : 0 < x) (hx1 : |x| ≤ 1) :
    |Real.sinc x - (expIPartial n x).im / x| ≤
      (|x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹)) / x := by
  have hsin := sin_expIPartial_error n x hn hx1
  have hsin' :
      |Real.sin x - (expIPartial n x).im| ≤
        x ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
    simpa [abs_of_pos hx0] using hsin
  have hxne : x ≠ 0 := ne_of_gt hx0
  rw [Real.sinc_of_ne_zero hxne]
  rw [← sub_div, abs_div, abs_of_pos hx0]
  exact div_le_div_of_nonneg_right hsin' hx0.le

/-- Two-sided exact sinc interval at a positive rational phase. -/
theorem sinc_expIPartial_interval (n : ℕ) (x : ℝ)
    (hn : 0 < n) (hx0 : 0 < x) (hx1 : |x| ≤ 1) :
    (expIPartial n x).im / x -
          (|x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹)) / x ≤
        Real.sinc x ∧
      Real.sinc x ≤
        (expIPartial n x).im / x +
          (|x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹)) / x := by
  have h := sinc_expIPartial_error n x hn hx0 hx1
  rw [abs_sub_le_iff] at h
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

/-- The degree-six even polynomial obtained by dividing the odd part of the
eight-term exponential Taylor polynomial by its phase. -/
def sincPolynomial7 (x : ℝ) : ℝ :=
  1 - x ^ 2 / 6 + x ^ 4 / 120 - x ^ 6 / 5040

/-- Exact error budget for the common hat sinc factor at the first-cell
center: `firstCenter / 100 = 3 / 32768`. -/
theorem firstCenter_hat_sinc_error :
    |Real.sinc (3 / 32768 : ℝ) - sincPolynomial7 (3 / 32768 : ℝ)| ≤
      (1 / 10000000000000000000000000000 : ℝ) := by
  have h := sinc_expIPartial_error 8 (3 / 32768 : ℝ)
    (by norm_num) (by norm_num) (by norm_num)
  have hp :
      (expIPartial 8 (3 / 32768 : ℝ)).im / (3 / 32768 : ℝ) =
        sincPolynomial7 (3 / 32768 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

/-- Exact error budget for the common edge sinc factor at the first-cell
center: `firstCenter / 2000 = 3 / 655360`. -/
theorem firstCenter_edge_sinc_error :
    |Real.sinc (3 / 655360 : ℝ) - sincPolynomial7 (3 / 655360 : ℝ)| ≤
      (1 / 1000000000000000000000000000000000000 : ℝ) := by
  have h := sinc_expIPartial_error 8 (3 / 655360 : ℝ)
    (by norm_num) (by norm_num) (by norm_num)
  have hp :
      (expIPartial 8 (3 / 655360 : ℝ)).im / (3 / 655360 : ℝ) =
        sincPolynomial7 (3 / 655360 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

end AEGIS.RHKreinSincIntervalV1

#print axioms AEGIS.RHKreinSincIntervalV1.sinc_expIPartial_error
#print axioms AEGIS.RHKreinSincIntervalV1.sinc_expIPartial_interval
#print axioms AEGIS.RHKreinSincIntervalV1.firstCenter_hat_sinc_error
#print axioms AEGIS.RHKreinSincIntervalV1.firstCenter_edge_sinc_error
~~~~~~

## RHKreinFifteenthCellK1FormulaV1

Path: `source/RHKreinFifteenthCellK1FormulaV1.lean`

Original source lines: 1–216

Full file SHA256: `407fb2554b81a94cfc503d62070dbe1d0afcbe88ad8941ff8745d0a9bd6eedf1`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFifteenthCellK0V1

/-!
# Fifteenth-cell first-derivative formula

This file expands the first derivative of `correctionSymbol` at the exact
fifteenth-cell midpoint.  It reduces the `k = 1` Taylor-jet premise to one
explicit numerical enclosure.  It does not assert that enclosure.

AUTHORITY_EFFECT = NONE.
-/

open scoped BigOperators

set_option autoImplicit false
set_option maxHeartbeats 800000
noncomputable section

namespace AEGIS.RHKreinFifteenthCellK1FormulaV1

open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFifteenthCellReductionV1
open AEGIS.RHKreinM8AnalyticV1

/-- Quotient-rule derivative of `sinc` away from zero. -/
theorem hasDerivAt_sinc_of_ne_zero {x : ℝ} (hx : x ≠ 0) :
    HasDerivAt Real.sinc ((x * Real.cos x - Real.sin x) / x ^ 2) x := by
  have hquot : HasDerivAt (fun y : ℝ => Real.sin y / y)
      ((x * Real.cos x - Real.sin x) / x ^ 2) x := by
    have h := (Real.hasDerivAt_sin x).div (hasDerivAt_id x) hx
    have hfun : (Real.sin / id : ℝ → ℝ) = fun y : ℝ => Real.sin y / y := by
      funext y
      rfl
    rw [hfun] at h
    simpa only [id_eq, mul_one, one_mul, mul_comm] using h
  apply hquot.congr_of_eventuallyEq
  filter_upwards [eventually_ne_nhds hx] with y hy
  rw [Real.sinc_of_ne_zero hy]

/-- Chain-rule specialization for a nonzero scaled sinc argument. -/
theorem hasDerivAt_sinc_div_const {c d : ℝ} (hc : c / d ≠ 0) :
    HasDerivAt (fun t : ℝ => Real.sinc (t / d))
      (((c / d) * Real.cos (c / d) - Real.sin (c / d)) / (c / d) ^ 2 *
        (1 / d)) c := by
  have hi : HasDerivAt (fun t : ℝ => t / d) (1 / d) c := by
    simpa only [id_eq] using (hasDerivAt_id c).div_const d
  exact (hasDerivAt_sinc_of_ne_zero hc).comp c hi

/-- The derivative of one trigonometric hat column at the midpoint. -/
def hatColumnDerivative (j : Fin 199) : ℝ :=
  (hatCoefficient j : ℝ) *
    (-(Real.sin (fifteenthCenter * hatCenter j) * hatCenter j))

/-- Derivative of the parity-selected edge phase at the midpoint. -/
def edgePhaseDerivative (j : Fin 5) : ℝ :=
  if j.val % 2 = 0 then
    -(Real.sin (fifteenthCenter * (1619 / 2000)) * (1619 / 2000))
  else
    Real.cos (fifteenthCenter * (1619 / 2000)) * (1619 / 2000)

/-- Derivative of one polynomial-times-phase edge column at the midpoint. -/
def edgeColumnDerivative (j : Fin 5) : ℝ :=
  (splineCoefficient j : ℝ) *
    (((j.val : ℝ) * fifteenthCenter ^ (j.val - 1)) *
        (if j.val % 2 = 0 then
          Real.cos (fifteenthCenter * (1619 / 2000))
        else
          Real.sin (fifteenthCenter * (1619 / 2000))) +
      fifteenthCenter ^ j.val * edgePhaseDerivative j)

/-- The sinc derivative in the hat component. -/
def fifteenthHatSincDerivative : ℝ :=
  ((fifteenthCenter / 100) * Real.cos (fifteenthCenter / 100) -
      Real.sin (fifteenthCenter / 100)) / (fifteenthCenter / 100) ^ 2 *
    (1 / 100)

/-- The sinc derivative in the edge component. -/
def fifteenthEdgeSincDerivative : ℝ :=
  ((fifteenthCenter / 2000) * Real.cos (fifteenthCenter / 2000) -
      Real.sin (fifteenthCenter / 2000)) / (fifteenthCenter / 2000) ^ 2 *
    (1 / 2000)

/-- Fully expanded product-rule value for `correctionSymbol' fifteenthCenter`. -/
def fifteenthCorrectionDerivativeFormula : ℝ :=
  (2 / 50) *
      ((2 * Real.sinc (fifteenthCenter / 100) * fifteenthHatSincDerivative) *
          (∑ j : Fin 199, (hatCoefficient j : ℝ) *
            Real.cos (fifteenthCenter * hatCenter j)) +
        Real.sinc (fifteenthCenter / 100) ^ 2 *
          (∑ j : Fin 199, hatColumnDerivative j)) +
    (19 * Real.sinc (fifteenthCenter / 2000) ^ 18 *
        fifteenthEdgeSincDerivative) *
      (∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
        (if j.val % 2 = 0 then
          Real.cos (fifteenthCenter * (1619 / 2000))
        else
          Real.sin (fifteenthCenter * (1619 / 2000)))) +
    Real.sinc (fifteenthCenter / 2000) ^ 19 *
      (∑ j : Fin 5, edgeColumnDerivative j)

private theorem hatColumn_hasDerivAt (j : Fin 199) :
    HasDerivAt
      (fun t : ℝ => (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j))
      (hatColumnDerivative j) fifteenthCenter := by
  have hinner := (hasDerivAt_id fifteenthCenter).mul_const (hatCenter j)
  simpa [hatColumnDerivative, mul_assoc] using
    ((Real.hasDerivAt_cos (fifteenthCenter * hatCenter j)).comp
      fifteenthCenter hinner).const_mul (hatCoefficient j : ℝ)

private theorem edgePhase_hasDerivAt (j : Fin 5) :
    HasDerivAt
      (fun t : ℝ =>
        if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
        else Real.sin (t * (1619 / 2000)))
      (edgePhaseDerivative j) fifteenthCenter := by
  have hinner := (hasDerivAt_id fifteenthCenter).mul_const (1619 / 2000 : ℝ)
  by_cases hj : j.val % 2 = 0
  · simp only [hj, if_true, edgePhaseDerivative]
    simpa [Function.comp_def, mul_assoc] using
      (Real.hasDerivAt_cos (fifteenthCenter * (1619 / 2000))).comp
        fifteenthCenter hinner
  · simp only [hj, if_false, edgePhaseDerivative]
    simpa [Function.comp_def] using
      (Real.hasDerivAt_sin (fifteenthCenter * (1619 / 2000))).comp
        fifteenthCenter hinner

private theorem edgeColumn_hasDerivAt (j : Fin 5) :
    HasDerivAt
      (fun t : ℝ => (splineCoefficient j : ℝ) * t ^ j.val *
        (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
        else Real.sin (t * (1619 / 2000))))
      (edgeColumnDerivative j) fifteenthCenter := by
  have hpow := hasDerivAt_pow j.val fifteenthCenter
  have hphase := edgePhase_hasDerivAt j
  have hproduct := hpow.mul hphase
  simpa [edgeColumnDerivative, mul_add, mul_assoc] using
    hproduct.const_mul (splineCoefficient j : ℝ)

/-- The explicit formula is the ordinary first derivative at the exact
fifteenth-cell midpoint. -/
theorem correctionSymbol_hasDerivAt_fifteenthCenter :
    HasDerivAt correctionSymbol fifteenthCorrectionDerivativeFormula
      fifteenthCenter := by
  have hhatSum :
      HasDerivAt
        (fun t : ℝ => ∑ j : Fin 199,
          (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j))
        (∑ j : Fin 199, hatColumnDerivative j) fifteenthCenter := by
    exact HasDerivAt.fun_sum fun j _ => hatColumn_hasDerivAt j
  have hedgeSum :
      HasDerivAt
        (fun t : ℝ => ∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
          (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
          else Real.sin (t * (1619 / 2000))))
        (∑ j : Fin 5, edgeColumnDerivative j) fifteenthCenter := by
    exact HasDerivAt.fun_sum fun j _ => edgeColumn_hasDerivAt j
  have hhatSinc : HasDerivAt (fun t : ℝ => Real.sinc (t / 100))
      fifteenthHatSincDerivative fifteenthCenter := by
    apply hasDerivAt_sinc_div_const
    norm_num [fifteenthCenter]
  have hedgeSinc : HasDerivAt (fun t : ℝ => Real.sinc (t / 2000))
      fifteenthEdgeSincDerivative fifteenthCenter := by
    apply hasDerivAt_sinc_div_const
    norm_num [fifteenthCenter]
  have hhat := (hhatSinc.pow 2).mul hhatSum
  have hedge := (hedgeSinc.pow 19).mul hedgeSum
  have hfull := hhat.const_mul (2 / 50 : ℝ) |>.add hedge
  have hsymbol := hfull.congr_of_eventuallyEq
    (show Filter.EventuallyEq (nhds fifteenthCenter) correctionSymbol _ from
      Filter.Eventually.of_forall fun t => by
        simp only [correctionSymbol]
        ring)
  apply hsymbol.congr_deriv
  simp only [fifteenthCorrectionDerivativeFormula,
    fifteenthHatSincDerivative, fifteenthEdgeSincDerivative, Pi.pow_apply]
  ring

/-- For `k = 1`, the normalized exact jet is the expanded derivative formula. -/
theorem fifteenthCenter_exactJetCoefficient_one :
    exactJetCoefficient fifteenthCenter 1 =
      fifteenthCorrectionDerivativeFormula := by
  rw [exactJetCoefficient, iteratedDeriv_one]
  norm_num
  exact correctionSymbol_hasDerivAt_fifteenthCenter.deriv

/-- Formula-to-target transport for the serialized `k = 1` enclosure. -/
theorem fifteenthCenter_k1_enclosure_of_formula
    (hformula :
      |fifteenthCorrectionDerivativeFormula - fifteenthJet 1| ≤
        fifteenthJetError 1) :
    |exactJetCoefficient fifteenthCenter 1 - fifteenthJet 1| ≤
      fifteenthJetError 1 := by
  rwa [fifteenthCenter_exactJetCoefficient_one]

end AEGIS.RHKreinFifteenthCellK1FormulaV1

#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.hasDerivAt_sinc_of_ne_zero
#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.correctionSymbol_hasDerivAt_fifteenthCenter
#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.fifteenthCenter_exactJetCoefficient_one
#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.fifteenthCenter_k1_enclosure_of_formula
~~~~~~

