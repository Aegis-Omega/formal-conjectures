# AEGIS source modules 2

Exact pinned or operator archive source. Compilation was not performed during transfer.

## WeilFixedLineFubiniSwapV4

Path: `source/WeilFixedLineFubiniSwapV4.lean`

Original source lines: 1–208

Full file SHA256: `b6226f21053f2a55672ec06cb9d18644007c01e4e20d967cd9c7229699eb595d`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineFubiniSwapV4.lean

~~~~~~lean
import WeilMellinWeightedFixedLineV2
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Tactic

/-!
AEGIS Ω — fixed-line Fubini / paired-Hadamard assembly v4.

This module consumes the exact FZ absolute product-integral certificate from
WeilFixedLineFubiniCoreV3 and turns it into the actual integral-tsum exchange.
It then composes that exchange with the already kernel-verified paired
Hadamard kernel identity.

No gamma/digamma evaluation, whole explicit-formula identity, arithmetic sign,
global Weil positivity, or RH conclusion is asserted here.
-/

open Complex MeasureTheory Filter
open scoped BigOperators

set_option autoImplicit false

noncomputable section

private theorem fubini_fixed_line_left_ne_v4
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    ((c : ℂ) + (t : ℂ) * I) ≠ ρ.val := by
  intro h
  have hre := congrArg Complex.re h
  simp at hre
  linarith [ρ.property.2.2]

private theorem fubini_one_sub_fixed_line_ne_v4
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    1 - ((c : ℂ) + (t : ℂ) * I) ≠ ρ.val := by
  intro h
  have hre := congrArg Complex.re h
  simp at hre
  linarith [ρ.property.2.1]

private theorem fubini_fixed_line_denom_left_ne_v4
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    ((c : ℂ) + (t : ℂ) * I) - ρ.val ≠ 0 :=
  sub_ne_zero.mpr (fubini_fixed_line_left_ne_v4 c t ρ hc)

private theorem fubini_fixed_line_denom_right_ne_v4
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    ((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val) ≠ 0 := by
  apply sub_ne_zero.mpr
  intro h
  apply fubini_one_sub_fixed_line_ne_v4 c t ρ hc
  rw [h]
  ring

private theorem fubini_paired_zero_kernel_continuous_v4
    (c : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    Continuous (fun t : ℝ => WeilPairedZeroKernelV3 c t ρ) := by
  unfold WeilPairedZeroKernelV3
  have h₁ : Continuous
      (fun t : ℝ => ((c : ℂ) + (t : ℂ) * I) - ρ.val) := by
    fun_prop
  have h₂ : Continuous
      (fun t : ℝ => ((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val)) := by
    fun_prop
  exact
    (continuous_const.div h₁
      (fun t => fubini_fixed_line_denom_left_ne_v4 c t ρ hc)).add
      (continuous_const.div h₂
        (fun t => fubini_fixed_line_denom_right_ne_v4 c t ρ hc))

private theorem fubini_paired_zero_kernel_global_norm_bound_v4
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    ‖WeilPairedZeroKernelV3 c t ρ‖ ≤ 2 / (c - 1) := by
  let δ : ℝ := c - 1
  have hδ : 0 < δ := by dsimp [δ]; linarith
  let d₁ : ℂ := ((c : ℂ) + (t : ℂ) * I) - ρ.val
  let d₂ : ℂ := ((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val)
  have hd₁ : δ ≤ ‖d₁‖ := by
    have hre : δ ≤ d₁.re := by
      dsimp [δ, d₁]
      simp
      linarith [ρ.property.2.2]
    exact hre.trans (Complex.re_le_norm d₁)
  have hd₂ : δ ≤ ‖d₂‖ := by
    have hre : δ ≤ d₂.re := by
      dsimp [δ, d₂]
      simp
      linarith [ρ.property.2.1]
    exact hre.trans (Complex.re_le_norm d₂)
  have hi₁ : ‖(1 : ℂ) / d₁‖ ≤ 1 / δ := by
    rw [norm_div, norm_one]
    exact one_div_le_one_div_of_le hδ hd₁
  have hi₂ : ‖(1 : ℂ) / d₂‖ ≤ 1 / δ := by
    rw [norm_div, norm_one]
    exact one_div_le_one_div_of_le hδ hd₂
  change ‖(1 : ℂ) / d₁ + (1 : ℂ) / d₂‖ ≤ 2 / δ
  calc
    ‖(1 : ℂ) / d₁ + (1 : ℂ) / d₂‖
        ≤ ‖(1 : ℂ) / d₁‖ + ‖(1 : ℂ) / d₂‖ := norm_add_le _ _
    _ ≤ 1 / δ + 1 / δ := add_le_add hi₁ hi₂
    _ = 2 / δ := by ring

private theorem fubini_paired_zero_kernel_mul_integrable_v4
    (H : ℝ → ℂ) (c : ℝ) (ρ : LiCriterion.NontrivialZero)
    (hc : 1 < c) (hH : HasVerticalNormMomentsTwoV3 H) :
    Integrable (fun t : ℝ => WeilPairedZeroKernelV3 c t ρ * H t) := by
  have hkmeas :
      AEStronglyMeasurable (fun t : ℝ => WeilPairedZeroKernelV3 c t ρ) :=
    (fubini_paired_zero_kernel_continuous_v4 c ρ hc).aestronglyMeasurable
  exact hH.1.bdd_mul hkmeas
    (Filter.Eventually.of_forall fun t =>
      fubini_paired_zero_kernel_global_norm_bound_v4 c t ρ hc)

/-- The FZ certificate is exactly strong enough to commute the multiplicity-
weighted paired zero series with the fixed-line integral. -/
theorem riemannXi_paired_kernel_integral_tsum_v4
    (H : ℝ → ℂ) (c : ℝ) (hc : 1 < c)
    (hH : HasVerticalNormMomentsTwoV3 H) :
    (∑' ρ : LiCriterion.NontrivialZero,
      ∫ t : ℝ,
        ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          WeilPairedZeroKernelV3 c t ρ) * H t) =
      ∫ t : ℝ,
        ∑' ρ : LiCriterion.NontrivialZero,
          ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            WeilPairedZeroKernelV3 c t ρ) * H t := by
  apply integral_tsum_of_summable_integral_norm
  · intro ρ
    have hprod :=
      fubini_paired_zero_kernel_mul_integrable_v4 H c ρ hc hH
    simpa [mul_assoc] using
      hprod.const_mul
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ)
  · have hFZ :=
      riemannXi_paired_kernel_product_integral_summable_v3 H c hc hH
    refine hFZ.congr ?_
    intro ρ
    have heq :
        (fun t : ℝ =>
          ‖((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
              WeilPairedZeroKernelV3 c t ρ) * H t‖) =
        (fun t : ℝ =>
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) *
            ‖WeilPairedZeroKernelV3 c t ρ * H t‖) := by
      funext t
      simp [norm_mul, mul_assoc]
    rw [heq, integral_const_mul]

/-- Full analytic composition achieved by the current fixed-line lane:
the integral of the paired xi logarithmic derivative is the multiplicity-
weighted series of paired-kernel integrals. -/
theorem riemannXi_paired_logDeriv_fixed_line_integral_v4
    (H : ℝ → ℂ) (c : ℝ) (hc : 1 < c)
    (hH : HasVerticalNormMomentsTwoV3 H) :
    (∫ t : ℝ,
      (2 * _root_.logDeriv LiCriterion.riemannXi
        ((c : ℂ) + (t : ℂ) * I)) * H t) =
      ∑' ρ : LiCriterion.NontrivialZero,
        ∫ t : ℝ,
          ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            WeilPairedZeroKernelV3 c t ρ) * H t := by
  calc
    (∫ t : ℝ,
      (2 * _root_.logDeriv LiCriterion.riemannXi
        ((c : ℂ) + (t : ℂ) * I)) * H t)
        =
      ∫ t : ℝ,
        ∑' ρ : LiCriterion.NontrivialZero,
          ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            WeilPairedZeroKernelV3 c t ρ) * H t := by
      apply integral_congr_ae
      filter_upwards [] with t
      let s : ℂ := (c : ℂ) + (t : ℂ) * I
      have hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val := by
        intro ρ
        exact fubini_fixed_line_left_ne_v4 c t ρ hc
      have h1s : ∀ ρ : LiCriterion.NontrivialZero, 1 - s ≠ ρ.val := by
        intro ρ
        exact fubini_one_sub_fixed_line_ne_v4 c t ρ hc
      have hsum :=
        riemannXi_paired_hadamard_kernel_summable_v2 s hs h1s
      have hts :=
        riemannXi_paired_hadamard_kernel_tsum_v2 s hs h1s
      calc
        (2 * _root_.logDeriv LiCriterion.riemannXi s) * H t
            =
          (∑' ρ : LiCriterion.NontrivialZero,
            (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
              (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val)))) * H t := by
              rw [hts]
        _ =
          ∑' ρ : LiCriterion.NontrivialZero,
            ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
              WeilPairedZeroKernelV3 c t ρ) * H t := by
              rw [← hsum.tsum_mul_right (H t)]
              apply tsum_congr
              intro ρ
              rfl
    _ =
      ∑' ρ : LiCriterion.NontrivialZero,
        ∫ t : ℝ,
          ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            WeilPairedZeroKernelV3 c t ρ) * H t :=
      (riemannXi_paired_kernel_integral_tsum_v4 H c hc hH).symm

end

#print axioms riemannXi_paired_kernel_integral_tsum_v4
#print axioms riemannXi_paired_logDeriv_fixed_line_integral_v4
~~~~~~

## WeilMellinWeightedFixedLineV2

Path: `source/WeilMellinWeightedFixedLineV2.lean`

Original source lines: 1–184

Full file SHA256: `51eed930b62271427ef7097a164ab7ebeae7569580fd0b9c1a4437ced1a7de04`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilMellinWeightedFixedLineV2.lean

~~~~~~lean
import WeilFixedLineFubiniCoreV3
import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier

/-!
AEGIS Ω — first absolute Mellin moment on an arbitrary fixed vertical line v2.

The fixed-line proof in #490 uses not only vertical L1 integrability but also
the first absolute moment in height.  The existing Mellin inversion lane
already identifies each fixed Mellin line with the Fourier transform of a
compactly supported smooth logarithmic profile.  Such a profile is Schwartz,
its Fourier transform is Schwartz, and Mathlib's
`SchwartzMap.integrable_pow_mul` supplies the required polynomially weighted
L1 control.

This theorem is valid for every real line `σ`, in particular for the pair
`c` and `1-c` used by the paired-Hadamard fixed-line argument.

No zero sum, Fubini interchange, explicit-formula assembly, sign inequality,
or RH conclusion is asserted here.
-/

open Set Filter Topology Complex MeasureTheory
open scoped ContDiff FourierTransform

set_option autoImplicit false

noncomputable section

private theorem mellin_fixed_line_log_profile_contDiff_v2
    (f : WeilCompactSmoothGV1) :
    ContDiff ℝ ∞ (MellinLogProfileV1 f.1) := by
  unfold MellinLogProfileV1
  have hneg : ContDiff ℝ ∞ (fun u : ℝ => -u) := by fun_prop
  exact f.2.1.comp (Real.contDiff_exp.comp hneg)

private theorem mellin_fixed_line_log_profile_hasCompactSupport_v2
    (f : WeilCompactSmoothGV1) :
    HasCompactSupport (MellinLogProfileV1 f.1) := by
  let K : Set ℝ := (fun x : ℝ => -Real.log x) '' tsupport f.1
  have hts : IsCompact (tsupport f.1) := by
    change IsCompact (closure (Function.support f.1))
    exact f.2.2.1
  have hlog : ContinuousOn (fun x : ℝ => -Real.log x) (tsupport f.1) := by
    intro x hx
    have hxpos : 0 < x := f.2.2.2 hx
    exact (Real.continuousAt_log hxpos.ne').neg.continuousWithinAt
  have hK : IsCompact K := hts.image_of_continuousOn hlog
  apply HasCompactSupport.of_support_subset_isCompact hK
  intro u hu
  change f.1 (Real.exp (-u)) ≠ 0 at hu
  have hmem : Real.exp (-u) ∈ tsupport f.1 := subset_closure hu
  refine ⟨Real.exp (-u), hmem, ?_⟩
  simp

private theorem mellin_fixed_line_complex_weight_contDiff_v2 (σ : ℝ) :
    ContDiff ℝ ∞ (MellinComplexWeightV1 σ) := by
  unfold MellinComplexWeightV1 MellinWeightV1
  fun_prop

private theorem mellin_fixed_line_weighted_profile_contDiff_v2
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    ContDiff ℝ ∞ (MellinWeightedLogProfileV1 f.1 σ) := by
  unfold MellinWeightedLogProfileV1
  exact (mellin_fixed_line_complex_weight_contDiff_v2 σ).mul
    (mellin_fixed_line_log_profile_contDiff_v2 f)

private theorem mellin_fixed_line_weighted_profile_hasCompactSupport_v2
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    HasCompactSupport (MellinWeightedLogProfileV1 f.1 σ) := by
  have hh : HasCompactSupport (MellinLogProfileV1 f.1) :=
    mellin_fixed_line_log_profile_hasCompactSupport_v2 f
  apply hh.of_isClosed_subset (isClosed_tsupport _)
  change tsupport (fun u : ℝ =>
      MellinComplexWeightV1 σ u * MellinLogProfileV1 f.1 u) ⊆
    tsupport (MellinLogProfileV1 f.1)
  exact tsupport_mul_subset_right

private def MellinFixedLineSchwartzV2
    (f : WeilCompactSmoothGV1) (σ : ℝ) : SchwartzMap ℝ ℂ :=
  (mellin_fixed_line_weighted_profile_hasCompactSupport_v2 f σ).toSchwartzMap
    (mellin_fixed_line_weighted_profile_contDiff_v2 f σ)

private theorem mellin_fixed_line_eq_fourier_v2
    (f : WeilCompactSmoothGV1) (σ γ : ℝ) :
    mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I) =
      𝓕 (MellinFixedLineSchwartzV2 f σ) (γ / (2 * Real.pi)) := by
  rw [mellin_eq_fourier]
  have hre : (((σ : ℂ) + (γ : ℂ) * Complex.I).re) = σ := by simp
  have him : (((σ : ℂ) + (γ : ℂ) * Complex.I).im) = γ := by simp
  rw [hre, him]
  have hprofile :
      (fun u : ℝ => Real.exp (-σ * u) • f.1 (Real.exp (-u))) =
        (MellinFixedLineSchwartzV2 f σ : ℝ → ℂ) := by
    funext u
    simp [MellinFixedLineSchwartzV2, MellinWeightedLogProfileV1,
      MellinComplexWeightV1, MellinWeightV1, MellinLogProfileV1,
      Complex.real_smul]
  rw [hprofile]
  rfl

/-- The first absolute height moment of the Mellin transform is integrable on
every real vertical line.  This is the A1 input used in the fixed-line Fubini
estimate of #490. -/
theorem weil_compact_smooth_mellin_vertical_abs_moment_one_v2
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    Integrable (fun γ : ℝ =>
      |γ| * ‖mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I)‖) := by
  let P : SchwartzMap ℝ ℂ := MellinFixedLineSchwartzV2 f σ
  have hweighted :
      Integrable (fun ξ : ℝ => ‖ξ‖ ^ (1 : ℕ) * ‖(𝓕 P) ξ‖) :=
    (𝓕 P).integrable_pow_mul volume 1
  have hpi : 0 < 2 * Real.pi := by positivity
  have hpi0 : 2 * Real.pi ≠ 0 := ne_of_gt hpi
  have hscaled :=
    hweighted.comp_mul_right' (inv_ne_zero hpi0)
  have hconst := hscaled.const_mul (2 * Real.pi)
  have hpoint : ∀ γ : ℝ,
      |γ| * ‖mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I)‖ =
        2 * Real.pi *
          (‖γ * (2 * Real.pi)⁻¹‖ ^ (1 : ℕ) *
            ‖(𝓕 P) (γ * (2 * Real.pi)⁻¹)‖) := by
    intro γ
    rw [mellin_fixed_line_eq_fourier_v2]
    change |γ| * ‖(𝓕 P) (γ / (2 * Real.pi))‖ =
      2 * Real.pi *
        (‖γ * (2 * Real.pi)⁻¹‖ ^ (1 : ℕ) *
          ‖(𝓕 P) (γ * (2 * Real.pi)⁻¹)‖)
    rw [div_eq_mul_inv]
    simp only [pow_one, Real.norm_eq_abs, abs_mul, abs_inv,
      abs_of_pos hpi]
    field_simp [hpi0]
  exact hconst.congr
    (Filter.Eventually.of_forall fun γ => (hpoint γ).symm)


/-- The second absolute height moment of the Mellin transform is integrable on
every real vertical line. This is the A2 input used by the strengthened FZ
majorant in WeilFixedLineFubiniCoreV3. -/
theorem weil_compact_smooth_mellin_vertical_abs_moment_two_v3
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    Integrable (fun γ : ℝ =>
      |γ| ^ 2 * ‖mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I)‖) := by
  let P : SchwartzMap ℝ ℂ := MellinFixedLineSchwartzV2 f σ
  have hweighted :
      Integrable (fun ξ : ℝ => ‖ξ‖ ^ (2 : ℕ) * ‖(𝓕 P) ξ‖) :=
    (𝓕 P).integrable_pow_mul volume 2
  have hpi : 0 < 2 * Real.pi := by positivity
  have hpi0 : 2 * Real.pi ≠ 0 := ne_of_gt hpi
  have hscaled :=
    hweighted.comp_mul_right' (inv_ne_zero hpi0)
  have hconst := hscaled.const_mul ((2 * Real.pi) ^ 2)
  have hpoint : ∀ γ : ℝ,
      |γ| ^ 2 * ‖mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I)‖ =
        (2 * Real.pi) ^ 2 *
          (‖γ * (2 * Real.pi)⁻¹‖ ^ (2 : ℕ) *
            ‖(𝓕 P) (γ * (2 * Real.pi)⁻¹)‖) := by
    intro γ
    rw [mellin_fixed_line_eq_fourier_v2]
    change |γ| ^ 2 * ‖(𝓕 P) (γ / (2 * Real.pi))‖ =
      (2 * Real.pi) ^ 2 *
        (‖γ * (2 * Real.pi)⁻¹‖ ^ (2 : ℕ) *
          ‖(𝓕 P) (γ * (2 * Real.pi)⁻¹)‖)
    rw [div_eq_mul_inv]
    simp only [Real.norm_eq_abs, abs_mul, abs_inv, abs_of_pos hpi]
    field_simp [hpi0]
  exact hconst.congr
    (Filter.Eventually.of_forall fun γ => (hpoint γ).symm)

/-- Concrete compact-smooth Mellin profiles satisfy the complete abstract
moment contract consumed by the FZ core: L1, first absolute moment, and second
absolute moment. -/
theorem weil_compact_smooth_mellin_has_vertical_norm_moments_two_v3
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    HasVerticalNormMomentsTwoV3
      (fun γ : ℝ => mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I)) := by
  refine ⟨?_, weil_compact_smooth_mellin_vertical_abs_moment_one_v2 f σ,
    weil_compact_smooth_mellin_vertical_abs_moment_two_v3 f σ⟩
  exact weil_compact_smooth_mellin_vertical_integrable_all_v1 f σ

end

#print axioms weil_compact_smooth_mellin_vertical_abs_moment_one_v2
#print axioms weil_compact_smooth_mellin_vertical_abs_moment_two_v3
#print axioms weil_compact_smooth_mellin_has_vertical_norm_moments_two_v3
~~~~~~

## WeilFixedLineFubiniCoreV3

Path: `source/WeilFixedLineFubiniCoreV3.lean`

Original source lines: 1–378

Full file SHA256: `25f6a69b74844a6af404f34e550f6f3465c1531a1f73e6993f164c538b611570`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineFubiniCoreV3.lean

~~~~~~lean
import WeilPairedHadamardKernelTsumV2
import Mathlib.Tactic

/-!
AEGIS Ω — fixed-line paired-zero Fubini majorant core v3.

This module kernelizes the absolute product-integral estimate (FZ) from the
#490 paired-Hadamard proof note.  It is deliberately stated for an abstract
vertical profile H carrying the three weighted L1 moments actually used by
the proof.  A subsequent module will bind those moments to the concrete
compact-smooth Mellin profile via Mathlib Schwartz integrability.

No contour shift, normalized explicit-formula assembly, arithmetic sign
inequality, global Weil positivity, or RH implication is asserted here.
-/

open Complex MeasureTheory Filter
open scoped BigOperators

set_option autoImplicit false

noncomputable section

/-- Paired nontrivial-zero kernel on the fixed line Re(s)=c. -/
def WeilPairedZeroKernelV3
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) : ℂ :=
  1 / (((c : ℂ) + (t : ℂ) * I) - ρ.val) +
  1 / (((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val))

/-- Exactly the L1 moments needed by the FZ split: H itself, |t|H, and
|t|^2 H.  The first field also supplies strong measurability of H. -/
def HasVerticalNormMomentsTwoV3 (H : ℝ → ℂ) : Prop :=
  Integrable H ∧
  Integrable (fun t : ℝ => |t| * ‖H t‖) ∧
  Integrable (fun t : ℝ => |t| ^ 2 * ‖H t‖)

private theorem weil_fixed_line_denom_left_ne_v3
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    ((c : ℂ) + (t : ℂ) * I) - ρ.val ≠ 0 := by
  intro h
  have heq : ((c : ℂ) + (t : ℂ) * I) = ρ.val := sub_eq_zero.mp h
  have hre := congrArg Complex.re heq
  simp at hre
  linarith [ρ.property.2.2]

private theorem weil_fixed_line_denom_right_ne_v3
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    ((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val) ≠ 0 := by
  intro h
  have heq : ((c : ℂ) + (t : ℂ) * I) = 1 - ρ.val := sub_eq_zero.mp h
  have hre := congrArg Complex.re heq
  simp at hre
  linarith [ρ.property.2.1]

/-- Exact paired rational identity, restricted to the actual fixed-line regime
c>1 so Lean's totalized division never encounters a pole. -/
theorem weil_paired_zero_kernel_eq_quotient_v3
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    WeilPairedZeroKernelV3 c t ρ =
      (2 * ((c : ℂ) + (t : ℂ) * I) - 1) /
        ((((c : ℂ) + (t : ℂ) * I) - ρ.val) *
          (((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val))) := by
  unfold WeilPairedZeroKernelV3
  have h₁ := weil_fixed_line_denom_left_ne_v3 c t ρ hc
  have h₂ := weil_fixed_line_denom_right_ne_v3 c t ρ hc
  field_simp [h₁, h₂]
  ring

private theorem weil_paired_zero_kernel_continuous_v3
    (c : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    Continuous (fun t : ℝ => WeilPairedZeroKernelV3 c t ρ) := by
  unfold WeilPairedZeroKernelV3
  have h₁ : Continuous
      (fun t : ℝ => ((c : ℂ) + (t : ℂ) * I) - ρ.val) := by
    fun_prop
  have h₂ : Continuous
      (fun t : ℝ => ((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val)) := by
    fun_prop
  exact
    (continuous_const.div h₁ (fun t => weil_fixed_line_denom_left_ne_v3 c t ρ hc)).add
      (continuous_const.div h₂ (fun t => weil_fixed_line_denom_right_ne_v3 c t ρ hc))

private theorem weil_paired_zero_kernel_global_norm_bound_v3
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c) :
    ‖WeilPairedZeroKernelV3 c t ρ‖ ≤ 2 / (c - 1) := by
  let δ : ℝ := c - 1
  have hδ : 0 < δ := by dsimp [δ]; linarith
  let d₁ : ℂ := ((c : ℂ) + (t : ℂ) * I) - ρ.val
  let d₂ : ℂ := ((c : ℂ) + (t : ℂ) * I) - (1 - ρ.val)
  have hd₁ : δ ≤ ‖d₁‖ := by
    have hre : δ ≤ d₁.re := by
      dsimp [δ, d₁]
      simp
      linarith [ρ.property.2.2]
    exact hre.trans (Complex.re_le_norm d₁)
  have hd₂ : δ ≤ ‖d₂‖ := by
    have hre : δ ≤ d₂.re := by
      dsimp [δ, d₂]
      simp
      linarith [ρ.property.2.1]
    exact hre.trans (Complex.re_le_norm d₂)
  have hi₁ : ‖(1 : ℂ) / d₁‖ ≤ 1 / δ := by
    rw [norm_div, norm_one]
    exact one_div_le_one_div_of_le hδ hd₁
  have hi₂ : ‖(1 : ℂ) / d₂‖ ≤ 1 / δ := by
    rw [norm_div, norm_one]
    exact one_div_le_one_div_of_le hδ hd₂
  change ‖(1 : ℂ) / d₁ + (1 : ℂ) / d₂‖ ≤ 2 / δ
  calc
    ‖(1 : ℂ) / d₁ + (1 : ℂ) / d₂‖
        ≤ ‖(1 : ℂ) / d₁‖ + ‖(1 : ℂ) / d₂‖ := norm_add_le _ _
    _ ≤ 1 / δ + 1 / δ := add_le_add hi₁ hi₂
    _ = 2 / δ := by ring

private theorem weil_paired_zero_kernel_central_norm_bound_v3
    (c t : ℝ) (ρ : LiCriterion.NontrivialZero) (hc : 1 < c)
    (hh : 1 ≤ |ρ.val.im|) (ht : |t| ≤ |ρ.val.im| / 2) :
    ‖WeilPairedZeroKernelV3 c t ρ‖ ≤
      4 * (2 * c + 1 + 2 * |t|) / |ρ.val.im| ^ 2 := by
  let h : ℝ := |ρ.val.im|
  have hpos : 0 < h := lt_of_lt_of_le zero_lt_one (by simpa [h] using hh)
  let z : ℂ := (c : ℂ) + (t : ℂ) * I
  let d₁ : ℂ := z - ρ.val
  let d₂ : ℂ := z - (1 - ρ.val)
  have him₁ : h / 2 ≤ |t - ρ.val.im| := by
    have htri : h ≤ |t - ρ.val.im| + |t| := by
      calc
        h = |(t - ρ.val.im) + (-t)| := by
          dsimp [h]
          rw [show (t - ρ.val.im) + (-t) = -ρ.val.im by ring, abs_neg]
        _ ≤ |t - ρ.val.im| + |-t| := abs_add_le _ _
        _ = |t - ρ.val.im| + |t| := by rw [abs_neg]
    linarith
  have him₂ : h / 2 ≤ |t + ρ.val.im| := by
    have htri : h ≤ |t + ρ.val.im| + |t| := by
      calc
        h = |(t + ρ.val.im) + (-t)| := by
          dsimp [h]
          rw [show (t + ρ.val.im) + (-t) = ρ.val.im by ring]
        _ ≤ |t + ρ.val.im| + |-t| := abs_add_le _ _
        _ = |t + ρ.val.im| + |t| := by rw [abs_neg]
    linarith
  have hd₁ : h / 2 ≤ ‖d₁‖ := by
    have hi := Complex.abs_im_le_norm d₁
    have hi' : |t - ρ.val.im| ≤ ‖d₁‖ := by
      simpa [d₁, z] using hi
    exact him₁.trans hi'
  have hd₂ : h / 2 ≤ ‖d₂‖ := by
    have hi := Complex.abs_im_le_norm d₂
    have hi' : |t + ρ.val.im| ≤ ‖d₂‖ := by
      simpa [d₂, z] using hi
    exact him₂.trans hi'
  have hprod : (h / 2) ^ 2 ≤ ‖d₁‖ * ‖d₂‖ := by
    have hm := mul_le_mul hd₁ hd₂ (by positivity) (norm_nonneg d₁)
    nlinarith
  have hnum : ‖2 * z - 1‖ ≤ 2 * c + 1 + 2 * |t| := by
    have hn := Complex.norm_le_abs_re_add_abs_im (2 * z - 1)
    have hcpos : 0 < 2 * c - 1 := by linarith
    calc
      ‖2 * z - 1‖ ≤ |(2 * z - 1).re| + |(2 * z - 1).im| := hn
      _ = |2 * c - 1| + |2 * t| := by simp [z]
      _ = (2 * c - 1) + 2 * |t| := by
        rw [abs_of_pos hcpos]
        simp [abs_mul]
      _ ≤ 2 * c + 1 + 2 * |t| := by linarith
  have hinv :
      (1 : ℝ) / (‖d₁‖ * ‖d₂‖) ≤ 4 / h ^ 2 := by
    have hhalf : 0 < (h / 2) ^ 2 := by positivity
    have h0 := one_div_le_one_div_of_le hhalf hprod
    have heq : (1 : ℝ) / (h / 2) ^ 2 = 4 / h ^ 2 := by
      field_simp [ne_of_gt hpos]
      ring
    exact h0.trans_eq heq
  rw [weil_paired_zero_kernel_eq_quotient_v3 c t ρ hc, norm_div, norm_mul]
  have hm := mul_le_mul hnum hinv (by positivity) (by positivity)
  simpa [z, d₁, d₂, h, div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using hm

private theorem riemannXi_paired_kernel_product_integral_eventually_bound_v3
    (H : ℝ → ℂ) (c : ℝ) (hc : 1 < c)
    (hH : HasVerticalNormMomentsTwoV3 H) :
    ∃ M : ℝ, 0 ≤ M ∧
      ∀ᶠ ρ : LiCriterion.NontrivialZero in cofinite,
        (∫ t : ℝ, ‖WeilPairedZeroKernelV3 c t ρ * H t‖) ≤
          2 * M / ‖ρ.val‖ ^ 2 := by
  classical
  let δ : ℝ := c - 1
  have hδ : 0 < δ := by dsimp [δ]; linarith
  let C : ℝ → ℝ := fun t =>
    4 * (2 * c + 1) * ‖H t‖ +
    8 * (|t| * ‖H t‖) +
    (8 / δ) * (|t| ^ 2 * ‖H t‖)
  have hCint : Integrable C := by
    have hsum :=
      ((hH.1.norm.const_mul (4 * (2 * c + 1))).fun_add
        (hH.2.1.const_mul 8)).fun_add
        (hH.2.2.const_mul (8 / δ))
    simpa only [C] using hsum
  have hCnonneg : ∀ t : ℝ, 0 ≤ C t := by
    intro t
    dsimp [C]
    positivity
  let M : ℝ := ∫ t : ℝ, C t
  have hM : 0 ≤ M := by
    dsimp [M]
    exact integral_nonneg hCnonneg
  refine ⟨M, hM, ?_⟩

  have hgenus :=
    LiCriterion.xi_genus_one_of_hadamard_order_one
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      LiCriterion.XiGrowth.riemannXi_order_le_one
  have hsmall :
      ∀ᶠ ρ : LiCriterion.NontrivialZero in cofinite,
        (1 : ℝ) / ‖ρ.val‖ ^ 2 < (1 / 4 : ℝ) :=
    hgenus.tendsto_cofinite_zero.eventually_lt_const (by norm_num)

  filter_upwards [hsmall] with ρ hρsmall
  have hρnormpos : 0 < ‖ρ.val‖ := norm_pos_iff.mpr ρ.ne_zero
  have hρnorm : 2 < ‖ρ.val‖ := by
    by_contra hnot
    have hle : ‖ρ.val‖ ≤ 2 := le_of_not_gt hnot
    have hinv :
        (1 / 4 : ℝ) ≤ (1 : ℝ) / ‖ρ.val‖ ^ 2 := by
      rw [div_le_div_iff₀ (by norm_num) (sq_pos_of_pos hρnormpos)]
      nlinarith
    exact (not_le_of_gt hρsmall) hinv

  let h : ℝ := |ρ.val.im|
  have hreabs : |ρ.val.re| = ρ.val.re := abs_of_pos ρ.property.2.1
  have hnorm_le : ‖ρ.val‖ ≤ ρ.val.re + h := by
    have hn := Complex.norm_le_abs_re_add_abs_im ρ.val
    simpa [h, hreabs] using hn
  have hh : 1 < h := by
    by_contra hnot
    have hhle : h ≤ 1 := le_of_not_gt hnot
    have : ‖ρ.val‖ < 2 := by
      exact hnorm_le.trans_lt (by linarith [ρ.property.2.2])
    linarith
  have hh1 : 1 ≤ h := le_of_lt hh
  have hpos : 0 < h := zero_lt_one.trans hh

  have hkernel_meas :
      AEStronglyMeasurable
        (fun t : ℝ => WeilPairedZeroKernelV3 c t ρ * H t) := by
    exact
      (weil_paired_zero_kernel_continuous_v3 c ρ hc).aestronglyMeasurable.mul
        hH.1.aestronglyMeasurable

  have hpoint : ∀ t : ℝ,
      ‖WeilPairedZeroKernelV3 c t ρ * H t‖ ≤ C t / h ^ 2 := by
    intro t
    by_cases ht : |t| ≤ h / 2
    · have hk :=
        weil_paired_zero_kernel_central_norm_bound_v3
          c t ρ hc (by simpa [h] using hh1) (by simpa [h] using ht)
      have hmain :
          4 * (2 * c + 1 + 2 * |t|) * ‖H t‖ ≤ C t := by
        have hextra : 0 ≤ (8 / δ) * |t| ^ 2 * ‖H t‖ := by positivity
        dsimp [C]
        nlinarith
      calc
        ‖WeilPairedZeroKernelV3 c t ρ * H t‖
            = ‖WeilPairedZeroKernelV3 c t ρ‖ * ‖H t‖ := norm_mul _ _
        _ ≤ (4 * (2 * c + 1 + 2 * |t|) / h ^ 2) * ‖H t‖ :=
          mul_le_mul_of_nonneg_right (by simpa [h] using hk) (norm_nonneg _)
        _ = (4 * (2 * c + 1 + 2 * |t|) * ‖H t‖) / h ^ 2 := by ring
        _ ≤ C t / h ^ 2 := by
          simp only [div_eq_mul_inv]
          exact mul_le_mul_of_nonneg_right hmain (inv_nonneg.mpr (sq_nonneg h))
    · have ht' : h / 2 < |t| := lt_of_not_ge ht
      have hsq : h ^ 2 ≤ 4 * |t| ^ 2 := by
        have h₁ : 0 ≤ 2 * |t| - h := by linarith [abs_nonneg t]
        have h₂ : 0 ≤ 2 * |t| + h := by positivity
        have hm : 0 ≤ (2 * |t| - h) * (2 * |t| + h) :=
          mul_nonneg h₁ h₂
        nlinarith
      have hk := weil_paired_zero_kernel_global_norm_bound_v3 c t ρ hc
      have hcoef : 0 ≤ (2 / δ) * ‖H t‖ := by positivity
      have htail :
          (2 / δ) * ‖H t‖ ≤
            ((8 / δ) * |t| ^ 2 * ‖H t‖) / h ^ 2 := by
        apply (le_div_iff₀ (sq_pos_of_pos hpos)).2
        have hm := mul_le_mul_of_nonneg_left hsq hcoef
        calc
          (2 / δ) * ‖H t‖ * h ^ 2
              ≤ (2 / δ) * ‖H t‖ * (4 * |t| ^ 2) := hm
          _ = (8 / δ) * |t| ^ 2 * ‖H t‖ := by ring
      have htailC : (8 / δ) * |t| ^ 2 * ‖H t‖ ≤ C t := by
        have h₀ : 0 ≤ 4 * (2 * c + 1) * ‖H t‖ := by positivity
        have h₁ : 0 ≤ 8 * |t| * ‖H t‖ := by positivity
        dsimp [C]
        nlinarith
      calc
        ‖WeilPairedZeroKernelV3 c t ρ * H t‖
            = ‖WeilPairedZeroKernelV3 c t ρ‖ * ‖H t‖ := norm_mul _ _
        _ ≤ (2 / δ) * ‖H t‖ :=
          mul_le_mul_of_nonneg_right (by simpa [δ] using hk) (norm_nonneg _)
        _ ≤ ((8 / δ) * |t| ^ 2 * ‖H t‖) / h ^ 2 := htail
        _ ≤ C t / h ^ 2 := by
          simp only [div_eq_mul_inv]
          exact mul_le_mul_of_nonneg_right htailC (inv_nonneg.mpr (sq_nonneg h))

  have hdomint : Integrable (fun t : ℝ => C t / h ^ 2) := by
    simpa [div_eq_mul_inv, mul_comm] using
      hCint.mul_const ((h ^ 2)⁻¹)
  have hprodint :
      Integrable (fun t : ℝ => WeilPairedZeroKernelV3 c t ρ * H t) :=
    hdomint.mono' hkernel_meas (ae_of_all _ hpoint)
  have hint :
      (∫ t : ℝ, ‖WeilPairedZeroKernelV3 c t ρ * H t‖) ≤
        M / h ^ 2 := by
    calc
      (∫ t : ℝ, ‖WeilPairedZeroKernelV3 c t ρ * H t‖)
          ≤ ∫ t : ℝ, C t / h ^ 2 :=
        integral_mono hprodint.norm hdomint hpoint
      _ = M / h ^ 2 := by
        dsimp [M]
        simp only [div_eq_mul_inv]
        rw [integral_mul_const]

  have hre2 : ρ.val.re ^ 2 ≤ 1 := by
    nlinarith [ρ.property.2.1, ρ.property.2.2]
  have hh2 : 1 ≤ h ^ 2 := by nlinarith
  have hnormsq : ‖ρ.val‖ ^ 2 ≤ 2 * h ^ 2 := by
    rw [Complex.sq_norm, Complex.normSq_apply]
    dsimp [h]
    nlinarith [sq_abs ρ.val.im]
  have hinvrel :
      (1 : ℝ) / h ^ 2 ≤ 2 / ‖ρ.val‖ ^ 2 := by
    exact
      (div_le_div_iff₀ (sq_pos_of_pos hpos) (sq_pos_of_pos hρnormpos)).2
        (by simpa using hnormsq)
  have hscaled : M / h ^ 2 ≤ 2 * M / ‖ρ.val‖ ^ 2 := by
    have hm := mul_le_mul_of_nonneg_left hinvrel hM
    simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using hm
  exact hint.trans hscaled

/-- FZ core: the multiplicity-weighted product-integral family is summable.
This is the exact absolute-convergence certificate needed before exchanging
the zero sum with the fixed-line integral. -/
theorem riemannXi_paired_kernel_product_integral_summable_v3
    (H : ℝ → ℂ) (c : ℝ) (hc : 1 < c)
    (hH : HasVerticalNormMomentsTwoV3 H) :
    Summable (fun ρ : LiCriterion.NontrivialZero =>
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) *
        ∫ t : ℝ, ‖WeilPairedZeroKernelV3 c t ρ * H t‖) := by
  classical
  obtain ⟨M, hM, hbound⟩ :=
    riemannXi_paired_kernel_product_integral_eventually_bound_v3 H c hc hH
  have hweighted :=
    LiCriterion.xi_weighted_genus_one_of_hadamard_order_one
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      LiCriterion.XiGrowth.riemannXi_order_le_one
  have hdom :
      Summable (fun ρ : LiCriterion.NontrivialZero =>
        (2 * M) *
          ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) /
            ‖ρ.val‖ ^ 2)) :=
    hweighted.mul_left (2 * M)
  refine Summable.of_norm_bounded_eventually hdom ?_
  filter_upwards [hbound] with ρ hρ
  have hint_nonneg :
      0 ≤ ∫ t : ℝ, ‖WeilPairedZeroKernelV3 c t ρ * H t‖ :=
    integral_nonneg (fun t => norm_nonneg _)
  have hmul_nonneg :
      0 ≤ (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) *
        ∫ t : ℝ, ‖WeilPairedZeroKernelV3 c t ρ * H t‖ :=
    mul_nonneg (Nat.cast_nonneg _) hint_nonneg
  rw [Real.norm_eq_abs, abs_of_nonneg hmul_nonneg]
  have hm :=
    mul_le_mul_of_nonneg_left hρ
      (Nat.cast_nonneg (analyticOrderNatAt LiCriterion.riemannXi ρ.val))
  simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using hm

end

#print axioms weil_paired_zero_kernel_eq_quotient_v3
#print axioms riemannXi_paired_kernel_product_integral_summable_v3
~~~~~~

## WeilPairedHadamardKernelTsumV2

Path: `source/WeilPairedHadamardKernelTsumV2.lean`

Original source lines: 1–165

Full file SHA256: `4388bc88b3369b85869ea4c5187fc80e6abebfabc1bd4ec1fbf7a5551008a2c4`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPairedHadamardKernelTsumV2.lean

~~~~~~lean
import WeilPairedHadamardFixedLineV1
import Mathlib.Tactic

/-!
AEGIS Ω — fused multiplicity-aware paired Hadamard kernel tsum v2.

#519 proves the fixed-line Hadamard identity as the difference of two
multiplicity-weighted tsums.  This module supplies the missing summability
evidence for each weighted genus-one term family, combines them by subtraction,
and then uses the already verified pointwise partial-fraction identity to fuse
that difference into one paired-kernel tsum.

No zero-sum / fixed-line-integral interchange is performed here.  In
particular, the Fubini estimate from the mathematical #490 proof remains a
separate obligation.  No arithmetic sign inequality or RH claim is asserted.
-/

open Complex
open scoped BigOperators

set_option autoImplicit false

noncomputable section

/-- A single multiplicity-weighted genus-one Hadamard term family is genuinely
summable away from the nontrivial zeros.  The proof expands multiplicity into
the provider's sigma carrier, applies its summable log-derivative theorem, and
then regroups the finite multiplicity fibres. -/
theorem riemannXi_weighted_hadamard_term_summable_v2
    (s : ℂ)
    (hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val) :
    Summable (fun ρ : LiCriterion.NontrivialZero =>
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (s / (ρ.val * (s - ρ.val)))) := by
  classical
  have hgenus :=
    LiCriterion.xi_weighted_genus_one_of_hadamard_order_one
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      LiCriterion.XiGrowth.riemannXi_order_le_one
  have hsigma_genus :=
    LiCriterion.summable_inv_norm_sq_zeros_with_multiplicity_of_weighted_genus
      hgenus
  have hsigma_log :
      Summable (fun i : LiCriterion.XiZeroWithMultiplicity =>
        _root_.logDeriv
          (fun w : ℂ => Hadamard.weierstrass_E 1 (w / i.1.val)) s) := by
    exact
      Hadamard.OrderOne.summable_logDeriv_weierstrass_E_one_div_of_summable_inv_norm_sq
        (z := fun i : LiCriterion.XiZeroWithMultiplicity => i.1.val)
        (fun i => i.1.ne_zero) hsigma_genus s (fun i => hs i.1)
  have hsigma_term :
      Summable (fun i : LiCriterion.XiZeroWithMultiplicity =>
        s / (i.1.val * (s - i.1.val))) := by
    refine hsigma_log.congr ?_
    intro i
    exact
      Hadamard.OrderOne.logDeriv_weierstrass_E_one_div
        (a := i.1.val) (x := s) i.1.ne_zero (hs i.1)
  have hweighted :
      HasSum
        (fun ρ : LiCriterion.NontrivialZero =>
          ∑' _k : Fin (analyticOrderNatAt LiCriterion.riemannXi ρ.val),
            s / (ρ.val * (s - ρ.val)))
        (∑' i : LiCriterion.XiZeroWithMultiplicity,
          s / (i.1.val * (s - i.1.val))) := by
    simpa [LiCriterion.XiZeroWithMultiplicity] using
      hsigma_term.hasSum.sigma
        (fun ρ =>
          hasSum_fintype
            (fun _k : Fin (analyticOrderNatAt LiCriterion.riemannXi ρ.val) =>
              s / (ρ.val * (s - ρ.val))))
  refine hweighted.summable.congr ?_
  intro ρ
  calc
    (∑' _k : Fin (analyticOrderNatAt LiCriterion.riemannXi ρ.val),
        s / (ρ.val * (s - ρ.val)))
        =
      ∑ _k : Fin (analyticOrderNatAt LiCriterion.riemannXi ρ.val),
        s / (ρ.val * (s - ρ.val)) := by
          simp
    _ =
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (s / (ρ.val * (s - ρ.val))) := by
          simp [Finset.card_univ, nsmul_eq_mul]

/-- The multiplicity-weighted paired partial-fraction kernel is summable.
This is the load-bearing legality required before fusing the two totalized
tsums from #519. -/
theorem riemannXi_paired_hadamard_kernel_summable_v2
    (s : ℂ)
    (hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val)
    (h1s : ∀ ρ : LiCriterion.NontrivialZero, 1 - s ≠ ρ.val) :
    Summable (fun ρ : LiCriterion.NontrivialZero =>
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val)))) := by
  have hleft := riemannXi_weighted_hadamard_term_summable_v2 s hs
  have hright :=
    riemannXi_weighted_hadamard_term_summable_v2 (1 - s) h1s
  refine (hleft.sub hright).congr ?_
  intro ρ
  calc
    (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          (s / (ρ.val * (s - ρ.val))) -
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          ((1 - s) / (ρ.val * ((1 - s) - ρ.val)))
        =
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (s / (ρ.val * (s - ρ.val)) -
          (1 - s) / (ρ.val * ((1 - s) - ρ.val))) := by
            ring
    _ =
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val))) := by
          rw [paired_hadamard_partial_fraction_v1
            s ρ.val ρ.ne_zero (hs ρ) (h1s ρ)]

/-- Fuse #519's difference of two individually summable Hadamard tsums into
one multiplicity-weighted paired-kernel tsum. -/
theorem riemannXi_paired_hadamard_kernel_tsum_v2
    (s : ℂ)
    (hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val)
    (h1s : ∀ ρ : LiCriterion.NontrivialZero, 1 - s ≠ ρ.val) :
    2 * _root_.logDeriv LiCriterion.riemannXi s =
      ∑' ρ : LiCriterion.NontrivialZero,
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val))) := by
  have hleft := riemannXi_weighted_hadamard_term_summable_v2 s hs
  have hright :=
    riemannXi_weighted_hadamard_term_summable_v2 (1 - s) h1s
  have hdiff := riemannXi_paired_hadamard_difference_v1 s hs h1s
  rw [← hleft.tsum_sub hright] at hdiff
  calc
    2 * _root_.logDeriv LiCriterion.riemannXi s =
        ∑' ρ : LiCriterion.NontrivialZero,
          ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
              (s / (ρ.val * (s - ρ.val))) -
            (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
              ((1 - s) / (ρ.val * ((1 - s) - ρ.val)))) := hdiff
    _ =
        ∑' ρ : LiCriterion.NontrivialZero,
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val))) := by
      apply tsum_congr
      intro ρ
      calc
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
              (s / (ρ.val * (s - ρ.val))) -
            (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
              ((1 - s) / (ρ.val * ((1 - s) - ρ.val)))
            =
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            (s / (ρ.val * (s - ρ.val)) -
              (1 - s) / (ρ.val * ((1 - s) - ρ.val))) := by
                ring
        _ =
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val))) := by
              rw [paired_hadamard_partial_fraction_v1
                s ρ.val ρ.ne_zero (hs ρ) (h1s ρ)]

end

#print axioms riemannXi_weighted_hadamard_term_summable_v2
#print axioms riemannXi_paired_hadamard_kernel_summable_v2
#print axioms riemannXi_paired_hadamard_kernel_tsum_v2
~~~~~~

## WeilPairedHadamardFixedLineV1

Path: `source/WeilPairedHadamardFixedLineV1.lean`

Original source lines: 1–197

Full file SHA256: `1eaea8c2d9647861a1a0271c89695cbbd852976623b7596ff8459c776ba28eff`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPairedHadamardFixedLineV1.lean

~~~~~~lean
import WeilFixedLineExplicitFormulaContractV2
import Lc.LiCriterion.HadamardBridge
import Lc.LiCriterion.XiGrowth
import Lc.LiCriterion.HadamardSummabilityBridge
import Hadamard.OrderOne.LogDerivMultiplicity
import Mathlib.Tactic

/-!
AEGIS Ω — paired Hadamard fixed-line zero kernel v1.

This module composes the existing multiplicity-aware genus-one provider with
`riemannXi`'s functional equation on the same Lean 4.33.1 / Mathlib pin used by
#488/#490/#493/#507/#511.

It deliberately stops at the difference of two individually controlled
Hadamard log-derivative sums.  It does not fuse that difference into one
paired-kernel `tsum`, does not prove the normalized explicit formula, and does
not prove the arithmetic sign inequality or RH.
-/

open Complex Filter Topology
open scoped BigOperators

set_option autoImplicit false

noncomputable section

private theorem riemannXi_ne_zero_of_avoids_nontrivial_zeros_v1
    (s : ℂ) (hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val) :
    LiCriterion.riemannXi s ≠ 0 := by
  intro hzero
  obtain ⟨ρ, hρ⟩ := (LiCriterion.xi_zeros_are_nontrivial_zeros (s := s)).mp hzero
  exact hs ρ hρ

/-- Multiplicity-aware Hadamard log derivative of the completed zeta function.
The constant `A` is the linear exponential coefficient in the genus-one
factorization. -/
theorem riemannXi_hadamard_logDeriv_with_multiplicity_v1 :
    ∃ A : ℂ, ∀ s : ℂ,
      (∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val) →
      _root_.logDeriv LiCriterion.riemannXi s =
        A + ∑' ρ : LiCriterion.NontrivialZero,
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            (s / (ρ.val * (s - ρ.val))) := by
  obtain ⟨A, B, hfac⟩ :=
    LiCriterion.xi_hadamard_factorization_with_multiplicity
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      LiCriterion.XiGrowth.riemannXi_order_le_one
  refine ⟨A, ?_⟩
  intro s hs
  let P : ℂ → ℂ := LiCriterion.xiMultiplicityE1Prod
  have hsum :=
    LiCriterion.xi_weighted_genus_one_of_hadamard_order_one
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      LiCriterion.XiGrowth.riemannXi_order_le_one
  have hP_explicit :
      P = fun w : ℂ =>
        ∏' j : Hadamard.OrderOne.WithMultiplicity
            LiCriterion.NontrivialZero
            (fun ρ => analyticOrderNatAt LiCriterion.riemannXi ρ.val),
          Hadamard.weierstrass_E 1 (w / j.1.val) := by
    funext w
    calc
      P w = LiCriterion.xiMultiplicityE1Prod w := rfl
      _ = LiCriterion.xiE1ProdWithMultiplicity w :=
        LiCriterion.xiMultiplicityE1Prod_eq_xiE1ProdWithMultiplicity w
      _ = (∏' j : Hadamard.OrderOne.WithMultiplicity
              LiCriterion.NontrivialZero
              (fun ρ => analyticOrderNatAt LiCriterion.riemannXi ρ.val),
            Hadamard.weierstrass_E 1 (w / j.1.val)) := rfl
  have hlogP :
      _root_.logDeriv P s =
        ∑' ρ : LiCriterion.NontrivialZero,
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            (s / (ρ.val * (s - ρ.val))) := by
    rw [hP_explicit]
    exact
      Hadamard.OrderOne.logDeriv_tprod_weierstrass_E_one_eq_tsum_of_summable_mul_inv_norm_sq
        (z := fun ρ : LiCriterion.NontrivialZero => ρ.val)
        (m := fun ρ : LiCriterion.NontrivialZero =>
          analyticOrderNatAt LiCriterion.riemannXi ρ.val)
        (fun ρ => ρ.ne_zero) hsum s hs
  have hxi_ne : LiCriterion.riemannXi s ≠ 0 :=
    riemannXi_ne_zero_of_avoids_nontrivial_zeros_v1 s hs
  have hP_ne : P s ≠ 0 := by
    intro hP
    apply hxi_ne
    calc
      LiCriterion.riemannXi s = Complex.exp (A * s + B) * P s := by
        simpa [P] using hfac s
      _ = 0 := by rw [hP, mul_zero]
  have hP_eq :
      P = fun w : ℂ => LiCriterion.riemannXi w / Complex.exp (A * w + B) := by
    funext w
    apply (eq_div_iff (Complex.exp_ne_zero (A * w + B))).2
    rw [hfac w]
    ring
  have hP_diff : Differentiable ℂ P := by
    rw [hP_eq]
    exact LiCriterion.xi_entire.div (by fun_prop)
      (fun w => Complex.exp_ne_zero (A * w + B))
  have hexp_log :
      _root_.logDeriv (fun w : ℂ => Complex.exp (A * w + B)) s = A := by
    rw [_root_.logDeriv_apply, deriv_cexp (by fun_prop)]
    simp
  have hfun :
      LiCriterion.riemannXi =
        fun w : ℂ => Complex.exp (A * w + B) * P w := by
    funext w
    simpa [P] using hfac w
  have hmul :
      _root_.logDeriv LiCriterion.riemannXi s =
        _root_.logDeriv (fun w : ℂ => Complex.exp (A * w + B)) s +
          _root_.logDeriv P s := by
    rw [hfun]
    exact _root_.logDeriv_mul s
      (Complex.exp_ne_zero (A * s + B)) hP_ne
      (by fun_prop) hP_diff.differentiableAt
  calc
    _root_.logDeriv LiCriterion.riemannXi s
        = _root_.logDeriv (fun w : ℂ => Complex.exp (A * w + B)) s +
            _root_.logDeriv P s := hmul
    _ = A + ∑' ρ : LiCriterion.NontrivialZero,
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            (s / (ρ.val * (s - ρ.val))) := by
          rw [hexp_log, hlogP]

/-- The functional equation `ξ(s)=ξ(1-s)` makes the logarithmic derivative
antisymmetric under `s ↦ 1-s`.  Nonvanishing hypotheses keep the statement on
the intended off-zero surface. -/
theorem riemannXi_logDeriv_one_sub_v1 (s : ℂ)
    (hs : LiCriterion.riemannXi s ≠ 0)
    (h1s : LiCriterion.riemannXi (1 - s) ≠ 0) :
    _root_.logDeriv LiCriterion.riemannXi (1 - s) =
      - _root_.logDeriv LiCriterion.riemannXi s := by
  have hcomp := _root_.logDeriv_comp
    (f := LiCriterion.riemannXi)
    (g := fun z : ℂ => 1 - z)
    (x := s)
    LiCriterion.xi_entire.differentiableAt
    (by fun_prop)
  have hfun :
      (LiCriterion.riemannXi ∘ fun z : ℂ => 1 - z) =
        LiCriterion.riemannXi := by
    funext z
    exact (LiCriterion.xi_functional_equation z).symm
  rw [hfun] at hcomp
  simp at hcomp
  calc
    _root_.logDeriv LiCriterion.riemannXi (1 - s)
        = -(- _root_.logDeriv LiCriterion.riemannXi (1 - s)) := by ring
    _ = - _root_.logDeriv LiCriterion.riemannXi s := by rw [hcomp]

/-- Algebraic cancellation of the genus-one correction terms when the two
Hadamard logarithmic derivatives at `s` and `1-s` are subtracted. -/
theorem paired_hadamard_partial_fraction_v1
    (s ρ : ℂ) (hρ0 : ρ ≠ 0) (hsρ : s ≠ ρ) (h1sρ : 1 - s ≠ ρ) :
    s / (ρ * (s - ρ)) -
        (1 - s) / (ρ * ((1 - s) - ρ)) =
      1 / (s - ρ) + 1 / (s - (1 - ρ)) := by
  have hs_pair : s ≠ 1 - ρ := by
    intro h
    apply h1sρ
    rw [h]
    ring
  field_simp [hρ0, sub_ne_zero.mpr hsρ, sub_ne_zero.mpr h1sρ,
    sub_ne_zero.mpr hs_pair]
  ring

/-- Paired fixed-line Hadamard difference.  The linear exponential coefficient
cancels after the `ξ(s)=ξ(1-s)` log-derivative antisymmetry.  This theorem
intentionally leaves the two absolutely controlled `tsum`s separate. -/
theorem riemannXi_paired_hadamard_difference_v1 (s : ℂ)
    (hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val)
    (h1s : ∀ ρ : LiCriterion.NontrivialZero, 1 - s ≠ ρ.val) :
    2 * _root_.logDeriv LiCriterion.riemannXi s =
      (∑' ρ : LiCriterion.NontrivialZero,
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          (s / (ρ.val * (s - ρ.val)))) -
      (∑' ρ : LiCriterion.NontrivialZero,
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          ((1 - s) / (ρ.val * ((1 - s) - ρ.val)))) := by
  obtain ⟨A, hA⟩ := riemannXi_hadamard_logDeriv_with_multiplicity_v1
  have hsA := hA s hs
  have h1sA := hA (1 - s) h1s
  have hs_ne := riemannXi_ne_zero_of_avoids_nontrivial_zeros_v1 s hs
  have h1s_ne := riemannXi_ne_zero_of_avoids_nontrivial_zeros_v1 (1 - s) h1s
  have hsym := riemannXi_logDeriv_one_sub_v1 s hs_ne h1s_ne
  rw [hsym] at h1sA
  linear_combination hsA - h1sA

end

#print axioms riemannXi_hadamard_logDeriv_with_multiplicity_v1
#print axioms riemannXi_logDeriv_one_sub_v1
#print axioms paired_hadamard_partial_fraction_v1
#print axioms riemannXi_paired_hadamard_difference_v1
~~~~~~

## WeilFixedLineExplicitFormulaContractV2

Path: `source/WeilFixedLineExplicitFormulaContractV2.lean`

Original source lines: 1–116

Full file SHA256: `3b6bcd3d4ae4b73be3f420d4284401a98c6236df0c58ad647a0028e9968ab84f`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineExplicitFormulaContractV2.lean

~~~~~~lean
import ZeroCountingMellinSummabilityV1
import WeilPrimeLineIdentityV1
import WeilAutocorrelationPoleAggregationV1
import WeilPoleTermV1

/-!
AEGIS Ω — corrected fixed-line integration contract for the RH explicit-formula lane.

The adopted #490 proof is a paired-Hadamard / Fubini argument on a fixed line
`c > 1`.  It does not move a rectangle across the critical strip and therefore
has no horizontal-segment-vanishing obligation.

This module binds four already proved surfaces to the actual autocorrelation:
* multiplicity-safe absolute zero summability from #488;
* compact-smooth autocorrelation closure and RHS convergence from #493;
* the fixed-line von-Mangoldt prime identity from #490;
* endpoint aggregation from #507, together with the zeta pole theorem ported
  to the same Lean/Mathlib pin.

It is a readiness/integration theorem only.  It does NOT prove the remaining
paired-Hadamard whole explicit-formula identity, the arithmetic sign, global
Weil positivity, or RH.
-/

open Set Filter Topology MeasureTheory Complex

set_option autoImplicit false

noncomputable section

/-- The actual autocorrelation inherits the multiplicity-weighted absolutely
convergent nontrivial-zero series from the compact-smooth closure theorem. -/
theorem weil_autocorrelation_zero_residue_summable_v2 (g : WeilCompactSmoothGV1) :
    Summable (WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g)) := by
  change Summable
    (WeilZeroIndexSummandV1 (WeilAutocorrelationCompactSmoothV1 g).1)
  exact weil_compact_smooth_zero_summable_v1 (WeilAutocorrelationCompactSmoothV1 g)

/-- Absolute norm summability is retained, so this is stronger than merely
choosing a symmetric-height summation prescription. -/
theorem weil_autocorrelation_zero_residue_norm_summable_v2 (g : WeilCompactSmoothGV1) :
    Summable (fun rho => ‖WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho‖) := by
  change Summable
    (fun rho => ‖WeilZeroIndexSummandV1 (WeilAutocorrelationCompactSmoothV1 g).1 rho‖)
  exact weil_compact_smooth_zero_norm_summable_v1 (WeilAutocorrelationCompactSmoothV1 g)

/-- The existing fixed-line prime identity applies directly to the actual
autocorrelation after #493 repackages it in the compact-smooth class. -/
theorem weil_autocorrelation_prime_line_identity_v2
    (g : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    (1 / (2 * Real.pi) : ℝ) •
        (∫ t : ℝ, (-deriv riemannZeta ((c : ℂ) + t * I) /
          riemannZeta ((c : ℂ) + t * I)) *
          mellin (WeilAutocorrelationV1 g) ((c : ℂ) + t * I)) =
      ∑' n : ℕ, (ArithmeticFunction.vonMangoldt n : ℂ) *
        WeilAutocorrelationV1 g (n : ℝ) := by
  change (1 / (2 * Real.pi) : ℝ) •
        (∫ t : ℝ, (-deriv riemannZeta ((c : ℂ) + t * I) /
          riemannZeta ((c : ℂ) + t * I)) *
          mellin (WeilAutocorrelationCompactSmoothV1 g).1 ((c : ℂ) + t * I)) =
      ∑' n : ℕ, (ArithmeticFunction.vonMangoldt n : ℂ) *
        (WeilAutocorrelationCompactSmoothV1 g).1 (n : ℝ)
  exact weil_compact_smooth_prime_line_identity_v1
    (WeilAutocorrelationCompactSmoothV1 g) c hc

/-- The finite collection of kernel-proved prerequisites that the fixed-line
paired-Hadamard assembly may consume.  Deliberately absent: any moving-contour
or horizontal-segment hypothesis. -/
structure WeilAutocorrelationFixedLineReadinessV2 (g : WeilCompactSmoothGV1) : Prop where
  zero_side_summable :
    Summable (WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g))
  zero_side_norm_summable :
    Summable (fun rho => ‖WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho‖)
  rhs_convergent :
    WeilExplicitRightSideConvergentV1 (WeilAutocorrelationV1 g)
  endpoint_pole_aggregate :
    mellin (WeilAutocorrelationV1 g) 0 +
        mellin (WeilAutocorrelationV1 g) 1 =
      WeilEndpointPoleAggregateV1 (mellin g.1 0) (mellin g.1 1)
  prime_line_identity :
    ∀ (c : ℝ), 1 < c →
      (1 / (2 * Real.pi) : ℝ) •
          (∫ t : ℝ, (-deriv riemannZeta ((c : ℂ) + t * I) /
            riemannZeta ((c : ℂ) + t * I)) *
            mellin (WeilAutocorrelationV1 g) ((c : ℂ) + t * I)) =
        ∑' n : ℕ, (ArithmeticFunction.vonMangoldt n : ℂ) *
          WeilAutocorrelationV1 g (n : ℝ)

/-- All corrected fixed-line prerequisites are already theorem consequences on
this carrier; no contour-shift assumption is introduced. -/
theorem weil_autocorrelation_fixed_line_readiness_v2
    (g : WeilCompactSmoothGV1) : WeilAutocorrelationFixedLineReadinessV2 g := by
  refine ⟨
    weil_autocorrelation_zero_residue_summable_v2 g,
    weil_autocorrelation_zero_residue_norm_summable_v2 g,
    weil_autocorrelation_explicit_right_side_convergent_v1 g,
    weil_autocorrelation_pole_term_eq_endpoint_aggregate_v1 g,
    ?_⟩
  intro c hc
  exact weil_autocorrelation_prime_line_identity_v2 g c hc

/-- With the repository's two moment conditions, the same readiness package is
available and the actual autocorrelation pole aggregate vanishes. -/
theorem weil_autocorrelation_fixed_line_readiness_of_moments_v2
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g) :
    WeilAutocorrelationFixedLineReadinessV2 g ∧
      mellin (WeilAutocorrelationV1 g) 0 +
        mellin (WeilAutocorrelationV1 g) 1 = 0 := by
  exact ⟨weil_autocorrelation_fixed_line_readiness_v2 g,
    weil_moment_conditions_autocorrelation_pole_term_zero_v1 g hm⟩

#print axioms weil_autocorrelation_zero_residue_summable_v2
#print axioms weil_autocorrelation_zero_residue_norm_summable_v2
#print axioms weil_autocorrelation_prime_line_identity_v2
#print axioms weil_autocorrelation_fixed_line_readiness_v2
#print axioms weil_autocorrelation_fixed_line_readiness_of_moments_v2
~~~~~~

## ZeroCountingMellinSummabilityV1

Path: `source/ZeroCountingMellinSummabilityV1.lean`

Original source lines: 1–152

Full file SHA256: `6cf6b91301d4cf40472818470b3fff8cd9e1a03469a111a6d9f6b76456538a08`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroCountingMellinSummabilityV1.lean

~~~~~~lean
import ZeroCountingBoundV1
import MellinDecayEstimateV1

/-!
AEGIS Ω — multiplicity-safe Mellin summability and canonical height limit.

The pinned Hadamard provider already proves multiplicity-weighted inverse-square
summability for xi from its order-at-most-one growth. Transferring multiplicity
to zeta and using the critical strip gives a shorter route than reimplementing
dyadic counting. Uniform quadratic Mellin decay is sufficient; the existing
compact-smooth cubic theorem supplies it.

This establishes an absolutely convergent zero functional on the existing
compact-smooth domain and identifies its symmetric-height limit. It supplies
neither the preregistered linear shell bound, the explicit formula, positivity,
nor RH. No simple-zero assumption is made.
-/

open Set Filter Topology
open Complex

noncomputable section

/-- Reusable comparison lemma: weighted inverse-square summability and a
bounded-width strip turn quadratic height decay into absolute summability.
The nonzero premise prevents division by the totalized value at zero. -/
theorem weighted_summable_of_inverse_square_and_height_decay_v1
    {ι : Type*} (z : ι → ℂ) (m : ι → ℕ) (F : ι → ℂ)
    (hzero : ∀ i, z i ≠ 0)
    (hstrip : ∀ i, |(z i).re| ≤ 1)
    (hsum : Summable (fun i => (m i : ℝ) / ‖z i‖ ^ 2))
    {D : ℝ}
    (hdecay : ∀ i, (1 + |(z i).im|) ^ 2 * ‖F i‖ ≤ D) :
    Summable (fun i => (m i : ℂ) * F i) := by
  apply Summable.of_norm_bounded (hsum.mul_left D)
  intro i
  have hn : 0 < ‖z i‖ := norm_pos_iff.mpr (hzero i)
  have hgeom : ‖z i‖ ≤ 1 + |(z i).im| :=
    (Complex.norm_le_abs_re_add_abs_im (z i)).trans
      (add_le_add (hstrip i) le_rfl)
  have hscaled : ‖z i‖ ^ 2 * ‖F i‖ ≤ D := by
    calc
      ‖z i‖ ^ 2 * ‖F i‖ ≤ (1 + |(z i).im|) ^ 2 * ‖F i‖ := by
        gcongr
      _ ≤ D := hdecay i
  have hF : ‖F i‖ ≤ D / ‖z i‖ ^ 2 :=
    (le_div_iff₀' (pow_pos hn 2)).2 hscaled
  calc
    ‖(m i : ℂ) * F i‖ = (m i : ℝ) * ‖F i‖ := by simp
    _ ≤ (m i : ℝ) * (D / ‖z i‖ ^ 2) := by gcongr
    _ = D * ((m i : ℝ) / ‖z i‖ ^ 2) := by ring

/-- Canonical injection into the independently pinned xi provider's carrier.
The AEGIS zero definition is retained throughout the public result. -/
private def nontrivial_index_to_li_v1 :
    RiemannNontrivialZeroIndexV2 ↪ LiCriterion.NontrivialZero where
  toFun rho := by
    have hstrip :=
      riemann_zeta_nontrivial_zero_critical_strip_v1 rho.2.1 rho.2.2
    exact ⟨rho.1, rho.2.1, hstrip.1, hstrip.2⟩
  inj' := by
    intro rho sigma h
    exact Subtype.ext (congrArg (fun z : LiCriterion.NontrivialZero => z.1) h)

/-- Multiplicity-weighted inverse-square summability transferred from xi to
the existing AEGIS nontrivial-zeta-zero carrier. -/
theorem riemann_zeta_weighted_inverse_square_summable_v1 :
    Summable (fun rho : RiemannNontrivialZeroIndexV2 =>
      (analyticOrderNatAt riemannZeta rho.1 : ℝ) / ‖rho.1‖ ^ 2) := by
  have hxi := LiCriterion.xi_weighted_genus_one_of_hadamard_order_one
    LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
    LiCriterion.XiGrowth.riemannXi_order_le_one
  have hpull := hxi.comp_injective nontrivial_index_to_li_v1.injective
  change Summable (fun rho : RiemannNontrivialZeroIndexV2 =>
    (analyticOrderNatAt LiCriterion.riemannXi rho.1 : ℝ) / ‖rho.1‖ ^ 2) at hpull
  have hmult : ∀ rho : RiemannNontrivialZeroIndexV2,
      analyticOrderNatAt LiCriterion.riemannXi rho.1 =
        analyticOrderNatAt riemannZeta rho.1 := by
    intro rho
    exact li_xi_zeta_multiplicity_eq_v1 (nontrivial_index_to_li_v1 rho)
  simpa only [hmult] using hpull

/-- A supplied uniform quadratic Mellin estimate suffices on the canonical
zero carrier. The inverse-square provider is stronger than a bare quadratic
cumulative count and is explicitly used in this theorem. -/
theorem zero_summable_of_uniform_mellin_quadratic_decay_v1
    {f : ℝ → ℂ} {D : ℝ}
    (hdecay : ∀ rho : RiemannNontrivialZeroIndexV2,
      (1 + |rho.1.im|) ^ 2 * ‖mellin f rho.1‖ ≤ D) :
    Summable (WeilZeroIndexSummandV1 f) := by
  apply weighted_summable_of_inverse_square_and_height_decay_v1
    (fun rho : RiemannNontrivialZeroIndexV2 => rho.1)
    (fun rho => analyticOrderNatAt riemannZeta rho.1)
    (fun rho => mellin f rho.1)
    _ _ riemann_zeta_weighted_inverse_square_summable_v1 hdecay
  · intro rho hzero
    have hs := riemann_zeta_nontrivial_zero_critical_strip_v1 rho.2.1 rho.2.2
    rw [hzero] at hs
    norm_num at hs
  · intro rho
    have hs := riemann_zeta_nontrivial_zero_critical_strip_v1 rho.2.1 rho.2.2
    rw [abs_of_pos hs.1]
    exact hs.2.le

/-- Actual compact-smooth Mellin zero summability, with multiplicities. -/
theorem weil_compact_smooth_zero_summable_v1 (g : WeilCompactSmoothGV1) :
    Summable (WeilZeroIndexSummandV1 g.1) := by
  obtain ⟨D, hD, hdecay⟩ :=
    weil_compact_smooth_mellin_vertical_cubic_decay_v1 g
  apply zero_summable_of_uniform_mellin_quadratic_decay_v1 (D := D)
  intro rho
  have hs := riemann_zeta_nontrivial_zero_critical_strip_v1 rho.2.1 rho.2.2
  have hd := hdecay rho.1.re ⟨hs.1.le, hs.2.le⟩ rho.1.im
  have hz : ((rho.1.re : ℂ) + (rho.1.im : ℂ) * Complex.I) = rho.1 := by
    apply Complex.ext <;> simp
  rw [hz] at hd
  have ht : 1 ≤ 1 + |rho.1.im| := by linarith [abs_nonneg rho.1.im]
  have hp : (1 + |rho.1.im|) ^ 2 ≤ (1 + |rho.1.im|) ^ 3 := by
    calc
      (1 + |rho.1.im|) ^ 2 ≤ (1 + |rho.1.im|) ^ 2 * (1 + |rho.1.im|) :=
        le_mul_of_one_le_right (sq_nonneg _) ht
      _ = (1 + |rho.1.im|) ^ 3 := by ring
  exact (mul_le_mul_of_nonneg_right hp (norm_nonneg _)).trans hd

/-- The zero series is absolutely convergent, rather than merely having a
chosen symmetric summation prescription. -/
theorem weil_compact_smooth_zero_norm_summable_v1 (g : WeilCompactSmoothGV1) :
    Summable (fun rho => ‖WeilZeroIndexSummandV1 g.1 rho‖) :=
  (weil_compact_smooth_zero_summable_v1 g).norm

/-- The existing finite symmetric-height expression converges to the canonical
unordered sum on the compact-smooth domain. -/
theorem weil_compact_smooth_height_limit_tsum_v1 (g : WeilCompactSmoothGV1) :
    HasWeilZeroHeightLimitV1 g.1
      (∑' rho, WeilZeroIndexSummandV1 g.1 rho) :=
  hasSum_implies_height_limit_v1 (weil_compact_smooth_zero_summable_v1 g).hasSum

/-- Any previously supplied symmetric-height limit on this domain is the
canonical absolutely convergent zero sum. -/
theorem weil_compact_smooth_height_limit_eq_tsum_v1
    (g : WeilCompactSmoothGV1) {L : ℂ}
    (hL : HasWeilZeroHeightLimitV1 g.1 L) :
    L = ∑' rho, WeilZeroIndexSummandV1 g.1 rho :=
  weil_zero_height_limit_unique_v1 hL (weil_compact_smooth_height_limit_tsum_v1 g)

#print axioms weighted_summable_of_inverse_square_and_height_decay_v1
#print axioms riemann_zeta_weighted_inverse_square_summable_v1
#print axioms zero_summable_of_uniform_mellin_quadratic_decay_v1
#print axioms weil_compact_smooth_zero_summable_v1
#print axioms weil_compact_smooth_zero_norm_summable_v1
#print axioms weil_compact_smooth_height_limit_tsum_v1
#print axioms weil_compact_smooth_height_limit_eq_tsum_v1
~~~~~~

## ZeroCountingBoundV1

Path: `source/ZeroCountingBoundV1.lean`

Original source lines: 1–383

Full file SHA256: `3e24ee3f14d8ff7d358d0243996a1b88f6ea96cbf69225ff00356d0a549e55e5`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroCountingBoundV1.lean

~~~~~~lean
import ZeroShellAnalyticSynthesisV1
import Lc.LiCriterion.HadamardSummabilityBridge
import Lc.LiCriterion.XiGrowth
import Hadamard.OrderOne.TailEstimates
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Topology.Algebra.InfiniteSum.Order

/-!
AEGIS Ω — multiplicity-aware quantitative zero counting v1.

This lane is RH-independent. It reuses the canonical AEGIS nontrivial-zero
carrier and analytic-order multiplicity, while pinning an independently
compiled Jensen/Hadamard provider for the entire Riemann xi function.

The quantitative route is deliberately coarse but sufficient downstream:

* xi and zeta analytic multiplicities agree at every nontrivial zero;
* the provider's order-`≤ 1` Jensen/Hadamard theorem gives cumulative
  multiplicity `O(r^2)` by choosing `ε = 1`;
* every AEGIS height shell `ceil |Im ρ| = n` lies in the centered norm ball
  of radius `n + 1`;
* finitely many radii below the provider threshold are absorbed into one
  explicit finite-prefix constant.

Thus the canonical AEGIS shell multiplicity mass is bounded by
`A * (n + 1)^2` without assuming the Riemann Hypothesis.

ZERO_COUNTING_QUADRATIC_BOUND_V1
RH_INDEPENDENT_ZERO_COUNTING
CRITICAL_LINE_RE_HALF_OPEN
EXPLICIT_FORMULA_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Filter Topology
open Complex

noncomputable section

/-- A deliberately coarse but sufficient shell-counting certificate. The
quadratic exponent is paired downstream with quartic Mellin decay to recover
the existing quadratic shell-mass certificate. -/
def HasQuadraticShellMultiplicityBoundV1 : Prop :=
  ∃ A : ℝ, 0 ≤ A ∧
    ∀ n : ℕ,
      ZeroHeightShellMultiplicityMassV1 n ≤
        A * (((n : ℝ) + 1) ^ 2)

private theorem li_nontrivial_zero_ne_zero_v1
    (rho : LiCriterion.NontrivialZero) : rho.1 ≠ 0 := by
  intro h
  have hre := rho.2.2.1
  rw [h] at hre
  norm_num at hre

private theorem li_nontrivial_zero_ne_one_v1
    (rho : LiCriterion.NontrivialZero) : rho.1 ≠ 1 := by
  intro h
  have hre := rho.2.2.2
  rw [h] at hre
  norm_num at hre

private theorem li_analyticAt_completedRiemannZeta_v1
    (rho : LiCriterion.NontrivialZero) :
    AnalyticAt ℂ completedRiemannZeta rho.1 := by
  let U : Set ℂ := {0}ᶜ ∩ {1}ᶜ
  have hUopen : IsOpen U := isOpen_compl_singleton.inter isOpen_compl_singleton
  have hrhoU : rho.1 ∈ U := by
    exact ⟨by simpa using li_nontrivial_zero_ne_zero_v1 rho,
      by simpa using li_nontrivial_zero_ne_one_v1 rho⟩
  apply DifferentiableOn.analyticAt (s := U) _ (hUopen.mem_nhds hrhoU)
  intro z hz
  exact (differentiableAt_completedZeta
    (by simpa [U] using hz.1) (by simpa [U] using hz.2)).differentiableWithinAt

private theorem li_analyticOrderAt_zeta_eq_completed_v1
    (rho : LiCriterion.NontrivialZero) :
    analyticOrderAt riemannZeta rho.1 =
      analyticOrderAt completedRiemannZeta rho.1 := by
  let inverseGamma : ℂ → ℂ := fun z => (Complex.Gammaℝ z)⁻¹
  have hinverseAnalytic : AnalyticAt ℂ inverseGamma rho.1 := by
    exact Complex.differentiable_Gammaℝ_inv.analyticAt rho.1
  have hGammaNe : Complex.Gammaℝ rho.1 ≠ 0 :=
    Complex.Gammaℝ_ne_zero_of_re_pos rho.2.2.1
  have hinverseOrder : analyticOrderAt inverseGamma rho.1 = 0 := by
    exact hinverseAnalytic.analyticOrderAt_eq_zero.mpr (inv_ne_zero hGammaNe)
  have heq :
      riemannZeta =ᶠ[nhds rho.1]
        fun z => completedRiemannZeta z * inverseGamma z := by
    filter_upwards [eventually_ne_nhds (li_nontrivial_zero_ne_zero_v1 rho)] with z hz
    rw [riemannZeta_def_of_ne_zero hz, div_eq_mul_inv]
  calc
    analyticOrderAt riemannZeta rho.1 =
        analyticOrderAt
          (fun z => completedRiemannZeta z * inverseGamma z) rho.1 :=
      analyticOrderAt_congr heq
    _ = analyticOrderAt completedRiemannZeta rho.1 +
        analyticOrderAt inverseGamma rho.1 :=
      analyticOrderAt_mul (li_analyticAt_completedRiemannZeta_v1 rho) hinverseAnalytic
    _ = analyticOrderAt completedRiemannZeta rho.1 := by
      rw [hinverseOrder, add_zero]

private theorem li_xi_eq_half_mul_completed_v1
    {s : ℂ} (hs0 : s ≠ 0) (hs1 : s ≠ 1) :
    LiCriterion.riemannXi s =
      (1 / 2 : ℂ) * s * (s - 1) * completedRiemannZeta s := by
  simpa [LiCriterion.riemannXi, XiZeros.riemannXi] using
    (XiZeros.xi_eq_half_s_sm1_Lambda (s := s) hs0 hs1)

/-- Analytic multiplicity is unchanged by passing from zeta to the provider's
entire xi function at a nontrivial zero. -/
theorem li_xi_zeta_multiplicity_eq_v1
    (rho : LiCriterion.NontrivialZero) :
    analyticOrderNatAt LiCriterion.riemannXi rho.1 =
      analyticOrderNatAt riemannZeta rho.1 := by
  let factor : ℂ → ℂ := fun z => (1 / 2 : ℂ) * z * (z - 1)
  have hfactorAnalytic : AnalyticAt ℂ factor rho.1 := by
    dsimp [factor]
    fun_prop
  have hfactorNe : factor rho.1 ≠ 0 := by
    dsimp [factor]
    exact mul_ne_zero
      (mul_ne_zero (by norm_num) (li_nontrivial_zero_ne_zero_v1 rho))
      (sub_ne_zero.mpr (li_nontrivial_zero_ne_one_v1 rho))
  have hfactorOrder : analyticOrderAt factor rho.1 = 0 :=
    hfactorAnalytic.analyticOrderAt_eq_zero.mpr hfactorNe
  have heq :
      LiCriterion.riemannXi =ᶠ[nhds rho.1]
        fun z => factor z * completedRiemannZeta z := by
    filter_upwards
      [eventually_ne_nhds (li_nontrivial_zero_ne_zero_v1 rho),
       eventually_ne_nhds (li_nontrivial_zero_ne_one_v1 rho)] with z hz0 hz1
    simpa [factor, mul_assoc] using li_xi_eq_half_mul_completed_v1 hz0 hz1
  have horder :
      analyticOrderAt LiCriterion.riemannXi rho.1 =
        analyticOrderAt riemannZeta rho.1 := by
    calc
      analyticOrderAt LiCriterion.riemannXi rho.1 =
          analyticOrderAt
            (fun z => factor z * completedRiemannZeta z) rho.1 :=
        analyticOrderAt_congr heq
      _ = analyticOrderAt factor rho.1 +
          analyticOrderAt completedRiemannZeta rho.1 :=
        analyticOrderAt_mul hfactorAnalytic
          (li_analyticAt_completedRiemannZeta_v1 rho)
      _ = analyticOrderAt completedRiemannZeta rho.1 := by
        rw [hfactorOrder, zero_add]
      _ = analyticOrderAt riemannZeta rho.1 :=
        (li_analyticOrderAt_zeta_eq_completed_v1 rho).symm
  simp only [analyticOrderNatAt, horder]

/-- Cumulative multiplicity of nontrivial zeta zeros in centered norm balls
is bounded quadratically for all sufficiently large radii. -/
theorem li_zeta_cumulative_quadratic_multiplicity_bound_v1 :
    ∃ R0 C : ℝ, 0 ≤ C ∧
      ∀ r : ℝ, R0 ≤ r →
        (∑ᶠ rho : LiCriterion.NontrivialZero,
          if ‖rho.1‖ ≤ r then
            (analyticOrderNatAt riemannZeta rho.1 : ℝ)
          else 0) ≤ C * r ^ 2 := by
  let Z : Hadamard.ZeroSet LiCriterion.riemannXi := LiCriterion.xiZeroSet
  letI : Countable Z.Zero := by
    dsimp [Z, LiCriterion.xiZeroSet]
    infer_instance
  have hzeros :
      ∀ s : ℂ, LiCriterion.riemannXi s = 0 ↔
        ∃ rho : Z.Zero, s = Z.z rho := by
    intro s
    simpa [Z, LiCriterion.xiZeroSet] using
      (LiCriterion.xi_zeros_are_nontrivial_zeros (s := s))
  have hinj : Function.Injective Z.z := by
    intro rho sigma h
    exact Subtype.ext h
  have hne : ∀ rho : Z.Zero, Z.z rho ≠ 0 := by
    intro rho
    simpa [Z, LiCriterion.xiZeroSet] using rho.ne_zero
  obtain ⟨R0, C, hC, hbound⟩ :=
    Hadamard.OrderOne.sum_multiplicity_zeros_le_rpow_of_order_le
      (f := LiCriterion.riemannXi)
      LiCriterion.xi_entire
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      (lam := (1 : ℝ))
      LiCriterion.XiGrowth.riemannXi_order_le_one
      (by norm_num)
      Z hzeros hinj hne
      (1 : ℝ) (by norm_num)
  refine ⟨R0, C, hC, ?_⟩
  intro r hr
  have hb := hbound r hr
  dsimp [Z, LiCriterion.xiZeroSet] at hb
  have hmult :
      (∑ᶠ rho : LiCriterion.NontrivialZero,
        if ‖rho.1‖ ≤ r then
          (analyticOrderNatAt riemannZeta rho.1 : ℝ)
        else 0) =
      (∑ᶠ rho : LiCriterion.NontrivialZero,
        if ‖rho.1‖ ≤ r then
          (analyticOrderNatAt LiCriterion.riemannXi rho.1 : ℝ)
        else 0) := by
    apply finsum_congr
    intro rho
    split_ifs <;> simp [li_xi_zeta_multiplicity_eq_v1]
  rw [hmult]
  calc
    (∑ᶠ rho : LiCriterion.NontrivialZero,
      if ‖rho.1‖ ≤ r then
        (analyticOrderNatAt LiCriterion.riemannXi rho.1 : ℝ)
      else 0) ≤ C * r ^ ((1 : ℝ) + 1) := hb
    _ = C * r ^ 2 := by
      rw [show (1 : ℝ) + 1 = 2 by norm_num, Real.rpow_two]

/-- Canonical injection from one AEGIS height shell into the provider's
nontrivial-zero carrier. -/
private def shell_to_li_nontrivial_zero_v1 (n : ℕ) :
    ZeroHeightShellSetV1 n ↪ LiCriterion.NontrivialZero where
  toFun rho := by
    have hstrip :=
      riemann_zeta_nontrivial_zero_critical_strip_v1 rho.1.2.1 rho.1.2.2
    exact ⟨rho.1.1, rho.1.2.1, hstrip.1, hstrip.2⟩
  inj' := by
    intro a b hab
    apply Subtype.ext
    apply Subtype.ext
    exact congrArg (fun rho : LiCriterion.NontrivialZero => rho.1) hab

/-- Every member of the canonical shell `n` lies in the centered norm ball of
radius `n + 1`. -/
private theorem shell_norm_le_succ_v1
    (n : ℕ) (rho : ZeroHeightShellSetV1 n) :
    ‖rho.1.1‖ ≤ (n : ℝ) + 1 := by
  have hstrip :=
    riemann_zeta_nontrivial_zero_critical_strip_v1 rho.1.2.1 rho.1.2.2
  have hre_nonneg : 0 ≤ rho.1.1.re := hstrip.1.le
  have hre_le : rho.1.1.re ≤ 1 := hstrip.2.le
  have hshell : ZeroHeightShellIndexV1 rho.1 = n := rho.2
  have hceil : |rho.1.1.im| ≤ (Nat.ceil |rho.1.1.im| : ℝ) :=
    Nat.le_ceil |rho.1.1.im|
  have him_le : |rho.1.1.im| ≤ (n : ℝ) := by
    rw [show Nat.ceil |rho.1.1.im| = n by
      simpa [ZeroHeightShellIndexV1] using hshell] at hceil
    exact hceil
  calc
    ‖rho.1.1‖ ≤ |rho.1.1.re| + |rho.1.1.im| :=
      Complex.norm_le_abs_re_add_abs_im rho.1.1
    _ = rho.1.1.re + |rho.1.1.im| := by
      rw [abs_of_nonneg hre_nonneg]
    _ ≤ 1 + (n : ℝ) := add_le_add hre_le him_le
    _ = (n : ℝ) + 1 := by ring

/-- Provider nontrivial zeros in a centered norm ball form a finite set. -/
private theorem li_norm_ball_finite_v1 (r : ℝ) :
    {rho : LiCriterion.NontrivialZero | ‖rho.1‖ ≤ r}.Finite := by
  rw [← Set.finite_coe_iff]
  let K : Set ℂ := Metric.closedBall (0 : ℂ) |r| ∩ riemannZetaZeros
  have hK : K.Finite :=
    IsCompact.inter_riemannZetaZeros_finite
      (isCompact_closedBall (0 : ℂ) |r|)
  letI : Fintype K := hK.fintype
  let embed : {rho : LiCriterion.NontrivialZero // ‖rho.1‖ ≤ r} → K := fun rho =>
    ⟨rho.1.1, by
      constructor
      · simp only [Metric.mem_closedBall, dist_zero_right]
        exact rho.2.trans (le_abs_self r)
      · exact mem_riemannZetaZeros.mpr rho.1.2.1⟩
  exact Finite.of_injective embed (by
    intro a b hab
    apply Subtype.ext
    apply Subtype.ext
    exact congrArg (fun z : K => z.1) hab)

/-- The finite mass of one AEGIS height shell is dominated by the provider's
cumulative multiplicity count in the centered norm ball of radius `n + 1`. -/
private theorem shell_multiplicity_mass_le_li_cumulative_v1 (n : ℕ) :
    ZeroHeightShellMultiplicityMassV1 n ≤
      ∑ᶠ rho : LiCriterion.NontrivialZero,
        if ‖rho.1‖ ≤ (n : ℝ) + 1 then
          (analyticOrderNatAt riemannZeta rho.1 : ℝ)
        else 0 := by
  letI : Fintype (ZeroHeightShellSetV1 n) :=
    (zero_height_shell_finite_v1 n).fintype
  let e := shell_to_li_nontrivial_zero_v1 n
  let f : ZeroHeightShellSetV1 n → ℝ := fun rho =>
    (analyticOrderNatAt riemannZeta rho.1.1 : ℝ)
  let g : LiCriterion.NontrivialZero → ℝ := fun rho =>
    if ‖rho.1‖ ≤ (n : ℝ) + 1 then
      (analyticOrderNatAt riemannZeta rho.1 : ℝ)
    else 0
  have hgfinite : (Function.support g).Finite := by
    apply (li_norm_ball_finite_v1 ((n : ℝ) + 1)).subset
    intro rho hrho
    by_cases hle : ‖rho.1‖ ≤ (n : ℝ) + 1
    · exact hle
    · exfalso
      exact hrho (by simp [g, hle])
  have hf : Summable f := Summable.of_finite
  have hg : Summable g := summable_of_hasFiniteSupport hgfinite
  have hle : (∑' rho, f rho) ≤ ∑' rho, g rho :=
    hf.tsum_le_tsum_of_inj e e.injective
      (fun rho _ => by
        dsimp [g]
        split_ifs <;> positivity)
      (fun rho => by
        have hnorm := shell_norm_le_succ_v1 n rho
        change (analyticOrderNatAt riemannZeta rho.1.1 : ℝ) ≤
          if ‖(e rho).1‖ ≤ (n : ℝ) + 1 then
            (analyticOrderNatAt riemannZeta (e rho).1 : ℝ)
          else 0
        have heval : (e rho).1 = rho.1.1 := by rfl
        have hball : ‖(e rho).1‖ ≤ (n : ℝ) + 1 := by
          simpa [heval] using hnorm
        rw [if_pos hball, heval])
      hg
  rw [tsum_eq_finsum hgfinite] at hle
  simpa [ZeroHeightShellMultiplicityMassV1, f, g] using hle

private theorem zero_height_shell_multiplicity_mass_nonneg_v1 (n : ℕ) :
    0 ≤ ZeroHeightShellMultiplicityMassV1 n := by
  unfold ZeroHeightShellMultiplicityMassV1
  exact tsum_nonneg fun _ => by positivity

/-- Actual multiplicity-safe quantitative shell bound used by the next analytic
synthesis lane. No critical-line hypothesis is used. -/
theorem riemann_zeta_has_quadratic_shell_multiplicity_bound_v1 :
    HasQuadraticShellMultiplicityBoundV1 := by
  obtain ⟨R0, C, hC, hcum⟩ :=
    li_zeta_cumulative_quadratic_multiplicity_bound_v1
  let N : ℕ := Nat.ceil (max R0 1)
  let S : ℝ := (Finset.range N).sum ZeroHeightShellMultiplicityMassV1
  let A : ℝ := max C S
  have hS : 0 ≤ S := by
    dsimp [S]
    exact Finset.sum_nonneg fun k _ =>
      zero_height_shell_multiplicity_mass_nonneg_v1 k
  have hA : 0 ≤ A :=
    hC.trans (le_max_left C S)
  have hCA : C ≤ A := le_max_left C S
  have hSA : S ≤ A := le_max_right C S
  refine ⟨A, hA, ?_⟩
  intro n
  by_cases hn : n < N
  · have hsmall : ZeroHeightShellMultiplicityMassV1 n ≤ S := by
      dsimp [S]
      exact Finset.single_le_sum
        (fun k _ => zero_height_shell_multiplicity_mass_nonneg_v1 k)
        (Finset.mem_range.mpr hn)
    have hr1 : 1 ≤ (((n : ℝ) + 1) ^ 2) := by
      have hn0 : 0 ≤ (n : ℝ) := by positivity
      nlinarith
    calc
      ZeroHeightShellMultiplicityMassV1 n ≤ S := hsmall
      _ ≤ A := hSA
      _ ≤ A * (((n : ℝ) + 1) ^ 2) :=
        le_mul_of_one_le_right hA hr1
  · have hNn : N ≤ n := Nat.le_of_not_gt hn
    have hR0N : R0 ≤ (N : ℝ) := by
      calc
        R0 ≤ max R0 1 := le_max_left R0 1
        _ ≤ (Nat.ceil (max R0 1) : ℝ) := Nat.le_ceil (max R0 1)
        _ = (N : ℝ) := by rfl
    have hNnR : (N : ℝ) ≤ (n : ℝ) := by
      exact_mod_cast hNn
    have hR0r : R0 ≤ (n : ℝ) + 1 := by
      linarith
    have hshell := shell_multiplicity_mass_le_li_cumulative_v1 n
    have hlarge := hcum ((n : ℝ) + 1) hR0r
    have hr2 : 0 ≤ (((n : ℝ) + 1) ^ 2) := sq_nonneg _
    calc
      ZeroHeightShellMultiplicityMassV1 n ≤
          ∑ᶠ rho : LiCriterion.NontrivialZero,
            if ‖rho.1‖ ≤ (n : ℝ) + 1 then
              (analyticOrderNatAt riemannZeta rho.1 : ℝ)
            else 0 := hshell
      _ ≤ C * (((n : ℝ) + 1) ^ 2) := hlarge
      _ ≤ A * (((n : ℝ) + 1) ^ 2) :=
        mul_le_mul_of_nonneg_right hCA hr2

#check HasQuadraticShellMultiplicityBoundV1
#check li_xi_zeta_multiplicity_eq_v1
#check li_zeta_cumulative_quadratic_multiplicity_bound_v1
#check riemann_zeta_has_quadratic_shell_multiplicity_bound_v1
#print axioms li_xi_zeta_multiplicity_eq_v1
#print axioms li_zeta_cumulative_quadratic_multiplicity_bound_v1
#print axioms riemann_zeta_has_quadratic_shell_multiplicity_bound_v1
~~~~~~

## ZeroShellAnalyticSynthesisV1

Path: `source/ZeroShellAnalyticSynthesisV1.lean`

Original source lines: 1–139

Full file SHA256: `5a688159e9c71c623862500a7fbdde37748e5b99334fdfe38ff6c508176dd53e`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroShellAnalyticSynthesisV1.lean

~~~~~~lean
import ZeroShellQuadraticBoundV1

/-!
AEGIS Ω — analytic shell synthesis v1.

This module is a pure synthesis layer over the already verified finite
height-shell and quadratic-shell infrastructure. It introduces two explicit
analytic interfaces:

* a linear bound on total analytic-order multiplicity mass in each shell;
* a cubic pointwise Mellin-decay bound on each shell.

From those two supplied inputs it proves the existing
`HasQuadraticShellMassBoundV1` certificate. The module does not prove either
analytic input, does not assume that nontrivial zeros lie on the critical line,
and does not prove an explicit formula, the Weil criterion, or RH.

ZERO_SHELL_ANALYTIC_SYNTHESIS_ONLY
ACTUAL_LINEAR_SHELL_MULTIPLICITY_BOUND_OPEN
ACTUAL_CUBIC_SHELL_MELLIN_DECAY_OPEN
ACTUAL_QUADRATIC_SHELL_BOUND_OPEN
ZERO_COUNTING_BOUND_OPEN
MELLIN_DECAY_ESTIMATE_OPEN
WEIL_CLASS_SHELL_MASS_SUMMABILITY_OPEN
CONDITIONAL_SYMMETRIC_CONVERGENCE_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Filter Topology
open Complex

noncomputable section

/-- Total analytic-order multiplicity mass in the `n`-th verified height
shell. The shell itself is the existing `ZeroHeightShellSetV1 n`; no parallel
zero carrier is introduced here. -/
def ZeroHeightShellMultiplicityMassV1 (n : ℕ) : ℝ :=
  ∑' rho : ZeroHeightShellSetV1 n,
    (analyticOrderNatAt riemannZeta rho.1.1 : ℝ)

/-- Weak zero-counting interface sufficient for the synthesis layer. A sharper
Riemann-von Mangoldt shell estimate may later discharge this premise, but this
module consumes only the linear majorant actually needed downstream. -/
def HasLinearShellMultiplicityBoundV1 : Prop :=
  ∃ A : ℝ, 0 ≤ A ∧
    ∀ n : ℕ,
      ZeroHeightShellMultiplicityMassV1 n ≤
        A * ((n + 1 : ℕ) : ℝ)

/-- Shell-local cubic Mellin-decay interface. A later Mellin/Fourier analysis
must construct this certificate uniformly for the intended test-function
class. -/
def HasCubicShellMellinDecayV1 (f : ℝ → ℂ) : Prop :=
  ∃ B : ℝ, 0 ≤ B ∧
    ∀ (n : ℕ) (rho : ZeroHeightShellSetV1 n),
      ‖mellin f rho.1.1‖ ≤
        B / (((n + 1 : ℕ) : ℝ) ^ 3)

/-- Linear multiplicity mass plus cubic pointwise Mellin decay implies the
quadratic shell certificate already consumed by `ZeroShellQuadraticBoundV1`.
This theorem is synthesis only: the two analytic premises remain independent
obligations. -/
theorem shell_count_and_mellin_decay_imply_quadratic_bound_v1
    {f : ℝ → ℂ}
    (hcount : HasLinearShellMultiplicityBoundV1)
    (hdecay : HasCubicShellMellinDecayV1 f) :
    HasQuadraticShellMassBoundV1 f := by
  classical
  rcases hcount with ⟨A, hA, hcount_bound⟩
  rcases hdecay with ⟨B, hB, hdecay_bound⟩
  refine ⟨A * B, mul_nonneg hA hB, ?_⟩
  intro n

  letI : Fintype (ZeroHeightShellSetV1 n) :=
    (zero_height_shell_finite_v1 n).fintype

  let t : ℝ := ((n + 1 : ℕ) : ℝ)
  have ht : 0 < t := by
    dsimp [t]
    positivity

  have hfactor : 0 ≤ B / t ^ 3 := by
    exact div_nonneg hB (by positivity)

  have hcount_n :
      (∑ rho : ZeroHeightShellSetV1 n,
        (analyticOrderNatAt riemannZeta rho.1.1 : ℝ)) ≤
      A * t := by
    simpa [ZeroHeightShellMultiplicityMassV1, tsum_fintype, t]
      using hcount_bound n

  have hterm :
      ∀ rho : ZeroHeightShellSetV1 n,
        ‖WeilZeroIndexSummandV1 f rho.1‖ ≤
          (analyticOrderNatAt riemannZeta rho.1.1 : ℝ) *
            (B / t ^ 3) := by
    intro rho
    have hm :
        0 ≤ (analyticOrderNatAt riemannZeta rho.1.1 : ℝ) := by
      positivity
    have hmul :=
      mul_le_mul_of_nonneg_left (hdecay_bound n rho) hm
    simpa [WeilZeroIndexSummandV1, norm_mul, t] using hmul

  change
    ZeroHeightShellMassV1 f n ≤
      QuadraticShellReferenceV1 (A * B) n

  calc
    ZeroHeightShellMassV1 f n =
        ∑ rho : ZeroHeightShellSetV1 n,
          ‖WeilZeroIndexSummandV1 f rho.1‖ := by
      simp [ZeroHeightShellMassV1, tsum_fintype]
    _ ≤
        ∑ rho : ZeroHeightShellSetV1 n,
          (analyticOrderNatAt riemannZeta rho.1.1 : ℝ) *
            (B / t ^ 3) := by
      exact Finset.sum_le_sum fun rho _ => hterm rho
    _ =
        (∑ rho : ZeroHeightShellSetV1 n,
          (analyticOrderNatAt riemannZeta rho.1.1 : ℝ)) *
            (B / t ^ 3) := by
      simpa only [Finset.sum_mul]
    _ ≤ (A * t) * (B / t ^ 3) := by
      exact mul_le_mul_of_nonneg_right hcount_n hfactor
    _ = QuadraticShellReferenceV1 (A * B) n := by
      unfold QuadraticShellReferenceV1
      change
        (A * t) * (B / t ^ 3) =
          (A * B) * (1 / t ^ 2)
      field_simp [ne_of_gt ht]

#check ZeroHeightShellMultiplicityMassV1
#check HasLinearShellMultiplicityBoundV1
#check HasCubicShellMellinDecayV1
#check shell_count_and_mellin_decay_imply_quadratic_bound_v1
#print axioms shell_count_and_mellin_decay_imply_quadratic_bound_v1
~~~~~~

## ZeroShellQuadraticBoundV1

Path: `source/ZeroShellQuadraticBoundV1.lean`

Original source lines: 1–97

Full file SHA256: `fca6acdcf6bb7a710fac65839197c9c3d12ca431aeca37dd826d855101fef9dd`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroShellQuadraticBoundV1.lean

~~~~~~lean
import ZeroHeightShellMassV1
import Mathlib.Analysis.PSeries

/-!
AEGIS Ω — quadratic height-shell mass bound reduction v1.

This lane proves only a sufficient quantitative reduction. If the already
verified shell norm-masses admit a uniform bound of the form

  shellMass(f,n) ≤ C * 1 / (n+1)^2

for some nonnegative constant `C`, then the shell-mass series is summable.
Consequently the previously verified shell bridge yields unconditional
summability of the zero-side Mellin summand and an actual symmetric-height
limit witness.

The lane does not prove that such a quadratic bound holds for any Weil/Bombieri
test class. The actual Mellin-decay estimate and quantitative zero-counting
input needed to establish such a bound remain separate open obligations.

QUADRATIC_SHELL_BOUND_SUFFICIENT_ONLY
ACTUAL_QUADRATIC_SHELL_BOUND_OPEN
MELLIN_DECAY_ESTIMATE_OPEN
ZERO_COUNTING_BOUND_OPEN
WEIL_CLASS_SHELL_MASS_SUMMABILITY_OPEN
CONDITIONAL_SYMMETRIC_CONVERGENCE_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Filter Topology

noncomputable section

/-- Quadratic comparison sequence used only as a sufficient shell-mass
majorant. The shift by one avoids the singular term at `n = 0`. -/
def QuadraticShellReferenceV1 (C : ℝ) (n : ℕ) : ℝ :=
  C * (1 / (((n + 1 : ℕ) : ℝ) ^ 2))

/-- Certificate that every finite shell norm-mass is bounded by one fixed
quadratic p-series majorant. This is a definition, not an existence theorem. -/
def HasQuadraticShellMassBoundV1 (f : ℝ → ℂ) : Prop :=
  ∃ C : ℝ, 0 ≤ C ∧
    ∀ n : ℕ, ZeroHeightShellMassV1 f n ≤ QuadraticShellReferenceV1 C n

private theorem zero_height_shell_mass_nonneg_v1 (f : ℝ → ℂ) (n : ℕ) :
    0 ≤ ZeroHeightShellMassV1 f n := by
  unfold ZeroHeightShellMassV1
  exact tsum_nonneg fun _ => norm_nonneg _

private theorem quadratic_shell_reference_summable_v1 (C : ℝ) :
    Summable (QuadraticShellReferenceV1 C) := by
  unfold QuadraticShellReferenceV1
  apply Summable.mul_left C
  have hp0 : Summable (fun n : ℕ => 1 / ((n : ℝ) ^ 2)) :=
    (Real.summable_one_div_nat_pow (p := 2)).mpr (by norm_num)
  have hshift :=
    (summable_nat_add_iff (f := fun n : ℕ => 1 / ((n : ℝ) ^ 2)) 1).mpr hp0
  simpa [Nat.cast_add, Nat.cast_one] using hshift

/-- A supplied quadratic shell-mass bound makes the shell-mass sequence
summable by direct comparison with the shifted p-series of exponent two. -/
theorem quadratic_shell_bound_implies_summable_v1
    {f : ℝ → ℂ} (h : HasQuadraticShellMassBoundV1 f) :
    Summable (ZeroHeightShellMassV1 f) := by
  rcases h with ⟨C, _hC, hbound⟩
  exact Summable.of_nonneg_of_le
    (fun n => zero_height_shell_mass_nonneg_v1 f n)
    hbound
    (quadratic_shell_reference_summable_v1 C)

/-- Under the supplied quadratic shell certificate, the complex zero-side
summand is unconditionally summable. -/
theorem quadratic_shell_bound_implies_zero_summable_v1
    {f : ℝ → ℂ} (h : HasQuadraticShellMassBoundV1 f) :
    Summable (WeilZeroIndexSummandV1 f) := by
  exact zero_summable_of_shell_mass_v1
    (quadratic_shell_bound_implies_summable_v1 h)

/-- Under the supplied quadratic shell certificate, the already verified
symmetric-height limit contract has an actual witness. This theorem does not
construct the certificate. -/
theorem quadratic_shell_bound_implies_height_limit_v1
    {f : ℝ → ℂ} (h : HasQuadraticShellMassBoundV1 f) :
    WeilZeroHeightLimitExistsV1 f := by
  exact shell_mass_implies_height_limit_exists_v1
    (quadratic_shell_bound_implies_summable_v1 h)

#check QuadraticShellReferenceV1
#check HasQuadraticShellMassBoundV1
#check quadratic_shell_bound_implies_summable_v1
#check quadratic_shell_bound_implies_zero_summable_v1
#check quadratic_shell_bound_implies_height_limit_v1
#print axioms quadratic_shell_bound_implies_summable_v1
#print axioms quadratic_shell_bound_implies_zero_summable_v1
#print axioms quadratic_shell_bound_implies_height_limit_v1
~~~~~~

## ZeroHeightShellMassV1

Path: `source/ZeroHeightShellMassV1.lean`

Original source lines: 1–148

Full file SHA256: `c54e4a4603ca6bdb9d056cad7d9ac16d736411a9a743cdefead78cc8d11c730f`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroHeightShellMassV1.lean

~~~~~~lean
import ZeroMajorantSummabilityV1
import ZeroCriticalStripV1
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Algebra.Order.Floor.Semiring

/-!
AEGIS Ω — finite height-shell mass reduction for the nontrivial zeta-zero side v1.

Each nontrivial zero is assigned the canonical shell index `ceil |Im rho|`.
Using the already verified critical-strip localization and Mathlib compact-zero
finiteness, every shell is finite. Mathlib's nonnegative partition theorem then
reduces global norm-summability of the multiplicity-weighted Mellin zero
summand exactly to summability of the sequence of finite shell norm-masses.

This lane does not prove any decay estimate for those shell masses and does not
prove that their series is summable for the Weil/Bombieri test class.

FINITE_HEIGHT_SHELL_REDUCTION_ONLY
SHELL_MASS_DECAY_BOUND_OPEN
WEIL_CLASS_SHELL_MASS_SUMMABILITY_OPEN
CONDITIONAL_SYMMETRIC_CONVERGENCE_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Filter Topology
open Complex

noncomputable section

/-- Canonical natural-number shell index of a nontrivial zeta zero. -/
def ZeroHeightShellIndexV1 (rho : RiemannNontrivialZeroIndexV2) : ℕ :=
  Nat.ceil |rho.1.im|

/-- The `n`-th shell consists of nontrivial zeros whose canonical ceiling
height is exactly `n`. -/
def ZeroHeightShellSetV1 (n : ℕ) : Set RiemannNontrivialZeroIndexV2 :=
  {rho | ZeroHeightShellIndexV1 rho = n}

/-- Every canonical height shell is finite. The proof places a shell in the
compact disk of radius `n + 1`, using `0 < Re rho < 1` for nontrivial zeros. -/
theorem zero_height_shell_finite_v1 (n : ℕ) :
    (ZeroHeightShellSetV1 n).Finite := by
  rw [← Set.finite_coe_iff]
  let K : Set ℂ := Metric.closedBall (0 : ℂ) ((n : ℝ) + 1) ∩ riemannZetaZeros
  have hK : K.Finite :=
    IsCompact.inter_riemannZetaZeros_finite
      (isCompact_closedBall (0 : ℂ) ((n : ℝ) + 1))
  letI : Fintype K := hK.fintype
  let embed : (ZeroHeightShellSetV1 n) → K := fun rho =>
    ⟨rho.1.1, by
      have hstrip :=
        riemann_zeta_nontrivial_zero_critical_strip_v1 rho.1.2.1 rho.1.2.2
      have hre_nonneg : 0 ≤ rho.1.1.re := hstrip.1.le
      have hre_le : rho.1.1.re ≤ 1 := hstrip.2.le
      have hshell : ZeroHeightShellIndexV1 rho.1 = n := rho.2
      have hceil : |rho.1.1.im| ≤ (Nat.ceil |rho.1.1.im| : ℝ) :=
        Nat.le_ceil |rho.1.1.im|
      have him_le : |rho.1.1.im| ≤ (n : ℝ) := by
        rw [show Nat.ceil |rho.1.1.im| = n by
          simpa [ZeroHeightShellIndexV1] using hshell] at hceil
        exact hceil
      constructor
      · simp only [Metric.mem_closedBall, dist_zero_right]
        calc
          ‖rho.1.1‖ ≤ |rho.1.1.re| + |rho.1.1.im| :=
            Complex.norm_le_abs_re_add_abs_im rho.1.1
          _ = rho.1.1.re + |rho.1.1.im| := by rw [abs_of_nonneg hre_nonneg]
          _ ≤ 1 + (n : ℝ) := add_le_add hre_le him_le
          _ = (n : ℝ) + 1 := by ring
      · exact mem_riemannZetaZeros.mpr rho.1.2.1⟩
  exact Finite.of_injective embed (by
    intro a b hab
    apply Subtype.ext
    apply Subtype.ext
    exact congrArg (fun z : K => z.1) hab)

/-- Finite norm-mass of the `n`-th canonical height shell. The expression is a
`tsum` over a finite subtype; finiteness is proved above. -/
def ZeroHeightShellMassV1 (f : ℝ → ℂ) (n : ℕ) : ℝ :=
  ∑' rho : ZeroHeightShellSetV1 n, ‖WeilZeroIndexSummandV1 f rho.1‖

private theorem zero_height_shell_partition_v1 :
    ∀ rho : RiemannNontrivialZeroIndexV2,
      ∃! n : ℕ, rho ∈ ZeroHeightShellSetV1 n := by
  intro rho
  refine ⟨ZeroHeightShellIndexV1 rho, ?_, ?_⟩
  · change ZeroHeightShellIndexV1 rho = ZeroHeightShellIndexV1 rho
    rfl
  · intro n hn
    change ZeroHeightShellIndexV1 rho = n at hn
    exact hn.symm

/-- Global absolute/norm summability of the zero-side summand is equivalent to
summability of the sequence of finite shell norm-masses. -/
theorem zero_norm_summable_iff_shell_mass_v1 (f : ℝ → ℂ) :
    Summable
        (fun rho : RiemannNontrivialZeroIndexV2 =>
          ‖WeilZeroIndexSummandV1 f rho‖) ↔
      Summable (ZeroHeightShellMassV1 f) := by
  have hpart :=
    summable_partition
      (f := fun rho : RiemannNontrivialZeroIndexV2 =>
        ‖WeilZeroIndexSummandV1 f rho‖)
      (s := ZeroHeightShellSetV1)
      (fun _ => norm_nonneg _)
      zero_height_shell_partition_v1
  constructor
  · intro h
    exact (hpart.mp h).2
  · intro hmass
    apply hpart.mpr
    refine ⟨?_, hmass⟩
    intro n
    letI : Fintype (ZeroHeightShellSetV1 n) :=
      (zero_height_shell_finite_v1 n).fintype
    exact (hasSum_fintype _).summable

/-- Summability of the finite shell masses is a sufficient certificate for
unconditional summability of the complex zero-side summand. -/
theorem zero_summable_of_shell_mass_v1
    {f : ℝ → ℂ} (h : Summable (ZeroHeightShellMassV1 f)) :
    Summable (WeilZeroIndexSummandV1 f) := by
  exact Summable.of_norm ((zero_norm_summable_iff_shell_mass_v1 f).mpr h)

/-- A summable shell-mass series therefore supplies an actual witness for the
already verified symmetric-height limit contract. -/
theorem shell_mass_implies_height_limit_exists_v1
    {f : ℝ → ℂ} (h : Summable (ZeroHeightShellMassV1 f)) :
    WeilZeroHeightLimitExistsV1 f := by
  have hsum : Summable (WeilZeroIndexSummandV1 f) :=
    zero_summable_of_shell_mass_v1 h
  refine ⟨∑' rho : RiemannNontrivialZeroIndexV2,
      WeilZeroIndexSummandV1 f rho, ?_⟩
  exact hasSum_implies_height_limit_v1 hsum.hasSum

#check ZeroHeightShellIndexV1
#check ZeroHeightShellSetV1
#check zero_height_shell_finite_v1
#check ZeroHeightShellMassV1
#check zero_norm_summable_iff_shell_mass_v1
#check zero_summable_of_shell_mass_v1
#check shell_mass_implies_height_limit_exists_v1
#print axioms zero_height_shell_finite_v1
#print axioms zero_norm_summable_iff_shell_mass_v1
#print axioms zero_summable_of_shell_mass_v1
#print axioms shell_mass_implies_height_limit_exists_v1
~~~~~~

## ZeroMajorantSummabilityV1

Path: `source/ZeroMajorantSummabilityV1.lean`

Original source lines: 1–82

Full file SHA256: `360ee880341d453835c33d7252ba2d96a5f836da2b78de768f9ccbe1e5fca73f`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroMajorantSummabilityV1.lean

~~~~~~lean
import ZeroHeightSummabilityBridgeV1
import Mathlib.Analysis.Normed.Group.InfiniteSum

/-!
AEGIS Ω — summable norm-majorant bridge for the nontrivial zeta-zero side v1.

This lane proves a standard direct-comparison reduction only. If one supplies a
real-valued summable majorant that pointwise dominates the norm of the already
verified multiplicity-weighted Mellin summand, then the zero-side summand is
unconditionally summable. The verified `HasSum -> height limit` bridge then
produces an actual height-limit witness, and that witness is uniquely the
unordered `tsum` under this strong hypothesis.

This lane does not construct such a majorant for the Weil/Bombieri test class.
It does not assert that unconditional summability is the weakest classical
summation convention needed by the explicit formula.

ZERO_MAJORANT_SUFFICIENT_ONLY
ACTUAL_MAJORANT_CONSTRUCTION_OPEN
WEIL_CLASS_MAJORANT_OPEN
CONDITIONAL_SYMMETRIC_CONVERGENCE_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Filter Topology

noncomputable section

/-- A concrete sufficient certificate for unconditional summability of the
multiplicity-weighted nontrivial-zero Mellin summand. -/
def HasSummableZeroMajorantV1 (f : ℝ → ℂ) : Prop :=
  ∃ g : RiemannNontrivialZeroIndexV2 → ℝ,
    Summable g ∧
      ∀ rho : RiemannNontrivialZeroIndexV2,
        ‖WeilZeroIndexSummandV1 f rho‖ ≤ g rho

/-- Direct comparison: a supplied summable norm-majorant makes the zero-side
summand unconditionally summable. -/
theorem zero_summable_of_majorant_v1
    {f : ℝ → ℂ} (h : HasSummableZeroMajorantV1 f) :
    Summable (WeilZeroIndexSummandV1 f) := by
  rcases h with ⟨g, hg, hbound⟩
  exact Summable.of_norm_bounded hg hbound

/-- Under the strong majorant certificate, the previously verified symmetric
height-limit contract has an actual witness. This does not construct the
certificate itself. -/
theorem majorant_implies_height_limit_exists_v1
    {f : ℝ → ℂ} (h : HasSummableZeroMajorantV1 f) :
    WeilZeroHeightLimitExistsV1 f := by
  have hsum : Summable (WeilZeroIndexSummandV1 f) :=
    zero_summable_of_majorant_v1 h
  refine ⟨∑' rho : RiemannNontrivialZeroIndexV2,
      WeilZeroIndexSummandV1 f rho, ?_⟩
  exact hasSum_implies_height_limit_v1 hsum.hasSum

/-- Any symmetric height-limit witness under the same majorant certificate is
the unordered `tsum`. The conclusion is conditional on the strong majorant. -/
theorem majorant_height_limit_eq_tsum_v1
    {f : ℝ → ℂ} {L : ℂ}
    (h : HasSummableZeroMajorantV1 f)
    (hL : HasWeilZeroHeightLimitV1 f L) :
    L = ∑' rho : RiemannNontrivialZeroIndexV2,
      WeilZeroIndexSummandV1 f rho := by
  have hsum : Summable (WeilZeroIndexSummandV1 f) :=
    zero_summable_of_majorant_v1 h
  have hTsum :
      HasWeilZeroHeightLimitV1 f
        (∑' rho : RiemannNontrivialZeroIndexV2,
          WeilZeroIndexSummandV1 f rho) :=
    hasSum_implies_height_limit_v1 hsum.hasSum
  exact weil_zero_height_limit_unique_v1 hL hTsum

#check HasSummableZeroMajorantV1
#check zero_summable_of_majorant_v1
#check majorant_implies_height_limit_exists_v1
#check majorant_height_limit_eq_tsum_v1
#print axioms zero_summable_of_majorant_v1
#print axioms majorant_implies_height_limit_exists_v1
#print axioms majorant_height_limit_eq_tsum_v1
~~~~~~

## ZeroHeightSummabilityBridgeV1

Path: `source/ZeroHeightSummabilityBridgeV1.lean`

Original source lines: 1–156

Full file SHA256: `4778e1f2bd64e1ee191be8092a32706cd7277aaa72a80a89bb1ef467dca39949`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroHeightSummabilityBridgeV1.lean

~~~~~~lean
import ZeroHeightLimitContractV1
import Mathlib.Topology.Algebra.InfiniteSum.Defs
import Mathlib.Order.Filter.AtTopBot.Finset

/-!
AEGIS Ω — unconditional-summability sufficient bridge to the symmetric height limit v1.

This lane does NOT prove that the zeta-zero summand is summable. It proves only
that the already verified symmetric-height truncations form a cofinal family of
finite subsets of the subtype of nontrivial zeta zeros, and therefore that an
explicit `HasSum` premise for the multiplicity-weighted Mellin summand implies
the previously verified `T → +∞` height-limit contract.

Unconditional `HasSum` is a deliberately strong sufficient hypothesis here. It
is not asserted to be equivalent to any weaker conditionally convergent
classical zero-summation convention.

UNCONDITIONAL_SUMMABILITY_SUFFICIENT_ONLY
ACTUAL_ZERO_SUM_SUMMABILITY_OPEN
HEIGHT_LIMIT_EXISTENCE_UNCONDITIONAL_OPEN
HEIGHT_RADIAL_EQUIVALENCE_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Filter Topology
open Complex

noncomputable section

/-- The subtype of all nontrivial Riemann-zeta zeros, using the same exclusion
of the trivial zeros as the verified height-truncation lane. -/
def RiemannNontrivialZeroIndexV2 :=
  { rho : ℂ //
      riemannZeta rho = 0 ∧
      (¬ ∃ n : ℕ, rho = -(2 : ℂ) * (n + 1)) }

private theorem parent_height_finset_mem_iff_v1 {T : ℝ} {s : ℂ} :
    s ∈ NontrivialZeroHeightFinsetV1 T ↔ s ∈ NontrivialZeroHeightSetV1 T := by
  simp [NontrivialZeroHeightFinsetV1]

/-- Each attached member of the verified complex-valued height finset canonically
becomes an element of the subtype of nontrivial zeros. -/
private def height_attach_to_nontrivial_index_v1 (T : ℝ) :
    {s // s ∈ NontrivialZeroHeightFinsetV1 T} ↪ RiemannNontrivialZeroIndexV2 where
  toFun s :=
    ⟨s.1, by
      have hsSet : s.1 ∈ NontrivialZeroHeightSetV1 T :=
        parent_height_finset_mem_iff_v1.mp s.2
      exact ⟨hsSet.1, hsSet.2.1⟩⟩
  inj' := by
    intro a b hab
    apply Subtype.ext
    exact congrArg (fun rho : RiemannNontrivialZeroIndexV2 => rho.1) hab

/-- Canonical finite-height carrier, now indexed directly by the subtype of
nontrivial zeros. It is obtained without enumerating the zero set. -/
noncomputable def NontrivialZeroHeightIndexFinsetV1 (T : ℝ) :
    Finset RiemannNontrivialZeroIndexV2 :=
  (NontrivialZeroHeightFinsetV1 T).attach.map
    (height_attach_to_nontrivial_index_v1 T)

private theorem mem_nontrivial_zero_height_index_finset_v1
    {T : ℝ} {rho : RiemannNontrivialZeroIndexV2} :
    rho ∈ NontrivialZeroHeightIndexFinsetV1 T ↔ |rho.1.im| ≤ T := by
  constructor
  · intro hrho
    rw [NontrivialZeroHeightIndexFinsetV1, Finset.mem_map] at hrho
    rcases hrho with ⟨x, hx, hxrho⟩
    have hxSet : x.1 ∈ NontrivialZeroHeightSetV1 T :=
      parent_height_finset_mem_iff_v1.mp x.2
    have hval : x.1 = rho.1 := by
      exact congrArg Subtype.val hxrho
    simpa [hval] using hxSet.2.2
  · intro him
    have hparent : rho.1 ∈ NontrivialZeroHeightFinsetV1 T :=
      parent_height_finset_mem_iff_v1.mpr ⟨rho.2.1, rho.2.2, him⟩
    let x : {s // s ∈ NontrivialZeroHeightFinsetV1 T} := ⟨rho.1, hparent⟩
    have hxattach : x ∈ (NontrivialZeroHeightFinsetV1 T).attach := by
      simp [x]
    have hxrho : height_attach_to_nontrivial_index_v1 T x = rho := by
      apply Subtype.ext
      rfl
    rw [NontrivialZeroHeightIndexFinsetV1, Finset.mem_map]
    exact ⟨x, hxattach, hxrho⟩

private theorem nontrivial_zero_height_index_finset_mono_v1 :
    Monotone NontrivialZeroHeightIndexFinsetV1 := by
  intro T U hTU rho hrho
  apply mem_nontrivial_zero_height_index_finset_v1.mpr
  exact (mem_nontrivial_zero_height_index_finset_v1.mp hrho).trans hTU

/-- The height-indexed finite carriers are cofinal among all finite subsets of
nontrivial zeta zeros. For a finite set `s`, the sum of `|Im rho|` over `s`
is a concrete height bound containing every member. -/
theorem tendsto_nontrivial_zero_height_index_finset_atTop_v1 :
    Tendsto NontrivialZeroHeightIndexFinsetV1 atTop atTop := by
  apply nontrivial_zero_height_index_finset_mono_v1.tendsto_atTop_atTop
  intro s
  refine ⟨∑ rho ∈ s, |rho.1.im|, ?_⟩
  intro rho hrho
  apply mem_nontrivial_zero_height_index_finset_v1.mpr
  exact Finset.single_le_sum (fun z _ => abs_nonneg z.1.im) hrho

/-- The multiplicity-weighted Mellin summand, now indexed by the subtype of
nontrivial zeros. -/
def WeilZeroIndexSummandV1
    (f : ℝ → ℂ) (rho : RiemannNontrivialZeroIndexV2) : ℂ :=
  (analyticOrderNatAt riemannZeta rho.1 : ℂ) * mellin f rho.1

/-- The subtype-indexed finite-height sum is exactly the previously verified
complex-valued finite-height truncation. -/
theorem nontrivial_zero_height_index_sum_eq_truncated_v1
    (f : ℝ → ℂ) (T : ℝ) :
    (NontrivialZeroHeightIndexFinsetV1 T).sum (WeilZeroIndexSummandV1 f) =
      WeilZeroHeightTruncatedSumV1 f T := by
  classical
  rw [NontrivialZeroHeightIndexFinsetV1, Finset.sum_map]
  unfold WeilZeroHeightTruncatedSumV1
  change
    (∑ x ∈ (NontrivialZeroHeightFinsetV1 T).attach,
      (analyticOrderNatAt riemannZeta x.1 : ℂ) * mellin f x.1) =
    ∑ s ∈ NontrivialZeroHeightFinsetV1 T,
      (analyticOrderNatAt riemannZeta s : ℂ) * mellin f s
  exact Finset.sum_attach (NontrivialZeroHeightFinsetV1 T)
    (fun s : ℂ => (analyticOrderNatAt riemannZeta s : ℂ) * mellin f s)

/-- A genuine unconditional `HasSum` proof for the multiplicity-weighted
nontrivial-zero summand is sufficient to produce the verified symmetric-height
limit contract. This theorem does not construct such a `HasSum` proof. -/
theorem hasSum_implies_height_limit_v1
    {f : ℝ → ℂ} {L : ℂ}
    (hsum : HasSum (WeilZeroIndexSummandV1 f) L) :
    HasWeilZeroHeightLimitV1 f L := by
  have hindexed :
      Tendsto
        (fun T : ℝ =>
          (NontrivialZeroHeightIndexFinsetV1 T).sum
            (WeilZeroIndexSummandV1 f))
        atTop (𝓝 L) := by
    exact hsum.comp tendsto_nontrivial_zero_height_index_finset_atTop_v1
  unfold HasWeilZeroHeightLimitV1
  convert hindexed using 1
  funext T
  exact (nontrivial_zero_height_index_sum_eq_truncated_v1 f T).symm

#check RiemannNontrivialZeroIndexV2
#check NontrivialZeroHeightIndexFinsetV1
#check tendsto_nontrivial_zero_height_index_finset_atTop_v1
#check WeilZeroIndexSummandV1
#check nontrivial_zero_height_index_sum_eq_truncated_v1
#check hasSum_implies_height_limit_v1
#print axioms tendsto_nontrivial_zero_height_index_finset_atTop_v1
#print axioms nontrivial_zero_height_index_sum_eq_truncated_v1
#print axioms hasSum_implies_height_limit_v1
~~~~~~

## ZeroHeightLimitContractV1

Path: `source/ZeroHeightLimitContractV1.lean`

Original source lines: 1–46

Full file SHA256: `473f59be097bbc69d3482a351137638c2f8d9d2d4b6a62494f11b283150ab501`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroHeightLimitContractV1.lean

~~~~~~lean
import ZeroHeightFiniteSumV1

/-!
AEGIS Ω — symmetric height-limit contract for multiplicity-weighted zeta-zero sums v1.

This lane formalizes only what it means for the already verified finite,
multiplicity-weighted height truncations to converge as the height parameter
`T : ℝ` tends to `+∞`. It also proves that any such limit is unique.

It does not prove that a limit exists, does not replace this height convention
with an unordered infinite sum, and does not prove an explicit formula, the
critical-line statement, or RH.

HEIGHT_LIMIT_CONTRACT_ONLY
HEIGHT_LIMIT_EXISTENCE_OPEN
ZERO_SUM_CONVERGENCE_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Filter Topology

/-- `L` is the symmetric-height limit of the finite multiplicity-weighted
Mellin sums when `T → +∞`. -/
def HasWeilZeroHeightLimitV1 (f : ℝ → ℂ) (L : ℂ) : Prop :=
  Tendsto (fun T : ℝ => WeilZeroHeightTruncatedSumV1 f T) atTop (𝓝 L)

/-- Merely the proposition that a height-limit witness exists. This definition
asserts no theorem of existence. -/
def WeilZeroHeightLimitExistsV1 (f : ℝ → ℂ) : Prop :=
  ∃ L : ℂ, HasWeilZeroHeightLimitV1 f L

/-- If the height-limit contract holds for two candidate values, they are equal.
This proves uniqueness only, not existence. -/
theorem weil_zero_height_limit_unique_v1
    {f : ℝ → ℂ} {L M : ℂ}
    (hL : HasWeilZeroHeightLimitV1 f L)
    (hM : HasWeilZeroHeightLimitV1 f M) :
    L = M := by
  exact tendsto_nhds_unique hL hM

#check HasWeilZeroHeightLimitV1
#check WeilZeroHeightLimitExistsV1
#check weil_zero_height_limit_unique_v1
#print axioms weil_zero_height_limit_unique_v1
~~~~~~

## ZeroHeightFiniteSumV1

Path: `source/ZeroHeightFiniteSumV1.lean`

Original source lines: 1–243

Full file SHA256: `c980ebc8245e8bf9ef1b316e601edfe7c0d955c468018cfc1ff2a1bf86bc1431`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroHeightFiniteSumV1.lean

~~~~~~lean
import Mathlib.Analysis.Analytic.Order
import Mathlib.Analysis.Complex.Norm
import Mathlib.Analysis.MellinTransform
import Mathlib.NumberTheory.LSeries.HurwitzZetaValues
import Mathlib.NumberTheory.LSeries.Nonvanishing
import Mathlib.NumberTheory.LSeries.ZetaZeros

/-!
AEGIS Ω — multiplicity-safe finite height sum for nontrivial Riemann-zeta zeros v1.

This lane builds only a finite, height-bounded zero carrier and a finite
multiplicity-weighted Mellin sum over that carrier. Every multiplicity is the
natural analytic order of `riemannZeta` at the corresponding zero, with a
proof that the order is finite and strictly positive.

No infinite zero sum, convergence claim, limiting convention, explicit
formula, critical-line assertion, or RH implication is introduced here.

FINITE_HEIGHT_SUM_ONLY
HEIGHT_LIMIT_EXISTENCE_OPEN
ZERO_SUM_CONVERGENCE_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Filter Topology
open Complex

noncomputable section

private theorem zero_nonpos_is_neg_nat_height_sum_local_v1
    {s : ℂ} (hz : riemannZeta s = 0) (hre : s.re ≤ 0) :
    ∃ n : ℕ, s = -n := by
  by_contra hneg
  have hnotnat : ∀ n : ℕ, s ≠ -n := by
    intro n hsn
    exact hneg ⟨n, hsn⟩
  have hs1 : s ≠ 1 := by
    intro hs
    subst s
    exact (not_le_of_gt (zero_lt_one : (0 : ℝ) < 1)) (by simpa using hre)
  have hzero_reflected : riemannZeta (1 - s) = 0 := by
    rw [riemannZeta_one_sub hnotnat hs1, hz, mul_zero]
  have hge : 1 ≤ (1 - s).re := by
    simpa [sub_eq_add_neg] using
      (le_add_of_nonneg_right (neg_nonneg.mpr hre) : (1 : ℝ) ≤ 1 + (-s.re))
  exact (riemannZeta_ne_zero_of_one_le_re hge) hzero_reflected

private theorem bernoulli_two_mul_ne_zero_height_sum_local_v1
    (k : ℕ) (hk : k ≠ 0) : bernoulli (2 * k) ≠ 0 := by
  intro hB
  have hzeta0 : riemannZeta (2 * (k : ℂ)) = 0 := by
    rw [riemannZeta_two_mul_nat hk, hB]
    simp
  have hk1 : (1 : ℝ) ≤ (k : ℝ) := by
    exact_mod_cast Nat.one_le_iff_ne_zero.mpr hk
  have hge : (1 : ℝ) ≤ (2 * (k : ℂ)).re := by
    norm_num
    linarith
  exact (riemannZeta_ne_zero_of_one_le_re hge) hzeta0

private theorem zeta_neg_odd_ne_zero_height_sum_local_v1 (k : ℕ) :
    riemannZeta (-(((2 * k + 1 : ℕ) : ℂ))) ≠ 0 := by
  rw [riemannZeta_neg_nat_eq_bernoulli (2 * k + 1)]
  apply div_ne_zero
  · apply mul_ne_zero
    · exact pow_ne_zero _ (by norm_num)
    · have hb : bernoulli (2 * (k + 1)) ≠ 0 :=
        bernoulli_two_mul_ne_zero_height_sum_local_v1 (k + 1) (by omega)
      have hidx : (2 * k + 1) + 1 = 2 * (k + 1) := by omega
      rw [hidx]
      exact_mod_cast hb
  · exact_mod_cast (show (2 * k + 1) + 1 ≠ 0 by omega)

private theorem zeta_neg_nat_zero_iff_trivial_height_sum_local_v1 (n : ℕ) :
    riemannZeta (-(n : ℂ)) = 0 ↔ ∃ k : ℕ, n = 2 * (k + 1) := by
  constructor
  · intro hz
    by_cases hn : n = 0
    · subst n
      norm_num [riemannZeta_zero] at hz
    · rcases Nat.even_or_odd' n with ⟨k, rfl | rfl⟩
      · have hk : k ≠ 0 := by
          intro hk
          subst k
          simp at hn
        obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hk
        exact ⟨j, rfl⟩
      · exact ((zeta_neg_odd_ne_zero_height_sum_local_v1 k) hz).elim
  · rintro ⟨k, rfl⟩
    simpa [Nat.cast_mul, Nat.cast_add] using riemannZeta_neg_two_mul_nat_add_one k

private theorem zero_nonpos_is_trivial_height_sum_local_v1
    {s : ℂ} (hz : riemannZeta s = 0) (hre : s.re ≤ 0) :
    ∃ k : ℕ, s = -(2 : ℂ) * (k + 1) := by
  obtain ⟨n, hs⟩ := zero_nonpos_is_neg_nat_height_sum_local_v1 hz hre
  have hzn : riemannZeta (-(n : ℂ)) = 0 := by
    rw [← hs]
    exact hz
  obtain ⟨k, hnk⟩ := (zeta_neg_nat_zero_iff_trivial_height_sum_local_v1 n).mp hzn
  refine ⟨k, ?_⟩
  calc
    s = -(n : ℂ) := hs
    _ = -((2 * (k + 1) : ℕ) : ℂ) := by rw [hnk]
    _ = -(2 : ℂ) * (k + 1) := by push_cast; ring

private theorem nontrivial_zero_critical_strip_height_sum_local_v1
    {s : ℂ} (hz : riemannZeta s = 0)
    (hnontrivial : ¬ ∃ n : ℕ, s = -(2 : ℂ) * (n + 1)) :
    0 < s.re ∧ s.re < 1 := by
  constructor
  · by_contra hpos
    have hre : s.re ≤ 0 := le_of_not_gt hpos
    exact hnontrivial (zero_nonpos_is_trivial_height_sum_local_v1 hz hre)
  · by_contra hlt
    have hge : 1 ≤ s.re := le_of_not_gt hlt
    exact (riemannZeta_ne_zero_of_one_le_re hge) hz

/-- Nontrivial Riemann-zeta zeros with imaginary height at most `T`. -/
def NontrivialZeroHeightSetV1 (T : ℝ) : Set ℂ :=
  {s | riemannZeta s = 0 ∧
       (¬ ∃ n : ℕ, s = -(2 : ℂ) * (n + 1)) ∧
       |s.im| ≤ T}

private theorem nontrivial_zero_height_set_finite_sum_local_v1 (T : ℝ) :
    (NontrivialZeroHeightSetV1 T).Finite := by
  have hfinite :
      (Metric.closedBall (0 : ℂ) (T + 1) ∩ riemannZetaZeros).Finite :=
    IsCompact.inter_riemannZetaZeros_finite (isCompact_closedBall (0 : ℂ) (T + 1))
  refine hfinite.subset ?_
  intro s hs
  change riemannZeta s = 0 ∧
      (¬ ∃ n : ℕ, s = -(2 : ℂ) * (n + 1)) ∧ |s.im| ≤ T at hs
  rcases hs with ⟨hz, hnontrivial, him⟩
  have hstrip := nontrivial_zero_critical_strip_height_sum_local_v1 hz hnontrivial
  have hre_nonneg : 0 ≤ s.re := hstrip.1.le
  have hre_le : s.re ≤ 1 := hstrip.2.le
  constructor
  · simp only [Metric.mem_closedBall, dist_zero_right]
    calc
      ‖s‖ ≤ |s.re| + |s.im| := Complex.norm_le_abs_re_add_abs_im s
      _ = s.re + |s.im| := by rw [abs_of_nonneg hre_nonneg]
      _ ≤ 1 + T := add_le_add hre_le him
      _ = T + 1 := by ring
  · exact mem_riemannZetaZeros.mpr hz

/-- Canonical finite carrier obtained from the verified finite height set. -/
noncomputable def NontrivialZeroHeightFinsetV1 (T : ℝ) : Finset ℂ :=
  (nontrivial_zero_height_set_finite_sum_local_v1 T).toFinset

private theorem mem_nontrivial_zero_height_finset_v1 {T : ℝ} {s : ℂ} :
    s ∈ NontrivialZeroHeightFinsetV1 T ↔ s ∈ NontrivialZeroHeightSetV1 T := by
  simp [NontrivialZeroHeightFinsetV1]

/-- Natural analytic-order multiplicity used for each finite-height zero. -/
def HeightZeroMultiplicityV1 (s : ℂ) : ℕ :=
  analyticOrderNatAt riemannZeta s

private theorem riemannZeta_order_ne_top_at_height_zero_v1
    {T : ℝ} {s : ℂ} (hs : s ∈ NontrivialZeroHeightFinsetV1 T) :
    analyticOrderAt riemannZeta s ≠ ⊤ := by
  have hsSet : s ∈ NontrivialZeroHeightSetV1 T :=
    mem_nontrivial_zero_height_finset_v1.mp hs
  rcases hsSet with ⟨hz, hnontrivial, _him⟩
  have hstrip := nontrivial_zero_critical_strip_height_sum_local_v1 hz hnontrivial
  have hs1 : s ≠ 1 := by
    intro h
    subst s
    norm_num at hstrip
  intro htop
  have hlocal : riemannZeta =ᶠ[𝓝 s] (fun _ : ℂ => 0) := by
    filter_upwards [analyticOrderAt_eq_top.mp htop] with z hz'
    exact hz'
  have hsU : s ∈ ({1}ᶜ : Set ℂ) := by
    simpa using hs1
  have heq : Set.EqOn riemannZeta (fun _ : ℂ => 0) ({1}ᶜ : Set ℂ) :=
    analyticOn_riemannZeta.eqOn_of_preconnected_of_eventuallyEq
      analyticOnNhd_const
      (isConnected_compl_singleton_of_one_lt_rank (by simp) (1 : ℂ)).isPreconnected
      hsU hlocal
  have hzero : riemannZeta (0 : ℂ) = 0 := by
    simpa using heq (by simp : (0 : ℂ) ∈ ({1}ᶜ : Set ℂ))
  rw [riemannZeta_zero] at hzero
  norm_num at hzero

/-- Every member of the finite height carrier receives a strictly positive
analytic-order multiplicity. -/
theorem height_zero_multiplicity_pos_v1
    {T : ℝ} {s : ℂ} (hs : s ∈ NontrivialZeroHeightFinsetV1 T) :
    0 < HeightZeroMultiplicityV1 s := by
  have hsSet : s ∈ NontrivialZeroHeightSetV1 T :=
    mem_nontrivial_zero_height_finset_v1.mp hs
  rcases hsSet with ⟨hz, hnontrivial, _him⟩
  have hstrip := nontrivial_zero_critical_strip_height_sum_local_v1 hz hnontrivial
  have hs1 : s ≠ 1 := by
    intro h
    subst s
    norm_num at hstrip
  have hsU : s ∈ ({1}ᶜ : Set ℂ) := by
    simpa using hs1
  have hAn : AnalyticAt ℂ riemannZeta s :=
    analyticOn_riemannZeta s hsU
  have horder_ne0 : analyticOrderAt riemannZeta s ≠ 0 :=
    hAn.analyticOrderAt_ne_zero.mpr hz
  have horder_netop : analyticOrderAt riemannZeta s ≠ ⊤ :=
    riemannZeta_order_ne_top_at_height_zero_v1 hs
  apply Nat.pos_of_ne_zero
  intro hnat
  have hnat' : analyticOrderNatAt riemannZeta s = 0 := by
    simpa [HeightZeroMultiplicityV1] using hnat
  apply horder_ne0
  calc
    analyticOrderAt riemannZeta s =
        (analyticOrderNatAt riemannZeta s : ℕ∞) :=
      (Nat.cast_analyticOrderNatAt horder_netop).symm
    _ = 0 := by simp [hnat']

/-- Casting the finite-height multiplicity back to `ℕ∞` recovers the analytic
order exactly; no multiplicity information is discarded. -/
theorem height_zero_multiplicity_cast_eq_order_v1
    {T : ℝ} {s : ℂ} (hs : s ∈ NontrivialZeroHeightFinsetV1 T) :
    (HeightZeroMultiplicityV1 s : ℕ∞) = analyticOrderAt riemannZeta s := by
  unfold HeightZeroMultiplicityV1
  exact Nat.cast_analyticOrderNatAt (riemannZeta_order_ne_top_at_height_zero_v1 hs)

/-- Pointwise multiplicity-weighted Mellin contribution at one finite-height zero. -/
def WeilZeroHeightSummandV1 (f : ℝ → ℂ) (s : ℂ) : ℂ :=
  (HeightZeroMultiplicityV1 s : ℂ) * mellin f s

/-- Finite multiplicity-weighted Mellin sum over nontrivial zeros of height at
most `T`. This is deliberately a `Finset.sum`, not an infinite sum or limit. -/
noncomputable def WeilZeroHeightTruncatedSumV1 (f : ℝ → ℂ) (T : ℝ) : ℂ :=
  (NontrivialZeroHeightFinsetV1 T).sum (fun s => WeilZeroHeightSummandV1 f s)

#check NontrivialZeroHeightFinsetV1
#check HeightZeroMultiplicityV1
#check height_zero_multiplicity_pos_v1
#check height_zero_multiplicity_cast_eq_order_v1
#check WeilZeroHeightSummandV1
#check WeilZeroHeightTruncatedSumV1
#print axioms height_zero_multiplicity_pos_v1
#print axioms height_zero_multiplicity_cast_eq_order_v1
~~~~~~

## ZeroCriticalStripV1

Path: `source/ZeroCriticalStripV1.lean`

Original source lines: 1–118

Full file SHA256: `3e05b5e32f04354d88844f0cb4c44cdd1d2288e3444f6ed72e58bdd3d3f105a0`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/ZeroCriticalStripV1.lean

~~~~~~lean
import Mathlib.NumberTheory.LSeries.HurwitzZetaValues
import Mathlib.NumberTheory.LSeries.Nonvanishing

/-!
AEGIS Ω — critical-strip localization of nontrivial Riemann-zeta zeros v1.

This lane proves only the classical open-strip localization of nontrivial
Riemann-zeta zeros:

  riemannZeta s = 0 and s not a negative even integer
    implies 0 < Re(s) and Re(s) < 1.

The nontrivial-zero predicate is written in the same form as the pinned
Formal Conjectures / Mathlib `RiemannHypothesis` target. This theorem does not
place zeros on the critical line and does not prove the Riemann Hypothesis.

CRITICAL_STRIP_LOCALIZATION_ONLY
CRITICAL_LINE_RE_HALF_OPEN
EXPLICIT_FORMULA_OPEN
RH_EQUIVALENCE_OPEN
-/

open Complex

private theorem zero_nonpos_is_neg_nat_strip_local_v1
    {s : ℂ} (hz : riemannZeta s = 0) (hre : s.re ≤ 0) :
    ∃ n : ℕ, s = -n := by
  by_contra hneg
  have hnotnat : ∀ n : ℕ, s ≠ -n := by
    intro n hsn
    exact hneg ⟨n, hsn⟩
  have hs1 : s ≠ 1 := by
    intro hs
    subst s
    exact (not_le_of_gt (zero_lt_one : (0 : ℝ) < 1)) (by simpa using hre)
  have hzero_reflected : riemannZeta (1 - s) = 0 := by
    rw [riemannZeta_one_sub hnotnat hs1, hz, mul_zero]
  have hge : 1 ≤ (1 - s).re := by
    simpa [sub_eq_add_neg] using
      (le_add_of_nonneg_right (neg_nonneg.mpr hre) : (1 : ℝ) ≤ 1 + (-s.re))
  exact (riemannZeta_ne_zero_of_one_le_re hge) hzero_reflected

private theorem bernoulli_two_mul_ne_zero_strip_local_v1
    (k : ℕ) (hk : k ≠ 0) : bernoulli (2 * k) ≠ 0 := by
  intro hB
  have hzeta0 : riemannZeta (2 * (k : ℂ)) = 0 := by
    rw [riemannZeta_two_mul_nat hk, hB]
    simp
  have hk1 : (1 : ℝ) ≤ (k : ℝ) := by
    exact_mod_cast Nat.one_le_iff_ne_zero.mpr hk
  have hge : (1 : ℝ) ≤ (2 * (k : ℂ)).re := by
    norm_num
    linarith
  exact (riemannZeta_ne_zero_of_one_le_re hge) hzeta0

private theorem zeta_neg_odd_ne_zero_strip_local_v1 (k : ℕ) :
    riemannZeta (-(((2 * k + 1 : ℕ) : ℂ))) ≠ 0 := by
  rw [riemannZeta_neg_nat_eq_bernoulli (2 * k + 1)]
  apply div_ne_zero
  · apply mul_ne_zero
    · exact pow_ne_zero _ (by norm_num)
    · have hb : bernoulli (2 * (k + 1)) ≠ 0 :=
        bernoulli_two_mul_ne_zero_strip_local_v1 (k + 1) (by omega)
      have hidx : (2 * k + 1) + 1 = 2 * (k + 1) := by omega
      rw [hidx]
      exact_mod_cast hb
  · exact_mod_cast (show (2 * k + 1) + 1 ≠ 0 by omega)

private theorem zeta_neg_nat_zero_iff_trivial_strip_local_v1 (n : ℕ) :
    riemannZeta (-(n : ℂ)) = 0 ↔ ∃ k : ℕ, n = 2 * (k + 1) := by
  constructor
  · intro hz
    by_cases hn : n = 0
    · subst n
      norm_num [riemannZeta_zero] at hz
    · rcases Nat.even_or_odd' n with ⟨k, rfl | rfl⟩
      · have hk : k ≠ 0 := by
          intro hk
          subst k
          simp at hn
        obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hk
        exact ⟨j, rfl⟩
      · exact ((zeta_neg_odd_ne_zero_strip_local_v1 k) hz).elim
  · rintro ⟨k, rfl⟩
    simpa [Nat.cast_mul, Nat.cast_add] using riemannZeta_neg_two_mul_nat_add_one k

private theorem zero_nonpos_is_trivial_strip_local_v1
    {s : ℂ} (hz : riemannZeta s = 0) (hre : s.re ≤ 0) :
    ∃ k : ℕ, s = -(2 : ℂ) * (k + 1) := by
  obtain ⟨n, hs⟩ := zero_nonpos_is_neg_nat_strip_local_v1 hz hre
  have hzn : riemannZeta (-(n : ℂ)) = 0 := by
    rw [← hs]
    exact hz
  obtain ⟨k, hnk⟩ := (zeta_neg_nat_zero_iff_trivial_strip_local_v1 n).mp hzn
  refine ⟨k, ?_⟩
  calc
    s = -(n : ℂ) := hs
    _ = -((2 * (k + 1) : ℕ) : ℂ) := by rw [hnk]
    _ = -(2 : ℂ) * (k + 1) := by push_cast; ring

/-- Every nontrivial Riemann-zeta zero lies in the open critical strip.

This is the standard localization `0 < Re(s) < 1`, not the Riemann Hypothesis
claim `Re(s) = 1/2`. -/
theorem riemann_zeta_nontrivial_zero_critical_strip_v1
    {s : ℂ} (hz : riemannZeta s = 0)
    (hnontrivial : ¬ ∃ n : ℕ, s = -(2 : ℂ) * (n + 1)) :
    0 < s.re ∧ s.re < 1 := by
  constructor
  · by_contra hpos
    have hre : s.re ≤ 0 := le_of_not_gt hpos
    exact hnontrivial (zero_nonpos_is_trivial_strip_local_v1 hz hre)
  · by_contra hlt
    have hge : 1 ≤ s.re := le_of_not_gt hlt
    exact (riemannZeta_ne_zero_of_one_le_re hge) hz

#check riemann_zeta_nontrivial_zero_critical_strip_v1
#print axioms riemann_zeta_nontrivial_zero_critical_strip_v1
~~~~~~

## Lc.LiCriterion.HadamardSummabilityBridge

Path: `source/Lc/LiCriterion/HadamardSummabilityBridge.lean`

Original source lines: 1–66

Full file SHA256: `6dcd2437505ed6ba99830aceee02c07103aef9fa7b907bbf9ce0bed04f72d8f4`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Lc/LiCriterion/HadamardSummabilityBridge.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Lc.LiCriterion.Basic
import Hadamard.OrderOne.SummabilityMultiplicity

/-!
# Hadamard Summability Bridge

This file builds the clean bridge from Hadamard order-`≤ 1` hypotheses for `riemannXi`
to the genus-one summability statements used by the Li-criterion development.
-/

open Complex
open scoped Topology

namespace LiCriterion

/-- The nontrivial zeros of `ζ` viewed as a `Hadamard.ZeroSet` for `riemannXi`. -/
noncomputable def xiZeroSet : Hadamard.ZeroSet riemannXi where
  Zero := NontrivialZero
  z := fun ρ => ρ.val
  isZero := by
    intro ρ
    exact (xi_zeros_are_nontrivial_zeros (s := ρ.val)).2 ⟨ρ, rfl⟩

/-- Genus-1 summability from the order-`≤ 1` Hadamard hypotheses for `riemannXi`.

This is the clean replacement path for the old zero-counting bridge: use the multiplicity-aware
Hadamard summability theorem and then compare termwise with the unweighted series, noting that every
zero has multiplicity at least `1`. -/
theorem xi_weighted_genus_one_of_hadamard_order_one
    (hfinite : Hadamard.hasFiniteOrder riemannXi)
    (horder : Hadamard.order riemannXi ≤ 1) :
    Summable (fun ρ : NontrivialZero =>
      (analyticOrderNatAt riemannXi ρ.val : ℝ) / ‖ρ.val‖ ^ 2) := by
  let Z : Hadamard.ZeroSet riemannXi := xiZeroSet
  have : Countable Z.Zero := by
    dsimp [Z, xiZeroSet]
    infer_instance
  have h_zeros_only : ∀ s : ℂ, riemannXi s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ := by
    intro s
    simpa [Z, xiZeroSet] using (xi_zeros_are_nontrivial_zeros (s := s))
  have h_inj : Function.Injective Z.z := by
    intro ρ ρ' h
    exact Subtype.ext h
  have h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0 := by
    intro ρ
    simpa [Z, xiZeroSet] using ρ.ne_zero
  have hsum_mult :
      Summable
        (fun ρ : Z.Zero => (analyticOrderNatAt riemannXi (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2) :=
    Hadamard.OrderOne.summable_analyticOrderNatAt_div_norm_sq_of_order_le_one
      (f := riemannXi) (hf_entire := xi_entire) (hf_finite := hfinite) (hf_order_le := horder)
      (Z := Z) (h_zeros_only := h_zeros_only) (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero)
  simpa [Z, xiZeroSet] using hsum_mult

theorem xi_genus_one_of_hadamard_order_one
    (hfinite : Hadamard.hasFiniteOrder riemannXi)
    (horder : Hadamard.order riemannXi ≤ 1) :
    Summable (fun (ρ : NontrivialZero) => (1 : ℝ) / ‖ρ.val‖ ^ 2) := by
  exact genus_one_of_weighted_genus (xi_weighted_genus_one_of_hadamard_order_one hfinite horder)

end LiCriterion
~~~~~~

