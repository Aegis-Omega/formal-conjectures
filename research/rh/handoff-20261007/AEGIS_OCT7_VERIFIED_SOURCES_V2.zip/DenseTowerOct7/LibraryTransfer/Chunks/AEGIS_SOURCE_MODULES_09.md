# AEGIS source modules 9

Exact pinned or operator archive source. Compilation was not performed during transfer.

## WeilThreeBlockRationalV1

Path: `source/WeilThreeBlockRationalV1.lean`

Original source lines: 1–146

Full file SHA256: `f6076a2cb13107151c352675a8f460b18981c48c6158802b31b08b1e6b0f5eb6`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockRationalV1.lean

~~~~~~lean
import Mathlib.Data.Real.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Linarith

/-!
# Finite three-block rational budget

Source context: Aegis-Omega/AEGIS-OMEGA PR #494,
cf660498847634a5a45fc6c19644132be3ec8417.
Input receipt SHA-256:
649ec8b74944271593b68bb9a9584c691e19e72c524401eb3d2d1bdc91638cc2.

Scope: exact rational enclosures, a three-variable sum-of-squares identity,
and conditional finite quadratic-budget implications. The input receipt is
provenance, not a Lean premise or an oracle. Its analytic interpretations
are NOT established here.

There is no import of the repository Weil definitions, no identification
with an analytic Gram matrix, and no operator-norm theorem in this file.
Global Weil sign remains OPEN; RH remains NOT_PROVEN; authority_effect=NONE.
-/

noncomputable section
namespace AEGIS.WeilThreeBlockRationalV1

/-- Arithmetic on the proposed rational endpoints, not analytic enclosures. -/
theorem rational_enclosures :
    (103 : ℚ) / 100 < 32449 / 31500 ∧
    (1 : ℚ) / 2 + 75 / 9086 = 2309 / 4543 ∧
    (2309 : ℚ) / 4543 < 51 / 100 ∧
    (7 : ℚ) / 20 + 15 / 13216 = 23203 / 66080 ∧
    (23203 : ℚ) / 66080 < 9 / 25 := by
  norm_num

/-- M has off-diagonal entries (51/100, 9/25, 51/100), w=(1,11/10,1).
These are the three coordinates of (93/100)w-Mw. -/
theorem rational_schur_rows :
    (93 : ℚ) / 100 - ((51 : ℚ) / 100 * (11 / 10) + 9 / 25) = 9 / 1000 ∧
    (93 : ℚ) / 100 * (11 / 10) - (51 / 100 + 51 / 100) = 3 / 1000 ∧
    (93 : ℚ) / 100 - (9 / 25 + (51 : ℚ) / 100 * (11 / 10)) = 9 / 1000 := by
  norm_num

/-- Exact scalar budget subtraction and normalization. -/
theorem rational_budget :
    (103 : ℚ) / 100 - 93 / 100 = 1 / 10 ∧
    ((93 : ℚ) / 100) / (103 / 100) = 93 / 103 ∧
    (0 : ℚ) < 93 / 103 ∧
    (93 : ℚ) / 103 < 1 := by
  norm_num

def energy (x y z : ℝ) : ℝ := x ^ 2 + y ^ 2 + z ^ 2

def offdiagMajorant (x y z : ℝ) : ℝ :=
  2 * ((51 / 100 : ℝ) * x * y + (9 / 25 : ℝ) * x * z +
    (51 / 100 : ℝ) * y * z)

/-- This proves the finite Schur estimate directly, without spectral theory. -/
theorem schur_sos_identity (x y z : ℝ) :
    (93 / 100 : ℝ) * energy x y z - offdiagMajorant x y z =
      (51 / 11000 : ℝ) * (11 * x - 10 * y) ^ 2 +
      (9 / 25 : ℝ) * (x - z) ^ 2 +
      (51 / 11000 : ℝ) * (10 * y - 11 * z) ^ 2 +
      (9 / 1000 : ℝ) * x ^ 2 +
      (3 / 1100 : ℝ) * y ^ 2 +
      (9 / 1000 : ℝ) * z ^ 2 := by
  dsimp [energy, offdiagMajorant]
  ring

theorem energy_nonneg (x y z : ℝ) : 0 ≤ energy x y z := by
  unfold energy
  positivity

theorem offdiag_majorant_le (x y z : ℝ) :
    offdiagMajorant x y z ≤ (93 / 100 : ℝ) * energy x y z := by
  rw [← sub_nonneg, schur_sos_identity]
  positivity

/-- A finite diagonal lower bound, with all three entry bounds explicit. -/
theorem diagonal_budget_lower (d0 d1 d2 x y z : ℝ)
    (h0 : (103 / 100 : ℝ) ≤ d0)
    (h1 : (103 / 100 : ℝ) ≤ d1)
    (h2 : (103 / 100 : ℝ) ≤ d2) :
    (103 / 100 : ℝ) * energy x y z ≤ d0 * x ^ 2 + d1 * y ^ 2 + d2 * z ^ 2 := by
  have hx := mul_le_mul_of_nonneg_right h0 (sq_nonneg x)
  have hy := mul_le_mul_of_nonneg_right h1 (sq_nonneg y)
  have hz := mul_le_mul_of_nonneg_right h2 (sq_nonneg z)
  unfold energy
  nlinarith

/-- Conditional finite negativity margin; d and r are arbitrary real scalars.
Applying this to an analytic form requires separately proved hd and hr. -/
theorem finite_budget_margin (x y z d r : ℝ)
    (hd : (103 / 100 : ℝ) * energy x y z ≤ d)
    (hr : r ≤ offdiagMajorant x y z) :
    -d + r ≤ -(1 / 10 : ℝ) * energy x y z := by
  have hmajor := offdiag_majorant_le x y z
  linarith

/-- A relative quadratic-budget inequality, NOT an operator-norm statement. -/
theorem finite_abs_relative_budget (x y z d r : ℝ)
    (hd : (103 / 100 : ℝ) * energy x y z ≤ d)
    (hr : |r| ≤ offdiagMajorant x y z) :
    |r| ≤ (93 / 103 : ℝ) * d := by
  calc
    |r| ≤ offdiagMajorant x y z := hr
    _ ≤ (93 / 100 : ℝ) * energy x y z := offdiag_majorant_le x y z
    _ = (93 / 103 : ℝ) * ((103 / 100 : ℝ) * energy x y z) := by ring
    _ ≤ (93 / 103 : ℝ) * d := mul_le_mul_of_nonneg_left hd (by norm_num)

/-- Strictness requires positive energy; the zero vector is not excluded silently. -/
theorem strict_negative_of_energy_pos (x y z d r : ℝ)
    (hd : (103 / 100 : ℝ) * energy x y z ≤ d)
    (hr : r ≤ offdiagMajorant x y z)
    (hE : 0 < energy x y z) :
    -d + r < 0 := by
  have hmargin := finite_budget_margin x y z d r hd hr
  have hneg : -(1 / 10 : ℝ) * energy x y z < 0 :=
    mul_neg_of_neg_of_pos (by norm_num) hE
  exact lt_of_le_of_lt hmargin hneg

/-- The tighter fixed-vector value in the receipt is distinct from a uniform bound. -/
theorem all_ones_value :
    -(103 / 100 : ℝ) * energy 1 1 1 + offdiagMajorant 1 1 1 = -(33 / 100 : ℝ) := by
  norm_num [energy, offdiagMajorant]

/-- Regression witness: 9/10 is too small for this rational majorant. -/
theorem rate_nine_tenths_is_too_small :
    (9 / 10 : ℝ) * energy 10 11 10 < offdiagMajorant 10 11 10 := by
  norm_num [energy, offdiagMajorant]

end AEGIS.WeilThreeBlockRationalV1

#print axioms AEGIS.WeilThreeBlockRationalV1.rational_enclosures
#print axioms AEGIS.WeilThreeBlockRationalV1.rational_schur_rows
#print axioms AEGIS.WeilThreeBlockRationalV1.rational_budget
#print axioms AEGIS.WeilThreeBlockRationalV1.schur_sos_identity
#print axioms AEGIS.WeilThreeBlockRationalV1.energy_nonneg
#print axioms AEGIS.WeilThreeBlockRationalV1.offdiag_majorant_le
#print axioms AEGIS.WeilThreeBlockRationalV1.diagonal_budget_lower
#print axioms AEGIS.WeilThreeBlockRationalV1.finite_budget_margin
#print axioms AEGIS.WeilThreeBlockRationalV1.finite_abs_relative_budget
#print axioms AEGIS.WeilThreeBlockRationalV1.strict_negative_of_energy_pos
#print axioms AEGIS.WeilThreeBlockRationalV1.all_ones_value
#print axioms AEGIS.WeilThreeBlockRationalV1.rate_nine_tenths_is_too_small
~~~~~~

## WeilLogCoordinateIsometryV21

Path: `source/WeilLogCoordinateIsometryV21.lean`

Original source lines: 1–110

Full file SHA256: `841caff752466eeb81177a4672040f269df88d20531a038789cff07498671481`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilLogCoordinateIsometryV21.lean

~~~~~~lean
import WeilAutocorrelationClosureV1
import WeilDisjointEnergyV2
import Mathlib.MeasureTheory.Function.JacobianOneDim
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

/-!
AEGIS Ω — logarithmic-coordinate L2 isometry bridge V2.1

LOCAL CANDIDATE / FORMAL_MATH_EVIDENCE_ONLY / NOT_YET_KERNEL_REPLAYED.

For a repository packet `g`, define

  h(t) = exp(t/2) * g(exp t).

The intended certificate normalization is `H = ∫ ||h(t)||² dt`.
This module proves the change-of-variables statement needed to identify it
with the repository's ordinary Lebesgue L2 energy of `g`, using the actual
positive-support invariant of `WeilCompactSmoothGV1`.

It does NOT prove any diagonal/off-diagonal Weil estimate, global sign, or RH.
-/

open Set Function MeasureTheory Complex
open scoped ContDiff ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilLogCoordinateIsometryV21

open AEGIS.WeilDisjointEnergyV2

def logLift (g : ℝ → ℂ) (t : ℝ) : ℂ :=
  Complex.ofReal (Real.exp (t / 2)) * g (Real.exp t)

/-- Whole-line exponential substitution, derived directly from Mathlib's
one-dimensional Jacobian theorem. -/
theorem integral_exp_substitution (f : ℝ → ℝ) :
    (∫ t : ℝ, Real.exp t * f (Real.exp t)) =
      ∫ x in Ioi (0 : ℝ), f x := by
  have hcov :=
    MeasureTheory.integral_image_eq_integral_abs_deriv_smul
      (f := Real.exp)
      (f' := Real.exp)
      (s := Set.univ)
      MeasurableSet.univ
      (fun x _ => (Real.hasDerivAt_exp x).hasDerivWithinAt)
      (Set.injOn_of_injective Real.exp_injective)
      f
  have himage : Real.exp '' Set.univ = Ioi (0 : ℝ) := by
    rw [Set.image_univ, Real.range_exp]
  rw [himage] at hcov
  simpa [abs_of_pos (Real.exp_pos _)] using hcov.symm

theorem logLift_norm_sq (g : ℝ → ℂ) (t : ℝ) :
    ‖logLift g t‖ ^ 2 =
      Real.exp t * ‖g (Real.exp t)‖ ^ 2 := by
  have hexp :
      (Real.exp (t / 2)) ^ 2 = Real.exp t := by
    rw [pow_two, ← Real.exp_add]
    congr 1
    ring
  rw [logLift, norm_mul, Complex.norm_real]
  rw [Real.norm_of_nonneg (Real.exp_pos _).le, mul_pow, hexp]

/-- The certificate's additive-coordinate energy is exactly the positive-axis
energy of the multiplicative packet. -/
theorem logLift_energy_eq_positive_energy (g : ℝ → ℂ) :
    (∫ t : ℝ, ‖logLift g t‖ ^ 2) =
      ∫ x in Ioi (0 : ℝ), ‖g x‖ ^ 2 := by
  calc
    (∫ t : ℝ, ‖logLift g t‖ ^ 2)
        = ∫ t : ℝ, Real.exp t * ‖g (Real.exp t)‖ ^ 2 := by
            apply integral_congr_ae
            filter_upwards with t
            exact logLift_norm_sq g t
    _ = ∫ x in Ioi (0 : ℝ), ‖g x‖ ^ 2 :=
      integral_exp_substitution (fun x : ℝ => ‖g x‖ ^ 2)

/-- Because a repository Weil packet has topological support inside `(0,∞)`,
its full-line L2 energy equals its positive-axis L2 energy. -/
theorem packet_energy_eq_positive_energy (g : WeilCompactSmoothGV1) :
    energy g.1 = ∫ x in Ioi (0 : ℝ), ‖g.1 x‖ ^ 2 := by
  unfold energy
  simpa using
    (MeasureTheory.setIntegral_eq_of_subset_of_forall_sdiff_eq_zero
      (f := fun x : ℝ => ‖g.1 x‖ ^ 2)
      (s := Ioi (0 : ℝ))
      (t := Set.univ)
      MeasurableSet.univ
      (Set.subset_univ _)
      (by
        intro x hx
        have hxnot : x ∉ tsupport g.1 := by
          intro hxt
          exact hx.2 (g.2.2.2 hxt)
        have hg0 : g.1 x = 0 := image_eq_zero_of_notMem_tsupport hxnot
        simp [hg0]))

/-- Exact norm identification required by the quotient-free three-block work
order: `H = ||h||₂² = energy(g)`. -/
theorem logLift_energy_eq_packet_energy (g : WeilCompactSmoothGV1) :
    (∫ t : ℝ, ‖logLift g.1 t‖ ^ 2) = energy g.1 := by
  calc
    (∫ t : ℝ, ‖logLift g.1 t‖ ^ 2)
        = ∫ x in Ioi (0 : ℝ), ‖g.1 x‖ ^ 2 :=
      logLift_energy_eq_positive_energy g.1
    _ = energy g.1 := (packet_energy_eq_positive_energy g).symm

end AEGIS.WeilLogCoordinateIsometryV21
~~~~~~

## WeilDisjointEnergyV2

Path: `source/WeilDisjointEnergyV2.lean`

Original source lines: 1–74

Full file SHA256: `ffc7cf026d1d158663ebffecdf15e265e841e6b70c62cdf60f2365f9e2dccebe`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilDisjointEnergyV2.lean

~~~~~~lean
import WeilThreeBlockComplexV2
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic

/-! Exact L2-energy decomposition on three pointwise disjoint supports.
Integrability hypotheses are retained, not replaced by totalized integrals.
The logarithmic/multiplicative change of variables is not claimed here. -/
open MeasureTheory Complex
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilDisjointEnergyV2

def energy (f : ℝ → ℂ) : ℝ := ∫ t : ℝ, ‖f t‖ ^ 2 ∂volume

def l2 (f : ℝ → ℂ) : ℝ := Real.sqrt (energy f)

theorem energy_nonnegative (f : ℝ → ℂ) : 0 ≤ energy f :=
  integral_nonneg (fun _ => sq_nonneg _)

theorem square_l2 (f : ℝ → ℂ) : l2 f ^ 2 = energy f :=
  Real.sq_sqrt (energy_nonnegative f)

theorem disjoint_pointwise (z0 z1 z2 a b c : ℂ)
    (hab : a = 0 ∨ b = 0) (hac : a = 0 ∨ c = 0) (hbc : b = 0 ∨ c = 0) :
    ‖z0*a + z1*b + z2*c‖ ^ 2 =
      ‖z0‖ ^ 2 * ‖a‖ ^ 2 + ‖z1‖ ^ 2 * ‖b‖ ^ 2 + ‖z2‖ ^ 2 * ‖c‖ ^ 2 := by
  rcases hab with rfl | rfl
  · rcases hbc with rfl | rfl <;> simp [norm_mul, mul_pow]
  · rcases hac with rfl | rfl <;> simp [norm_mul, mul_pow]

theorem disjoint_integral (z0 z1 z2 : ℂ) (f0 f1 f2 : ℝ → ℂ)
    (h0 : Integrable (fun t => ‖f0 t‖ ^ 2) volume)
    (h1 : Integrable (fun t => ‖f1 t‖ ^ 2) volume)
    (h2 : Integrable (fun t => ‖f2 t‖ ^ 2) volume)
    (h01 : ∀ t, f0 t = 0 ∨ f1 t = 0)
    (h02 : ∀ t, f0 t = 0 ∨ f2 t = 0)
    (h12 : ∀ t, f1 t = 0 ∨ f2 t = 0) :
    energy (fun t => z0*f0 t + z1*f1 t + z2*f2 t) =
      ‖z0‖ ^ 2 * energy f0 + ‖z1‖ ^ 2 * energy f1 + ‖z2‖ ^ 2 * energy f2 := by
  unfold energy
  simp_rw [disjoint_pointwise z0 z1 z2 _ _ _ (h01 _) (h02 _) (h12 _)]
  have h0' : Integrable (fun t => ‖z0‖ ^ 2 * ‖f0 t‖ ^ 2) volume :=
    h0.const_mul _
  have h1' : Integrable (fun t => ‖z1‖ ^ 2 * ‖f1 t‖ ^ 2) volume :=
    h1.const_mul _
  have h2' : Integrable (fun t => ‖z2‖ ^ 2 * ‖f2 t‖ ^ 2) volume :=
    h2.const_mul _
  have hab :
      (∫ t : ℝ, ‖z0‖ ^ 2 * ‖f0 t‖ ^ 2 + ‖z1‖ ^ 2 * ‖f1 t‖ ^ 2 ∂volume) =
        (∫ t : ℝ, ‖z0‖ ^ 2 * ‖f0 t‖ ^ 2 ∂volume) +
          ∫ t : ℝ, ‖z1‖ ^ 2 * ‖f1 t‖ ^ 2 ∂volume := by
    simpa only [Pi.add_apply] using integral_add h0' h1'
  have habc :
      (∫ t : ℝ, (‖z0‖ ^ 2 * ‖f0 t‖ ^ 2 + ‖z1‖ ^ 2 * ‖f1 t‖ ^ 2) +
          ‖z2‖ ^ 2 * ‖f2 t‖ ^ 2 ∂volume) =
        (∫ t : ℝ, ‖z0‖ ^ 2 * ‖f0 t‖ ^ 2 + ‖z1‖ ^ 2 * ‖f1 t‖ ^ 2 ∂volume) +
          ∫ t : ℝ, ‖z2‖ ^ 2 * ‖f2 t‖ ^ 2 ∂volume := by
    simpa only [Pi.add_apply] using integral_add (h0'.add h1') h2'
  rw [habc, hab]
  simp only [integral_const_mul]

theorem quotient_free_norm_identity (z0 z1 z2 : ℂ) (f0 f1 f2 : ℝ → ℂ)
    (h0 : Integrable (fun t => ‖f0 t‖ ^ 2) volume)
    (h1 : Integrable (fun t => ‖f1 t‖ ^ 2) volume)
    (h2 : Integrable (fun t => ‖f2 t‖ ^ 2) volume)
    (h01 : ∀ t, f0 t = 0 ∨ f1 t = 0)
    (h02 : ∀ t, f0 t = 0 ∨ f2 t = 0)
    (h12 : ∀ t, f1 t = 0 ∨ f2 t = 0) :
    AEGIS.WeilThreeBlockComplexV2.weightedEnergy z0 z1 z2 (l2 f0) (l2 f1) (l2 f2) =
      energy (fun t => z0*f0 t + z1*f1 t + z2*f2 t) := by
  rw [AEGIS.WeilThreeBlockComplexV2.energy_expansion, square_l2, square_l2, square_l2]
  exact (disjoint_integral z0 z1 z2 f0 f1 f2 h0 h1 h2 h01 h02 h12).symm

end AEGIS.WeilDisjointEnergyV2
~~~~~~

## WeilThreeBlockAnalyticConstantsV21

Path: `source/WeilThreeBlockAnalyticConstantsV21.lean`

Original source lines: 1–148

Full file SHA256: `7d2d7bd21ef9b0bc812c9a98a975f8f559bbd5ed7b456ea756640762771fed5a`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockAnalyticConstantsV21.lean

~~~~~~lean
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.NumberTheory.Harmonic.EulerMascheroni
import Mathlib.Tactic

/-!
AEGIS Ω — elementary analytic constants for the three-block Weil certificate V2.1

LOCAL CANDIDATE / FORMAL_MATH_EVIDENCE_ONLY / NOT_YET_KERNEL_REPLAYED.

Purpose:
bind the elementary numerical inequalities used by the written width-1/32
three-block certificate directly to the pinned Mathlib surface.

This file proves no Weil sign by itself.  In particular it does NOT prove:
* the diagonal kernel inequality D/H >= ...;
* the separated moment-zero Archimedean estimate;
* the prime-window identification;
* global Weil nonpositivity or RH.
-/

open scoped BigOperators
noncomputable section

namespace AEGIS.WeilThreeBlockAnalyticConstantsV21

theorem log_two_lower :
    (693 : ℝ) / 1000 < Real.log 2 := by
  exact (by norm_num : (693 : ℝ) / 1000 < 0.6931471803).trans Real.log_two_gt_d9

theorem log_two_upper :
    Real.log 2 < (7 : ℝ) / 10 := by
  exact Real.log_two_lt_d9.trans (by norm_num)

theorem sqrt_two_lower :
    (7 : ℝ) / 5 < Real.sqrt 2 := by
  have hs : (Real.sqrt 2) ^ 2 = (2 : ℝ) := by
    simpa using Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have hn : 0 ≤ Real.sqrt 2 := Real.sqrt_nonneg _
  nlinarith

theorem exp_one_over_64_upper :
    Real.exp ((1 : ℝ) / 64) < (64 : ℝ) / 63 := by
  calc
    Real.exp ((1 : ℝ) / 64)
        < 1 / (1 - (1 : ℝ) / 64) :=
      Real.exp_bound_div_one_sub_of_interval' (by norm_num) (by norm_num)
    _ = (64 : ℝ) / 63 := by norm_num

theorem exp_five_over_64_upper :
    Real.exp ((5 : ℝ) / 64) < (64 : ℝ) / 59 := by
  calc
    Real.exp ((5 : ℝ) / 64)
        < 1 / (1 - (5 : ℝ) / 64) :=
      Real.exp_bound_div_one_sub_of_interval' (by norm_num) (by norm_num)
    _ = (64 : ℝ) / 59 := by norm_num

theorem exp_one_over_16_upper :
    Real.exp ((1 : ℝ) / 16) < (16 : ℝ) / 15 := by
  calc
    Real.exp ((1 : ℝ) / 16)
        < 1 / (1 - (1 : ℝ) / 16) :=
      Real.exp_bound_div_one_sub_of_interval' (by norm_num) (by norm_num)
    _ = (16 : ℝ) / 15 := by norm_num

/-- A small finite Taylor lower bound, used only to turn a π upper bound
into the certificate's `log (4π) < 633/250` inequality. -/
theorem exp_633_over_250_gt_88_over_7 :
    (88 : ℝ) / 7 < Real.exp ((633 : ℝ) / 250) := by
  have h :=
    Real.sum_le_exp_of_nonneg
      (by norm_num : (0 : ℝ) ≤ (633 : ℝ) / 250) 10
  have hs :
      (88 : ℝ) / 7 <
        ∑ i ∈ Finset.range 10,
          (((633 : ℝ) / 250) ^ i) / i.factorial := by
    norm_num [Finset.sum_range_succ, Nat.factorial_succ]
  exact hs.trans_le h

theorem log_four_pi_upper :
    Real.log (4 * Real.pi) < (633 : ℝ) / 250 := by
  rw [Real.log_lt_iff_lt_exp (mul_pos (by norm_num) Real.pi_pos)]
  calc
    (4 : ℝ) * Real.pi < 4 * 3.1416 :=
      mul_lt_mul_of_pos_left Real.pi_lt_d4 (by norm_num)
    _ < (88 : ℝ) / 7 := by norm_num
    _ < Real.exp ((633 : ℝ) / 250) := exp_633_over_250_gt_88_over_7

/-- Exact rational value used only to make the γ bound a small trusted-kernel
specialization of Mathlib's monotone Euler-Mascheroni upper sequence. -/
theorem harmonic_256_exact :
    harmonic 256 =
      (102120333780755602922415011407986918913493325085710168750386125102325162741298648605491283438121466698312402217 : ℚ) /
      (16674490806895842671659008751776385350270324508909651849955453691538889375930032935391666564679008085339616000 : ℚ) := by
  set_option maxRecDepth 100000 in
    norm_num [harmonic]

theorem euler_mascheroni_upper :
    Real.eulerMascheroniConstant < (29 : ℝ) / 50 := by
  have hγ := Real.eulerMascheroniConstant_lt_eulerMascheroniSeq' 256
  have hseq :
      Real.eulerMascheroniSeq' 256 =
        ((harmonic 256 : ℚ) : ℝ) - Real.log (256 : ℝ) := by
    set_option maxRecDepth 100000 in
      simp [Real.eulerMascheroniSeq']
  rw [hseq] at hγ
  have hlog256 : Real.log (256 : ℝ) = 8 * Real.log 2 := by
    calc
      Real.log (256 : ℝ) = Real.log ((2 : ℝ) ^ 8) := by norm_num
      _ = 8 * Real.log 2 := by rw [Real.log_pow]; norm_num
  rw [hlog256] at hγ
  have hH :
      (((harmonic 256 : ℚ) : ℝ) - 8 * (0.6931471803 : ℝ))
        < (29 : ℝ) / 50 := by
    rw [harmonic_256_exact]
    norm_num
  nlinarith [Real.log_two_gt_d9]

theorem prime_adjacent_scalar_upper :
    Real.log 2 / Real.sqrt 2 < (1 : ℝ) / 2 := by
  have hspos : 0 < Real.sqrt 2 := Real.sqrt_pos.2 (by norm_num)
  rw [div_lt_iff₀ hspos]
  nlinarith [log_two_upper, sqrt_two_lower]

theorem prime_outer_scalar_upper :
    Real.log 2 / 2 < (7 : ℝ) / 20 := by
  nlinarith [log_two_upper]

/-- The complete elementary constant margin needed after the analytic diagonal
kernel has been reduced to
`log(coth(1/64)) - log(4π) - γ - (1/64) exp(1/64)`.
No kernel identity is asserted here. -/
theorem diagonal_constant_floor :
    (32449 : ℝ) / 31500 <
      6 * Real.log 2
        - Real.log (4 * Real.pi)
        - Real.eulerMascheroniConstant
        - ((1 : ℝ) / 64) * Real.exp ((1 : ℝ) / 64) := by
  have hsmall :
      ((1 : ℝ) / 64) * Real.exp ((1 : ℝ) / 64) < (1 : ℝ) / 63 := by
    nlinarith [exp_one_over_64_upper]
  nlinarith [log_two_lower, log_four_pi_upper, euler_mascheroni_upper, hsmall]

theorem certificate_diagonal_threshold :
    (103 : ℝ) / 100 < (32449 : ℝ) / 31500 := by
  norm_num

end AEGIS.WeilThreeBlockAnalyticConstantsV21
~~~~~~

## WeilWidthPrimeVanishingV23

Path: `source/WeilWidthPrimeVanishingV23.lean`

Original source lines: 1–115

Full file SHA256: `64572986800a9f6476a9e98b3e94e4dbb2df73e7dbb9d11e402690b5f2bfaedd`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilWidthPrimeVanishingV23.lean

~~~~~~lean
import WeilThreeBlockTranslatedPacketsV22
import WeilAutocorrelationRealityV1
import WeilPrimeSummabilityV1
import Mathlib.Tactic

/-!
AEGIS Ω — width-1/32 diagonal prime vanishing V2.3

Parent exact head:
  7e3c85664c65faf1e02f6887c22b4350386a1af8

This module closes only the non-Archimedean diagonal term for the retained
width-1/32 packet family.  It proves directly from logarithmic support that the
repository autocorrelation vanishes at every x >= 2, then uses the already
verified reciprocal identity for x^{-1}.  Hence every repository prime term is
zero and the full prime `tsum` is zero.

No Archimedean inequality, cross-term majorant, global Weil sign, or RH is
proved here.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilWidthPrimeVanishingV23

open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilThreeBlockAnalyticConstantsV21

/-- Width-1/32 log support forces the multiplicative autocorrelation to vanish
at every scale x >= 2. -/
theorem autocorrelation_zero_of_ge_two
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    {x : ℝ} (hx : 2 ≤ x) :
    WeilAutocorrelationV1 g x = 0 := by
  unfold WeilAutocorrelationV1
  apply integral_eq_zero_of_ae
  filter_upwards [] with y
  by_cases hy : 0 < y
  · by_cases hgy : g.1 y = 0
    · simp [hgy]
    · by_cases hgxy : g.1 (x * y) = 0
      · simp [hgxy]
      · have hxpos : 0 < x := lt_of_lt_of_le (by norm_num) hx
        have hxypos : 0 < x * y := mul_pos hxpos hy
        have hylog :=
          log_mem_of_ne_zero g hw hy hgy
        have hxylog :=
          log_mem_of_ne_zero g hw hxypos hgxy
        have hlogmul :
            Real.log (x * y) = Real.log x + Real.log y := by
          rw [Real.log_mul hxpos.ne' hy.ne']
        rw [hlogmul] at hxylog
        have hlogx :
            (1 / 32 : ℝ) < Real.log x := by
          exact log_two_gt_one_thirty_two.trans_le
            (Real.log_le_log (by norm_num) hx)
        exfalso
        linarith [hylog.1, hylog.2, hxylog.1, hxylog.2, hlogx]
  · have hgy : g.1 y = 0 :=
      packet_eq_zero_of_nonpos g (le_of_not_gt hy)
    simp [hgy]

/-- The reciprocal autocorrelation sample also vanishes at every x >= 2. -/
theorem autocorrelation_inv_zero_of_ge_two
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    {x : ℝ} (hx : 2 ≤ x) :
    WeilAutocorrelationV1 g x⁻¹ = 0 := by
  have hxpos : 0 < x := lt_of_lt_of_le (by norm_num) hx
  rw [weil_autocorrelation_reciprocal_v1 g hxpos]
  rw [autocorrelation_zero_of_ge_two g a hw hx]
  simp

/-- Every positive-integer prime-power term on the diagonal is zero. -/
theorem diagonal_prime_term_zero
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (n : ℕ) :
    WeilPrimeTermV1 (WeilAutocorrelationV1 g) n = 0 := by
  by_cases hn : n = 0
  · subst n
    simp [WeilPrimeTermV1]
  · have hm : 2 ≤ n + 1 := by omega
    have hp :
        WeilAutocorrelationV1 g ((n + 1 : ℕ) : ℝ) = 0 :=
      autocorrelation_zero_of_ge_two g a hw (by exact_mod_cast hm)
    have hi :
        WeilAutocorrelationV1 g (((n + 1 : ℕ) : ℝ)⁻¹) = 0 :=
      autocorrelation_inv_zero_of_ge_two g a hw (by exact_mod_cast hm)
    unfold WeilPrimeTermV1
    change ((ArithmeticFunction.vonMangoldt (n + 1) : ℝ) : ℂ) *
      (WeilAutocorrelationV1 g ((n + 1 : ℕ) : ℝ) +
        (1 / ((n + 1 : ℕ) : ℂ)) *
          WeilAutocorrelationV1 g (((n + 1 : ℕ) : ℝ)⁻¹)) = 0
    rw [hp, hi]
    ring

/-- Width-1/32 diagonal prime vanishing in the ACTUAL repository explicit-formula term. -/
theorem diagonal_prime_sum_zero
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) :
    WeilPrimeSumV1 (WeilAutocorrelationV1 g) = 0 := by
  unfold WeilPrimeSumV1
  simp [diagonal_prime_term_zero g a hw]

#print axioms autocorrelation_zero_of_ge_two
#print axioms autocorrelation_inv_zero_of_ge_two
#print axioms diagonal_prime_term_zero
#print axioms diagonal_prime_sum_zero

end AEGIS.WeilWidthPrimeVanishingV23
~~~~~~

## WeilThreeBlockTranslatedPacketsV22

Path: `source/WeilThreeBlockTranslatedPacketsV22.lean`

Original source lines: 1–360

Full file SHA256: `f74b16c4562017458fc62d6a1a6d6a30e144e04fb5d78a6da1a360f2e4ff0993`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockTranslatedPacketsV22.lean

~~~~~~lean
import WeilLogCoordinateIsometryV21
import WeilThreeBlockAnalyticConstantsV21
import Mathlib.MeasureTheory.Function.JacobianOneDim
import Mathlib.MeasureTheory.Measure.Haar.Basic
import Mathlib.Tactic

/-!
AEGIS Ω — retained three-block translated packets V2.2.

Exact parent:
  Aegis-Omega/AEGIS-OMEGA@f86af1f59c3095ee13877dae7f91b3c5a8b637f4

Toolchain:
  Lean 4.33.1 / Mathlib 0df444a360eaa60ab8c11dca51a86af692955474

This module is deliberately narrow.  It reuses the already kernel-verified
V2/V2.1 carrier, norm bridge and analytic constants.  It adds only the special
translated-profile construction

  T_d g(x) = exp(-d/2) g(exp(-d)x)

used for the concrete shifts -log 2, 0, +log 2.  It proves carrier membership,
log-lift translation, support translation, repository moment preservation,
energy preservation, and pairwise disjointness for a common width-1/32 packet.

It does NOT prove any Archimedean B-bound, global Weil sign or RH.
-/

open Set Function MeasureTheory Complex
open scoped ContDiff ComplexConjugate
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilThreeBlockTranslatedPacketsV22

open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilThreeBlockAnalyticConstantsV21

def LogSupportIn (g : WeilCompactSmoothGV1) (lo hi : ℝ) : Prop :=
  tsupport (logLift g.1) ⊆ Icc lo hi

def WidthOneThirtyTwoAt (g : WeilCompactSmoothGV1) (a : ℝ) : Prop :=
  LogSupportIn g (a - (1 / 64 : ℝ)) (a + (1 / 64 : ℝ))

def translateFn (g : WeilCompactSmoothGV1) (d x : ℝ) : ℂ :=
  (Real.exp (-d / 2) : ℂ) * g.1 (Real.exp (-d) * x)

def translateEnvelope (g : WeilCompactSmoothGV1) (d : ℝ) : Set ℝ :=
  (fun y : ℝ => Real.exp d * y) '' tsupport g.1

theorem translateEnvelope_compact (g : WeilCompactSmoothGV1) (d : ℝ) :
    IsCompact (translateEnvelope g d) :=
  g.2.2.1.image (continuous_const.mul continuous_id)

theorem translateEnvelope_positive (g : WeilCompactSmoothGV1) (d : ℝ) :
    translateEnvelope g d ⊆ Ioi 0 := by
  rintro x ⟨y, hy, rfl⟩
  exact mul_pos (Real.exp_pos d) (g.2.2.2 hy)

theorem translate_tsupport_subset (g : WeilCompactSmoothGV1) (d : ℝ) :
    tsupport (translateFn g d) ⊆ translateEnvelope g d := by
  apply closure_minimal ?_ (translateEnvelope_compact g d).isClosed
  intro x hx
  by_contra hnot
  apply hx
  unfold translateFn
  have hg : g.1 (Real.exp (-d) * x) = 0 := by
    by_contra hgne
    apply hnot
    refine ⟨Real.exp (-d) * x, subset_tsupport _ hgne, ?_⟩
    calc
      Real.exp d * (Real.exp (-d) * x)
          = (Real.exp d * Real.exp (-d)) * x := by ring
      _ = x := by
        rw [← Real.exp_add]
        simp
  simp [hg]

theorem translate_hasCompactSupport (g : WeilCompactSmoothGV1) (d : ℝ) :
    HasCompactSupport (translateFn g d) :=
  (translateEnvelope_compact g d).of_isClosed_subset
    (isClosed_tsupport _) (translate_tsupport_subset g d)

theorem translate_tsupport_positive (g : WeilCompactSmoothGV1) (d : ℝ) :
    tsupport (translateFn g d) ⊆ Ioi 0 :=
  (translate_tsupport_subset g d).trans (translateEnvelope_positive g d)

theorem translate_contDiff (g : WeilCompactSmoothGV1) (d : ℝ) :
    ContDiff ℝ ∞ (translateFn g d) := by
  unfold translateFn
  exact contDiff_const.mul (g.2.1.comp (contDiff_const.mul contDiff_id))

def translatePacket (g : WeilCompactSmoothGV1) (d : ℝ) : WeilCompactSmoothGV1 :=
  ⟨translateFn g d, translate_contDiff g d,
    translate_hasCompactSupport g d, translate_tsupport_positive g d⟩

@[simp] theorem translatePacket_apply
    (g : WeilCompactSmoothGV1) (d x : ℝ) :
    (translatePacket g d).1 x =
      (Real.exp (-d / 2) : ℂ) * g.1 (Real.exp (-d) * x) := rfl

theorem logLift_translate (g : WeilCompactSmoothGV1) (d t : ℝ) :
    logLift (translatePacket g d).1 t = logLift g.1 (t - d) := by
  unfold logLift translatePacket translateFn
  dsimp
  have harg : Real.exp (-d) * Real.exp t = Real.exp (t - d) := by
    rw [← Real.exp_add]
    congr 1
    ring
  rw [harg]
  have hscalar :
      (Real.exp (t / 2) : ℂ) * (Real.exp (-d / 2) : ℂ) =
        (Real.exp ((t - d) / 2) : ℂ) := by
    rw [← Complex.ofReal_mul, ← Real.exp_add]
    congr 1
    ring
  rw [← mul_assoc, hscalar]

theorem log_mem_of_ne_zero
    (g : WeilCompactSmoothGV1) {lo hi x : ℝ}
    (hI : LogSupportIn g lo hi) (hx : 0 < x) (hg : g.1 x ≠ 0) :
    Real.log x ∈ Icc lo hi := by
  have hLift : logLift g.1 (Real.log x) ≠ 0 := by
    unfold logLift
    rw [Real.exp_log hx]
    exact mul_ne_zero (by simp) hg
  exact hI (subset_tsupport _ hLift)

theorem packet_eq_zero_of_nonpos
    (g : WeilCompactSmoothGV1) {x : ℝ} (hx : x ≤ 0) : g.1 x = 0 := by
  apply image_eq_zero_of_notMem_tsupport
  intro hmem
  exact (not_lt_of_ge hx) (g.2.2.2 hmem)

theorem translate_logSupportIn
    (g : WeilCompactSmoothGV1) (d lo hi : ℝ)
    (hI : LogSupportIn g lo hi) :
    LogSupportIn (translatePacket g d) (lo + d) (hi + d) := by
  unfold LogSupportIn
  apply closure_minimal ?_ isClosed_Icc
  intro t ht
  have hne : logLift (translatePacket g d).1 t ≠ 0 := ht
  rw [logLift_translate] at hne
  have hm : t - d ∈ tsupport (logLift g.1) := subset_tsupport _ hne
  have h := hI hm
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

theorem pointwise_disjoint_of_log_intervals
    (p q : WeilCompactSmoothGV1)
    {plo phi qlo qhi : ℝ}
    (hp : LogSupportIn p plo phi)
    (hq : LogSupportIn q qlo qhi)
    (hsep : phi < qlo) :
    ∀ x : ℝ, p.1 x = 0 ∨ q.1 x = 0 := by
  intro x
  by_cases hx : 0 < x
  · by_cases hlog : Real.log x ≤ phi
    · right
      by_contra hq0
      have hm := log_mem_of_ne_zero q hq hx hq0
      linarith [hm.1]
    · left
      by_contra hp0
      have hm := log_mem_of_ne_zero p hp hx hp0
      linarith [hm.2]
  · left
    exact packet_eq_zero_of_nonpos p (le_of_not_gt hx)

theorem integral_exp_substitution_complex (f : ℝ → ℂ) :
    (∫ x in Ioi (0 : ℝ), f x) =
      ∫ t : ℝ, (Real.exp t) • f (Real.exp t) := by
  have h :=
    MeasureTheory.integral_image_eq_integral_abs_deriv_smul
      (s := (Set.univ : Set ℝ))
      (f := Real.exp) (f' := Real.exp)
      MeasurableSet.univ
      (fun x _ => (Real.hasDerivAt_exp x).hasDerivWithinAt)
      Real.exp_injective.injOn f
  simpa [Set.image_univ, Real.range_exp, abs_of_pos (Real.exp_pos _)] using h

def logMomentMinus (g : WeilCompactSmoothGV1) : ℂ :=
  ∫ t : ℝ, (Real.exp (-t / 2) : ℂ) * logLift g.1 t

def logMomentPlus (g : WeilCompactSmoothGV1) : ℂ :=
  ∫ t : ℝ, (Real.exp (t / 2) : ℂ) * logLift g.1 t

theorem logMomentMinus_eq_repository (g : WeilCompactSmoothGV1) :
    logMomentMinus g = ∫ x in Ioi (0 : ℝ), g.1 x / (x : ℂ) := by
  unfold logMomentMinus
  rw [integral_exp_substitution_complex]
  apply integral_congr_ae
  filter_upwards [] with t
  unfold logLift
  rw [Complex.real_smul]
  have he : (Real.exp t : ℂ) ≠ 0 := by simp
  field_simp
  have hreal : Real.exp (-(t / 2)) * Real.exp (t / 2) = 1 := by
    rw [← Real.exp_add]
    have hz : -(t / 2) + t / 2 = 0 := by ring
    rw [hz, Real.exp_zero]
  have hcomplex :
      (Real.exp (-(t / 2)) : ℂ) * (Real.exp (t / 2) : ℂ) = 1 := by
    exact_mod_cast hreal
  change ((Real.exp (-(t / 2)) : ℂ) * (Real.exp (t / 2) : ℂ)) *
      g.1 (Real.exp t) = g.1 (Real.exp t)
  rw [hcomplex, one_mul]

theorem logMomentPlus_eq_repository (g : WeilCompactSmoothGV1) :
    logMomentPlus g = ∫ x in Ioi (0 : ℝ), g.1 x := by
  unfold logMomentPlus
  rw [integral_exp_substitution_complex]
  apply integral_congr_ae
  filter_upwards [] with t
  unfold logLift
  rw [Complex.real_smul]
  have h :
      (Real.exp (t / 2) : ℂ) * (Real.exp (t / 2) : ℂ) =
        (Real.exp t : ℂ) := by
    rw [← Complex.ofReal_mul, ← Real.exp_add]
    congr 1
    ring
  rw [← mul_assoc, h]

theorem translate_preserves_moments
    (g : WeilCompactSmoothGV1) (d : ℝ)
    (hm : WeilMomentConditionsV1 g) :
    WeilMomentConditionsV1 (translatePacket g d) := by
  have hmMinus : logMomentMinus g = 0 := by
    rw [logMomentMinus_eq_repository]
    exact hm.1
  have hmPlus : logMomentPlus g = 0 := by
    rw [logMomentPlus_eq_repository]
    exact hm.2
  have hMinus : logMomentMinus (translatePacket g d) =
      (Real.exp (-d / 2) : ℂ) * logMomentMinus g := by
    unfold logMomentMinus
    simp_rw [logLift_translate]
    calc
      (∫ t : ℝ, (Real.exp (-t / 2) : ℂ) * logLift g.1 (t - d))
          = ∫ t : ℝ, (Real.exp (-d / 2) : ℂ) *
              ((Real.exp (-(t - d) / 2) : ℂ) * logLift g.1 (t - d)) := by
              apply integral_congr_ae
              filter_upwards [] with t
              have hs : Real.exp (-t / 2) =
                  Real.exp (-d / 2) * Real.exp (-(t - d) / 2) := by
                rw [← Real.exp_add]
                congr 1
                ring
              rw [show (Real.exp (-t / 2) : ℂ) =
                  (Real.exp (-d / 2) : ℂ) *
                    (Real.exp (-(t - d) / 2) : ℂ) by exact_mod_cast hs]
              ring
      _ = (Real.exp (-d / 2) : ℂ) *
            ∫ t : ℝ, (Real.exp (-(t - d) / 2) : ℂ) * logLift g.1 (t - d) := by
              rw [integral_const_mul]
      _ = (Real.exp (-d / 2) : ℂ) * logMomentMinus g := by
              unfold logMomentMinus
              congr 1
              simpa [sub_eq_add_neg] using
                (integral_add_right_eq_self
                  (fun s : ℝ => (Real.exp (-s / 2) : ℂ) * logLift g.1 s) (-d))
  have hPlus : logMomentPlus (translatePacket g d) =
      (Real.exp (d / 2) : ℂ) * logMomentPlus g := by
    unfold logMomentPlus
    simp_rw [logLift_translate]
    calc
      (∫ t : ℝ, (Real.exp (t / 2) : ℂ) * logLift g.1 (t - d))
          = ∫ t : ℝ, (Real.exp (d / 2) : ℂ) *
              ((Real.exp ((t - d) / 2) : ℂ) * logLift g.1 (t - d)) := by
              apply integral_congr_ae
              filter_upwards [] with t
              have hs : Real.exp (t / 2) =
                  Real.exp (d / 2) * Real.exp ((t - d) / 2) := by
                rw [← Real.exp_add]
                congr 1
                ring
              rw [show (Real.exp (t / 2) : ℂ) =
                  (Real.exp (d / 2) : ℂ) *
                    (Real.exp ((t - d) / 2) : ℂ) by exact_mod_cast hs]
              ring
      _ = (Real.exp (d / 2) : ℂ) *
            ∫ t : ℝ, (Real.exp ((t - d) / 2) : ℂ) * logLift g.1 (t - d) := by
              rw [integral_const_mul]
      _ = (Real.exp (d / 2) : ℂ) * logMomentPlus g := by
              unfold logMomentPlus
              congr 1
              simpa [sub_eq_add_neg] using
                (integral_add_right_eq_self
                  (fun s : ℝ => (Real.exp (s / 2) : ℂ) * logLift g.1 s) (-d))
  constructor
  · rw [← logMomentMinus_eq_repository, hMinus, hmMinus, mul_zero]
  · rw [← logMomentPlus_eq_repository, hPlus, hmPlus, mul_zero]

theorem translate_energy (g : WeilCompactSmoothGV1) (d : ℝ) :
    energy (translatePacket g d).1 = energy g.1 := by
  rw [← logLift_energy_eq_packet_energy (translatePacket g d)]
  rw [← logLift_energy_eq_packet_energy g]
  simp_rw [logLift_translate]
  simpa [sub_eq_add_neg] using
    (integral_add_right_eq_self
      (fun s : ℝ => ‖logLift g.1 s‖ ^ 2) (-d))

def gMinus (g : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  translatePacket g (-Real.log 2)

def gZero (g : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  translatePacket g 0

def gPlus (g : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  translatePacket g (Real.log 2)

theorem log_two_gt_one_thirty_two : (1 / 32 : ℝ) < Real.log 2 := by
  exact (show (1 / 32 : ℝ) < 693 / 1000 by norm_num).trans log_two_lower

theorem three_blocks_preserve_moments
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g) :
    WeilMomentConditionsV1 (gMinus g) ∧
    WeilMomentConditionsV1 (gZero g) ∧
    WeilMomentConditionsV1 (gPlus g) := by
  exact ⟨translate_preserves_moments g (-Real.log 2) hm,
    translate_preserves_moments g 0 hm,
    translate_preserves_moments g (Real.log 2) hm⟩

theorem three_blocks_energy
    (g : WeilCompactSmoothGV1) :
    energy (gMinus g).1 = energy g.1 ∧
    energy (gZero g).1 = energy g.1 ∧
    energy (gPlus g).1 = energy g.1 := by
  exact ⟨translate_energy g (-Real.log 2), translate_energy g 0,
    translate_energy g (Real.log 2)⟩

theorem three_blocks_pairwise_disjoint
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) :
    (∀ x : ℝ, (gMinus g).1 x = 0 ∨ (gZero g).1 x = 0) ∧
    (∀ x : ℝ, (gMinus g).1 x = 0 ∨ (gPlus g).1 x = 0) ∧
    (∀ x : ℝ, (gZero g).1 x = 0 ∨ (gPlus g).1 x = 0) := by
  have hminus := translate_logSupportIn g (-Real.log 2)
    (a - (1 / 64 : ℝ)) (a + (1 / 64 : ℝ)) hw
  have hzero := translate_logSupportIn g 0
    (a - (1 / 64 : ℝ)) (a + (1 / 64 : ℝ)) hw
  have hplus := translate_logSupportIn g (Real.log 2)
    (a - (1 / 64 : ℝ)) (a + (1 / 64 : ℝ)) hw
  have hgap := log_two_gt_one_thirty_two
  constructor
  · apply pointwise_disjoint_of_log_intervals (gMinus g) (gZero g) hminus hzero
    linarith [hgap]
  constructor
  · apply pointwise_disjoint_of_log_intervals (gMinus g) (gPlus g) hminus hplus
    linarith [hgap]
  · apply pointwise_disjoint_of_log_intervals (gZero g) (gPlus g) hzero hplus
    linarith [hgap]

#print axioms logLift_translate
#print axioms translate_preserves_moments
#print axioms translate_energy
#print axioms three_blocks_pairwise_disjoint

end AEGIS.WeilThreeBlockTranslatedPacketsV22
~~~~~~

## WeilArchimedeanCothTailV1

Path: `source/WeilArchimedeanCothTailV1.lean`

Original source lines: 1–177

Full file SHA256: `531b53a53d2ef864f9b071791ed5c0a9f028a62cdc283f4475baf7b9d73b0bd7`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilArchimedeanCothTailV1.lean

~~~~~~lean
/-
AEGIS Ω — the `coth` tail of the archimedean diagonal kernel, V1.

`WeilThreeBlockAnalyticConstantsV21` closes the numeric margin of the diagonal
threshold once the archimedean diagonal kernel has been reduced to

    log (coth (1/64)) - log (4π) - γ - (1/64) * exp (1/64)

and its docstring is explicit that "no kernel identity is asserted here".
The `log (coth (1/64))` there is a tail integral: in the log coordinate
`x = exp u` the archimedean denominator `x - x⁻¹` is `2 sinh u`, and outside the
packet's log-support the autocorrelation vanishes, leaving

    ∫_{w}^{∞} du / sinh u = log (coth (w/2)).

This module proves that identity and connects it to the constant the
certificate consumes. Mathlib 0df444a3 has no `coth` and no `∫ 1 / sinh`, so
both are built here from `exp`/`log` only.

What this module does NOT do: it does not prove the archimedean diagonal lower
bound `(103/100) ‖g‖² ≤ -Re (B g g)`, it does not identify this tail with the
kernel of `WeilArchimedeanIntegrandV1` for a concrete packet, and it proves
nothing about the Weil criterion or RH. It supplies one reusable analytic
ingredient of that reduction, nothing more.
-/
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Exponential
import Mathlib.Tactic

open Set Filter MeasureTheory Real
open scoped Topology

namespace AEGIS.WeilArchimedeanCothTailV1

/-- Antiderivative of `1 / sinh` on `(0, ∞)`, written with `exp`/`log` only
(Mathlib 0df444a3 has no `coth`). -/
noncomputable def cothPrim (u : ℝ) : ℝ :=
  Real.log (1 - Real.exp (-u)) - Real.log (1 + Real.exp (-u))

theorem exp_neg_lt_one {u : ℝ} (hu : 0 < u) : Real.exp (-u) < 1 := by
  rw [Real.exp_lt_one_iff]; linarith

theorem cothPrim_hasDerivAt {u : ℝ} (hu : 0 < u) :
    HasDerivAt cothPrim (1 / Real.sinh u) u := by
  have hp : (0 : ℝ) < Real.exp (-u) := Real.exp_pos _
  have hlt : Real.exp (-u) < 1 := exp_neg_lt_one hu
  have h1 : (1 : ℝ) - Real.exp (-u) ≠ 0 := by linarith
  have h2 : (1 : ℝ) + Real.exp (-u) ≠ 0 := by positivity
  have he : HasDerivAt (fun t : ℝ => Real.exp (-t)) (-Real.exp (-u)) u := by
    simpa using ((hasDerivAt_id u).neg).exp
  have hA : HasDerivAt (fun t : ℝ => Real.log (1 - Real.exp (-t)))
      (Real.exp (-u) / (1 - Real.exp (-u))) u := by
    simpa using (((hasDerivAt_const u (1 : ℝ)).sub he).log h1)
  have hB : HasDerivAt (fun t : ℝ => Real.log (1 + Real.exp (-t)))
      (-Real.exp (-u) / (1 + Real.exp (-u))) u := by
    simpa using (((hasDerivAt_const u (1 : ℝ)).add he).log h2)
  have hinv : Real.exp u = (Real.exp (-u))⁻¹ := by
    rw [Real.exp_neg, inv_inv]
  have hgt : (1 : ℝ) < Real.exp u := by
    have := Real.add_one_le_exp u
    linarith
  have hsq : (1 : ℝ) - Real.exp (-u) ^ 2 ≠ 0 := by nlinarith
  have key :
      Real.exp (-u) / (1 - Real.exp (-u)) - -Real.exp (-u) / (1 + Real.exp (-u))
        = 1 / Real.sinh u := by
    rw [Real.sinh_eq, hinv]
    have hne : (Real.exp (-u))⁻¹ - Real.exp (-u) ≠ 0 := by
      rw [← hinv]; intro h; nlinarith
    field_simp [h1, h2, hne, hsq]
    ring
  show HasDerivAt
    (fun t : ℝ => Real.log (1 - Real.exp (-t)) - Real.log (1 + Real.exp (-t)))
    (1 / Real.sinh u) u
  rw [← key]
  exact hA.sub hB

theorem cothPrim_tendsto_atTop : Tendsto cothPrim atTop (𝓝 0) := by
  have he : Tendsto (fun u : ℝ => Real.exp (-u)) atTop (𝓝 0) :=
    Real.tendsto_exp_neg_atTop_nhds_zero
  have hA : Tendsto (fun u : ℝ => Real.log (1 - Real.exp (-u))) atTop (𝓝 0) := by
    have h : Tendsto (fun u : ℝ => 1 - Real.exp (-u)) atTop (𝓝 1) := by
      simpa using tendsto_const_nhds.sub he
    simpa [Function.comp_def] using
      (Real.continuousAt_log (by norm_num : (1:ℝ) ≠ 0)).tendsto.comp h
  have hB : Tendsto (fun u : ℝ => Real.log (1 + Real.exp (-u))) atTop (𝓝 0) := by
    have h : Tendsto (fun u : ℝ => 1 + Real.exp (-u)) atTop (𝓝 1) := by
      simpa using tendsto_const_nhds.add he
    simpa [Function.comp_def] using
      (Real.continuousAt_log (by norm_num : (1:ℝ) ≠ 0)).tendsto.comp h
  show Tendsto
    (fun u : ℝ => Real.log (1 - Real.exp (-u)) - Real.log (1 + Real.exp (-u)))
    atTop (𝓝 0)
  simpa using hA.sub hB

theorem sinh_pos_of_pos {u : ℝ} (hu : 0 < u) : 0 < Real.sinh u := by
  rw [Real.sinh_eq]
  have : Real.exp (-u) < Real.exp u := Real.exp_lt_exp.mpr (by linarith)
  linarith

/-- **The tail integral of `1 / sinh`.**  For `w > 0`,
`∫_w^∞ du / sinh u = log ((1 + e^{-w}) / (1 - e^{-w})) = log (coth (w/2))`. -/
theorem integral_one_div_sinh_Ioi {w : ℝ} (hw : 0 < w) :
    (∫ u in Ioi w, 1 / Real.sinh u)
      = Real.log ((1 + Real.exp (-w)) / (1 - Real.exp (-w))) := by
  have hderiv : ∀ u ∈ Ici w, HasDerivAt cothPrim (1 / Real.sinh u) u := fun u hu =>
    cothPrim_hasDerivAt (lt_of_lt_of_le hw hu)
  have hpos : ∀ u ∈ Ioi w, 0 ≤ 1 / Real.sinh u := by
    intro u hu
    have := sinh_pos_of_pos (lt_trans hw hu)
    positivity
  rw [integral_Ioi_of_hasDerivAt_of_nonneg' hderiv hpos cothPrim_tendsto_atTop]
  have hlt : Real.exp (-w) < 1 := exp_neg_lt_one hw
  have h1 : (0 : ℝ) < 1 - Real.exp (-w) := by linarith
  have h2 : (0 : ℝ) < 1 + Real.exp (-w) := by positivity
  rw [Real.log_div (ne_of_gt h2) (ne_of_gt h1)]
  simp [cothPrim]

/-- `exp (1/32) < 65/63`, via the degree-3 Taylor bound.  The margin is
`65 * 147456 - 152137 * 63 = 9`, so the cubic term is genuinely needed. -/
theorem exp_one_div_32_lt : Real.exp (1 / 32) < 65 / 63 := by
  have h := Real.exp_bound (x := (1 / 32 : ℝ)) (by norm_num) (n := 3) (by norm_num)
  rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_succ,
    Finset.sum_range_zero] at h
  norm_num at h
  rw [abs_le] at h
  linarith [h.2]

theorem exp_neg_one_div_32_gt : (63 : ℝ) / 65 < Real.exp (-(1 / 32)) := by
  have hpos : (0 : ℝ) < Real.exp (1 / 32) := Real.exp_pos _
  have hlt := exp_one_div_32_lt
  rw [Real.exp_neg]
  rw [lt_inv_comm₀ (by norm_num) hpos]
  calc Real.exp (1 / 32) < 65 / 65 * (65 / 63) := by
        rw [show (65:ℝ)/65 = 1 by norm_num, one_mul]; exact hlt
    _ = ((63 : ℝ) / 65)⁻¹ := by norm_num

/-- The coth ratio at half-width `1/64` exceeds `64 = 2 ^ 6`. -/
theorem coth_ratio_gt_64 :
    (64 : ℝ) < (1 + Real.exp (-(1 / 32))) / (1 - Real.exp (-(1 / 32))) := by
  set a := Real.exp (-(1 / 32)) with ha
  have h63 : (63 : ℝ) / 65 < a := exp_neg_one_div_32_gt
  have hlt1 : a < 1 := by
    rw [ha, Real.exp_lt_one_iff]; norm_num
  have hden : (0 : ℝ) < 1 - a := by linarith
  rw [lt_div_iff₀ hden]
  linarith

/-- **Bridge to the certificate constant.**  The `1/sinh` tail at `w = 1/32`,
which equals `log (coth (1/64))`, is strictly above the `6 * log 2` that
`WeilThreeBlockAnalyticConstantsV21.diagonal_constant_floor` uses. -/
theorem six_log_two_lt_log_coth_ratio :
    6 * Real.log 2
      < Real.log ((1 + Real.exp (-(1 / 32))) / (1 - Real.exp (-(1 / 32)))) := by
  have h64 : Real.log 64 = 6 * Real.log 2 := by
    rw [show (64 : ℝ) = 2 ^ (6 : ℕ) by norm_num, Real.log_pow]
    norm_num
  rw [← h64]
  exact Real.log_lt_log (by norm_num) coth_ratio_gt_64

/-- **Punchline.**  At the certificate's packet half-width `w = 1/32`, the
`1 / sinh` tail — that is `log (coth (1/64))` — strictly exceeds the `6 * log 2`
used by `WeilThreeBlockAnalyticConstantsV21.diagonal_constant_floor`. -/
theorem six_log_two_lt_integral_one_div_sinh_Ioi :
    6 * Real.log 2 < ∫ u in Ioi (1 / 32 : ℝ), 1 / Real.sinh u := by
  rw [integral_one_div_sinh_Ioi (by norm_num : (0:ℝ) < 1 / 32)]
  simpa using six_log_two_lt_log_coth_ratio

end AEGIS.WeilArchimedeanCothTailV1

#print axioms AEGIS.WeilArchimedeanCothTailV1.cothPrim_hasDerivAt
#print axioms AEGIS.WeilArchimedeanCothTailV1.cothPrim_tendsto_atTop
#print axioms AEGIS.WeilArchimedeanCothTailV1.integral_one_div_sinh_Ioi
#print axioms AEGIS.WeilArchimedeanCothTailV1.exp_one_div_32_lt
#print axioms AEGIS.WeilArchimedeanCothTailV1.coth_ratio_gt_64
#print axioms AEGIS.WeilArchimedeanCothTailV1.six_log_two_lt_log_coth_ratio
#print axioms AEGIS.WeilArchimedeanCothTailV1.six_log_two_lt_integral_one_div_sinh_Ioi
~~~~~~

## WeilThreeBlockNormBridgeV21

Path: `source/WeilThreeBlockNormBridgeV21.lean`

Original source lines: 1–135

Full file SHA256: `a17d2a02bcce1785cee0060367c7efe3cbafddbb729a1a8f525518bb421dd520`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockNormBridgeV21.lean

~~~~~~lean
import WeilMixedAlgebraV2
import WeilDisjointEnergyV2

/-!
AEGIS Ω — three-block actual L2 norm bridge V2.1

LOCAL CANDIDATE / FORMAL_MATH_EVIDENCE_ONLY / NOT_YET_KERNEL_REPLAYED.

This module closes only the finite norm/correspondence step:
* compact-smooth Weil packets have integrable squared norm;
* for three pointwise-disjoint packets, the rational certificate's
  `weightedEnergy` is exactly the ordinary L2 energy of the ACTUAL
  `WeilMixedAlgebraV2.combo`;
* therefore the already proved `actual_three_block_bound` can be stated
  directly against that actual combo energy.

It does NOT prove any of the six analytic diagonal/off-diagonal estimates.
It does NOT prove moment conditions, full Weil negativity, the full Weil
criterion, or RH.
-/

open Set Function MeasureTheory Complex
open scoped ContDiff ComplexConjugate
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilThreeBlockNormBridgeV21

open AEGIS.WeilMixedAlgebraV2
open AEGIS.WeilThreeBlockComplexV2
open AEGIS.WeilDisjointEnergyV2

/-- A compact-smooth packet has an integrable squared norm on the real line. -/
theorem packet_energy_integrable (g : WeilCompactSmoothGV1) :
    Integrable (fun t : ℝ => ‖g.1 t‖ ^ 2) volume := by
  have hc : Continuous (fun t : ℝ => ‖g.1 t‖ ^ 2) := by
    exact g.2.1.continuous.norm.pow 2
  have hk : HasCompactSupport (fun t : ℝ => ‖g.1 t‖ ^ 2) := by
    apply HasCompactSupport.intro g.2.2.1
    intro t ht
    simp [image_eq_zero_of_notMem_tsupport ht]
  exact hc.integrable_of_hasCompactSupport hk

/--
For pointwise-disjoint packets, the exact finite certificate energy is the
ordinary L2 energy of the actual packet combination used by the repository
mixed Weil form.
-/
theorem combo_energy_identity
    (z0 z1 z2 : ℂ)
    (g0 g1 g2 : WeilCompactSmoothGV1)
    (h01 : ∀ t : ℝ, g0.1 t = 0 ∨ g1.1 t = 0)
    (h02 : ∀ t : ℝ, g0.1 t = 0 ∨ g2.1 t = 0)
    (h12 : ∀ t : ℝ, g1.1 t = 0 ∨ g2.1 t = 0) :
    weightedEnergy z0 z1 z2 (l2 g0.1) (l2 g1.1) (l2 g2.1) =
      energy (combo z0 z1 z2 g0 g1 g2).1 := by
  have h :=
    quotient_free_norm_identity
      z0 z1 z2 g0.1 g1.1 g2.1
      (packet_energy_integrable g0)
      (packet_energy_integrable g1)
      (packet_energy_integrable g2)
      h01 h02 h12
  simpa [combo, addPacket, scalePacket] using h

/--
The current six analytic estimates imply the actual repository Weil RHS bound
with no abstract `r_i`: each scale is the actual L2 norm of its packet.
-/
theorem actual_three_block_l2_bound
    (z0 z1 z2 : ℂ)
    (g0 g1 g2 : WeilCompactSmoothGV1)
    (h01disj : ∀ t : ℝ, g0.1 t = 0 ∨ g1.1 t = 0)
    (h02disj : ∀ t : ℝ, g0.1 t = 0 ∨ g2.1 t = 0)
    (h12disj : ∀ t : ℝ, g1.1 t = 0 ∨ g2.1 t = 0)
    (h0 :
      (103 / 100 : ℝ) * (l2 g0.1) ^ 2 ≤ -(B g0 g0).re)
    (h1 :
      (103 / 100 : ℝ) * (l2 g1.1) ^ 2 ≤ -(B g1 g1).re)
    (h2 :
      (103 / 100 : ℝ) * (l2 g2.1) ^ 2 ≤ -(B g2 g2).re)
    (h01 :
      ‖B g0 g1‖ ≤ (51 / 100 : ℝ) * l2 g0.1 * l2 g1.1)
    (h02 :
      ‖B g0 g2‖ ≤ (9 / 25 : ℝ) * l2 g0.1 * l2 g2.1)
    (h12 :
      ‖B g1 g2‖ ≤ (51 / 100 : ℝ) * l2 g1.1 * l2 g2.1) :
    (WeilExplicitRightSideV1
      (WeilAutocorrelationV1 (combo z0 z1 z2 g0 g1 g2))).re ≤
      -(1 / 10 : ℝ) * energy (combo z0 z1 z2 g0 g1 g2).1 := by
  calc
    (WeilExplicitRightSideV1
      (WeilAutocorrelationV1 (combo z0 z1 z2 g0 g1 g2))).re
        ≤ -(1 / 10 : ℝ) *
            weightedEnergy z0 z1 z2 (l2 g0.1) (l2 g1.1) (l2 g2.1) :=
      actual_three_block_bound
        z0 z1 z2 g0 g1 g2
        (l2 g0.1) (l2 g1.1) (l2 g2.1)
        h0 h1 h2 h01 h02 h12
    _ = -(1 / 10 : ℝ) * energy (combo z0 z1 z2 g0 g1 g2).1 := by
      rw [combo_energy_identity z0 z1 z2 g0 g1 g2 h01disj h02disj h12disj]

/--
Strict negativity follows only after an explicit positive-energy premise.
This remains a finite three-packet statement, not global Weil negativity.
-/
theorem actual_three_block_strict_negative_of_energy_pos
    (z0 z1 z2 : ℂ)
    (g0 g1 g2 : WeilCompactSmoothGV1)
    (h01disj : ∀ t : ℝ, g0.1 t = 0 ∨ g1.1 t = 0)
    (h02disj : ∀ t : ℝ, g0.1 t = 0 ∨ g2.1 t = 0)
    (h12disj : ∀ t : ℝ, g1.1 t = 0 ∨ g2.1 t = 0)
    (h0 :
      (103 / 100 : ℝ) * (l2 g0.1) ^ 2 ≤ -(B g0 g0).re)
    (h1 :
      (103 / 100 : ℝ) * (l2 g1.1) ^ 2 ≤ -(B g1 g1).re)
    (h2 :
      (103 / 100 : ℝ) * (l2 g2.1) ^ 2 ≤ -(B g2 g2).re)
    (h01 :
      ‖B g0 g1‖ ≤ (51 / 100 : ℝ) * l2 g0.1 * l2 g1.1)
    (h02 :
      ‖B g0 g2‖ ≤ (9 / 25 : ℝ) * l2 g0.1 * l2 g2.1)
    (h12 :
      ‖B g1 g2‖ ≤ (51 / 100 : ℝ) * l2 g1.1 * l2 g2.1)
    (hE : 0 < energy (combo z0 z1 z2 g0 g1 g2).1) :
    (WeilExplicitRightSideV1
      (WeilAutocorrelationV1 (combo z0 z1 z2 g0 g1 g2))).re < 0 := by
  have hbound :=
    actual_three_block_l2_bound
      z0 z1 z2 g0 g1 g2
      h01disj h02disj h12disj
      h0 h1 h2 h01 h02 h12
  nlinarith

end AEGIS.WeilThreeBlockNormBridgeV21
~~~~~~

## RHKreinCriticalLineBridgeV1

Path: `source/RHKreinCriticalLineBridgeV1.lean`

Original source lines: 1–95

Full file SHA256: `904c0d0132b19950986a6d1b79bdb407acdf3d1d1839336f52c6f8c1b43af28c`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinCriticalLineBridgeV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import WeilAutocorrelationMellinV11
import RHKreinPairingV13
import Mathlib.Tactic

/-!
# Critical-line Mellin/Fourier normalization for the RH Krein lane

Mathlib's real Fourier transform uses exp(-2*pi*i*x*xi), while the AEGIS
Krein numerics use angular frequency t in exp(i*t*x).  This file pins the
conversion xi = -t/(2*pi) and then identifies the Mellin transform of the
multiplicative autocorrelation on the critical line with the Fourier
norm-square of the logarithmic lift.

No sign theorem and no RH conclusion is asserted here.
-/

open MeasureTheory FourierTransform Complex
open scoped ComplexConjugate

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinCriticalLineBridgeV1

open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilPairedZeroEvaluationV9
open AEGIS.WeilAutocorrelationMellinV11

/-- Critical-line Mellin transform equals the Mathlib Fourier transform of the
unitary logarithmic lift at the scaled frequency -t/(2*pi). -/
theorem critical_mellin_eq_fourier_scaled_v1
    (g : WeilCompactSmoothGV1) (t : ℝ) :
    mellin g.1 (((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) =
      𝓕 (logLift g.1) (-t / (2 * Real.pi)) := by
  rw [mellin_eq_log_integral_v9, Real.fourier_real_eq_integral_exp_smul]
  apply integral_congr_ae
  filter_upwards [] with u
  unfold WeilLogMellinIntegrandV9 logLift
  simp only [smul_eq_mul]
  have hphase :
      -2 * Real.pi * u * (-t / (2 * Real.pi)) = t * u := by
    field_simp [Real.pi_ne_zero]
  rw [hphase]
  have hexp :
      Complex.exp
          ((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ)) =
        Complex.exp (((t * u : ℝ) : ℂ) * I) *
          (Real.exp (u / 2) : ℂ) := by
    rw [Complex.ofReal_exp, ← Complex.exp_add]
    congr 1
    push_cast
    ring
  rw [hexp]
  ring

/-- On the critical line the reflected Mellin factor is the same factor. -/
theorem critical_reflection_v1 (t : ℝ) :
    1 - conj ((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I)) =
      (((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) := by
  apply Complex.ext <;> norm_num

/-- The actual repository multiplicative autocorrelation has critical-line
Mellin transform equal to the Fourier norm-square of the logarithmic lift,
with the exact Mathlib 2*pi frequency normalization exposed. -/
theorem autocorrelation_mellin_critical_normSq_v1
    (g : WeilCompactSmoothGV1) (t : ℝ) :
    mellin (WeilAutocorrelationV1 g)
        (((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) =
      ((Complex.normSq
        (𝓕 (logLift g.1) (-t / (2 * Real.pi))) : ℝ) : ℂ) := by
  rw [weil_autocorrelation_mellin_factorization_v11]
  rw [critical_reflection_v1 t]
  rw [critical_mellin_eq_fourier_scaled_v1]
  rw [Complex.mul_conj]

#print axioms AEGIS.RHKreinCriticalLineBridgeV1.critical_mellin_eq_fourier_scaled_v1
#print axioms AEGIS.RHKreinCriticalLineBridgeV1.autocorrelation_mellin_critical_normSq_v1

end AEGIS.RHKreinCriticalLineBridgeV1
~~~~~~

## WeilAutocorrelationMellinV11

Path: `source/WeilAutocorrelationMellinV11.lean`

Original source lines: 1–319

Full file SHA256: `e7e7d43007c753d388b689aa7e1b011100fe215190cb0bacbda86cc74ea9dcd0`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilAutocorrelationMellinV11.lean

~~~~~~lean
import WeilPairedZeroEvaluationV9
import WeilWidthArchCorrelationV25
import WeilAutocorrelationClosureV1
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.Tactic

/-!
AEGIS Ω — full Mellin factorization of multiplicative autocorrelation V11.

For a repository packet g, put

  h(u) = exp(u/2) g(exp u),
  C_g(t) = ∫ h(v+t) conj(h(v)) dv,
  H_g(z) = ∫ exp(z u) h(u) du.

This module proves the bilateral correlation-transform identity

  ∫ exp(z t) C_g(t) dt
    = H_g(z) * conj(H_g(-conj z)),

using a genuine product-integrability/Fubini proof on the compact log-support.

Combining this with the existing log-coordinate Mellin representation and
the multiplicative/log autocorrelation identity gives, for every s : ℂ,

  mellin (WeilAutocorrelationV1 g) s
    = mellin g s * conj (mellin g (1 - conj s)).

This is the load-bearing zero-side factorization used by the restricted
Weil-criterion contrapositive.  No sign or RH conclusion is asserted here.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology Function MeasureTheory Complex
open scoped BigOperators ComplexConjugate

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilAutocorrelationMellinV11

open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilWidthArchCorrelationV25
open AEGIS.WeilPairedZeroEvaluationV9

/-- Centered bilateral Mellin/Laplace transform of the logarithmic packet. -/
def WeilCenteredTransformV11
    (g : WeilCompactSmoothGV1) (z : ℂ) : ℂ :=
  ∫ u : ℝ,
    Complex.exp (z * (u : ℂ)) * logLift g.1 u

/-- Exact relation between the centered transform and the repository Mellin
transform. -/
theorem centered_transform_eq_mellin_v11
    (g : WeilCompactSmoothGV1) (z : ℂ) :
    WeilCenteredTransformV11 g z =
      mellin g.1 (z + (1 / 2 : ℂ)) := by
  rw [mellin_eq_log_integral_v9]
  unfold WeilCenteredTransformV11 WeilLogMellinIntegrandV9 logLift
  apply integral_congr_ae
  filter_upwards [] with u
  have hexp :
      Complex.exp ((z + (1 / 2 : ℂ)) * (u : ℂ)) =
        Complex.exp (z * (u : ℂ)) *
          (Real.exp (u / 2) : ℂ) := by
    rw [show
      (z + (1 / 2 : ℂ)) * (u : ℂ) =
        z * (u : ℂ) + ((u / 2 : ℝ) : ℂ) by
          push_cast
          ring,
      Complex.exp_add,
      ← Complex.ofReal_exp]
  rw [hexp]
  ring

private theorem logLift_continuous_v11
    (g : WeilCompactSmoothGV1) :
    Continuous (logLift g.1) := by
    have hg : Continuous g.1 := g.2.1.continuous
    unfold logLift
    fun_prop

/-- Public compact-support fact for the logarithmic packet. -/
theorem logLift_hasCompactSupport_v11
    (g : WeilCompactSmoothGV1) :
    HasCompactSupport (logLift g.1) := by
  let K : Set ℝ := Real.log '' tsupport g.1
  have hK : IsCompact K := by
    have hlog : ContinuousOn Real.log (tsupport g.1) := by
      intro x hx
      exact
        (Real.continuousAt_log
          (ne_of_gt (g.2.2.2 hx))).continuousWithinAt
    exact g.2.2.1.image_of_continuousOn hlog
  apply HasCompactSupport.of_support_subset_isCompact hK
  intro u hu
  have hne : g.1 (Real.exp u) ≠ 0 := by
    intro hz
    apply hu
    simp [logLift, hz]
  have hm : Real.exp u ∈ tsupport g.1 := subset_tsupport _ hne
  exact ⟨Real.exp u, hm, Real.log_exp u⟩

/-- Joint kernel whose two iterated integrals are exchanged in the
correlation-transform proof. -/
def WeilCenteredCorrelationJointV11
    (g : WeilCompactSmoothGV1) (z : ℂ) (p : ℝ × ℝ) : ℂ :=
  Complex.exp (z * (p.1 : ℂ)) *
    logLift g.1 (p.2 + p.1) *
      conj (logLift g.1 p.2)

/-- Absolute product-integrability of the centered correlation kernel for every
complex spectral parameter.  Compact support, not a strip estimate, carries
the proof. -/
theorem centered_correlation_joint_integrable_v11
    (g : WeilCompactSmoothGV1) (z : ℂ) :
    Integrable (WeilCenteredCorrelationJointV11 g z)
      (volume.prod volume) := by
  let K : Set ℝ := tsupport (logLift g.1)
  let J : Set (ℝ × ℝ) :=
    (fun p : ℝ × ℝ => (p.1 - p.2, p.2)) '' (K ×ˢ K)
  have hK : IsCompact K := (logLift_hasCompactSupport_v11 g)
  have hJ : IsCompact J := by
    apply hK.prod hK |>.image
    fun_prop
  have hcont : Continuous (WeilCenteredCorrelationJointV11 g z) := by
    unfold WeilCenteredCorrelationJointV11
    exact
      ((by fun_prop :
        Continuous (fun p : ℝ × ℝ =>
          Complex.exp (z * (p.1 : ℂ)))).mul
        ((logLift_continuous_v11 g).comp
          (continuous_snd.add continuous_fst))).mul
        (continuous_conj.comp
          ((logLift_continuous_v11 g).comp continuous_snd))
  have hsupp :
      tsupport (WeilCenteredCorrelationJointV11 g z) ⊆ J := by
    apply closure_minimal ?_ hJ.isClosed
    intro p hp
    have hleft : logLift g.1 (p.2 + p.1) ≠ 0 := by
      intro hz
      apply hp
      simp [WeilCenteredCorrelationJointV11, hz]
    have hright : logLift g.1 p.2 ≠ 0 := by
      intro hz
      apply hp
      simp [WeilCenteredCorrelationJointV11, hz]
    have hl : p.2 + p.1 ∈ K := subset_tsupport _ hleft
    have hr : p.2 ∈ K := subset_tsupport _ hright
    refine ⟨(p.2 + p.1, p.2), ⟨hl, hr⟩, ?_⟩
    apply Prod.ext <;> simp <;> ring
  exact hcont.integrable_of_hasCompactSupport
    (hJ.of_isClosed_subset (isClosed_tsupport _) hsupp)

/-- Inner-u transform at fixed v. -/
private theorem centered_correlation_inner_u_v11
    (g : WeilCompactSmoothGV1) (z : ℂ) (v : ℝ) :
    (∫ u : ℝ,
      Complex.exp (z * (u : ℂ)) *
        logLift g.1 (v + u) *
          conj (logLift g.1 v)) =
      WeilCenteredTransformV11 g z *
        (Complex.exp (-(z * (v : ℂ))) *
          conj (logLift g.1 v)) := by
  let F : ℝ → ℂ := fun w =>
    Complex.exp (z * (w : ℂ)) * logLift g.1 w
  have hshift :
      (∫ u : ℝ,
        Complex.exp (z * (u : ℂ)) *
          logLift g.1 (v + u)) =
        Complex.exp (-(z * (v : ℂ))) *
          WeilCenteredTransformV11 g z := by
    calc
      (∫ u : ℝ,
        Complex.exp (z * (u : ℂ)) *
          logLift g.1 (v + u))
        =
      ∫ u : ℝ,
        Complex.exp (-(z * (v : ℂ))) * F (u + v) := by
          apply integral_congr_ae
          filter_upwards [] with u
          dsimp [F]
          rw [← mul_assoc, ← Complex.exp_add, add_comm u v]
          congr 2
          push_cast
          ring
      _ =
        Complex.exp (-(z * (v : ℂ))) *
          (∫ u : ℝ, F (u + v)) := by
            rw [integral_const_mul]
      _ =
        Complex.exp (-(z * (v : ℂ))) *
          (∫ u : ℝ, F u) := by
            rw [integral_add_right_eq_self F v]
      _ =
        Complex.exp (-(z * (v : ℂ))) *
          WeilCenteredTransformV11 g z := by
            rfl
  rw [integral_mul_const, hshift]
  ring

/-- Conjugated reflected centered transform. -/
private theorem reflected_centered_transform_v11
    (g : WeilCompactSmoothGV1) (z : ℂ) :
    (∫ v : ℝ,
      Complex.exp (-(z * (v : ℂ))) *
        conj (logLift g.1 v)) =
      conj (WeilCenteredTransformV11 g (-conj z)) := by
  rw [WeilCenteredTransformV11, ← integral_conj]
  apply integral_congr_ae
  filter_upwards [] with v
  rw [map_mul, ← Complex.exp_conj]
  congr 2
  simp [map_neg, map_mul, Complex.conj_ofReal]

/-- Bilateral transform of the log-autocorrelation factors exactly. -/
theorem centered_correlation_transform_factorization_v11
    (g : WeilCompactSmoothGV1) (z : ℂ) :
    (∫ u : ℝ,
      Complex.exp (z * (u : ℂ)) *
        logCorrelationV25 g u) =
      WeilCenteredTransformV11 g z *
        conj (WeilCenteredTransformV11 g (-conj z)) := by
  have hprod := centered_correlation_joint_integrable_v11 g z
  calc
    (∫ u : ℝ,
      Complex.exp (z * (u : ℂ)) *
        logCorrelationV25 g u)
      =
    ∫ u : ℝ,
      ∫ v : ℝ,
        WeilCenteredCorrelationJointV11 g z (u, v) := by
          apply integral_congr_ae
          filter_upwards [] with u
          unfold logCorrelationV25 WeilCenteredCorrelationJointV11
          rw [← integral_const_mul]
          congr 1
          funext v
          simp only
          ring
    _ =
    ∫ v : ℝ,
      ∫ u : ℝ,
        WeilCenteredCorrelationJointV11 g z (u, v) := by
          exact integral_integral_swap
            (f := fun u v => WeilCenteredCorrelationJointV11 g z (u, v))
            (by simpa [Function.uncurry_def] using hprod)
    _ =
    ∫ v : ℝ,
      WeilCenteredTransformV11 g z *
        (Complex.exp (-(z * (v : ℂ))) *
          conj (logLift g.1 v)) := by
          apply integral_congr_ae
          filter_upwards [] with v
          unfold WeilCenteredCorrelationJointV11
          simpa [add_comm, mul_assoc] using
            centered_correlation_inner_u_v11 g z v
    _ =
      WeilCenteredTransformV11 g z *
        (∫ v : ℝ,
          Complex.exp (-(z * (v : ℂ))) *
            conj (logLift g.1 v)) := by
              rw [integral_const_mul]
    _ =
      WeilCenteredTransformV11 g z *
        conj (WeilCenteredTransformV11 g (-conj z)) := by
              rw [reflected_centered_transform_v11]

/-- Full Mellin factorization of the repository autocorrelation, valid for
every complex s. -/
theorem weil_autocorrelation_mellin_factorization_v11
    (g : WeilCompactSmoothGV1) (s : ℂ) :
    mellin (WeilAutocorrelationV1 g) s =
      mellin g.1 s *
        conj (mellin g.1 (1 - conj s)) := by
  let A := WeilAutocorrelationCompactSmoothV1 g
  have hlog :=
    mellin_eq_log_integral_v9 A s
  have hcorr :
      (∫ u : ℝ,
        WeilLogMellinIntegrandV9 A s u) =
      ∫ u : ℝ,
        Complex.exp ((s - (1 / 2 : ℂ)) * (u : ℂ)) *
          logCorrelationV25 g u := by
    apply integral_congr_ae
    filter_upwards [] with u
    unfold WeilLogMellinIntegrandV9
    rw [show A.1 (Real.exp u) = WeilAutocorrelationV1 g (Real.exp u) by rfl]
    rw [logCorrelation_eq_autocorrelation_v25]
    have he :
        (Real.exp (u / 2) : ℂ) ≠ 0 := by simp
    field_simp [he]
    have hsplit :
        Complex.exp (s * (u : ℂ)) =
          Complex.exp ((u : ℂ) * (s * 2 - 1) / 2) *
            Complex.exp (((u / 2 : ℝ) : ℂ)) := by
      rw [← Complex.exp_add]
      congr 1
      push_cast
      ring
    rw [Complex.ofReal_exp, hsplit]
    ring
  rw [show mellin (WeilAutocorrelationV1 g) s = mellin A.1 s from rfl, hlog, hcorr,
    centered_correlation_transform_factorization_v11]
  rw [centered_transform_eq_mellin_v11,
    centered_transform_eq_mellin_v11]
  congr 2
  · ring
  · congr 2
    have h2 : (starRingEnd ℂ) (2 : ℂ) = 2 := by
      rw [show (2 : ℂ) = ((2 : ℝ) : ℂ) by norm_num, Complex.conj_ofReal]
    simp [h2]
    ring

  end AEGIS.WeilAutocorrelationMellinV11

#print axioms AEGIS.WeilAutocorrelationMellinV11.centered_correlation_transform_factorization_v11
#print axioms AEGIS.WeilAutocorrelationMellinV11.weil_autocorrelation_mellin_factorization_v11
~~~~~~

## RHKreinPairingV13

Path: `source/RHKreinPairingV13.lean`

Original source lines: 1–117

Full file SHA256: `72253dde1bd27e17c84889d23f02fbf2e235f77b2cdf5f672a7e9650748ec75d`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/RHKreinPairingV13.lean

~~~~~~lean
import Mathlib

/-!
AEGIS Ω — the Krein pairing for the Fourier-side dual certificate, V13.

The certificate in `RH_STATUS.md` adds `Ĥ(ξ)` to the weighted symbol, with `H` supported outside the
window `|u| < L`. This module proves that such a term pairs to zero against `|Ĝ₁|²`, where `G₁` is supported
in an interval of length `L`:

* `self_adj`: `∫ 𝓕f·g = ∫ f·𝓕g` (Mathlib's `VectorFourier.integral_fourierIntegral_smul_eq_flip`).
* `fourier_fourier`: `𝓕(𝓕H)(x) = H(−x)` from Fourier inversion.
* `fourier_conj_neg`, `fourier_autoc`: for `A = G ⋆ G̃`, `𝓕A = |𝓕G|²` (Mathlib's convolution theorem).
* `autoc_support`: `A` vanishes on `|x| ≥ b − a` when `G` vanishes outside `(a, b)`.
* `pairing_zero`, `krein_pairing`: `∫ |𝓕G|²·𝓕H = ∫ A(x)·H(−x) dx = 0`, since the supports are disjoint.

With `RHKreinFactorV13` (support of `g₁`) this gives the pairing step of the certificate. Not RH.
AUTHORITY_EFFECT = NONE.
-/

open MeasureTheory FourierTransform
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinPairingV13

theorem self_adj (f g : ℝ → ℂ) (hf : Integrable f) (hg : Integrable g) :
    ∫ ξ, 𝓕 f ξ * g ξ = ∫ x, f x * 𝓕 g x := by
  have h := VectorFourier.integral_fourierIntegral_smul_eq_flip (e := Real.fourierChar)
    (μ := volume) (ν := volume) (L := innerₗ ℝ) Real.continuous_fourierChar
    continuous_inner hf hg
  simpa [Real.fourier_eq, VectorFourier.fourierIntegral, smul_eq_mul] using h

theorem fourier_fourier (H : ℝ → ℂ) (hHc : Continuous H) (hH : Integrable H)
    (hFH : Integrable (𝓕 H)) (x : ℝ) : 𝓕 (𝓕 H) x = H (-x) := by
  have hinv := hHc.fourierInv_fourier_eq hH hFH
  have h := Real.fourierInv_eq_fourier_neg (𝓕 H) (-x)
  rw [neg_neg] at h
  rw [← h, hinv]

theorem pairing_zero (A H : ℝ → ℂ) (L : ℝ) (hA : Integrable A) (hHc : Continuous H)
    (hH : Integrable H) (hFH : Integrable (𝓕 H))
    (hAs : ∀ x, A x ≠ 0 → |x| < L) (hHs : ∀ u, |u| < L → H u = 0) :
    ∫ ξ, 𝓕 A ξ * 𝓕 H ξ = 0 := by
  rw [self_adj A (𝓕 H) hA hFH]
  simp_rw [fourier_fourier H hHc hH hFH]
  have hz : ∀ x, A x * H (-x) = 0 := by
    intro x
    by_cases h : A x = 0
    · simp [h]
    · rw [hHs (-x) (by rw [abs_neg]; exact hAs x h), mul_zero]
  simp [hz]

theorem fourier_conj_neg (f : ℝ → ℂ) (ξ : ℝ) :
    𝓕 (fun x => (starRingEnd ℂ) (f (-x))) ξ = (starRingEnd ℂ) (𝓕 f ξ) := by
  rw [Real.fourier_real_eq_integral_exp_smul, Real.fourier_real_eq_integral_exp_smul,
    ← integral_conj, ← integral_neg_eq_self]
  congr 1
  funext x
  simp only [smul_eq_mul, map_mul, neg_neg, ← Complex.exp_conj, Complex.conj_ofReal, Complex.conj_I]
  congr 2
  push_cast
  ring

open Convolution in
/-- The autocorrelation `A = G ⋆ G̃`, `G̃(x) = conj G(−x)`. -/
noncomputable def autoc (G : ℝ → ℂ) : ℝ → ℂ :=
  G ⋆[ContinuousLinearMap.mul ℂ ℂ] (fun x => (starRingEnd ℂ) (G (-x)))

theorem fourier_autoc (G : ℝ → ℂ) (hG : Integrable G) (ξ : ℝ) :
    𝓕 (autoc G) ξ = ((Complex.normSq (𝓕 G ξ) : ℝ) : ℂ) := by
  have hGt : Integrable (fun x => (starRingEnd ℂ) (G (-x))) := by
    have h := (Complex.conjLIE.toContinuousLinearMap).integrable_comp hG.comp_neg
    simpa using h
  unfold autoc
  rw [Real.fourier_mul_convolution_eq hG hGt, fourier_conj_neg, Complex.mul_conj]

open Convolution in
theorem autoc_support (G : ℝ → ℂ) (a b : ℝ) (hsupp : ∀ y, G y ≠ 0 → y ∈ Set.Ioo a b) :
    ∀ x, autoc G x ≠ 0 → |x| < b - a := by
  intro x hx
  by_contra hge
  apply hx
  have hz : ∀ t, G t * (starRingEnd ℂ) (G (t - x)) = 0 := by
    intro t
    by_cases h1 : G t = 0
    · rw [h1, zero_mul]
    · by_cases h2 : G (t - x) = 0
      · rw [h2, map_zero, mul_zero]
      · exfalso
        have m1 := hsupp t h1
        have m2 := hsupp _ h2
        apply hge
        rw [abs_lt]
        constructor <;> linarith [m1.1, m1.2, m2.1, m2.2]
  unfold autoc
  rw [convolution_def]
  simp only [ContinuousLinearMap.mul_apply', neg_sub]
  simp [hz]

/-- **Krein pairing.** If `G` is integrable and vanishes outside `(a, b)`, and `H` is continuous and
integrable with integrable Fourier transform and vanishes on `|u| < b − a`, then
`∫ |𝓕G(ξ)|²·𝓕H(ξ) dξ = 0`. So a dual-certificate term `Ĥ` supported outside the window costs nothing. -/
theorem krein_pairing (G : ℝ → ℂ) (a b : ℝ) (hG : Integrable G)
    (hsupp : ∀ y, G y ≠ 0 → y ∈ Set.Ioo a b)
    (H : ℝ → ℂ) (hHc : Continuous H) (hH : Integrable H) (hFH : Integrable (𝓕 H))
    (hHs : ∀ u, |u| < b - a → H u = 0) :
    ∫ ξ, ((Complex.normSq (𝓕 G ξ) : ℝ) : ℂ) * 𝓕 H ξ = 0 := by
  have hGt : Integrable (fun x => (starRingEnd ℂ) (G (-x))) := by
    have h := (Complex.conjLIE.toContinuousLinearMap).integrable_comp hG.comp_neg
    simpa using h
  have hA : Integrable (autoc G) := hG.integrable_convolution (ContinuousLinearMap.mul ℂ ℂ) hGt
  simp_rw [← fourier_autoc G hG]
  exact pairing_zero (autoc G) H (b - a) hA hHc hH hFH (autoc_support G a b hsupp) hHs

end AEGIS.RHKreinPairingV13

#print axioms AEGIS.RHKreinPairingV13.krein_pairing
~~~~~~

## RHKreinFactorV13

Path: `source/RHKreinFactorV13.lean`

Original source lines: 1–376

Full file SHA256: `ee97f9fcee046509f3a2539685cb191cb3c00a87f832478d32bebcdf91b1a4dc`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/RHKreinFactorV13.lean

~~~~~~lean
import Mathlib

/-!
AEGIS Ω — the moment-zero factorisation for the Krein dual certificate, V13.

In the logarithmic coordinate the two Weil moment conditions are `∫ G(y)·e^{±y/2} dy = 0`.
Put `G₁ = e^{−|·|/2} * G`, the Green's function of `1/4 − D²` applied to `G`, so that
`Ĝ₁(ξ) = Ĝ(ξ)/(ξ² + 1/4)`. If `G` vanishes outside `[a, b]` and both moments are zero, then
`G₁` also vanishes outside `[a, b]`. The reason is that on `x ≥ b` the kernel factors as
`e^{−x/2}·e^{y/2}`, and on `x ≤ a` as `e^{x/2}·e^{−y/2}`.

`kreinFactor_lift_support` states the same for the unitary log lift `G(t) = e^{t/2}·g(e^t)` of a
multiplicative `g` supported in `[e^a, e^b]`, under the repository's moment conditions
`∫_{x>0} g(x)/x dx = 0` and `∫_{x>0} g(x) dx = 0` (the two halves of `WeilMomentConditionsV1`).

The second half is the differential equation. `G1 = e^{−x/2}·∫_a^x e^{y/2}G − e^{x/2}·∫_b^x e^{−y/2}G` is
twice differentiable with `G1/4 − G1'' = G` (`G1_ode`, fundamental theorem of calculus). It vanishes outside
`(a, b)` when both interval moments are zero (`G1_support`). `G1_lift` states both facts for the log lift of a
repository test function under `WeilMomentConditionsV1`.

Together these give the factorisation `g = (1/4 − D²)g₁` with `g₁` supported in the same interval. The
Fourier-side certificate in `RH_STATUS.md` uses it.

`moment_zero_parametrization` is the smooth form. If `h` is `C^∞` with `tsupport h ⊆ [a, b]` and
`∫ e^{±u/2} h(u) du = 0`, then `h = χ'' − χ/4` with `χ = −G1` smooth and `tsupport χ ⊆ [a, b]`. `G1` is the
composition of the first-order inverses of `D + 1/2` and `D − 1/2`. Not RH. AUTHORITY_EFFECT = NONE.
-/

open Set MeasureTheory
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFactorV13

/-- `G₁(x) = ∫ e^{−|x − y|/2}·G(y) dy`. -/
def kreinFactor (G : ℝ → ℂ) (x : ℝ) : ℂ :=
  ∫ y, (Real.exp (-(|x - y|) / 2) : ℂ) * G y

theorem kreinFactor_eq_zero_of_le (G : ℝ → ℂ) (a b : ℝ)
    (hsupp : ∀ y, G y ≠ 0 → y ∈ Icc a b)
    (hmom : ∫ y, (Real.exp (y / 2) : ℂ) * G y = 0) {x : ℝ} (hx : b ≤ x) :
    kreinFactor G x = 0 := by
  have hpt : ∀ y, (Real.exp (-(|x - y|) / 2) : ℂ) * G y =
      (Real.exp (-x / 2) : ℂ) * ((Real.exp (y / 2) : ℂ) * G y) := by
    intro y
    by_cases hG : G y = 0
    · simp [hG]
    · have hy : y ≤ x := le_trans (hsupp y hG).2 hx
      have habs : |x - y| = x - y := abs_of_nonneg (by linarith)
      rw [habs, ← mul_assoc, ← Complex.ofReal_mul, ← Real.exp_add]
      congr 3
      ring
  unfold kreinFactor
  simp_rw [hpt]
  rw [integral_const_mul, hmom, mul_zero]

theorem kreinFactor_eq_zero_of_ge (G : ℝ → ℂ) (a b : ℝ)
    (hsupp : ∀ y, G y ≠ 0 → y ∈ Icc a b)
    (hmom : ∫ y, (Real.exp (-y / 2) : ℂ) * G y = 0) {x : ℝ} (hx : x ≤ a) :
    kreinFactor G x = 0 := by
  have hpt : ∀ y, (Real.exp (-(|x - y|) / 2) : ℂ) * G y =
      (Real.exp (x / 2) : ℂ) * ((Real.exp (-y / 2) : ℂ) * G y) := by
    intro y
    by_cases hG : G y = 0
    · simp [hG]
    · have hy : x ≤ y := le_trans hx (hsupp y hG).1
      have habs : |x - y| = y - x := by rw [abs_sub_comm]; exact abs_of_nonneg (by linarith)
      rw [habs, ← mul_assoc, ← Complex.ofReal_mul, ← Real.exp_add]
      congr 3
      ring
  unfold kreinFactor
  simp_rw [hpt]
  rw [integral_const_mul, hmom, mul_zero]

/-- Both moments zero and `G` supported in `[a, b]`: `G₁ = e^{−|·|/2} * G` is supported in `[a, b]`. -/
theorem kreinFactor_support (G : ℝ → ℂ) (a b : ℝ)
    (hsupp : ∀ y, G y ≠ 0 → y ∈ Icc a b)
    (hplus : ∫ y, (Real.exp (y / 2) : ℂ) * G y = 0)
    (hminus : ∫ y, (Real.exp (-y / 2) : ℂ) * G y = 0) :
    ∀ x, kreinFactor G x ≠ 0 → x ∈ Ioo a b := by
  intro x hx
  refine ⟨?_, ?_⟩
  · by_contra h
    exact hx (kreinFactor_eq_zero_of_ge G a b hsupp hminus (not_lt.mp h))
  · by_contra h
    exact hx (kreinFactor_eq_zero_of_le G a b hsupp hplus (not_lt.mp h))

/-- The unitary log lift `G(t) = e^{t/2}·g(e^t)` (same as `WeilLogCoordinateIsometryV21.logLift`). -/
def lift (g : ℝ → ℂ) (t : ℝ) : ℂ := (Real.exp (t / 2) : ℂ) * g (Real.exp t)

/-- Whole-line exponential substitution for complex-valued integrands. -/
theorem integral_exp_subst (f : ℝ → ℂ) :
    (∫ t : ℝ, (Real.exp t : ℂ) * f (Real.exp t)) = ∫ x in Ioi (0 : ℝ), f x := by
  have hcov :=
    MeasureTheory.integral_image_eq_integral_abs_deriv_smul
      (f := Real.exp) (f' := Real.exp) (s := Set.univ) MeasurableSet.univ
      (fun x _ => (Real.hasDerivAt_exp x).hasDerivWithinAt)
      (Set.injOn_of_injective Real.exp_injective) f
  rw [Set.image_univ, Real.range_exp] at hcov
  rw [hcov, Measure.restrict_univ]
  congr 1
  funext t
  rw [abs_of_pos (Real.exp_pos t), Complex.real_smul]

/-- `∫ e^{t/2}·G(t) dt = ∫_{x>0} g(x) dx`. -/
theorem lift_moment_plus (g : ℝ → ℂ) :
    (∫ t, (Real.exp (t / 2) : ℂ) * lift g t) = ∫ x in Ioi (0 : ℝ), g x := by
  rw [← integral_exp_subst]
  congr 1
  funext t
  unfold lift
  rw [← mul_assoc, ← Complex.ofReal_mul, ← Real.exp_add]
  congr 3
  ring

/-- `∫ e^{−t/2}·G(t) dt = ∫_{x>0} g(x)/x dx`. -/
theorem lift_moment_minus (g : ℝ → ℂ) :
    (∫ t, (Real.exp (-t / 2) : ℂ) * lift g t) = ∫ x in Ioi (0 : ℝ), g x / (x : ℂ) := by
  rw [← integral_exp_subst]
  congr 1
  funext t
  unfold lift
  have hne : (Real.exp t : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (Real.exp_pos t).ne'
  rw [← mul_assoc, ← Complex.ofReal_mul, ← Real.exp_add]
  have h0 : -t / 2 + t / 2 = 0 := by ring
  rw [h0, Real.exp_zero, Complex.ofReal_one, one_mul]
  field_simp

/-- The repository's two moment conditions, for `g` supported in `[e^a, e^b]`, make
`e^{−|·|/2} * G` vanish outside `(a, b)`, where `G` is the unitary log lift of `g`. -/
theorem kreinFactor_lift_support (g : ℝ → ℂ) (a b : ℝ)
    (hsupp : ∀ x, g x ≠ 0 → x ∈ Icc (Real.exp a) (Real.exp b))
    (hinv : ∫ x in Ioi (0 : ℝ), g x / (x : ℂ) = 0)
    (hone : ∫ x in Ioi (0 : ℝ), g x = 0) :
    ∀ t, kreinFactor (lift g) t ≠ 0 → t ∈ Ioo a b := by
  refine kreinFactor_support (lift g) a b ?_ (by rw [lift_moment_plus]; exact hone)
    (by rw [lift_moment_minus]; exact hinv)
  intro t ht
  have hg : g (Real.exp t) ≠ 0 := by
    intro h0; apply ht; simp [lift, h0]
  have hmem := hsupp _ hg
  exact ⟨Real.exp_le_exp.mp hmem.1, Real.exp_le_exp.mp hmem.2⟩

/-- `e^{c·x}` as a complex-valued function of a real variable. -/
def ex (c : ℝ) (x : ℝ) : ℂ := (Real.exp (c * x) : ℂ)

theorem hasDerivAt_ex (c x : ℝ) : HasDerivAt (ex c) (c * ex c x) x := by
  have h : HasDerivAt (fun y => Real.exp (c * y)) (Real.exp (c * x) * c) x := by
    have h0 := ((hasDerivAt_id x).const_mul c).exp
    simpa using h0
  have h2 : HasDerivAt (fun y => ((Real.exp (c * y) : ℝ) : ℂ)) ((Real.exp (c * x) * c : ℝ) : ℂ) x :=
    h.ofReal_comp
  exact h2.congr_deriv (by unfold ex; push_cast; ring)

/-- `P(x) = ∫_a^x e^{y/2} G(y) dy`. -/
def P (G : ℝ → ℂ) (a x : ℝ) : ℂ := ∫ y in a..x, ex (1/2) y * G y
/-- `Q(x) = ∫_b^x e^{−y/2} G(y) dy`. -/
def Q (G : ℝ → ℂ) (b x : ℝ) : ℂ := ∫ y in b..x, ex (-1/2) y * G y

/-- `G₁ = e^{−x/2}·P − e^{x/2}·Q`. -/
def G1 (G : ℝ → ℂ) (a b x : ℝ) : ℂ := ex (-1/2) x * P G a x - ex (1/2) x * Q G b x

/-- `G₁' = −½·e^{−x/2}·P − ½·e^{x/2}·Q`. -/
def G1' (G : ℝ → ℂ) (a b x : ℝ) : ℂ :=
  -(1/2 : ℂ) * ex (-1/2) x * P G a x - (1/2 : ℂ) * ex (1/2) x * Q G b x

theorem ex_mul_ex (c d x : ℝ) : ex c x * ex d x = ex (c + d) x := by
  unfold ex; rw [← Complex.ofReal_mul, ← Real.exp_add]; congr 2; ring

theorem hasDerivAt_P (G : ℝ → ℂ) (hG : Continuous G) (a x : ℝ) :
    HasDerivAt (P G a) (ex (1/2) x * G x) x := by
  have hc : Continuous (fun y => ex (1/2) y * G y) :=
    (Complex.continuous_ofReal.comp (Real.continuous_exp.comp (continuous_const.mul continuous_id))).mul hG
  exact (hc.integral_hasStrictDerivAt a x).hasDerivAt

theorem hasDerivAt_Q (G : ℝ → ℂ) (hG : Continuous G) (b x : ℝ) :
    HasDerivAt (Q G b) (ex (-1/2) x * G x) x := by
  have hc : Continuous (fun y => ex (-1/2) y * G y) :=
    (Complex.continuous_ofReal.comp (Real.continuous_exp.comp (continuous_const.mul continuous_id))).mul hG
  exact (hc.integral_hasStrictDerivAt b x).hasDerivAt

theorem hasDerivAt_G1 (G : ℝ → ℂ) (hG : Continuous G) (a b x : ℝ) :
    HasDerivAt (G1 G a b) (G1' G a b x) x := by
  have h1 := (hasDerivAt_ex (-1/2) x).mul (hasDerivAt_P G hG a x)
  have h2 := (hasDerivAt_ex (1/2) x).mul (hasDerivAt_Q G hG b x)
  have e1 : ex (-1/2) x * (ex (1/2) x * G x) = G x := by
    rw [← mul_assoc, ex_mul_ex]; norm_num [ex]
  have e2 : ex (1/2) x * (ex (-1/2) x * G x) = G x := by
    rw [← mul_assoc, ex_mul_ex]; norm_num [ex]
  exact (h1.sub h2).congr_deriv (by unfold G1'; push_cast; linear_combination e1 - e2)

theorem hasDerivAt_G1' (G : ℝ → ℂ) (hG : Continuous G) (a b x : ℝ) :
    HasDerivAt (G1' G a b) (G1 G a b x / 4 - G x) x := by
  have h1 := ((hasDerivAt_ex (-1/2) x).const_mul (-(1/2 : ℂ))).mul (hasDerivAt_P G hG a x)
  have h2 := ((hasDerivAt_ex (1/2) x).const_mul (1/2 : ℂ)).mul (hasDerivAt_Q G hG b x)
  have e1 : ex (-1/2) x * (ex (1/2) x * G x) = G x := by
    rw [← mul_assoc, ex_mul_ex]; norm_num [ex]
  have e2 : ex (1/2) x * (ex (-1/2) x * G x) = G x := by
    rw [← mul_assoc, ex_mul_ex]; norm_num [ex]
  exact (h1.sub h2).congr_deriv (by
    unfold G1; push_cast; linear_combination (-(1/2 : ℂ)) * e1 - (1/2 : ℂ) * e2)

/-- `(1/4 − D²) G₁ = G`: `G₁` is twice differentiable and `G₁/4 − G₁'' = G`. -/
theorem G1_ode (G : ℝ → ℂ) (hG : Continuous G) (a b x : ℝ) :
    deriv (G1 G a b) = G1' G a b ∧ G1 G a b x / 4 - deriv (G1' G a b) x = G x := by
  refine ⟨funext fun y => (hasDerivAt_G1 G hG a b y).deriv, ?_⟩
  rw [(hasDerivAt_G1' G hG a b x).deriv]; ring

theorem continuous_ex (c : ℝ) : Continuous (ex c) :=
  Complex.continuous_ofReal.comp (Real.continuous_exp.comp (continuous_const.mul continuous_id))

theorem integral_zero_right (f : ℝ → ℂ) (b x : ℝ) (hbx : b ≤ x)
    (hf : ∀ y, b < y → f y = 0) : (∫ y in b..x, f y) = 0 := by
  rw [intervalIntegral.integral_of_le hbx]
  rw [setIntegral_congr_fun measurableSet_Ioc (g := fun _ => (0 : ℂ)) (fun y hy => hf y hy.1)]
  simp

theorem integral_zero_left (f : ℝ → ℂ) (a x : ℝ) (hxa : x ≤ a)
    (hf : ∀ y, y ≤ a → f y = 0) : (∫ y in a..x, f y) = 0 := by
  rw [intervalIntegral.integral_symm, intervalIntegral.integral_of_le hxa]
  rw [setIntegral_congr_fun measurableSet_Ioc (g := fun _ => (0 : ℂ)) (fun y hy => hf y hy.2)]
  simp

/-- With `G` continuous, vanishing outside `(a, b)`, and both interval moments zero,
`G₁ = e^{−x/2}·P − e^{x/2}·Q` vanishes outside `(a, b)`. -/
theorem G1_support (G : ℝ → ℂ) (hG : Continuous G) (a b : ℝ)
    (hsupp : ∀ y, G y ≠ 0 → y ∈ Ioo a b)
    (hplus : (∫ y in a..b, ex (1/2) y * G y) = 0)
    (hminus : (∫ y in a..b, ex (-1/2) y * G y) = 0) :
    ∀ x, G1 G a b x ≠ 0 → x ∈ Ioo a b := by
  have hz : ∀ y, y ∉ Ioo a b → G y = 0 := fun y hy => by
    by_contra h; exact hy (hsupp y h)
  have hii : ∀ c u v, IntervalIntegrable (fun y => ex c y * G y) volume u v :=
    fun c u v => ((continuous_ex c).mul hG).intervalIntegrable u v
  intro x hx
  by_contra hout
  apply hx
  rcases not_and_or.mp hout with h | h
  · -- x ≤ a
    have hxa : x ≤ a := not_lt.mp h
    have hP : P G a x = 0 := integral_zero_left _ a x hxa
      (fun y hy => by rw [hz y (fun hm => absurd hm.1 (not_lt.mpr hy)), mul_zero])
    have hQ : Q G b x = 0 := by
      unfold Q
      rw [← intervalIntegral.integral_add_adjacent_intervals (hii _ b a) (hii _ a x),
        intervalIntegral.integral_symm, hminus, neg_zero, zero_add]
      exact integral_zero_left _ a x hxa
        (fun y hy => by rw [hz y (fun hm => absurd hm.1 (not_lt.mpr hy)), mul_zero])
    simp [G1, hP, hQ]
  · -- b ≤ x
    have hbx : b ≤ x := not_lt.mp h
    have hQ : Q G b x = 0 := integral_zero_right _ b x hbx
      (fun y hy => by rw [hz y (fun hm => absurd hm.2 (not_lt.mpr hy.le)), mul_zero])
    have hP : P G a x = 0 := by
      unfold P
      rw [← intervalIntegral.integral_add_adjacent_intervals (hii _ a b) (hii _ b x), hplus, zero_add]
      exact integral_zero_right _ b x hbx
        (fun y hy => by rw [hz y (fun hm => absurd hm.2 (not_lt.mpr hy.le)), mul_zero])
    simp [G1, hP, hQ]

theorem interval_eq_whole (f : ℝ → ℂ) (a b : ℝ) (hab : a ≤ b)
    (hf : ∀ y, y ∉ Ioo a b → f y = 0) : (∫ y in a..b, f y) = ∫ y, f y := by
  rw [intervalIntegral.integral_of_le hab]
  exact setIntegral_eq_integral_of_forall_compl_eq_zero
    (fun y hy => hf y (fun h => hy ⟨h.1, h.2.le⟩))

/-- The factorisation for the repository's test functions: if `g` is continuous, its unitary
log lift `G` vanishes outside `(a, b)`, and `∫_{x>0} g(x)/x dx = ∫_{x>0} g(x) dx = 0`, then
`G₁ = e^{−x/2}·∫_a^x e^{y/2}G − e^{x/2}·∫_b^x e^{−y/2}G` vanishes outside `(a, b)` and solves
`G₁/4 − G₁'' = G`. -/
theorem G1_lift (g : ℝ → ℂ) (hg : Continuous g) (a b : ℝ) (hab : a ≤ b)
    (hsupp : ∀ t, lift g t ≠ 0 → t ∈ Ioo a b)
    (hinv : ∫ x in Ioi (0 : ℝ), g x / (x : ℂ) = 0)
    (hone : ∫ x in Ioi (0 : ℝ), g x = 0) :
    (∀ x, G1 (lift g) a b x ≠ 0 → x ∈ Ioo a b) ∧
      ∀ x, G1 (lift g) a b x / 4 - deriv (G1' (lift g) a b) x = lift g x := by
  have hG : Continuous (lift g) :=
    (Complex.continuous_ofReal.comp (Real.continuous_exp.comp (continuous_id.div_const 2))).mul
      (hg.comp Real.continuous_exp)
  have hz : ∀ c y, y ∉ Ioo a b → ex c y * lift g y = 0 := fun c y hy => by
    have : lift g y = 0 := by by_contra h; exact hy (hsupp y h)
    rw [this, mul_zero]
  have hplus : (∫ y in a..b, ex (1/2) y * lift g y) = 0 := by
    rw [interval_eq_whole _ a b hab (hz _), ← hone, ← lift_moment_plus]
    congr 1; funext y; unfold ex; rw [show (1/2 : ℝ) * y = y / 2 by ring]
  have hminus : (∫ y in a..b, ex (-1/2) y * lift g y) = 0 := by
    rw [interval_eq_whole _ a b hab (hz _), ← hinv, ← lift_moment_minus]
    congr 1; funext y; unfold ex; rw [show (-1/2 : ℝ) * y = -y / 2 by ring]
  exact ⟨G1_support (lift g) hG a b hsupp hplus hminus, fun x => (G1_ode (lift g) hG a b x).2⟩

/-! ### Moment-zero parametrisation: smooth, same window

`chi = −G1` is the support-preserving inverse of `D² − 1/4`. It is the composition of the
first-order inverses of `D + 1/2` and `D − 1/2`. If `h` is smooth, supported in `[a, b]`, and both
weighted moments `∫ e^{±u/2} h(u) du` vanish, then `chi` is smooth, supported in `[a, b]`, and
`h = chi'' − chi/4`. -/

open scoped ContDiff

theorem contDiff_ex (c : ℝ) : ContDiff ℝ ∞ (ex c) :=
  Complex.ofRealCLM.contDiff.comp (contDiff_const.mul contDiff_id).exp

theorem contDiff_P (G : ℝ → ℂ) (hG : ContDiff ℝ ∞ G) (a : ℝ) : ContDiff ℝ ∞ (P G a) := by
  rw [contDiff_infty_iff_deriv]
  refine ⟨fun x => (hasDerivAt_P G hG.continuous a x).differentiableAt, ?_⟩
  rw [show deriv (P G a) = fun x => ex (1/2) x * G x from
    funext fun x => (hasDerivAt_P G hG.continuous a x).deriv]
  exact (contDiff_ex _).mul hG

theorem contDiff_Q (G : ℝ → ℂ) (hG : ContDiff ℝ ∞ G) (b : ℝ) : ContDiff ℝ ∞ (Q G b) := by
  rw [contDiff_infty_iff_deriv]
  refine ⟨fun x => (hasDerivAt_Q G hG.continuous b x).differentiableAt, ?_⟩
  rw [show deriv (Q G b) = fun x => ex (-1/2) x * G x from
    funext fun x => (hasDerivAt_Q G hG.continuous b x).deriv]
  exact (contDiff_ex _).mul hG

theorem contDiff_G1 (G : ℝ → ℂ) (hG : ContDiff ℝ ∞ G) (a b : ℝ) : ContDiff ℝ ∞ (G1 G a b) :=
  ((contDiff_ex _).mul (contDiff_P G hG a)).sub ((contDiff_ex _).mul (contDiff_Q G hG b))

/-- A continuous `h` with `tsupport h ⊆ [a, b]` vanishes at `a` and `b` as well. -/
theorem ne_zero_mem_Ioo (h : ℝ → ℂ) (hc : Continuous h) (a b : ℝ)
    (hs : tsupport h ⊆ Icc a b) : ∀ y, h y ≠ 0 → y ∈ Ioo a b := by
  have hz : ∀ y, y ∉ Icc a b → h y = 0 := fun y hy =>
    image_eq_zero_of_notMem_tsupport (fun h' => hy (hs h'))
  have hcl : IsClosed {x | h x = 0} := isClosed_eq hc continuous_const
  intro y hy
  have hyI : y ∈ Icc a b := by by_contra h'; exact hy (hz y h')
  refine ⟨lt_of_le_of_ne hyI.1 fun he => hy ?_, lt_of_le_of_ne hyI.2 fun he => hy ?_⟩
  · have hsub : Iio a ⊆ {x | h x = 0} := fun x hx => hz x fun hm => absurd hm.1 (not_le.mpr hx)
    have hcl' := hcl.closure_subset_iff.mpr hsub
    rw [closure_Iio] at hcl'
    rw [← he]; exact hcl' self_mem_Iic
  · have hsub : Ioi b ⊆ {x | h x = 0} := fun x hx => hz x fun hm => absurd hm.2 (not_le.mpr hx)
    have hcl' := hcl.closure_subset_iff.mpr hsub
    rw [closure_Ioi] at hcl'
    rw [he]; exact hcl' self_mem_Ici

/-- **Moment-zero parametrisation.** If `h` is smooth with `tsupport h ⊆ [a, b]` and
`∫ e^{−u/2} h(u) du = ∫ e^{u/2} h(u) du = 0`, then `h = chi'' − chi/4` for a smooth `chi` with
`tsupport chi ⊆ [a, b]`, namely `chi = −G1`. -/
theorem moment_zero_parametrization (h : ℝ → ℂ) (a b : ℝ) (hab : a ≤ b)
    (hh : ContDiff ℝ ∞ h) (hs : tsupport h ⊆ Icc a b)
    (hminus : ∫ u, (Real.exp (-u / 2) : ℂ) * h u = 0)
    (hplus : ∫ u, (Real.exp (u / 2) : ℂ) * h u = 0) :
    ∃ chi : ℝ → ℂ, ContDiff ℝ ∞ chi ∧ tsupport chi ⊆ Icc a b ∧
      ∀ u, h u = deriv (deriv chi) u - (1/4 : ℂ) * chi u := by
  have hc := hh.continuous
  have hsupp := ne_zero_mem_Ioo h hc a b hs
  have hz : ∀ c y, y ∉ Ioo a b → ex c y * h y = 0 := fun c y hy => by
    have : h y = 0 := by by_contra h'; exact hy (hsupp y h')
    rw [this, mul_zero]
  have hp : (∫ y in a..b, ex (1/2) y * h y) = 0 := by
    rw [interval_eq_whole _ a b hab (hz _), ← hplus]
    congr 1; funext y; unfold ex; rw [show (1/2 : ℝ) * y = y / 2 by ring]
  have hm : (∫ y in a..b, ex (-1/2) y * h y) = 0 := by
    rw [interval_eq_whole _ a b hab (hz _), ← hminus]
    congr 1; funext y; unfold ex; rw [show (-1/2 : ℝ) * y = -y / 2 by ring]
  refine ⟨fun x => -G1 h a b x, (contDiff_G1 h hh a b).neg, ?_, fun u => ?_⟩
  · refine closure_minimal (fun x hx => Ioo_subset_Icc_self ?_) isClosed_Icc
    exact G1_support h hc a b hsupp hp hm x fun h0 => hx (by simp [h0])
  · have hd : deriv (fun x => -G1 h a b x) = fun x => -G1' h a b x :=
      funext fun x => (hasDerivAt_G1 h hc a b x).neg.deriv
    rw [hd, show (fun x => -G1' h a b x) = -G1' h a b from rfl, deriv.neg,
      (hasDerivAt_G1' h hc a b u).deriv]
    show h u = -(G1 h a b u / 4 - h u) - (1/4 : ℂ) * -G1 h a b u
    ring

end AEGIS.RHKreinFactorV13

#print axioms AEGIS.RHKreinFactorV13.kreinFactor_support
#print axioms AEGIS.RHKreinFactorV13.kreinFactor_lift_support
#print axioms AEGIS.RHKreinFactorV13.G1_ode
#print axioms AEGIS.RHKreinFactorV13.G1_support
#print axioms AEGIS.RHKreinFactorV13.G1_lift
#print axioms AEGIS.RHKreinFactorV13.contDiff_G1
#print axioms AEGIS.RHKreinFactorV13.moment_zero_parametrization
~~~~~~

## RHKreinCertificateTransferV1

Path: `source/RHKreinCertificateTransferV1.lean`

Original source lines: 1–108

Full file SHA256: `f64aab94ef83877f6adb7c2c90e114e36eadfe07bdf00293155402b65e3b6d1e`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinCertificateTransferV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinPrimeSymbolV1

/-!
# Transfer of a weighted Krein certificate to the actual Weil form

The pointwise certificate, mass factorization and correction pairing remain
explicit hypotheses. Integrability of the actual symbol and packet energy
is discharged by the repository identities. The conclusion is about the
actual arithmetic form, with no shadow quadratic form.
-/

open MeasureTheory
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinCertificateTransferV1

open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHDyadicDiagonalV13
open AEGIS.WeilDisjointEnergyV2

theorem symbol_mass_integrable (g : WeilCompactSmoothGV1) :
    Integrable (fun t : ℝ => symbol t * criticalSpectralMass g t) := by
  refine ((archSymbol_mass_integrable g).sub
    ((cosine_mass_integrable g (Real.log 2)).const_mul
      (Real.sqrt 2 * Real.log 2))).congr (Filter.Eventually.of_forall fun t => ?_)
  simp only [symbol, Pi.sub_apply]
  ring

/-- An integrable zero-cost correction and a pointwise weighted certificate
imply a quantitative bound for the actual finite-window Weil arithmetic form. -/
theorem actual_margin_of_weighted_certificate
    (g : WeilCompactSmoothGV1) (r a m : ℝ)
    (hw : HalfWidthAt g r a) (hr : 2 * r < Real.log 3)
    (ρ C : ℝ → ℝ)
    (hρ : ∀ t : ℝ, 0 ≤ ρ t)
    (hmass : ∀ t : ℝ, criticalSpectralMass g t = (t ^ 2 + 1 / 4) ^ 2 * ρ t)
    (hCint : Integrable (fun t : ℝ => C t * ρ t))
    (hCzero : (∫ t : ℝ, C t * ρ t) = 0)
    (hcert : ∀ t : ℝ, 0 ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - m) + C t) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re ≤ -m * energy g.1 := by
  have hS := symbol_mass_integrable g
  have hM := (criticalSpectralMass_integrable g).const_mul m
  have hD : Integrable (fun t : ℝ =>
      symbol t * criticalSpectralMass g t - m * criticalSpectralMass g t) := hS.sub hM
  have hnonneg : 0 ≤ ∫ t : ℝ,
      (symbol t * criticalSpectralMass g t - m * criticalSpectralMass g t) +
        C t * ρ t := by
    apply integral_nonneg
    intro t
    calc
      0 ≤ ((t ^ 2 + 1 / 4) ^ 2 * (symbol t - m) + C t) * ρ t :=
        mul_nonneg (hcert t) (hρ t)
      _ = _ := by
        dsimp only
        rw [hmass]
        ring
  rw [integral_add hD hCint, hCzero, add_zero,
    integral_sub hS hM, integral_const_mul] at hnonneg
  rw [actual_arithmetic_real_eq_symbol_integral g r a hw hr, energy_eq_mass_integral]
  have hK : 0 ≤ (1 / (4 * Real.pi) : ℝ) := by positivity
  have hbound := mul_nonneg hK hnonneg
  nlinarith

/-- The same certificate transfers to the actual canonical zero quadratic
when the two repository moments vanish. -/
theorem zero_quadratic_margin_of_weighted_certificate
    (g : WeilCompactSmoothGV1) (r a m : ℝ)
    (hw : HalfWidthAt g r a) (hr : 2 * r < Real.log 3)
    (hm : WeilMomentConditionsV1 g)
    (ρ C : ℝ → ℝ)
    (hρ : ∀ t : ℝ, 0 ≤ ρ t)
    (hmass : ∀ t : ℝ, criticalSpectralMass g t = (t ^ 2 + 1 / 4) ^ 2 * ρ t)
    (hCint : Integrable (fun t : ℝ => C t * ρ t))
    (hCzero : (∫ t : ℝ, C t * ρ t) = 0)
    (hcert : ∀ t : ℝ, 0 ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - m) + C t) :
    m * energy g.1 ≤
      (∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho).re := by
  have h := actual_margin_of_weighted_certificate g r a m hw hr ρ C hρ hmass
    hCint hCzero hcert
  rw [AEGIS.WeilAutocorrelationExplicitFormulaV10.autocorrelation_explicit_formula_v10 g hm,
    Complex.neg_re] at h
  linarith

end AEGIS.RHKreinCertificateTransferV1

#print axioms AEGIS.RHKreinCertificateTransferV1.symbol_mass_integrable
#print axioms AEGIS.RHKreinCertificateTransferV1.actual_margin_of_weighted_certificate

#print axioms AEGIS.RHKreinCertificateTransferV1.zero_quadratic_margin_of_weighted_certificate
~~~~~~

## RHKreinPrimeSymbolV1

Path: `source/RHKreinPrimeSymbolV1.lean`

Original source lines: 1–235

Full file SHA256: `d538dd54e5ea5f59f30d422f5235e5bec6794e431989105d70b966045f318e7d`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinPrimeSymbolV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinSymbolIntegrationV1
import RHDyadicDiagonalV13
import WeilThreeBlockPrimeEvaluationV30

/-!
# Prime cosine and the actual finite-window Weil symbol

This module uses the actual paired Mellin inversion theorem and the actual
prime sum. Its window hypothesis is full logarithmic width below log 3.
The symbol convention is angular frequency with Mathlib frequency -t/(2*pi).
-/

open Set Filter MeasureTheory Complex FourierTransform
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinPrimeSymbolV1

open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHDyadicDiagonalV13
open AEGIS.WeilFixedLineGammaCoreV10
open AEGIS.WeilDisjointEnergyV2

/-- For full width below log 3, every possible nonzero prime term other than 2
is outside the autocorrelation support. -/
theorem prime_sum_eq_two_of_halfWidth
    (g : WeilCompactSmoothGV1) (r a : ℝ)
    (hw : HalfWidthAt g r a) (hr : 2 * r < Real.log 3) :
    WeilPrimeSumV1 (WeilAutocorrelationV1 g) =
      WeilPrimeTermV1 (WeilAutocorrelationV1 g) 1 := by
  unfold WeilPrimeSumV1
  apply tsum_eq_single 1
  intro n hn
  by_cases hn0 : n = 0
  · simp [hn0, WeilPrimeTermV1]
  have hm3R : (3 : ℝ) ≤ ((n + 1 : ℕ) : ℝ) := by exact_mod_cast (show 3 ≤ n + 1 by omega)
  have hmpos : (0 : ℝ) < ((n + 1 : ℕ) : ℝ) := by positivity
  have hlog : Real.log 3 ≤ Real.log ((n + 1 : ℕ) : ℝ) :=
    Real.log_le_log (by norm_num) hm3R
  have hA : WeilAutocorrelationV1 g ((n + 1 : ℕ) : ℝ) = 0 := by
    have h := autocorrelation_zero_of_halfWidth g r a
      (Real.log ((n + 1 : ℕ) : ℝ)) hw (by linarith)
    rwa [Real.exp_log hmpos] at h
  have hAi : WeilAutocorrelationV1 g (((n + 1 : ℕ) : ℝ))⁻¹ = 0 := by
    rw [weil_autocorrelation_reciprocal_v1 g hmpos, hA]
    simp
  simp only [WeilPrimeTermV1, hA, hAi, mul_zero, add_zero]

theorem criticalSpectralMass_integrable (g : WeilCompactSmoothGV1) :
    Integrable (criticalSpectralMass g) := by
  have h := (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5
    (WeilAutocorrelationCompactSmoothV1 g) (1 / 2)).1.re
  simpa only [paired_autocorrelation_eq_criticalSpectralMass,
    RCLike.re_to_complex, Complex.ofReal_re] using h

theorem criticalSpectralMass_nonnegative (g : WeilCompactSmoothGV1) (t : ℝ) :
    0 ≤ criticalSpectralMass g t := by
  exact add_nonneg (Complex.normSq_nonneg _) (Complex.normSq_nonneg _)

theorem cosine_mass_integrable (g : WeilCompactSmoothGV1) (u : ℝ) :
    Integrable (fun t : ℝ => Real.cos (t * u) * criticalSpectralMass g t) := by
  have hc : Continuous (fun t : ℝ => Real.cos (t * u)) := by fun_prop
  exact (criticalSpectralMass_integrable g).bdd_mul hc.aestronglyMeasurable
    (Filter.Eventually.of_forall fun t => by
      simpa only [Real.norm_eq_abs] using Real.abs_cos_le_one (t * u))

private theorem critical_exp_profile_integrable
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    Integrable (fun t : ℝ =>
      Complex.exp (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ))) *
        (criticalSpectralMass g t : ℂ)) := by
  have hH := (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5
    (WeilAutocorrelationCompactSmoothV1 g) (1 / 2)).1
  change Integrable (fun t : ℝ =>
    WeilPairedMellinProfileV5 (WeilAutocorrelationCompactSmoothV1 g) (1 / 2) t) at hH
  simp_rw [paired_autocorrelation_eq_criticalSpectralMass] at hH
  have hc : Continuous (fun t : ℝ =>
      Complex.exp (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ)))) := by fun_prop
  have hb : ∀ t : ℝ,
      ‖Complex.exp (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ)))‖ ≤
        Real.exp (-u / 2) := by
    intro t
    rw [Complex.norm_exp]
    have he : (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ))).re = -u / 2 := by
      simp
      ring
    rw [he]
  exact hH.bdd_mul hc.aestronglyMeasurable (Filter.Eventually.of_forall hb)

/-- Real Mellin inversion at exp u, with its exact exponential factor. -/
theorem cosine_mass_inversion (g : WeilCompactSmoothGV1) (u : ℝ) :
    (1 / (2 * Real.pi)) * Real.exp (-u / 2) *
      (∫ t : ℝ, Real.cos (t * u) * criticalSpectralMass g t) =
    (WeilAutocorrelationV1 g (Real.exp u) +
      (Real.exp (-u) : ℂ) * WeilAutocorrelationV1 g (Real.exp (-u))).re := by
  have h := weil_paired_profile_exp_half_integral_expanded_v10
    (WeilAutocorrelationCompactSmoothV1 g) (1 / 2) (2 * u)
  have hu : (2 * u) / 2 = u := by ring
  rw [hu] at h
  simp_rw [paired_autocorrelation_eq_criticalSpectralMass] at h
  have hr := congrArg Complex.re h
  have hpoint : ∀ t : ℝ,
      (Complex.exp (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ))) *
        (criticalSpectralMass g t : ℂ)).re =
      Real.exp (-u / 2) * (Real.cos (t * u) * criticalSpectralMass g t) := by
    intro t
    rw [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero,
      Complex.exp_re]
    have he : (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ))).re = -u / 2 := by
      simp
      ring
    have hi : (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ))).im = -(t * u) := by simp
    rw [he, hi, Real.cos_neg]
    ring
  have hreal :
      (∫ t : ℝ, Complex.exp (-((((1 / 2 : ℝ) : ℂ) + (t : ℂ) * I) * (u : ℂ))) *
        (criticalSpectralMass g t : ℂ)).re =
      Real.exp (-u / 2) * ∫ t : ℝ, Real.cos (t * u) * criticalSpectralMass g t := by
    have hre := (integral_re (critical_exp_profile_integrable g u)).symm
    simp only [RCLike.re_to_complex] at hre
    rw [hre]
    simp_rw [hpoint]
    rw [integral_const_mul]
  have hs : (1 / (2 * Real.pi) : ℂ) = ((1 / (2 * Real.pi) : ℝ) : ℂ) := by
    push_cast
    rfl
  rw [hs, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero,
    hreal] at hr
  simpa only [WeilAutocorrelationCompactSmoothV1, mul_assoc] using hr

/-- The factor linking the prime-2 coefficient to the explicit numerical symbol. -/
theorem twice_exp_neg_half_log_two : 2 * Real.exp (-Real.log 2 / 2) = Real.sqrt 2 := by
  rw [show -Real.log 2 / 2 = -(Real.log 2 / 2) by ring, Real.exp_neg,
    AEGIS.WeilThreeBlockPrimeEvaluationV30.exp_log_two_half]
  have hs : Real.sqrt 2 ≠ 0 := (Real.sqrt_pos.mpr (by norm_num : (0 : ℝ) < 2)).ne'
  have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  field_simp [hs]
  nlinarith

/-- The actual prime-2 contribution is exactly its cosine Fourier multiplier. -/
theorem prime_two_real_eq_cosine_mass (g : WeilCompactSmoothGV1) :
    (WeilPrimeTermV1 (WeilAutocorrelationV1 g) 1).re =
      (1 / (4 * Real.pi)) * (Real.sqrt 2 * Real.log 2) *
        ∫ t : ℝ, Real.cos (t * Real.log 2) * criticalSpectralMass g t := by
  have h := cosine_mass_inversion g (Real.log 2)
  rw [Real.exp_log (by norm_num : (0 : ℝ) < 2), Real.exp_neg,
    Real.exp_log (by norm_num : (0 : ℝ) < 2)] at h
  norm_num at h
  have hv : ArithmeticFunction.vonMangoldt 2 = Real.log 2 :=
    ArithmeticFunction.vonMangoldt_apply_prime Nat.prime_two
  have hs := twice_exp_neg_half_log_two
  simp only [WeilPrimeTermV1, show (1 + 1 : ℕ) = 2 from rfl, hv]
  norm_num only [Nat.cast_ofNat, Complex.add_re, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
    zero_mul, sub_zero]
  norm_num
  rw [← h]
  rw [← hs]
  ring

/-- Exact explicit symbol consumed by the rational certificate. -/
def symbol (t : ℝ) : ℝ :=
  archSymbol t - Real.sqrt 2 * Real.log 2 * Real.cos (t * Real.log 2)

/-- The Archimedean symbol times the actual spectral mass is integrable. -/
theorem archSymbol_mass_integrable (g : WeilCompactSmoothGV1) :
    Integrable (fun t : ℝ => archSymbol t * criticalSpectralMass g t) := by
  have hI := AEGIS.RHKreinSymbolIntegrationV1.WeilFixedLineCompletedGammaV10.weil_fixed_line_completed_gamma_integrable_v10
    (WeilAutocorrelationCompactSmoothV1 g) (1 / 2) (by norm_num)
  simp_rw [paired_autocorrelation_eq_criticalSpectralMass] at hI
  refine (hI.re.const_mul (2 : ℝ)).congr (Filter.Eventually.of_forall fun t => ?_)
  simp only [RCLike.re_to_complex, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, mul_zero,
    sub_zero, completed_gamma_critical_real]
  ring

/-- Full exact symbol identity on logarithmic support width below log 3.
Both Fourier masses are retained, so no evenness of the complex packet is assumed. -/
theorem actual_arithmetic_real_eq_symbol_integral
    (g : WeilCompactSmoothGV1) (r a : ℝ)
    (hw : HalfWidthAt g r a) (hr : 2 * r < Real.log 3) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re =
      -(1 / (4 * Real.pi)) *
        ∫ t : ℝ, symbol t * criticalSpectralMass g t := by
  have hsplit : (∫ t : ℝ, symbol t * criticalSpectralMass g t) =
      (∫ t : ℝ, archSymbol t * criticalSpectralMass g t) -
      (Real.sqrt 2 * Real.log 2) *
        ∫ t : ℝ, Real.cos (t * Real.log 2) * criticalSpectralMass g t := by
    have he : (fun t : ℝ => symbol t * criticalSpectralMass g t) =
        (fun t : ℝ => archSymbol t * criticalSpectralMass g t -
          (Real.sqrt 2 * Real.log 2) *
            (Real.cos (t * Real.log 2) * criticalSpectralMass g t)) := by
      funext t
      unfold symbol
      ring
    rw [he]
    rw [integral_sub (archSymbol_mass_integrable g)
      ((cosine_mass_integrable g (Real.log 2)).const_mul (Real.sqrt 2 * Real.log 2)),
      integral_const_mul]
  rw [actual_arithmetic_real_eq_prime_sub_archSymbol,
    prime_sum_eq_two_of_halfWidth g r a hw hr, prime_two_real_eq_cosine_mass,
    hsplit]
  ring

/-- The same spectral mass gives exactly the actual repository packet energy. -/
theorem energy_eq_mass_integral (g : WeilCompactSmoothGV1) :
    energy g.1 = (1 / (4 * Real.pi)) * ∫ t : ℝ, criticalSpectralMass g t := by
  have h := cosine_mass_inversion g 0
  simp only [neg_zero, zero_div, Real.exp_zero, mul_zero, Real.cos_zero,
    one_mul, mul_one, Complex.ofReal_one, Complex.add_re] at h
  rw [AEGIS.WeilDiagonalKernelReductionV21.autocorrelation_one_re_eq_energy] at h
  calc
    energy g.1 = (1 / 2) * ((1 / (2 * Real.pi)) * ∫ t : ℝ, criticalSpectralMass g t) := by linarith
    _ = _ := by ring

end AEGIS.RHKreinPrimeSymbolV1

#print axioms AEGIS.RHKreinPrimeSymbolV1.prime_sum_eq_two_of_halfWidth
#print axioms AEGIS.RHKreinPrimeSymbolV1.cosine_mass_inversion
#print axioms AEGIS.RHKreinPrimeSymbolV1.actual_arithmetic_real_eq_symbol_integral
#print axioms AEGIS.RHKreinPrimeSymbolV1.energy_eq_mass_integral
~~~~~~

## RHDyadicDiagonalV13

Path: `source/RHDyadicDiagonalV13.lean`

Original source lines: 1–295

Full file SHA256: `bca7ff7ba0d90332c5f3857f4cc6efb5338f52ba1364369a5b9a1bfed67e2889`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/RHDyadicDiagonalV13.lean

~~~~~~lean
import RHNarrowDiagonalUpgradeV2
import Mathlib.Tactic

/-!
AEGIS Ω — the diagonal at every width, V13.

The repository proves the diagonal floor `103/100 · E` at log-half-width `1/64`
and `32/25 · E` at half-width `1/128`, each with a hand-tuned shell estimate.
Underneath, every ingredient is parametric: `logCross_zero_outside` takes
arbitrary supports and `integral_one_div_sinh_Ioi` is stated for every lower
limit.  This module states the diagonal for every half-width `0 < r ≤ 1/64`:

  E · ( log((1+e^{-2r})/(1−e^{-2r})) − κ − r·e^{1/64} ) ≤ −Re B(g, g),

with `κ = log(4π) + γ`.  The coth tail `log((1+e^{-2r})/(1−e^{-2r}))` grows
like `log(1/r)`: the diagonal is unbounded as the packet narrows.  This is the
analytic half of the pattern "narrower packets certify more dyadic
translates".  The arithmetic half (single dyadic sample per window) is a
separate module.  Neither is RH.  AUTHORITY_EFFECT = NONE.
-/

open Set MeasureTheory Complex
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHDyadicDiagonalV13
open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilThreeBlockCrossPrimeV28
open AEGIS.WeilSeparatedArchBridgeV31
open AEGIS.WeilWidthArchBudgetV26
open AEGIS.WeilWidthArchIntegralV27
open AEGIS.WeilWidthDiagonalArchFrontierV24
open AEGIS.WeilDiagonalKernelReductionV21
open AEGIS.WeilThreeBlockAnalyticConstantsV21
open AEGIS.WeilArchimedeanCothTailV1
open AEGIS.WeilMixedAlgebraV2
open AEGIS.RHNarrowDiagonalUpgradeV2

/-- Log-support inside `[a − r, a + r]`. -/
def HalfWidthAt (g : WeilCompactSmoothGV1) (r a : ℝ) : Prop :=
  LogSupportIn g (a - r) (a + r)

/-- The coth tail `∫_{w}^{∞} du / sinh u`. -/
def cothTail (w : ℝ) : ℝ :=
  Real.log ((1 + Real.exp (-w)) / (1 - Real.exp (-w)))

theorem halfWidth_implies_retained (g : WeilCompactSmoothGV1) (r a : ℝ)
    (hr : r ≤ 1 / 64) (hw : HalfWidthAt g r a) : WidthOneThirtyTwoAt g a := by
  intro t ht
  have h := hw ht
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

theorem halfWidth_1_128_iff (g : WeilCompactSmoothGV1) (a : ℝ) :
    HalfWidthAt g (1 / 128) a ↔ WidthOneSixtyFourAt g a := Iff.rfl

/-- Beyond twice the half-width the autocorrelation vanishes. -/
theorem autocorrelation_zero_of_halfWidth (g : WeilCompactSmoothGV1) (r a u : ℝ)
    (hw : HalfWidthAt g r a) (hu : 2 * r < u) :
    WeilAutocorrelationV1 g (Real.exp u) = 0 := by
  have hc := logCross_zero_outside g g (a - r) (a + r) (a - r) (a + r) u hw hw
    (Or.inr (by linarith))
  rw [logCross_eq_mixed_v28] at hc
  have hm := (mul_eq_zero.mp hc).resolve_left (by simp)
  change WeilAutocorrelationV1 g (Real.exp u) = 0 at hm
  exact hm

theorem tail_integrand_eq (g : WeilCompactSmoothGV1) (r a : ℝ)
    (hw : HalfWidthAt g r a) {u : ℝ} (hu : 2 * r < u) :
    widthArchLogIntegrandV26 g u = -energy g.1 / Real.sinh u := by
  unfold widthArchLogIntegrandV26
  rw [autocorrelation_zero_of_halfWidth g r a u hw hu]
  simp

theorem split_at (g : WeilCompactSmoothGV1) (w : ℝ) (hw : 0 ≤ w) :
    (∫ u in Ioi (0 : ℝ), widthArchLogIntegrandV26 g u) =
      (∫ u in Ioc (0 : ℝ) w, widthArchLogIntegrandV26 g u) +
      ∫ u in Ioi w, widthArchLogIntegrandV26 g u := by
  have hfull := width_arch_log_integrableOn_v27 g
  have hinner : IntegrableOn (widthArchLogIntegrandV26 g) (Ioc (0 : ℝ) w) :=
    hfull.mono_set (fun u hu => hu.1)
  have htail : IntegrableOn (widthArchLogIntegrandV26 g) (Ioi w) :=
    hfull.mono_set (by intro u hu; change w < u at hu; change (0 : ℝ) < u; linarith)
  rw [← Set.Ioc_union_Ioi_eq_Ioi hw,
    setIntegral_union Set.Ioc_disjoint_Ioi_same measurableSet_Ioi hinner htail]

theorem inner_le (g : WeilCompactSmoothGV1) (w : ℝ) (hw0 : 0 ≤ w) (hw32 : w ≤ 1 / 32) :
    (∫ u in Ioc (0 : ℝ) w, widthArchLogIntegrandV26 g u) ≤
      w * (energy g.1 * (Real.exp (1 / 64 : ℝ) / 2)) := by
  have hfull := width_arch_log_integrableOn_v27 g
  have hinner : IntegrableOn (widthArchLogIntegrandV26 g) (Ioc (0 : ℝ) w) :=
    hfull.mono_set (fun u hu => hu.1)
  calc
    _ ≤ ∫ _u in Ioc (0 : ℝ) w, energy g.1 * (Real.exp (1 / 64 : ℝ) / 2) := by
      apply setIntegral_mono_on hinner continuous_const.integrableOn_Ioc measurableSet_Ioc
      intro u hu
      exact width_arch_log_inner_pointwise_v26 g hu.1 (le_trans hu.2 hw32)
    _ = _ := by
      rw [setIntegral_const, smul_eq_mul, Real.volume_real_Ioc_of_le hw0]
      ring

theorem tail_eq (g : WeilCompactSmoothGV1) (r a : ℝ) (hr : 0 < r)
    (hw : HalfWidthAt g r a) :
    (∫ u in Ioi (2 * r), widthArchLogIntegrandV26 g u) =
      -energy g.1 * cothTail (2 * r) := by
  calc
    (∫ u in Ioi (2 * r), widthArchLogIntegrandV26 g u)
        = ∫ u in Ioi (2 * r), (-energy g.1) * (1 / Real.sinh u) := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro u hu
          rw [tail_integrand_eq g r a hw hu]
          ring
    _ = (-energy g.1) * ∫ u in Ioi (2 * r), 1 / Real.sinh u := by
          rw [integral_const_mul]
    _ = -energy g.1 * cothTail (2 * r) := by
          rw [integral_one_div_sinh_Ioi (by linarith : (0 : ℝ) < 2 * r)]
          rfl

/-- Archimedean budget at every half-width `0 < r ≤ 1/64`. -/
theorem arch_budget (g : WeilCompactSmoothGV1) (r a : ℝ) (hr0 : 0 < r) (hr : r ≤ 1 / 64)
    (hw : HalfWidthAt g r a) :
    (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re ≤
      energy g.1 * (r * Real.exp (1 / 64 : ℝ) - cothTail (2 * r)) := by
  rw [archimedean_real_eq_log_integral_v27, split_at g (2 * r) (by linarith)]
  have hi := inner_le g (2 * r) (by linarith) (by linarith)
  have ht := tail_eq g r a hr0 hw
  rw [ht]
  nlinarith [energy_nonnegative g.1, Real.exp_pos (1 / 64 : ℝ)]

/-- **The diagonal at every half-width.**  The floor grows like `log(1/r)`. -/
theorem diagonal_lower (g : WeilCompactSmoothGV1) (r a : ℝ) (hr0 : 0 < r) (hr : r ≤ 1 / 64)
    (hw : HalfWidthAt g r a) :
    energy g.1 * (cothTail (2 * r) - diagonalKappaV21 - r * Real.exp (1 / 64 : ℝ)) ≤
      -(B g g).re := by
  have hp := width_diagonal_prime_sum_zero_v24 g a (halfWidth_implies_retained g r a hr hw)
  have hb := arch_budget g r a hr0 hr hw
  rw [actual_diagonal_rhs_decomposition g hp]
  nlinarith [energy_nonnegative g.1]

/-- Sanity: at `r = 1/64` this recovers the repository's `103/100` floor route
(`cothTail (1/32) > 6 log 2`, `κ + (1/64)e^{1/64} < 6 log 2 − 103/100`). -/
theorem diagonal_lower_recovers_103_over_100 (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : HalfWidthAt g (1 / 64) a) :
    (103 / 100 : ℝ) * energy g.1 ≤ -(B g g).re := by
  have h := diagonal_lower g (1 / 64) a (by norm_num) le_rfl hw
  have hE := energy_nonnegative g.1
  have htail : 6 * Real.log 2 < cothTail (2 * (1 / 64)) := by
    have := six_log_two_lt_integral_one_div_sinh_Ioi
    rw [integral_one_div_sinh_Ioi (by norm_num : (0 : ℝ) < 1 / 32)] at this
    unfold cothTail
    norm_num at this ⊢
    exact this
  have hc := diagonal_constant_floor
  have hn := certificate_diagonal_threshold
  unfold diagonalKappaV21 at h
  nlinarith [mul_le_mul_of_nonneg_left (le_of_lt htail) hE]


/-! ### Growth of the coth tail -/

/-- `sinh u ≤ u · e^u` for `u ≥ 0` (from `1 − 2u ≤ e^{−2u}`). -/
theorem sinh_le_self_mul_exp {u : ℝ} (hu : 0 ≤ u) : Real.sinh u ≤ u * Real.exp u := by
  have h := Real.add_one_le_exp (-(2 * u))
  have hmul := mul_le_mul_of_nonneg_left h (Real.exp_pos u).le
  have hprod : Real.exp u * Real.exp (-(2 * u)) = Real.exp (-u) := by
    rw [← Real.exp_add]; ring_nf
  rw [hprod] at hmul
  rw [Real.sinh_eq]
  nlinarith [hmul]

theorem cothTail_eq_neg_cothPrim (w : ℝ) (hw : 0 < w) : cothTail w = -cothPrim w := by
  unfold cothTail cothPrim
  have hlt : Real.exp (-w) < 1 := exp_neg_lt_one hw
  rw [Real.log_div (by positivity) (by linarith)]
  ring

theorem cothTail_nonneg (w : ℝ) (hw : 0 < w) : 0 ≤ cothTail w := by
  unfold cothTail
  apply Real.log_nonneg
  have hlt : Real.exp (-w) < 1 := exp_neg_lt_one hw
  rw [le_div_iff₀ (by linarith)]
  linarith [Real.exp_pos (-w)]

/-- `cothTail w − cothTail c = ∫_{w}^{c} du / sinh u`. -/
theorem cothTail_sub (w c : ℝ) (hw : 0 < w) (hwc : w ≤ c) :
    cothTail w - cothTail c = ∫ u in w..c, 1 / Real.sinh u := by
  have hderiv : ∀ u ∈ Set.uIcc w c, HasDerivAt cothPrim (1 / Real.sinh u) u := by
    intro u hu
    rw [Set.uIcc_of_le hwc] at hu
    exact cothPrim_hasDerivAt (lt_of_lt_of_le hw hu.1)
  have hcont : ContinuousOn (fun u : ℝ => 1 / Real.sinh u) (Set.uIcc w c) := by
    rw [Set.uIcc_of_le hwc]
    apply continuousOn_const.div Real.continuous_sinh.continuousOn
    intro u hu
    exact ne_of_gt (sinh_pos_of_pos (lt_of_lt_of_le hw hu.1))
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hderiv (hcont.intervalIntegrable),
    cothTail_eq_neg_cothPrim w hw, cothTail_eq_neg_cothPrim c (lt_of_lt_of_le hw hwc)]
  ring

/-- On `[w, c]` the integrand dominates `e^{-c} / u`, so the tail exceeds
`e^{-c} · log(c / w)`. -/
theorem cothTail_ge' (w c : ℝ) (hw : 0 < w) (hwc : w ≤ c) :
    Real.exp (-c) * (Real.log c - Real.log w) + cothTail c ≤ cothTail w := by
  have hc : 0 < c := lt_of_lt_of_le hw hwc
  have hsub := cothTail_sub w c hw hwc
  have hcont1 : ContinuousOn (fun u : ℝ => Real.exp (-c) * u⁻¹) (Set.uIcc w c) := by
    rw [Set.uIcc_of_le hwc]
    apply continuousOn_const.mul
    exact continuousOn_inv₀.mono (fun u hu => ne_of_gt (lt_of_lt_of_le hw hu.1))
  have hcont2 : ContinuousOn (fun u : ℝ => 1 / Real.sinh u) (Set.uIcc w c) := by
    rw [Set.uIcc_of_le hwc]
    apply continuousOn_const.div Real.continuous_sinh.continuousOn
    intro u hu
    exact ne_of_gt (sinh_pos_of_pos (lt_of_lt_of_le hw hu.1))
  have hmono : (∫ u in w..c, Real.exp (-c) * u⁻¹) ≤ ∫ u in w..c, 1 / Real.sinh u := by
    apply intervalIntegral.integral_mono_on hwc hcont1.intervalIntegrable hcont2.intervalIntegrable
    intro u hu
    have hu0 : 0 < u := lt_of_lt_of_le hw hu.1
    have hs : 0 < Real.sinh u := sinh_pos_of_pos hu0
    have hle : Real.sinh u ≤ u * Real.exp c :=
      (sinh_le_self_mul_exp hu0.le).trans
        (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hu.2) hu0.le)
    have hec : Real.exp (-c) * Real.exp c = 1 := by rw [← Real.exp_add]; simp
    rw [one_div, ← div_eq_mul_inv, div_le_iff₀ hu0]
    rw [show Real.exp (-c) = (Real.sinh u)⁻¹ * u * Real.exp (-c) * Real.sinh u / u by
      field_simp]
    have : (Real.sinh u)⁻¹ * Real.sinh u = 1 := inv_mul_cancel₀ (ne_of_gt hs)
    calc
      (Real.sinh u)⁻¹ * u * Real.exp (-c) * Real.sinh u / u
          = (Real.sinh u)⁻¹ * (Real.exp (-c) * Real.sinh u) := by field_simp
      _ ≤ (Real.sinh u)⁻¹ * (Real.exp (-c) * (u * Real.exp c)) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul_of_nonneg_left hle (Real.exp_pos _).le) (inv_pos.mpr hs).le
      _ = (Real.sinh u)⁻¹ * u := by
          rw [show Real.exp (-c) * (u * Real.exp c) = u * (Real.exp (-c) * Real.exp c) by ring,
            hec, mul_one]
  have heq : (∫ u in w..c, Real.exp (-c) * u⁻¹) = Real.exp (-c) * (Real.log c - Real.log w) := by
    rw [intervalIntegral.integral_const_mul, integral_inv_of_pos hw hc,
      Real.log_div (ne_of_gt hc) (ne_of_gt hw)]
  linarith [heq, hmono, hsub]

theorem cothTail_ge (w c : ℝ) (hw : 0 < w) (hwc : w ≤ c) :
    Real.exp (-c) * (Real.log c - Real.log w) ≤ cothTail w := by
  have := cothTail_ge' w c hw hwc
  linarith [cothTail_nonneg c (lt_of_lt_of_le hw hwc)]

/-- The repository's `1/32` tail constant, in `cothTail` form. -/
theorem cothTail_one_div_32 : 6 * Real.log 2 < cothTail (1 / 32) := by
  have := six_log_two_lt_integral_one_div_sinh_Ioi
  rw [integral_one_div_sinh_Ioi (by norm_num : (0 : ℝ) < 1 / 32)] at this
  exact this

/-- Sharper floor below `1/32`: `e^{-1/32} · log(1/(32 w)) + 6 log 2 ≤ cothTail w`. -/
theorem cothTail_ge_below_32 (w : ℝ) (hw : 0 < w) (hw32 : w ≤ 1 / 32) :
    Real.exp (-(1 / 32 : ℝ)) * (Real.log (1 / 32) - Real.log w) + 6 * Real.log 2 ≤ cothTail w := by
  have h := cothTail_ge' w (1 / 32) hw hw32
  linarith [cothTail_one_div_32]

/-- Dyadic form: half-width `2^{-m}` (window `2^{1-m}`), cutoff `1/8`. -/
theorem cothTail_dyadic (m : ℕ) (hm : 4 ≤ m) :
    Real.exp (-(1 / 8 : ℝ)) * (((m : ℝ) - 4) * Real.log 2) ≤
      cothTail (2 * (2 : ℝ) ^ (-(m : ℝ))) := by
  have hw : (0 : ℝ) < 2 * (2 : ℝ) ^ (-(m : ℝ)) := by positivity
  have h16 : (2 : ℝ) ^ (-(m : ℝ)) ≤ 1 / 16 := by
    have hle : (2 : ℝ) ^ (-(m : ℝ)) ≤ (2 : ℝ) ^ (-(4 : ℝ)) := by
      apply Real.rpow_le_rpow_of_exponent_le (by norm_num)
      have : (4 : ℝ) ≤ m := by exact_mod_cast hm
      linarith
    have h4 : (2 : ℝ) ^ (-(4 : ℝ)) = 1 / 16 := by
      rw [Real.rpow_neg (by norm_num), show (4 : ℝ) = ((4 : ℕ) : ℝ) by norm_num,
        Real.rpow_natCast]
      norm_num
    rw [h4] at hle
    exact hle
  have hwc : 2 * (2 : ℝ) ^ (-(m : ℝ)) ≤ 1 / 8 := by linarith
  have h := cothTail_ge _ (1 / 8) hw hwc
  have hlog : Real.log (1 / 8) - Real.log (2 * (2 : ℝ) ^ (-(m : ℝ))) =
      ((m : ℝ) - 4) * Real.log 2 := by
    rw [Real.log_mul (by norm_num) (by positivity), Real.log_rpow (by norm_num),
      show (1 / 8 : ℝ) = 2 ^ (-(3 : ℝ)) by
        rw [Real.rpow_neg (by norm_num), show (3 : ℝ) = ((3 : ℕ) : ℝ) by norm_num,
          Real.rpow_natCast]
        norm_num,
      Real.log_rpow (by norm_num)]
    ring
  rw [hlog] at h
  exact h

end AEGIS.RHDyadicDiagonalV13

#print axioms AEGIS.RHDyadicDiagonalV13.diagonal_lower
#print axioms AEGIS.RHDyadicDiagonalV13.diagonal_lower_recovers_103_over_100
#print axioms AEGIS.RHDyadicDiagonalV13.cothTail_ge
#print axioms AEGIS.RHDyadicDiagonalV13.cothTail_dyadic
#print axioms AEGIS.RHDyadicDiagonalV13.cothTail_ge_below_32
~~~~~~

## RHNarrowDiagonalUpgradeV2

Path: `source/RHNarrowDiagonalUpgradeV2.lean`

Original source lines: 1–167

Full file SHA256: `2c8f9dd0c1ec972df8015b8d914058b1208ca52483f1dae261aa70bf6aa3d9b8`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/RHNarrowDiagonalUpgradeV2.lean

~~~~~~lean
import WeilSeparatedArchBridgeV31
import Mathlib.Tactic

/-!
AEGIS Omega -- narrower-support diagonal upgrade V2.

For total log-support width 1/64, the interval (1/64,1/32] is already
outside the autocorrelation support. Its actual transformed Archimedean
integrand is at most -16 E. The interval has length 1/64 and therefore
contributes at most -E/4, improving the inherited 103/100 lower bound to
32/25. This is a narrower test class, NOT a replacement for the width-1/32
class and NOT an assertion that the existing gNarrow has this support.
This candidate source requires pinned Lean replay and an axiom audit.
-/

open Set MeasureTheory Complex
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHNarrowDiagonalUpgradeV2
open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilThreeBlockCrossPrimeV28
open AEGIS.WeilSeparatedArchBridgeV31
open AEGIS.WeilWidthArchBudgetV26
open AEGIS.WeilWidthArchIntegralV27
open AEGIS.WeilWidthDiagonalArchFrontierV24
open AEGIS.WeilDiagonalKernelReductionV21
open AEGIS.WeilThreeBlockAnalyticConstantsV21
open AEGIS.WeilMixedAlgebraV2

def WidthOneSixtyFourAt (g : WeilCompactSmoothGV1) (a : ℝ) : Prop :=
  LogSupportIn g (a - 1 / 128) (a + 1 / 128)

theorem narrow_implies_retained_v2 (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneSixtyFourAt g a) : WidthOneThirtyTwoAt g a := by
  intro t ht
  have h := hw ht
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

theorem narrow_autocorrelation_zero_v2 (g : WeilCompactSmoothGV1) (a u : ℝ)
    (hw : WidthOneSixtyFourAt g a) (hu : (1 / 64 : ℝ) < u) :
    WeilAutocorrelationV1 g (Real.exp u) = 0 := by
  have hc := logCross_zero_outside g g
    (a - 1 / 128) (a + 1 / 128) (a - 1 / 128) (a + 1 / 128)
    u hw hw (Or.inr (by linarith))
  rw [logCross_eq_mixed_v28] at hc
  have hm := (mul_eq_zero.mp hc).resolve_left (by simp)
  change WeilAutocorrelationV1 g (Real.exp u) = 0 at hm
  exact hm

/-- Elementary upper bound from the inherited exponential constant; no
numerical approximation of the transcendental function is used. -/
theorem sinh_small_upper_v2 (u : ℝ) (hu : u ≤ (1 / 32 : ℝ)) :
    Real.sinh u ≤ (1 / 16 : ℝ) := by
  have he : Real.exp u ≤ (16 / 15 : ℝ) :=
    (Real.exp_le_exp.mpr (by linarith : u ≤ (1 / 16 : ℝ))).trans
      exp_one_over_16_upper.le
  have hn : (31 / 32 : ℝ) ≤ Real.exp (-u) := by
    linarith [Real.add_one_le_exp (-u)]
  rw [Real.sinh_eq]
  linarith

theorem narrow_middle_pointwise_v2 (g : WeilCompactSmoothGV1) (a u : ℝ)
    (hw : WidthOneSixtyFourAt g a)
    (hu : u ∈ Ioc (1 / 64 : ℝ) (1 / 32 : ℝ)) :
    widthArchLogIntegrandV26 g u ≤ -16 * energy g.1 := by
  have hE := energy_nonnegative g.1
  have hp : 0 < Real.sinh u :=
    AEGIS.WeilArchimedeanCothTailV1.sinh_pos_of_pos (by linarith [hu.1])
  have hs := sinh_small_upper_v2 u hu.2
  have hm := mul_le_mul_of_nonneg_left hs hE
  unfold widthArchLogIntegrandV26
  rw [narrow_autocorrelation_zero_v2 g a u hw hu.1]
  simp only [Complex.zero_re, mul_zero, zero_sub]
  apply (div_le_iff₀ hp).2
  nlinarith

theorem narrow_inner_integral_upgrade_v2 (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneSixtyFourAt g a) :
    (∫ u in Ioc (0 : ℝ) (1 / 32 : ℝ), widthArchLogIntegrandV26 g u) ≤
      energy g.1 * diagonalSmallV21 - (1 / 4 : ℝ) * energy g.1 := by
  let C : ℝ := energy g.1 * (Real.exp (1 / 64 : ℝ) / 2)
  have hE := energy_nonnegative g.1
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hfull := width_arch_log_integrableOn_v27 g
  have hl : IntegrableOn (widthArchLogIntegrandV26 g) (Ioc (0 : ℝ) (1 / 64 : ℝ)) :=
    hfull.mono_set (fun _ hu => hu.1)
  have hr : IntegrableOn (widthArchLogIntegrandV26 g) (Ioc (1 / 64 : ℝ) (1 / 32 : ℝ)) :=
    hfull.mono_set (by intro u hu; change 0 < u; linarith [hu.1])
  have hleft : (∫ u in Ioc (0 : ℝ) (1 / 64 : ℝ), widthArchLogIntegrandV26 g u) ≤
      (1 / 64 : ℝ) * C := by
    calc
      _ ≤ ∫ _u in Ioc (0 : ℝ) (1 / 64 : ℝ), C := by
        apply setIntegral_mono_on hl continuous_const.integrableOn_Ioc measurableSet_Ioc
        intro u hu
        exact width_arch_log_inner_pointwise_v26 g hu.1 (by linarith [hu.2])
      _ = _ := by
        rw [setIntegral_const, smul_eq_mul,
          Real.volume_real_Ioc_of_le (by norm_num : (0 : ℝ) ≤ 1 / 64)]
        ring
  have hright : (∫ u in Ioc (1 / 64 : ℝ) (1 / 32 : ℝ), widthArchLogIntegrandV26 g u) ≤
      -(1 / 4 : ℝ) * energy g.1 := by
    calc
      _ ≤ ∫ _u in Ioc (1 / 64 : ℝ) (1 / 32 : ℝ), -16 * energy g.1 := by
        apply setIntegral_mono_on hr continuous_const.integrableOn_Ioc measurableSet_Ioc
        intro u hu
        exact narrow_middle_pointwise_v2 g a u hw hu
      _ = _ := by
        rw [setIntegral_const, smul_eq_mul,
          Real.volume_real_Ioc_of_le (by norm_num : (1 / 64 : ℝ) ≤ 1 / 32)]
        ring
  have hu : Ioc (0 : ℝ) (1 / 64 : ℝ) ∪ Ioc (1 / 64 : ℝ) (1 / 32 : ℝ) =
      Ioc (0 : ℝ) (1 / 32 : ℝ) := by
    ext u
    constructor
    · rintro (h | h)
      · exact ⟨h.1, by linarith [h.2]⟩
      · exact ⟨by linarith [h.1], h.2⟩
    · intro h
      by_cases hsplit : u ≤ (1 / 64 : ℝ)
      · exact Or.inl ⟨h.1, hsplit⟩
      · exact Or.inr ⟨lt_of_not_ge hsplit, h.2⟩
  have hd : Disjoint (Ioc (0 : ℝ) (1 / 64 : ℝ)) (Ioc (1 / 64 : ℝ) (1 / 32 : ℝ)) := by
    rw [Set.disjoint_left]
    intro u h1 h2
    linarith [h1.2, h2.1]
  rw [← hu, setIntegral_union hd measurableSet_Ioc hl hr]
  calc
    _ ≤ (1 / 64 : ℝ) * C - (1 / 4 : ℝ) * energy g.1 := by linarith
    _ ≤ (1 / 32 : ℝ) * C - (1 / 4 : ℝ) * energy g.1 := by nlinarith
    _ = _ := by dsimp [C, diagonalSmallV21]; ring

theorem narrow_arch_budget_upgrade_v2 (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneSixtyFourAt g a) :
    (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re ≤
      energy g.1 * (diagonalSmallV21 - diagonalTailV24) - (1 / 4 : ℝ) * energy g.1 := by
  rw [archimedean_real_eq_log_integral_v27, width_arch_log_split_v27,
    width_arch_tail_integral_eq_v27 g a (narrow_implies_retained_v2 g a hw)]
  have hi := narrow_inner_integral_upgrade_v2 g a hw
  linarith

theorem narrow_diagonal_32_over_25_v2 (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneSixtyFourAt g a) :
    (32 / 25 : ℝ) * energy g.1 ≤ -(B g g).re := by
  have hp := width_diagonal_prime_sum_zero_v24 g a (narrow_implies_retained_v2 g a hw)
  have hE := energy_nonnegative g.1
  have hf : (103 / 100 : ℝ) ≤ diagonalTailV24 - diagonalKappaV21 - diagonalSmallV21 := by
    have ht := diagonal_tail_gt_six_log_two_v24
    have hc := diagonal_constant_floor
    have hn := certificate_diagonal_threshold
    unfold diagonalKappaV21 diagonalSmallV21
    linarith
  have hm := mul_le_mul_of_nonneg_left hf hE
  have hb := narrow_arch_budget_upgrade_v2 g a hw
  rw [actual_diagonal_rhs_decomposition g hp]
  nlinarith

end AEGIS.RHNarrowDiagonalUpgradeV2

#print axioms AEGIS.RHNarrowDiagonalUpgradeV2.narrow_implies_retained_v2
#print axioms AEGIS.RHNarrowDiagonalUpgradeV2.narrow_autocorrelation_zero_v2
#print axioms AEGIS.RHNarrowDiagonalUpgradeV2.sinh_small_upper_v2
#print axioms AEGIS.RHNarrowDiagonalUpgradeV2.narrow_middle_pointwise_v2
#print axioms AEGIS.RHNarrowDiagonalUpgradeV2.narrow_inner_integral_upgrade_v2
#print axioms AEGIS.RHNarrowDiagonalUpgradeV2.narrow_arch_budget_upgrade_v2
#print axioms AEGIS.RHNarrowDiagonalUpgradeV2.narrow_diagonal_32_over_25_v2
~~~~~~

## AEGISOverlay.RHKreinM8CertificateV1

Path: `source/AEGISOverlay/RHKreinM8CertificateV1.lean`

Original source lines: 1–79

Full file SHA256: `ca03343d5188cef1e15f9adc998977484dfbb21640be83544ecd91d9698a865c`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinM8CertificateV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinExplicitCorrectionV1
import Mathlib.Tactic

/-!
# Exact M8 payload for the order-19 finite Krein certificate

The numerical checker uses a degree-seven Taylor jet for the correction and
the uniform eighth-derivative budget

  M8 =
    sum_i 2*w*|a_i|*(u_i+w)^8
    + sum_j |b_j|*(2/h)^j*(L+19*h)^8.

This module recomputes that quantity entirely in rational arithmetic from
the exact coefficients already compiled into RHKreinExplicitCorrectionV1
and proves that it equals the rational value serialized in
krein_order19_v1/certificate.json.

This theorem validates the exact arithmetic payload only. The analytic
statement |C^(8)(t)| <= M8 is a separate proof obligation.

AUTHORITY_EFFECT = NONE.
RH is not asserted here.
-/

open scoped BigOperators

set_option autoImplicit false

namespace AEGIS.RHKreinM8CertificateV1

open AEGIS.RHKreinExplicitCorrectionV1

def hatCenterQ (j : Fin 199) : ℚ :=
  ((j.val : ℚ) + 41) / 50

def certificateM8Q : ℚ :=
  (∑ j : Fin 199,
      2 * (1 / 50 : ℚ) * |hatCoefficient j| *
        (hatCenterQ j + 1 / 50) ^ 8) +
    ∑ j : Fin 5,
      |splineCoefficient j| *
        (2 : ℚ) ^ j.val / (1 / 1000 : ℚ) ^ j.val *
        (819 / 1000 : ℚ) ^ 8

def serializedM8Q : ℚ :=
  15958085437561175275197089938898547979087185237 /
    5000000000000000000000000000000000

set_option maxRecDepth 16384 in
set_option maxHeartbeats 16000000 in
theorem certificateM8_eq_serialized_v1 :
    certificateM8Q = serializedM8Q := by
  norm_num [certificateM8Q, serializedM8Q, hatCenterQ,
    hatCoefficient, splineCoefficient, Fin.sum_univ_succ]

theorem serializedM8Q_pos_v1 : 0 < serializedM8Q := by
  norm_num [serializedM8Q]

end AEGIS.RHKreinM8CertificateV1

#print axioms AEGIS.RHKreinM8CertificateV1.certificateM8_eq_serialized_v1
#print axioms AEGIS.RHKreinM8CertificateV1.serializedM8Q_pos_v1
~~~~~~

## AEGISOverlay.RHKreinSplineL1NormV1

Path: `source/AEGISOverlay/RHKreinSplineL1NormV1.lean`

Original source lines: 1–277

Full file SHA256: `02a114526815feb3e7ad32dfaf6d65e4c8477ba20454b08edb5b04410516216d`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinSplineL1NormV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinSplineL1DerivativeBoundV1
import Mathlib.MeasureTheory.Group.Integral
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Analysis.Calculus.Deriv.Support

/-!
# L1 derivative bounds for the genuine normalized-box spline

The existing FTC identity is combined with translation invariance of Lebesgue
measure and the integral triangle inequality. Each differentiated averaging
step costs at most 2/h in L1. Induction gives the order-19 bounds through order
seventeen, with integrability proved, not inferred from a totalized integral.
The weighted eighth-moment bound supplies the spline part of the M8 budget.

No correction-function sign, finite-cell certificate, or RH is asserted.
AUTHORITY_EFFECT = NONE.
-/

open Set MeasureTheory Convolution

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSplineL1NormV1

open AEGIS.RHKreinSplineSupportV1
open AEGIS.RHKreinSplineContinuityV1
open AEGIS.RHKreinSplineL1DerivativeBoundV1
open AEGIS.RHBoxFourierComplementarityV1

/-- The centered difference produced by differentiating one box average. -/
def boxDifference (h : ℝ) (f : ℝ → ℂ) (x : ℝ) : ℂ :=
  (h : ℂ)⁻¹ * (f (x + h / 2) - f (x - h / 2))

theorem boxDifference_integrable (h : ℝ) (f : ℝ → ℂ) (hf : Integrable f) :
    Integrable (boxDifference h f) :=
  ((hf.comp_add_right (h / 2)).sub (hf.comp_sub_right (h / 2))).const_mul _

/-- Translation invariance gives the precise L1 cost of the centered difference. -/
theorem integral_norm_boxDifference_le (f : ℝ → ℂ) (hf : Integrable f)
    {h : ℝ} (hh : 0 < h) :
    (∫ x : ℝ, ‖boxDifference h f x‖) ≤ (2 / h) * ∫ x : ℝ, ‖f x‖ := by
  have hp := (hf.comp_add_right (h / 2)).norm
  have hm := (hf.comp_sub_right (h / 2)).norm
  calc
    (∫ x : ℝ, ‖boxDifference h f x‖) ≤
        ∫ x : ℝ, h⁻¹ * (‖f (x + h / 2)‖ + ‖f (x - h / 2)‖) := by
      apply integral_mono (boxDifference_integrable h f hf).norm
        ((hp.add hm).const_mul _)
      intro x
      dsimp only [boxDifference]
      rw [norm_mul, norm_inv, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hh]
      exact mul_le_mul_of_nonneg_left (norm_sub_le _ _) (inv_nonneg.mpr hh.le)
    _ = (2 / h) * ∫ x : ℝ, ‖f x‖ := by
      rw [integral_const_mul, integral_add hp hm,
        integral_add_right_eq_self (fun x : ℝ => ‖f x‖) (h / 2),
        integral_sub_right_eq_self (fun x : ℝ => ‖f x‖) (h / 2)]
      ring

/-- The derivative is an integrable genuine function. -/
theorem deriv_convolution_normalizedBox_integrable (f : ℝ → ℂ)
    (hc : Continuous f) (hf : Integrable f) {h : ℝ} (hh : 0 < h) :
    Integrable (deriv (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h)) := by
  have he : deriv (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) =
      boxDifference h f := funext (deriv_convolution_normalizedBox f hc hh)
  rw [he]
  exact boxDifference_integrable h f hf

/-- The actual moving-average derivative, not a surrogate, has norm at most 2/h. -/
theorem integral_norm_deriv_convolution_normalizedBox_le (f : ℝ → ℂ)
    (hc : Continuous f) (hf : Integrable f) {h : ℝ} (hh : 0 < h) :
    (∫ x : ℝ, ‖deriv (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) x‖) ≤
      (2 / h) * ∫ x : ℝ, ‖f x‖ := by
  have he : deriv (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) =
      boxDifference h f := funext (deriv_convolution_normalizedBox f hc hh)
  rw [he]
  exact integral_norm_boxDifference_le f hf hh

/-- Integral triangle inequality followed by Fubini, with both factors integrable. -/
theorem integral_norm_convolution_le (f g : ℝ → ℂ)
    (hf : Integrable f) (hg : Integrable g) :
    (∫ x : ℝ, ‖(f ⋆[ContinuousLinearMap.mul ℂ ℂ] g) x‖) ≤
      (∫ x : ℝ, ‖f x‖) * ∫ x : ℝ, ‖g x‖ := by
  calc
    (∫ x : ℝ, ‖(f ⋆[ContinuousLinearMap.mul ℂ ℂ] g) x‖) ≤
        ∫ x : ℝ, ((fun y => ‖f y‖) ⋆[ContinuousLinearMap.mul ℝ ℝ]
          (fun y => ‖g y‖)) x := by
      apply integral_mono (hf.integrable_convolution _ hg).norm
        (hf.norm.integrable_convolution _ hg.norm)
      intro x
      simpa only [convolution_def, ContinuousLinearMap.mul_apply', norm_mul] using
        norm_integral_le_integral_norm (fun t : ℝ => f t * g (x - t))
    _ = (∫ x : ℝ, ‖f x‖) * ∫ x : ℝ, ‖g x‖ := by
      simpa only [ContinuousLinearMap.mul_apply'] using
        integral_convolution (ContinuousLinearMap.mul ℝ ℝ) hf.norm hg.norm

/-- The normalized interval density has L1 mass exactly one. -/
theorem integral_norm_normalizedBox {h : ℝ} (hh : 0 < h) :
    (∫ x : ℝ, ‖normalizedBox h x‖) = 1 := by
  have he : (fun x : ℝ => ‖normalizedBox h x‖) =
      (Ioc (-(h / 2)) (h / 2)).indicator (fun _ : ℝ => h⁻¹) := by
    funext x
    by_cases hx : x ∈ Ioc (-(h / 2)) (h / 2)
    · simp [normalizedBox, boxProfile, hx, norm_inv, Complex.norm_real,
        Real.norm_eq_abs, abs_of_pos hh]
    · simp [normalizedBox, boxProfile, hx]
  rw [he, integral_indicator measurableSet_Ioc,
    ← intervalIntegral.integral_of_le (by linarith : -(h / 2) ≤ h / 2),
    intervalIntegral.integral_const]
  simp only [smul_eq_mul]
  convert mul_inv_cancel₀ hh.ne' using 1
  ring

/-- All normalized-box convolution powers have L1 norm at most one. -/
theorem integral_norm_splineCore_le_one {h : ℝ} (hh : 0 < h) (n : ℕ) :
    (∫ x : ℝ, ‖splineCore h n x‖) ≤ 1 := by
  induction n with
  | zero =>
    exact le_of_eq (integral_norm_normalizedBox hh)
  | succ n ih =>
    calc
      (∫ x : ℝ, ‖splineCore h (n + 1) x‖) ≤
          (∫ x : ℝ, ‖splineCore h n x‖) * ∫ x : ℝ, ‖normalizedBox h x‖ :=
        integral_norm_convolution_le _ _ (splineCore_integrable h n)
          (normalizedBox_integrable h)
      _ ≤ 1 := by rw [integral_norm_normalizedBox hh, mul_one]; exact ih

/-- Finite-order differentiation commutes with the centered difference. -/
theorem iteratedDeriv_boxDifference (j : ℕ) (f : ℝ → ℂ)
    (hc : ContDiff ℝ j f) (h : ℝ) :
    iteratedDeriv j (boxDifference h f) = boxDifference h (iteratedDeriv j f) := by
  have hp : ContDiff ℝ j (fun y : ℝ => f (y + h / 2)) :=
    hc.comp (contDiff_id.add contDiff_const)
  have hm : ContDiff ℝ j (fun y : ℝ => f (y - h / 2)) :=
    hc.comp (contDiff_id.sub contDiff_const)
  funext x
  unfold boxDifference
  rw [iteratedDeriv_const_mul_field, iteratedDeriv_fun_sub hp.contDiffAt hm.contDiffAt,
    iteratedDeriv_comp_add_const j f (h / 2), iteratedDeriv_comp_sub_const j f (h / 2)]

/-- Each derivative consumes one box; two undifferentiated boxes remain.
The integrability component prevents vacuous use of totalized Bochner integrals. -/
theorem splineCore_iteratedDeriv_L1 {h : ℝ} (hh : 0 < h) (j n : ℕ) :
    Integrable (iteratedDeriv j (splineCore h (n + j + 1))) ∧
      (∫ x : ℝ, ‖iteratedDeriv j (splineCore h (n + j + 1)) x‖) ≤ (2 / h) ^ j := by
  induction j with
  | zero =>
    simpa only [iteratedDeriv_zero, pow_zero] using
      (show Integrable (splineCore h (n + 0 + 1)) ∧
        (∫ x : ℝ, ‖splineCore h (n + 0 + 1) x‖) ≤ 1 from
        ⟨splineCore_integrable h _, integral_norm_splineCore_le_one hh _⟩)
  | succ j ih =>
    have hc : ContDiff ℝ j (splineCore h (n + j + 1)) :=
      (splineCore_contDiff hh.le (n + j)).of_le (by
        exact_mod_cast (show j ≤ n + j by omega))
    have he : deriv (splineCore h (n + (j + 1) + 1)) =
        boxDifference h (splineCore h (n + j + 1)) := by
      rw [show n + (j + 1) + 1 = (n + j + 1) + 1 by omega, splineCore]
      exact funext (deriv_convolution_normalizedBox _ hc.continuous hh)
    rw [iteratedDeriv_succ', he, iteratedDeriv_boxDifference j _ hc h]
    refine ⟨boxDifference_integrable h _ ih.1, ?_⟩
    calc
      (∫ x : ℝ, ‖boxDifference h (iteratedDeriv j (splineCore h (n + j + 1))) x‖) ≤
          (2 / h) * ∫ x : ℝ, ‖iteratedDeriv j (splineCore h (n + j + 1)) x‖ :=
        integral_norm_boxDifference_le _ ih.1 hh
      _ ≤ (2 / h) * (2 / h) ^ j :=
        mul_le_mul_of_nonneg_left ih.2 (by positivity)
      _ = (2 / h) ^ (j + 1) := (pow_succ' _ _).symm

/-- The genuine order-19 spline satisfies the L1 derivative budget through order 17. -/
theorem spline19_iteratedDeriv_L1 (L : ℝ) {h : ℝ} (hh : 0 < h)
    (j : ℕ) (hj : j ≤ 17) :
    Integrable (iteratedDeriv j (spline19 L h)) ∧
      (∫ x : ℝ, ‖iteratedDeriv j (spline19 L h) x‖) ≤ (2 / h) ^ j := by
  have hc := splineCore_iteratedDeriv_L1 hh j (17 - j)
  rw [show 17 - j + j + 1 = 18 by omega] at hc
  unfold spline19
  rw [iteratedDeriv_comp_sub_const]
  refine ⟨hc.1.comp_sub_right _, ?_⟩
  rw [integral_sub_right_eq_self
    (fun x : ℝ => ‖iteratedDeriv j (splineCore h 18) x‖) (L + 19 * h / 2)]
  exact hc.2

/-- The same budget in the derivative-iterate convention of the certificate. -/
theorem spline19_derivative_L1 (L : ℝ) {h : ℝ} (hh : 0 < h)
    (j : ℕ) (hj : j ≤ 17) :
    Integrable (deriv^[j] (spline19 L h)) ∧
      (∫ x : ℝ, ‖(deriv^[j] (spline19 L h)) x‖) ≤ (2 / h) ^ j := by
  simpa only [iteratedDeriv_eq_iterate] using spline19_iteratedDeriv_L1 L hh j hj

private theorem tsupport_iteratedDeriv_subset (f : ℝ → ℂ) (j : ℕ) :
    tsupport (iteratedDeriv j f) ⊆ tsupport f := by
  induction j with
  | zero => exact Subset.rfl
  | succ j ih =>
    simpa only [iteratedDeriv_succ] using tsupport_deriv_subset.trans ih

/-- The moment bound used for the eighth Fourier derivative of each spline column. -/
theorem spline19_derivative_weighted_eighth_L1 (L : ℝ) (hL : 0 ≤ L)
    {h : ℝ} (hh : 0 < h) (j : ℕ) (hj : j ≤ 17) :
    Integrable (fun x : ℝ => |x| ^ 8 * ‖(deriv^[j] (spline19 L h)) x‖) ∧
      (∫ x : ℝ, |x| ^ 8 * ‖(deriv^[j] (spline19 L h)) x‖) ≤
        (2 / h) ^ j * (L + 19 * h) ^ 8 := by
  let f : ℝ → ℂ := deriv^[j] (spline19 L h)
  obtain ⟨hi, hb⟩ := spline19_derivative_L1 L hh j hj
  have hs : tsupport f ⊆ Icc L (L + 19 * h) := by
    apply (show tsupport f ⊆ tsupport (spline19 L h) from by
      simpa only [f, iteratedDeriv_eq_iterate] using
        tsupport_iteratedDeriv_subset (spline19 L h) j).trans
    exact closure_minimal (fun x hx => spline19_support L h x hx) isClosed_Icc
  have hbound (x : ℝ) : |x| ^ 8 * ‖f x‖ ≤ (L + 19 * h) ^ 8 * ‖f x‖ := by
    by_cases hx : f x = 0
    · simp [hx]
    · have hxI := hs (subset_closure hx)
      have hx0 : 0 ≤ x := hL.trans hxI.1
      rw [abs_of_nonneg hx0]
      gcongr
      exact hxI.2
  have hmeas : AEStronglyMeasurable (fun x : ℝ => |x| ^ 8 * ‖f x‖) volume :=
    (continuous_abs.pow 8).aestronglyMeasurable.mul hi.norm.aestronglyMeasurable
  have hiw : Integrable (fun x : ℝ => |x| ^ 8 * ‖f x‖) := by
    refine (hi.norm.const_mul ((L + 19 * h) ^ 8)).mono' hmeas ?_
    exact Filter.Eventually.of_forall (fun x => by
      rw [Real.norm_eq_abs, abs_of_nonneg (by positivity)]
      exact hbound x)
  refine ⟨hiw, ?_⟩
  calc
    (∫ x : ℝ, |x| ^ 8 * ‖f x‖) ≤ ∫ x : ℝ, (L + 19 * h) ^ 8 * ‖f x‖ :=
      integral_mono hiw (hi.norm.const_mul _) hbound
    _ = (L + 19 * h) ^ 8 * ∫ x : ℝ, ‖f x‖ := integral_const_mul _ _
    _ ≤ (L + 19 * h) ^ 8 * (2 / h) ^ j :=
      mul_le_mul_of_nonneg_left hb (by positivity)
    _ = (2 / h) ^ j * (L + 19 * h) ^ 8 := mul_comm _ _

/-- Exact spline-column constants used in the rational M8 payload.
This is not the full correction M8 theorem or the finite-cell certificate. -/
theorem certificate_spline_columns_weighted_eighth_L1 (j : Fin 5) :
    Integrable (fun x : ℝ => |x| ^ 8 *
      ‖(deriv^[j.val] (spline19 (4 / 5) (1 / 1000))) x‖) ∧
      (∫ x : ℝ, |x| ^ 8 * ‖(deriv^[j.val] (spline19 (4 / 5) (1 / 1000))) x‖) ≤
        (2000 : ℝ) ^ j.val * (819 / 1000 : ℝ) ^ 8 := by
  have hj : j.val ≤ 17 := by omega
  convert spline19_derivative_weighted_eighth_L1 (4 / 5) (by norm_num)
    (h := 1 / 1000) (by norm_num) j.val hj using 1
  norm_num

end AEGIS.RHKreinSplineL1NormV1

#print axioms AEGIS.RHKreinSplineL1NormV1.boxDifference_integrable
#print axioms AEGIS.RHKreinSplineL1NormV1.integral_norm_boxDifference_le
#print axioms AEGIS.RHKreinSplineL1NormV1.deriv_convolution_normalizedBox_integrable
#print axioms AEGIS.RHKreinSplineL1NormV1.integral_norm_deriv_convolution_normalizedBox_le
#print axioms AEGIS.RHKreinSplineL1NormV1.integral_norm_convolution_le
#print axioms AEGIS.RHKreinSplineL1NormV1.integral_norm_normalizedBox
#print axioms AEGIS.RHKreinSplineL1NormV1.integral_norm_splineCore_le_one
#print axioms AEGIS.RHKreinSplineL1NormV1.iteratedDeriv_boxDifference
#print axioms AEGIS.RHKreinSplineL1NormV1.splineCore_iteratedDeriv_L1
#print axioms AEGIS.RHKreinSplineL1NormV1.spline19_iteratedDeriv_L1
#print axioms AEGIS.RHKreinSplineL1NormV1.spline19_derivative_L1
#print axioms AEGIS.RHKreinSplineL1NormV1.spline19_derivative_weighted_eighth_L1
#print axioms AEGIS.RHKreinSplineL1NormV1.certificate_spline_columns_weighted_eighth_L1
~~~~~~

## AEGISOverlay.RHKreinSplineL1DerivativeBoundV1

Path: `source/AEGISOverlay/RHKreinSplineL1DerivativeBoundV1.lean`

Original source lines: 1–79

Full file SHA256: `cab8885e68a886fb7fe1e054c14b2a9c29d65b9f520a0c641f32a82cdb22b1e4`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinSplineL1DerivativeBoundV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinSplineContinuityV1
import Mathlib.Tactic

/-!
# Moving-average derivative primitive for the Krein M8 closure

The order-19 spline is a repeated convolution with the normalized interval
box.  This module proves the ordinary derivative identity for one averaging
step.  It is the FTC input for the exact L1 estimate used by the M8 certificate.

No numerical certificate and no RH statement is asserted here.
AUTHORITY_EFFECT = NONE.
-/

open Set MeasureTheory Convolution

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSplineL1DerivativeBoundV1

open AEGIS.RHKreinSplineSupportV1
open AEGIS.RHKreinSplineContinuityV1

/-- Exact derivative of convolution with the normalized interval box. -/
theorem deriv_convolution_normalizedBox
    (f : ℝ → ℂ) (hf : Continuous f) {h : ℝ} (hh : 0 < h) (x : ℝ) :
    deriv (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) x =
      (h : ℂ)⁻¹ * (f (x + h / 2) - f (x - h / 2)) := by
  have hfun :
      (f ⋆[ContinuousLinearMap.mul ℂ ℂ] normalizedBox h) =
        fun y : ℝ =>
          (h : ℂ)⁻¹ *
            ((∫ u in (0 : ℝ)..(y + h / 2), f u) -
              ∫ u in (0 : ℝ)..(y - h / 2), f u) := by
    funext y
    rw [convolution_normalizedBox f hh.le y,
      intervalIntegral.integral_interval_sub_left
        (hf.intervalIntegrable _ _) (hf.intervalIntegrable _ _)]
  have hp0 :
      HasDerivAt (fun z : ℝ => ∫ u in (0 : ℝ)..z, f u)
        (f (x + h / 2)) (x + h / 2) :=
    (hf.integral_hasStrictDerivAt 0 (x + h / 2)).hasDerivAt
  have hm0 :
      HasDerivAt (fun z : ℝ => ∫ u in (0 : ℝ)..z, f u)
        (f (x - h / 2)) (x - h / 2) :=
    (hf.integral_hasStrictDerivAt 0 (x - h / 2)).hasDerivAt
  have hp :
      HasDerivAt (fun y : ℝ => ∫ u in (0 : ℝ)..(y + h / 2), f u)
        (f (x + h / 2)) x := by
    simpa only [Function.comp_def, one_smul] using
      hp0.scomp x ((hasDerivAt_id' x).add_const (h / 2))
  have hm :
      HasDerivAt (fun y : ℝ => ∫ u in (0 : ℝ)..(y - h / 2), f u)
        (f (x - h / 2)) x := by
    simpa only [Function.comp_def, one_smul] using
      hm0.scomp x ((hasDerivAt_id' x).sub_const (h / 2))
  rw [hfun]
  exact ((hp.sub hm).const_mul ((h : ℂ)⁻¹)).deriv

end AEGIS.RHKreinSplineL1DerivativeBoundV1

#print axioms AEGIS.RHKreinSplineL1DerivativeBoundV1.deriv_convolution_normalizedBox
~~~~~~

## AEGISOverlay.RHKreinFourierTaylorBoundV1

Path: `source/AEGISOverlay/RHKreinFourierTaylorBoundV1.lean`

Original source lines: 1–141

Full file SHA256: `aa7dfd6c7657fcfc17463b22275b070700339aed242fa29582e7f1b6c88bd6e6`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinFourierTaylorBoundV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinFiniteIntervalKernelV1
import Mathlib.Analysis.Fourier.FourierTransformDeriv
import Mathlib.Tactic

/-!
# Fourier-moment control of the finite Krein Taylor remainder

The external order-19 certificate bounds the eighth derivative of its angular
Fourier correction by an exact time-domain moment.  This file proves the
general analytic bridge behind that step.

No certificate coefficients and no RH statement occur here.
-/

open MeasureTheory FourierTransform Complex
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFourierTaylorBoundV1

/-- Scale converting Mathlib frequency to the angular convention used by the
Krein certificate. -/
def angularScale : ℝ := -(2 * Real.pi)⁻¹

/-- Mathlib Fourier transform expressed in angular frequency. -/
def angularFourier (f : ℝ → ℂ) (t : ℝ) : ℂ :=
  𝓕 f (angularScale * t)

/-- The algebraic scale is exactly the repository convention `-t/(2*pi)`. -/
theorem angularScale_mul (t : ℝ) :
    angularScale * t = -t / (2 * Real.pi) := by
  unfold angularScale
  field_simp [Real.pi_ne_zero]

/-- Integrable ordinary polynomial moments through order eight. -/
def HasMomentsUpToEight (f : ℝ → ℂ) : Prop :=
  ∀ n : ℕ, n ≤ 8 → Integrable (fun x : ℝ => x ^ n • f x)

set_option maxHeartbeats 2000000 in
/-- Every continuous compactly supported function has the finite polynomial
moments needed for the eighth-order Fourier Taylor argument. -/
theorem hasMomentsUpToEight_of_continuous_compact
    (f : ℝ → ℂ) (hc : Continuous f) (hs : HasCompactSupport f) :
    HasMomentsUpToEight f := by
  intro n _hn
  have hcont : Continuous (fun x : ℝ => x ^ n • f x) :=
    (continuous_id.pow n).smul hc
  have hs' : HasCompactSupport (fun x : ℝ => x ^ n • f x) := by
    rw [hasCompactSupport_iff_eventuallyEq] at hs ⊢
    exact hs.mono fun x hx => by simp [hx]
  exact hcont.integrable_of_hasCompactSupport hs'

/-- Ordinary moments imply the norm moments required by Mathlib's Fourier
smoothness theorem. -/
theorem norm_moment_integrable
    (f : ℝ → ℂ) (h : HasMomentsUpToEight f)
    (n : ℕ) (hn : n ≤ 8) :
    Integrable (fun x : ℝ => ‖x‖ ^ n * ‖f x‖) := by
  have hi := (h n hn).norm
  simpa only [norm_smul, norm_pow] using hi

/-- The Fourier transform is C^8 under the committed moment hypothesis. -/
theorem fourier_contDiff_eight
    (f : ℝ → ℂ) (h : HasMomentsUpToEight f) :
    ContDiff ℝ 8 (𝓕 f) := by
  apply Real.contDiff_fourier
  intro n hn
  have hn' : n ≤ 8 := by exact_mod_cast hn
  exact norm_moment_integrable f h n hn'

/-- Exact eighth derivative formula before the angular rescaling. -/
theorem fourier_eighth_derivative
    (f : ℝ → ℂ) (h : HasMomentsUpToEight f) :
    iteratedDeriv 8 (𝓕 f) =
      𝓕 (fun x : ℝ => (-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8 • f x) := by
  apply Real.iteratedDeriv_fourier (N := (8 : ℕ∞))
  · intro n hn
    have hn' : n ≤ 8 := by exact_mod_cast hn
    exact h n hn'
  · norm_num

/-- Exact chain-rule identity for the angular Fourier transform. -/
theorem angular_eighth_derivative
    (f : ℝ → ℂ) (h : HasMomentsUpToEight f) :
    iteratedDeriv 8 (angularFourier f) =
      fun t : ℝ =>
        angularScale ^ 8 •
          𝓕 (fun x : ℝ => (-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8 • f x)
            (angularScale * t) := by
  unfold angularFourier
  rw [iteratedDeriv_comp_const_smul (n := 8)
    (fourier_contDiff_eight f h) angularScale]
  rw [fourier_eighth_derivative f h]

/-- The eighth angular derivative is bounded by the L1 norm of the eighth
Fourier multiplier, with the exact angular scaling factor exposed. -/
theorem angular_eighth_derivative_norm_le
    (f : ℝ → ℂ) (h : HasMomentsUpToEight f) (t : ℝ) :
    ‖iteratedDeriv 8 (angularFourier f) t‖ ≤
      |angularScale| ^ 8 *
        ∫ x : ℝ, ‖((-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8) • f x‖ := by
  rw [angular_eighth_derivative f h]
  rw [norm_smul, Real.norm_eq_abs, abs_pow]
  apply mul_le_mul_of_nonneg_left
  · change ‖VectorFourier.fourierIntegral Real.fourierChar volume
      (innerₗ ℝ)
      (fun x : ℝ => (-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8 • f x)
      (angularScale * t)‖ ≤
        ∫ x : ℝ, ‖((-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8) • f x‖
    exact VectorFourier.norm_fourierIntegral_le_integral_norm
      Real.fourierChar volume (innerₗ ℝ)
      (fun x : ℝ => (-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8 • f x)
      (angularScale * t)
  · positivity

end AEGIS.RHKreinFourierTaylorBoundV1

#print axioms AEGIS.RHKreinFourierTaylorBoundV1.hasMomentsUpToEight_of_continuous_compact
#print axioms AEGIS.RHKreinFourierTaylorBoundV1.norm_moment_integrable
#print axioms AEGIS.RHKreinFourierTaylorBoundV1.fourier_contDiff_eight
#print axioms AEGIS.RHKreinFourierTaylorBoundV1.fourier_eighth_derivative
#print axioms AEGIS.RHKreinFourierTaylorBoundV1.angular_eighth_derivative
#print axioms AEGIS.RHKreinFourierTaylorBoundV1.angular_eighth_derivative_norm_le
~~~~~~

## AEGISOverlay.RHKreinFiniteIntervalKernelV1

Path: `source/AEGISOverlay/RHKreinFiniteIntervalKernelV1.lean`

Original source lines: 1–327

Full file SHA256: `6179170c861fe6d151962df89fff8ec1d86dbfa47db63c98ca09651f14d87de5`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinFiniteIntervalKernelV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Calculus.Taylor
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Tactic

/-!
# Kernel-side primitives for the finite Krein interval certificate

This file contains no numerical interval certificate and no RH claim.  It
formalizes the reusable correctness layer needed by the integer checker:

* exact high-precision enclosures for pi and log 2 already proved by Mathlib;
* arbitrary-order Taylor enclosure of real sine/cosine through
  `Complex.exp_bound`;
* Lipschitz transport of a certified center value across a real cell;
* scaled-phase transport, used for the many rational Fourier frequencies in
  the order-19 correction.

The intended consumer is the finite interval `|t| <= 300` part of
`RHKreinExplicitCorrectionV1.PointwiseCertificate`.
-/

open Complex
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFiniteIntervalKernelV1

/-- The exact Mathlib twenty-decimal enclosure of pi. -/
theorem pi_enclosure :
    (3.14159265358979323846 : ℝ) < Real.pi ∧
      Real.pi < (3.14159265358979323847 : ℝ) :=
  ⟨Real.pi_gt_d20, Real.pi_lt_d20⟩

/-- The exact Mathlib ten-decimal enclosure used for the prime-two phase. -/
theorem log_two_enclosure :
    (0.6931471803 : ℝ) < Real.log 2 ∧
      Real.log 2 < (0.6931471808 : ℝ) :=
  ⟨Real.log_two_gt_d9, Real.log_two_lt_d9⟩

/-- Complex Taylor polynomial for `exp (i*x)`, with `n` terms. -/
def expIPartial (n : ℕ) (x : ℝ) : ℂ :=
  ∑ m ∈ Finset.range n, (((x : ℂ) * I) ^ m) / m.factorial

/-- Arbitrary-order rigorous Taylor enclosure for `exp (i*x)` on `|x| <= 1`.
This is the core high-precision primitive; for fixed rational `x` and `n`,
the polynomial and the error constant reduce to exact arithmetic. -/
theorem expIPartial_error (n : ℕ) (x : ℝ) (hn : 0 < n) (hx : |x| ≤ 1) :
    ‖Complex.exp ((x : ℂ) * I) - expIPartial n x‖ ≤
      |x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
  have hxc : ‖((x : ℂ) * I)‖ ≤ 1 := by
    simpa [Complex.norm_mul, Real.norm_eq_abs] using hx
  have h := Complex.exp_bound (x := ((x : ℂ) * I)) hxc hn
  simpa [expIPartial, Complex.norm_mul, Real.norm_eq_abs] using h

/-- Project the arbitrary-order exponential enclosure to the sine coordinate. -/
theorem sin_expIPartial_error (n : ℕ) (x : ℝ) (hn : 0 < n) (hx : |x| ≤ 1) :
    |Real.sin x - (expIPartial n x).im| ≤
      |x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
  have hnorm := expIPartial_error n x hn hx
  have him := Complex.abs_im_le_norm
    (Complex.exp ((x : ℂ) * I) - expIPartial n x)
  have heq :
      (Complex.exp ((x : ℂ) * I) - expIPartial n x).im =
        Real.sin x - (expIPartial n x).im := by
    simp
  rw [heq] at him
  exact him.trans hnorm

/-- Project the arbitrary-order exponential enclosure to the cosine coordinate. -/
theorem cos_expIPartial_error (n : ℕ) (x : ℝ) (hn : 0 < n) (hx : |x| ≤ 1) :
    |Real.cos x - (expIPartial n x).re| ≤
      |x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
  have hnorm := expIPartial_error n x hn hx
  have hre := Complex.abs_re_le_norm
    (Complex.exp ((x : ℂ) * I) - expIPartial n x)
  have heq :
      (Complex.exp ((x : ℂ) * I) - expIPartial n x).re =
        Real.cos x - (expIPartial n x).re := by
    simp
  rw [heq] at hre
  exact hre.trans hnorm

/-- Convert the complex Taylor norm enclosure into a two-sided real sine
interval.  For rational `x`, both endpoints except for the theorem-proved
remainder are exact rational arithmetic. -/
theorem sin_expIPartial_interval (n : ℕ) (x : ℝ) (hn : 0 < n) (hx : |x| ≤ 1) :
    (expIPartial n x).im -
        |x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) ≤ Real.sin x ∧
      Real.sin x ≤ (expIPartial n x).im +
        |x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
  have h := sin_expIPartial_error n x hn hx
  rw [abs_sub_le_iff] at h
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

/-- Convert the complex Taylor norm enclosure into a two-sided real cosine
interval. -/
theorem cos_expIPartial_interval (n : ℕ) (x : ℝ) (hn : 0 < n) (hx : |x| ≤ 1) :
    (expIPartial n x).re -
        |x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) ≤ Real.cos x ∧
      Real.cos x ≤ (expIPartial n x).re +
        |x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
  have h := cos_expIPartial_error n x hn hx
  rw [abs_sub_le_iff] at h
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

/-- Full sine primitive used by the integer checker: evaluate the Taylor
polynomial at a small center `q`, allow an arbitrary integral number of full
periods, and transport over a certified phase radius. -/
theorem sin_periodic_expIPartial_enclosure
    (n : ℕ) (q x r : ℝ) (k : ℤ)
    (hn : 0 < n) (hq : |q| ≤ 1) (_hr : 0 ≤ r)
    (hx : |x - (q + k * (2 * Real.pi))| ≤ r) :
    (expIPartial n q).im -
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) - r ≤ Real.sin x ∧
      Real.sin x ≤
        (expIPartial n q).im +
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) + r := by
  have hc := sin_expIPartial_interval n q hn hq
  have hlo :
      (expIPartial n q).im -
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) ≤
        Real.sin (q + k * (2 * Real.pi)) := by
    simpa using hc.1
  have hhi :
      Real.sin (q + k * (2 * Real.pi)) ≤
        (expIPartial n q).im +
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
    simpa using hc.2
  have hdist := Real.abs_sin_sub_sin_le x (q + k * (2 * Real.pi))
  rw [abs_sub_le_iff] at hdist
  constructor <;> linarith [hdist.1, hdist.2, hlo, hhi]

/-- Full cosine analogue of `sin_periodic_expIPartial_enclosure`. -/
theorem cos_periodic_expIPartial_enclosure
    (n : ℕ) (q x r : ℝ) (k : ℤ)
    (hn : 0 < n) (hq : |q| ≤ 1) (_hr : 0 ≤ r)
    (hx : |x - (q + k * (2 * Real.pi))| ≤ r) :
    (expIPartial n q).re -
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) - r ≤ Real.cos x ∧
      Real.cos x ≤
        (expIPartial n q).re +
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) + r := by
  have hc := cos_expIPartial_interval n q hn hq
  have hlo :
      (expIPartial n q).re -
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) ≤
        Real.cos (q + k * (2 * Real.pi)) := by
    simpa using hc.1
  have hhi :
      Real.cos (q + k * (2 * Real.pi)) ≤
        (expIPartial n q).re +
          |q| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
    simpa using hc.2
  have hdist := Real.abs_cos_sub_cos_le x (q + k * (2 * Real.pi))
  rw [abs_sub_le_iff] at hdist
  constructor <;> linarith [hdist.1, hdist.2, hlo, hhi]

/-- A certified sine value at a center transports across a cell with no
additional transcendental reasoning. -/
theorem sin_cell_enclosure (x c r lo hi : ℝ)
    (_hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hlo : lo ≤ Real.sin c) (hhi : Real.sin c ≤ hi) :
    lo - r ≤ Real.sin x ∧ Real.sin x ≤ hi + r := by
  have h := Real.abs_sin_sub_sin_le x c
  rw [abs_sub_le_iff] at h
  constructor <;> linarith

/-- The analogous cell transport for cosine. -/
theorem cos_cell_enclosure (x c r lo hi : ℝ)
    (_hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hlo : lo ≤ Real.cos c) (hhi : Real.cos c ≤ hi) :
    lo - r ≤ Real.cos x ∧ Real.cos x ≤ hi + r := by
  have h := Real.abs_cos_sub_cos_le x c
  rw [abs_sub_le_iff] at h
  constructor <;> linarith

/-- Scaling a real phase scales its cell radius by the absolute frequency. -/
theorem scaled_phase_radius (a x c r : ℝ) (hx : |x - c| ≤ r) :
    |a * x - a * c| ≤ |a| * r := by
  rw [← mul_sub, abs_mul]
  exact mul_le_mul_of_nonneg_left hx (abs_nonneg a)

/-- Sine cell transport for a scaled Fourier phase. -/
theorem sin_scaled_cell_enclosure (a x c r lo hi : ℝ)
    (hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hlo : lo ≤ Real.sin (a * c)) (hhi : Real.sin (a * c) ≤ hi) :
    lo - |a| * r ≤ Real.sin (a * x) ∧
      Real.sin (a * x) ≤ hi + |a| * r := by
  exact sin_cell_enclosure (a * x) (a * c) (|a| * r) lo hi
    (mul_nonneg (abs_nonneg a) hr) (scaled_phase_radius a x c r hx) hlo hhi

/-- Cosine cell transport for a scaled Fourier phase. -/
theorem cos_scaled_cell_enclosure (a x c r lo hi : ℝ)
    (hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hlo : lo ≤ Real.cos (a * c)) (hhi : Real.cos (a * c) ≤ hi) :
    lo - |a| * r ≤ Real.cos (a * x) ∧
      Real.cos (a * x) ≤ hi + |a| * r := by
  exact cos_cell_enclosure (a * x) (a * c) (|a| * r) lo hi
    (mul_nonneg (abs_nonneg a) hr) (scaled_phase_radius a x c r hx) hlo hhi

/-- Explicit real Taylor polynomial centered at `c`.  Unlike
`taylorWithinEval`, this expression contains only ordinary iterated derivatives,
so after the derivative formulas are proved its coefficients can be checked by
exact arithmetic. -/
def centeredTaylorEval (f : ℝ → ℝ) (n : ℕ) (c x : ℝ) : ℝ :=
  ∑ k ∈ Finset.range (n + 1),
    (((Nat.factorial k : ℕ) : ℝ)⁻¹ * (x - c) ^ k) * iteratedDeriv k f c

/-- On a unique-differentiability set, Mathlib's within-Taylor polynomial is
the explicit ordinary-derivative polynomial above. -/
theorem taylorWithinEval_eq_centeredTaylor
    (f : ℝ → ℝ) (n : ℕ) (s : Set ℝ) (c x : ℝ)
    (hs : UniqueDiffOn ℝ s) (hc : c ∈ s) (hf : ContDiffAt ℝ n f c) :
    taylorWithinEval f n s c x = centeredTaylorEval f n c x := by
  rw [taylor_within_apply]
  unfold centeredTaylorEval
  apply Finset.sum_congr rfl
  intro k hk
  have hkn : k ≤ n := Nat.le_of_lt_succ (Finset.mem_range.mp hk)
  have hkdiff : ContDiffAt ℝ k f c := hf.of_le (by exact_mod_cast hkn)
  rw [iteratedDerivWithin_eq_iteratedDeriv hs hkdiff hc]
  simp only [smul_eq_mul]

/-- The centered polynomial evaluates to the function at its center. -/
theorem centeredTaylorEval_self (f : ℝ → ℝ) (n : ℕ) (c : ℝ)
    (hf : ContDiffAt ℝ n f c) :
    centeredTaylorEval f n c c = f c := by
  rw [← taylorWithinEval_eq_centeredTaylor f n Set.univ c c
    uniqueDiffOn_univ (Set.mem_univ c) hf]
  exact taylorWithinEval_self f n Set.univ c

/-- Degree-seven Lagrange remainder bound in a form tailored to the committed
finite-interval certificate.  The only analytic input beyond smoothness is a
uniform bound on the eighth ordinary derivative. -/
theorem centeredTaylor7_remainder_of_ne
    (f : ℝ → ℝ) (c x M : ℝ) (hcx : c ≠ x)
    (hf : ContDiff ℝ 8 f)
    (hM : ∀ y : ℝ, |iteratedDeriv 8 f y| ≤ M) :
    |f x - centeredTaylorEval f 7 c x| ≤
      M * |x - c| ^ 8 / (40320 : ℝ) := by
  obtain ⟨y, hy, hrem⟩ :=
    taylor_mean_remainder_lagrange_iteratedDeriv
      (f := f) (x := x) (x₀ := c) (n := 7) hcx hf.contDiffOn
  have htaylor :
      taylorWithinEval f 7 (Set.uIcc c x) c x =
        centeredTaylorEval f 7 c x := by
    apply taylorWithinEval_eq_centeredTaylor
    · exact uniqueDiffOn_uIcc hcx
    · exact Set.left_mem_uIcc
    · exact hf.contDiffAt.of_le (by norm_num)
  rw [← htaylor, hrem, abs_div, abs_mul, abs_pow]
  have hMy := hM y
  have hM0 : 0 ≤ M := (abs_nonneg (iteratedDeriv 8 f y)).trans hMy
  have hpow : 0 ≤ |x - c| ^ 8 := pow_nonneg (abs_nonneg _) _
  norm_num
  exact div_le_div_of_nonneg_right
    (mul_le_mul hMy le_rfl hpow hM0) (by norm_num)

/-- Cell-radius version of the degree-seven remainder bound. -/
theorem centeredTaylor7_cell_remainder_of_ne
    (f : ℝ → ℝ) (c x r M : ℝ) (hcx : c ≠ x)
    (_hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hf : ContDiff ℝ 8 f)
    (hM : ∀ y : ℝ, |iteratedDeriv 8 f y| ≤ M) :
    |f x - centeredTaylorEval f 7 c x| ≤
      M * r ^ 8 / (40320 : ℝ) := by
  have hbase := centeredTaylor7_remainder_of_ne f c x M hcx hf hM
  have hM0 : 0 ≤ M := (abs_nonneg (iteratedDeriv 8 f c)).trans (hM c)
  have hp := pow_le_pow_left₀ (abs_nonneg (x - c)) hx 8
  exact hbase.trans (by
    apply div_le_div_of_nonneg_right
    · exact mul_le_mul_of_nonneg_left hp hM0
    · norm_num)

/-- A lower bound for the explicit degree-seven polynomial promotes to a
lower bound for the analytic function after subtracting the rigorous
eighth-derivative remainder budget. -/
theorem lower_of_centeredTaylor7
    (f : ℝ → ℝ) (c x r M L : ℝ)
    (hcx : c ≠ x) (hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hf : ContDiff ℝ 8 f)
    (hM : ∀ y : ℝ, |iteratedDeriv 8 f y| ≤ M)
    (hpoly : L ≤ centeredTaylorEval f 7 c x) :
    L - M * r ^ 8 / (40320 : ℝ) ≤ f x := by
  have hrem := centeredTaylor7_cell_remainder_of_ne f c x r M hcx hr hx hf hM
  rw [abs_sub_le_iff] at hrem
  linarith

end AEGIS.RHKreinFiniteIntervalKernelV1

#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.pi_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.log_two_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.expIPartial_error
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.sin_expIPartial_error
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.cos_expIPartial_error
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.sin_expIPartial_interval
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.cos_expIPartial_interval
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.sin_periodic_expIPartial_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.cos_periodic_expIPartial_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.sin_cell_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.cos_cell_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.sin_scaled_cell_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.cos_scaled_cell_enclosure
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.taylorWithinEval_eq_centeredTaylor
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.centeredTaylor7_remainder_of_ne
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.centeredTaylor7_cell_remainder_of_ne
#print axioms AEGIS.RHKreinFiniteIntervalKernelV1.lower_of_centeredTaylor7
~~~~~~

## RHEulerGammaSharpV1

Path: `source/RHEulerGammaSharpV1.lean`

Original source lines: 1–42

Full file SHA256: `ea8bb3b5376e7c4642384d45ff456ff52373d34bf42219d62ea0dc1b20ec63da`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
import RHKreinFifthCellCompositionV1

open Real
set_option autoImplicit false
set_option maxRecDepth 200000
set_option maxHeartbeats 100000000

namespace AEGIS.RHEulerGammaSharpV1

open AEGIS.RHKreinFiniteIntervalKernelV1

theorem harmonic_8192_upper :
    harmonic 8192 < (95881900461 / 10000000000 : ℚ) := by
  simp only [harmonic, Finset.sum_range_succ, Finset.sum_range_zero]
  norm_num

theorem log_8192 : Real.log 8192 = 13 * Real.log 2 := by
  rw [show (8192 : ℝ) = 2 ^ 13 by norm_num, Real.log_pow]
  norm_num

/-- A sharper rational upper enclosure for Euler's constant, obtained from
the monotone harmonic/log sandwich at `n = 8192`. -/
theorem gamma_lt_5773 :
    Real.eulerMascheroniConstant < (5773 / 10000 : ℝ) := by
  have h := Real.eulerMascheroniConstant_lt_eulerMascheroniSeq' 8192
  simp only [Real.eulerMascheroniSeq', show (8192 : ℕ) ≠ 0 by norm_num,
    if_false] at h
  have hH : (harmonic 8192 : ℝ) < 95881900461 / 10000000000 := by
    have h' := (Rat.cast_lt (K := ℝ)).mpr harmonic_8192_upper
    push_cast at h'
    exact h'
  have hl : Real.log (((8192 : ℕ) : ℝ)) = 13 * Real.log 2 := by
    norm_num
    exact log_8192
  have h2 := (log_two_enclosure).1
  rw [hl] at h
  norm_num at h2 ⊢
  linarith

end AEGIS.RHEulerGammaSharpV1

#print axioms AEGIS.RHEulerGammaSharpV1.gamma_lt_5773
~~~~~~

## RHKreinFifthCellCompositionV1

Path: `source/RHKreinFifthCellCompositionV1.lean`

Original source lines: 1–233

Full file SHA256: `ade949220b2590d7b8946fc6e25593c0997fce4d794ff5788f98a7812262df5e`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFourthCellCompositionV1

/-!
# Compose the existing zero jet into the fifth serialized cell

The symbol floor inherited from the third endpoint is a measured negative
control here.  Re-anchoring the already proved digamma certificate at
`75/2048` and extending the finite sum from 16 to 24 terms gives the stronger
uniform symbol floor `-1267/200`.  The zero jet and M8 bound are unchanged.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 4000000
noncomputable section

namespace AEGIS.RHKreinFifthCellCompositionV1

open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinThirdCellCompositionV1
open AEGIS.RHKreinFourthCellCompositionV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1

/-- The literal fifth entry of the unchanged committed payload. -/
def fifthCell : FiniteCellV1 :=
  ⟨75 / 2048, 675 / 16384, 219222047756099148⟩

private def fifthLeft : ℝ := 75 / 2048

private theorem fifthDigammaPartialLower :
    (-719517262047183 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm fifthLeft n := by
  have h0 : (-3536418012511957 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm fifthLeft n := by
    norm_num [fifthLeft, quarterTerm]
  have h1 : (-45749699273267 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm fifthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifthLeft, quarterTerm]
  have h2 : (-15418598450691 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm fifthLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [fifthLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm fifthLeft)
      (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm fifthLeft)
      (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2]

private theorem fifthDigammaLower (t : ℝ) (hst : fifthLeft ^ 2 ≤ t ^ 2) :
    (-421 / 100 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_quarter_certificate_lower_of_sq_le fifthLeft t 24 hst
  have hpartial := fifthDigammaPartialLower
  norm_num [fifthLeft] at hcert ⊢
  have hpartial' : (-719517262047183 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 24, quarterTerm (75 / 2048) n := by
    simpa [fifthLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem fifthLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by
    nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem fifthPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The stronger exact symbol floor needed by the fifth cell. -/
theorem fifthCell_symbol_lower (t : ℝ)
    (hlo : (fifthCell.lo : ℝ) ≤ t) (_hhi : t ≤ (fifthCell.hi : ℝ)) :
    (-1267 / 200 : ℝ) ≤ symbol t := by
  have ht0 : 0 ≤ t := by norm_num [fifthCell] at hlo; linarith
  have hst : fifthLeft ^ 2 ≤ t ^ 2 := by
    have hleft : fifthLeft ≤ t := by simpa [fifthCell, fifthLeft] using hlo
    have hleft0 : 0 ≤ fifthLeft := by norm_num [fifthLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft) (add_nonneg ht0 hleft0)]
  have hd := fifthDigammaLower t hst
  have hlp := fifthLogPiUpper
  have hamp := fifthPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

private def reuseRadius : ℝ := 675 / 16384
private def symbolFloor : ℝ := -1267 / 200
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue fifthCell : ℝ)
private def reuseError : ℝ :=
  (serializedM8Q : ℝ) * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 1000000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    fifthCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, firstJetError, serializedM8Q, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, fifthCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, fifthCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The fifth serialized lower bound follows from the existing zero jet, M8
bound, and the positive-left-endpoint symbol certificate above. -/
theorem fifthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 fifthCell := by
  apply cellAnalyticSound_of_correction_lower fifthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [fifthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [fifthCell, reuseRadius] using hhi
    have hcover : |t - firstCenter| ≤ reuseRadius := by
      rw [firstCenter, sub_zero, abs_of_nonneg ht0]
      exact htr
    exact correction_lower_of_jet_enclosures firstCenter t reuseRadius
      (jetPolynomial7 firstJet firstCenter t) firstJet firstJetError
      (by norm_num [reuseRadius]) hcover existing_zero_jet_enclosures le_rfl
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [fifthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [fifthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 1000000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := fifthCell_symbol_lower t hlo hhi
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue fifthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first five unchanged serialized cell results compose as a tuple. -/
theorem first_five_cells_sound :
    CellAnalyticSoundV1 firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 thirdCell ∧ CellAnalyticSoundV1 fourthCell ∧
      CellAnalyticSoundV1 fifthCell :=
  ⟨firstCell_sound_of_jet_enclosures,
    secondCell_sound_from_existing_zero_jet,
    thirdCell_sound_from_existing_zero_jet,
    fourthCell_sound_from_existing_zero_jet,
    fifthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinFifthCellCompositionV1

#print axioms AEGIS.RHKreinFifthCellCompositionV1.fifthCell_symbol_lower
#print axioms AEGIS.RHKreinFifthCellCompositionV1.fifthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinFifthCellCompositionV1.first_five_cells_sound
~~~~~~

## RHKreinFourthCellCompositionV1

Path: `source/RHKreinFourthCellCompositionV1.lean`

Original source lines: 1–137

Full file SHA256: `6f7d329c791d0ab308e6fb0155af414912cbbf6754d2e59399359a0850cc09be`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinThirdCellCompositionV1

/-!
# Compose the existing zero jet into the fourth serialized cell

The positive-endpoint digamma certificate proved for the third cell exposes a
symbol floor valid at every later nonnegative frequency.  This module reuses
that theorem, the eight zero-jet enclosures, and the original M8 bound.  Exact
rational arithmetic leaves a small but strictly positive combined budget.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 3000000
noncomputable section

namespace AEGIS.RHKreinFourthCellCompositionV1

open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinThirdCellCompositionV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1

/-- The literal fourth entry of the unchanged committed payload. -/
def fourthCell : FiniteCellV1 :=
  ⟨525 / 16384, 75 / 2048, 253868912037845735⟩

private def reuseRadius : ℝ := 75 / 2048
private def symbolFloor : ℝ := -1269 / 200
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue fourthCell : ℝ)
private def reuseError : ℝ :=
  (serializedM8Q : ℝ) * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 100000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    fourthCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, firstJetError, serializedM8Q, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, fourthCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, fourthCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The unchanged fourth serialized lower bound follows entirely by composing
the existing zero jet, M8 bound, and third-endpoint symbol certificate. -/
theorem fourthCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 fourthCell := by
  apply cellAnalyticSound_of_correction_lower fourthCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [fourthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [fourthCell, reuseRadius] using hhi
    have hcover : |t - firstCenter| ≤ reuseRadius := by
      rw [firstCenter, sub_zero, abs_of_nonneg ht0]
      exact htr
    exact correction_lower_of_jet_enclosures firstCenter t reuseRadius
      (jetPolynomial7 firstJet firstCenter t) firstJet firstJetError
      (by norm_num [reuseRadius]) hcover existing_zero_jet_enclosures le_rfl
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [fourthCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [fourthCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 100000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := by
      apply symbol_lower_of_thirdLeft_le
      norm_num [fourthCell] at hlo ⊢
      linarith
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue fourthCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first four unchanged serialized cell results compose as a tuple. -/
theorem first_four_cells_sound :
    CellAnalyticSoundV1 firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 thirdCell ∧ CellAnalyticSoundV1 fourthCell :=
  ⟨firstCell_sound_of_jet_enclosures,
    secondCell_sound_from_existing_zero_jet,
    thirdCell_sound_from_existing_zero_jet,
    fourthCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinFourthCellCompositionV1

#print axioms AEGIS.RHKreinFourthCellCompositionV1.fourthCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinFourthCellCompositionV1.first_four_cells_sound
~~~~~~

## RHKreinThirdCellCompositionV1

Path: `source/RHKreinThirdCellCompositionV1.lean`

Original source lines: 1–234

Full file SHA256: `507e0225ffa4b9107b6fea73e38c0f9f41f1e304ddf3add908ebe35385eaed84`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinSecondCellCompositionV1

/-!
# Compose the existing zero jet into the third serialized cell

The global zero-frequency symbol floor is just too weak on this cell.  The
proved digamma monotonicity theorem is instead anchored at the cell's positive
left endpoint.  A 16-term exact rational certificate then yields the uniform
symbol floor `-1269/200`.  Together with the existing eight zero-jet
enclosures and original-definition M8 bound, the combined endpoint budget is
strictly positive.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 4000000
noncomputable section

namespace AEGIS.RHKreinThirdCellCompositionV1

open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinSecondCellCompositionV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1

/-- The literal third entry of the unchanged committed payload. -/
def thirdCell : FiniteCellV1 :=
  ⟨225 / 8192, 525 / 16384, 289287866131689861⟩

private def thirdLeft : ℝ := 225 / 8192

private theorem thirdDigammaPartialLower :
    (-3591574317375397 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 16, quarterTerm thirdLeft n := by
  have h0 : (-3545823697412947 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm thirdLeft n := by
    norm_num [thirdLeft, quarterTerm]
  have h1 : (-915012399249 / 20000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm thirdLeft n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [thirdLeft, quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm thirdLeft)
    (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1]

private theorem thirdDigammaLower (t : ℝ) (hst : thirdLeft ^ 2 ≤ t ^ 2) :
    (-211 / 50 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_quarter_certificate_lower_of_sq_le thirdLeft t 16 hst
  have hpartial := thirdDigammaPartialLower
  norm_num [thirdLeft] at hcert ⊢
  have hpartial' : (-3591574317375397 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 16, quarterTerm (225 / 8192) n := by
    simpa [thirdLeft] using hpartial
  linarith only [hcert, hpartial']

private theorem thirdLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by
    nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem thirdPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The third-cell endpoint certificate actually supplies the same symbol
floor at every later nonnegative frequency.  Exposing that stronger type lets
later cells reuse the proof without regenerating the digamma certificate. -/
theorem symbol_lower_of_thirdLeft_le (t : ℝ)
    (hlo : (225 / 8192 : ℝ) ≤ t) :
    (-1269 / 200 : ℝ) ≤ symbol t := by
  have ht0 : 0 ≤ t := by linarith
  have hst : thirdLeft ^ 2 ≤ t ^ 2 := by
    have hleft : thirdLeft ≤ t := by simpa [thirdLeft] using hlo
    have hleft0 : 0 ≤ thirdLeft := by norm_num [thirdLeft]
    nlinarith [mul_nonneg (sub_nonneg.mpr hleft) (add_nonneg ht0 hleft0)]
  have hd := thirdDigammaLower t hst
  have hlp := thirdLogPiUpper
  have hamp := thirdPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

/-- A uniform symbol floor on the third cell, produced by exact kernel
arithmetic and the positive-left-endpoint digamma certificate. -/
theorem thirdCell_symbol_lower (t : ℝ)
    (hlo : (thirdCell.lo : ℝ) ≤ t) (_hhi : t ≤ (thirdCell.hi : ℝ)) :
    (-1269 / 200 : ℝ) ≤ symbol t :=
  symbol_lower_of_thirdLeft_le t (by simpa [thirdCell] using hlo)

private def reuseRadius : ℝ := 525 / 16384
private def symbolFloor : ℝ := -1269 / 200
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue thirdCell : ℝ)
private def reuseError : ℝ :=
  (serializedM8Q : ℝ) * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 4000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    thirdCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, firstJetError, serializedM8Q, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, thirdCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, thirdCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The unchanged third serialized lower bound follows from the already proved
zero jet, M8 bound, and the positive-endpoint symbol certificate above. -/
theorem thirdCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 thirdCell := by
  apply cellAnalyticSound_of_correction_lower thirdCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [thirdCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [thirdCell, reuseRadius] using hhi
    have hcover : |t - firstCenter| ≤ reuseRadius := by
      rw [firstCenter, sub_zero, abs_of_nonneg ht0]
      exact htr
    exact correction_lower_of_jet_enclosures firstCenter t reuseRadius
      (jetPolynomial7 firstJet firstCenter t) firstJet firstJetError
      (by norm_num [reuseRadius]) hcover existing_zero_jet_enclosures le_rfl
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [thirdCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [thirdCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 4000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := thirdCell_symbol_lower t hlo hhi
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue thirdCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first three unchanged serialized cell results compose as a triple. -/
theorem first_three_cells_sound :
    CellAnalyticSoundV1 firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 thirdCell :=
  ⟨firstCell_sound_of_jet_enclosures,
    secondCell_sound_from_existing_zero_jet,
    thirdCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinThirdCellCompositionV1

#print axioms AEGIS.RHKreinThirdCellCompositionV1.thirdCell_symbol_lower
#print axioms AEGIS.RHKreinThirdCellCompositionV1.symbol_lower_of_thirdLeft_le
#print axioms AEGIS.RHKreinThirdCellCompositionV1.thirdCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinThirdCellCompositionV1.first_three_cells_sound
~~~~~~

## RHKreinSecondCellCompositionV1

Path: `source/RHKreinSecondCellCompositionV1.lean`

Original source lines: 1–148

Full file SHA256: `5807ff9459a4d1a510f4d713acfcaec7260462fbdd14dff9013286bf25b410ab`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFirstCellV1
import RHKreinSecondCellReductionV1

/-!
# Compose the existing zero jet into the second serialized cell

Uses the eight normalized zero-jet enclosures and global symbol lower bound
from `RHKreinFirstCellV1`, the original-definition M8 Taylor bound, and the
unchanged `secondCell` definition. The combined weighted polynomial has
nonpositive coefficients of t^2, t^4 and t^6. Its lower bound is its value
at 225/8192; exact rational arithmetic closes that budget.
-/

open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 2000000
noncomputable section

namespace AEGIS.RHKreinSecondCellCompositionV1

open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinSecondCellReductionV1
open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1

/-- Package the eight already proved zero-jet results without new enclosures. -/
theorem existing_zero_jet_enclosures :
    ∀ k ∈ Finset.range 8,
      |exactJetCoefficient firstCenter k - firstJet k| ≤ firstJetError k := by
  intro k hk
  have hklt : k < 8 := Finset.mem_range.mp hk
  interval_cases k
  · rw [firstJet_zero_exact]
    norm_num [firstJetError]
  · rw [firstJet_one_exact]
    norm_num [firstJetError]
  · exact firstJet_two_enclosure
  · rw [firstJet_three_exact]
    norm_num [firstJetError]
  · exact firstJet_four_enclosure
  · rw [firstJet_five_exact]
    norm_num [firstJetError]
  · exact firstJet_six_enclosure
  · rw [firstJet_seven_exact]
    norm_num [firstJetError]

private def reuseRadius : ℝ := 225 / 8192
private def symbolFloor : ℝ := -3177232903 / 500000000
private def weightedCoefficient : ℝ :=
  symbolFloor - 1 / 16 - (lowerValue secondCell : ℝ)
private def reuseError : ℝ :=
  (serializedM8Q : ℝ) * reuseRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * reuseRadius ^ k
private def weightedFloor (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * weightedCoefficient +
    jetPolynomial7 firstJet firstCenter t - reuseError

private theorem weightedFloor_expansion (t : ℝ) :
    weightedFloor t =
      (firstJet 0 + weightedCoefficient / 16 - reuseError) +
      (firstJet 2 + weightedCoefficient / 2) * t ^ 2 +
      (firstJet 4 + weightedCoefficient) * t ^ 4 + firstJet 6 * t ^ 6 := by
  norm_num [weightedFloor, jetPolynomial7, firstCenter,
    Finset.sum_range_succ, firstJet]
  ring

private theorem endpoint_budget : (1 / 2000 : ℝ) < weightedFloor reuseRadius := by
  norm_num [weightedFloor, reuseRadius, weightedCoefficient, symbolFloor,
    secondCell, lowerValue, jetPolynomial7, firstJet, firstCenter,
    reuseError, firstJetError, serializedM8Q, Finset.sum_range_succ]

private theorem weightedFloor_lower (t : ℝ) (ht0 : 0 ≤ t)
    (htr : t ≤ reuseRadius) : weightedFloor reuseRadius ≤ weightedFloor t := by
  have h2 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 2)
    (show firstJet 2 + weightedCoefficient / 2 ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, secondCell, lowerValue])
  have h4 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 4)
    (show firstJet 4 + weightedCoefficient ≤ 0 by
      norm_num [firstJet, weightedCoefficient, symbolFloor, secondCell, lowerValue])
  have h6 := mul_le_mul_of_nonpos_left (pow_le_pow_left₀ ht0 htr 6)
    (show firstJet 6 ≤ 0 by norm_num [firstJet])
  simp only [weightedFloor_expansion]
  linarith only [h2, h4, h6]

/-- The unchanged second serialized lower bound follows from existing zero-jet
and global symbol theorems. No second-center analytic hypothesis is required. -/
theorem secondCell_sound_from_existing_zero_jet : CellAnalyticSoundV1 secondCell := by
  apply cellAnalyticSound_of_correction_lower secondCell
    (fun t => jetPolynomial7 firstJet firstCenter t - reuseError)
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [secondCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [secondCell, reuseRadius] using hhi
    have hcover : |t - firstCenter| ≤ reuseRadius := by
      rw [firstCenter, sub_zero, abs_of_nonneg ht0]
      exact htr
    exact correction_lower_of_jet_enclosures firstCenter t reuseRadius
      (jetPolynomial7 firstJet firstCenter t) firstJet firstJetError
      (by norm_num [reuseRadius]) hcover existing_zero_jet_enclosures le_rfl
  · intro t hlo hhi
    have ht0 : 0 ≤ t := by norm_num [secondCell] at hlo; linarith
    have htr : t ≤ reuseRadius := by simpa [secondCell, reuseRadius] using hhi
    have hgap : 0 ≤ weightedFloor t :=
      ((by norm_num : (0 : ℝ) ≤ 1 / 2000).trans endpoint_budget.le).trans
        (weightedFloor_lower t ht0 htr)
    have hs : symbolFloor ≤ symbol t := firstCell_symbol_lower t
    have hsmul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) (sq_nonneg (t ^ 2 + 1 / 4))
    calc
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue secondCell : ℝ) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbolFloor - 1 / 16) +
            (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        dsimp only [weightedFloor, weightedCoefficient] at hgap
        nlinarith only [hgap]
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (jetPolynomial7 firstJet firstCenter t - reuseError) := by
        simpa only [add_comm] using
          add_le_add_right hsmul (jetPolynomial7 firstJet firstCenter t - reuseError)

/-- The first and second unchanged serialized cell results compose as a pair. -/
theorem first_two_cells_sound :
    CellAnalyticSoundV1 firstCell ∧ CellAnalyticSoundV1 secondCell :=
  ⟨firstCell_sound_of_jet_enclosures, secondCell_sound_from_existing_zero_jet⟩

end AEGIS.RHKreinSecondCellCompositionV1

#print axioms AEGIS.RHKreinSecondCellCompositionV1.existing_zero_jet_enclosures
#print axioms AEGIS.RHKreinSecondCellCompositionV1.secondCell_sound_from_existing_zero_jet
#print axioms AEGIS.RHKreinSecondCellCompositionV1.first_two_cells_sound
~~~~~~

