# AEGIS source modules 6

Exact pinned or operator archive source. Compilation was not performed during transfer.

## Hadamard.OrderOne.ZeroCountingBounds

Path: `source/Hadamard/OrderOne/ZeroCountingBounds.lean`

Original source lines: 1–787

Full file SHA256: `1ea6d0e69cd1c9fa065cca9e254ac5989858bd2fb8ca75447814f701e0246eb8`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/OrderOne/ZeroCountingBounds.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Data.Set.Card
import Mathlib.Analysis.Analytic.Order
import Hadamard.ZeroCounting
import Hadamard.ZeroSet

/-!
Zero counting bounds for a `ZeroSet` enumeration, in the order‑`≤ 1` regime.

This file bridges the Jensen/divisor-based counting lemma in
`LZC/HadamardFactorization/ZeroCounting.lean` to the `ZeroSet`-based canonical
product development.
-/

open scoped BigOperators

namespace Hadamard

open Complex Real Filter Metric MeromorphicOn

namespace OrderOne

/-! ### Relating `ZeroSet` enumerations to divisor support -/

lemma mem_divisor_support_of_simple_zero
    {f : ℂ → ℂ} (hf : Differentiable ℂ f)
    {R : ℝ} (_hR : 0 < R) {u : ℂ}
    (hu_mem : u ∈ closedBall (0 : ℂ) |R|)
    (hu0 : f u = 0) (hu' : deriv f u ≠ 0) :
    u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|)).support := by
  -- Compute the divisor value at `u` via the (analytic) meromorphic order.
  have hmer : MeromorphicOn f (closedBall (0 : ℂ) |R|) := fun z _ =>
    (hf.analyticAt z).meromorphicAt
  have han : AnalyticAt ℂ f u := hf.analyticAt u
  have horder : analyticOrderAt f u = 1 := by
    -- `analyticOrderAt (f· - f u) u = 1` and `f u = 0`.
    simpa [hu0] using han.analyticOrderAt_sub_eq_one_of_deriv_ne_zero hu'
  have hmerOrder : meromorphicOrderAt f u = (1 : WithTop ℤ) := by
    -- `meromorphicOrderAt = ENat.map Nat.cast (analyticOrderAt ...)`.
    simpa [horder] using han.meromorphicOrderAt_eq
  have hdiv :
      MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u = (meromorphicOrderAt f u).untop₀ :=
    MeromorphicOn.divisor_apply hmer hu_mem
  have : MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u = (1 : ℤ) := by
    simp [hdiv, hmerOrder, WithTop.untop₀]
  have hdiv_ne : MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u ≠ 0 := by
    simp [this]
  have : u ∈ Function.support (fun x : ℂ => MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) x) :=
    Function.mem_support.2 hdiv_ne
  simpa [Function.locallyFinsuppWithin.support] using this

lemma mem_divisor_support_of_zero
    {f : ℂ → ℂ} (hf : Differentiable ℂ f)
    {R : ℝ} {u : ℂ}
    (hu_mem : u ∈ closedBall (0 : ℂ) |R|)
    (hf0 : f 0 ≠ 0) (hu0 : f u = 0) :
    u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|)).support := by
  -- Compute the divisor value at `u` via the meromorphic order.
  have hmer : MeromorphicOn f (closedBall (0 : ℂ) |R|) := fun z _ =>
    (hf.analyticAt z).meromorphicAt
  have han : AnalyticAt ℂ f u := hf.analyticAt u
  -- Use preconnectedness of the closed ball to rule out infinite order.
  have hf_an : AnalyticOnNhd ℂ f (closedBall (0 : ℂ) |R|) := by
    intro z _
    exact hf.analyticAt z
  have h0_mem : (0 : ℂ) ∈ closedBall (0 : ℂ) |R| := by
    simp [Metric.mem_closedBall, abs_nonneg R]
  have horder0 : analyticOrderAt f 0 = 0 :=
    (hf.analyticAt 0).analyticOrderAt_eq_zero.2 hf0
  have horder0_ne_top : analyticOrderAt f 0 ≠ ⊤ := by
    simp [horder0]
  have hpre : IsPreconnected (closedBall (0 : ℂ) |R|) :=
    (convex_closedBall (0 : ℂ) |R|).isPreconnected
  have horder_ne_top : analyticOrderAt f u ≠ ⊤ :=
    hf_an.analyticOrderAt_ne_top_of_isPreconnected hpre h0_mem hu_mem horder0_ne_top
  have hdiv :
      MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u = (meromorphicOrderAt f u).untop₀ :=
    MeromorphicOn.divisor_apply hmer hu_mem
  have hmerOrder : meromorphicOrderAt f u = (analyticOrderAt f u).map (↑) :=
    han.meromorphicOrderAt_eq
  have horder_ne0 : analyticOrderAt f u ≠ 0 := (han.analyticOrderAt_ne_zero).2 hu0
  -- Show the divisor value is nonzero.
  -- Show the divisor value is nonzero.
  have hdiv_ne : MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u ≠ 0 := by
    cases hAU : analyticOrderAt f u with
    | top =>
        cases (horder_ne_top (by simp [hAU]))
    | coe n =>
        have hn_ne0 : n ≠ 0 := by
          intro hn0
          apply horder_ne0
          simp [hAU, hn0]
        have : MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u = (n : ℤ) := by
          simp [hdiv, hmerOrder, hAU]
        simp [this, hn_ne0]
  have : u ∈ Function.support (fun x : ℂ => MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) x) :=
    Function.mem_support.2 hdiv_ne
  simpa [Function.locallyFinsuppWithin.support] using this

/-! ### Zero counting for the `ZeroSet` index type -/

theorem ncard_zeros_le_of_order_le_one
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_simple : ∀ ρ : Z.Zero, deriv f (Z.z ρ) ≠ 0) :
    ∀ ε : ℝ, 0 < ε →
      ∃ R₀ : ℝ, ∀ r : ℝ, R₀ ≤ r →
        (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero).ncard : ℝ) ≤
          ((2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖) / Real.log 2 := by
  intro ε hε
  -- `f 0 ≠ 0` since all zeros are nonzero and `Z` enumerates all zeros.
  have hf0 : f 0 ≠ 0 := by
    intro hf0
    rcases (h_zeros_only 0).1 hf0 with ⟨ρ, hρ⟩
    exact (h_z_ne_zero ρ) (by simp [hρ])
  -- Growth bound on `maxModulus f R` from `order f ≤ 1`.
  obtain ⟨R₁, hmax⟩ :=
    Hadamard.ZeroCounting.maxModulus_le_exp_rpow_of_order_le_one f hf_finite hf_order_le ε hε
  refine ⟨max R₁ 1, ?_⟩
  intro r hr
  have hr_ge_R1 : R₁ ≤ 2 * r := by
    have hR1_le : R₁ ≤ r := le_trans (le_max_left _ _) hr
    have hr_pos : 0 < r :=
      lt_of_lt_of_le
        (by norm_num : (0 : ℝ) < 1)
        (le_trans (le_max_right R₁ 1) hr)
    calc
      R₁ ≤ r := hR1_le
      _ ≤ 2 * r := by nlinarith
  have hRpos : 0 < 2 * r := by
    have : (0 : ℝ) < r := lt_of_lt_of_le (by norm_num) (le_trans (le_max_right R₁ 1) hr)
    linarith
  -- Apply Jensen zero-counting at radius `R = 2r`.
  have hdiv_bound :
      (({u : ℂ |
            u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|)).support ∧
              ‖u‖ ≤ (2 * r) / 2} : Set ℂ).ncard : ℝ)
        ≤ (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
    -- Use the unconditional Jensen bound.
    simpa using
      Hadamard.ZeroCounting.card_zeros_le_of_max_one_maxModulus (f := f) (R := (2 * r))
        (by exact hRpos) hf_entire hf0
  -- Relate the divisor-support counting set to `{ρ | ‖Z.z ρ‖ ≤ r}`
  -- via `h_zeros_only` and injectivity.
  have himage :
      (Z.z '' ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero)) =
        {u : ℂ | f u = 0 ∧ ‖u‖ ≤ r} := by
    ext u
    constructor
    · rintro ⟨ρ, hρ, rfl⟩
      refine ⟨Z.isZero ρ, ?_⟩
      simpa [Set.mem_ofPred_eq] using hρ
    · rintro ⟨hu0, hur⟩
      rcases (h_zeros_only u).1 hu0 with ⟨ρ, rfl⟩
      refine ⟨ρ, ?_, rfl⟩
      simpa [Set.mem_ofPred_eq] using hur
  -- Every zero `u` with `‖u‖ ≤ r` lies in the divisor-support counting set for radius `2r`.
  have hzeros_subset :
      {u : ℂ | f u = 0 ∧ ‖u‖ ≤ r}
        ⊆ {u : ℂ |
            u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|)).support ∧
              ‖u‖ ≤ (2 * r) / 2} := by
    intro u hu
    have hu0' : f u = 0 := hu.1
    have hur : ‖u‖ ≤ r := hu.2
    have hu_mem : u ∈ closedBall (0 : ℂ) |(2 * r)| := by
      have : ‖u‖ ≤ 2 * r := le_trans hur (by linarith)
      -- `‖u‖ ≤ 2r` implies membership in the closed ball.
      simpa [Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos] using this
    -- Use `h_simple` via the `ZeroSet` witness.
    rcases (h_zeros_only u).1 hu0' with ⟨ρ, rfl⟩
    refine ⟨?_, ?_⟩
    · exact mem_divisor_support_of_simple_zero hf_entire hRpos hu_mem (Z.isZero ρ) (h_simple ρ)
    · simpa using hur
  have hfinite_div :
      ({u : ℂ |
            u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|)).support ∧
              ‖u‖ ≤ (2 * r) / 2} : Set ℂ).Finite := by
    -- Support of the divisor on a compact set is finite.
    have hD :
        ((MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|)).support : Set ℂ).Finite :=
      (MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|)).finiteSupport
        (isCompact_closedBall (0 : ℂ) |(2 * r)|)
    exact hD.subset (by intro u hu; exact hu.1)
  have hcard_zeros_le :
      (({u : ℂ | f u = 0 ∧ ‖u‖ ≤ r} : Set ℂ).ncard : ℝ)
        ≤ (({u : ℂ |
              u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|)).support ∧
                ‖u‖ ≤ (2 * r) / 2} : Set ℂ).ncard : ℝ) := by
    exact_mod_cast Set.ncard_le_ncard hzeros_subset hfinite_div
  have hcardZ :
      (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero).ncard : ℝ)
        = (({u : ℂ | f u = 0 ∧ ‖u‖ ≤ r} : Set ℂ).ncard : ℝ) := by
    -- `Z.z` is injective and identifies the two sets.
    have h :=
      Set.ncard_image_of_injective ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero) h_inj
    -- `h : (Z.z '' S).ncard = S.ncard`.
    -- Rewrite using `himage` and cast to `ℝ`.
    have : (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero).ncard : ℝ)
        = ((Z.z '' ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero)).ncard : ℝ) := by
      exact_mod_cast h.symm
    simpa [himage] using this
  -- Combine.
  have hbound1 :
      (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero).ncard : ℝ)
        ≤ (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
    -- Use the chain: Z-card = zero-card ≤ divisor-card ≤ Jensen bound.
    have := le_trans (le_trans (le_of_eq hcardZ) hcard_zeros_le) hdiv_bound
    exact this
  -- Replace `log (max 1 (maxModulus f (2r)))` using the max-modulus growth bound.
  have hM_le : maxModulus f (2 * r) ≤ Real.exp ((2 * r) ^ ((1 : ℝ) + ε)) :=
    hmax (2 * r) hr_ge_R1
  have hexp_ge1 : (1 : ℝ) ≤ Real.exp ((2 * r) ^ ((1 : ℝ) + ε)) := by
    have : 0 ≤ (2 * r) ^ ((1 : ℝ) + ε) := Real.rpow_nonneg (le_of_lt hRpos) _
    simpa using Real.one_le_exp this
  have hmax1_le : max 1 (maxModulus f (2 * r)) ≤ Real.exp ((2 * r) ^ ((1 : ℝ) + ε)) :=
    max_le hexp_ge1 hM_le
  have hlog_le : Real.log (max 1 (maxModulus f (2 * r))) ≤ (2 * r) ^ ((1 : ℝ) + ε) := by
    have hpos : 0 < max 1 (maxModulus f (2 * r)) := by
      have : (0 : ℝ) < (1 : ℝ) := by norm_num
      exact lt_of_lt_of_le this (le_max_left _ _)
    have := Real.log_le_log hpos hmax1_le
    simpa [Real.log_exp] using this
  have hnum :
      Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖
        ≤ (2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖ :=
    sub_le_sub_right hlog_le _
  have hden : 0 ≤ Real.log 2 := by
    exact le_of_lt (by simpa using Real.log_pos (by norm_num : (1 : ℝ) < 2))
  have hfrac :
      (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2
        ≤ ((2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖) / Real.log 2 :=
    div_le_div_of_nonneg_right hnum hden
  exact le_trans hbound1 hfrac

/-- Multiplicity-weighted zero counting for a `ZeroSet` enumeration, in the order-`≤ 1` regime.

This bounds `∑ ord_ρ(f)` over zeros `ρ` with `‖Z.z ρ‖ ≤ r`, where `ord_ρ(f)` is the vanishing order
(`analyticOrderNatAt f (Z.z ρ)`). -/
theorem sum_multiplicity_zeros_le_of_order_le_one
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0) :
    ∀ ε : ℝ, 0 < ε →
      ∃ R₀ : ℝ, ∀ r : ℝ, R₀ ≤ r →
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ≤
          ((2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖) / Real.log 2 := by
  classical
  intro ε hε
  -- `f 0 ≠ 0` since all zeros are nonzero and `Z` enumerates all zeros.
  have hf0 : f 0 ≠ 0 := by
    intro hf0
    rcases (h_zeros_only 0).1 hf0 with ⟨ρ, hρ⟩
    exact (h_z_ne_zero ρ) (by simp [hρ])
  -- Growth bound on `maxModulus f R` from `order f ≤ 1`.
  obtain ⟨R₁, hmax⟩ :=
    Hadamard.ZeroCounting.maxModulus_le_exp_rpow_of_order_le_one f hf_finite hf_order_le ε hε
  refine ⟨max R₁ 1, ?_⟩
  intro r hr
  have hr_ge_R1 : R₁ ≤ 2 * r := by
    have hR1_le : R₁ ≤ r := le_trans (le_max_left _ _) hr
    have hr_pos : 0 < r :=
      lt_of_lt_of_le (by norm_num : (0 : ℝ) < 1) (le_trans (le_max_right R₁ 1) hr)
    calc
      R₁ ≤ r := hR1_le
      _ ≤ 2 * r := by nlinarith
  have hRpos : 0 < 2 * r := by
    have : (0 : ℝ) < r := lt_of_lt_of_le (by norm_num) (le_trans (le_max_right R₁ 1) hr)
    linarith
  -- Jensen bound on the sum of divisor weights in `‖u‖ ≤ r` for the divisor on `‖u‖ ≤ 2r`.
  have hdiv_bound :
      (∑ᶠ u : ℂ,
          if ‖u‖ ≤ r then
            ((MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|) u : ℤ) : ℝ)
          else 0)
        ≤ (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
    -- Use the unconditional Jensen bound with multiplicities.
    simpa using
      Hadamard.ZeroCounting.sum_zeros_multiplicity_le_of_max_one_maxModulus (f := f)
        (R := (2 * r)) (by exact hRpos) hf_entire hf0
  -- Compare the multiplicity sum over `Z.Zero` to the divisor-weight sum over `ℂ`.
  have hbound1 :
      (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
        ≤ (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
    -- Work with the divisor on the ball of radius `2r`.
    let U : Set ℂ := closedBall (0 : ℂ) |(2 * r)|
    let D : Function.locallyFinsuppWithin U ℤ := MeromorphicOn.divisor f U
    have hmer : MeromorphicOn f U := fun z _ => (hf_entire.analyticAt z).meromorphicAt
    have hD_fin : (D.support : Set ℂ).Finite :=
      D.finiteSupport (isCompact_closedBall (0 : ℂ) |(2 * r)|)
    have hD_nonneg : 0 ≤ D := by
      have hf_an : AnalyticOnNhd ℂ f U := by
        intro z _
        exact hf_entire.analyticAt z
      exact hf_an.divisor_nonneg
    let Sρ : Set Z.Zero := {ρ : Z.Zero | ‖Z.z ρ‖ ≤ r}
    -- Image of `Sρ` lies in the divisor support.
    have hImage : Z.z '' Sρ ⊆ D.support := by
      intro u hu
      rcases hu with ⟨ρ, hρ, rfl⟩
      have hu_mem : Z.z ρ ∈ U := by
        have : ‖Z.z ρ‖ ≤ 2 * r :=
          le_trans (by simpa [Sρ, Set.mem_ofPred_eq] using hρ) (by linarith)
        simpa [U, Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos] using this
      -- A zero contributes positively to the divisor support.
      have : Z.z ρ ∈ (MeromorphicOn.divisor f U).support :=
        mem_divisor_support_of_zero
          (f := f) hf_entire (R := (2 * r)) (u := Z.z ρ) hu_mem hf0 (Z.isZero ρ)
      simpa [D, U] using this
    have hImageFinite : (Z.z '' Sρ).Finite := hD_fin.subset hImage
    have hSρ_fin : Sρ.Finite := Set.Finite.of_finite_image hImageFinite (h_inj.injOn)
    let sZ : Finset Z.Zero := hSρ_fin.toFinset
    let sU : Finset ℂ := sZ.image Z.z
    -- Rewrite the LHS finsum as a finite sum over `sZ`.
    have hLHS :
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
          = ∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ) := by
      have hsupp :
          Function.support (fun ρ : Z.Zero =>
              if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ⊆ sZ := by
        intro ρ hρ
        have hne :
            (if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ≠ 0 :=
          Function.mem_support.1 hρ
        have hle : ‖Z.z ρ‖ ≤ r := by
          by_contra hle
          apply hne
          simp [hle]
        have : ρ ∈ Sρ := by
          simpa [Sρ, Set.mem_ofPred_eq] using hle
        exact hSρ_fin.mem_toFinset.2 this
      have :=
        (finsum_eq_sum_of_support_subset
          (f := fun ρ : Z.Zero =>
            if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
          (s := sZ) hsupp)
      have hsum_if :
          (∑ ρ ∈ sZ, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) =
            ∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ) := by
        refine Finset.sum_congr rfl ?_
        intro ρ hρ
        have hρS : ρ ∈ Sρ := hSρ_fin.mem_toFinset.1 hρ
        have hle : ‖Z.z ρ‖ ≤ r := by simpa [Sρ, Set.mem_ofPred_eq] using hρS
        simp [hle]
      simpa [hsum_if] using this
    -- Move the sum from `Z.Zero` to its image in `ℂ`.
    have hsum_image :
        (∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ))
          = ∑ u ∈ sU, (analyticOrderNatAt f u : ℝ) := by
      -- `sU` is the image of `sZ` under the injective map `Z.z`.
      have hinjOn : Set.InjOn Z.z (sZ : Set Z.Zero) := h_inj.injOn
      -- `Finset.sum_image` rewrites the sum over the image.
      simpa [sU] using
        (Finset.sum_image (f := fun u : ℂ => (analyticOrderNatAt f u : ℝ))
          (s := sZ) (g := Z.z) hinjOn).symm
    -- Replace `analyticOrderNatAt` by the divisor values on `sU`.
    have hsum_divisor :
        (∑ u ∈ sU, (analyticOrderNatAt f u : ℝ))
          = ∑ u ∈ sU, (D u : ℝ) := by
      refine Finset.sum_congr rfl ?_
      intro u hu
      -- `u` lies in the closed ball `U`.
      have huU : u ∈ U := by
        rcases Finset.mem_image.1 hu with ⟨ρ, hρ, rfl⟩
        have hρS : ρ ∈ Sρ := hSρ_fin.mem_toFinset.1 hρ
        have hle : ‖Z.z ρ‖ ≤ r := by simpa [Sρ, Set.mem_ofPred_eq] using hρS
        have : ‖Z.z ρ‖ ≤ 2 * r := le_trans hle (by linarith)
        simpa [U, Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos] using this
      -- Analytic order is finite throughout `U` since `f 0 ≠ 0`.
      have hf_anU : AnalyticOnNhd ℂ f U := by
        intro z _
        exact hf_entire.analyticAt z
      have h0U : (0 : ℂ) ∈ U := by
        simp [U, Metric.mem_closedBall]
      have hpreU : IsPreconnected U := (convex_closedBall (0 : ℂ) |(2 * r)|).isPreconnected
      have horder0 : analyticOrderAt f 0 = 0 :=
        (hf_entire.analyticAt 0).analyticOrderAt_eq_zero.2 hf0
      have horder0_ne_top : analyticOrderAt f 0 ≠ ⊤ := by simp [horder0]
      have horder_ne_top : analyticOrderAt f u ≠ ⊤ :=
        hf_anU.analyticOrderAt_ne_top_of_isPreconnected hpreU h0U huU horder0_ne_top
      -- Compute the divisor value at `u`.
      have hDu :
          MeromorphicOn.divisor f U u = (analyticOrderNatAt f u : ℤ) := by
        have han_u : AnalyticAt ℂ f u := hf_entire.analyticAt u
        have hdiv_apply :
            MeromorphicOn.divisor f U u = (meromorphicOrderAt f u).untop₀ :=
          MeromorphicOn.divisor_apply hmer huU
        have hmerOrder_u : meromorphicOrderAt f u = (analyticOrderAt f u).map (↑) :=
          han_u.meromorphicOrderAt_eq
        obtain ⟨n, hn : (n : ℕ∞) = analyticOrderAt f u⟩ := ENat.ne_top_iff_exists.mp horder_ne_top
        have hnNat : analyticOrderNatAt f u = n := by
          simp [analyticOrderNatAt, hn.symm]
        have : MeromorphicOn.divisor f U u = (n : ℤ) := by
          rw [hdiv_apply, hmerOrder_u, hn.symm]
          simp
        rw [hnNat]
        exact this
      -- Coerce to `ℝ`.
      have : (analyticOrderNatAt f u : ℝ) = (D u : ℝ) := by
        -- `D` is definitionally the divisor on `U`.
        -- Use `hDu` and cast to `ℝ`.
        have hDu' : D u = (analyticOrderNatAt f u : ℤ) := by simpa [D] using hDu
        -- Coerce and rewrite.
        exact_mod_cast hDu'.symm
      exact this
    -- `sU` is a subset of the divisor-support ball set,
    -- so its sum is bounded by the divisor finsum.
    let Su : Set ℂ := {u : ℂ | u ∈ D.support ∧ ‖u‖ ≤ r}
    have hSu_fin : Su.Finite := by
      refine hD_fin.subset ?_
      intro u hu
      exact hu.1
    let sSu : Finset ℂ := hSu_fin.toFinset
    have hsU_sub : sU ⊆ sSu := by
      intro u hu
      rcases Finset.mem_image.1 hu with ⟨ρ, hρ, rfl⟩
      have hρS : ρ ∈ Sρ := hSρ_fin.mem_toFinset.1 hρ
      have hle : ‖Z.z ρ‖ ≤ r := by simpa [Sρ, Set.mem_ofPred_eq] using hρS
      have hz_support : Z.z ρ ∈ D.support := by
        have hz_mem : Z.z ρ ∈ U := by
          have : ‖Z.z ρ‖ ≤ 2 * r := le_trans hle (by linarith)
          simpa [U, Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos] using this
        have : Z.z ρ ∈ (MeromorphicOn.divisor f U).support :=
          mem_divisor_support_of_zero
            (f := f) hf_entire (R := (2 * r)) (u := Z.z ρ) hz_mem hf0 (Z.isZero ρ)
        simpa [D, U] using this
      have : (Z.z ρ) ∈ Su := ⟨hz_support, hle⟩
      exact hSu_fin.mem_toFinset.2 this
    have hSu_nonneg : ∀ u ∈ sSu, u ∉ sU → 0 ≤ (D u : ℝ) := by
      intro u hu _
      have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
      exact_mod_cast hDu0
    have hsum_le :
        (∑ u ∈ sU, (D u : ℝ)) ≤ ∑ u ∈ sSu, (D u : ℝ) :=
      Finset.sum_le_sum_of_subset_of_nonneg hsU_sub hSu_nonneg
    have hsumSu_eq :
        (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) = ∑ u ∈ sSu, (D u : ℝ) := by
      have hsupp :
          Function.support (fun u : ℂ => if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) ⊆ sSu := by
        intro u hu
        have hne : (if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) ≠ 0 :=
          Function.mem_support.1 hu
        have hle : ‖u‖ ≤ r := by
          by_contra hle
          apply hne
          simp [hle]
        have hDu : D u ≠ 0 := by
          intro hDu0
          apply hne
          simp [hle, hDu0]
        have huS : u ∈ Su := by
          refine ⟨?_, hle⟩
          have : u ∈ Function.support (fun x : ℂ => D x) := Function.mem_support.2 hDu
          simpa [Function.locallyFinsuppWithin.support] using this
        exact hSu_fin.mem_toFinset.2 huS
      have :=
        (finsum_eq_sum_of_support_subset
          (f := fun u : ℂ => if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0)
          (s := sSu) hsupp)
      have hsum_if :
          (∑ u ∈ sSu, if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) = ∑ u ∈ sSu, (D u : ℝ) := by
        refine Finset.sum_congr rfl ?_
        intro u hu
        have huS : u ∈ Su := hSu_fin.mem_toFinset.1 hu
        have hle : ‖u‖ ≤ r := huS.2
        simp [hle]
      simpa [hsum_if] using this
    -- Finish the comparison.
    have hcompare :
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
          ≤ (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((MeromorphicOn.divisor f U u : ℤ) : ℝ) else 0) := by
      -- Rewrite LHS, then compare sums over `sU` and `sSu`, then rewrite RHS.
      have hRHS : (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((MeromorphicOn.divisor f U u : ℤ) : ℝ) else 0) =
          (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) := by
        rfl
      calc
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
            = ∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ) := hLHS
        _ = ∑ u ∈ sU, (analyticOrderNatAt f u : ℝ) := by simp [hsum_image]
        _ = ∑ u ∈ sU, (D u : ℝ) := hsum_divisor
        _ ≤ ∑ u ∈ sSu, (D u : ℝ) := hsum_le
        _ = (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) := by simp [hsumSu_eq]
        _ = (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((MeromorphicOn.divisor f U u : ℤ) : ℝ) else 0) := by rfl
    -- Combine with Jensen.
    have hdiv_bound' :
        (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((MeromorphicOn.divisor f U u : ℤ) : ℝ) else 0) ≤
          (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
      simpa [U] using hdiv_bound
    exact le_trans hcompare hdiv_bound'
  -- Replace `log (max 1 (maxModulus f (2r)))` using the max-modulus growth bound.
  have hM_le : maxModulus f (2 * r) ≤ Real.exp ((2 * r) ^ ((1 : ℝ) + ε)) :=
    hmax (2 * r) hr_ge_R1
  have hexp_ge1 : (1 : ℝ) ≤ Real.exp ((2 * r) ^ ((1 : ℝ) + ε)) := by
    have : 0 ≤ (2 * r) ^ ((1 : ℝ) + ε) := Real.rpow_nonneg (le_of_lt hRpos) _
    simpa using Real.one_le_exp this
  have hmax1_le : max 1 (maxModulus f (2 * r)) ≤ Real.exp ((2 * r) ^ ((1 : ℝ) + ε)) :=
    max_le hexp_ge1 hM_le
  have hlog_le : Real.log (max 1 (maxModulus f (2 * r))) ≤ (2 * r) ^ ((1 : ℝ) + ε) := by
    have hpos : 0 < max 1 (maxModulus f (2 * r)) := by
      have : (0 : ℝ) < (1 : ℝ) := by norm_num
      exact lt_of_lt_of_le this (le_max_left _ _)
    have := Real.log_le_log hpos hmax1_le
    simpa [Real.log_exp] using this
  have hnum :
      Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖
        ≤ (2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖ :=
    sub_le_sub_right hlog_le _
  have hden : 0 ≤ Real.log 2 := by
    exact le_of_lt (by simpa using Real.log_pos (by norm_num : (1 : ℝ) < 2))
  have hfrac :
      (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2
        ≤ ((2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖) / Real.log 2 :=
    div_le_div_of_nonneg_right hnum hden
  exact le_trans hbound1 hfrac

/-- **General-order multiplicity-weighted zero counting.**

This is the `order f ≤ lam` analogue of `sum_multiplicity_zeros_le_of_order_le_one`.
The proof is identical except we use the general max-modulus growth bound
`maxModulus_le_exp_rpow_of_order_le` instead of its order-1 specialization. -/
theorem sum_multiplicity_zeros_le_of_order_le
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) {lam : ℝ} (hf_order_le : order f ≤ lam)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0) :
    ∀ ε : ℝ, 0 < ε →
      ∃ R₀ : ℝ, ∀ r : ℝ, R₀ ≤ r →
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ≤
          ((2 * r) ^ (lam + ε) - Real.log ‖f 0‖) / Real.log 2 := by
  classical
  intro ε hε
  have hf0 : f 0 ≠ 0 := by
    intro hf0
    rcases (h_zeros_only 0).1 hf0 with ⟨ρ, hρ⟩
    exact (h_z_ne_zero ρ) (by simp [hρ])
  obtain ⟨R₁, hmax⟩ :=
    Hadamard.ZeroCounting.maxModulus_le_exp_rpow_of_order_le f hf_finite hf_order_le ε hε
  refine ⟨max R₁ 1, ?_⟩
  intro r hr
  have hr_ge_R1 : R₁ ≤ 2 * r := by
    have hR1_le : R₁ ≤ r := le_trans (le_max_left _ _) hr
    have hr_pos : 0 < r :=
      lt_of_lt_of_le (by norm_num : (0 : ℝ) < 1) (le_trans (le_max_right R₁ 1) hr)
    calc
      R₁ ≤ r := hR1_le
      _ ≤ 2 * r := by nlinarith
  have hRpos : 0 < 2 * r := by
    have : (0 : ℝ) < r := lt_of_lt_of_le (by norm_num) (le_trans (le_max_right R₁ 1) hr)
    linarith
  -- Jensen bound on the sum of divisor weights in `‖u‖ ≤ r` for the divisor on `‖u‖ ≤ 2r`.
  have hdiv_bound :
      (∑ᶠ u : ℂ,
          if ‖u‖ ≤ r then
            ((MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 * r)|) u : ℤ) : ℝ)
          else 0)
        ≤ (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
    simpa using
      Hadamard.ZeroCounting.sum_zeros_multiplicity_le_of_max_one_maxModulus (f := f)
        (R := (2 * r)) (by exact hRpos) hf_entire hf0
  -- Compare the multiplicity sum over `Z.Zero` to the divisor-weight sum over `ℂ`.
  have hbound1 :
      (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
        ≤ (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
    -- Same proof as in the `order ≤ 1` version; only the max-modulus bound changes.
    let U : Set ℂ := closedBall (0 : ℂ) |(2 * r)|
    let D : Function.locallyFinsuppWithin U ℤ := MeromorphicOn.divisor f U
    have hmer : MeromorphicOn f U := fun z _ => (hf_entire.analyticAt z).meromorphicAt
    have hD_fin : (D.support : Set ℂ).Finite :=
      D.finiteSupport (isCompact_closedBall (0 : ℂ) |(2 * r)|)
    have hD_nonneg : 0 ≤ D := by
      have hf_an : AnalyticOnNhd ℂ f U := by
        intro z _
        exact hf_entire.analyticAt z
      exact hf_an.divisor_nonneg
    let Sρ : Set Z.Zero := {ρ : Z.Zero | ‖Z.z ρ‖ ≤ r}
    have hImage : Z.z '' Sρ ⊆ D.support := by
      intro u hu
      rcases hu with ⟨ρ, hρ, rfl⟩
      have hu_mem : Z.z ρ ∈ U := by
        have : ‖Z.z ρ‖ ≤ 2 * r :=
          le_trans (by simpa [Sρ, Set.mem_ofPred_eq] using hρ) (by linarith)
        simpa [U, Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos] using this
      have : Z.z ρ ∈ (MeromorphicOn.divisor f U).support :=
        mem_divisor_support_of_zero
          (f := f) hf_entire (R := (2 * r)) (u := Z.z ρ) hu_mem hf0 (Z.isZero ρ)
      simpa [D, U] using this
    have hImageFinite : (Z.z '' Sρ).Finite := hD_fin.subset hImage
    have hSρ_fin : Sρ.Finite := Set.Finite.of_finite_image hImageFinite (h_inj.injOn)
    let sZ : Finset Z.Zero := hSρ_fin.toFinset
    let sU : Finset ℂ := sZ.image Z.z
    have hLHS :
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
          = ∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ) := by
      have hsupp :
          Function.support (fun ρ : Z.Zero =>
              if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ⊆ sZ := by
        intro ρ hρ
        have hne :
            (if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ≠ 0 :=
          Function.mem_support.1 hρ
        have hle : ‖Z.z ρ‖ ≤ r := by
          by_contra hle
          apply hne
          simp [hle]
        have : ρ ∈ Sρ := by
          simpa [Sρ, Set.mem_ofPred_eq] using hle
        exact hSρ_fin.mem_toFinset.2 this
      have :=
        (finsum_eq_sum_of_support_subset
          (f := fun ρ : Z.Zero =>
            if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
          (s := sZ) hsupp)
      have hsum_if :
          (∑ ρ ∈ sZ, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) =
            ∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ) := by
        refine Finset.sum_congr rfl ?_
        intro ρ hρ
        have hρS : ρ ∈ Sρ := hSρ_fin.mem_toFinset.1 hρ
        have hle : ‖Z.z ρ‖ ≤ r := by simpa [Sρ, Set.mem_ofPred_eq] using hρS
        simp [hle]
      simpa [hsum_if] using this
    have hsum_image :
        (∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ))
          = ∑ u ∈ sU, (analyticOrderNatAt f u : ℝ) := by
      have hinjOn : Set.InjOn Z.z (sZ : Set Z.Zero) := h_inj.injOn
      simpa [sU] using (Finset.sum_image (f := fun u : ℂ => (analyticOrderNatAt f u : ℝ))
        (s := sZ) (g := Z.z) hinjOn).symm
    have hsum_divisor :
        (∑ u ∈ sU, (analyticOrderNatAt f u : ℝ))
          = ∑ u ∈ sU, (D u : ℝ) := by
      refine Finset.sum_congr rfl ?_
      intro u hu
      have huU : u ∈ U := by
        rcases Finset.mem_image.1 hu with ⟨ρ, hρ, rfl⟩
        have hρS : ρ ∈ Sρ := hSρ_fin.mem_toFinset.1 hρ
        have hle : ‖Z.z ρ‖ ≤ r := by simpa [Sρ, Set.mem_ofPred_eq] using hρS
        have : ‖Z.z ρ‖ ≤ 2 * r := le_trans hle (by linarith)
        simpa [U, Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos] using this
      have hf_anU : AnalyticOnNhd ℂ f U := by
        intro z _
        exact hf_entire.analyticAt z
      have h0U : (0 : ℂ) ∈ U := by
        simp [U, Metric.mem_closedBall]
      have hpreU : IsPreconnected U := (convex_closedBall (0 : ℂ) |(2 * r)|).isPreconnected
      have horder0 : analyticOrderAt f 0 = 0 :=
        (hf_entire.analyticAt 0).analyticOrderAt_eq_zero.2 hf0
      have horder0_ne_top : analyticOrderAt f 0 ≠ ⊤ := by simp [horder0]
      have horder_ne_top : analyticOrderAt f u ≠ ⊤ :=
        hf_anU.analyticOrderAt_ne_top_of_isPreconnected hpreU h0U huU horder0_ne_top
      have hDu :
          MeromorphicOn.divisor f U u = (analyticOrderNatAt f u : ℤ) := by
        have han_u : AnalyticAt ℂ f u := hf_entire.analyticAt u
        have hdiv_apply :
            MeromorphicOn.divisor f U u = (meromorphicOrderAt f u).untop₀ :=
          MeromorphicOn.divisor_apply hmer huU
        have hmerOrder_u : meromorphicOrderAt f u = (analyticOrderAt f u).map (↑) :=
          han_u.meromorphicOrderAt_eq
        obtain ⟨n, hn : (n : ℕ∞) = analyticOrderAt f u⟩ := ENat.ne_top_iff_exists.mp horder_ne_top
        have hnNat : analyticOrderNatAt f u = n := by
          simp [analyticOrderNatAt, hn.symm]
        have : MeromorphicOn.divisor f U u = (n : ℤ) := by
          rw [hdiv_apply, hmerOrder_u, hn.symm]
          simp
        rw [hnNat]
        exact this
      have : (analyticOrderNatAt f u : ℝ) = (D u : ℝ) := by
        have hDu' : D u = (analyticOrderNatAt f u : ℤ) := by simpa [D] using hDu
        exact_mod_cast hDu'.symm
      exact this
    let Su : Set ℂ := {u : ℂ | u ∈ D.support ∧ ‖u‖ ≤ r}
    have hSu_fin : Su.Finite := by
      refine hD_fin.subset ?_
      intro u hu
      exact hu.1
    let sSu : Finset ℂ := hSu_fin.toFinset
    have hsU_sub : sU ⊆ sSu := by
      intro u hu
      rcases Finset.mem_image.1 hu with ⟨ρ, hρ, rfl⟩
      have hρS : ρ ∈ Sρ := hSρ_fin.mem_toFinset.1 hρ
      have hle : ‖Z.z ρ‖ ≤ r := by simpa [Sρ, Set.mem_ofPred_eq] using hρS
      have hz_support : Z.z ρ ∈ D.support := by
        have hz_mem : Z.z ρ ∈ U := by
          have : ‖Z.z ρ‖ ≤ 2 * r := le_trans hle (by linarith)
          simpa [U, Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos] using this
        have : Z.z ρ ∈ (MeromorphicOn.divisor f U).support :=
          mem_divisor_support_of_zero
            (f := f) hf_entire (R := (2 * r)) (u := Z.z ρ) hz_mem hf0 (Z.isZero ρ)
        simpa [D, U] using this
      have : (Z.z ρ) ∈ Su := ⟨hz_support, hle⟩
      exact hSu_fin.mem_toFinset.2 this
    have hSu_nonneg : ∀ u ∈ sSu, u ∉ sU → 0 ≤ (D u : ℝ) := by
      intro u hu _
      have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
      exact_mod_cast hDu0
    have hsum_le :
        (∑ u ∈ sU, (D u : ℝ)) ≤ ∑ u ∈ sSu, (D u : ℝ) :=
      Finset.sum_le_sum_of_subset_of_nonneg hsU_sub hSu_nonneg
    have hsumSu_eq :
        (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) = ∑ u ∈ sSu, (D u : ℝ) := by
      have hsupp :
          Function.support (fun u : ℂ => if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) ⊆ sSu := by
        intro u hu
        have hne : (if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) ≠ 0 :=
          Function.mem_support.1 hu
        have hle : ‖u‖ ≤ r := by
          by_contra hle
          apply hne
          simp [hle]
        have hDu : D u ≠ 0 := by
          intro hDu0
          apply hne
          simp [hle, hDu0]
        have huS : u ∈ Su := by
          refine ⟨?_, hle⟩
          have : u ∈ Function.support (fun x : ℂ => D x) := Function.mem_support.2 hDu
          simpa [Function.locallyFinsuppWithin.support] using this
        exact hSu_fin.mem_toFinset.2 huS
      have :=
        (finsum_eq_sum_of_support_subset
          (f := fun u : ℂ => if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0)
          (s := sSu) hsupp)
      have hsum_if :
          (∑ u ∈ sSu, if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) = ∑ u ∈ sSu, (D u : ℝ) := by
        refine Finset.sum_congr rfl ?_
        intro u hu
        have huS : u ∈ Su := hSu_fin.mem_toFinset.1 hu
        have hle : ‖u‖ ≤ r := huS.2
        simp [hle]
      simpa [hsum_if] using this
    have hcompare :
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
          ≤ (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((MeromorphicOn.divisor f U u : ℤ) : ℝ) else 0) := by
      calc
        (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
            = ∑ ρ ∈ sZ, (analyticOrderNatAt f (Z.z ρ) : ℝ) := hLHS
        _ = ∑ u ∈ sU, (analyticOrderNatAt f u : ℝ) := by simp [hsum_image]
        _ = ∑ u ∈ sU, (D u : ℝ) := hsum_divisor
        _ ≤ ∑ u ∈ sSu, (D u : ℝ) := hsum_le
        _ = (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((D u : ℤ) : ℝ) else 0) := by simp [hsumSu_eq]
        _ = (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((MeromorphicOn.divisor f U u : ℤ) : ℝ) else 0) := by rfl
    have hdiv_bound' :
        (∑ᶠ u : ℂ, if ‖u‖ ≤ r then ((MeromorphicOn.divisor f U u : ℤ) : ℝ) else 0) ≤
          (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2 := by
      simpa [U] using hdiv_bound
    exact le_trans hcompare hdiv_bound'
  -- Replace `log (max 1 (maxModulus f (2r)))` using the max-modulus growth bound (general order).
  have hM_le : maxModulus f (2 * r) ≤ Real.exp ((2 * r) ^ (lam + ε)) :=
    hmax (2 * r) hr_ge_R1
  have hexp_ge1 : (1 : ℝ) ≤ Real.exp ((2 * r) ^ (lam + ε)) := by
    have : 0 ≤ (2 * r) ^ (lam + ε) := Real.rpow_nonneg (le_of_lt hRpos) _
    simpa using Real.one_le_exp this
  have hmax1_le : max 1 (maxModulus f (2 * r)) ≤ Real.exp ((2 * r) ^ (lam + ε)) :=
    max_le hexp_ge1 hM_le
  have hlog_le : Real.log (max 1 (maxModulus f (2 * r))) ≤ (2 * r) ^ (lam + ε) := by
    have hpos : 0 < max 1 (maxModulus f (2 * r)) := by
      have : (0 : ℝ) < (1 : ℝ) := by norm_num
      exact lt_of_lt_of_le this (le_max_left _ _)
    have := Real.log_le_log hpos hmax1_le
    simpa [Real.log_exp] using this
  have hnum :
      Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖
        ≤ (2 * r) ^ (lam + ε) - Real.log ‖f 0‖ :=
    sub_le_sub_right hlog_le _
  have hden : 0 ≤ Real.log 2 := by
    exact le_of_lt (by simpa using Real.log_pos (by norm_num : (1 : ℝ) < 2))
  have hfrac :
      (Real.log (max 1 (maxModulus f (2 * r))) - Real.log ‖f 0‖) / Real.log 2
        ≤ ((2 * r) ^ (lam + ε) - Real.log ‖f 0‖) / Real.log 2 :=
    div_le_div_of_nonneg_right hnum hden
  exact le_trans hbound1 hfrac

end OrderOne

end Hadamard
~~~~~~

## Hadamard.ZeroCounting

Path: `source/Hadamard/ZeroCounting.lean`

Original source lines: 1–885

Full file SHA256: `9987d7ac4775ef1dcafee17265391ca9270c4b7a3a4984fb5bbc3b3d2903a3b9`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/ZeroCounting.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Analysis.Complex.JensenFormula
import Hadamard.Basic

/-!
Zero counting bounds from Jensen's formula.

This module packages one very specific estimate we use repeatedly:
if `order f ≤ 1`, then the number of (distinct) zeros in a disk grows like `O(r^(1+ε))`.

We express “distinct zeros” using the `MeromorphicOn.divisor` support on a closed ball; for an
analytic function this support is exactly the set of zeros in the ball (no poles).
-/

open Complex Real Filter Topology MeasureTheory
open scoped BigOperators

namespace Hadamard

namespace ZeroCounting

open Metric MeromorphicOn

/-! ### From `order ≤ 1` to a crude `maxModulus` upper bound -/

private lemma mul_card_le_sum_of_forall_le {α : Type*} (s : Finset α) (a : ℝ) (f : α → ℝ)
    (h : ∀ x ∈ s, a ≤ f x) : a * (s.card : ℝ) ≤ ∑ x ∈ s, f x := by
  classical
  classical
  induction s using Finset.induction_on with
  | empty =>
      simp
  | @insert x s hx ih =>
      have hx' : a ≤ f x := h x (by simp [hx])
      have hs' : ∀ y ∈ s, a ≤ f y := by
        intro y hy
        exact h y (by simp [hy])
      have ih' : a * (s.card : ℝ) ≤ ∑ y ∈ s, f y := ih hs'
      -- `card (insert x s) = card s + 1`, `sum (insert x s) = f x + sum s`
      have hcard : ((insert x s).card : ℝ) = (s.card : ℝ) + 1 := by
        have : (insert x s).card = s.card + 1 := Finset.card_insert_of_notMem hx
        exact_mod_cast this
      have hsum : (∑ y ∈ insert x s, f y) = f x + ∑ y ∈ s, f y := by
        simpa using (Finset.sum_insert (f := f) (s := s) (a := x) hx)
      -- Combine
      calc
        a * ((insert x s).card : ℝ)
            = a * ((s.card : ℝ) + 1) := by simp [hcard]
        _ = a * (s.card : ℝ) + a := by ring
        _ ≤ (∑ y ∈ s, f y) + f x := by
              exact add_le_add ih' hx'
        _ = f x + ∑ y ∈ s, f y := by ac_rfl
        _ = ∑ y ∈ insert x s, f y := by simp [hsum]

private noncomputable def orderAux (f : ℂ → ℂ) (r : ℝ) : ℝ :=
  if r > 0 ∧ maxModulus f r > 1 then
    Real.log (Real.log (maxModulus f r)) / Real.log r
  else 0

private lemma isBoundedUnder_orderAux_of_hasFiniteOrder (f : ℂ → ℂ) (hf : hasFiniteOrder f) :
    IsBoundedUnder (· ≤ ·) atTop (orderAux f) := by
  classical
  obtain ⟨hf_diff, ρ₀, R₀, hf_bound⟩ := hf
  refine isBoundedUnder_of_eventually_le (u := orderAux f) (a := max ρ₀ 0) ?_
  refine (eventually_atTop.2 ⟨max R₀ 2, ?_⟩)
  intro r hr
  have hr_ge_R0 : R₀ ≤ r := le_trans (le_max_left _ _) hr
  have hr_ge2 : (2 : ℝ) ≤ r := le_trans (le_max_right _ _) hr
  have hr_pos : 0 < r := by linarith
  have hr_gt1 : 1 < r := by linarith
  have hlogr_pos : 0 < Real.log r := Real.log_pos hr_gt1
  by_cases hM : maxModulus f r > 1
  · have hM_le : maxModulus f r ≤ Real.exp (r ^ ρ₀) := by
      refine maxModulus_le_of_forall_norm_le f hf_diff.continuous (le_of_lt hr_pos) ?_
      intro z hz
      have hRz : R₀ ≤ ‖z‖ := by simpa [hz] using hr_ge_R0
      exact le_of_lt (by simpa [hz] using hf_bound z hRz)
    have hlogM_le : Real.log (maxModulus f r) ≤ r ^ ρ₀ := by
      have hM_pos : 0 < maxModulus f r := lt_trans (by linarith) hM
      have := Real.log_le_log hM_pos hM_le
      simpa [Real.log_exp] using this
    have hlogM_pos : 0 < Real.log (maxModulus f r) := Real.log_pos hM
    have hloglog_le :
        Real.log (Real.log (maxModulus f r)) ≤ Real.log (r ^ ρ₀) :=
      Real.log_le_log hlogM_pos hlogM_le
    have hratio_le : Real.log (Real.log (maxModulus f r)) / Real.log r ≤ ρ₀ := by
      have hlogrpow : Real.log (r ^ ρ₀) = ρ₀ * Real.log r := Real.log_rpow hr_pos ρ₀
      have : Real.log (Real.log (maxModulus f r)) ≤ ρ₀ * Real.log r :=
        le_trans hloglog_le (by rw [hlogrpow])
      exact (div_le_iff₀ hlogr_pos).2 this
    have hcond : r > 0 ∧ maxModulus f r > 1 := ⟨hr_pos, hM⟩
    have : orderAux f r ≤ ρ₀ := by simpa [orderAux, hcond] using hratio_le
    exact le_trans this (le_max_left _ _)
  · have hcond : ¬(r > 0 ∧ maxModulus f r > 1) := by
      intro hcond
      exact hM hcond.2
    simp [orderAux, hcond, le_max_right _ _]

theorem maxModulus_le_exp_rpow_of_order_le_one (f : ℂ → ℂ)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1) :
    ∀ ε : ℝ, 0 < ε → ∃ R₀ : ℝ, ∀ r : ℝ, R₀ ≤ r → maxModulus f r ≤ Real.exp (r ^ (1 + ε)) := by
  classical
  intro ε hε
  have hu_bdd : IsBoundedUnder (· ≤ ·) atTop (orderAux f) :=
    isBoundedUnder_orderAux_of_hasFiniteOrder f hf_finite
  have h_limsup_le : Filter.limsup (orderAux f) atTop ≤ (1 : ℝ) := hf_order_le
  have hu_event : ∀ᶠ r : ℝ in atTop, orderAux f r < (1 : ℝ) + ε :=
    eventually_lt_add_pos_of_limsup_le (by simpa using hu_bdd) h_limsup_le hε
  -- also ensure `2 ≤ r` so `log r > 0`
  have hge2 : ∀ᶠ r : ℝ in atTop, (2 : ℝ) ≤ r := Filter.eventually_ge_atTop 2
  rcases (Filter.eventually_atTop.1 (hu_event.and hge2)) with ⟨R₀, hR₀⟩
  refine ⟨R₀, ?_⟩
  intro r hr
  have hr' := hR₀ r hr
  have haux_lt : orderAux f r < (1 : ℝ) + ε := hr'.1
  have hr_ge2 : (2 : ℝ) ≤ r := hr'.2
  have hr_pos : 0 < r := by linarith
  by_cases hM : maxModulus f r > 1
  · have hr_gt1 : 1 < r := by linarith
    have hlogr_pos : 0 < Real.log r := Real.log_pos hr_gt1
    have hcond : r > 0 ∧ maxModulus f r > 1 := ⟨hr_pos, hM⟩
    have hmain :
        Real.log (Real.log (maxModulus f r)) / Real.log r < (1 : ℝ) + ε := by
      simpa [orderAux, hcond] using haux_lt
    have hloglog :
        Real.log (Real.log (maxModulus f r)) < ((1 : ℝ) + ε) * Real.log r :=
      (div_lt_iff₀ hlogr_pos).1 hmain
    have hlogM_pos : 0 < Real.log (maxModulus f r) := Real.log_pos hM
    have hlogM : Real.log (maxModulus f r) < Real.exp (((1 : ℝ) + ε) * Real.log r) := by
      have hexp :
          Real.exp (Real.log (Real.log (maxModulus f r))) < Real.exp (((1 : ℝ) + ε) * Real.log r) :=
        (Real.exp_lt_exp).2 hloglog
      simpa [Real.exp_log hlogM_pos] using hexp
    have hexp_eq : Real.exp (((1 : ℝ) + ε) * Real.log r) = r ^ ((1 : ℝ) + ε) := by
      calc
        Real.exp (((1 : ℝ) + ε) * Real.log r) = Real.exp (Real.log r * ((1 : ℝ) + ε)) := by ring_nf
        _ = Real.exp (Real.log r) ^ ((1 : ℝ) + ε) := by simp [Real.exp_mul]
        _ = r ^ ((1 : ℝ) + ε) := by simp [Real.exp_log hr_pos]
    have hlogM' : Real.log (maxModulus f r) < r ^ ((1 : ℝ) + ε) := by
      simpa [hexp_eq] using hlogM
    have hM_pos : 0 < maxModulus f r := lt_trans (by linarith) hM
    have hM_lt : maxModulus f r < Real.exp (r ^ ((1 : ℝ) + ε)) := by
      have hexp : Real.exp (Real.log (maxModulus f r)) < Real.exp (r ^ ((1 : ℝ) + ε)) :=
        (Real.exp_lt_exp).2 hlogM'
      simpa [Real.exp_log hM_pos] using hexp
    exact le_of_lt hM_lt
  · -- If `M ≤ 1`, the bound is trivial since `exp(r^(1+ε)) ≥ 1`.
    have hM_le : maxModulus f r ≤ 1 := le_of_not_gt hM
    have hexp_ge : (1 : ℝ) ≤ Real.exp (r ^ ((1 : ℝ) + ε)) := by
      have : 0 ≤ r ^ ((1 : ℝ) + ε) := by
        exact Real.rpow_nonneg (le_of_lt hr_pos) _
      simpa using (Real.one_le_exp this)
    exact le_trans hM_le hexp_ge

/-- **General-order max-modulus growth bound.**

If `f` has finite order with `order f ≤ lam`, then for every `ε > 0` there is
`R₀` such that for all `r ≥ R₀`, `maxModulus f r ≤ Real.exp (r ^ (lam + ε))`.

This is the `order ≤ lam` analogue of
`maxModulus_le_exp_rpow_of_order_le_one`. The proof is exactly the same: the
specific constant `1` in the latter never interacts with the analysis, it is
simply the bound on the limsup. -/
theorem maxModulus_le_exp_rpow_of_order_le (f : ℂ → ℂ)
    (hf_finite : hasFiniteOrder f) {lam : ℝ} (hf_order_le : order f ≤ lam) :
    ∀ ε : ℝ, 0 < ε → ∃ R₀ : ℝ, ∀ r : ℝ, R₀ ≤ r →
      maxModulus f r ≤ Real.exp (r ^ (lam + ε)) := by
  classical
  intro ε hε
  have hu_bdd : IsBoundedUnder (· ≤ ·) atTop (orderAux f) :=
    isBoundedUnder_orderAux_of_hasFiniteOrder f hf_finite
  have h_limsup_le : Filter.limsup (orderAux f) atTop ≤ lam := hf_order_le
  have hu_event : ∀ᶠ r : ℝ in atTop, orderAux f r < lam + ε :=
    eventually_lt_add_pos_of_limsup_le (by simpa using hu_bdd) h_limsup_le hε
  have hge2 : ∀ᶠ r : ℝ in atTop, (2 : ℝ) ≤ r := Filter.eventually_ge_atTop 2
  rcases (Filter.eventually_atTop.1 (hu_event.and hge2)) with ⟨R₀, hR₀⟩
  refine ⟨R₀, ?_⟩
  intro r hr
  have hr' := hR₀ r hr
  have haux_lt : orderAux f r < lam + ε := hr'.1
  have hr_ge2 : (2 : ℝ) ≤ r := hr'.2
  have hr_pos : 0 < r := by linarith
  by_cases hM : maxModulus f r > 1
  · have hr_gt1 : 1 < r := by linarith
    have hlogr_pos : 0 < Real.log r := Real.log_pos hr_gt1
    have hcond : r > 0 ∧ maxModulus f r > 1 := ⟨hr_pos, hM⟩
    have hmain :
        Real.log (Real.log (maxModulus f r)) / Real.log r < lam + ε := by
      simpa [orderAux, hcond] using haux_lt
    have hloglog :
        Real.log (Real.log (maxModulus f r)) < (lam + ε) * Real.log r :=
      (div_lt_iff₀ hlogr_pos).1 hmain
    have hlogM_pos : 0 < Real.log (maxModulus f r) := Real.log_pos hM
    have hlogM : Real.log (maxModulus f r) < Real.exp ((lam + ε) * Real.log r) := by
      have hexp :
          Real.exp (Real.log (Real.log (maxModulus f r))) < Real.exp ((lam + ε) * Real.log r) :=
        (Real.exp_lt_exp).2 hloglog
      simpa [Real.exp_log hlogM_pos] using hexp
    have hexp_eq : Real.exp ((lam + ε) * Real.log r) = r ^ (lam + ε) := by
      calc
        Real.exp ((lam + ε) * Real.log r) = Real.exp (Real.log r * (lam + ε)) := by ring_nf
        _ = Real.exp (Real.log r) ^ (lam + ε) := by simp [Real.exp_mul]
        _ = r ^ (lam + ε) := by simp [Real.exp_log hr_pos]
    have hlogM' : Real.log (maxModulus f r) < r ^ (lam + ε) := by
      simpa [hexp_eq] using hlogM
    have hM_pos : 0 < maxModulus f r := lt_trans (by linarith) hM
    have hM_lt : maxModulus f r < Real.exp (r ^ (lam + ε)) := by
      have hexp : Real.exp (Real.log (maxModulus f r)) < Real.exp (r ^ (lam + ε)) :=
        (Real.exp_lt_exp).2 hlogM'
      simpa [Real.exp_log hM_pos] using hexp
    exact le_of_lt hM_lt
  · have hM_le : maxModulus f r ≤ 1 := le_of_not_gt hM
    have hexp_ge : (1 : ℝ) ≤ Real.exp (r ^ (lam + ε)) := by
      have : 0 ≤ r ^ (lam + ε) := by
        exact Real.rpow_nonneg (le_of_lt hr_pos) _
      simpa using (Real.one_le_exp this)
    exact le_trans hM_le hexp_ge

/-! ### Jensen ⇒ a bound on the number of zeros -/

theorem card_zeros_le_of_maxModulus (f : ℂ → ℂ) {R : ℝ} (hR : 0 < R)
    (hf_entire : Differentiable ℂ f) (hf0 : f 0 ≠ 0) (hM : (1 : ℝ) ≤ maxModulus f R) :
    (({u : ℂ |
          u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|)).support ∧ ‖u‖ ≤ R / 2} :
        Set ℂ).ncard : ℝ)
      ≤ (Real.log (maxModulus f R) - Real.log ‖f 0‖) / Real.log 2 := by
  classical
  -- Setup Jensen on `closedBall 0 R`.
  have hmer : MeromorphicOn f (closedBall (0 : ℂ) |R|) := fun z _ =>
    (hf_entire.analyticAt z).meromorphicAt
  have hCB0 : (0 : ℂ) ∈ closedBall (0 : ℂ) |R| := by
    simp [Metric.mem_closedBall, abs_nonneg R]
  have htrailing : meromorphicTrailingCoeffAt f 0 = f 0 := by
    simpa using (hf_entire.analyticAt 0).meromorphicTrailingCoeffAt_of_ne_zero hf0
  have hdiv0 : MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) 0 = 0 := by
    -- `divisor` at `0` is `order.untop₀`, and the order is zero since `f 0 ≠ 0`.
    have horder0 : analyticOrderAt f 0 = 0 :=
      (hf_entire.analyticAt 0).analyticOrderAt_eq_zero.2 hf0
    have hmerOrder0 :
        meromorphicOrderAt f 0 = 0 := by
      simpa [horder0] using (hf_entire.analyticAt 0).meromorphicOrderAt_eq
    simp [MeromorphicOn.divisor_apply hmer hCB0, hmerOrder0]
  -- Jensen formula at the origin.
  have hjensen :
      Real.circleAverage (Real.log ‖f ·‖) 0 R
        = (∑ᶠ u, MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u * Real.log (R * ‖u‖⁻¹))
          + Real.log ‖f 0‖ := by
    have :=
      MeromorphicOn.circleAverage_log_norm (c := (0 : ℂ)) (R := R) (f := f)
        (by exact hR.ne') hmer
    -- simplify `‖0 - u‖ = ‖u‖`, divisor at 0, and trailing coefficient
    simpa [hdiv0, htrailing, norm_sub_rev, add_assoc, add_left_comm, add_comm, sub_eq_add_neg]
      using this
  -- Upper-bound the circle average by `log (maxModulus f R)` (pointwise, using `M ≥ 1`).
  have hCircleInt : CircleIntegrable (Real.log ‖f ·‖) 0 R := by
    apply MeromorphicOn.circleIntegrable_log_norm
    intro z hz
    have hz' : z ∈ closedBall (0 : ℂ) |R| := Metric.sphere_subset_closedBall hz
    exact hmer z hz'
  have havg_le :
      Real.circleAverage (Real.log ‖f ·‖) 0 R ≤ Real.log (maxModulus f R) := by
    refine
      Real.circleAverage_mono_on_of_le_circle (c := (0 : ℂ)) (R := R)
        (f := fun z => Real.log ‖f z‖) (a := Real.log (maxModulus f R)) hCircleInt ?_
    intro z hz
    have hzR : ‖z‖ = R := by simpa [Metric.mem_sphere, dist_eq_norm, abs_of_pos hR] using hz
    have hnorm : ‖f z‖ ≤ maxModulus f R := norm_le_maxModulus_on_circle f hf_entire.continuous hzR
    by_cases hfz : f z = 0
    · have hlogM_nonneg : 0 ≤ Real.log (maxModulus f R) := Real.log_nonneg hM
      simpa [hfz] using hlogM_nonneg
    · have hpos : 0 < ‖f z‖ := norm_pos_iff.2 hfz
      exact Real.log_le_log hpos hnorm
  -- Convert Jensen + `havg_le` into an upper bound on the finsum.
  have hsum_le :
      (∑ᶠ u, MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u * Real.log (R * ‖u‖⁻¹))
        ≤ Real.log (maxModulus f R) - Real.log ‖f 0‖ := by
    have := sub_le_sub_right havg_le (Real.log ‖f 0‖)
    -- `circleAverage = sum + log‖f0‖`
    -- so `sum = circleAverage - log‖f0‖`.
    simpa [hjensen, sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using this
  -- Lower-bound the same finsum by `log 2 * (number of zeros with ‖u‖ ≤ R/2)`.
  let D : Function.locallyFinsuppWithin (closedBall (0 : ℂ) |R|) ℤ :=
    MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|)
  have hD_fin : (D.support : Set ℂ).Finite :=
    D.finiteSupport (isCompact_closedBall (0 : ℂ) |R|)
  have hD_nonneg : 0 ≤ D := by
    -- analytic ⇒ nonnegative divisor on the closed ball
    have hf_an : AnalyticOnNhd ℂ f (closedBall (0 : ℂ) |R|) := by
      intro z _
      exact hf_entire.analyticAt z
    exact hf_an.divisor_nonneg
  let S : Set ℂ := {u : ℂ | u ∈ D.support ∧ ‖u‖ ≤ R / 2}
  have hS_fin : S.Finite := by
    refine hD_fin.subset ?_
    intro u hu
    exact hu.1
  have hlog2_pos : 0 < Real.log 2 := by
    simpa using (Real.log_pos (by norm_num : (1 : ℝ) < 2))
  have hsum_ge :
      (Real.log 2) * (hS_fin.toFinset.card : ℝ)
        ≤ (∑ᶠ u, D u * Real.log (R * ‖u‖⁻¹)) := by
    -- Expand the finsum as a finite sum over the support.
    have hsupp :
        (Function.support fun u => (D u : ℝ) * Real.log (R * ‖u‖⁻¹)) ⊆ hD_fin.toFinset := by
      intro u hu
      -- if the term is nonzero, then `D u ≠ 0`, hence `u ∈ D.support`
      have ht_ne : (D u : ℝ) * Real.log (R * ‖u‖⁻¹) ≠ 0 := (Function.mem_support.1 hu)
      have hDu : D u ≠ 0 := by
        intro hDu0
        apply ht_ne
        simp [hDu0]
      have huD : u ∈ D.support := by
        have : u ∈ Function.support (fun x : ℂ => D x) := (Function.mem_support.2 hDu)
        simpa [Function.locallyFinsuppWithin.support] using this
      exact hD_fin.mem_toFinset.2 huD
    -- Restrict the sum to the support finset.
    have hsum_eq :
        (∑ᶠ u, D u * Real.log (R * ‖u‖⁻¹))
          = ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      simpa using
        (finsum_eq_sum_of_support_subset
          (f := fun u : ℂ => (D u : ℝ) * Real.log (R * ‖u‖⁻¹)) (s := hD_fin.toFinset) hsupp)
    -- Show each `u ∈ S` contributes at least `log 2`, and other terms are nonnegative.
    have hterm_ge : ∀ u ∈ hS_fin.toFinset, (Real.log 2 : ℝ) ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      intro u hu
      have huS : u ∈ S := (hS_fin.mem_toFinset).1 hu
      have hDu_ne : D u ≠ 0 := by
        have huD : u ∈ D.support := huS.1
        have huD' : u ∈ Function.support (fun x : ℂ => D x) := by
          simpa [Function.locallyFinsuppWithin.support] using huD
        exact (Function.mem_support.1 huD')
      have hDu_pos : (1 : ℤ) ≤ D u := by
        have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
        have hlt : (0 : ℤ) < D u := lt_of_le_of_ne hDu0 (Ne.symm hDu_ne)
        -- `0 + 1 ≤ D u` ↔ `0 < D u`
        simpa [zero_add] using (Int.add_one_le_iff.2 hlt)
      have hu_ne0 : u ≠ 0 := by
        intro hu0
        -- would force `D 0 = 0` since `f 0 ≠ 0`
        have : D 0 = 0 := by simpa [D] using hdiv0
        have : D u = 0 := by simpa [hu0] using this
        exact hDu_ne this
      have hu_le : ‖u‖ ≤ R / 2 := huS.2
      have hu_pos : 0 < ‖u‖ := norm_pos_iff.2 hu_ne0
      have htwo : (2 : ℝ) ≤ R * ‖u‖⁻¹ := by
        have hmul : (2 : ℝ) * ‖u‖ ≤ R := by nlinarith
        have : (2 : ℝ) ≤ R / ‖u‖ := (le_div_iff₀ hu_pos).2 hmul
        simpa [div_eq_mul_inv] using this
      have hlog_ge : Real.log 2 ≤ Real.log (R * ‖u‖⁻¹) :=
        Real.log_le_log (by positivity : (0 : ℝ) < 2) htwo
      have hlog_nonneg : 0 ≤ Real.log (R * ‖u‖⁻¹) := by
        have h1 : (1 : ℝ) ≤ R * ‖u‖⁻¹ := le_trans (by norm_num : (1 : ℝ) ≤ 2) htwo
        exact Real.log_nonneg h1
      -- combine: `(D u : ℝ) ≥ 1` and `log(R/‖u‖) ≥ log 2`
      have hDu_ge1 : (1 : ℝ) ≤ (D u : ℝ) := by exact_mod_cast hDu_pos
      have hlog_ge' : (Real.log 2 : ℝ) ≤ (1 : ℝ) * Real.log (R * ‖u‖⁻¹) := by
        simpa [one_mul] using hlog_ge
      have := le_trans hlog_ge' (mul_le_mul_of_nonneg_right hDu_ge1 hlog_nonneg)
      simpa [one_mul, mul_assoc] using this
    -- The sum over the whole support dominates `log2 * card S`.
    have hcard_mul :
        (Real.log 2) * (hS_fin.toFinset.card : ℝ)
          ≤ ∑ u ∈ hS_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      -- each summand ≥ log2
      have h := mul_card_le_sum_of_forall_le (s := hS_fin.toFinset) (a := Real.log 2)
        (f := fun u => (D u : ℝ) * Real.log (R * ‖u‖⁻¹)) hterm_ge
      simpa [mul_comm] using h
    -- enlarge from `S` to the full support by monotonicity (all terms are nonnegative)
    have hnonneg : ∀ u ∈ hD_fin.toFinset, 0 ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      intro u hu
      have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
      have hDu0' : (0 : ℝ) ≤ (D u : ℝ) := by exact_mod_cast hDu0
      have hlog0 : 0 ≤ Real.log (R * ‖u‖⁻¹) := by
        -- `u` is in the support of `D`, hence `u ∈ closedBall 0 R`, so `‖u‖ ≤ R`
        have huU : u ∈ closedBall (0 : ℂ) |R| := by
          have : u ∈ D.support := hD_fin.mem_toFinset.1 hu
          exact D.supportWithinDomain this
        have hu_le : ‖u‖ ≤ |R| := by simpa [Metric.mem_closedBall, dist_eq_norm] using huU
        by_cases hu0 : u = 0
        · subst hu0
          simp
        · have hu_pos : 0 < ‖u‖ := norm_pos_iff.2 hu0
          have hmul_ge : (1 : ℝ) ≤ R * ‖u‖⁻¹ := by
            have : (1 : ℝ) ≤ R / ‖u‖ := by
              have hu_le' : ‖u‖ ≤ R := by simpa [abs_of_pos hR] using hu_le
              have : (1 : ℝ) * ‖u‖ ≤ R := by simpa [one_mul] using hu_le'
              exact (le_div_iff₀ hu_pos).2 this
            simpa [div_eq_mul_inv] using this
          exact Real.log_nonneg hmul_ge
      exact mul_nonneg hDu0' hlog0
    have hsub : hS_fin.toFinset ⊆ hD_fin.toFinset := by
      intro u hu
      have : u ∈ S := by simpa [hS_fin.mem_toFinset] using hu
      exact hD_fin.mem_toFinset.2 this.1
    have hsum_le' :
        (∑ u ∈ hS_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹))
          ≤ ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      have hnonneg' :
          ∀ u ∈ hD_fin.toFinset, u ∉ hS_fin.toFinset → 0 ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
        intro u hu _
        exact hnonneg u hu
      exact Finset.sum_le_sum_of_subset_of_nonneg hsub hnonneg'
    -- combine everything and rewrite `finsum`
    have : (Real.log 2) * (hS_fin.toFinset.card : ℝ)
        ≤ ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) :=
      le_trans hcard_mul hsum_le'
    simpa [hsum_eq] using this
  -- Now finish by dividing by `log 2`.
  have hlog2_ne : Real.log 2 ≠ 0 := ne_of_gt hlog2_pos
  have hcard :
      (hS_fin.toFinset.card : ℝ) ≤ (Real.log (maxModulus f R) - Real.log ‖f 0‖) / Real.log 2 := by
    have h1 : (Real.log 2) * (hS_fin.toFinset.card : ℝ)
        ≤ Real.log (maxModulus f R) - Real.log ‖f 0‖ :=
      le_trans hsum_ge hsum_le
    -- divide by the positive constant `log 2`
    have := mul_le_mul_of_nonneg_left h1 (le_of_lt (inv_pos.2 hlog2_pos))
    -- rewrite `inv * (log2 * card) = card`
    -- and `inv * (rhs) = rhs / log2`
    simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm, hlog2_ne] using this
  have hcard' : ((S.ncard : ℝ)) ≤ (Real.log (maxModulus f R) - Real.log ‖f 0‖) / Real.log 2 := by
    simpa [Set.ncard_eq_toFinset_card S hS_fin] using hcard
  simpa [S] using hcard'

/-! ### Variant: avoid the `1 ≤ maxModulus f R` side condition

The lemma `card_zeros_le_of_maxModulus` assumes `1 ≤ maxModulus f R` in order to compare the
circle-average of `log ‖f‖` with `log (maxModulus f R)` even at points where `f` vanishes on the
circle (since `Real.log 0 = 0`).

For growth applications we want an unconditional bound, so we instead compare with
`log (max 1 (maxModulus f R))`.
-/

theorem card_zeros_le_of_max_one_maxModulus (f : ℂ → ℂ) {R : ℝ} (hR : 0 < R)
    (hf_entire : Differentiable ℂ f) (hf0 : f 0 ≠ 0) :
    (({u : ℂ |
          u ∈ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|)).support ∧ ‖u‖ ≤ R / 2} :
        Set ℂ).ncard : ℝ)
      ≤ (Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖) / Real.log 2 := by
  classical
  -- Setup Jensen on `closedBall 0 R`.
  have hmer : MeromorphicOn f (closedBall (0 : ℂ) |R|) := fun z _ =>
    (hf_entire.analyticAt z).meromorphicAt
  have hCB0 : (0 : ℂ) ∈ closedBall (0 : ℂ) |R| := by
    simp [Metric.mem_closedBall, abs_nonneg R]
  have htrailing : meromorphicTrailingCoeffAt f 0 = f 0 := by
    simpa using (hf_entire.analyticAt 0).meromorphicTrailingCoeffAt_of_ne_zero hf0
  have hdiv0 : MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) 0 = 0 := by
    have horder0 : analyticOrderAt f 0 = 0 :=
      (hf_entire.analyticAt 0).analyticOrderAt_eq_zero.2 hf0
    have hmerOrder0 : meromorphicOrderAt f 0 = 0 := by
      simpa [horder0] using (hf_entire.analyticAt 0).meromorphicOrderAt_eq
    simp [MeromorphicOn.divisor_apply hmer hCB0, hmerOrder0]
  -- Jensen formula at the origin.
  have hjensen :
      Real.circleAverage (Real.log ‖f ·‖) 0 R
        = (∑ᶠ u, MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u * Real.log (R * ‖u‖⁻¹))
          + Real.log ‖f 0‖ := by
    have :=
      MeromorphicOn.circleAverage_log_norm (c := (0 : ℂ)) (R := R) (f := f) (by exact hR.ne') hmer
    simpa [hdiv0, htrailing, norm_sub_rev, add_assoc, add_left_comm, add_comm, sub_eq_add_neg]
      using this
  -- Upper-bound the circle average by `log (max 1 (maxModulus f R))`.
  have hCircleInt : CircleIntegrable (Real.log ‖f ·‖) 0 R := by
    apply MeromorphicOn.circleIntegrable_log_norm
    intro z hz
    have hz' : z ∈ closedBall (0 : ℂ) |R| := Metric.sphere_subset_closedBall hz
    exact hmer z hz'
  have havg_le :
      Real.circleAverage (Real.log ‖f ·‖) 0 R ≤ Real.log (max 1 (maxModulus f R)) := by
    refine
      Real.circleAverage_mono_on_of_le_circle (c := (0 : ℂ)) (R := R)
        (f := fun z => Real.log ‖f z‖) (a := Real.log (max 1 (maxModulus f R))) hCircleInt ?_
    intro z hz
    have hzR : ‖z‖ = R := by simpa [Metric.mem_sphere, dist_eq_norm, abs_of_pos hR] using hz
    have hnorm : ‖f z‖ ≤ maxModulus f R := norm_le_maxModulus_on_circle f hf_entire.continuous hzR
    have hnorm' : ‖f z‖ ≤ max 1 (maxModulus f R) := le_trans hnorm (le_max_right _ _)
    by_cases hfz : f z = 0
    · have hlogM_nonneg : 0 ≤ Real.log (max 1 (maxModulus f R)) :=
        Real.log_nonneg (le_max_left _ _)
      simpa [hfz] using hlogM_nonneg
    · have hpos : 0 < ‖f z‖ := norm_pos_iff.2 hfz
      exact Real.log_le_log hpos hnorm'
  -- Convert Jensen + `havg_le` into an upper bound on the finsum.
  have hsum_le :
      (∑ᶠ u, MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u * Real.log (R * ‖u‖⁻¹))
        ≤ Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖ := by
    have := sub_le_sub_right havg_le (Real.log ‖f 0‖)
    simpa [hjensen, sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using this
  -- Lower-bound the same finsum by `log 2 * (number of zeros with ‖u‖ ≤ R/2)`.
  let D : Function.locallyFinsuppWithin (closedBall (0 : ℂ) |R|) ℤ :=
    MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|)
  have hD_fin : (D.support : Set ℂ).Finite := D.finiteSupport (isCompact_closedBall (0 : ℂ) |R|)
  have hD_nonneg : 0 ≤ D := by
    have hf_an : AnalyticOnNhd ℂ f (closedBall (0 : ℂ) |R|) := by
      intro z _
      exact hf_entire.analyticAt z
    exact hf_an.divisor_nonneg
  let S : Set ℂ := {u : ℂ | u ∈ D.support ∧ ‖u‖ ≤ R / 2}
  have hS_fin : S.Finite := by
    refine hD_fin.subset ?_
    intro u hu
    exact hu.1
  have hlog2_pos : 0 < Real.log 2 := by
    simpa using (Real.log_pos (by norm_num : (1 : ℝ) < 2))
  -- This block is copied from `card_zeros_le_of_maxModulus`, with only the `hsum_le` bound changed.
  have hsum_ge :
      (Real.log 2) * (hS_fin.toFinset.card : ℝ)
        ≤ (∑ᶠ u, D u * Real.log (R * ‖u‖⁻¹)) := by
    -- Expand the finsum as a finite sum over the support.
    have hsupp :
        (Function.support fun u => (D u : ℝ) * Real.log (R * ‖u‖⁻¹)) ⊆ hD_fin.toFinset := by
      intro u hu
      have ht_ne : (D u : ℝ) * Real.log (R * ‖u‖⁻¹) ≠ 0 := (Function.mem_support.1 hu)
      have hDu : D u ≠ 0 := by
        intro hDu0
        apply ht_ne
        simp [hDu0]
      have huD : u ∈ D.support := by
        have : u ∈ Function.support (fun x : ℂ => D x) := (Function.mem_support.2 hDu)
        simpa [Function.locallyFinsuppWithin.support] using this
      exact hD_fin.mem_toFinset.2 huD
    have hsum_eq :
        (∑ᶠ u, D u * Real.log (R * ‖u‖⁻¹))
          = ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      classical
      -- `finsum` over a finite-support function is a finite sum over the support.
      simpa using finsum_eq_sum_of_support_subset
        (f := fun u : ℂ => (D u : ℝ) * Real.log (R * ‖u‖⁻¹))
        (s := hD_fin.toFinset) hsupp
    -- Lower bound each term by `log 2` on `S`.
    have hterm_ge :
        ∀ u ∈ hS_fin.toFinset, (Real.log 2) ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      intro u hu
      have huS : u ∈ S := hS_fin.mem_toFinset.1 hu
      have hu_support : u ∈ D.support := huS.1
      have hDu_ne : D u ≠ 0 := by
        intro hDu0
        exact hu_support (by simp [hDu0])
      have hDu_pos : (0 : ℤ) < D u := by
        have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
        exact lt_of_le_of_ne hDu0 (Ne.symm hDu_ne)
      have hu_ne0 : u ≠ 0 := by
        intro hu0
        have : D 0 = 0 := by simpa [D] using hdiv0
        have : D u = 0 := by simpa [hu0] using this
        exact hDu_ne this
      have hu_le : ‖u‖ ≤ R / 2 := huS.2
      have hu_pos : 0 < ‖u‖ := norm_pos_iff.2 hu_ne0
      have htwo : (2 : ℝ) ≤ R * ‖u‖⁻¹ := by
        have hmul : (2 : ℝ) * ‖u‖ ≤ R := by nlinarith
        have : (2 : ℝ) ≤ R / ‖u‖ := (le_div_iff₀ hu_pos).2 hmul
        simpa [div_eq_mul_inv] using this
      have hlog_ge : Real.log 2 ≤ Real.log (R * ‖u‖⁻¹) :=
        Real.log_le_log (by positivity : (0 : ℝ) < 2) htwo
      have hlog_nonneg : 0 ≤ Real.log (R * ‖u‖⁻¹) := by
        have h1 : (1 : ℝ) ≤ R * ‖u‖⁻¹ := le_trans (by norm_num : (1 : ℝ) ≤ 2) htwo
        exact Real.log_nonneg h1
      have hDu_ge1 : (1 : ℝ) ≤ (D u : ℝ) := by exact_mod_cast hDu_pos
      have hlog_ge' : (Real.log 2 : ℝ) ≤ (1 : ℝ) * Real.log (R * ‖u‖⁻¹) := by
        simpa [one_mul] using hlog_ge
      have := le_trans hlog_ge' (mul_le_mul_of_nonneg_right hDu_ge1 hlog_nonneg)
      simpa [one_mul, mul_assoc] using this
    -- The sum over the whole support dominates `log2 * card S`.
    have hcard_mul :
        (Real.log 2) * (hS_fin.toFinset.card : ℝ)
          ≤ ∑ u ∈ hS_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      have h :=
        mul_card_le_sum_of_forall_le (s := hS_fin.toFinset) (a := Real.log 2)
          (f := fun u => (D u : ℝ) * Real.log (R * ‖u‖⁻¹)) hterm_ge
      simpa [mul_comm] using h
    -- Enlarge from `S` to the full support by monotonicity (all terms are nonnegative).
    have hnonneg : ∀ u ∈ hD_fin.toFinset, 0 ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      intro u hu
      have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
      have hDu0' : (0 : ℝ) ≤ (D u : ℝ) := by exact_mod_cast hDu0
      have hlog0 : 0 ≤ Real.log (R * ‖u‖⁻¹) := by
        have huU : u ∈ closedBall (0 : ℂ) |R| := by
          have : u ∈ D.support := hD_fin.mem_toFinset.1 hu
          exact D.supportWithinDomain this
        have hu_le : ‖u‖ ≤ |R| := by simpa [Metric.mem_closedBall, dist_eq_norm] using huU
        by_cases hu0 : u = 0
        · subst hu0
          simp
        · have hu_pos : 0 < ‖u‖ := norm_pos_iff.2 hu0
          have hmul_ge : (1 : ℝ) ≤ R * ‖u‖⁻¹ := by
            have : (1 : ℝ) ≤ R / ‖u‖ := by
              have hu_le' : ‖u‖ ≤ R := by simpa [abs_of_pos hR] using hu_le
              have : (1 : ℝ) * ‖u‖ ≤ R := by simpa [one_mul] using hu_le'
              exact (le_div_iff₀ hu_pos).2 this
            simpa [div_eq_mul_inv] using this
          exact Real.log_nonneg hmul_ge
      exact mul_nonneg hDu0' hlog0
    have hsub : hS_fin.toFinset ⊆ hD_fin.toFinset := by
      intro u hu
      have : u ∈ S := by simpa [hS_fin.mem_toFinset] using hu
      exact hD_fin.mem_toFinset.2 this.1
    have hsum_le' :
        (∑ u ∈ hS_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹))
          ≤ ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      have hnonneg' :
          ∀ u ∈ hD_fin.toFinset, u ∉ hS_fin.toFinset → 0 ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
        intro u hu _
        exact hnonneg u hu
      exact Finset.sum_le_sum_of_subset_of_nonneg hsub hnonneg'
    have :
        (Real.log 2) * (hS_fin.toFinset.card : ℝ)
          ≤ ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) :=
      le_trans hcard_mul hsum_le'
    simpa [hsum_eq] using this
  -- Finish by dividing by `log 2`.
  have hlog2_ne : Real.log 2 ≠ 0 := ne_of_gt hlog2_pos
  have hcard :
      (hS_fin.toFinset.card : ℝ)
        ≤ (Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖) / Real.log 2 := by
    have h1 :
        (Real.log 2) * (hS_fin.toFinset.card : ℝ)
          ≤ Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖ :=
      le_trans hsum_ge hsum_le
    have := mul_le_mul_of_nonneg_left h1 (le_of_lt (inv_pos.2 hlog2_pos))
    -- rewrite `inv * (log2 * card) = card` and `inv * rhs = rhs / log2`
    simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm, hlog2_ne] using this
  have hcard' :
      ((S.ncard : ℝ)) ≤ (Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖) / Real.log 2 := by
    simpa [Set.ncard_eq_toFinset_card S hS_fin] using hcard
  simpa [S] using hcard'

/-! ### Jensen ⇒ a bound on the sum of multiplicities (divisor weights)

The previous lemmas bound the number of *distinct* zeros in a disk by discarding multiplicities.
For multiplicity-aware Hadamard products we instead need control of
`∑ multiplicity(u)` over zeros `u` in a disk.

We express this as the sum of divisor values on the same set: for analytic functions the divisor
value at `u` is exactly the vanishing multiplicity of `f` at `u`.
-/

/-- Jensen-style bound on the sum of divisor weights in the disk `‖u‖ ≤ R/2`.

This is the multiplicity-aware analogue of `card_zeros_le_of_max_one_maxModulus`.

The LHS is `∑_{u : ‖u‖ ≤ R/2} ord_u(f)` where `ord_u(f)` is the (nonnegative) divisor value.
-/
theorem sum_zeros_multiplicity_le_of_max_one_maxModulus (f : ℂ → ℂ) {R : ℝ} (hR : 0 < R)
    (hf_entire : Differentiable ℂ f) (hf0 : f 0 ≠ 0) :
    (∑ᶠ u : ℂ,
        if ‖u‖ ≤ R / 2 then
          ((MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u : ℤ) : ℝ)
        else 0)
      ≤ (Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖) / Real.log 2 := by
  classical
  -- Setup Jensen on `closedBall 0 R`.
  have hmer : MeromorphicOn f (closedBall (0 : ℂ) |R|) := fun z _ =>
    (hf_entire.analyticAt z).meromorphicAt
  have hCB0 : (0 : ℂ) ∈ closedBall (0 : ℂ) |R| := by
    simp [Metric.mem_closedBall, abs_nonneg R]
  have htrailing : meromorphicTrailingCoeffAt f 0 = f 0 := by
    simpa using (hf_entire.analyticAt 0).meromorphicTrailingCoeffAt_of_ne_zero hf0
  have hdiv0 : MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) 0 = 0 := by
    have horder0 : analyticOrderAt f 0 = 0 :=
      (hf_entire.analyticAt 0).analyticOrderAt_eq_zero.2 hf0
    have hmerOrder0 : meromorphicOrderAt f 0 = 0 := by
      simpa [horder0] using (hf_entire.analyticAt 0).meromorphicOrderAt_eq
    simp [MeromorphicOn.divisor_apply hmer hCB0, hmerOrder0]
  -- Jensen formula at the origin.
  have hjensen :
      Real.circleAverage (Real.log ‖f ·‖) 0 R =
        (∑ᶠ u, MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u * Real.log (R * ‖u‖⁻¹)) +
          Real.log ‖f 0‖ := by
    have :=
      MeromorphicOn.circleAverage_log_norm (c := (0 : ℂ)) (R := R) (f := f) (by exact hR.ne') hmer
    simpa [hdiv0, htrailing, norm_sub_rev, add_assoc, add_left_comm, add_comm, sub_eq_add_neg]
      using this
  -- Upper-bound the circle average by `log (max 1 (maxModulus f R))`.
  have hCircleInt : CircleIntegrable (Real.log ‖f ·‖) 0 R := by
    apply MeromorphicOn.circleIntegrable_log_norm
    intro z hz
    have hz' : z ∈ closedBall (0 : ℂ) |R| := Metric.sphere_subset_closedBall hz
    exact hmer z hz'
  have havg_le :
      Real.circleAverage (Real.log ‖f ·‖) 0 R ≤ Real.log (max 1 (maxModulus f R)) := by
    refine
      Real.circleAverage_mono_on_of_le_circle (c := (0 : ℂ)) (R := R)
        (f := fun z => Real.log ‖f z‖) (a := Real.log (max 1 (maxModulus f R))) hCircleInt ?_
    intro z hz
    have hzR : ‖z‖ = R := by simpa [Metric.mem_sphere, dist_eq_norm, abs_of_pos hR] using hz
    have hnorm : ‖f z‖ ≤ maxModulus f R := norm_le_maxModulus_on_circle f hf_entire.continuous hzR
    have hnorm' : ‖f z‖ ≤ max 1 (maxModulus f R) := le_trans hnorm (le_max_right _ _)
    by_cases hfz : f z = 0
    · have hlogM_nonneg : 0 ≤ Real.log (max 1 (maxModulus f R)) :=
        Real.log_nonneg (le_max_left _ _)
      simpa [hfz] using hlogM_nonneg
    · have hpos : 0 < ‖f z‖ := norm_pos_iff.2 hfz
      exact Real.log_le_log hpos hnorm'
  -- Convert Jensen + `havg_le` into an upper bound on the finsum.
  have hsum_le :
      (∑ᶠ u, MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|) u * Real.log (R * ‖u‖⁻¹))
        ≤ Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖ := by
    have := sub_le_sub_right havg_le (Real.log ‖f 0‖)
    simpa [hjensen, sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using this
  -- Lower-bound the same finsum by `log 2 * (sum of divisor weights in ‖u‖ ≤ R/2)`.
  let D : Function.locallyFinsuppWithin (closedBall (0 : ℂ) |R|) ℤ :=
    MeromorphicOn.divisor f (closedBall (0 : ℂ) |R|)
  have hD_fin : (D.support : Set ℂ).Finite :=
    D.finiteSupport (isCompact_closedBall (0 : ℂ) |R|)
  have hD_nonneg : 0 ≤ D := by
    have hf_an : AnalyticOnNhd ℂ f (closedBall (0 : ℂ) |R|) := by
      intro z _
      exact hf_entire.analyticAt z
    exact hf_an.divisor_nonneg
  let S : Set ℂ := {u : ℂ | u ∈ D.support ∧ ‖u‖ ≤ R / 2}
  have hS_fin : S.Finite := by
    refine hD_fin.subset ?_
    intro u hu
    exact hu.1
  have hlog2_pos : 0 < Real.log 2 := by
    simpa using (Real.log_pos (by norm_num : (1 : ℝ) < 2))
  have hlog2_ne : Real.log 2 ≠ 0 := ne_of_gt hlog2_pos
  have hsum_ge :
      (Real.log 2) * (∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ))
        ≤ (∑ᶠ u, D u * Real.log (R * ‖u‖⁻¹)) := by
    -- Expand the finsum as a finite sum over the support.
    have hsupp :
        (Function.support fun u => (D u : ℝ) * Real.log (R * ‖u‖⁻¹)) ⊆ hD_fin.toFinset := by
      intro u hu
      have ht_ne : (D u : ℝ) * Real.log (R * ‖u‖⁻¹) ≠ 0 := (Function.mem_support.1 hu)
      have hDu : D u ≠ 0 := by
        intro hDu0
        apply ht_ne
        simp [hDu0]
      have huD : u ∈ D.support := by
        have : u ∈ Function.support (fun x : ℂ => D x) := (Function.mem_support.2 hDu)
        simpa [Function.locallyFinsuppWithin.support] using this
      exact hD_fin.mem_toFinset.2 huD
    have hsum_eq :
        (∑ᶠ u, D u * Real.log (R * ‖u‖⁻¹)) =
          ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      classical
      simpa using finsum_eq_sum_of_support_subset
        (f := fun u : ℂ => (D u : ℝ) * Real.log (R * ‖u‖⁻¹))
        (s := hD_fin.toFinset) hsupp
    -- For `u ∈ S`, we have `log 2 ≤ log (R/‖u‖)`.
    have hlog_ge :
        ∀ u, u ∈ hS_fin.toFinset → Real.log 2 ≤ Real.log (R * ‖u‖⁻¹) := by
      intro u hu
      have huS : u ∈ S := hS_fin.mem_toFinset.1 hu
      have hu_ne0 : u ≠ 0 := by
        intro hu0
        have : D 0 = 0 := by simpa [D] using hdiv0
        have : D u = 0 := by simpa [hu0] using this
        have huD : u ∈ D.support := huS.1
        have huD' : u ∈ Function.support (fun x : ℂ => D x) := by
          simpa [Function.locallyFinsuppWithin.support] using huD
        exact (Function.mem_support.1 huD') this
      have hu_le : ‖u‖ ≤ R / 2 := huS.2
      have hu_pos : 0 < ‖u‖ := norm_pos_iff.2 hu_ne0
      have htwo : (2 : ℝ) ≤ R * ‖u‖⁻¹ := by
        have hmul : (2 : ℝ) * ‖u‖ ≤ R := by nlinarith
        have : (2 : ℝ) ≤ R / ‖u‖ := (le_div_iff₀ hu_pos).2 hmul
        simpa [div_eq_mul_inv] using this
      exact Real.log_le_log (by positivity : (0 : ℝ) < 2) htwo
    -- Now sum the pointwise inequality `log2 * D u ≤ D u * log(...)` over `S`.
    have hS_term :
        (Real.log 2) * (∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ))
          ≤ ∑ u ∈ hS_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      -- Rewrite the LHS as a sum.
      have hmul_sum :
          (Real.log 2) * (∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ)) =
            ∑ u ∈ hS_fin.toFinset, (Real.log 2) * ((D u : ℤ) : ℝ) := by
        simp [Finset.mul_sum]
      rw [hmul_sum]
      refine Finset.sum_le_sum ?_
      intro u hu
      have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
      have hDu0' : (0 : ℝ) ≤ (D u : ℝ) := by exact_mod_cast hDu0
      have hlog_nonneg : 0 ≤ Real.log (R * ‖u‖⁻¹) :=
        le_trans (le_of_lt hlog2_pos) (hlog_ge u hu)
      have hle : (Real.log 2) ≤ Real.log (R * ‖u‖⁻¹) := hlog_ge u hu
      -- Multiply by the nonnegative weight `(D u : ℝ)`.
      have := mul_le_mul_of_nonneg_left hle hDu0'
      -- Coerce `(D u : ℤ)` to `ℝ` consistently.
      simpa [mul_assoc, mul_left_comm, mul_comm] using this
    -- Enlarge from `S` to the full support finset (all terms are nonnegative).
    have hnonneg : ∀ u ∈ hD_fin.toFinset, 0 ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      intro u hu
      have hDu0 : (0 : ℤ) ≤ D u := hD_nonneg u
      have hDu0' : (0 : ℝ) ≤ (D u : ℝ) := by exact_mod_cast hDu0
      have hlog0 : 0 ≤ Real.log (R * ‖u‖⁻¹) := by
        -- `u` is in the support of `D`, hence `u ∈ closedBall 0 R`, so `‖u‖ ≤ R`.
        have huU : u ∈ closedBall (0 : ℂ) |R| := by
          have : u ∈ D.support := hD_fin.mem_toFinset.1 hu
          exact D.supportWithinDomain this
        have hu_le : ‖u‖ ≤ |R| := by simpa [Metric.mem_closedBall, dist_eq_norm] using huU
        by_cases hu0 : u = 0
        · subst hu0
          simp
        · have hu_pos : 0 < ‖u‖ := norm_pos_iff.2 hu0
          have hmul_ge : (1 : ℝ) ≤ R * ‖u‖⁻¹ := by
            have : (1 : ℝ) ≤ R / ‖u‖ := by
              have hu_le' : ‖u‖ ≤ R := by simpa [abs_of_pos hR] using hu_le
              have : (1 : ℝ) * ‖u‖ ≤ R := by simpa [one_mul] using hu_le'
              exact (le_div_iff₀ hu_pos).2 this
            simpa [div_eq_mul_inv] using this
          exact Real.log_nonneg hmul_ge
      exact mul_nonneg hDu0' hlog0
    have hsub : hS_fin.toFinset ⊆ hD_fin.toFinset := by
      intro u hu
      have : u ∈ S := by simpa [hS_fin.mem_toFinset] using hu
      exact hD_fin.mem_toFinset.2 this.1
    have hsum_le' :
        (∑ u ∈ hS_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹))
          ≤ ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
      have hnonneg' :
          ∀ u ∈ hD_fin.toFinset, u ∉ hS_fin.toFinset → 0 ≤ (D u : ℝ) * Real.log (R * ‖u‖⁻¹) := by
        intro u hu _
        exact hnonneg u hu
      exact Finset.sum_le_sum_of_subset_of_nonneg hsub hnonneg'
    have :
        (Real.log 2) * (∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ))
          ≤ ∑ u ∈ hD_fin.toFinset, (D u : ℝ) * Real.log (R * ‖u‖⁻¹) :=
      le_trans hS_term hsum_le'
    simpa [hsum_eq] using this
  -- Divide by `log 2`.
  have hweight :
      (∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ))
        ≤ (Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖) / Real.log 2 := by
    have h1 :
        (Real.log 2) * (∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ))
          ≤ Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖ :=
      le_trans hsum_ge hsum_le
    have := mul_le_mul_of_nonneg_left h1 (le_of_lt (inv_pos.2 hlog2_pos))
    simpa [div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm, hlog2_ne] using this
  -- Unfold the set definition in the statement.
  -- Rewrite the LHS as a `finsum` cutoff.
  have h_finsum :
      (∑ᶠ u : ℂ, if ‖u‖ ≤ R / 2 then ((D u : ℤ) : ℝ) else 0) =
        ∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ) := by
    -- The support is contained in `S`.
    have hsupp :
        Function.support (fun u : ℂ => if ‖u‖ ≤ R / 2 then ((D u : ℤ) : ℝ) else 0)
          ⊆ hS_fin.toFinset := by
      intro u hu
      have hu_ne : (if ‖u‖ ≤ R / 2 then ((D u : ℤ) : ℝ) else 0) ≠ 0 :=
        Function.mem_support.1 hu
      have hu_le : ‖u‖ ≤ R / 2 := by
        by_contra hle
        apply hu_ne
        simp [hle]
      have hDu : D u ≠ 0 := by
        intro hDu0
        apply hu_ne
        simp [hu_le, hDu0]
      have huS : u ∈ S := by
        refine ⟨?_, hu_le⟩
        have : u ∈ Function.support (fun x : ℂ => D x) := Function.mem_support.2 hDu
        simpa [Function.locallyFinsuppWithin.support] using this
      exact hS_fin.mem_toFinset.2 huS
    have :=
      (finsum_eq_sum_of_support_subset
        (f := fun u : ℂ => if ‖u‖ ≤ R / 2 then ((D u : ℤ) : ℝ) else 0)
        (s := hS_fin.toFinset) hsupp)
    -- Now simplify the `if` on the RHS using membership in `S`.
    have hsum_if :
        (∑ u ∈ hS_fin.toFinset, if ‖u‖ ≤ R / 2 then ((D u : ℤ) : ℝ) else 0) =
          ∑ u ∈ hS_fin.toFinset, ((D u : ℤ) : ℝ) := by
      refine Finset.sum_congr rfl ?_
      intro u hu
      have huS : u ∈ S := hS_fin.mem_toFinset.1 hu
      have hu_le : ‖u‖ ≤ R / 2 := huS.2
      simp [hu_le]
    simpa [hsum_if] using this
  -- Now finish by rewriting both sides to the theorem statement.
  have hweight' :
      (∑ᶠ u : ℂ, if ‖u‖ ≤ R / 2 then ((D u : ℤ) : ℝ) else 0)
        ≤ (Real.log (max 1 (maxModulus f R)) - Real.log ‖f 0‖) / Real.log 2 := by
    simpa [h_finsum] using hweight
  simpa [D] using hweight'

end ZeroCounting

end Hadamard
~~~~~~

## Hadamard.ZeroSet

Path: `source/Hadamard/ZeroSet.lean`

Original source lines: 1–40

Full file SHA256: `bd0437c14bc7949e7228b357407e832e7a7aa156d51aa6ca8d47ad201040933e`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/ZeroSet.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
/-
Zero sets and canonical products used in the Hadamard factorization development.

This is factored out so downstream files can talk about “a chosen enumeration of zeros”
without importing the (WIP) factorization proof in `FullTheorem.lean`.
-/

import Hadamard.Basic

/-!
# Zero sets of entire functions

The `ZeroSet` structure packaging the zeros of an entire function together with the data the
Hadamard factorization needs, and the associated canonical product.
-/

open scoped BigOperators

namespace Hadamard

/-- A choice of zeros for a function `f`, with explicit enumeration. -/
structure ZeroSet (f : ℂ → ℂ) where
  /-- Index type for the chosen zeros. -/
  Zero : Type
  /-- The underlying complex value of a zero. -/
  z : Zero → ℂ
  /-- Each indexed value is a genuine zero of `f`. -/
  isZero : ∀ ρ : Zero, f (z ρ) = 0

/-- The canonical genus‑1 Weierstrass product over a countable zero set. -/
noncomputable def canonicalProductZeroSet
    {f : ℂ → ℂ} (Z : ZeroSet f) [Countable Z.Zero] (s : ℂ) : ℂ :=
  ∏' ρ : Z.Zero, weierstrass_E 1 (s / Z.z ρ)

end Hadamard
~~~~~~

## Lc.LiCriterion.XiGrowth

Path: `source/Lc/LiCriterion/XiGrowth.lean`

Original source lines: 1–628

Full file SHA256: `329c7fcbdc3e563ce9932d7cdbd4eb4434a314dbcf02310549c1782fb9cbbb81`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Lc/LiCriterion/XiGrowth.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Lc.LiCriterion.Basic
import Hadamard.OrderOne.OrderFromMaxModulus

/-!
# The order of the completed zeta function `ξ`

This file proves the two analytic facts that the Li-criterion biconditional
(`LiCriterion.biconditional_rh_li_of_hadamard_order_one`) still needs:

* `LiCriterion.riemannXi_hasFiniteOrder` : `ξ` is an entire function of finite order;
* `LiCriterion.riemannXi_order_le_one`   : the order of `ξ` is at most `1`.

## The route

The classical route bounds `ξ = ½ s (s-1) π^{-s/2} Γ(s/2) ζ(s)` factor by factor, and then owes a
polynomial bound for `ζ` in the critical strip -- which is not in Mathlib, and is the hard part.

This file avoids `ζ` entirely.  Mathlib builds `completedRiemannZeta₀` as a Mellin transform:

  `completedRiemannZeta₀ s = (mellin f_modif (s/2)) / 2`,

where `f_modif` is the modified theta kernel of the functional-equation pair
`HurwitzZeta.hurwitzEvenFEPair 0` -- explicitly `Θ(x) - 1` on `(1, ∞)` and `Θ(x) - x^{-1/2}` on
`(0, 1)`.  The kernel decays exponentially at `∞` (`isBigO_atTop_evenKernel_sub`), and the kernel
functional equation transports that decay to `0`.  Bounding the Mellin integral against those two
exponentials gives `‖Λ₀(w)‖ ≤ exp (O (‖w‖ log ‖w‖))` for *every* `w`, with no case split on the
critical strip, no Stirling expansion, and no growth bound for `ζ`.

The elementary majorant `u ^ A * exp (-p u) ≤ exp (A log (A/p))` (`rpow_mul_exp_neg_le`) does the
work that Stirling would otherwise do; it is just `log t ≤ t - 1`.
-/

namespace LiCriterion.XiGrowth

open Complex Real Set Filter MeasureTheory HurwitzZeta
open scoped Topology


/-! ## Part A: an elementary majorant -/

/-- The elementary bound `u ^ A * exp (-(p * u)) ≤ exp (A * log (A / p))`, valid for all
`u > 0`, `A ≥ 0`, `p > 0`.  This replaces any appeal to Stirling: it is just `log t ≤ t - 1`. -/
lemma rpow_mul_exp_neg_le {u A p : ℝ} (hu : 0 < u) (hA : 0 ≤ A) (hp : 0 < p) :
    u ^ A * rexp (-(p * u)) ≤ rexp (A * Real.log (A / p)) := by
  rcases eq_or_lt_of_le hA with rfl | hA'
  · have : rexp (-(p * u)) ≤ 1 := Real.exp_le_one_iff.2 (by nlinarith : -(p * u) ≤ 0)
    simpa using this
  -- `A > 0`: take logarithms.
  have hAp : 0 < A / p := div_pos hA' hp
  have hkey : A * Real.log u - p * u ≤ A * Real.log (A / p) := by
    -- `log (u * p / A) ≤ u * p / A - 1`
    have h := Real.log_le_sub_one_of_pos (x := u * p / A) (by positivity)
    have hlog : Real.log (u * p / A) = Real.log u - Real.log (A / p) := by
      rw [Real.log_div (by positivity) (ne_of_gt hA'), Real.log_div (ne_of_gt hA') (ne_of_gt hp),
        Real.log_mul (ne_of_gt hu) (ne_of_gt hp)]
      ring
    rw [hlog] at h
    have hmul := mul_le_mul_of_nonneg_left h hA
    have : A * (u * p / A - 1) = p * u - A := by field_simp
    nlinarith [hA'.le]
  calc u ^ A * rexp (-(p * u))
      = rexp (A * Real.log u) * rexp (-(p * u)) := by
        rw [Real.rpow_def_of_pos hu]; ring_nf
    _ = rexp (A * Real.log u - p * u) := by rw [← Real.exp_add]; ring_nf
    _ ≤ rexp (A * Real.log (A / p)) := Real.exp_le_exp.2 hkey

/-! ## Part B: exponential decay of the theta kernel -/

/-- The even kernel at `a = 0` decays exponentially: there are `C, p > 0` with
`|Θ(x) - 1| ≤ C exp (-p x)` for every `x ≥ 1`.  Mathlib supplies the asymptotic; the content
here is upgrading it from `atTop` to all of `[1, ∞)` by compactness. -/
lemma exists_kernel_bound :
    ∃ C p : ℝ, 0 < C ∧ 0 < p ∧ ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x)) := by
  obtain ⟨p, hp, hO⟩ := isBigO_atTop_evenKernel_sub 0
  obtain ⟨c, hc⟩ := hO.bound
  obtain ⟨R, hR⟩ := eventually_atTop.1 hc
  set R' : ℝ := max R 1 with hR'
  have hR'1 : 1 ≤ R' := le_max_right _ _
  -- bound on the compact piece `[1, R']`
  have hcompact : IsCompact (Icc (1:ℝ) R') := isCompact_Icc
  have hcont : ContinuousOn (fun x : ℝ => evenKernel 0 x - 1) (Icc (1:ℝ) R') := by
    refine ContinuousOn.sub ?_ continuousOn_const
    exact (continuousOn_evenKernel 0).mono (fun x hx => lt_of_lt_of_le zero_lt_one hx.1)
  obtain ⟨M, hM⟩ := hcompact.exists_bound_of_continuousOn hcont
  refine ⟨max (max c 0) (max (M * rexp (p * R')) 0) + 1, p, by positivity, hp, ?_⟩
  intro x hx1
  set C := max (max c 0) (max (M * rexp (p * R')) 0) + 1 with hC
  have hxpos : 0 < x := lt_of_lt_of_le zero_lt_one hx1
  rcases le_or_gt x R' with hle | hgt
  · -- compact range: use the sup bound, paying `exp (p R')`
    have h1 : |evenKernel 0 x - 1| ≤ M := by simpa using hM x ⟨hx1, hle⟩
    have h2 : M * rexp (p * R') * rexp (-(p * x)) ≤ C * rexp (-(p * x)) := by
      have : M * rexp (p * R') ≤ C := by
        have := le_max_left (M * rexp (p * R')) 0
        have h' := le_max_right (max c 0) (max (M * rexp (p * R')) 0)
        simp only [hC]; linarith [le_trans this h']
      exact mul_le_mul_of_nonneg_right this (le_of_lt (Real.exp_pos _))
    refine le_trans (le_trans h1 ?_) h2
    have hexp : (1:ℝ) ≤ rexp (p * R') * rexp (-(p * x)) := by
      rw [← Real.exp_add]
      exact Real.one_le_exp (by nlinarith)
    nlinarith [le_trans (abs_nonneg _) h1, Real.exp_pos (p * R'), Real.exp_pos (-(p*x))]
  · -- tail: use the `atTop` bound
    have hxR : R ≤ x := le_trans (le_max_left R 1) (le_of_lt hgt)
    have h1 : ‖evenKernel 0 x - 1‖ ≤ c * ‖rexp (-p * x)‖ := by simpa using hR x hxR
    have h2 : c ≤ C := by
      have := le_max_left c 0
      have h' := le_max_left (max c 0) (max (M * rexp (p * R')) 0)
      simp only [hC]; linarith [le_trans this h']
    have hnorm : ‖rexp (-p * x)‖ = rexp (-(p * x)) := by
      rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]; ring_nf
    rw [Real.norm_eq_abs, hnorm] at h1
    exact le_trans h1 (mul_le_mul_of_nonneg_right h2 (le_of_lt (Real.exp_pos _)))

/-! ## Part C: the modified kernel `f_modif` of the Riemann FE-pair -/

/-- The Riemann functional-equation pair, whose `Λ₀` is the completed zeta. -/
noncomputable abbrev PR : WeakFEPair ℂ := hurwitzEvenFEPair 0

lemma completedRiemannZeta₀_eq_mellin (s : ℂ) :
    completedRiemannZeta₀ s = (mellin PR.f_modif (s / 2)) / 2 := rfl

lemma f_modif_eq_of_one_lt {x : ℝ} (hx : 1 < x) :
    PR.f_modif x = (evenKernel 0 x : ℂ) - 1 := by
  simp [WeakFEPair.f_modif, hurwitzEvenFEPair, hx, not_lt.2 hx.le, Set.mem_Ioi, Set.mem_Ioo]

lemma f_modif_eq_of_lt_one {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    PR.f_modif x = (evenKernel 0 x : ℂ) - ((x ^ (-(1/2) : ℝ) : ℝ) : ℂ) := by
  have hnot : ¬ (1 < x) := not_lt.2 hx1.le
  simp [WeakFEPair.f_modif, hurwitzEvenFEPair, hnot, hx0, hx1, Set.mem_Ioi, Set.mem_Ioo]

/-- On `(1, ∞)` the modified kernel inherits the exponential decay of the theta kernel. -/
lemma norm_f_modif_of_one_lt {C p : ℝ}
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x)))
    {x : ℝ} (hx : 1 < x) : ‖PR.f_modif x‖ ≤ C * rexp (-(p * x)) := by
  rw [f_modif_eq_of_one_lt hx]
  have : ‖((evenKernel 0 x : ℂ) - 1)‖ = |evenKernel 0 x - 1| := by
    rw [show ((evenKernel 0 x : ℂ) - 1) = ((evenKernel 0 x - 1 : ℝ) : ℂ) by push_cast; ring]
    exact Complex.norm_real _
  rw [this]
  exact hker x hx.le

/-- On `(0, 1)` the functional equation of the theta kernel converts the decay at `∞` into
decay at `0`: `‖f_modif x‖ ≤ C x^(-1/2) exp (-p/x)`. -/
lemma norm_f_modif_of_lt_one {C p : ℝ}
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x)))
    {x : ℝ} (hx0 : 0 < x) (hx1 : x < 1) :
    ‖PR.f_modif x‖ ≤ x ^ (-(1/2) : ℝ) * (C * rexp (-(p / x))) := by
  have hinv : 1 ≤ 1 / x := by rw [le_div_iff₀ hx0]; linarith
  -- the functional equation, at `a = 0`
  have hFE : evenKernel 0 x = x ^ (-(1/2) : ℝ) * evenKernel 0 (1 / x) := by
    rw [evenKernel_functional_equation 0 x, evenKernel_eq_cosKernel_of_zero,
      Real.rpow_neg hx0.le]
    ring
  have hval : PR.f_modif x = ((x ^ (-(1/2) : ℝ) * (evenKernel 0 (1 / x) - 1) : ℝ) : ℂ) := by
    rw [f_modif_eq_of_lt_one hx0 hx1, hFE]
    push_cast
    ring
  rw [hval, Complex.norm_real, Real.norm_eq_abs, abs_mul,
    abs_of_nonneg (Real.rpow_nonneg hx0.le _)]
  have hb := hker (1 / x) hinv
  have hpx : p * (1 / x) = p / x := by ring
  rw [hpx] at hb
  exact mul_le_mul_of_nonneg_left hb (Real.rpow_nonneg hx0.le _)

/-! ## Part D: the Mellin integral estimate -/

/-- Pointwise bound for the Mellin integrand on `(0, 1]`. -/
lemma integrand_le_of_mem_Ioc {C p : ℝ} (hC : 0 < C) (hp : 0 < p)
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x)))
    (w : ℂ) {x : ℝ} (hx : x ∈ Ioc (0:ℝ) 1) :
    ‖(x : ℂ) ^ (w - 1) • PR.f_modif x‖ ≤
      C * rexp (max (3/2 - w.re) 0 * Real.log (max (3/2 - w.re) 0 / p)) := by
  obtain ⟨hx0, hx1⟩ := hx
  set A := max (3/2 - w.re) 0 with hAdef
  have hA0 : 0 ≤ A := le_max_right _ _
  rcases eq_or_lt_of_le hx1 with rfl | hlt
  · -- at `x = 1` the modified kernel vanishes
    have h1 : PR.f_modif 1 = 0 := by
      simp [WeakFEPair.f_modif, Set.mem_Ioi, Set.mem_Ioo]
    simp only [h1, smul_zero, norm_zero]
    positivity
  · -- `0 < x < 1`
    have hnorm : ‖(x : ℂ) ^ (w - 1) • PR.f_modif x‖ = x ^ (w.re - 1) * ‖PR.f_modif x‖ := by
      rw [norm_smul, Complex.norm_cpow_eq_rpow_re_of_pos hx0]
      simp
    rw [hnorm]
    have hfb := norm_f_modif_of_lt_one hker hx0 hlt
    have hstep : x ^ (w.re - 1) * ‖PR.f_modif x‖
        ≤ x ^ (w.re - 1) * (x ^ (-(1/2) : ℝ) * (C * rexp (-(p / x)))) :=
      mul_le_mul_of_nonneg_left hfb (Real.rpow_nonneg hx0.le _)
    refine le_trans hstep ?_
    -- collect the powers of `x`
    have hxx : x ^ (w.re - 1) * x ^ (-(1/2) : ℝ) = x ^ (w.re - 3/2) := by
      rw [← Real.rpow_add hx0]; ring_nf
    have hcollect : x ^ (w.re - 1) * (x ^ (-(1/2) : ℝ) * (C * rexp (-(p / x))))
        = C * (x ^ (w.re - 3/2) * rexp (-(p / x))) := by
      rw [← hxx]; ring
    rw [hcollect]
    refine mul_le_mul_of_nonneg_left ?_ hC.le
    -- `x ^ (σ - 3/2) ≤ x ^ (-A)` because `x ≤ 1` and `-A ≤ σ - 3/2`
    have hmono : x ^ (w.re - 3/2) ≤ x ^ (-A) := by
      apply Real.rpow_le_rpow_of_exponent_ge hx0 hlt.le
      have : -A ≤ w.re - 3/2 := by
        simp only [hAdef, neg_le, le_max_iff]
        left; linarith
      linarith
    refine le_trans (mul_le_mul_of_nonneg_right hmono (Real.exp_pos _).le) ?_
    -- now apply the elementary majorant with `u = 1/x`
    have hu : (0:ℝ) < 1 / x := by positivity
    have hkey := rpow_mul_exp_neg_le (u := 1/x) (A := A) (p := p) hu hA0 hp
    have h1 : x ^ (-A) = (1/x) ^ A := by
      rw [one_div, Real.inv_rpow hx0.le, Real.rpow_neg hx0.le]
    have h2 : -(p / x) = -(p * (1/x)) := by ring
    rw [h1, h2]
    exact hkey

/-- Pointwise bound for the Mellin integrand on `(1, ∞)`. -/
lemma integrand_le_of_mem_Ioi {C p : ℝ} (hC : 0 < C) (hp : 0 < p)
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x)))
    (w : ℂ) {x : ℝ} (hx : x ∈ Ioi (1:ℝ)) :
    ‖(x : ℂ) ^ (w - 1) • PR.f_modif x‖ ≤
      C * rexp (max (w.re - 1) 0 * Real.log (max (w.re - 1) 0 / (p/2))) * rexp (-(p/2 * x)) := by
  have hx1 : (1:ℝ) < x := hx
  have hx0 : (0:ℝ) < x := lt_trans zero_lt_one hx1
  set B := max (w.re - 1) 0 with hBdef
  have hB0 : 0 ≤ B := le_max_right _ _
  have hnorm : ‖(x : ℂ) ^ (w - 1) • PR.f_modif x‖ = x ^ (w.re - 1) * ‖PR.f_modif x‖ := by
    rw [norm_smul, Complex.norm_cpow_eq_rpow_re_of_pos hx0]
    simp
  rw [hnorm]
  have hfb := norm_f_modif_of_one_lt hker hx1
  have hstep : x ^ (w.re - 1) * ‖PR.f_modif x‖ ≤ x ^ (w.re - 1) * (C * rexp (-(p * x))) :=
    mul_le_mul_of_nonneg_left hfb (Real.rpow_nonneg hx0.le _)
  refine le_trans hstep ?_
  -- `x ^ (σ - 1) ≤ x ^ B` because `x ≥ 1`
  have hmono : x ^ (w.re - 1) ≤ x ^ B :=
    Real.rpow_le_rpow_of_exponent_le hx1.le (le_max_left _ _)
  have hstep2 : x ^ (w.re - 1) * (C * rexp (-(p * x))) ≤ x ^ B * (C * rexp (-(p * x))) := by
    have : (0:ℝ) ≤ C * rexp (-(p * x)) := by positivity
    exact mul_le_mul_of_nonneg_right hmono this
  refine le_trans hstep2 ?_
  -- split the exponential and apply the elementary majorant at rate `p/2`
  have hsplit : rexp (-(p * x)) = rexp (-(p/2 * x)) * rexp (-(p/2 * x)) := by
    rw [← Real.exp_add]; ring_nf
  rw [hsplit]
  have hkey := rpow_mul_exp_neg_le (u := x) (A := B) (p := p/2) hx0 hB0 (by positivity)
  calc x ^ B * (C * (rexp (-(p/2 * x)) * rexp (-(p/2 * x))))
      = C * (x ^ B * rexp (-(p/2 * x))) * rexp (-(p/2 * x)) := by ring
    _ ≤ C * rexp (B * Real.log (B / (p/2))) * rexp (-(p/2 * x)) := by
        have hxB : x ^ B * rexp (-(p/2 * x)) ≤ rexp (B * Real.log (B / (p/2))) := by
          have : -(p / 2 * x) = -(p/2 * x) := rfl
          exact hkey
        have hnn : (0:ℝ) ≤ rexp (-(p/2 * x)) := (Real.exp_pos _).le
        exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hxB hC.le) hnn

/-- **The Mellin bound.**  The Mellin transform of the modified theta kernel is bounded by an
explicit expression in `Re w` alone.  No growth bound for `ζ` enters: the decay of the theta
kernel at `∞`, transported to `0` by the functional equation, is the whole input. -/
lemma norm_mellin_f_modif_le {C p : ℝ} (hC : 0 < C) (hp : 0 < p)
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x))) (w : ℂ) :
    ‖mellin PR.f_modif w‖ ≤
      C * rexp (max (3/2 - w.re) 0 * Real.log (max (3/2 - w.re) 0 / p))
      + C * rexp (max (w.re - 1) 0 * Real.log (max (w.re - 1) 0 / (p/2))) * (2/p) := by
  have hp2 : (0:ℝ) < p/2 := by positivity
  set K₁ := C * rexp (max (3/2 - w.re) 0 * Real.log (max (3/2 - w.re) 0 / p)) with hK1
  set K₂ := C * rexp (max (w.re - 1) 0 * Real.log (max (w.re - 1) 0 / (p/2))) with hK2
  have hK1nn : 0 ≤ K₁ := by rw [hK1]; positivity
  have hK2nn : 0 ≤ K₂ := by rw [hK2]; positivity
  -- integrability of the Mellin integrand, for free from the FE-pair machinery
  have hint : IntegrableOn (fun t : ℝ => (t:ℂ) ^ (w - 1) • PR.f_modif t) (Ioi 0) :=
    (PR.isStrongFEPair_toStrongFEPair.hasMellin w).1
  set F : ℝ → ℝ := fun x => ‖(x:ℂ) ^ (w - 1) • PR.f_modif x‖ with hFdef
  have hFint : IntegrableOn F (Ioi 0) := hint.norm
  have hFint1 : IntegrableOn F (Ioc 0 1) := hFint.mono_set Ioc_subset_Ioi_self
  have hFint2 : IntegrableOn F (Ioi 1) := hFint.mono_set (Ioi_subset_Ioi zero_le_one)
  -- ‖∫‖ ≤ ∫ ‖·‖, then split at 1
  have hstep1 : ‖mellin PR.f_modif w‖ ≤ ∫ x in Ioi (0:ℝ), F x :=
    norm_integral_le_integral_norm _
  have hdisj : Disjoint (Ioc (0:ℝ) 1) (Ioi (1:ℝ)) := by
    rw [Set.disjoint_left]
    intro a ha ha'
    exact absurd (mem_Ioi.1 ha') (not_lt.2 ha.2)
  have hsplit : ∫ x in Ioi (0:ℝ), F x = (∫ x in Ioc (0:ℝ) 1, F x) + ∫ x in Ioi (1:ℝ), F x := by
    rw [← setIntegral_union hdisj measurableSet_Ioi hFint1 hFint2,
      Set.Ioc_union_Ioi_eq_Ioi zero_le_one]
  -- the piece over `(0, 1]`
  have hb1 : (∫ x in Ioc (0:ℝ) 1, F x) ≤ K₁ := by
    have hconst : IntegrableOn (fun _ : ℝ => K₁) (Ioc (0:ℝ) 1) :=
      integrableOn_const (hs := measure_Ioc_lt_top.ne)
    have hmono : (∫ x in Ioc (0:ℝ) 1, F x) ≤ ∫ _x in Ioc (0:ℝ) 1, K₁ :=
      setIntegral_mono_on hFint1 hconst measurableSet_Ioc
        (fun x hx => integrand_le_of_mem_Ioc hC hp hker w hx)
    simpa using hmono
  -- the piece over `(1, ∞)`
  have hb2 : (∫ x in Ioi (1:ℝ), F x) ≤ K₂ * (2/p) := by
    have hexpint : IntegrableOn (fun x : ℝ => rexp (-(p/2 * x))) (Ioi 1) := by
      have := (integrableOn_Ioi_comp_mul_left_iff (fun u : ℝ => rexp (-u)) 1 hp2).2
        (integrableOn_exp_neg_Ioi (p/2 * 1))
      simpa using this
    have hgint : IntegrableOn (fun x : ℝ => K₂ * rexp (-(p/2 * x))) (Ioi 1) :=
      hexpint.const_mul K₂
    have hmono : (∫ x in Ioi (1:ℝ), F x) ≤ ∫ x in Ioi (1:ℝ), K₂ * rexp (-(p/2 * x)) :=
      setIntegral_mono_on hFint2 hgint measurableSet_Ioi
        (fun x hx => integrand_le_of_mem_Ioi hC hp hker w hx)
    have hcomp : (∫ x in Ioi (1:ℝ), K₂ * rexp (-(p/2 * x))) = K₂ * ((p/2)⁻¹ * rexp (-(p/2))) := by
      rw [integral_const_mul]
      congr 1
      have h := integral_comp_mul_left_Ioi (fun u : ℝ => rexp (-u)) 1 hp2
      rw [mul_one, integral_exp_neg_Ioi, smul_eq_mul] at h
      exact h
    rw [hcomp] at hmono
    refine le_trans hmono ?_
    have hfac : (p/2)⁻¹ * rexp (-(p/2)) ≤ 2/p := by
      have h1 : rexp (-(p/2)) ≤ 1 := Real.exp_le_one_iff.2 (by linarith)
      have h2 : (0:ℝ) < (p/2)⁻¹ := by positivity
      have h3 : (p/2)⁻¹ * rexp (-(p/2)) ≤ (p/2)⁻¹ * 1 :=
        mul_le_mul_of_nonneg_left h1 h2.le
      have h4 : (p/2)⁻¹ = 2/p := by field_simp
      linarith [h3, h4 ▸ h3]
    exact mul_le_mul_of_nonneg_left hfac hK2nn
  calc ‖mellin PR.f_modif w‖ ≤ ∫ x in Ioi (0:ℝ), F x := hstep1
    _ = (∫ x in Ioc (0:ℝ) 1, F x) + ∫ x in Ioi (1:ℝ), F x := hsplit
    _ ≤ K₁ + K₂ * (2/p) := add_le_add hb1 hb2

/-! ## Part E: from the Mellin bound to a bound on `Λ₀` and `ξ` -/

/-- Monotonicity bookkeeping: `a log (a/q)` is dominated by its value at the upper end,
after clipping the logarithm at `0`. -/
lemma term_le {a M q : ℝ} (ha : 0 ≤ a) (haM : a ≤ M) (hq : 0 < q) :
    a * Real.log (a / q) ≤ M * max (Real.log (M / q)) 0 := by
  have hM : 0 ≤ M := le_trans ha haM
  have hmaxnn : 0 ≤ max (Real.log (M / q)) 0 := le_max_right _ _
  rcases eq_or_lt_of_le ha with rfl | ha'
  · simp [mul_nonneg hM hmaxnn]
  rcases le_or_gt (Real.log (a / q)) 0 with hlog | hlog
  · have : a * Real.log (a / q) ≤ 0 := mul_nonpos_of_nonneg_of_nonpos ha hlog
    exact le_trans this (mul_nonneg hM hmaxnn)
  · have hle : Real.log (a / q) ≤ Real.log (M / q) :=
      Real.log_le_log (by positivity) (by gcongr)
    calc a * Real.log (a / q) ≤ M * Real.log (a / q) :=
          mul_le_mul_of_nonneg_right haM hlog.le
      _ ≤ M * Real.log (M / q) := mul_le_mul_of_nonneg_left hle hM
      _ ≤ M * max (Real.log (M / q)) 0 := mul_le_mul_of_nonneg_left (le_max_left _ _) hM

/-- The explicit majorant, as a function of the radius. -/
noncomputable def bnd (C p r : ℝ) : ℝ :=
  C * rexp ((3/2 + r) * max (Real.log ((3/2 + r) / p)) 0)
  + C * rexp (r * max (Real.log (r / (p/2))) 0) * (2/p)

/-- `r ↦ max (log (r/q)) 0` is monotone on `[0, ∞)`, including at `r = 0`. -/
lemma maxlog_mono {q : ℝ} (hq : 0 < q) {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    max (Real.log (a / q)) 0 ≤ max (Real.log (b / q)) 0 := by
  rcases eq_or_lt_of_le ha with rfl | ha'
  · simp
  · exact max_le_max_right 0 (Real.log_le_log (by positivity) (by gcongr))

/-- The majorant is monotone in the radius. -/
lemma bnd_mono {C p : ℝ} (hC : 0 < C) (hp : 0 < p) {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    bnd C p a ≤ bnd C p b := by
  have hq : (0:ℝ) < p/2 := by positivity
  have h1 : (3/2 + a) * max (Real.log ((3/2 + a) / p)) 0
      ≤ (3/2 + b) * max (Real.log ((3/2 + b) / p)) 0 := by
    refine mul_le_mul (by linarith) (maxlog_mono hp (by linarith) (by linarith))
      (le_max_right _ _) (by linarith)
  have h2 : a * max (Real.log (a / (p/2))) 0 ≤ b * max (Real.log (b / (p/2))) 0 :=
    mul_le_mul hab (maxlog_mono hq ha hab) (le_max_right _ _) (le_trans ha hab)
  unfold bnd
  refine add_le_add (mul_le_mul_of_nonneg_left (Real.exp_le_exp.2 h1) hC.le) ?_
  exact mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (Real.exp_le_exp.2 h2) hC.le) (by positivity)

/-- The Mellin transform of the modified kernel, bounded in terms of `‖w‖` alone. -/
lemma norm_mellin_le_bnd {C p : ℝ} (hC : 0 < C) (hp : 0 < p)
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x))) (w : ℂ) :
    ‖mellin PR.f_modif w‖ ≤ bnd C p ‖w‖ := by
  refine le_trans (norm_mellin_f_modif_le hC hp hker w) ?_
  have hre : |w.re| ≤ ‖w‖ := Complex.abs_re_le_norm w
  have hre1 : w.re ≤ ‖w‖ := le_trans (le_abs_self _) hre
  have hre2 : -‖w‖ ≤ w.re := neg_le_of_abs_le hre
  have hA : max (3/2 - w.re) 0 ≤ 3/2 + ‖w‖ := by
    apply max_le <;> [linarith; positivity]
  have hB : max (w.re - 1) 0 ≤ ‖w‖ := by
    apply max_le <;> [linarith; positivity]
  have h1 := term_le (le_max_right (3/2 - w.re) 0) hA hp
  have h2 := term_le (le_max_right (w.re - 1) 0) hB (by positivity : (0:ℝ) < p/2)
  unfold bnd
  refine add_le_add (mul_le_mul_of_nonneg_left (Real.exp_le_exp.2 h1) hC.le) ?_
  exact mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (Real.exp_le_exp.2 h2) hC.le) (by positivity)

/-- The completed zeta `Λ₀`, bounded on the circle of radius `r`. -/
lemma norm_completedRiemannZeta₀_le {C p : ℝ} (hC : 0 < C) (hp : 0 < p)
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x))) (z : ℂ) :
    ‖completedRiemannZeta₀ z‖ ≤ bnd C p ‖z‖ := by
  rw [completedRiemannZeta₀_eq_mellin, norm_div]
  have h := norm_mellin_le_bnd hC hp hker (z / 2)
  have hnorm : ‖z / 2‖ = ‖z‖ / 2 := by simp
  rw [hnorm] at h
  have hmono : bnd C p (‖z‖ / 2) ≤ bnd C p ‖z‖ :=
    bnd_mono hC hp (by positivity) (by linarith [norm_nonneg z])
  have h2 : ‖(2:ℂ)‖ = 2 := by simp
  rw [h2]
  have : ‖mellin PR.f_modif (z/2)‖ / 2 ≤ bnd C p ‖z‖ / 2 := by
    apply div_le_div_of_nonneg_right (le_trans h hmono) (by norm_num)
  refine le_trans this ?_
  have hb : 0 ≤ bnd C p ‖z‖ := by unfold bnd; positivity
  linarith

/-! ## Part F: the bound on `ξ`, and the two order facts -/

/-- The constant collecting the `p`-dependence of the logarithms. -/
noncomputable def cst (p : ℝ) : ℝ := |Real.log p| + |Real.log (2/p)| + Real.log 3 + 1

lemma cst_pos (p : ℝ) : 0 < cst p := by
  have h3 : 0 < Real.log 3 := Real.log_pos (by norm_num)
  unfold cst; positivity

/-- The majorant, collapsed into a single exponential, for radii `≥ 1`. -/
lemma bnd_le_exp {C p r : ℝ} (hC : 0 < C) (hp : 0 < p) (hr : 1 ≤ r) :
    bnd C p r ≤ (C * (1 + 2/p)) * rexp (4 * r * (Real.log r + cst p)) := by
  have hr0 : (0:ℝ) < r := lt_of_lt_of_le zero_lt_one hr
  have hlogr : 0 ≤ Real.log r := Real.log_nonneg hr
  have hc := cst_pos p
  have hsum : 0 ≤ Real.log r + cst p := by linarith
  -- the two exponents
  set X := (3/2 + r) * max (Real.log ((3/2 + r) / p)) 0 with hX
  set Y := r * max (Real.log (r / (p/2))) 0 with hY
  have hX0 : 0 ≤ X := by rw [hX]; positivity
  have hY0 : 0 ≤ Y := by rw [hY]; positivity
  -- `X ≤ 3 r (log r + c)`
  have hXle : X ≤ 3 * r * (Real.log r + cst p) := by
    have h1 : max (Real.log ((3/2 + r) / p)) 0 ≤ Real.log r + cst p := by
      apply max_le _ hsum
      have hle : (3/2 + r) / p ≤ 3 * r / p := by
        apply div_le_div_of_nonneg_right _ hp.le
        linarith
      have h2 : Real.log ((3/2 + r) / p) ≤ Real.log (3 * r / p) :=
        Real.log_le_log (by positivity) hle
      have h3 : Real.log (3 * r / p) = Real.log 3 + Real.log r - Real.log p := by
        rw [Real.log_div (by positivity) (ne_of_gt hp), Real.log_mul (by norm_num) (ne_of_gt hr0)]
      have h4 : -Real.log p ≤ |Real.log p| := neg_le_abs _
      unfold cst
      have h5 : 0 ≤ |Real.log (2/p)| := abs_nonneg _
      linarith [h2, h3.le, h3.ge]
    have h2 : (3/2 + r) ≤ 3 * r := by linarith
    rw [hX]
    calc (3/2 + r) * max (Real.log ((3/2 + r) / p)) 0
        ≤ (3 * r) * max (Real.log ((3/2 + r) / p)) 0 :=
          mul_le_mul_of_nonneg_right h2 (le_max_right _ _)
      _ ≤ (3 * r) * (Real.log r + cst p) :=
          mul_le_mul_of_nonneg_left h1 (by positivity)
      _ = 3 * r * (Real.log r + cst p) := by ring
  -- `Y ≤ r (log r + c)`
  have hYle : Y ≤ r * (Real.log r + cst p) := by
    have h1 : max (Real.log (r / (p/2))) 0 ≤ Real.log r + cst p := by
      apply max_le _ hsum
      have h3 : Real.log (r / (p/2)) = Real.log r - Real.log (p/2) := by
        rw [Real.log_div (ne_of_gt hr0) (by positivity)]
      have h4 : Real.log (p/2) = -Real.log (2/p) := by
        rw [← Real.log_inv]; congr 1; field_simp
      have h5 : Real.log (2/p) ≤ |Real.log (2/p)| := le_abs_self _
      unfold cst
      have h6 : 0 ≤ |Real.log p| := abs_nonneg _
      have h7 : 0 < Real.log 3 := Real.log_pos (by norm_num)
      linarith [h3.le, h3.ge, h4.le, h4.ge]
    rw [hY]
    exact mul_le_mul_of_nonneg_left h1 hr0.le
  -- collapse the sum of two exponentials
  have hkey : rexp X + rexp Y * (2/p) ≤ (1 + 2/p) * rexp (X + Y) := by
    have h1 : rexp X ≤ rexp (X + Y) := Real.exp_le_exp.2 (by linarith)
    have h2 : rexp Y ≤ rexp (X + Y) := Real.exp_le_exp.2 (by linarith)
    have hpp : (0:ℝ) < 2/p := by positivity
    nlinarith [Real.exp_pos (X + Y), h1, h2]
  have hXY : X + Y ≤ 4 * r * (Real.log r + cst p) := by linarith
  calc bnd C p r = C * rexp X + C * rexp Y * (2/p) := rfl
    _ = C * (rexp X + rexp Y * (2/p)) := by ring
    _ ≤ C * ((1 + 2/p) * rexp (X + Y)) := mul_le_mul_of_nonneg_left hkey hC.le
    _ ≤ C * ((1 + 2/p) * rexp (4 * r * (Real.log r + cst p))) := by
        have : rexp (X + Y) ≤ rexp (4 * r * (Real.log r + cst p)) := Real.exp_le_exp.2 hXY
        have hnn : (0:ℝ) ≤ 1 + 2/p := by positivity
        exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left this hnn) hC.le
    _ = (C * (1 + 2/p)) * rexp (4 * r * (Real.log r + cst p)) := by ring

/-- **The growth bound for `ξ`.**  For every `z` with `‖z‖ ≥ 1`,
`‖ξ z‖ ≤ exp (‖z‖ * (4 log ‖z‖ + K))` for a constant `K` depending only on the kernel data. -/
lemma norm_riemannXi_le_exp {C p : ℝ} (hC : 0 < C) (hp : 0 < p)
    (hker : ∀ x : ℝ, 1 ≤ x → |evenKernel 0 x - 1| ≤ C * rexp (-(p * x)))
    {z : ℂ} (hz : 1 ≤ ‖z‖) :
    ‖riemannXi z‖
      ≤ rexp (‖z‖ * (4 * Real.log ‖z‖ +
          (max (Real.log (C * (1 + 2/p) + 1)) 0 + 2 + 4 * cst p))) := by
  set r := ‖z‖ with hrdef
  have hr0 : (0:ℝ) < r := lt_of_lt_of_le zero_lt_one hz
  have hlogr : 0 ≤ Real.log r := Real.log_nonneg hz
  have hc := cst_pos p
  set D := C * (1 + 2/p) with hD
  have hD0 : 0 < D := by rw [hD]; positivity
  -- pointwise bound on ξ
  have hΛ : ‖completedRiemannZeta₀ z‖ ≤ bnd C p r := norm_completedRiemannZeta₀_le hC hp hker z
  have hxi : ‖riemannXi z‖ ≤ (1/2) * r * (r + 1) * bnd C p r + 1/2 := by
    have hdef : riemannXi z = (1/2 : ℂ) * z * (z - 1) * completedRiemannZeta₀ z + (1/2 : ℂ) := rfl
    rw [hdef]
    refine le_trans (norm_add_le _ _) ?_
    have h1 : ‖(1/2 : ℂ) * z * (z - 1) * completedRiemannZeta₀ z‖
        = (1/2) * r * ‖z - 1‖ * ‖completedRiemannZeta₀ z‖ := by
      simp [hrdef]
    have h2 : ‖z - 1‖ ≤ r + 1 := le_trans (norm_sub_le _ _) (by simp [hrdef])
    have h3 : ‖(1/2 : ℂ)‖ = 1/2 := by simp
    rw [h1, h3]
    have hbn : 0 ≤ bnd C p r := by unfold bnd; positivity
    have hstep : (1/2) * r * ‖z - 1‖ * ‖completedRiemannZeta₀ z‖
        ≤ (1/2) * r * (r + 1) * bnd C p r := by
      apply mul_le_mul _ hΛ (norm_nonneg _) (by positivity)
      exact mul_le_mul_of_nonneg_left h2 (by positivity)
    linarith
  -- collapse the majorant
  have hb := bnd_le_exp (C := C) (p := p) hC hp hz
  have hmul : (1/2) * r * (r + 1) * bnd C p r + 1/2
      ≤ (D + 1) * r ^ 2 * rexp (4 * r * (Real.log r + cst p)) := by
    have he1 : (1:ℝ) ≤ rexp (4 * r * (Real.log r + cst p)) :=
      Real.one_le_exp (by positivity)
    have hpoly : (1/2) * r * (r + 1) ≤ r ^ 2 := by nlinarith
    have hbn : 0 ≤ bnd C p r := by unfold bnd; positivity
    have h1 : (1/2) * r * (r + 1) * bnd C p r
        ≤ r ^ 2 * (D * rexp (4 * r * (Real.log r + cst p))) := by
      apply mul_le_mul hpoly hb hbn (by positivity)
    have h2 : (1:ℝ)/2 ≤ 1 * r ^ 2 * rexp (4 * r * (Real.log r + cst p)) := by
      nlinarith [sq_nonneg (r - 1), hz, Real.exp_pos (4 * r * (Real.log r + cst p))]
    nlinarith [h1, h2, Real.exp_pos (4 * r * (Real.log r + cst p))]
  -- turn the polynomial prefactor into an exponential
  have hr2 : rexp (2 * Real.log r) = r ^ 2 := by
    rw [show (2:ℝ) * Real.log r = Real.log r + Real.log r by ring, Real.exp_add,
      Real.exp_log hr0]
    ring
  have hpre : (D + 1) * r ^ 2 = rexp (Real.log (D + 1) + 2 * Real.log r) := by
    rw [Real.exp_add, Real.exp_log (by positivity), hr2]
  have hfinal : Real.log (D + 1) + 2 * Real.log r + 4 * r * (Real.log r + cst p)
      ≤ r * (4 * Real.log r + (max (Real.log (D + 1)) 0 + 2 + 4 * cst p)) := by
    have h1 : Real.log (D + 1) ≤ max (Real.log (D + 1)) 0 * r := by
      have hm : 0 ≤ max (Real.log (D + 1)) 0 := le_max_right _ _
      nlinarith [le_max_left (Real.log (D + 1)) 0]
    have h2 : 2 * Real.log r ≤ 2 * r := by
      nlinarith [Real.log_le_sub_one_of_pos hr0]
    nlinarith [hc.le]
  calc ‖riemannXi z‖ ≤ (1/2) * r * (r + 1) * bnd C p r + 1/2 := hxi
    _ ≤ (D + 1) * r ^ 2 * rexp (4 * r * (Real.log r + cst p)) := hmul
    _ = rexp (Real.log (D + 1) + 2 * Real.log r) * rexp (4 * r * (Real.log r + cst p)) := by
        rw [hpre]
    _ = rexp (Real.log (D + 1) + 2 * Real.log r + 4 * r * (Real.log r + cst p)) := by
        rw [← Real.exp_add]
    _ ≤ rexp (r * (4 * Real.log r + (max (Real.log (D + 1)) 0 + 2 + 4 * cst p))) :=
        Real.exp_le_exp.2 hfinal

/-! ## Part G: the two order facts -/

/-- The growth bound, with the kernel data packaged away. -/
lemma exists_xi_bound : ∃ K : ℝ, 0 ≤ K ∧ ∀ z : ℂ, 1 ≤ ‖z‖ →
    ‖riemannXi z‖ ≤ rexp (‖z‖ * (4 * Real.log ‖z‖ + K)) := by
  obtain ⟨C, p, hC, hp, hker⟩ := exists_kernel_bound
  refine ⟨max (Real.log (C * (1 + 2/p) + 1)) 0 + 2 + 4 * cst p, ?_, ?_⟩
  · have h1 : 0 ≤ max (Real.log (C * (1 + 2/p) + 1)) 0 := le_max_right _ _
    have h2 := (cst_pos p).le
    linarith
  · intro z hz
    exact norm_riemannXi_le_exp hC hp hker hz

/-- **`ξ` is an entire function of finite order.** -/
theorem riemannXi_hasFiniteOrder : Hadamard.hasFiniteOrder riemannXi := by
  obtain ⟨K, hK, hbd⟩ := exists_xi_bound
  refine ⟨xi_entire, 2, ?_⟩
  have hev : ∀ᶠ r : ℝ in atTop, 4 * Real.log r + K < r := by
    have hlog : ∀ᶠ r : ℝ in atTop, ‖Real.log r‖ ≤ (1/8) * ‖r ^ (1:ℝ)‖ :=
      (isLittleO_log_rpow_atTop one_pos).def (by norm_num)
    filter_upwards [hlog, eventually_ge_atTop (2*(K+1)), eventually_ge_atTop (1:ℝ)]
      with r h1 h2 hr1
    have hr0 : (0:ℝ) < r := lt_of_lt_of_le zero_lt_one hr1
    rw [Real.rpow_one, Real.norm_eq_abs, Real.norm_eq_abs, abs_of_pos hr0] at h1
    have h3 : Real.log r ≤ (1/8) * r := le_trans (le_abs_self _) h1
    linarith
  obtain ⟨R₀, hR₀⟩ := eventually_atTop.1 (hev.and (eventually_ge_atTop (1:ℝ)))
  refine ⟨max R₀ 1, ?_⟩
  intro z hz
  have hz1 : 1 ≤ ‖z‖ := le_trans (le_max_right R₀ 1) hz
  have hzR : R₀ ≤ ‖z‖ := le_trans (le_max_left R₀ 1) hz
  obtain ⟨hlt, -⟩ := hR₀ ‖z‖ hzR
  have hz0 : (0:ℝ) < ‖z‖ := lt_of_lt_of_le zero_lt_one hz1
  refine lt_of_le_of_lt (hbd z hz1) ?_
  apply Real.exp_lt_exp.2
  have hsq : ‖z‖ ^ (2:ℝ) = ‖z‖ * ‖z‖ := by
    rw [show (2:ℝ) = (1:ℝ) + 1 by norm_num, Real.rpow_add hz0, Real.rpow_one]
  rw [hsq]
  exact mul_lt_mul_of_pos_left hlt hz0

/-- **The order of `ξ` is at most `1`.** -/
theorem riemannXi_order_le_one : Hadamard.order riemannXi ≤ 1 := by
  obtain ⟨K, hK, hbd⟩ := exists_xi_bound
  refine Hadamard.order_le_one_of_forall_pos_eventually_maxModulus_le_exp_rpow_one_add
    riemannXi xi_entire ?_
  intro ε hε
  have hlog : ∀ᶠ r : ℝ in atTop, ‖Real.log r‖ ≤ (1/8) * ‖r ^ ε‖ :=
    (isLittleO_log_rpow_atTop hε).def (by norm_num)
  have hKe : ∀ᶠ r : ℝ in atTop, 2 * K ≤ r ^ ε :=
    (tendsto_rpow_atTop hε).eventually_ge_atTop (2 * K)
  filter_upwards [hlog, hKe, eventually_ge_atTop (1:ℝ)] with r h1 h2 hr1
  have hr0 : (0:ℝ) < r := lt_of_lt_of_le zero_lt_one hr1
  have hrpow : (0:ℝ) < r ^ ε := Real.rpow_pos_of_pos hr0 ε
  rw [Real.norm_eq_abs, Real.norm_eq_abs, abs_of_pos hrpow] at h1
  have h3 : Real.log r ≤ (1/8) * r ^ ε := le_trans (le_abs_self _) h1
  refine Hadamard.maxModulus_le_of_forall_norm_le _ xi_entire.continuous hr0.le ?_
  intro z hzr
  have hz1 : 1 ≤ ‖z‖ := by rw [hzr]; exact hr1
  have hb := hbd z hz1
  rw [hzr] at hb
  refine le_trans hb (Real.exp_le_exp.2 ?_)
  have hstep : 4 * Real.log r + K ≤ r ^ ε := by linarith
  have hmul : r * (4 * Real.log r + K) ≤ r * r ^ ε :=
    mul_le_mul_of_nonneg_left hstep hr0.le
  have hcomb : r * r ^ ε = r ^ (1 + ε) := by
    rw [Real.rpow_add hr0, Real.rpow_one]
  linarith [hmul, hcomb.le, hcomb.ge]

end LiCriterion.XiGrowth
~~~~~~

## Hadamard.OrderOne.OrderFromMaxModulus

Path: `source/Hadamard/OrderOne/OrderFromMaxModulus.lean`

Original source lines: 1–176

Full file SHA256: `ff105cf4e302e0a40e7ce18b08922146bb20b4973f937af995cfe2f98b22c67f`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/OrderOne/OrderFromMaxModulus.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Order.LiminfLimsup
import Hadamard.Basic

/-!
Order bounds from max-modulus bounds.

This file isolates a general lemma that converts an eventual max-modulus bound

`maxModulus f r ≤ exp (r ^ ρ)`

into an order bound `order f ≤ ρ`, where `order` is the `limsup` definition from
`LZC/HadamardFactorization/Basic.lean`.

It is used in the order-`≤ 1` Hadamard factorization proof to show the quotient
`Q := f / P` has `order Q < 2`, hence is an exponential of a linear function.
-/

namespace Hadamard

open Complex Real Filter

/-! ### A coboundedness helper for the `order` auxiliary function -/

/-- A cheap eventual lower bound for the auxiliary function used in `order`.

This is purely a `Filter`/`limsup` technicality: `Filter.limsup_le_of_le` requires an
`IsCoboundedUnder` hypothesis, which we obtain from this lemma. -/
private lemma orderAux_eventually_ge_neg_one (f : ℂ → ℂ) (hf : Differentiable ℂ f) :
    ∀ᶠ r : ℝ in atTop,
      (-1 : ℝ) ≤
        (if r > 0 ∧ maxModulus f r > 1 then
            Real.log (Real.log (maxModulus f r)) / Real.log r
          else 0) := by
  classical
  -- Either the max modulus ever exceeds 1, or it never does.
  by_cases hex : ∃ r0 : ℝ, maxModulus f r0 > 1
  · rcases hex with ⟨r0, hr0⟩
    have hr0_nonneg : 0 ≤ r0 := by
      by_contra h
      have hr0_neg : r0 < 0 := lt_of_not_ge h
      have hset_empty : {y : ℝ | ∃ z : ℂ, ‖z‖ = r0 ∧ y = ‖f z‖} = ∅ := by
        ext y
        constructor
        · rintro ⟨z, hz, rfl⟩
          have : (0 : ℝ) ≤ ‖z‖ := norm_nonneg z
          linarith [hz, hr0_neg]
        · intro hy; cases hy
      have : maxModulus f r0 = 0 := by
        simp [maxModulus, hset_empty]
      have : ¬ maxModulus f r0 > 1 := by
        simp [this]
      exact this hr0
    -- `M0` is a fixed value `> 1`.
    let M0 : ℝ := maxModulus f r0
    have hM0 : 1 < M0 := hr0
    have hlogM0_pos : 0 < Real.log M0 := Real.log_pos hM0
    let L : ℝ := Real.log (Real.log M0)
    -- Threshold making `log r ≥ -L`, and ensuring `r ≥ r0` and `r ≥ 2`.
    let R1 : ℝ := max (max r0 2) (Real.exp (-L))
    have hR1_ge2 : (2 : ℝ) ≤ R1 := le_trans (le_max_right r0 2) (le_max_left _ _)
    have hR1_ge_r0 : r0 ≤ R1 := le_trans (le_max_left r0 2) (le_max_left _ _)
    have hR1_ge_exp : Real.exp (-L) ≤ R1 := le_max_right _ _
    refine Filter.eventually_atTop.2 ⟨R1, ?_⟩
    intro r hr
    have hr_ge2 : (2 : ℝ) ≤ r := le_trans hR1_ge2 hr
    have hr_pos : 0 < r := lt_of_lt_of_le (by norm_num : (0 : ℝ) < 2) hr_ge2
    have hr_gt1 : 1 < r := by linarith
    have hlogr_pos : 0 < Real.log r := Real.log_pos hr_gt1
    have hM0_le : M0 ≤ maxModulus f r := by
      have hr0_le : r0 ≤ r := le_trans hR1_ge_r0 hr
      exact maxModulus_mono_of_differentiable f hf (hR := hr_pos) (hr := hr0_nonneg) hr0_le
    have hMr_gt1 : 1 < maxModulus f r := lt_of_lt_of_le hM0 hM0_le
    have hloglog_ge : L ≤ Real.log (Real.log (maxModulus f r)) := by
      have hlogMr_ge : Real.log M0 ≤ Real.log (maxModulus f r) :=
        Real.log_le_log (by linarith [hM0]) hM0_le
      have : Real.log (Real.log M0) ≤ Real.log (Real.log (maxModulus f r)) :=
        Real.log_le_log hlogM0_pos (le_trans (le_rfl) hlogMr_ge)
      simpa [L] using this
    have hlogr_ge : -L ≤ Real.log r := by
      have : Real.exp (-L) ≤ r := le_trans hR1_ge_exp hr
      have hlog_exp : Real.log (Real.exp (-L)) ≤ Real.log r :=
        Real.log_le_log (by positivity) this
      simpa [Real.log_exp] using hlog_exp
    -- Now `-log r ≤ loglogM`.
    have hneglogr_le : -Real.log r ≤ Real.log (Real.log (maxModulus f r)) := by
      have : -Real.log r ≤ L := by linarith [hlogr_ge]
      exact le_trans this hloglog_ge
    -- Convert to `(-1) ≤ loglogM / log r`.
    have : (-1 : ℝ) ≤ Real.log (Real.log (maxModulus f r)) / Real.log r := by
      have : (-1 : ℝ) * Real.log r ≤ Real.log (Real.log (maxModulus f r)) := by
        simpa using hneglogr_le
      exact (le_div_iff₀ hlogr_pos).2 this
    have hcond : r > 0 ∧ maxModulus f r > 1 := ⟨hr_pos, hMr_gt1⟩
    simpa [hcond] using this
  · -- If the max modulus never exceeds 1, the expression is always 0.
    refine Filter.Eventually.of_forall ?_
    intro r
    have hnot : ¬ maxModulus f r > 1 := by
      intro hr'
      exact hex ⟨r, hr'⟩
    by_cases hr0 : r > 0
    · simp [hr0, hnot]
    · simp [hr0]

/-! ### Order bound from an eventual max-modulus bound -/

theorem order_le_of_eventually_maxModulus_le_exp_rpow
    (f : ℂ → ℂ) (ρ : ℝ) (hρ : 0 ≤ ρ) (hf : Differentiable ℂ f)
    (h : ∀ᶠ r : ℝ in atTop, maxModulus f r ≤ Real.exp (r ^ ρ)) :
    order f ≤ ρ := by
  let u : ℝ → ℝ := fun r : ℝ =>
    if r > 0 ∧ maxModulus f r > 1 then
      Real.log (Real.log (maxModulus f r)) / Real.log r
    else 0
  have hu_upper : ∀ᶠ r : ℝ in atTop, u r ≤ ρ := by
    filter_upwards [h, (eventually_gt_atTop (1 : ℝ))] with r hr hr_gt1
    by_cases hcond : r > 0 ∧ maxModulus f r > 1
    · have hr_pos : 0 < r := hcond.1
      have hlogr_pos : 0 < Real.log r := Real.log_pos hr_gt1
      have hM_pos : 0 < maxModulus f r := lt_trans (by linarith) hcond.2
      have hlogM_le : Real.log (maxModulus f r) ≤ r ^ ρ := by
        have := Real.log_le_log hM_pos hr
        simpa [Real.log_exp] using this
      have hlogM_pos : 0 < Real.log (maxModulus f r) := Real.log_pos hcond.2
      have hloglog_le : Real.log (Real.log (maxModulus f r)) ≤ Real.log (r ^ ρ) :=
        Real.log_le_log hlogM_pos hlogM_le
      have hlogrpow : Real.log (r ^ ρ) = ρ * Real.log r := Real.log_rpow hr_pos ρ
      have : Real.log (Real.log (maxModulus f r)) ≤ ρ * Real.log r :=
        le_trans hloglog_le (by rw [hlogrpow])
      have : Real.log (Real.log (maxModulus f r)) / Real.log r ≤ ρ :=
        (div_le_iff₀ hlogr_pos).2 this
      simpa [u, hcond] using this
    · simp [u, hcond, hρ]
  have hu_lower : ∀ᶠ r : ℝ in atTop, (-1 : ℝ) ≤ u r := orderAux_eventually_ge_neg_one f hf
  have hu_cobdd : IsCoboundedUnder (· ≤ ·) atTop u :=
    Filter.isCoboundedUnder_le_of_eventually_le atTop hu_lower
  have hlimsup : Filter.limsup u atTop ≤ ρ :=
    Filter.limsup_le_of_le (f := (atTop : Filter ℝ)) (u := u) (a := ρ) hu_cobdd hu_upper
  simpa [Hadamard.order, u] using hlimsup

/-! ### Order bounds from a `ρ + ε` max-modulus family -/

/-!
If we can bound `maxModulus f r` by `exp(r^(ρ+ε))` for every `ε > 0`, then `order f ≤ ρ`.

This packages the exact “max-modulus form” pipeline used for order-`≤ 1` goals:
prove the family of bounds, then apply `order_le_of_eventually_maxModulus_le_exp_rpow`
at exponent `ρ+ε`, and finally let `ε → 0` using `le_of_forall_pos_le_add`.
-/
theorem order_le_of_forall_pos_eventually_maxModulus_le_exp_rpow_add
    (f : ℂ → ℂ) (ρ : ℝ) (hρ : 0 ≤ ρ) (hf : Differentiable ℂ f)
    (h : ∀ ε : ℝ, 0 < ε →
      ∀ᶠ r : ℝ in atTop, maxModulus f r ≤ Real.exp (r ^ (ρ + ε))) :
    order f ≤ ρ := by
  refine _root_.le_of_forall_pos_le_add ?_
  intro ε hε
  have hρ' : 0 ≤ ρ + ε := add_nonneg hρ (le_of_lt hε)
  exact
    order_le_of_eventually_maxModulus_le_exp_rpow (f := f) (ρ := ρ + ε) (hρ := hρ') (hf := hf)
      (h := h ε hε)

/-! A convenient specialization for order-`≤ 1` (the β use-case). -/
theorem order_le_one_of_forall_pos_eventually_maxModulus_le_exp_rpow_one_add
    (f : ℂ → ℂ) (hf : Differentiable ℂ f)
    (h : ∀ ε : ℝ, 0 < ε → ∀ᶠ r : ℝ in atTop, maxModulus f r ≤ Real.exp (r ^ (1 + ε))) :
    order f ≤ 1 := by
  simpa using
    (order_le_of_forall_pos_eventually_maxModulus_le_exp_rpow_add (f := f) (ρ := 1) (hρ := by
      norm_num) (hf := hf) (h := h))

end Hadamard
~~~~~~

## MellinDecayEstimateV1

Path: `source/MellinDecayEstimateV1.lean`

Original source lines: 1–511

Full file SHA256: `ca2203ce4c2da420d89bbcb012aaefefb23584eac040b975272d2ce3fa5d2eed`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/MellinDecayEstimateV1.lean

~~~~~~lean
import WeilCriterionCompactSmoothV1
import ZeroShellAnalyticSynthesisV1
import Mathlib.Analysis.MellinInversion
import Mathlib.Analysis.Fourier.FourierTransformDeriv
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.MeasureTheory.Integral.CompactlySupported

/-!
AEGIS Ω — compact-smooth Mellin vertical cubic decay v1.

This lane works on the existing conservative compact-smooth positive-half-line
class `WeilCompactSmoothGV1`. It proves a uniform cubic vertical-strip bound
for the Mellin transform and then converts that bound to the existing canonical
height-shell interface `HasCubicShellMellinDecayV1`.

The proof is RH-independent. It uses the whole strip `0 ≤ re(s) ≤ 1`, the
existing canonical shell index `ceil |im(s)|`, Mathlib's Mellin/Fourier
identity, and third-order Fourier derivative control.

MELLIN_VERTICAL_CUBIC_DECAY_V1
AUTOCORRELATION_COMPACT_SMOOTH_BRIDGE_OPEN
ZERO_COUNTING_BOUND_OPEN
EXPLICIT_FORMULA_OPEN
CRITICAL_LINE_RE_HALF_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Filter Topology
open Complex MeasureTheory
open scoped ContDiff FourierTransform

noncomputable section

/-- Log-coordinate profile used by Mathlib's Mellin/Fourier identity. -/
def MellinLogProfileV1 (f : ℝ → ℂ) (u : ℝ) : ℂ :=
  f (Real.exp (-u))

/-- Real exponential weight appearing at fixed vertical-strip real part. -/
def MellinWeightV1 (σ u : ℝ) : ℝ :=
  Real.exp (-σ * u)

/-- Complex-valued view of the real exponential weight. -/
def MellinComplexWeightV1 (σ u : ℝ) : ℂ :=
  MellinWeightV1 σ u • (1 : ℂ)

/-- Fourier-side profile whose transform equals the Mellin transform. -/
def MellinWeightedLogProfileV1 (f : ℝ → ℂ) (σ u : ℝ) : ℂ :=
  MellinComplexWeightV1 σ u * MellinLogProfileV1 f u

/-- Uniform vertical cubic decay, stated without division so the zero-frequency
case remains total and explicit. -/
def HasUniformMellinVerticalCubicDecayV1 (f : ℝ → ℂ) : Prop :=
  ∃ D : ℝ, 0 ≤ D ∧
    ∀ σ : ℝ, σ ∈ Set.Icc 0 1 → ∀ γ : ℝ,
      (1 + |γ|) ^ 3 *
          ‖mellin f ((σ : ℂ) + (γ : ℂ) * Complex.I)‖ ≤ D

private theorem mellin_log_profile_contDiff_v1 (g : WeilCompactSmoothGV1) :
    ContDiff ℝ ∞ (MellinLogProfileV1 g.1) := by
  unfold MellinLogProfileV1
  have hneg : ContDiff ℝ ∞ (fun u : ℝ => -u) := by fun_prop
  exact g.2.1.comp (Real.contDiff_exp.comp hneg)

private theorem mellin_log_profile_hasCompactSupport_v1
    (g : WeilCompactSmoothGV1) :
    HasCompactSupport (MellinLogProfileV1 g.1) := by
  let K : Set ℝ := (fun x : ℝ => -Real.log x) '' tsupport g.1
  have hts : IsCompact (tsupport g.1) := by
    change IsCompact (closure (Function.support g.1))
    exact g.2.2.1
  have hlog : ContinuousOn (fun x : ℝ => -Real.log x) (tsupport g.1) := by
    intro x hx
    have hxpos : 0 < x := g.2.2.2 hx
    exact (Real.continuousAt_log hxpos.ne').neg.continuousWithinAt
  have hK : IsCompact K := hts.image_of_continuousOn hlog
  apply HasCompactSupport.of_support_subset_isCompact hK
  intro u hu
  change g.1 (Real.exp (-u)) ≠ 0 at hu
  have hmem : Real.exp (-u) ∈ tsupport g.1 := subset_closure hu
  refine ⟨Real.exp (-u), hmem, ?_⟩
  simp

private theorem mellin_weight_contDiff_v1 (σ : ℝ) :
    ContDiff ℝ ∞ (MellinWeightV1 σ) := by
  unfold MellinWeightV1
  fun_prop

private theorem mellin_complex_weight_contDiff_v1 (σ : ℝ) :
    ContDiff ℝ ∞ (MellinComplexWeightV1 σ) := by
  unfold MellinComplexWeightV1
  exact (mellin_weight_contDiff_v1 σ).smul_const (1 : ℂ)

private theorem mellin_weight_iteratedDeriv_v1 (σ : ℝ) (n : ℕ) :
    iteratedDeriv n (MellinWeightV1 σ) =
      fun u : ℝ => (-σ) ^ n * Real.exp (-σ * u) := by
  change iteratedDeriv n (fun u : ℝ => Real.exp ((-σ) * u)) =
    fun u : ℝ => (-σ) ^ n * Real.exp ((-σ) * u)
  exact iteratedDeriv_exp_const_mul n (-σ)

private theorem mellin_complex_weight_iteratedDeriv_v1
    (σ : ℝ) (n : ℕ) (u : ℝ) :
    iteratedDeriv n (MellinComplexWeightV1 σ) u =
      (((-σ) ^ n * Real.exp (-σ * u) : ℝ) : ℂ) := by
  have hwTop : ContDiffAt ℝ ∞ (MellinWeightV1 σ) u :=
    (mellin_weight_contDiff_v1 σ).contDiffAt
  have hw : ContDiffAt ℝ (n : ℕ∞ω) (MellinWeightV1 σ) u :=
    hwTop.of_le (by exact_mod_cast le_top)
  change iteratedDeriv n (fun y : ℝ => MellinWeightV1 σ y • (1 : ℂ)) u =
    (((-σ) ^ n * Real.exp (-σ * u) : ℝ) : ℂ)
  rw [iteratedDeriv_smul_const hw]
  rw [congrFun (mellin_weight_iteratedDeriv_v1 σ n) u]
  simp [Complex.real_smul]

private theorem mellin_weighted_log_profile_contDiff_v1
    (g : WeilCompactSmoothGV1) (σ : ℝ) :
    ContDiff ℝ ∞ (MellinWeightedLogProfileV1 g.1 σ) := by
  unfold MellinWeightedLogProfileV1
  exact (mellin_complex_weight_contDiff_v1 σ).mul (mellin_log_profile_contDiff_v1 g)

private theorem mellin_weighted_log_profile_hasCompactSupport_v1
    (g : WeilCompactSmoothGV1) (σ : ℝ) :
    HasCompactSupport (MellinWeightedLogProfileV1 g.1 σ) := by
  have hh : HasCompactSupport (MellinLogProfileV1 g.1) :=
    mellin_log_profile_hasCompactSupport_v1 g
  apply hh.of_isClosed_subset (isClosed_tsupport _)
  change tsupport (fun u : ℝ =>
      MellinComplexWeightV1 σ u * MellinLogProfileV1 g.1 u) ⊆
    tsupport (MellinLogProfileV1 g.1)
  exact tsupport_mul_subset_right

private theorem mellin_weighted_log_profile_tsupport_subset_v1
    (g : WeilCompactSmoothGV1) (σ : ℝ) :
    tsupport (MellinWeightedLogProfileV1 g.1 σ) ⊆
      tsupport (MellinLogProfileV1 g.1) := by
  change tsupport (fun u : ℝ =>
      MellinComplexWeightV1 σ u * MellinLogProfileV1 g.1 u) ⊆
    tsupport (MellinLogProfileV1 g.1)
  exact tsupport_mul_subset_right

private theorem mellin_iteratedDeriv_hasCompactSupport_v1
    {f : ℝ → ℂ} (hf : HasCompactSupport f) (n : ℕ) :
    HasCompactSupport (iteratedDeriv n f) := by
  have hF : HasCompactSupport (iteratedFDeriv ℝ n f) := hf.iteratedFDeriv n
  rw [iteratedDeriv_eq_equiv_comp]
  exact hF.comp_left (map_zero _)

private theorem mellin_weighted_log_profile_deriv_integrable_v1
    (g : WeilCompactSmoothGV1) (σ : ℝ) (n : ℕ) :
    Integrable (iteratedDeriv n (MellinWeightedLogProfileV1 g.1 σ)) := by
  let p := MellinWeightedLogProfileV1 g.1 σ
  have hpcont : ContDiff ℝ ∞ p := mellin_weighted_log_profile_contDiff_v1 g σ
  have hpcomp : HasCompactSupport p :=
    mellin_weighted_log_profile_hasCompactSupport_v1 g σ
  have hpderivcont : Continuous (iteratedDeriv n p) :=
    hpcont.continuous_iteratedDeriv n (by exact_mod_cast le_top)
  exact hpderivcont.integrable_of_hasCompactSupport
    (mellin_iteratedDeriv_hasCompactSupport_v1 hpcomp n)

private theorem mellin_log_profile_deriv_bound_v1
    (g : WeilCompactSmoothGV1) (i : ℕ) :
    ∃ C : ℝ, ∀ u : ℝ, ‖iteratedDeriv i (MellinLogProfileV1 g.1) u‖ ≤ C := by
  let h := MellinLogProfileV1 g.1
  have hhcont : ContDiff ℝ ∞ h := mellin_log_profile_contDiff_v1 g
  have hhcomp : HasCompactSupport h := mellin_log_profile_hasCompactSupport_v1 g
  have hc : Continuous (iteratedDeriv i h) :=
    hhcont.continuous_iteratedDeriv i (by exact_mod_cast le_top)
  exact hc.bounded_above_of_compact_support
    (mellin_iteratedDeriv_hasCompactSupport_v1 hhcomp i)

/-- The weighted log profiles have a single L1 bound for derivatives of order
at most three, uniformly for `σ ∈ [0,1]`. -/
private theorem mellin_weighted_log_profile_uniform_l1_v1
    (g : WeilCompactSmoothGV1) :
    ∃ L : ℝ, 0 ≤ L ∧
      ∀ σ : ℝ, σ ∈ Set.Icc 0 1 → ∀ n : ℕ, n ≤ 3 →
        (∫ u : ℝ,
          ‖iteratedDeriv n (MellinWeightedLogProfileV1 g.1 σ) u‖) ≤ L := by
  let h := MellinLogProfileV1 g.1
  have hhcont : ContDiff ℝ ∞ h := mellin_log_profile_contDiff_v1 g
  have hhcomp : HasCompactSupport h := mellin_log_profile_hasCompactSupport_v1 g
  have htscomp : IsCompact (tsupport h) := by
    change IsCompact (closure (Function.support h))
    exact hhcomp
  obtain ⟨r, hr⟩ :=
    (Metric.isBounded_iff_subset_closedBall (0 : ℝ)).mp htscomp.isBounded
  let R : ℝ := max r 0
  have hR : 0 ≤ R := le_max_right _ _
  have htsR : tsupport h ⊆ Metric.closedBall (0 : ℝ) R := by
    exact hr.trans (Metric.closedBall_subset_closedBall (le_max_left _ _))

  obtain ⟨C0, hC0⟩ := mellin_log_profile_deriv_bound_v1 g 0
  obtain ⟨C1, hC1⟩ := mellin_log_profile_deriv_bound_v1 g 1
  obtain ⟨C2, hC2⟩ := mellin_log_profile_deriv_bound_v1 g 2
  obtain ⟨C3, hC3⟩ := mellin_log_profile_deriv_bound_v1 g 3
  let C : ℝ := max 0 (max C0 (max C1 (max C2 C3)))
  have hC : 0 ≤ C := le_max_left _ _
  have hC0' : C0 ≤ C :=
    (le_max_left C0 (max C1 (max C2 C3))).trans (le_max_right 0 _)
  have hC1' : C1 ≤ C :=
    (le_max_left C1 (max C2 C3)).trans
      ((le_max_right C0 _).trans (le_max_right 0 _))
  have hC2' : C2 ≤ C :=
    (le_max_left C2 C3).trans
      ((le_max_right C1 _).trans ((le_max_right C0 _).trans (le_max_right 0 _)))
  have hC3' : C3 ≤ C :=
    (le_max_right C2 C3).trans
      ((le_max_right C1 _).trans ((le_max_right C0 _).trans (le_max_right 0 _)))
  have hCderiv : ∀ i : ℕ, i ≤ 3 → ∀ u : ℝ,
      ‖iteratedDeriv i h u‖ ≤ C := by
    intro i hi u
    interval_cases i
    · exact (hC0 u).trans hC0'
    · exact (hC1 u).trans hC1'
    · exact (hC2 u).trans hC2'
    · exact (hC3 u).trans hC3'

  let M : ℝ := 8 * Real.exp R * C
  have hM : 0 ≤ M := by
    dsimp [M]
    positivity
  let K : Set ℝ := Metric.closedBall (0 : ℝ) R
  have hKmeas : MeasurableSet K := measurableSet_closedBall
  have hKfinite : volume K ≠ ⊤ := ne_of_lt measure_closedBall_lt_top
  let L : ℝ := ∫ _u : ℝ in K, M
  have hL : 0 ≤ L := by
    dsimp [L]
    exact setIntegral_nonneg hKmeas (fun _ _ => hM)

  refine ⟨L, hL, ?_⟩
  intro σ hσ n hn
  let p := MellinWeightedLogProfileV1 g.1 σ

  have hpcont : ContDiff ℝ ∞ p := mellin_weighted_log_profile_contDiff_v1 g σ
  have hp_ts : tsupport p ⊆ tsupport h :=
    mellin_weighted_log_profile_tsupport_subset_v1 g σ
  have hpint : Integrable (iteratedDeriv n p) :=
    mellin_weighted_log_profile_deriv_integrable_v1 g σ n

  have hsigma_abs : |σ| ≤ 1 := by
    rw [abs_of_nonneg hσ.1]
    exact hσ.2

  have hpoint : ∀ u ∈ K, ‖iteratedDeriv n p u‖ ≤ M := by
    intro u hu
    have huabs : |u| ≤ R := by
      simpa [K, Metric.mem_closedBall, Real.dist_eq] using hu
    have hexparg : -σ * u ≤ R := by
      calc
        -σ * u ≤ |σ * u| := by
          simpa [abs_mul] using le_abs_self (-σ * u)
        _ = |σ| * |u| := abs_mul σ u
        _ ≤ 1 * R := by gcongr
        _ = R := one_mul R
    have hexp : Real.exp (-σ * u) ≤ Real.exp R :=
      Real.exp_le_exp.mpr hexparg

    have hweight : ∀ i : ℕ,
        ‖iteratedDeriv i (MellinComplexWeightV1 σ) u‖ ≤ Real.exp R := by
      intro i
      rw [mellin_complex_weight_iteratedDeriv_v1]
      simp only [Complex.norm_real, Real.norm_eq_abs, abs_mul, abs_pow, Real.abs_exp]
      calc
        |(-σ)| ^ i * Real.exp (-σ * u)
            ≤ 1 ^ i * Real.exp R := by
              gcongr
              · simpa using hsigma_abs
        _ = Real.exp R := by simp

    change ‖iteratedDeriv n
      (fun x : ℝ => MellinComplexWeightV1 σ x * h x) u‖ ≤ M
    have hw_n : ContDiffAt ℝ (n : ℕ∞ω) (MellinComplexWeightV1 σ) u :=
      (mellin_complex_weight_contDiff_v1 σ).contDiffAt.of_le
        (by exact_mod_cast le_top)
    have hh_n : ContDiffAt ℝ (n : ℕ∞ω) h u :=
      hhcont.contDiffAt.of_le (by exact_mod_cast le_top)
    rw [iteratedDeriv_fun_mul hw_n hh_n]
    calc
      ‖∑ i ∈ Finset.range (n + 1),
          (n.choose i : ℂ) *
            iteratedDeriv i (MellinComplexWeightV1 σ) u *
              iteratedDeriv (n - i) h u‖
          ≤ ∑ i ∈ Finset.range (n + 1),
              ‖(n.choose i : ℂ) *
                iteratedDeriv i (MellinComplexWeightV1 σ) u *
                  iteratedDeriv (n - i) h u‖ := norm_sum_le ..
      _ ≤ ∑ i ∈ Finset.range (n + 1),
              (n.choose i : ℝ) * Real.exp R * C := by
        apply Finset.sum_le_sum
        intro i hi
        have hni : n - i ≤ 3 := (Nat.sub_le n i).trans hn
        simp only [norm_mul, Complex.norm_natCast, Real.norm_natCast]
        gcongr
        · exact hweight i
        · exact hCderiv (n - i) hni u
      _ = (2 : ℝ) ^ n * Real.exp R * C := by
        rw [← Finset.sum_mul, ← Finset.sum_mul]
        norm_cast
        rw [Nat.sum_range_choose]
      _ ≤ 8 * Real.exp R * C := by
        have hpow : (2 : ℝ) ^ n ≤ 8 := by
          interval_cases n <;> norm_num
        gcongr
      _ = M := by rfl

  have hsupport :
      Function.support (fun u : ℝ => ‖iteratedDeriv n p u‖) ⊆ K := by
    intro u hu
    have hder_ne : iteratedDeriv n p u ≠ 0 := by
      simpa using hu
    have hF_ne : iteratedFDeriv ℝ n p u ≠ 0 := by
      intro hz
      apply hder_ne
      rw [iteratedDeriv_eq_equiv_comp, Function.comp_apply, hz]
      simp
    have huts_p : u ∈ tsupport p :=
      support_iteratedFDeriv_subset n hF_ne
    exact htsR (hp_ts huts_p)

  have hzero : ∀ u : ℝ, u ∉ K → ‖iteratedDeriv n p u‖ = 0 := by
    intro u hu
    by_contra hne
    exact hu (hsupport hne)

  have hinter_eq :
      (∫ u : ℝ, ‖iteratedDeriv n p u‖) =
        ∫ u : ℝ in K, ‖iteratedDeriv n p u‖ := by
    rw [← integral_indicator hKmeas]
    apply integral_congr_ae
    filter_upwards with u
    by_cases hu : u ∈ K
    · simp [hu]
    · simp [hu, hzero u hu]

  rw [hinter_eq]
  dsimp [L]
  exact setIntegral_mono_on hpint.norm.integrableOn
    (integrableOn_const hKfinite) hKmeas hpoint

/-- Smooth compactly supported positive-half-line functions have uniform cubic
Mellin decay throughout the closed critical strip. -/
theorem weil_compact_smooth_mellin_vertical_cubic_decay_v1
    (g : WeilCompactSmoothGV1) :
    HasUniformMellinVerticalCubicDecayV1 g.1 := by
  obtain ⟨L, hL, hLbound⟩ := mellin_weighted_log_profile_uniform_l1_v1 g
  refine ⟨8 * L, by positivity, ?_⟩
  intro σ hσ γ
  let p := MellinWeightedLogProfileV1 g.1 σ
  let ξ : ℝ := γ / (2 * Real.pi)
  have hpcont : ContDiff ℝ ∞ p := mellin_weighted_log_profile_contDiff_v1 g σ
  have hpcontFourier : ContDiff ℝ (3 : ℕ∞) p := by
    exact hpcont.of_le (mod_cast le_top)
  have hpint : ∀ n : ℕ, Integrable (iteratedDeriv n p) :=
    fun n => mellin_weighted_log_profile_deriv_integrable_v1 g σ n
  have hL0 := hLbound σ hσ 0 (by omega)
  have hL3 := hLbound σ hσ 3 (by omega)

  have hmellin :
      mellin g.1 ((σ : ℂ) + (γ : ℂ) * Complex.I) = 𝓕 p ξ := by
    rw [mellin_eq_fourier]
    have hre : (((σ : ℂ) + (γ : ℂ) * Complex.I).re) = σ := by simp
    have him : (((σ : ℂ) + (γ : ℂ) * Complex.I).im) = γ := by simp
    rw [hre, him]
    change 𝓕 (fun u : ℝ => Real.exp (-σ * u) • g.1 (Real.exp (-u)))
        (γ / (2 * Real.pi)) =
      𝓕 (MellinWeightedLogProfileV1 g.1 σ) (γ / (2 * Real.pi))
    have hprofile :
        (fun u : ℝ => Real.exp (-σ * u) • g.1 (Real.exp (-u))) =
          MellinWeightedLogProfileV1 g.1 σ := by
      funext u
      simp [MellinWeightedLogProfileV1, MellinComplexWeightV1,
        MellinWeightV1, MellinLogProfileV1, Complex.real_smul]
    rw [hprofile]

  have hfourier0 : ‖𝓕 p ξ‖ ≤ L := by
    calc
      ‖𝓕 p ξ‖ ≤ ∫ u : ℝ, ‖p u‖ := by
        rw [Real.fourier_eq]
        calc
          ‖∫ u : ℝ, 𝐞 (-inner ℝ u ξ) • p u‖
              ≤ ∫ u : ℝ, ‖𝐞 (-inner ℝ u ξ) • p u‖ :=
                norm_integral_le_integral_norm _
          _ = ∫ u : ℝ, ‖p u‖ := by
            apply integral_congr_ae
            filter_upwards with u
            simp [Circle.norm_smul]
      _ ≤ L := by
        simpa using hL0

  have hfourier3 :
      ‖𝓕 (iteratedDeriv 3 p) ξ‖ ≤ L := by
    calc
      ‖𝓕 (iteratedDeriv 3 p) ξ‖
          ≤ ∫ u : ℝ, ‖iteratedDeriv 3 p u‖ := by
        rw [Real.fourier_eq]
        calc
          ‖∫ u : ℝ, 𝐞 (-inner ℝ u ξ) • iteratedDeriv 3 p u‖
              ≤ ∫ u : ℝ, ‖𝐞 (-inner ℝ u ξ) • iteratedDeriv 3 p u‖ :=
                norm_integral_le_integral_norm _
          _ = ∫ u : ℝ, ‖iteratedDeriv 3 p u‖ := by
            apply integral_congr_ae
            filter_upwards with u
            simp [Circle.norm_smul]
      _ ≤ L := hL3

  have hderiv_fourier :=
    congrFun
      (Real.fourier_iteratedDeriv
        (N := (3 : ℕ∞)) (n := 3) hpcontFourier
        (fun n _ => hpint n) (by norm_num)) ξ

  have hfreq :
      |γ| ^ 3 * ‖𝓕 p ξ‖ ≤ L := by
    have hnormfactor :
        ‖((2 * Real.pi * Complex.I * ξ) ^ 3 : ℂ)‖ = |γ| ^ 3 := by
      simp [ξ, norm_pow, Complex.norm_real,
        Real.norm_eq_abs, abs_of_pos Real.pi_pos]
      field_simp [Real.pi_ne_zero]
    have htmp :
        ‖((2 * Real.pi * Complex.I * ξ) ^ 3 : ℂ) • 𝓕 p ξ‖ ≤ L := by
      rw [← hderiv_fourier]
      exact hfourier3
    simpa [norm_smul, hnormfactor] using htmp

  rw [hmellin]
  by_cases hγ : |γ| ≤ 1
  · calc
      (1 + |γ|) ^ 3 * ‖𝓕 p ξ‖
          ≤ 8 * ‖𝓕 p ξ‖ := by
            have hcube : (1 + |γ|) ^ 3 ≤ (2 : ℝ) ^ 3 := by
              apply pow_le_pow_left₀
              · positivity
              · linarith [abs_nonneg γ]
            norm_num at hcube ⊢
            gcongr
      _ ≤ 8 * L := by gcongr
  · have hγ1 : 1 ≤ |γ| := le_of_not_ge hγ
    have hcube : (1 + |γ|) ^ 3 ≤ 8 * |γ| ^ 3 := by
      have hlin : 1 + |γ| ≤ 2 * |γ| := by linarith
      calc
        (1 + |γ|) ^ 3 ≤ (2 * |γ|) ^ 3 :=
          pow_le_pow_left₀ (by positivity) hlin 3
        _ = 8 * |γ| ^ 3 := by ring
    calc
      (1 + |γ|) ^ 3 * ‖𝓕 p ξ‖
          ≤ (8 * |γ| ^ 3) * ‖𝓕 p ξ‖ := by gcongr
      _ = 8 * (|γ| ^ 3 * ‖𝓕 p ξ‖) := by ring
      _ ≤ 8 * L := by gcongr

/-- Uniform vertical cubic decay implies the existing canonical shell-local
cubic certificate, with the explicit geometric factor eight. -/
theorem uniform_mellin_vertical_cubic_decay_implies_shell_decay_v1
    {f : ℝ → ℂ}
    (h : HasUniformMellinVerticalCubicDecayV1 f) :
    HasCubicShellMellinDecayV1 f := by
  rcases h with ⟨D, hD, hdecay⟩
  refine ⟨8 * D, mul_nonneg (by norm_num) hD, ?_⟩
  intro n rho
  let z : ℂ := rho.1.1
  have hstrip :=
    riemann_zeta_nontrivial_zero_critical_strip_v1 rho.1.2.1 rho.1.2.2
  have hre : z.re ∈ Set.Icc (0 : ℝ) 1 := ⟨hstrip.1.le, hstrip.2.le⟩
  have hs : ((z.re : ℂ) + (z.im : ℂ) * Complex.I) = z := by
    apply Complex.ext <;> simp
  have hv := hdecay z.re hre z.im
  rw [hs] at hv

  have hshell : Nat.ceil |z.im| = n := by
    simpa [z, ZeroHeightShellSetV1, ZeroHeightShellIndexV1] using rho.2
  have hceil : (n : ℝ) < |z.im| + 1 := by
    rw [← hshell]
    exact Nat.ceil_lt_add_one (abs_nonneg z.im)
  let t : ℝ := ((n + 1 : ℕ) : ℝ)
  have ht : 0 < t := by
    dsimp [t]
    positivity
  have hgeom : t ≤ 2 * (1 + |z.im|) := by
    dsimp [t]
    norm_num [Nat.cast_add, Nat.cast_one]
    linarith [abs_nonneg z.im]
  have hgeom3 : t ^ 3 ≤ 8 * (1 + |z.im|) ^ 3 := by
    calc
      t ^ 3 ≤ (2 * (1 + |z.im|)) ^ 3 :=
        pow_le_pow_left₀ (by positivity) hgeom 3
      _ = 8 * (1 + |z.im|) ^ 3 := by ring

  have hscaled :
      t ^ 3 * ‖mellin f z‖ ≤ 8 * D := by
    calc
      t ^ 3 * ‖mellin f z‖
          ≤ (8 * (1 + |z.im|) ^ 3) * ‖mellin f z‖ := by gcongr
      _ = 8 * ((1 + |z.im|) ^ 3 * ‖mellin f z‖) := by ring
      _ ≤ 8 * D := by gcongr
  apply (le_div_iff₀' (pow_pos ht 3)).2
  simpa [t, mul_comm] using hscaled

/-- The existing compact-smooth positive-support domain therefore supplies the
actual shell-local cubic Mellin certificate consumed by PR #479. -/
theorem weil_compact_smooth_has_cubic_shell_mellin_decay_v1
    (g : WeilCompactSmoothGV1) :
    HasCubicShellMellinDecayV1 g.1 :=
  uniform_mellin_vertical_cubic_decay_implies_shell_decay_v1
    (weil_compact_smooth_mellin_vertical_cubic_decay_v1 g)

#check HasUniformMellinVerticalCubicDecayV1
#check weil_compact_smooth_mellin_vertical_cubic_decay_v1
#check uniform_mellin_vertical_cubic_decay_implies_shell_decay_v1
#check weil_compact_smooth_has_cubic_shell_mellin_decay_v1
#print axioms weil_compact_smooth_mellin_vertical_cubic_decay_v1
#print axioms uniform_mellin_vertical_cubic_decay_implies_shell_decay_v1
#print axioms weil_compact_smooth_has_cubic_shell_mellin_decay_v1
~~~~~~

## WeilCriterionCompactSmoothV1

Path: `source/WeilCriterionCompactSmoothV1.lean`

Original source lines: 1–93

Full file SHA256: `cde3befd425dde8eedd28f95b12469279d356ea14f2fd10c8ba9398f8482be53`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilCriterionCompactSmoothV1.lean

~~~~~~lean
import Mathlib.Analysis.MellinTransform
import Mathlib.NumberTheory.ArithmeticFunction.VonMangoldt
import Mathlib.NumberTheory.Harmonic.EulerMascheroni
import Mathlib.NumberTheory.LSeries.RiemannZeta

/-!
AEGIS Ω — conservative Weil/Bombieri criterion domain v1.

Source boundary: Enrico Bombieri's official Clay Mathematics Institute problem
description, Section 5 (printed pp. 121–122), is used only to pin the mathematical
shape of the explicit formula and Weil negativity route.

This file formalizes a compact-smooth positive-half-line subdomain, not Weil's full
class W. It defines the two zero-moment conditions, the autocorrelation shape, and
the right-hand side of the explicit formula using Mathlib primitives.

It proves neither the explicit formula nor the Riemann Hypothesis, and it does not
assert that negativity on this restricted subdomain is equivalent to RH.

FULL_WEIL_CLASS_COVERAGE_OPEN
EXPLICIT_FORMULA_THEOREM_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set
open Complex
open MeasureTheory
open scoped ContDiff

noncomputable section

/-- A conservative smooth compactly-supported subdomain on the positive half-line.
    This is intentionally narrower than Bombieri's full class W. -/
def WeilCompactSmoothGV1 :=
  { g : ℝ → ℂ // ContDiff ℝ ∞ g ∧ HasCompactSupport g ∧ tsupport g ⊆ Set.Ioi 0 }

/-- The two vanishing moments appearing in the Weil criterion route. -/
def WeilMomentConditionsV1 (g : WeilCompactSmoothGV1) : Prop :=
  (∫ x in Set.Ioi (0 : ℝ), g.1 x / (x : ℂ)) = 0 ∧
  (∫ x in Set.Ioi (0 : ℝ), g.1 x) = 0

/-- Multiplicative autocorrelation shape used in Bombieri's statement. -/
def WeilAutocorrelationV1 (g : WeilCompactSmoothGV1) (x : ℝ) : ℂ :=
  ∫ y in Set.Ioi (0 : ℝ), g.1 (x * y) * star (g.1 y)

/-- One positive-integer prime-power term of the explicit-formula right side.
    Index `n` represents the positive integer `n + 1`. -/
def WeilPrimeTermV1 (f : ℝ → ℂ) (n : ℕ) : ℂ :=
  let m : ℕ := n + 1
  ((ArithmeticFunction.vonMangoldt m : ℝ) : ℂ) *
    (f (m : ℝ) + (1 / (m : ℂ)) * f (((m : ℝ))⁻¹))

/-- Prime-power sum from the explicit-formula right side. -/
def WeilPrimeSumV1 (f : ℝ → ℂ) : ℂ :=
  ∑' n : ℕ, WeilPrimeTermV1 f n

/-- Archimedean integrand from the explicit-formula right side. -/
def WeilArchimedeanIntegrandV1 (f : ℝ → ℂ) (x : ℝ) : ℂ :=
  (f x + (1 / (x : ℂ)) * f (x⁻¹) - (2 / (x : ℂ)) * f 1) /
    ((x : ℂ) - ((x⁻¹ : ℝ) : ℂ))

/-- The constant multiplying `f(1)` in Bombieri's normalization. -/
def WeilArchimedeanConstantV1 : ℂ :=
  ((Real.log (4 * Real.pi) + Real.eulerMascheroniConstant : ℝ) : ℂ)

/-- Archimedean integral from `1` to `∞`, represented as a set integral on `(1,∞)`. -/
def WeilArchimedeanIntegralV1 (f : ℝ → ℂ) : ℂ :=
  ∫ x in Set.Ioi (1 : ℝ), WeilArchimedeanIntegrandV1 f x

/-- Concrete right-hand-side expression from the explicit formula. -/
def WeilExplicitRightSideV1 (f : ℝ → ℂ) : ℂ :=
  WeilPrimeSumV1 f + WeilArchimedeanConstantV1 * f 1 + WeilArchimedeanIntegralV1 f

/-- Convergence obligations kept explicit because `tsum` and integrals are totalized in Lean. -/
def WeilExplicitRightSideConvergentV1 (f : ℝ → ℂ) : Prop :=
  Summable (WeilPrimeTermV1 f) ∧
  IntegrableOn (WeilArchimedeanIntegrandV1 f) (Set.Ioi (1 : ℝ))

/-- Negativity candidate on the restricted compact-smooth domain only.
    Reality of the value is included explicitly rather than assumed. -/
def WeilCompactSmoothNegativityV1 : Prop :=
  ∀ g : WeilCompactSmoothGV1,
    WeilMomentConditionsV1 g →
    WeilExplicitRightSideConvergentV1 (WeilAutocorrelationV1 g) →
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).im = 0 ∧
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re ≤ 0

#check WeilCompactSmoothGV1
#check WeilMomentConditionsV1
#check WeilAutocorrelationV1
#check WeilPrimeTermV1
#check WeilExplicitRightSideV1
#check WeilCompactSmoothNegativityV1
~~~~~~

## WeilPrimeLineIdentityV1

Path: `source/WeilPrimeLineIdentityV1.lean`

Original source lines: 1–169

Full file SHA256: `77b44010b7b92b15ab45778826c885fbbba9a69c21b400a7c0f4b01e4ab73dff`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPrimeLineIdentityV1.lean

~~~~~~lean
import Mathlib.Analysis.MellinInversion
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.NumberTheory.LSeries.Dirichlet
import WeilMellinInversionV1

/-!
AEGIS Ω — prime-side Mellin inversion with explicit analytic hypotheses.

The exchange of a Dirichlet series and the height integral is justified by
absolute integrability on the product, derived from L-series summability at a
real point and vertical integrability of the Mellin transform. No contour shift,
zero sum, explicit formula, positivity, or RH implication is asserted here.
-/

open Complex MeasureTheory
open scoped Topology

set_option autoImplicit false

noncomputable section

/-- The norm of an L-series term is constant along a vertical line. -/
theorem lseries_term_vertical_norm_v1
    (a : ℕ → ℂ) (c t : ℝ) (n : ℕ) :
    ‖LSeries.term a ((c : ℂ) + t * I) n‖ =
      ‖LSeries.term a (c : ℂ) n‖ := by
  simp [LSeries.norm_term_eq]

private theorem lseries_term_vertical_continuous_v1
    (a : ℕ → ℂ) (c : ℝ) (n : ℕ) :
    Continuous (fun t : ℝ => LSeries.term a ((c : ℂ) + t * I) n) := by
  by_cases hn : n = 0
  · subst n
    simpa using (continuous_const : Continuous (fun _ : ℝ => (0 : ℂ)))
  · have hnC : (n : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr hn
    simp only [LSeries.term_of_ne_zero hn, Complex.cpow_def_of_ne_zero hnC]
    exact continuous_const.div (by fun_prop) (fun _ => Complex.exp_ne_zero _)

/-- Each product term is integrable; its dominating coefficient is independent
of height. The function `F` need only be vertically integrable. -/
theorem lseries_vertical_product_integrable_v1
    (a : ℕ → ℂ) (F : ℂ → ℂ) (c : ℝ)
    (hF : VerticalIntegrable F c) (n : ℕ) :
    Integrable (fun t : ℝ => LSeries.term a ((c : ℂ) + t * I) n *
      F ((c : ℂ) + t * I)) := by
  refine (hF.norm.const_mul ‖LSeries.term a (c : ℂ) n‖).mono' ?_ ?_
  · exact (lseries_term_vertical_continuous_v1 a c n).aestronglyMeasurable.mul
      hF.aestronglyMeasurable
  · exact Filter.Eventually.of_forall fun t => by
      simp only [norm_mul, lseries_term_vertical_norm_v1]
      exact le_rfl

/-- Absolute product-integral summability, the precise Fubini hypothesis. -/
theorem lseries_vertical_product_integral_norm_summable_v1
    (a : ℕ → ℂ) (F : ℂ → ℂ) (c : ℝ)
    (ha : LSeriesSummable a (c : ℂ)) :
    Summable (fun n : ℕ => ∫ t : ℝ,
      ‖LSeries.term a ((c : ℂ) + t * I) n * F ((c : ℂ) + t * I)‖) := by
  simp_rw [norm_mul, lseries_term_vertical_norm_v1, integral_const_mul]
  exact ha.norm.mul_right _

/-- The prime-side interchange as a `HasSum`, retaining both summability and
the value of the integral. -/
theorem lseries_vertical_product_hasSum_integral_v1
    (a : ℕ → ℂ) (F : ℂ → ℂ) (c : ℝ)
    (ha : LSeriesSummable a (c : ℂ)) (hF : VerticalIntegrable F c) :
    HasSum (fun n : ℕ => ∫ t : ℝ,
      LSeries.term a ((c : ℂ) + t * I) n * F ((c : ℂ) + t * I))
      (∫ t : ℝ, LSeries a ((c : ℂ) + t * I) * F ((c : ℂ) + t * I)) := by
  have h := hasSum_integral_of_summable_integral_norm
    (lseries_vertical_product_integrable_v1 a F c hF)
    (lseries_vertical_product_integral_norm_summable_v1 a F c ha)
  have heq : (∫ t : ℝ, ∑' n : ℕ,
      LSeries.term a ((c : ℂ) + t * I) n * F ((c : ℂ) + t * I)) =
      (∫ t : ℝ, LSeries a ((c : ℂ) + t * I) * F ((c : ℂ) + t * I)) := by
    apply integral_congr_ae
    exact Filter.Eventually.of_forall fun t => by
      have ht : LSeriesSummable a ((c : ℂ) + t * I) :=
        LSeriesSummable.of_re_le_re (by simp) ha
      exact (ht.hasSum.mul_right (F ((c : ℂ) + t * I))).tsum_eq
  rw [heq] at h
  exact h

private theorem lseries_mellin_term_inversion_v1
    (a : ℕ → ℂ) (ha0 : a 0 = 0) (f : ℝ → ℂ) (c : ℝ)
    (hf : MellinConvergent f (c : ℂ))
    (hF : VerticalIntegrable (mellin f) c)
    (hcont : ∀ n : ℕ, n ≠ 0 → ContinuousAt f (n : ℝ)) (n : ℕ) :
    (1 / (2 * Real.pi) : ℝ) •
        (∫ t : ℝ, LSeries.term a ((c : ℂ) + t * I) n *
          mellin f ((c : ℂ) + t * I)) = a n * f (n : ℝ) := by
  by_cases hn : n = 0
  · subst n
    simp [ha0]
  have hinv := mellinInv_mellin_eq c f
    (show (0 : ℝ) < (n : ℝ) by exact_mod_cast Nat.pos_of_ne_zero hn)
    hf hF (hcont n hn)
  calc
    _ = a n * mellinInv c (mellin f) (n : ℝ) := by
      have hk : (fun t : ℝ => LSeries.term a ((c : ℂ) + t * I) n *
          mellin f ((c : ℂ) + t * I)) =
          (fun t : ℝ => a n * ((n : ℂ) ^ (-((c : ℂ) + t * I)) *
            mellin f ((c : ℂ) + t * I))) := by
        funext t
        rw [LSeries.term_def₀ ha0]
        ring
      rw [hk, integral_const_mul]
      simp only [mellinInv, Complex.ofReal_natCast, Complex.real_smul, smul_eq_mul]
      simp only [mul_comm, mul_left_comm, mul_assoc]
    _ = _ := by rw [hinv]

/-- Dirichlet-series/Mellin inversion with the absolute exchange established,
rather than supplied as an assumption. -/
theorem lseries_mellin_prime_line_identity_v1
    (a : ℕ → ℂ) (ha0 : a 0 = 0) (f : ℝ → ℂ) (c : ℝ)
    (ha : LSeriesSummable a (c : ℂ))
    (hf : MellinConvergent f (c : ℂ))
    (hF : VerticalIntegrable (mellin f) c)
    (hcont : ∀ n : ℕ, n ≠ 0 → ContinuousAt f (n : ℝ)) :
    (1 / (2 * Real.pi) : ℝ) •
        (∫ t : ℝ, LSeries a ((c : ℂ) + t * I) *
          mellin f ((c : ℂ) + t * I)) =
      ∑' n : ℕ, a n * f (n : ℝ) := by
  have h := (lseries_vertical_product_hasSum_integral_v1 a (mellin f) c ha hF).const_smul
    (1 / (2 * Real.pi) : ℝ)
  have heq : (fun n : ℕ => (1 / (2 * Real.pi) : ℝ) •
      (∫ t : ℝ, LSeries.term a ((c : ℂ) + t * I) n *
        mellin f ((c : ℂ) + t * I))) = (fun n : ℕ => a n * f (n : ℝ)) := by
    funext n
    exact lseries_mellin_term_inversion_v1 a ha0 f c hf hF hcont n
  rw [heq] at h
  exact h.tsum_eq.symm

/-- Specialization to the negative logarithmic derivative of the actual Riemann
zeta function on `c > 1`; compact support is not required by this abstract form. -/
theorem vonMangoldt_mellin_prime_line_identity_v1
    (f : ℝ → ℂ) (c : ℝ) (hc : 1 < c)
    (hf : MellinConvergent f (c : ℂ))
    (hF : VerticalIntegrable (mellin f) c)
    (hcont : ∀ n : ℕ, n ≠ 0 → ContinuousAt f (n : ℝ)) :
    (1 / (2 * Real.pi) : ℝ) •
        (∫ t : ℝ, (-deriv riemannZeta ((c : ℂ) + t * I) /
          riemannZeta ((c : ℂ) + t * I)) *
          mellin f ((c : ℂ) + t * I)) =
      ∑' n : ℕ, (ArithmeticFunction.vonMangoldt n : ℂ) * f (n : ℝ) := by
  have h := lseries_mellin_prime_line_identity_v1
    (fun n => (ArithmeticFunction.vonMangoldt n : ℂ)) (by simp) f c
    (ArithmeticFunction.LSeriesSummable_vonMangoldt (by simpa using hc)) hf hF hcont
  convert h using 1
  congr 1
  apply integral_congr_ae
  exact Filter.Eventually.of_forall fun t => by
    dsimp only
    rw [ArithmeticFunction.LSeries_vonMangoldt_eq_deriv_riemannZeta_div
      (show 1 < (((c : ℂ) + t * I) : ℂ).re by simpa using hc)]

/-- The prime-line identity for the actual AEGIS test-function class. Its
Mellin convergence, vertical integrability and continuity are proved inputs. -/
theorem weil_compact_smooth_prime_line_identity_v1
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    (1 / (2 * Real.pi) : ℝ) •
        (∫ t : ℝ, (-deriv riemannZeta ((c : ℂ) + t * I) /
          riemannZeta ((c : ℂ) + t * I)) *
          mellin f.1 ((c : ℂ) + t * I)) =
      ∑' n : ℕ, (ArithmeticFunction.vonMangoldt n : ℂ) * f.1 (n : ℝ) := by
  exact vonMangoldt_mellin_prime_line_identity_v1 f.1 c hc
    (weil_compact_smooth_mellin_convergent_all_v1 f c)
    (weil_compact_smooth_mellin_vertical_integrable_all_v1 f c)
    (fun _ _ => f.2.1.continuous.continuousAt)
~~~~~~

## WeilMellinInversionV1

Path: `source/WeilMellinInversionV1.lean`

Original source lines: 1–128

Full file SHA256: `01eacbcd7ea3911cc84407252eb65e42fa1aba30aa72e3eac1592b1252e1336a`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilMellinInversionV1.lean

~~~~~~lean
import MellinDecayEstimateV1
import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier

/-!
Mellin convergence and inversion for the existing compact smooth positive
support class, on every real vertical line. The pinned cubic-decay source is
unchanged; this extension reuses its canonical logarithmic profile definitions.
-/

open Set Filter Topology Complex MeasureTheory
open scoped ContDiff FourierTransform

noncomputable section

private theorem mellin_log_profile_contDiff_v1 (g : WeilCompactSmoothGV1) :
    ContDiff ℝ ∞ (MellinLogProfileV1 g.1) := by
  unfold MellinLogProfileV1
  have hneg : ContDiff ℝ ∞ (fun u : ℝ => -u) := by fun_prop
  exact g.2.1.comp (Real.contDiff_exp.comp hneg)

private theorem mellin_log_profile_hasCompactSupport_v1
    (g : WeilCompactSmoothGV1) :
    HasCompactSupport (MellinLogProfileV1 g.1) := by
  let K : Set ℝ := (fun x : ℝ => -Real.log x) '' tsupport g.1
  have hts : IsCompact (tsupport g.1) := by
    change IsCompact (closure (Function.support g.1))
    exact g.2.2.1
  have hlog : ContinuousOn (fun x : ℝ => -Real.log x) (tsupport g.1) := by
    intro x hx
    have hxpos : 0 < x := g.2.2.2 hx
    exact (Real.continuousAt_log hxpos.ne').neg.continuousWithinAt
  have hK : IsCompact K := hts.image_of_continuousOn hlog
  apply HasCompactSupport.of_support_subset_isCompact hK
  intro u hu
  change g.1 (Real.exp (-u)) ≠ 0 at hu
  have hmem : Real.exp (-u) ∈ tsupport g.1 := subset_closure hu
  refine ⟨Real.exp (-u), hmem, ?_⟩
  simp

private theorem mellin_weight_contDiff_v1 (σ : ℝ) :
    ContDiff ℝ ∞ (MellinWeightV1 σ) := by
  unfold MellinWeightV1
  fun_prop

private theorem mellin_complex_weight_contDiff_v1 (σ : ℝ) :
    ContDiff ℝ ∞ (MellinComplexWeightV1 σ) := by
  unfold MellinComplexWeightV1
  exact (mellin_weight_contDiff_v1 σ).smul_const (1 : ℂ)

private theorem mellin_weighted_log_profile_contDiff_v1
    (g : WeilCompactSmoothGV1) (σ : ℝ) :
    ContDiff ℝ ∞ (MellinWeightedLogProfileV1 g.1 σ) := by
  unfold MellinWeightedLogProfileV1
  exact (mellin_complex_weight_contDiff_v1 σ).mul (mellin_log_profile_contDiff_v1 g)

private theorem mellin_weighted_log_profile_hasCompactSupport_v1
    (g : WeilCompactSmoothGV1) (σ : ℝ) :
    HasCompactSupport (MellinWeightedLogProfileV1 g.1 σ) := by
  have hh : HasCompactSupport (MellinLogProfileV1 g.1) :=
    mellin_log_profile_hasCompactSupport_v1 g
  apply hh.of_isClosed_subset (isClosed_tsupport _)
  change tsupport (fun u : ℝ =>
      MellinComplexWeightV1 σ u * MellinLogProfileV1 g.1 u) ⊆
    tsupport (MellinLogProfileV1 g.1)
  exact tsupport_mul_subset_right


set_option autoImplicit false

/-- Compact positive support gives Mellin convergence at every complex point.
This reuses the existing test-function carrier and the ordinary Mellin integral. -/
theorem weil_compact_smooth_mellin_convergent_all_v1
    (f : WeilCompactSmoothGV1) (s : ℂ) :
    MellinConvergent f.1 s := by
  rw [MellinConvergent]
  let q : ℝ → ℂ := fun t => (t : ℂ) ^ (s - 1) * f.1 t
  have hq_on : ContinuousOn q (Set.Ioi 0) := by
    intro t ht
    exact
      (continuousAt_ofReal_cpow_const _ _ (Or.inr <| ne_of_gt ht)).continuousWithinAt.mul
        f.2.1.continuous.continuousAt.continuousWithinAt
  have hq_ts : tsupport q ⊆ Set.Ioi 0 :=
    (tsupport_mul_subset_right
      (f := fun t : ℝ => (t : ℂ) ^ (s - 1)) (g := f.1)).trans f.2.2.2
  have hq_cont : Continuous q :=
    hq_on.continuous_of_tsupport_subset isOpen_Ioi hq_ts
  have hq_compact : HasCompactSupport q := f.2.2.1.mul_left
  simpa only [q, smul_eq_mul] using
    (hq_cont.integrable_of_hasCompactSupport hq_compact).integrableOn

/-- Every fixed vertical line is integrable. Compact-smooth logarithmic
profiles are Schwartz, so no restriction to the critical strip is needed. -/
theorem weil_compact_smooth_mellin_vertical_integrable_all_v1
    (f : WeilCompactSmoothGV1) (σ : ℝ) :
    VerticalIntegrable (mellin f.1) σ := by
  let p := MellinWeightedLogProfileV1 f.1 σ
  let P : SchwartzMap ℝ ℂ :=
    (mellin_weighted_log_profile_hasCompactSupport_v1 f σ).toSchwartzMap
      (mellin_weighted_log_profile_contDiff_v1 f σ)
  have hFourier : Integrable (𝓕 p) := by
    exact (𝓕 P).integrable
  have hscaled := hFourier.comp_mul_right'
    (inv_ne_zero (show 2 * Real.pi ≠ 0 by positivity))
  have hmellin (γ : ℝ) :
      mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I) =
        𝓕 p (γ / (2 * Real.pi)) := by
    rw [mellin_eq_fourier]
    have hre : (((σ : ℂ) + (γ : ℂ) * Complex.I).re) = σ := by simp
    have him : (((σ : ℂ) + (γ : ℂ) * Complex.I).im) = γ := by simp
    rw [hre, him]
    have hprofile :
        (fun u : ℝ => Real.exp (-σ * u) • f.1 (Real.exp (-u))) = p := by
      funext u
      simp [p, MellinWeightedLogProfileV1, MellinComplexWeightV1,
        MellinWeightV1, MellinLogProfileV1, Complex.real_smul]
    rw [hprofile]
  change Integrable (fun γ : ℝ => mellin f.1 ((σ : ℂ) + (γ : ℂ) * Complex.I))
  simpa only [hmellin, div_eq_mul_inv] using hscaled

/-- Mellin inversion on every real vertical line, with all analytic hypotheses
discharged by the existing compact-smooth positive-support class. -/
theorem weil_compact_smooth_mellin_inversion_v1
    (f : WeilCompactSmoothGV1) (σ : ℝ) {x : ℝ} (hx : 0 < x) :
    mellinInv σ (mellin f.1) x = f.1 x := by
  exact mellinInv_mellin_eq σ f.1 hx
    (weil_compact_smooth_mellin_convergent_all_v1 f σ)
    (weil_compact_smooth_mellin_vertical_integrable_all_v1 f σ)
    f.2.1.continuous.continuousAt
~~~~~~

## WeilAutocorrelationPoleAggregationV1

Path: `source/WeilAutocorrelationPoleAggregationV1.lean`

Original source lines: 1–259

Full file SHA256: `7bb9b15715769f21c6ffd0a3200aa9fccca4bd89c42ae369127e39dd4a1c5429`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilAutocorrelationPoleAggregationV1.lean

~~~~~~lean
import WeilMellinInversionV1
import WeilAutocorrelationClosureV1
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.Tactic

/-!
AEGIS Ω — Mellin endpoint aggregation for the Weil autocorrelation lane.

This module transfers the two-profile aggregation / information-loss pattern
to the two Mellin endpoints of the repository's Lebesgue-measure Weil
autocorrelation.

For endpoint values `a,b : ℂ`, the pole cross-aggregate

  a * conj b + b * conj a

is exactly twice the real part of one cross term. Hence the aggregate loses
the complementary imaginary information: aggregate zero does not force
`a = 0` and `b = 0` separately.

The second layer kernel-binds this algebra to the actual autocorrelation. The
`s = 1` endpoint is proved by compact-support Fubini and the pinned Mathlib
Mellin scaling theorem. The `s = 0` endpoint is transported through the
already verified reciprocal involution for the unchanged `dy` autocorrelation.

No global sign inequality, RH equivalence, admission, or authority effect is
asserted here.
-/

open Set MeasureTheory Complex
open scoped ComplexConjugate

set_option autoImplicit false

noncomputable section

/-- One oriented endpoint cross term. -/
def WeilEndpointCrossTermV1 (a b : ℂ) : ℂ :=
  a * conj b

/-- Symmetric endpoint aggregate. -/
def WeilEndpointPoleAggregateV1 (a b : ℂ) : ℂ :=
  WeilEndpointCrossTermV1 a b + WeilEndpointCrossTermV1 b a

/-- Swapping the two endpoint profiles conjugates the oriented cross term. -/
theorem weil_endpoint_cross_swap_eq_conj_v1 (a b : ℂ) :
    WeilEndpointCrossTermV1 b a = conj (WeilEndpointCrossTermV1 a b) := by
  simp [WeilEndpointCrossTermV1, mul_comm]

/-- The symmetric aggregate remembers only twice the real part of one cross
term. This is the precise lossy projection. -/
theorem weil_endpoint_pole_aggregate_eq_two_re_v1 (a b : ℂ) :
    WeilEndpointPoleAggregateV1 a b =
      (((2 : ℝ) * (WeilEndpointCrossTermV1 a b).re : ℝ) : ℂ) := by
  rw [WeilEndpointPoleAggregateV1, weil_endpoint_cross_swap_eq_conj_v1]
  apply Complex.ext <;> simp <;> ring

/-- If both endpoint profiles vanish, then their pole aggregate vanishes. -/
theorem weil_endpoint_pole_aggregate_zero_of_endpoints_zero_v1
    {a b : ℂ} (ha : a = 0) (hb : b = 0) :
    WeilEndpointPoleAggregateV1 a b = 0 := by
  simp [ha, hb, WeilEndpointPoleAggregateV1, WeilEndpointCrossTermV1]

/-- Concrete collision: two nonzero endpoint profiles can have zero aggregate. -/
theorem weil_endpoint_pole_aggregate_zero_collision_v1 :
    WeilEndpointPoleAggregateV1 (1 : ℂ) Complex.I = 0 := by
  simp [WeilEndpointPoleAggregateV1, WeilEndpointCrossTermV1]

/-- Therefore aggregate zero cannot recover the two endpoint profiles. -/
theorem weil_endpoint_pole_aggregate_zero_not_force_zero_profiles_v1 :
    ∃ a b : ℂ,
      a ≠ 0 ∧ b ≠ 0 ∧ WeilEndpointPoleAggregateV1 a b = 0 := by
  refine ⟨1, Complex.I, ?_, ?_, weil_endpoint_pole_aggregate_zero_collision_v1⟩
  · norm_num
  · simp

/-- The repository's first zero-moment integral is exactly the Mellin endpoint
at `s = 0`. -/
theorem weil_mellin_zero_eq_moment0_v1 (g : WeilCompactSmoothGV1) :
    mellin g.1 0 =
      ∫ x in Ioi (0 : ℝ), g.1 x / (x : ℂ) := by
  unfold mellin
  apply setIntegral_congr_fun measurableSet_Ioi
  intro x hx
  simp [Complex.cpow_neg_one, div_eq_mul_inv, mul_comm]

/-- The repository's second zero-moment integral is exactly the Mellin endpoint
at `s = 1`. -/
theorem weil_mellin_one_eq_moment1_v1 (g : WeilCompactSmoothGV1) :
    mellin g.1 1 =
      ∫ x in Ioi (0 : ℝ), g.1 x := by
  unfold mellin
  apply setIntegral_congr_fun measurableSet_Ioi
  intro x hx
  simp

/-- The existing two-moment condition is a sufficient (but, by the collision
above, algebraically non-minimal) condition for vanishing endpoint aggregate. -/
theorem weil_moment_conditions_endpoint_pole_aggregate_zero_v1
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g) :
    WeilEndpointPoleAggregateV1 (mellin g.1 0) (mellin g.1 1) = 0 := by
  rcases hm with ⟨hm0, hm1⟩
  have h0 : mellin g.1 0 = 0 :=
    (weil_mellin_zero_eq_moment0_v1 g).trans hm0
  have h1 : mellin g.1 1 = 0 :=
    (weil_mellin_one_eq_moment1_v1 g).trans hm1
  exact weil_endpoint_pole_aggregate_zero_of_endpoints_zero_v1 h0 h1

/-- Joint integrand used for the compact-support Fubini step. -/
private def WeilAutocorrelationJointV1 (g : WeilCompactSmoothGV1) (x y : ℝ) : ℂ :=
  g.1 (x * y) * conj (g.1 y)

private theorem weil_autocorrelation_joint_continuous_v1 (g : WeilCompactSmoothGV1) :
    Continuous (Function.uncurry (WeilAutocorrelationJointV1 g)) := by
  exact (g.2.1.continuous.comp (continuous_fst.mul continuous_snd)).mul
    (continuous_star.comp (g.2.1.continuous.comp continuous_snd))

private theorem weil_autocorrelation_joint_tsupport_subset_v1
    (g : WeilCompactSmoothGV1) :
    tsupport (Function.uncurry (WeilAutocorrelationJointV1 g)) ⊆
      WeilAutocorrelationSupportEnvelopeV1 g ×ˢ tsupport g.1 := by
  apply closure_minimal ?_
    ((weil_autocorrelation_support_envelope_compact_v1 g).prod g.2.2.1).isClosed
  intro p hp
  have hy : g.1 p.2 ≠ 0 := by
    intro h
    apply hp
    change g.1 (p.1 * p.2) * conj (g.1 p.2) = 0
    rw [h, map_zero, mul_zero]
  have hxy : g.1 (p.1 * p.2) ≠ 0 := by
    intro h
    apply hp
    change g.1 (p.1 * p.2) * conj (g.1 p.2) = 0
    rw [h, zero_mul]
  have hyK : p.2 ∈ tsupport g.1 := subset_tsupport g.1 hy
  have hxyK : p.1 * p.2 ∈ tsupport g.1 := subset_tsupport g.1 hxy
  refine ⟨?_, hyK⟩
  refine ⟨(p.1 * p.2, p.2), ⟨hxyK, hyK⟩, ?_⟩
  exact mul_div_cancel_right₀ p.1 (ne_of_gt (g.2.2.2 hyK))

private theorem weil_autocorrelation_joint_hasCompactSupport_v1
    (g : WeilCompactSmoothGV1) :
    HasCompactSupport (Function.uncurry (WeilAutocorrelationJointV1 g)) :=
  ((weil_autocorrelation_support_envelope_compact_v1 g).prod g.2.2.1).of_isClosed_subset
    (isClosed_tsupport _) (weil_autocorrelation_joint_tsupport_subset_v1 g)

private theorem weil_autocorrelation_joint_swap_v1 (g : WeilCompactSmoothGV1) :
    (∫ x in Ioi (0 : ℝ), ∫ y in Ioi (0 : ℝ), WeilAutocorrelationJointV1 g x y) =
      ∫ y in Ioi (0 : ℝ), ∫ x in Ioi (0 : ℝ), WeilAutocorrelationJointV1 g x y := by
  exact integral_integral_swap_of_hasCompactSupport
    (μ := volume.restrict (Ioi (0 : ℝ)))
    (ν := volume.restrict (Ioi (0 : ℝ)))
    (weil_autocorrelation_joint_continuous_v1 g)
    (weil_autocorrelation_joint_hasCompactSupport_v1 g)

/-- The `s = 1` Mellin endpoint of the actual autocorrelation factors into
the two endpoint profiles. -/
theorem weil_autocorrelation_mellin_one_factor_v1 (g : WeilCompactSmoothGV1) :
    mellin (WeilAutocorrelationV1 g) 1 =
      mellin g.1 1 * conj (mellin g.1 0) := by
  rw [mellin]
  simp only [sub_self, cpow_zero, one_smul]
  change (∫ x in Ioi (0 : ℝ),
      ∫ y in Ioi (0 : ℝ), WeilAutocorrelationJointV1 g x y) = _
  rw [weil_autocorrelation_joint_swap_v1 g]
  calc
    (∫ y in Ioi (0 : ℝ),
        ∫ x in Ioi (0 : ℝ), WeilAutocorrelationJointV1 g x y) =
        ∫ y in Ioi (0 : ℝ),
          (∫ x in Ioi (0 : ℝ), g.1 (x * y)) * conj (g.1 y) := by
            apply setIntegral_congr_fun measurableSet_Ioi
            intro y hy
            change (∫ x in Ioi (0 : ℝ), g.1 (x * y) * conj (g.1 y)) =
              (∫ x in Ioi (0 : ℝ), g.1 (x * y)) * conj (g.1 y)
            rw [integral_mul_const]
    _ = ∫ y in Ioi (0 : ℝ),
          (((y : ℂ)⁻¹ * mellin g.1 1) * conj (g.1 y)) := by
            apply setIntegral_congr_fun measurableSet_Ioi
            intro y hy
            have hscale :
                (∫ x in Ioi (0 : ℝ), g.1 (x * y)) =
                  (y : ℂ)⁻¹ * mellin g.1 1 := by
              have h := mellin_comp_mul_right g.1 (1 : ℂ) hy
              simpa [mellin, Complex.cpow_neg_one] using h
            change (∫ x in Ioi (0 : ℝ), g.1 (x * y)) * conj (g.1 y) =
              ((y : ℂ)⁻¹ * mellin g.1 1) * conj (g.1 y)
            rw [hscale]
    _ = mellin g.1 1 *
          (∫ y in Ioi (0 : ℝ), (y : ℂ)⁻¹ * conj (g.1 y)) := by
            rw [← integral_const_mul]
            apply setIntegral_congr_fun measurableSet_Ioi
            intro y hy
            ring
    _ = mellin g.1 1 * conj (mellin g.1 0) := by
            congr 1
            rw [weil_mellin_zero_eq_moment0_v1 g, ← integral_conj]
            apply setIntegral_congr_fun measurableSet_Ioi
            intro y hy
            simp [div_eq_mul_inv, mul_comm]

/-- The reciprocal involution of the unchanged `dy` autocorrelation exchanges
the two Mellin endpoints by complex conjugation. -/
theorem weil_autocorrelation_mellin_zero_eq_conj_one_v1
    (g : WeilCompactSmoothGV1) :
    mellin (WeilAutocorrelationV1 g) 0 =
      conj (mellin (WeilAutocorrelationV1 g) 1) := by
  have hinv := mellin_comp_inv (WeilAutocorrelationV1 g) (0 : ℂ)
  simp only [neg_zero] at hinv
  rw [← hinv]
  unfold mellin
  rw [← integral_conj]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro x hx
  simp only [zero_sub, sub_self, cpow_zero, one_smul,
    Complex.cpow_neg_one, smul_eq_mul]
  rw [weil_autocorrelation_reciprocal_v1 g hx]
  have hxC : (x : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (ne_of_gt hx)
  simp [hxC]

/-- The `s = 0` endpoint is the conjugate orientation of the same cross term. -/
theorem weil_autocorrelation_mellin_zero_factor_v1 (g : WeilCompactSmoothGV1) :
    mellin (WeilAutocorrelationV1 g) 0 =
      mellin g.1 0 * conj (mellin g.1 1) := by
  rw [weil_autocorrelation_mellin_zero_eq_conj_one_v1,
    weil_autocorrelation_mellin_one_factor_v1]
  simp [mul_comm]

/-- The actual autocorrelation pole term is exactly the symmetric endpoint
aggregate. -/
theorem weil_autocorrelation_pole_term_eq_endpoint_aggregate_v1
    (g : WeilCompactSmoothGV1) :
    mellin (WeilAutocorrelationV1 g) 0 +
        mellin (WeilAutocorrelationV1 g) 1 =
      WeilEndpointPoleAggregateV1 (mellin g.1 0) (mellin g.1 1) := by
  rw [weil_autocorrelation_mellin_zero_factor_v1,
    weil_autocorrelation_mellin_one_factor_v1]
  rfl

/-- Therefore the actual pole term sees only twice the real part of one
endpoint cross term. -/
theorem weil_autocorrelation_pole_term_eq_two_re_v1 (g : WeilCompactSmoothGV1) :
    mellin (WeilAutocorrelationV1 g) 0 +
        mellin (WeilAutocorrelationV1 g) 1 =
      (((2 : ℝ) *
        (WeilEndpointCrossTermV1 (mellin g.1 0) (mellin g.1 1)).re : ℝ) : ℂ) := by
  rw [weil_autocorrelation_pole_term_eq_endpoint_aggregate_v1,
    weil_endpoint_pole_aggregate_eq_two_re_v1]

/-- The legacy two-zero-moment condition kills the actual autocorrelation pole
term. This proves sufficiency only; the collision theorem above shows that the
endpoint pair is not recoverable from the aggregate. -/
theorem weil_moment_conditions_autocorrelation_pole_term_zero_v1
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g) :
    mellin (WeilAutocorrelationV1 g) 0 +
        mellin (WeilAutocorrelationV1 g) 1 = 0 := by
  rw [weil_autocorrelation_pole_term_eq_endpoint_aggregate_v1]
  exact weil_moment_conditions_endpoint_pole_aggregate_zero_v1 g hm

end
~~~~~~

## WeilAutocorrelationClosureV1

Path: `source/WeilAutocorrelationClosureV1.lean`

Original source lines: 1–153

Full file SHA256: `764b37b7f10cba5603b2c2cb46af799216bade9493a2a41379a60cb31234450a`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilAutocorrelationClosureV1.lean

~~~~~~lean
import WeilArchimedeanConvergenceV1
import WeilAutocorrelationRealityV1
import Mathlib.Analysis.Calculus.ContDiff.Convolution
import Mathlib.Tactic

/-!
Closure of the existing Lebesgue-measure Weil autocorrelation in the existing
compact-smooth positive-support class. The integral and normalization are unchanged.

The support envelope consists of ratios of points of `tsupport g`. Smoothness
uses the fixed compact support of the second factor in the integration variable.
Arithmetic convergence then follows from the existing compact-smooth theorem.

EXPLICIT_FORMULA_OPEN
ARITHMETIC_NEGATIVITY_OPEN
FULL_WEIL_CLASS_COVERAGE_OPEN
RH_EQUIVALENCE_OPEN
RH_NOT_PROVEN
-/

open Set Function MeasureTheory Complex
open scoped ContDiff Convolution ComplexConjugate

set_option autoImplicit false

noncomputable section

/-- A compact ratio envelope; this does not assert equality with the support. -/
def WeilAutocorrelationSupportEnvelopeV1 (g : WeilCompactSmoothGV1) : Set ℝ :=
  (fun p : ℝ × ℝ => p.1 / p.2) '' (tsupport g.1 ×ˢ tsupport g.1)

theorem weil_autocorrelation_support_envelope_compact_v1 (g : WeilCompactSmoothGV1) :
    IsCompact (WeilAutocorrelationSupportEnvelopeV1 g) := by
  apply (g.2.2.1.prod g.2.2.1).image_of_continuousOn
  exact continuous_fst.continuousOn.div continuous_snd.continuousOn
    (fun p hp => ne_of_gt (g.2.2.2 hp.2))

theorem weil_autocorrelation_support_envelope_positive_v1 (g : WeilCompactSmoothGV1) :
    WeilAutocorrelationSupportEnvelopeV1 g ⊆ Ioi 0 := by
  rintro x ⟨p, hp, rfl⟩
  change 0 < p.1 / p.2
  exact div_pos (show 0 < p.1 from g.2.2.2 hp.1)
    (show 0 < p.2 from g.2.2.2 hp.2)

/-- The integrand vanishes unless both arguments lie in the original support. -/
theorem weil_autocorrelation_tsupport_subset_v1 (g : WeilCompactSmoothGV1) :
    tsupport (WeilAutocorrelationV1 g) ⊆ WeilAutocorrelationSupportEnvelopeV1 g := by
  apply closure_minimal ?_ (weil_autocorrelation_support_envelope_compact_v1 g).isClosed
  intro x hx
  by_contra hnot
  apply hx
  apply integral_eq_zero_of_ae
  filter_upwards [] with y
  by_cases hy : g.1 y = 0
  · simp [hy]
  · have hyK : y ∈ tsupport g.1 := subset_tsupport g.1 hy
    have hxy : g.1 (x * y) = 0 := by
      by_contra hxy
      apply hnot
      refine ⟨(x * y, y), ⟨subset_tsupport g.1 hxy, hyK⟩, ?_⟩
      exact mul_div_cancel_right₀ x (ne_of_gt (g.2.2.2 hyK))
    simp [hxy]

theorem weil_autocorrelation_hasCompactSupport_v1 (g : WeilCompactSmoothGV1) :
    HasCompactSupport (WeilAutocorrelationV1 g) :=
  (weil_autocorrelation_support_envelope_compact_v1 g).of_isClosed_subset
    (isClosed_tsupport _) (weil_autocorrelation_tsupport_subset_v1 g)

theorem weil_autocorrelation_tsupport_positive_v1 (g : WeilCompactSmoothGV1) :
    tsupport (WeilAutocorrelationV1 g) ⊆ Ioi 0 :=
  (weil_autocorrelation_tsupport_subset_v1 g).trans
    (weil_autocorrelation_support_envelope_positive_v1 g)

/-- Pointwise existence of the actual autocorrelation integral, independently
of the convention that Lean assigns values to nonintegrable integrals. -/
theorem weil_autocorrelation_integrand_integrable_v1 (g : WeilCompactSmoothGV1) (x : ℝ) :
    IntegrableOn (fun y : ℝ => g.1 (x * y) * star (g.1 y)) (Ioi 0) := by
  have hc : Continuous (fun y : ℝ => g.1 (x * y) * star (g.1 y)) := by
    exact (g.2.1.continuous.comp (continuous_const.mul continuous_id)).mul
      (continuous_star.comp g.2.1.continuous)
  have hk : HasCompactSupport (fun y : ℝ => g.1 (x * y) * star (g.1 y)) := by
    apply HasCompactSupport.intro g.2.2.1
    intro y hy
    simp [image_eq_zero_of_notMem_tsupport hy]
  exact (hc.integrable_of_hasCompactSupport hk).integrableOn

/-- Smoothness follows from a fixed compact support in the integration variable.
The auxiliary convolution is evaluated at zero and rewrites exactly to the
original integral with measure `volume.restrict (Ioi 0)`. -/
theorem weil_autocorrelation_contDiff_v1 (g : WeilCompactSmoothGV1) :
    ContDiff ℝ ∞ (WeilAutocorrelationV1 g) := by
  let F : ℝ → ℝ → ℂ := fun p z => g.1 (p * (-z)) * conj (g.1 (-z))
  have hF : ContDiff ℝ ∞ (fun q : ℝ × ℝ => F q.1 q.2) :=
    (g.2.1.comp (contDiff_fst.mul contDiff_snd.neg)).mul
      (Complex.conjCLE.contDiff.comp (g.2.1.comp contDiff_snd.neg))
  have hsupport : ∀ p z : ℝ, p ∈ (univ : Set ℝ) →
      z ∉ (fun y : ℝ => -y) '' tsupport g.1 → F p z = 0 := by
    intro p z _ hz
    have hneg : -z ∉ tsupport g.1 := by
      intro h
      exact hz ⟨-z, h, neg_neg z⟩
    simp [F, image_eq_zero_of_notMem_tsupport hneg]
  have H := contDiffOn_convolution_right_with_param_comp
    (μ := volume.restrict (Ioi (0 : ℝ)))
    (ContinuousLinearMap.lsmul ℝ ℝ)
    (v := fun _ : ℝ => (0 : ℝ)) (n := (⊤ : ℕ∞)) contDiffOn_const
    isOpen_univ (g.2.2.1.image continuous_neg) hsupport
    (locallyIntegrable_const (μ := volume.restrict (Ioi (0 : ℝ))) (1 : ℝ))
    hF.contDiffOn
  rw [← contDiffOn_univ]
  change ContDiffOn ℝ ∞
    (fun x : ℝ => ∫ y in Ioi (0 : ℝ), g.1 (x * y) * star (g.1 y)) univ
  simpa only [convolution, F, zero_sub, neg_neg,
    ContinuousLinearMap.lsmul_apply, one_smul,
    Complex.star_def] using H

/-- Repackage the original function with proved class membership. -/
def WeilAutocorrelationCompactSmoothV1 (g : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  ⟨WeilAutocorrelationV1 g, weil_autocorrelation_contDiff_v1 g,
    weil_autocorrelation_hasCompactSupport_v1 g, weil_autocorrelation_tsupport_positive_v1 g⟩

theorem weil_autocorrelation_compact_smooth_coe_v1 (g : WeilCompactSmoothGV1) :
    (WeilAutocorrelationCompactSmoothV1 g).1 = WeilAutocorrelationV1 g := rfl

/-- Discharge the convergence premise using the unchanged arithmetic theorem. -/
theorem weil_autocorrelation_explicit_right_side_convergent_v1 (g : WeilCompactSmoothGV1) :
    WeilExplicitRightSideConvergentV1 (WeilAutocorrelationV1 g) :=
  weil_compact_smooth_explicit_right_side_convergent_v1
    (WeilAutocorrelationCompactSmoothV1 g)

/-- The original candidate is equivalent to its remaining real sign inequality.
Neither that inequality nor the candidate is asserted here. -/
theorem weil_compact_smooth_negativity_iff_unconditional_real_inequality_v1 :
    WeilCompactSmoothNegativityV1 ↔
      ∀ g : WeilCompactSmoothGV1, WeilMomentConditionsV1 g →
        (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re ≤ 0 := by
  rw [weil_compact_smooth_negativity_iff_real_inequality_v1]
  constructor
  · intro h g hm
    exact h g hm (weil_autocorrelation_explicit_right_side_convergent_v1 g)
  · intro h g hm _
    exact h g hm

#print axioms weil_autocorrelation_support_envelope_compact_v1
#print axioms weil_autocorrelation_support_envelope_positive_v1
#print axioms weil_autocorrelation_tsupport_subset_v1
#print axioms weil_autocorrelation_hasCompactSupport_v1
#print axioms weil_autocorrelation_tsupport_positive_v1
#print axioms weil_autocorrelation_integrand_integrable_v1
#print axioms weil_autocorrelation_contDiff_v1
#print axioms weil_autocorrelation_compact_smooth_coe_v1
#print axioms weil_autocorrelation_explicit_right_side_convergent_v1
#print axioms weil_compact_smooth_negativity_iff_unconditional_real_inequality_v1
~~~~~~

## WeilArchimedeanConvergenceV1

Path: `source/WeilArchimedeanConvergenceV1.lean`

Original source lines: 1–155

Full file SHA256: `84c286ab801f6647def8450b0f6979a81a73ab2e436f4a2e835c5caef470bfd8`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilArchimedeanConvergenceV1.lean

~~~~~~lean
import WeilPrimeSummabilityV1
import Mathlib.Analysis.Calculus.DSlope
import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals

/-!
The archimedean integral in the existing Weil normalization is integrable on
the repository's compact-smooth test-function domain.  The apparent singularity
at 1 is removed by a divided difference; compact support away from 0 makes the
tail a constant multiple of `(x^2 - 1)⁻¹`.

These are convergence statements.  No explicit-formula identity or sign
inequality is assumed or established here.
-/

open Set Complex MeasureTheory
open scoped ContDiff

set_option autoImplicit false

noncomputable section

/-- Multiplying numerator and denominator by `x` exposes the quadratic tail. -/
theorem weil_archimedean_integrand_rational_v1 (f : ℝ → ℂ) {x : ℝ}
    (hx : 1 < x) :
    WeilArchimedeanIntegrandV1 f x =
      ((x : ℂ) * f x + f x⁻¹ - 2 * f 1) / ((x : ℂ) ^ 2 - 1) := by
  have hx0 : (x : ℂ) ≠ 0 := by exact_mod_cast (show x ≠ 0 by linarith)
  have hq : (x : ℂ) ^ 2 - 1 ≠ 0 := by
    exact_mod_cast (show x ^ 2 - 1 ≠ 0 by nlinarith)
  have hd : (x : ℂ) - (x : ℂ)⁻¹ ≠ 0 := by
    have hi : x⁻¹ < 1 := inv_lt_one_of_one_lt₀ hx
    have hr : x - x⁻¹ ≠ 0 := by linarith
    exact_mod_cast hr
  simp only [WeilArchimedeanIntegrandV1, Complex.ofReal_inv]
  field_simp [hx0, hq, hd]
  <;> ring

/-- The divided difference supplies the finite continuous extension at 1. -/
theorem weil_archimedean_integrand_dslope_v1 (f : ℝ → ℂ) {x : ℝ}
    (hx : 1 < x) :
    WeilArchimedeanIntegrandV1 f x =
      dslope (fun t : ℝ => (t : ℂ) * f t + f t⁻¹) 1 x / ((x : ℂ) + 1) := by
  rw [weil_archimedean_integrand_rational_v1 f hx,
    dslope_of_ne _ (ne_of_gt hx)]
  simp only [slope, vsub_eq_sub, Complex.real_smul, Complex.ofReal_inv,
    Complex.ofReal_sub, Complex.ofReal_one, inv_one, one_mul]
  have hm : (x : ℂ) - 1 ≠ 0 := by
    exact_mod_cast (show x - 1 ≠ 0 by linarith)
  have hp : (x : ℂ) + 1 ≠ 0 := by
    exact_mod_cast (show x + 1 ≠ 0 by linarith)
  have hq : (x : ℂ) ^ 2 - 1 ≠ 0 := by
    exact_mod_cast (show x ^ 2 - 1 ≠ 0 by nlinarith)
  field_simp [hm, hp, hq]
  <;> ring

private theorem weil_archimedean_aux_differentiable_v1 (f : WeilCompactSmoothGV1)
    {x : ℝ} (hx : x ≠ 0) :
    DifferentiableAt ℝ (fun t : ℝ => (t : ℂ) * f.1 t + f.1 t⁻¹) x := by
  have hf : Differentiable ℝ f.1 := f.2.1.differentiable (by simp)
  exact ((Complex.differentiable_ofReal x).mul (hf x)).add
    ((hf x⁻¹).comp x (differentiableAt_id.inv hx))

/-- Integrability across the apparent endpoint singularity, on every bounded interval. -/
theorem weil_compact_smooth_archimedean_integrableOn_Ioc_v1
    (f : WeilCompactSmoothGV1) (R : ℝ) :
    IntegrableOn (WeilArchimedeanIntegrandV1 f.1) (Ioc 1 R) := by
  let n : ℝ → ℂ := fun t => (t : ℂ) * f.1 t + f.1 t⁻¹
  have hs : ContinuousOn (dslope n 1) (Icc 1 R) := by
    intro x hx
    by_cases he : x = 1
    · subst x
      exact (continuousAt_dslope_same.mpr
        (weil_archimedean_aux_differentiable_v1 f one_ne_zero)).continuousWithinAt
    · apply (continuousWithinAt_dslope_of_ne he).mpr
      exact (weil_archimedean_aux_differentiable_v1 f
        (show x ≠ 0 by linarith [hx.1])).continuousAt.continuousWithinAt
  have hc : ContinuousOn (fun x : ℝ => dslope n 1 x / ((x : ℂ) + 1)) (Icc 1 R) := by
    apply hs.div (Complex.continuous_ofReal.continuousOn.add continuousOn_const)
    intro x hx
    change (x : ℂ) + 1 ≠ 0
    exact_mod_cast (show x + 1 ≠ 0 by linarith [hx.1])
  refine (hc.integrableOn_Icc.mono_set Ioc_subset_Icc_self).congr_fun ?_
    measurableSet_Ioc
  intro x hx
  exact (weil_archimedean_integrand_dslope_v1 f.1 hx.1).symm

/-- The compact-support tail is bounded by an integrable inverse square. -/
theorem weil_archimedean_integrand_tail_bound_v1 (f : ℝ → ℂ) {x : ℝ}
    (hx : 2 ≤ x) (hz : f x = 0 ∧ f x⁻¹ = 0) :
    ‖WeilArchimedeanIntegrandV1 f x‖ ≤ (4 * ‖f 1‖) * x ^ (-2 : ℝ) := by
  have hx1 : 1 < x := by linarith
  have hq : 0 < x ^ 2 - 1 := by nlinarith
  have hs : 0 < x ^ 2 := by nlinarith
  have he : WeilArchimedeanIntegrandV1 f x =
      -(2 * f 1) / (((x ^ 2 - 1 : ℝ) : ℂ)) := by
    rw [weil_archimedean_integrand_rational_v1 f hx1]
    simp only [hz.1, hz.2, mul_zero, zero_add, zero_sub, Complex.ofReal_sub,
      Complex.ofReal_pow, Complex.ofReal_one]
  rw [he, norm_div, norm_neg, norm_mul]
  simp only [Complex.norm_ofNat, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hq]
  calc
    2 * ‖f 1‖ / (x ^ 2 - 1) ≤ 4 * ‖f 1‖ / x ^ 2 := by
      apply (div_le_div_iff₀ hq hs).mpr
      have hnon : 0 ≤ ‖f 1‖ * (x ^ 2 - 2) :=
        mul_nonneg (norm_nonneg _) (by nlinarith)
      nlinarith
    _ = (4 * ‖f 1‖) * x ^ (-2 : ℝ) := by
      simp [Real.rpow_neg_ofNat, zpow_neg, div_eq_mul_inv]

/-- The existing archimedean integrand is integrable for every existing test function. -/
theorem weil_compact_smooth_archimedean_integrable_v1 (f : WeilCompactSmoothGV1) :
    IntegrableOn (WeilArchimedeanIntegrandV1 f.1) (Ioi 1) := by
  obtain ⟨R, hR, hz⟩ := weil_compact_smooth_eventually_zero_and_inv_v1 f
  have hRp : 0 < R := by linarith
  have hc : ContinuousOn (WeilArchimedeanIntegrandV1 f.1) (Ioi R) := by
    have hcq : ContinuousOn
        (fun x : ℝ => ((x : ℂ) * f.1 x + f.1 x⁻¹ - 2 * f.1 1) /
          ((x : ℂ) ^ 2 - 1)) (Ioi R) := by
      intro x hx
      change R < x at hx
      have hxp : 1 < x := by linarith [hx]
      have hn := (weil_archimedean_aux_differentiable_v1 f
        (show x ≠ 0 by linarith)).continuousAt
      have hd : (x : ℂ) ^ 2 - 1 ≠ 0 := by
        exact_mod_cast (show x ^ 2 - 1 ≠ 0 by nlinarith)
      exact ((hn.sub continuousAt_const).div
        ((Complex.continuous_ofReal.continuousAt.pow 2).sub continuousAt_const)
        hd).continuousWithinAt
    apply hcq.congr
    intro x hx
    change R < x at hx
    exact weil_archimedean_integrand_rational_v1 f.1 (x := x) (by linarith)
  have hp : IntegrableOn (fun x : ℝ => x ^ (-2 : ℝ)) (Ioi R) :=
    integrableOn_Ioi_rpow_of_lt (by norm_num) hRp
  have ht : IntegrableOn (WeilArchimedeanIntegrandV1 f.1) (Ioi R) := by
    apply (hp.const_mul (4 * ‖f.1 1‖)).mono'
      (hc.aestronglyMeasurable measurableSet_Ioi)
    filter_upwards [self_mem_ae_restrict measurableSet_Ioi] with x hx
    exact weil_archimedean_integrand_tail_bound_v1 f.1
      (hR.trans (le_of_lt hx)) (hz x (le_of_lt hx))
  have hu := integrableOn_union.mpr
    ⟨weil_compact_smooth_archimedean_integrableOn_Ioc_v1 f R, ht⟩
  apply hu.mono_set
  intro x hx
  by_cases hxR : x ≤ R
  · exact Or.inl ⟨hx, hxR⟩
  · exact Or.inr (lt_of_not_ge hxR)

/-- Both explicit right-side convergence obligations are now discharged on the
repository's compact-smooth domain; the identity with zeros is a separate theorem. -/
theorem weil_compact_smooth_explicit_right_side_convergent_v1
    (f : WeilCompactSmoothGV1) : WeilExplicitRightSideConvergentV1 f.1 := by
  exact ⟨weil_compact_smooth_prime_summable_v1 f,
    weil_compact_smooth_archimedean_integrable_v1 f⟩
~~~~~~

## WeilPrimeSummabilityV1

Path: `source/WeilPrimeSummabilityV1.lean`

Original source lines: 1–106

Full file SHA256: `6b1c23496a8b4252b858a80cd9f2d6e4cbca3adef68953fc8c45d7e2f67ea98f`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPrimeSummabilityV1.lean

~~~~~~lean
import WeilCriterionCompactSmoothV1
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.Algebra.InfiniteSum.Basic

/-!
AEGIS Ω — finite prime-power support on the existing Weil test-function class.

Compact support contained in the positive half-line bounds both the support and
its reciprocal image. Consequently both evaluations in `WeilPrimeTermV1`
vanish above one finite cutoff. This proves actual summability of the existing
prime term, independently of any zero-counting or explicit-formula identity.

EXPLICIT_FORMULA_THEOREM_OPEN
WEIL_NEGATIVITY_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set Function

set_option autoImplicit false

noncomputable section

/-- Positive compact support supplies a common real cutoff for a function and
its reciprocal evaluation. Smoothness is not needed for this statement. -/
theorem weil_eventually_zero_and_inv_of_compact_positive_support_v1
    (f : ℝ → ℂ) (hf : HasCompactSupport f)
    (hpos : tsupport f ⊆ Set.Ioi 0) :
    ∃ R : ℝ, 2 ≤ R ∧ ∀ x : ℝ, R ≤ x → f x = 0 ∧ f x⁻¹ = 0 := by
  have hK : IsCompact (tsupport f) := hf
  have hinv : ContinuousOn (fun x : ℝ => x⁻¹) (tsupport f) :=
    continuousOn_id.inv₀ (fun x hx => ne_of_gt (hpos hx))
  obtain ⟨A, hA⟩ := hK.bddAbove
  obtain ⟨B, hB⟩ := (hK.image_of_continuousOn hinv).bddAbove
  let R : ℝ := max 2 (max A B + 1)
  have hAR : A < R := calc
    A ≤ max A B := le_max_left _ _
    _ < max A B + 1 := by linarith
    _ ≤ R := le_max_right _ _
  have hBR : B < R := calc
    B ≤ max A B := le_max_right _ _
    _ < max A B + 1 := by linarith
    _ ≤ R := le_max_right _ _
  refine ⟨R, le_max_left _ _, ?_⟩
  intro x hx
  constructor
  · apply image_eq_zero_of_notMem_tsupport
    intro hmem
    exact (not_le_of_gt (lt_of_lt_of_le hAR hx)) (hA hmem)
  · apply image_eq_zero_of_notMem_tsupport
    intro hmem
    have hxin : x ∈ (fun y : ℝ => y⁻¹) '' tsupport f :=
      ⟨x⁻¹, hmem, inv_inv x⟩
    exact (not_le_of_gt (lt_of_lt_of_le hBR hx)) (hB hxin)

/-- The common real cutoff specialized to the repository's existing class. -/
theorem weil_compact_smooth_eventually_zero_and_inv_v1
    (f : WeilCompactSmoothGV1) :
    ∃ R : ℝ, 2 ≤ R ∧ ∀ x : ℝ, R ≤ x → f.1 x = 0 ∧ f.1 x⁻¹ = 0 :=
  weil_eventually_zero_and_inv_of_compact_positive_support_v1
    f.1 f.2.2.1 f.2.2.2

/-- The existing prime-power term vanishes at every sufficiently large index. -/
theorem weil_compact_smooth_prime_term_cutoff_v1
    (f : WeilCompactSmoothGV1) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n → WeilPrimeTermV1 f.1 n = 0 := by
  obtain ⟨R, _, hR⟩ := weil_compact_smooth_eventually_zero_and_inv_v1 f
  obtain ⟨N, hN⟩ := exists_nat_gt R
  refine ⟨N, ?_⟩
  intro n hn
  have hnR : R ≤ ((n + 1 : ℕ) : ℝ) := by
    apply le_trans hN.le
    exact_mod_cast hn.trans (Nat.le_succ n)
  obtain ⟨hlarge, hsmall⟩ := hR ((n + 1 : ℕ) : ℝ) hnR
  simp only [WeilPrimeTermV1, hlarge, hsmall, mul_zero, add_zero]

/-- There are only finitely many nonzero prime-power terms. -/
theorem weil_compact_smooth_prime_term_hasFiniteSupport_v1
    (f : WeilCompactSmoothGV1) :
    Function.HasFiniteSupport (WeilPrimeTermV1 f.1) := by
  classical
  obtain ⟨N, hN⟩ := weil_compact_smooth_prime_term_cutoff_v1 f
  refine (Finset.range N).finite_toSet.subset ?_
  intro n hn
  change WeilPrimeTermV1 f.1 n ≠ 0 at hn
  simp only [Finset.mem_coe, Finset.mem_range]
  by_contra hnot
  exact hn (hN n (Nat.le_of_not_gt hnot))

/-- The repository's prime-power series is summable for every compact-smooth
test function; no formal identity with the zero sum is asserted here. -/
theorem weil_compact_smooth_prime_summable_v1
    (f : WeilCompactSmoothGV1) : Summable (WeilPrimeTermV1 f.1) :=
  summable_of_hasFiniteSupport
    (weil_compact_smooth_prime_term_hasFiniteSupport_v1 f)

/-- The totalized prime `tsum` agrees with an actual finite sum. -/
theorem weil_compact_smooth_prime_sum_eq_finite_sum_v1
    (f : WeilCompactSmoothGV1) :
    ∃ N : ℕ, WeilPrimeSumV1 f.1 =
      ∑ n ∈ Finset.range N, WeilPrimeTermV1 f.1 n := by
  obtain ⟨N, hN⟩ := weil_compact_smooth_prime_term_cutoff_v1 f
  refine ⟨N, ?_⟩
  apply tsum_eq_sum
  intro n hn
  exact hN n (Nat.le_of_not_gt (by simpa using hn))
~~~~~~

## WeilAutocorrelationRealityV1

Path: `source/WeilAutocorrelationRealityV1.lean`

Original source lines: 1–132

Full file SHA256: `d7ed312feef5e19156a564e339f241369e2b3794f933324a874c927593704d84`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilAutocorrelationRealityV1.lean

~~~~~~lean
import WeilCriterionCompactSmoothV1
import Mathlib.MeasureTheory.Integral.IntegralEqImproper
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Topology.Algebra.InfiniteSum.Constructions
import Mathlib.Tactic

/-!
AEGIS Ω — autocorrelation involution and reality of the arithmetic expression.

The change of variables uses the positive-half-line Lebesgue measure, including
its scaling factor. Reality does not supply the remaining sign inequality.
The generic reality theorem also holds for Lean's totalized sums/integrals;
it must not be used as evidence that those expressions converge.

EXPLICIT_FORMULA_OPEN
ARITHMETIC_NEGATIVITY_OPEN
RH_EQUIVALENCE_OPEN
-/

open Set MeasureTheory Complex
open scoped ComplexConjugate

set_option autoImplicit false

noncomputable section

/-- The reciprocal identity includes the Jacobian `x` for the repository's
Lebesgue-measure autocorrelation (which does not use `dy / y`). -/
theorem weil_autocorrelation_reciprocal_v1 (g : WeilCompactSmoothGV1)
    {x : ℝ} (hx : 0 < x) :
    WeilAutocorrelationV1 g x⁻¹ =
      (x : ℂ) * conj (WeilAutocorrelationV1 g x) := by
  have hchange := integral_comp_mul_left_Ioi'
    (fun y : ℝ => g.1 (x⁻¹ * y) * conj (g.1 y)) 0 hx
  simp only [mul_zero, inv_mul_cancel_left₀ hx.ne'] at hchange
  have hconj :
      (∫ y in Ioi (0 : ℝ), g.1 y * conj (g.1 (x * y))) =
        conj (∫ y in Ioi (0 : ℝ), g.1 (x * y) * conj (g.1 y)) := by
    rw [← integral_conj]
    apply integral_congr_ae
    filter_upwards [] with y
    simp [mul_comm]
  simpa only [WeilAutocorrelationV1, Complex.star_def, hconj,
    Complex.real_smul] using hchange.symm

/-- At the identity, the autocorrelation is real. -/
theorem weil_autocorrelation_one_real_v1 (g : WeilCompactSmoothGV1) :
    (WeilAutocorrelationV1 g 1).im = 0 := by
  apply Complex.conj_eq_iff_im.mp
  simpa using (weil_autocorrelation_reciprocal_v1 g (x := 1) zero_lt_one).symm

private theorem reflected_term_eq_conj_v1 (f : ℝ → ℂ)
    (hf : ∀ x : ℝ, 0 < x → f x⁻¹ = (x : ℂ) * conj (f x))
    {x : ℝ} (hx : 0 < x) :
    (1 / (x : ℂ)) * f x⁻¹ = conj (f x) := by
  rw [hf x hx]
  have hxC : (x : ℂ) ≠ 0 := by exact_mod_cast hx.ne'
  simp [div_eq_mul_inv, ← mul_assoc, hxC]

/-- Positive-integer prime terms are fixed by conjugation under the exact
reciprocal involution; no sign is inferred. -/
theorem weil_prime_term_conj_of_reciprocal_v1 (f : ℝ → ℂ)
    (hf : ∀ x : ℝ, 0 < x → f x⁻¹ = (x : ℂ) * conj (f x)) (n : ℕ) :
    conj (WeilPrimeTermV1 f n) = WeilPrimeTermV1 f n := by
  have hn : (0 : ℝ) < (n + 1 : ℕ) := by positivity
  have href : (1 / ((n + 1 : ℕ) : ℂ)) * f (((n + 1 : ℕ) : ℝ)⁻¹) =
      conj (f ((n + 1 : ℕ) : ℝ)) := by
    simpa only [Complex.ofReal_natCast] using reflected_term_eq_conj_v1 f hf hn
  simp only [WeilPrimeTermV1]
  rw [href]
  simp [add_comm]

/-- The archimedean integrand is real on its integration domain. -/
theorem weil_archimedean_integrand_conj_of_reciprocal_v1 (f : ℝ → ℂ)
    (hf : ∀ x : ℝ, 0 < x → f x⁻¹ = (x : ℂ) * conj (f x))
    {x : ℝ} (hx : 1 < x) :
    conj (WeilArchimedeanIntegrandV1 f x) = WeilArchimedeanIntegrandV1 f x := by
  have h1 : conj (f 1) = f 1 := by simpa using (hf 1 zero_lt_one).symm
  unfold WeilArchimedeanIntegrandV1
  rw [reflected_term_eq_conj_v1 f hf (lt_trans zero_lt_one hx)]
  simp [h1, add_comm, Complex.conj_ofNat]

/-- Reality is an algebraic consequence of the reciprocal identity. This does
not discharge the separately defined convergence obligations. -/
theorem weil_explicit_right_side_real_of_reciprocal_v1 (f : ℝ → ℂ)
    (hf : ∀ x : ℝ, 0 < x → f x⁻¹ = (x : ℂ) * conj (f x)) :
    (WeilExplicitRightSideV1 f).im = 0 := by
  have hp : conj (WeilPrimeSumV1 f) = WeilPrimeSumV1 f := by
    change star (∑' n : ℕ, WeilPrimeTermV1 f n) = ∑' n : ℕ, WeilPrimeTermV1 f n
    rw [tsum_star]
    apply tsum_congr
    intro n
    exact weil_prime_term_conj_of_reciprocal_v1 f hf n
  have ha : conj (WeilArchimedeanIntegralV1 f) = WeilArchimedeanIntegralV1 f := by
    unfold WeilArchimedeanIntegralV1
    rw [← integral_conj]
    apply setIntegral_congr_fun measurableSet_Ioi
    intro x hx
    exact weil_archimedean_integrand_conj_of_reciprocal_v1 f hf hx
  have h1 : conj (f 1) = f 1 := by simpa using (hf 1 zero_lt_one).symm
  apply Complex.conj_eq_iff_im.mp
  simp only [WeilExplicitRightSideV1, map_add, map_mul, hp, ha, h1,
    WeilArchimedeanConstantV1, Complex.conj_ofReal]

/-- The reality conjunct of the existing negativity candidate follows without
the explicit formula, zero localization, or a sign assumption. -/
theorem weil_autocorrelation_explicit_right_side_real_v1 (g : WeilCompactSmoothGV1) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).im = 0 := by
  apply weil_explicit_right_side_real_of_reciprocal_v1
  intro x hx
  exact weil_autocorrelation_reciprocal_v1 g hx

/-- The existing negativity candidate reduces to its real inequality. The
convergence premise is retained verbatim, rather than silently removed. -/
theorem weil_compact_smooth_negativity_iff_real_inequality_v1 :
    WeilCompactSmoothNegativityV1 ↔
      ∀ g : WeilCompactSmoothGV1, WeilMomentConditionsV1 g →
        WeilExplicitRightSideConvergentV1 (WeilAutocorrelationV1 g) →
        (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re ≤ 0 := by
  constructor
  · intro h g hm hc
    exact (h g hm hc).2
  · intro h g hm hc
    exact ⟨weil_autocorrelation_explicit_right_side_real_v1 g, h g hm hc⟩

#print axioms weil_autocorrelation_reciprocal_v1
#print axioms weil_autocorrelation_one_real_v1
#print axioms weil_prime_term_conj_of_reciprocal_v1
#print axioms weil_archimedean_integrand_conj_of_reciprocal_v1
#print axioms weil_explicit_right_side_real_of_reciprocal_v1
#print axioms weil_autocorrelation_explicit_right_side_real_v1
#print axioms weil_compact_smooth_negativity_iff_real_inequality_v1
~~~~~~

## WeilPoleTermV1

Path: `source/WeilPoleTermV1.lean`

Original source lines: 1–77

Full file SHA256: `0f9649cec81bbfde0b5f57c99edcb46d20a903dc039168a445e9157e1212157a`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPoleTermV1.lean

~~~~~~lean
/-
AEGIS Ω — pole and prime-generating-function binding for the fixed-line Weil lane.

This is the theorem-bearing pole surface from PR #510, ported onto the #507
Lean 4.33.1 / Mathlib 0df444a3 pin.  The moving-contour obligation from #510
is deliberately NOT imported: the adopted #490 paired-Hadamard proof works on
a fixed line c > 1 and explicitly does not use horizontal contour segments.

This module proves only the pole residue and the von-Mangoldt L-series binding.
It does not prove the whole explicit formula, an arithmetic sign, global Weil
positivity, or RH.
-/
import Mathlib.NumberTheory.Harmonic.ZetaAsymp
import Mathlib.NumberTheory.LSeries.Dirichlet

open Filter Topology Complex

namespace WeilPoleTerm

noncomputable def zeta1LogDeriv (s : ℂ) : ℂ := deriv riemannZeta₁ s / riemannZeta₁ s

theorem zeta1LogDeriv_tendsto : Tendsto zeta1LogDeriv (𝓝 1) (𝓝 (deriv riemannZeta₁ 1)) := by
  have : ContinuousAt zeta1LogDeriv 1 := by
    apply ContinuousAt.div
    · exact (differentiable_riemannZeta₁.deriv).continuous.continuousAt
    · exact differentiable_riemannZeta₁.continuous.continuousAt
    · simp [riemannZeta₁_one]
  simpa [zeta1LogDeriv, riemannZeta₁_one] using this.tendsto

/-- `-ζ'/ζ` has a simple pole at `s = 1` with residue `1`. -/
theorem neg_logDeriv_riemannZeta_residue_one :
    Tendsto (fun s : ℂ => (s - 1) * (-(deriv riemannZeta s / riemannZeta s)))
      (𝓝[≠] 1) (𝓝 1) := by
  have key : (fun s : ℂ => (s - 1) * (-(deriv riemannZeta s / riemannZeta s)))
      =ᶠ[𝓝[≠] 1] (fun s : ℂ => 1 - (s - 1) * zeta1LogDeriv s) := by
    filter_upwards [log_deriv_riemannZeta_eq_neg_inv_sub_add, self_mem_nhdsWithin] with s hs hne
    have h1 : s - 1 ≠ 0 := sub_ne_zero_of_ne hne
    rw [hs, zeta1LogDeriv]
    field_simp
    ring
  rw [tendsto_congr' key]
  have h0 : Tendsto (fun s : ℂ => s - 1) (𝓝[≠] 1) (𝓝 0) := by
    have h : Tendsto (fun s : ℂ => s - 1) (𝓝 1) (𝓝 ((1 : ℂ) - 1)) :=
      tendsto_id.sub tendsto_const_nhds
    rw [sub_self] at h
    exact h.mono_left nhdsWithin_le_nhds
  have h1 := zeta1LogDeriv_tendsto.mono_left (nhdsWithin_le_nhds (s := {(1 : ℂ)}ᶜ))
  simpa using tendsto_const_nhds.sub (h0.mul h1)

/-- For any transform continuous at `1`, the pole residue of `(-ζ'/ζ) F`
is exactly `F 1`. -/
theorem weil_pole_term_v1 (F : ℂ → ℂ) (hF : ContinuousAt F 1) :
    Tendsto (fun s : ℂ => (s - 1) * (-(deriv riemannZeta s / riemannZeta s)) * F s)
      (𝓝[≠] 1) (𝓝 (F 1)) := by
  simpa using
    neg_logDeriv_riemannZeta_residue_one.mul (hF.tendsto.mono_left nhdsWithin_le_nhds)

theorem weil_pole_term_ne_zero_v1 (F : ℂ → ℂ) (hF : ContinuousAt F 1) (h1 : F 1 ≠ 0) :
    ∃ L : ℂ, L ≠ 0 ∧
      Tendsto (fun s : ℂ => (s - 1) * (-(deriv riemannZeta s / riemannZeta s)) * F s)
        (𝓝[≠] 1) (𝓝 L) :=
  ⟨F 1, h1, weil_pole_term_v1 F hF⟩

/-- On `Re s > 1`, the von-Mangoldt L-series is the same `-ζ'/ζ` whose pole
was identified above. -/
theorem vonMangoldt_lseries_eq_neg_logDeriv_v1 {s : ℂ} (hs : 1 < s.re) :
    LSeries (fun n => (ArithmeticFunction.vonMangoldt n : ℂ)) s
      = -(deriv riemannZeta s / riemannZeta s) := by
  simpa [neg_div] using ArithmeticFunction.LSeries_vonMangoldt_eq_deriv_riemannZeta_div hs

end WeilPoleTerm

#print axioms WeilPoleTerm.zeta1LogDeriv_tendsto
#print axioms WeilPoleTerm.neg_logDeriv_riemannZeta_residue_one
#print axioms WeilPoleTerm.weil_pole_term_v1
#print axioms WeilPoleTerm.weil_pole_term_ne_zero_v1
#print axioms WeilPoleTerm.vonMangoldt_lseries_eq_neg_logDeriv_v1
~~~~~~

## Lc.LiCriterion.HadamardBridge

Path: `source/Lc/LiCriterion/HadamardBridge.lean`

Original source lines: 1–136

Full file SHA256: `a44c65e65a71689137b6db995b8ee9a41a6fcb63c0fcd0258dbf5afdd2816f9d`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Lc/LiCriterion/HadamardBridge.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Lc.LiCriterion.Basic
import Hadamard.General

/-!
# The Hadamard bridge for `ξ`

Specializes the general genus-1 Hadamard factorization to `riemannXi`, with multiplicities:
the zero set of `ξ` as a `Hadamard.ZeroSetMultiplicity`, and the resulting `E₁` product.
-/

open Complex

namespace LiCriterion

/-- The nontrivial zeros of `riemannXi`, indexed once each and weighted by their analytic order. -/
noncomputable def xiZeroSetMultiplicity : Hadamard.ZeroSetMultiplicity riemannXi where
  Zero := NontrivialZero
  z := fun ρ => ρ.val
  isZero := by
    intro ρ
    exact (xi_zeros_are_nontrivial_zeros (s := ρ.val)).2 ⟨ρ, rfl⟩
  mult := fun ρ => analyticOrderNatAt riemannXi ρ.val
  mult_pos := by
    intro ρ
    have hρ_zero : riemannXi ρ.val = 0 :=
      (xi_zeros_are_nontrivial_zeros (s := ρ.val)).2 ⟨ρ, rfl⟩
    have hxi_analytic : AnalyticOnNhd ℂ riemannXi Set.univ := by
      intro z _
      exact xi_entire.analyticAt z
    have h0_order_ne_top : analyticOrderAt riemannXi 0 ≠ ⊤ := by
      have h0_order_zero : analyticOrderAt riemannXi 0 = 0 := by
        exact (xi_entire.analyticAt 0).analyticOrderAt_eq_zero.2 (by
          unfold riemannXi
          norm_num)
      simp [h0_order_zero]
    have hρ_analytic : AnalyticAt ℂ riemannXi ρ.val := xi_entire.analyticAt ρ.val
    have hρ_order_ne_top : analyticOrderAt riemannXi ρ.val ≠ ⊤ :=
      AnalyticOnNhd.analyticOrderAt_ne_top_of_isPreconnected
        (hf := hxi_analytic) (U := Set.univ) (x := 0) (y := ρ.val)
        isPreconnected_univ (by simp) (by simp) h0_order_ne_top
    have hρ_orderAt_ne_zero : analyticOrderAt riemannXi ρ.val ≠ 0 :=
      (hρ_analytic.analyticOrderAt_ne_zero).2 hρ_zero
    have hρ_orderNat_ne_zero : analyticOrderNatAt riemannXi ρ.val ≠ 0 := by
      intro hzero
      exact hρ_orderAt_ne_zero
        (by simpa [hzero] using (Nat.cast_analyticOrderNatAt hρ_order_ne_top).symm)
    exact Nat.pos_of_ne_zero hρ_orderNat_ne_zero

noncomputable instance : Countable xiZeroSetMultiplicity.Zero := by
  simpa [xiZeroSetMultiplicity] using (inferInstance : Countable NontrivialZero)

/-- The honest genus-1 canonical product for `riemannXi`, counted with multiplicity. -/
noncomputable def xiMultiplicityE1Prod (s : ℂ) : ℂ :=
  xiZeroSetMultiplicity.canonicalProductZeroSetMultiplicity s

@[simp] theorem xiMultiplicityE1Prod_eq_xiE1ProdWithMultiplicity (s : ℂ) :
    xiMultiplicityE1Prod s = xiE1ProdWithMultiplicity s := by
  rfl

/-- General Hadamard factorization for `riemannXi`, specialized to order `≤ 1`. -/
theorem xi_hadamard_factorization_with_multiplicity_polynomial
    (hfinite : Hadamard.hasFiniteOrder riemannXi)
    (horder : Hadamard.order riemannXi ≤ 1) :
    ∃ g : Polynomial ℂ,
      g.natDegree ≤ 1 ∧
      ∀ s : ℂ,
        riemannXi s =
          Complex.exp (g.eval s) *
            Hadamard.canonicalProductZeroSetMultiplicityRank xiZeroSetMultiplicity 1 s := by
  have h_zeros_only :
      ∀ s : ℂ,
        riemannXi s = 0 ↔ ∃ ρ : xiZeroSetMultiplicity.Zero, s = xiZeroSetMultiplicity.z ρ := by
    intro s
    simpa [xiZeroSetMultiplicity] using (xi_zeros_are_nontrivial_zeros (s := s))
  have h_inj : Function.Injective xiZeroSetMultiplicity.z := by
    intro ρ ρ' h
    exact Subtype.ext h
  have h_z_ne_zero : ∀ ρ : xiZeroSetMultiplicity.Zero, xiZeroSetMultiplicity.z ρ ≠ 0 := by
    intro ρ
    exact ρ.ne_zero
  have h_mult :
      ∀ ρ : xiZeroSetMultiplicity.Zero,
        analyticOrderNatAt riemannXi (xiZeroSetMultiplicity.z ρ) =
          xiZeroSetMultiplicity.mult ρ := by
    intro ρ
    rfl
  simpa using
    (Hadamard.hadamard_factorization_general
      (f := riemannXi)
      (hf_entire := xi_entire)
      (hf_finite := hfinite)
      (lam := 1)
      (hlam := by positivity)
      (hf_order_le := horder)
      (Z := xiZeroSetMultiplicity)
      (h_zeros_only := h_zeros_only)
      (h_inj := h_inj)
      (h_z_ne_zero := h_z_ne_zero)
      (h_mult := h_mult))

/-- A linear-exponential form of the multiplicity-aware Hadamard factorization for `riemannXi`. -/
theorem xi_hadamard_factorization_with_multiplicity
    (hfinite : Hadamard.hasFiniteOrder riemannXi)
    (horder : Hadamard.order riemannXi ≤ 1) :
    ∃ a b : ℂ, ∀ s : ℂ,
      riemannXi s = Complex.exp (a * s + b) * xiMultiplicityE1Prod s := by
  obtain ⟨g, hgdeg, hgfac⟩ :=
    xi_hadamard_factorization_with_multiplicity_polynomial hfinite horder
  obtain ⟨a, b, hab⟩ := Hadamard.polynomial_eval_eq_linear_of_natDegree_le_one g hgdeg
  refine ⟨a, b, ?_⟩
  intro s
  calc
    riemannXi s
        = Complex.exp (g.eval s) *
            Hadamard.canonicalProductZeroSetMultiplicityRank xiZeroSetMultiplicity 1 s := hgfac s
    _ = Complex.exp (a * s + b) *
          Hadamard.canonicalProductZeroSetMultiplicityRank xiZeroSetMultiplicity 1 s := by
            rw [hab s]
    _ = Complex.exp (a * s + b) * xiMultiplicityE1Prod s := by
          simp [xiMultiplicityE1Prod, Hadamard.canonicalProductZeroSetMultiplicityRank_one]

theorem xi_factorization_prod_with_multiplicity_of_hadamard_order_one
    (hfinite : Hadamard.hasFiniteOrder riemannXi)
    (horder : Hadamard.order riemannXi ≤ 1) :
    xi_factorization_prod_with_multiplicity := by
  obtain ⟨a, b, hξ⟩ := xi_hadamard_factorization_with_multiplicity hfinite horder
  refine ⟨a, b, ?_⟩
  intro s
  simpa using hξ s

end LiCriterion
~~~~~~

## Hadamard.General

Path: `source/Hadamard/General.lean`

Original source lines: 1–28

Full file SHA256: `4218ddf7b78eef826f696cc9078300bff707b215f096425de125743e1640ab33`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/General.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
/-
General finite-order Hadamard factorization — public entry point.

Import this file for the multiplicity-aware, any-finite-order version of
Hadamard's factorization theorem (Conway XI.3.4).
-/

import Hadamard.General.Factorization

/-!
# Genus-1 Hadamard factorization

Aggregator for the general order-`≤ 1` factorization theorem.
-/

namespace Hadamard

export General
  ( canonicalProductZeroSetMultiplicityRank
    canonicalProductZeroSetMultiplicityRank_one
    hadamard_factorization_general )

end Hadamard
~~~~~~

