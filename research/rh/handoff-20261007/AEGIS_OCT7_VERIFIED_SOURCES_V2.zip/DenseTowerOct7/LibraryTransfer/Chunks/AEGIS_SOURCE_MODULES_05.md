# AEGIS source modules 5

Exact pinned or operator archive source. Compilation was not performed during transfer.

## FunctionsOfOneComplexVariable.BorelCaratheodory

Path: `source/FunctionsOfOneComplexVariable/BorelCaratheodory.lean`

Original source lines: 1–510

Full file SHA256: `c455ada13da3cc6688e613baffab127bed5b2683a8032a88ba3b41d231ce56ff`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/FunctionsOfOneComplexVariable/BorelCaratheodory.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
/-
  Borel–Carathéodory Theorem

  This file scaffolds the proof of the Borel–Carathéodory inequality following the
  handwritten notes.

  **Main Result**:
  If g is holomorphic on the closed disk of radius R and z satisfies ‖z‖ ≤ r < R, then
    ‖g(z)‖ ≤ (2r/(R-r)) * (A - Re(g(0))) + ‖g(0)‖
  where A = sup{Re(g(ζ)) : ‖ζ‖ = R}.
-/

import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.Analytic.Basic
import Mathlib.Analysis.Calculus.FDeriv.Basic
import Mathlib.Topology.MetricSpace.Basic
import Mathlib.Analysis.Complex.Schwarz
import Mathlib.Analysis.Complex.AbsMax

/-!
# The Borel–Carathéodory inequality

A bound on `‖g‖` on a disk in terms of the supremum of `re g` on a larger disk.
-/

open Complex Real Filter Topology
open scoped BigOperators ComplexConjugate

namespace LZCBorelCaratheodory
noncomputable section

-- Define the boundary supremum using conditionally complete lattice
noncomputable def boundaryRealSup (g : ℂ → ℂ) (R : ℝ) : ℝ :=
  sSup {x | ∃ ζ : ℂ, ‖ζ‖ = R ∧ x = (g ζ).re}

lemma real_part_le_boundaryRealSup (g : ℂ → ℂ) (R : ℝ)
    (h_bdd : BddAbove {x | ∃ ζ : ℂ, ‖ζ‖ = R ∧ x = (g ζ).re})
    {ζ : ℂ} (hζ : ‖ζ‖ = R) :
    (g ζ).re ≤ boundaryRealSup g R := by
  unfold boundaryRealSup
  apply le_csSup h_bdd
  exact ⟨ζ, hζ, rfl⟩

/-- On the closed ball `‖w‖ ≤ R`, the real part of `g` is bounded by the boundary
supremum. This follows from the maximum principle for harmonic functions. -/
lemma real_part_le_boundaryRealSup_closedBall (g : ℂ → ℂ) (R : ℝ)
    (_h_R : 0 < R)
    (h_holo : ∀ w : ℂ, ‖w‖ ≤ R → DifferentiableAt ℂ g w)
    (h_bdd : BddAbove {x | ∃ ζ : ℂ, ‖ζ‖ = R ∧ x = (g ζ).re})
    {w : ℂ} (hw : ‖w‖ ≤ R) :
    (g w).re ≤ boundaryRealSup g R := by
  set A := boundaryRealSup g R with hA_def
  -- Strategy: Apply maximum modulus principle to exp(g)
  -- Since ‖exp(g(z))‖ = exp(Re(g(z))), bounding ‖exp(g)‖ bounds Re(g)
  set f := Complex.exp ∘ g with hf_def
  have hf_diff : ∀ z : ℂ, ‖z‖ < R → DifferentiableAt ℂ f z := by
    intro z hz
    apply DifferentiableAt.comp
    · exact Complex.differentiableAt_exp
    · exact h_holo z (le_of_lt hz)
  have norm_exp_eq : ∀ z, ‖f z‖ = Real.exp (g z).re := by
    intro z
    simp [f, Complex.norm_exp]
  have h_boundary : ∀ ζ : ℂ, ‖ζ‖ = R → ‖f ζ‖ ≤ Real.exp A := by
    intro ζ hζ
    rw [norm_exp_eq]
    apply Real.exp_le_exp.mpr
    exact real_part_le_boundaryRealSup g R h_bdd hζ
  have hf_le : ‖f w‖ ≤ Real.exp A := by
    by_cases hw_strict : ‖w‖ < R
    · -- Case: ‖w‖ < R (interior point)
      set U := Metric.ball (0 : ℂ) R with hU_def
      have hU_bdd : Bornology.IsBounded U := Metric.isBounded_ball
      have hf_diffcont : DiffContOnCl ℂ f U := by
        constructor
        · intro z hz
          have hz_norm : ‖z‖ < R := by
            simpa only [U, Metric.mem_ball, dist_eq_norm, sub_zero] using hz
          exact (hf_diff z hz_norm).differentiableWithinAt
        · intro z hz
          have hz_norm : ‖z‖ ≤ R := by
            apply Metric.closure_ball_subset_closedBall at hz
            simpa only [Metric.mem_closedBall, dist_eq_norm, sub_zero] using hz
          have : DifferentiableAt ℂ f z := by
            apply DifferentiableAt.comp
            · exact Complex.differentiableAt_exp
            · exact h_holo z hz_norm
          exact this.continuousAt.continuousWithinAt
      have hw_closure : w ∈ closure U := by
        apply subset_closure
        simpa only [U, Metric.mem_ball, dist_eq_norm, sub_zero] using hw_strict
      apply Complex.norm_le_of_forall_mem_frontier_norm_le hU_bdd hf_diffcont _ hw_closure
      intro z hz
      have hz_sphere : ‖z‖ = R := by
        have : z ∈ frontier U → ‖z‖ ≤ R := by
          intro h
          have := frontier_subset_closure h
          have := Metric.closure_ball_subset_closedBall this
          simpa only [Metric.mem_closedBall, dist_eq_norm, sub_zero] using this
        have hz_le : ‖z‖ ≤ R := this hz
        have hz_ge : R ≤ ‖z‖ := by
          by_contra h
          push Not at h
          have : z ∈ U := by
            simpa only [U, Metric.mem_ball, dist_eq_norm, sub_zero] using h
          have hz_interior : z ∈ interior U := by
            rw [Metric.isOpen_ball.interior_eq]
            exact this
          have h_disj : Disjoint (interior U) (frontier U) := disjoint_interior_frontier
          have : z ∉ frontier U := Set.disjoint_left.mp h_disj hz_interior
          contradiction
        exact le_antisymm hz_le hz_ge
      exact h_boundary z hz_sphere
    · -- Case: ‖w‖ = R (boundary point)
      push Not at hw_strict
      have hw_eq : ‖w‖ = R := le_antisymm hw hw_strict
      exact h_boundary w hw_eq
  rw [norm_exp_eq] at hf_le
  exact Real.exp_le_exp.mp hf_le

/-- Möbius transformation used in the Borel-Carathéodory proof.
For a > 0, this maps w ↦ w/(2a - w). -/
def mobius (a : ℝ) (w : ℂ) : ℂ := w / (2 * a - w)

lemma mobius_zero (a : ℝ) : mobius a 0 = 0 := by
  simp [mobius]

/-- If Re(w) < a, then |mobius a w| < 1. -/
lemma mobius_maps_to_unit_ball (a : ℝ) (ha : 0 < a) (w : ℂ)
    (hw : w.re < a) : ‖mobius a w‖ < 1 := by
  unfold mobius
  -- Need to show |w/(2a - w)| < 1, i.e., |w| < |2a - w|
  rw [norm_div]
  rw [div_lt_one]
  · -- Show |w| < |2a - w|
    have norm_sq_ineq : Complex.normSq w < Complex.normSq ((2 * a : ℂ) - w) := by
      rw [Complex.normSq_apply, Complex.normSq_apply]
      simp [sub_re, sub_im, ofReal_re, ofReal_im]
      -- w.re² + w.im² < (2a - w.re)² + w.im²
      nlinarith [sq_nonneg (a - w.re), hw]
    calc ‖w‖
        = Real.sqrt (Complex.normSq w) := by rw [Complex.norm_def]
      _ < Real.sqrt (Complex.normSq ((2 * a : ℂ) - w)) :=
          Real.sqrt_lt_sqrt (Complex.normSq_nonneg _) norm_sq_ineq
      _ = ‖(2 * a : ℂ) - w‖ := by rw [Complex.norm_def]
  · -- Show 2a - w ≠ 0
    exact norm_pos_iff.mpr <| by
      intro h_eq
      have h_re_eq : (2 * a : ℂ).re = w.re := by
        have := congr_arg Complex.re h_eq
        simp [sub_re] at this
        linarith
      have : 2 * a = w.re := by simpa using h_re_eq
      linarith

/-- The Möbius transformation mobius a is differentiable where 2*a - w ≠ 0. -/
lemma mobius_differentiable (a : ℝ) (w : ℂ) (hw : (2 * a : ℂ) - w ≠ 0) :
    DifferentiableAt ℂ (mobius a) w := by
  unfold mobius
  apply DifferentiableAt.div
  · exact differentiableAt_id
  · apply DifferentiableAt.sub
    · exact differentiableAt_const _
    · exact differentiableAt_id
  · exact hw

/-- If w/(2a - w) = y, then |w| = 2a|y|/|1+y|. This is a key algebraic step.
Requires a > 0 to ensure the formula has the right sign. -/
lemma mobius_norm_formula (a : ℝ) (ha : 0 < a) (w y : ℂ)
    (hdenom : (2 * a : ℂ) - w ≠ 0)
    (heq : w / ((2 * a : ℂ) - w) = y)
    (hy_ne : y ≠ -1) :
    ‖w‖ = (2 * a) * ‖y‖ / ‖1 + y‖ := by
  -- From w / (2a - w) = y, derive w = y * (2a - w) by multiplying both sides
  have w_eq : w = y * ((2 * a : ℂ) - w) := by
    rw [div_eq_iff hdenom] at heq
    exact heq
  -- Expand: w = 2ay - yw, so w + yw = 2ay, thus w(1+y) = 2ay
  have w_times_one_plus_y : w * (1 + y) = (2 * a : ℂ) * y := by
    linear_combination w_eq
  -- Divide by (1 + y) to get w = 2ay / (1+y)
  have one_plus_y_ne_zero : (1 : ℂ) + y ≠ 0 := by
    intro h
    have : y = -1 := by
      linear_combination h
    exact hy_ne this
  have w_formula : w = (2 * a : ℂ) * y / (1 + y) := by
    rw [eq_div_iff one_plus_y_ne_zero]
    exact w_times_one_plus_y
  -- Take norms
  calc ‖w‖
      = ‖(2 * a : ℂ) * y / (1 + y)‖ := by rw [w_formula]
    _ = ‖(2 * a : ℂ) * y‖ / ‖1 + y‖ := norm_div _ _
    _ = ‖(2 * a : ℂ)‖ * ‖y‖ / ‖1 + y‖ := by rw [norm_mul]
    _ = (2 * a) * ‖y‖ / ‖1 + y‖ := by
        have h : ‖(2 * a : ℂ)‖ = 2 * a := by
          norm_cast
          exact abs_of_pos (by linarith : 0 < 2 * a)
        rw [h]

/-- Helper lemma: if y = w/(2a - w) and Re(w) < a, then |y| < 1.
This avoids duplicating the proof from mobius_maps_to_unit_ball. -/
lemma norm_lt_one_of_div_eq (a : ℝ) (ha : 0 < a) (w y : ℂ)
    (hw : w.re < a)
    (heq : w / ((2 * a : ℂ) - w) = y) : ‖y‖ < 1 := by
  rw [← heq]
  exact mobius_maps_to_unit_ball a ha w hw

/-- The function t ↦ t/(1-t) is monotonically increasing on [0, 1). -/
lemma div_one_sub_mono {x y : ℝ} (_hx : 0 ≤ x) (hy : y < 1) (hxy : x ≤ y) :
    x / (1 - x) ≤ y / (1 - y) := by
  have hx1 : x < 1 := lt_of_le_of_lt hxy hy
  have h1x : 0 < 1 - x := by linarith
  have h1y : 0 < 1 - y := by linarith
  exact (div_le_div_iff₀ h1x h1y).2 (by nlinarith)

/-- A bundled structure for functions that map ball(0, R) into closedBall(0, 1),
    are holomorphic, and fix the origin. This abstraction prevents
    excessive unfolding when composing functions like Möbius transformations. -/
structure BallToUnitBall (R : ℝ) where
  /-- The underlying function -/
  toFun : ℂ → ℂ
  /-- The function maps the ball of radius R into the closed unit ball -/
  maps_to : Set.MapsTo toFun (Metric.ball 0 R) (Metric.closedBall 0 1)
  /-- The function is holomorphic on the ball -/
  differentiable : DifferentiableOn ℂ toFun (Metric.ball 0 R)
  /-- The function fixes 0 -/
  maps_zero : toFun 0 = 0

namespace BallToUnitBall

instance (R : ℝ) : CoeFun (BallToUnitBall R) (fun _ => ℂ → ℂ) where
  coe := BallToUnitBall.toFun

/-- The Schwarz lemma for bundled ball-to-ball functions -/
theorem schwarz_bound {R : ℝ} (f : BallToUnitBall R) {z : ℂ} (hz : z ∈ Metric.ball 0 R) :
    ‖f.toFun z‖ ≤ ‖z‖ / R := by
  have h_R : 0 < R := Metric.nonempty_ball.mp ⟨z, hz⟩
  -- Apply mathlib's Schwarz lemma
  have h_maps' : Set.MapsTo f.toFun (Metric.ball 0 R) (Metric.closedBall (f.toFun 0) 1) := by
    rw [f.maps_zero]
    exact f.maps_to
  have key : dist (f.toFun z) (f.toFun 0) ≤ 1 / R * dist z 0 :=
    Complex.dist_le_div_mul_dist_of_mapsTo_ball f.differentiable h_maps' hz
  rw [f.maps_zero] at key
  simp only [dist_zero_right] at key
  calc ‖f.toFun z‖ ≤ 1 / R * ‖z‖ := key
    _ = ‖z‖ / R := by ring

end BallToUnitBall

/-- Inversion bound for Möbius transformation: if y = w/(2a - w) and |y| < 1,
then |w| ≤ 2a|y|/(1 - |y|).

This lemma is stated without direct reference to `mobius` to avoid type checking issues. -/
lemma mobius_inversion_bound (a : ℝ) (ha : 0 < a) (w : ℂ)
    (hw_re : w.re < a) (y : ℂ)
    (hdenom : (2 * a : ℂ) - w ≠ 0)
    (heq : w / ((2 * a : ℂ) - w) = y) :
    ‖w‖ ≤ (2 * a) * (‖y‖ / (1 - ‖y‖)) := by
  -- Step 1: Show |y| < 1 using the helper lemma
  have y_bound : ‖y‖ < 1 := norm_lt_one_of_div_eq a ha w y hw_re heq
  -- Step 2: Show y ≠ -1 from |y| < 1
  have y_ne_neg_one : y ≠ -1 := by
    intro h
    have : ‖y‖ = 1 := by simp [h, norm_neg]
    linarith
  -- Step 3: Apply mobius_norm_formula
  have w_norm_eq := mobius_norm_formula a ha w y hdenom heq y_ne_neg_one
  -- Step 4: Reverse triangle inequality: 1 - ‖y‖ ≤ ‖1 + y‖
  -- Direct proof using triangle inequality
  have reverse_triangle : 1 - ‖y‖ ≤ ‖1 + y‖ := by
    have h1 : ‖(1 : ℂ)‖ = 1 := by simp
    have h2 : (1 : ℂ) = (1 + y) + (-y) := by ring
    have h3 : ‖(1 : ℂ)‖ ≤ ‖1 + y‖ + ‖-y‖ := by
      conv_lhs => rw [h2]
      exact norm_add_le (1 + y) (-y)
    have h4 : ‖-y‖ = ‖y‖ := norm_neg y
    linarith
  -- Step 5: Conclude
  calc ‖w‖
      = (2 * a) * ‖y‖ / ‖1 + y‖ := w_norm_eq
    _ ≤ (2 * a) * ‖y‖ / (1 - ‖y‖) := by
        apply div_le_div_of_nonneg_left
        · exact mul_nonneg (by linarith : 0 ≤ 2 * a) (norm_nonneg y)
        · linarith
        · exact reverse_triangle
    _ = (2 * a) * (‖y‖ / (1 - ‖y‖)) := by rw [mul_div_assoc]

/-- **Borel–Carathéodory Theorem (Point-wise version)**.

If `g : ℂ → ℂ` is holomorphic on the closed disk `‖z‖ ≤ R` and `r < R`, then for any
`z` with `‖z‖ ≤ r`, we have
  `‖g z‖ ≤ (2r/(R-r)) * (A - Re(g(0))) + ‖g(0)‖`
where `A := sup {Re(g(ζ)) : ‖ζ‖ = R}`.

**Proof strategy**:
1. Use maximum modulus principle to show Re(g(w)) ≤ A for all ‖w‖ ≤ R
2. For any ε > 0, construct auxiliary function h_ε mapping ball(0,R) → ball(0,1)
3. Apply Schwarz lemma to h_ε
4. Take ε → 0 to get the final bound
-/
lemma borel_caratheodory_point (g : ℂ → ℂ) (R r : ℝ)
    (h_R : 0 < R) (h_r : r < R)
    (h_holo : ∀ z : ℂ, ‖z‖ ≤ R → DifferentiableAt ℂ g z)
    (h_bdd : BddAbove {x | ∃ ζ : ℂ, ‖ζ‖ = R ∧ x = (g ζ).re}) :
    ∀ z : ℂ, ‖z‖ ≤ r →
      ‖g z‖ ≤
        (2 * r / (R - r)) *
          (boundaryRealSup g R - (g 0).re) + ‖g 0‖ := by
  intro z hz
  -- Define the boundary supremum
  set A : ℝ := boundaryRealSup g R with hA_def
  -- Step 1: Show Re(g(w)) ≤ A for all ‖w‖ ≤ R via maximum modulus principle
  have re_le_A : ∀ w : ℂ, ‖w‖ ≤ R → (g w).re ≤ A := by
    intro w hw
    exact real_part_le_boundaryRealSup_closedBall g R h_R h_holo h_bdd hw
  -- Step 2: For any ε > 0, construct auxiliary map h_ε
  have main_eps : ∀ ε > 0,
      ‖g z‖ ≤ (2 * r / (R - r)) * (A - (g 0).re + ε) + ‖g 0‖ := by
    intro ε hε
    -- Define a := A - Re g(0) + ε > 0
    set a : ℝ := A - (g 0).re + ε with ha_def
    have ha_pos : 0 < a := by
      have h_g0_le_A : (g 0).re ≤ A := re_le_A 0 (by simp [h_R.le] : ‖(0:ℂ)‖ ≤ R)
      linarith
    -- **Bundle the function as a BallToUnitBall to avoid unfolding**
    -- Define v(w) = g(w) - g(0) and hεf = mobius a ∘ v
    let v : ℂ → ℂ := fun w => g w - g 0
    -- Construct hεf as a bundled BallToUnitBall structure
    let hεf : BallToUnitBall R := {
      toFun := mobius a ∘ v

      maps_to := by
        intro w hw
        simp only [Metric.mem_ball, dist_zero_right] at hw
        simp only [Metric.mem_closedBall, dist_zero_right, Function.comp_def]
        apply le_of_lt
        apply mobius_maps_to_unit_ball a ha_pos
        change (g w - g 0).re < a
        have hw_le : ‖w‖ ≤ R := le_of_lt hw
        have : (g w).re ≤ A := re_le_A w hw_le
        calc (g w - g 0).re
            = (g w).re - (g 0).re := by simp [sub_re]
          _ ≤ A - (g 0).re := by linarith
          _ < a := by linarith

      differentiable := by
        intro w hw
        -- v is differentiable
        have h_v_diff : DifferentiableWithinAt ℂ v (Metric.ball 0 R) w := by
          simp only [v]
          apply DifferentiableWithinAt.sub
          · exact (h_holo w (le_of_lt (mem_ball_zero_iff.mp hw))).differentiableWithinAt
          · exact differentiableWithinAt_const (c := g 0)
        -- mobius a is differentiable at v w
        have h_mobius_diff : DifferentiableAt ℂ (mobius a) (v w) := by
          apply mobius_differentiable
          change (2 * a : ℂ) - (g w - g 0) ≠ 0
          intro h_eq
          have hw_le : ‖w‖ ≤ R := le_of_lt (mem_ball_zero_iff.mp hw)
          have : (g w).re ≤ A := re_le_A w hw_le
          have v_re_lt : (g w - g 0).re < a := by
            calc (g w - g 0).re
                = (g w).re - (g 0).re := by simp [sub_re]
              _ ≤ A - (g 0).re := by linarith
              _ < a := by linarith
          have h_re_eq : (2 * a : ℂ).re = (g w - g 0).re := by
            have := congr_arg Complex.re h_eq
            simp [sub_re] at this
            linarith
          have : 2 * a = (g w - g 0).re := by simpa using h_re_eq
          linarith
        -- Compose them
        apply DifferentiableWithinAt.comp (s := Metric.ball 0 R) (t := Set.univ)
        · exact h_mobius_diff.differentiableWithinAt
        · exact h_v_diff
        · intros x _; exact Set.mem_univ _
      maps_zero := by simp [v, mobius_zero]
    }
    have hz_mem : z ∈ Metric.ball (0 : ℂ) R := by
      have hz_lt : ‖z‖ < R := lt_of_le_of_lt hz h_r
      simpa [Metric.mem_ball, dist_eq_norm] using hz_lt
    -- **Apply bundled Schwarz lemma - no unfolding needed!**
    have hz_bound : ‖hεf.toFun z‖ ≤ ‖z‖ / R :=
      BallToUnitBall.schwarz_bound hεf hz_mem
    -- **Möbius Transformation Inversion**
    -- We need: ‖g z - g 0‖ ≤ (2*a) * (‖hεf.toFun z‖ / (1 - ‖hεf.toFun z‖))
    -- Since hεf.toFun z = mobius a (v z) where v z = g z - g 0,
    -- we can apply mobius_inversion_bound
    have bound_g_sub : ‖g z - g 0‖ ≤ (2 * a) * (‖hεf.toFun z‖ / (1 - ‖hεf.toFun z‖)) := by
      have v_z_re_lt : (v z).re < a := by
        change (g z - g 0).re < a
        have hz_le : ‖z‖ ≤ R := le_trans hz (le_of_lt h_r)
        have : (g z).re ≤ A := re_le_A z hz_le
        calc (g z - g 0).re
            = (g z).re - (g 0).re := by simp [sub_re]
          _ ≤ A - (g 0).re := by linarith
          _ < a := by linarith
      have v_z_denom_ne_zero : (2 * a : ℂ) - (v z) ≠ 0 := by
        intro h_eq
        have h_re_eq : (2 * a : ℂ).re = (v z).re := by
          have := congr_arg Complex.re h_eq
          simp [sub_re] at this
          linarith
        have : 2 * a = (v z).re := by simpa using h_re_eq
        linarith [v_z_re_lt]
      have v_z_mobius_eq : (v z) / ((2 * a : ℂ) - (v z)) = hεf.toFun z := by
        rfl
      exact
        mobius_inversion_bound
          a ha_pos (v z) v_z_re_lt (hεf.toFun z) v_z_denom_ne_zero v_z_mobius_eq
    -- Substitute the Schwarz bound
    have h_mono_step1 : ‖g z - g 0‖ ≤ (2 * a) * ((‖z‖ / R) / (1 - (‖z‖ / R))) := by
      -- Use monotonicity of x ↦ x/(1-x) and hz_bound
      have h_z_over_R_lt_1 : ‖z‖ / R < 1 := by
        have : ‖z‖ < R := lt_of_le_of_lt hz h_r
        rw [div_lt_one h_R]
        exact this
      -- Monotonicity: if x ≤ y and y < 1, then x/(1-x) ≤ y/(1-y)
      -- For 0 ≤ x ≤ y < 1, the function f(t) = t/(1-t) is increasing
      -- This is a standard result from calculus: f'(t) = 1/(1-t)² > 0
      have mono : ‖hεf.toFun z‖ / (1 - ‖hεf.toFun z‖) ≤ (‖z‖ / R) / (1 - (‖z‖ / R)) := by
        apply div_one_sub_mono
        · exact norm_nonneg _
        · exact h_z_over_R_lt_1
        · exact hz_bound
      calc ‖g z - g 0‖
          ≤ (2 * a) * (‖hεf.toFun z‖ / (1 - ‖hεf.toFun z‖)) := bound_g_sub
        _ ≤ (2 * a) * ((‖z‖ / R) / (1 - (‖z‖ / R))) := by
            gcongr
    -- Use ‖z‖ ≤ r
    have bound_at_r : ‖g z - g 0‖ ≤ (2 * a) * (r / (R - r)) := by
      -- Again use monotonicity: ‖z‖ ≤ r implies (‖z‖/R)/(1-‖z‖/R) ≤ (r/R)/(1-r/R)
      have h_r_over_R_lt_1 : r / R < 1 := by
        rw [div_lt_one h_R]
        exact h_r
      have h_z_over_R_le_r_over_R : ‖z‖ / R ≤ r / R := by
        exact div_le_div_of_nonneg_right hz (le_of_lt h_R)
      -- Simplify (r/R) / (1 - r/R) = r / (R - r)
      have simplify_frac : (r / R) / (1 - r / R) = r / (R - r) := by
        have h_R_ne_zero : R ≠ 0 := ne_of_gt h_R
        have h_R_sub_r_ne_zero : R - r ≠ 0 := by linarith [h_r]
        field_simp
      -- Apply monotonicity again: ‖z‖ ≤ r implies the fractions satisfy the inequality
      -- This is again an application of monotonicity of t ↦ t/(1-t)
      have mono2 : (‖z‖ / R) / (1 - ‖z‖ / R) ≤ (r / R) / (1 - r / R) := by
        apply div_one_sub_mono
        · apply div_nonneg
          · exact norm_nonneg z
          · linarith
        · exact h_r_over_R_lt_1
        · exact h_z_over_R_le_r_over_R
      calc ‖g z - g 0‖
          ≤ (2 * a) * ((‖z‖ / R) / (1 - (‖z‖ / R))) := h_mono_step1
        _ ≤ (2 * a) * ((r / R) / (1 - r / R)) := by
            gcongr
        _ = (2 * a) * (r / (R - r)) := by rw [simplify_frac]
    -- Final triangle inequality
    calc ‖g z‖
        = ‖(g z - g 0) + g 0‖ := by ring_nf
      _ ≤ ‖g z - g 0‖ + ‖g 0‖ := norm_add_le _ _
      _ ≤ (2 * a) * (r / (R - r)) + ‖g 0‖ := by linarith [bound_at_r]
      _ = (2 * r / (R - r)) * a + ‖g 0‖ := by ring
      _ = (2 * r / (R - r)) * (A - (g 0).re + ε) + ‖g 0‖ := by rw [ha_def]
  -- Handle special case r = 0
  by_cases hr0 : r = 0
  · have hz0 : z = 0 := by
      have : ‖z‖ ≤ 0 := by simpa [hr0] using hz
      exact norm_le_zero_iff.mp this
    simp [hz0, hr0]
  -- Take limit as ε → 0
  have h_main : ‖g z‖ ≤ (2 * r / (R - r)) * (A - (g 0).re) + ‖g 0‖ := by
    -- For any δ > 0, ‖g z‖ ≤ base + δ
    have base_le : ∀ δ > 0, ‖g z‖ ≤ (2 * r / (R - r)) * (A - (g 0).re) + ‖g 0‖ + δ := by
      intro δ hδ
      have cpos : 0 < (2 * r / (R - r)) := by
        have : 0 < R - r := sub_pos.mpr h_r
        have hrpos : 0 < r := by
          have hrle : 0 ≤ r := le_trans (norm_nonneg z) hz
          exact lt_of_le_of_ne hrle (Ne.symm hr0)
        exact div_pos (by linarith) this
      set ε := δ / (2 * r / (R - r)) with hε_def
      have hε : 0 < ε := by
        simpa only [hε_def] using div_pos hδ cpos
      have := main_eps ε hε
      have heq : (2 * r / (R - r)) * (A - (g 0).re + ε) + ‖g 0‖
            = (2 * r / (R - r)) * (A - (g 0).re) + ‖g 0‖ + δ := by
        have h_eps_eq : (2 * r / (R - r)) * ε = δ := by
          rw [hε_def]
          exact mul_div_cancel₀ δ (ne_of_gt cpos)
        calc (2 * r / (R - r)) * (A - (g 0).re + ε) + ‖g 0‖
            = (2 * r / (R - r)) * (A - (g 0).re) + (2 * r / (R - r)) * ε + ‖g 0‖ := by ring
          _ = (2 * r / (R - r)) * (A - (g 0).re) + δ + ‖g 0‖ := by rw [h_eps_eq]
          _ = (2 * r / (R - r)) * (A - (g 0).re) + ‖g 0‖ + δ := by ring
      exact heq ▸ this
    -- Deduce ≤ base from ≤ base + δ for all δ > 0
    refine (le_iff_forall_pos_lt_add).2 fun ε hε => ?_
    have h_base : ‖g z‖ ≤ (2 * r / (R - r)) * (A - (g 0).re) + ‖g 0‖ + ε / 2 :=
      base_le (ε / 2) (by linarith)
    linarith [h_base]
  exact h_main

end
end LZCBorelCaratheodory
~~~~~~

## Hadamard.OrderOne.MultipliableFactors

Path: `source/Hadamard/OrderOne/MultipliableFactors.lean`

Original source lines: 1–211

Full file SHA256: `64e3e10ebb1f79ad6104d79ca0aa95c1d82472f29aaa3c6193bf40819bdd3736`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/OrderOne/MultipliableFactors.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Analysis.SpecialFunctions.Log.Summable
import Hadamard.Basic
import Hadamard.OrderOne.CofiniteControl

/-!
Genus‑1 canonical factors are multipliable under the standard hypothesis `∑ 1/‖z i‖² < ∞`.

This isolates the analytic input used repeatedly when building canonical products:
for fixed `s`, the family `i ↦ weierstrass_E 1 (s / z i)` is an infinite product that converges.
-/

open Complex Filter
open scoped BigOperators

namespace Hadamard
namespace OrderOne

lemma summable_norm_weierstrass_E_one_sub_one_of_summable_inv_norm_sq {ι : Type} {z : ι → ℂ}
    (hz0 : ∀ i, z i ≠ 0)
    (h : Summable (fun i => (1 : ℝ) / ‖z i‖ ^ 2))
    (s : ℂ) :
    Summable (fun i : ι => ‖weierstrass_E 1 (s / z i) - 1‖) := by
  classical
  by_cases hs : s = 0
  · subst hs
    simp [weierstrass_E_zero_arg]
  · have hs_norm : 0 < ‖s‖ := norm_pos_iff.2 hs
    have hR : 0 < (2 : ℝ) * ‖s‖ := by nlinarith
    let S : Set ι := {i : ι | ‖z i‖ ≤ (2 : ℝ) * ‖s‖}
    have hSfinite : S.Finite :=
      finite_norm_le_of_summable_inv_norm_sq (z := z) hz0 h (R := (2 : ℝ) * ‖s‖) hR
    -- Split the norm-series into a finite “bad” part on `S` plus a summable tail on `Sᶜ`.
    have hS_part :
        Summable (fun i : ι => if i ∈ S then ‖weierstrass_E 1 (s / z i) - 1‖ else 0) := by
      refine summable_of_hasFiniteSupport ?_
      have hsupp : Function.support
          (fun i : ι => if i ∈ S then ‖weierstrass_E 1 (s / z i) - 1‖ else 0) ⊆ S := by
        intro i hi
        by_contra hnot
        have : (if i ∈ S then ‖weierstrass_E 1 (s / z i) - 1‖ else 0) ≠ 0 := by
          simpa [Function.support] using hi
        simp [hnot] at this
      exact hSfinite.subset hsupp
    -- Tail: for `i ∉ S`, we have `‖s / z i‖ ≤ 1/2`, so the genus‑1 bound applies.
    have hTail :
        Summable (fun i : ι => if i ∈ S then 0 else ‖weierstrass_E 1 (s / z i) - 1‖) := by
      have hu :
          Summable (fun i : ι => (4 * ‖s‖ ^ 2) * ((1 : ℝ) / ‖z i‖ ^ 2)) := by
        exact h.mul_left (4 * ‖s‖ ^ 2)
      refine Summable.of_nonneg_of_le
          (f := fun i : ι => (4 * ‖s‖ ^ 2) * ((1 : ℝ) / ‖z i‖ ^ 2))
          (g := fun i : ι => if i ∈ S then 0 else ‖weierstrass_E 1 (s / z i) - 1‖) ?_ ?_ hu
      · intro i
        by_cases hi : i ∈ S <;> simp [hi, norm_nonneg]
      · intro i
        by_cases hi : i ∈ S
        · have hnonneg :
              0 ≤ (4 * ‖s‖ ^ 2) * ((1 : ℝ) / ‖z i‖ ^ 2) := by
            positivity
          simpa [hi] using hnonneg
        · have hz_gt : (2 : ℝ) * ‖s‖ < ‖z i‖ := by
            have : ¬‖z i‖ ≤ (2 : ℝ) * ‖s‖ := by simpa [S] using hi
            exact lt_of_not_ge this
          have hz_pos : 0 < ‖z i‖ := norm_pos_iff.2 (hz0 i)
          have hratio : ‖s‖ / ‖z i‖ ≤ (1 / 2 : ℝ) := by
            refine (div_le_iff₀ hz_pos).2 ?_
            have hz_ge : (2 : ℝ) * ‖s‖ ≤ ‖z i‖ := le_of_lt hz_gt
            have := mul_le_mul_of_nonneg_left hz_ge (by positivity : 0 ≤ (1 / 2 : ℝ))
            simpa [mul_assoc] using this
          have hdiv : ‖s / z i‖ ≤ (1 / 2 : ℝ) := by
            simpa [norm_div] using hratio
          have hE :
              ‖weierstrass_E 1 (s / z i) - 1‖ ≤ (4 * ‖s‖ ^ 2) * ((1 : ℝ) / ‖z i‖ ^ 2) := by
            have hE' := weierstrass_E_small_disk_norm_sub_one_le (h := 1) (z := s / z i) hdiv
            simpa [pow_two, norm_div, div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm] using hE'
          simpa [hi] using hE
    -- Recombine.
    have :
        Summable (fun i : ι =>
          (if i ∈ S then ‖weierstrass_E 1 (s / z i) - 1‖ else 0) +
            (if i ∈ S then 0 else ‖weierstrass_E 1 (s / z i) - 1‖)) :=
      hS_part.add hTail
    have hsum :
        (fun i : ι =>
          (if i ∈ S then ‖weierstrass_E 1 (s / z i) - 1‖ else 0) +
            (if i ∈ S then 0 else ‖weierstrass_E 1 (s / z i) - 1‖))
          = (fun i : ι => ‖weierstrass_E 1 (s / z i) - 1‖) := by
      funext i
      by_cases hi : i ∈ S <;> simp [hi]
    simpa [hsum] using this

lemma multipliable_weierstrass_E_one_of_summable_inv_norm_sq {ι : Type} {z : ι → ℂ}
    (hz0 : ∀ i, z i ≠ 0)
    (h : Summable (fun i => (1 : ℝ) / ‖z i‖ ^ 2))
    (s : ℂ) :
    Multipliable (fun i : ι => weierstrass_E 1 (s / z i)) := by
  have hsumm :
      Summable (fun i : ι => ‖weierstrass_E 1 (s / z i) - 1‖) :=
    summable_norm_weierstrass_E_one_sub_one_of_summable_inv_norm_sq (z := z) hz0 h s
  have hmul : Multipliable (fun i : ι => 1 + (weierstrass_E 1 (s / z i) - 1)) :=
    multipliable_one_add_of_summable hsumm
  simpa [sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using hmul

/-! ### General-rank versions -/

/-- **Rank-`p` analogue of `summable_norm_weierstrass_E_one_sub_one_of_summable_inv_norm_sq`.**

Under `∑ 1/‖z i‖^(p+1) < ∞`, the family `‖E_p(s/z i) - 1‖` is summable for every `s : ℂ`. -/
lemma summable_norm_weierstrass_E_sub_one_of_summable_inv_norm_pow
    {ι : Type*} {z : ι → ℂ} {p : ℕ}
    (hz0 : ∀ i, z i ≠ 0)
    (h : Summable (fun i => (1 : ℝ) / ‖z i‖ ^ (p + 1)))
    (s : ℂ) :
    Summable (fun i : ι => ‖weierstrass_E p (s / z i) - 1‖) := by
  classical
  by_cases hs : s = 0
  · subst hs
    simp [weierstrass_E_zero_arg]
  · have hs_norm : 0 < ‖s‖ := norm_pos_iff.2 hs
    have hR : 0 < (2 : ℝ) * ‖s‖ := by nlinarith
    let S : Set ι := {i : ι | ‖z i‖ ≤ (2 : ℝ) * ‖s‖}
    have hSfinite : S.Finite :=
      finite_norm_le_of_summable_inv_norm_pow (z := z) (p := p) hz0 h (R := (2 : ℝ) * ‖s‖) hR
    -- Bad (finite) part.
    have hS_part :
        Summable (fun i : ι => if i ∈ S then ‖weierstrass_E p (s / z i) - 1‖ else 0) := by
      refine summable_of_hasFiniteSupport ?_
      have hsupp : Function.support
          (fun i : ι => if i ∈ S then ‖weierstrass_E p (s / z i) - 1‖ else 0) ⊆ S := by
        intro i hi
        by_contra hnot
        have : (if i ∈ S then ‖weierstrass_E p (s / z i) - 1‖ else 0) ≠ 0 := by
          simpa [Function.support] using hi
        simp [hnot] at this
      exact hSfinite.subset hsupp
    have hTail :
        Summable (fun i : ι => if i ∈ S then 0 else ‖weierstrass_E p (s / z i) - 1‖) := by
      have hu :
          Summable (fun i : ι => (4 * ‖s‖ ^ (p + 1)) * ((1 : ℝ) / ‖z i‖ ^ (p + 1))) := by
        exact h.mul_left (4 * ‖s‖ ^ (p + 1))
      refine Summable.of_nonneg_of_le
          (f := fun i : ι => (4 * ‖s‖ ^ (p + 1)) * ((1 : ℝ) / ‖z i‖ ^ (p + 1)))
          (g := fun i : ι => if i ∈ S then 0 else ‖weierstrass_E p (s / z i) - 1‖) ?_ ?_ hu
      · intro i
        by_cases hi : i ∈ S <;> simp [hi, norm_nonneg]
      · intro i
        by_cases hi : i ∈ S
        · have hnonneg :
              0 ≤ (4 * ‖s‖ ^ (p + 1)) * ((1 : ℝ) / ‖z i‖ ^ (p + 1)) := by
            positivity
          simpa [hi] using hnonneg
        · have hz_gt : (2 : ℝ) * ‖s‖ < ‖z i‖ := by
            have : ¬‖z i‖ ≤ (2 : ℝ) * ‖s‖ := by simpa [S] using hi
            exact lt_of_not_ge this
          have hz_pos : 0 < ‖z i‖ := norm_pos_iff.2 (hz0 i)
          have hratio : ‖s‖ / ‖z i‖ ≤ (1 / 2 : ℝ) := by
            refine (div_le_iff₀ hz_pos).2 ?_
            have hz_ge : (2 : ℝ) * ‖s‖ ≤ ‖z i‖ := le_of_lt hz_gt
            have := mul_le_mul_of_nonneg_left hz_ge (by positivity : 0 ≤ (1 / 2 : ℝ))
            simpa [mul_assoc] using this
          have hdiv : ‖s / z i‖ ≤ (1 / 2 : ℝ) := by
            simpa [norm_div] using hratio
          have hE :
              ‖weierstrass_E p (s / z i) - 1‖ ≤ 4 * ‖s / z i‖ ^ (p + 1) :=
            weierstrass_E_small_disk_norm_sub_one_le (h := p) (z := s / z i) hdiv
          -- Rewrite `4 * ‖s/z i‖^(p+1)` as `(4 * ‖s‖^(p+1)) * (1/‖z i‖^(p+1))`.
          have hz_pos_pow : (0 : ℝ) < ‖z i‖ ^ (p + 1) := by positivity
          have hrw : 4 * ‖s / z i‖ ^ (p + 1)
              = (4 * ‖s‖ ^ (p + 1)) * ((1 : ℝ) / ‖z i‖ ^ (p + 1)) := by
            rw [norm_div, div_pow]
            field_simp
          have hfinal :
              ‖weierstrass_E p (s / z i) - 1‖ ≤
                (4 * ‖s‖ ^ (p + 1)) * ((1 : ℝ) / ‖z i‖ ^ (p + 1)) := by
            rw [← hrw]; exact hE
          simpa [hi] using hfinal
    have :
        Summable (fun i : ι =>
          (if i ∈ S then ‖weierstrass_E p (s / z i) - 1‖ else 0) +
            (if i ∈ S then 0 else ‖weierstrass_E p (s / z i) - 1‖)) :=
      hS_part.add hTail
    have hsum :
        (fun i : ι =>
          (if i ∈ S then ‖weierstrass_E p (s / z i) - 1‖ else 0) +
            (if i ∈ S then 0 else ‖weierstrass_E p (s / z i) - 1‖))
          = (fun i : ι => ‖weierstrass_E p (s / z i) - 1‖) := by
      funext i
      by_cases hi : i ∈ S <;> simp [hi]
    simpa [hsum] using this

/-- **Rank-`p` analogue of `multipliable_weierstrass_E_one_of_summable_inv_norm_sq`.** -/
lemma multipliable_weierstrass_E_of_summable_inv_norm_pow
    {ι : Type*} {z : ι → ℂ} {p : ℕ}
    (hz0 : ∀ i, z i ≠ 0)
    (h : Summable (fun i => (1 : ℝ) / ‖z i‖ ^ (p + 1)))
    (s : ℂ) :
    Multipliable (fun i : ι => weierstrass_E p (s / z i)) := by
  have hsumm :
      Summable (fun i : ι => ‖weierstrass_E p (s / z i) - 1‖) :=
    summable_norm_weierstrass_E_sub_one_of_summable_inv_norm_pow (z := z) (p := p) hz0 h s
  have hmul : Multipliable (fun i : ι => 1 + (weierstrass_E p (s / z i) - 1)) :=
    multipliable_one_add_of_summable hsumm
  simpa [sub_eq_add_neg, add_assoc, add_left_comm, add_comm] using hmul

end OrderOne
end Hadamard
~~~~~~

## Hadamard.OrderOne.CofiniteControl

Path: `source/Hadamard/OrderOne/CofiniteControl.lean`

Original source lines: 1–110

Full file SHA256: `d1ff5845fce48b187396f81716f962bb16ec753c1aff279443d22ea4e05cac56`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/OrderOne/CofiniteControl.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.Normed.Group.InfiniteSum
import Mathlib.Order.Filter.Cofinite
import Mathlib.Topology.Algebra.InfiniteSum.Order

/-!
Finiteness/escape-to-infinity lemmas for genus‑1 style summability hypotheses.

These are the “cheap topology” inputs used repeatedly when working with canonical products:
from summability of `1 / ‖z i‖^2` (and a nonzero hypothesis), we get that only finitely many
indices have `‖z i‖ ≤ R` for any fixed `R > 0`.
-/

open Filter

namespace Hadamard
namespace OrderOne

lemma finite_norm_le_of_summable_inv_norm_sq {ι : Type} {z : ι → ℂ}
    (hz0 : ∀ i, z i ≠ 0)
    (h : Summable (fun i => (1 : ℝ) / ‖z i‖ ^ 2))
    {R : ℝ} (hR : 0 < R) :
    ({i : ι | ‖z i‖ ≤ R} : Set ι).Finite := by
  have ht : Tendsto (fun i : ι => (1 : ℝ) / ‖z i‖ ^ 2) cofinite (nhds 0) :=
    h.tendsto_cofinite_zero
  have hpos : (0 : ℝ) < (1 / R ^ 2 : ℝ) := by positivity
  have hsmall : ∀ᶠ i in cofinite, (1 : ℝ) / ‖z i‖ ^ 2 < 1 / R ^ 2 :=
    ht.eventually (Iio_mem_nhds hpos)
  have hfinite_compl : ({i : ι | ¬((1 : ℝ) / ‖z i‖ ^ 2 < 1 / R ^ 2)} : Set ι).Finite := by
    have : ({i : ι | (1 : ℝ) / ‖z i‖ ^ 2 < 1 / R ^ 2} : Set ι) ∈ (cofinite : Filter ι) := hsmall
    have : ({i : ι | (1 : ℝ) / ‖z i‖ ^ 2 < 1 / R ^ 2} : Set ι)ᶜ.Finite :=
      (Filter.mem_cofinite.1 this)
    simpa [Set.compl_ofPred] using this
  refine hfinite_compl.subset ?_
  intro i hi
  have hzpos : 0 < (‖z i‖ : ℝ) := norm_pos_iff.2 (hz0 i)
  have hzpos_sq : 0 < (‖z i‖ : ℝ) ^ 2 := by positivity
  have hsq_le : (‖z i‖ : ℝ) ^ 2 ≤ R ^ 2 := by
    have : (‖z i‖ : ℝ) ≤ R := hi
    have habs : |(‖z i‖ : ℝ)| ≤ |R| := by
      simpa [abs_of_nonneg (norm_nonneg _), abs_of_pos hR] using this
    simpa using (sq_le_sq.2 habs)
  have hcontra : (1 : ℝ) / R ^ 2 ≤ (1 : ℝ) / ‖z i‖ ^ 2 :=
    one_div_le_one_div_of_le hzpos_sq hsq_le
  intro hlt
  exact (lt_irrefl (1 / R ^ 2)) (lt_of_le_of_lt hcontra hlt)

/-- **General-exponent finiteness.**

The `exponent ≥ 1` analogue of `finite_norm_le_of_summable_inv_norm_sq`:
given `∑ 1/‖z i‖^(p+1) < ∞` (for `p : ℕ`) and all `z i ≠ 0`, only finitely
many `i` have `‖z i‖ ≤ R`. -/
lemma finite_norm_le_of_summable_inv_norm_pow {ι : Type*} {z : ι → ℂ} {p : ℕ}
    (hz0 : ∀ i, z i ≠ 0)
    (h : Summable (fun i : ι => (1 : ℝ) / ‖z i‖ ^ (p + 1)))
    {R : ℝ} (hR : 0 < R) :
    ({i : ι | ‖z i‖ ≤ R} : Set ι).Finite := by
  have ht : Tendsto (fun i : ι => (1 : ℝ) / ‖z i‖ ^ (p + 1)) cofinite (nhds 0) :=
    h.tendsto_cofinite_zero
  have hpos : (0 : ℝ) < (1 / R ^ (p + 1) : ℝ) := by positivity
  have hsmall : ∀ᶠ i in cofinite, (1 : ℝ) / ‖z i‖ ^ (p + 1) < 1 / R ^ (p + 1) :=
    ht.eventually (Iio_mem_nhds hpos)
  have hfinite_compl :
      ({i : ι | ¬((1 : ℝ) / ‖z i‖ ^ (p + 1) < 1 / R ^ (p + 1))} : Set ι).Finite := by
    have : ({i : ι | (1 : ℝ) / ‖z i‖ ^ (p + 1) < 1 / R ^ (p + 1)} : Set ι) ∈
        (cofinite : Filter ι) := hsmall
    have : ({i : ι | (1 : ℝ) / ‖z i‖ ^ (p + 1) < 1 / R ^ (p + 1)} : Set ι)ᶜ.Finite :=
      (Filter.mem_cofinite.1 this)
    simpa [Set.compl_ofPred] using this
  refine hfinite_compl.subset ?_
  intro i hi
  have hzpos : 0 < (‖z i‖ : ℝ) := norm_pos_iff.2 (hz0 i)
  have hzpos_pow : 0 < (‖z i‖ : ℝ) ^ (p + 1) := by positivity
  have hpow_le : (‖z i‖ : ℝ) ^ (p + 1) ≤ R ^ (p + 1) := by
    exact pow_le_pow_left₀ (norm_nonneg _) hi (p + 1)
  have hcontra : (1 : ℝ) / R ^ (p + 1) ≤ (1 : ℝ) / ‖z i‖ ^ (p + 1) :=
    one_div_le_one_div_of_le hzpos_pow hpow_le
  intro hlt
  exact (lt_irrefl (1 / R ^ (p + 1))) (lt_of_le_of_lt hcontra hlt)

lemma tendsto_norm_atTop_of_summable_inv_norm_sq {ι : Type} {z : ι → ℂ}
    (hz0 : ∀ i, z i ≠ 0)
    (h : Summable (fun i => (1 : ℝ) / ‖z i‖ ^ 2)) :
    Tendsto (fun i : ι => ‖z i‖) cofinite atTop := by
  refine tendsto_atTop.mpr ?_
  intro R
  by_cases hR : 0 < R
  · have hfin_le : ({i : ι | ‖z i‖ ≤ R} : Set ι).Finite :=
      finite_norm_le_of_summable_inv_norm_sq (z := z) hz0 h (R := R) hR
    have hfin_lt : ({i : ι | ‖z i‖ < R} : Set ι).Finite := by
      refine hfin_le.subset ?_
      intro i hi
      exact le_of_lt (by simpa [Set.mem_ofPred_eq] using hi)
    have : ({i : ι | ¬R ≤ ‖z i‖} : Set ι).Finite := by
      simpa [not_le] using hfin_lt
    exact (Filter.eventually_cofinite.2 this)
  · -- If `R ≤ 0`, this is trivial since norms are nonnegative.
    have hR' : R ≤ 0 := le_of_not_gt hR
    refine Filter.Eventually.of_forall ?_
    intro i
    have : (0 : ℝ) ≤ ‖z i‖ := norm_nonneg _
    linarith

end OrderOne
end Hadamard
~~~~~~

## Lc.LiCriterion.MobiusMap

Path: `source/Lc/LiCriterion/MobiusMap.lean`

Original source lines: 1–183

Full file SHA256: `7ba73287750254feaff69592636a3bf1707897e1c76383f506fdb12db766c524`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Lc/LiCriterion/MobiusMap.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
/-
  Möbius map geometry for Li's criterion.

  The basic transform is `ρ ↦ 1 - 1/ρ` (equivalently `(ρ - 1) / ρ`).

  It sends:
  - `Re ρ = 1/2` to the unit circle `‖1 - 1/ρ‖ = 1`,
  - `Re ρ > 1/2` to the open unit disk `‖1 - 1/ρ‖ < 1`,
  - `Re ρ < 1/2` to the exterior `1 < ‖1 - 1/ρ‖`,
  for `ρ ≠ 0`.
-/

import Mathlib.Analysis.Complex.Basic

/-!
# The Möbius map `z ↦ 1 - 1/z`

Elementary norm and real-part identities for the map carrying the critical line to the unit
circle, used to turn RH into a statement about the closed unit disk.
-/

namespace LiCriterion

open Complex Real

/-- Helper: norm squared of complex difference. -/
lemma norm_sq_diff (z w : ℂ) : ‖z - w‖ ^ 2 = (z - w).re ^ 2 + (z - w).im ^ 2 := by
  have h1 : ‖z - w‖ ^ 2 = Complex.normSq (z - w) := by
    exact (Complex.normSq_eq_norm_sq (z - w)).symm
  rw [h1, Complex.normSq_apply, sub_re, sub_im, sq, sq]

/-- Helper: expanding `(a - b)²`. -/
lemma sq_sub_expand (a b : ℝ) : (a - b) ^ 2 = a ^ 2 - 2 * a * b + b ^ 2 := by
  rw [sub_sq]

/-- Helper: norm-squared inequality implies `Re` inequality. -/
lemma norm_sq_ineq_to_re (ρ : ℂ) : ‖ρ - 1‖ ^ 2 < ‖ρ‖ ^ 2 ↔ ρ.re > 1 / 2 := by
  rw [norm_sq_diff]
  have h1 : ‖ρ‖ ^ 2 = ρ.re ^ 2 + ρ.im ^ 2 := by
    have : ‖ρ‖ ^ 2 = Complex.normSq ρ := (Complex.normSq_eq_norm_sq ρ).symm
    simp [this, Complex.normSq_apply, sq]
  rw [h1]
  have h2 : (ρ - 1).re = ρ.re - 1 := by
    rw [sub_re, one_re]
  have h3 : (ρ - 1).im = ρ.im := by
    rw [sub_im, one_im]
    ring
  rw [h2, h3, sq_sub_expand]
  have h_simp : ρ.re ^ 2 - 2 * ρ.re * 1 + 1 ^ 2 = ρ.re ^ 2 - 2 * ρ.re + 1 := by ring
  rw [h_simp]
  constructor
  · intro h
    have h4 :
        (ρ.re ^ 2 - 2 * ρ.re + 1) + ρ.im ^ 2 < ρ.re ^ 2 + ρ.im ^ 2 ↔
          ρ.re ^ 2 - 2 * ρ.re + 1 < ρ.re ^ 2 :=
      add_lt_add_iff_right (ρ.im ^ 2)
    have h5 : ρ.re ^ 2 - 2 * ρ.re + 1 < ρ.re ^ 2 := by
      simpa [h4] using h
    have h7 : 1 < 2 * ρ.re := by linarith
    have h8 : 1 / 2 < ρ.re := by
      rw [div_lt_iff₀ two_pos, mul_comm]
      exact h7
    exact h8
  · intro h
    have h4 :
        (ρ.re ^ 2 - 2 * ρ.re + 1) + ρ.im ^ 2 < ρ.re ^ 2 + ρ.im ^ 2 ↔
          ρ.re ^ 2 - 2 * ρ.re + 1 < ρ.re ^ 2 :=
      add_lt_add_iff_right (ρ.im ^ 2)
    rw [h4]
    have h5 : 1 / 2 < ρ.re := h
    rw [div_lt_iff₀ two_pos, mul_comm] at h5
    have h6 : 1 < 2 * ρ.re := h5
    have h8 : ρ.re ^ 2 - 2 * ρ.re + 1 < ρ.re ^ 2 := by linarith
    exact h8

/-- Helper: squaring preserves `<` for nonnegative reals. -/
lemma norm_sq_lt_norm_sq {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) : a < b ↔ a ^ 2 < b ^ 2 := by
  constructor
  · intro hlt
    have h_neg : -b < a := by
      rw [neg_lt]
      have hb_pos : 0 < b := lt_of_le_of_lt ha hlt
      linarith
    exact sq_lt_sq' h_neg hlt
  · intro hsq
    have ha_eq : a = √(a ^ 2) := (Real.sqrt_sq ha).symm
    have hb_eq : b = √(b ^ 2) := (Real.sqrt_sq hb).symm
    rw [ha_eq, hb_eq]
    exact Real.sqrt_lt_sqrt (sq_nonneg a) hsq

/-- The key strict geometric equivalence: `‖1 - 1/ρ‖ < 1 ↔ Re(ρ) > 1/2` (for `ρ ≠ 0`). -/
lemma modulus_criterion (ρ : ℂ) (hρ : ρ ≠ 0) : ‖1 - 1 / ρ‖ < 1 ↔ ρ.re > 1 / 2 := by
  have h1 : (1 : ℂ) - (1 : ℂ) / ρ = (ρ - 1) / ρ := by
    field_simp
  rw [h1, norm_div]
  have h2 : 0 < ‖ρ‖ := norm_pos_iff.mpr hρ
  rw [div_lt_one h2]
  have h3 : ‖ρ - 1‖ < ‖ρ‖ ↔ ‖ρ - 1‖ ^ 2 < ‖ρ‖ ^ 2 := by
    have h_nn1 : 0 ≤ ‖ρ - 1‖ := norm_nonneg _
    have h_nn2 : 0 ≤ ‖ρ‖ := norm_nonneg _
    exact norm_sq_lt_norm_sq h_nn1 h_nn2
  rw [h3]
  exact norm_sq_ineq_to_re ρ

/-- The equality case: `‖ρ - 1‖² = ‖ρ‖² ↔ Re(ρ) = 1/2`. -/
lemma norm_sq_eq_to_re_half (ρ : ℂ) : ‖ρ - 1‖ ^ 2 = ‖ρ‖ ^ 2 ↔ ρ.re = 1 / 2 := by
  have hL : ‖ρ - 1‖ ^ 2 = (ρ.re - 1) ^ 2 + ρ.im ^ 2 := by
    have h := norm_sq_diff ρ 1
    simpa [sub_re, sub_im, one_re, one_im, sq] using h
  have hR : ‖ρ‖ ^ 2 = ρ.re ^ 2 + ρ.im ^ 2 := by
    have : ‖ρ‖ ^ 2 = Complex.normSq ρ := (Complex.normSq_eq_norm_sq ρ).symm
    simp [this, Complex.normSq_apply, sq]
  constructor
  · intro h
    have hsum : (ρ.re - 1) ^ 2 + ρ.im ^ 2 = ρ.re ^ 2 + ρ.im ^ 2 := by
      simpa [hL, hR] using h
    have h' : (ρ.re - 1) ^ 2 = ρ.re ^ 2 := add_right_cancel hsum
    have : ρ.re ^ 2 - 2 * ρ.re + 1 = ρ.re ^ 2 := by
      simpa [sub_sq] using h'
    have h2 : 2 * ρ.re = 1 := by linarith
    have : ρ.re = (1 : ℝ) / 2 := by
      have hmul : ρ.re * 2 = 1 := by simpa [mul_comm] using h2
      exact (eq_div_iff_mul_eq (two_ne_zero : (2 : ℝ) ≠ 0)).mpr hmul
    simpa [one_div] using this
  · intro h
    have h' : (ρ.re - 1) ^ 2 = ρ.re ^ 2 := by
      have : (1 / 2 - (1 : ℝ)) ^ 2 = (1 / 2 : ℝ) ^ 2 := by norm_num
      simp only [h]
      ring
    simp only [hL, hR, h']

/-- Exterior case: `1 < ‖1 - 1/ρ‖ ↔ Re(ρ) < 1/2` (for `ρ ≠ 0`). -/
lemma one_lt_modulus_iff_re_lt_half (ρ : ℂ) (hρ : ρ ≠ 0) : 1 < ‖1 - 1 / ρ‖ ↔ ρ.re < 1 / 2 := by
  have h1 : (1 : ℂ) - (1 : ℂ) / ρ = (ρ - 1) / ρ := by
    field_simp
  rw [h1, norm_div]
  have hρnorm_pos : 0 < ‖ρ‖ := norm_pos_iff.mpr hρ
  have hρnorm_ne : ‖ρ‖ ≠ 0 := ne_of_gt hρnorm_pos
  have hdiv : (1 : ℝ) < ‖ρ - 1‖ / ‖ρ‖ ↔ ‖ρ‖ < ‖ρ - 1‖ := by
    constructor
    · intro hlt
      have hmul : (1 : ℝ) * ‖ρ‖ < (‖ρ - 1‖ / ‖ρ‖) * ‖ρ‖ :=
        mul_lt_mul_of_pos_right hlt hρnorm_pos
      simpa [div_eq_mul_inv, mul_assoc, hρnorm_ne] using hmul
    · intro hlt
      have hdiv' : ‖ρ‖ / ‖ρ‖ < ‖ρ - 1‖ / ‖ρ‖ :=
        div_lt_div_of_pos_right hlt hρnorm_pos
      simpa [hρnorm_ne] using hdiv'
  have hsq : ‖ρ‖ < ‖ρ - 1‖ ↔ ‖ρ‖ ^ 2 < ‖ρ - 1‖ ^ 2 := by
    have hnn1 : 0 ≤ ‖ρ‖ := norm_nonneg _
    have hnn2 : 0 ≤ ‖ρ - 1‖ := norm_nonneg _
    exact norm_sq_lt_norm_sq (a := ‖ρ‖) (b := ‖ρ - 1‖) hnn1 hnn2
  have hre : ‖ρ‖ ^ 2 < ‖ρ - 1‖ ^ 2 ↔ ρ.re < 1 / 2 := by
    have h := (norm_sq_ineq_to_re (ρ := (1 - ρ)))
    have h' : ‖ρ‖ ^ 2 < ‖1 - ρ‖ ^ 2 ↔ (1 - ρ).re > 1 / 2 := by
      simpa [sub_eq_add_neg, add_assoc, add_comm, add_left_comm] using h
    have h'' : ‖ρ‖ ^ 2 < ‖ρ - 1‖ ^ 2 ↔ (1 - ρ).re > 1 / 2 := by
      simpa [norm_sub_rev] using h'
    constructor
    · intro hlt
      have : (1 - ρ).re > 1 / 2 := (h'').1 hlt
      have : (1 : ℝ) - ρ.re > 1 / 2 := by simpa [sub_re, one_re] using this
      linarith
    · intro hlt
      have : (1 : ℝ) - ρ.re > 1 / 2 := by linarith
      have : (1 - ρ).re > 1 / 2 := by simpa [sub_re, one_re] using this
      exact (h'').2 this
  constructor
  · intro hlt
    have hlt' : ‖ρ‖ < ‖ρ - 1‖ := (hdiv).1 hlt
    have hsq' : ‖ρ‖ ^ 2 < ‖ρ - 1‖ ^ 2 := (hsq).1 hlt'
    exact (hre).1 hsq'
  · intro hlt
    have hsq' : ‖ρ‖ ^ 2 < ‖ρ - 1‖ ^ 2 := (hre).2 hlt
    have hlt' : ‖ρ‖ < ‖ρ - 1‖ := (hsq).2 hsq'
    exact (hdiv).2 hlt'

end LiCriterion
~~~~~~

## Lc.LiCriterion.GenusOne

Path: `source/Lc/LiCriterion/GenusOne.lean`

Original source lines: 1–160

Full file SHA256: `5b53793cb362751bad06dc852f7fd7735d77df8ba56b3b5fa8aebf3931f5c455`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Lc/LiCriterion/GenusOne.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
/-
  Genus-1 estimates for Li's criterion.

  The genus-0 approach tries to bound individual Li summands by `O(1/‖ρ‖)`, which is too strong
  for ξ: the natural Weierstrass product is genus 1 and only gives square-summability.

  The key trick is to *pair* zeros `ρ` and `1-ρ`. On the level of the Li summand, this produces
  the core expression

    `2 - (w^m + w^{-m})`

  which is `O(‖w-1‖^2)` when `w` is near `1`. Since `w-1 = -(1/ρ)`, this yields an eventual bound
  by `C(m) / ‖ρ‖^2`, matching the genus-1 hypothesis.
-/

import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Analysis.Complex.Basic

/-!
# Genus-1 pairing of the Li summands

The core term `2 - (wᵐ + w⁻ᵐ)` and the identity pairing a zero `ρ` with `1 - ρ`, which is what
makes the sum over zeros converge at genus 1.
-/

open scoped BigOperators

namespace LiCriterion

noncomputable section

/-- The paired genus-1 core term `2 - (w^m + w^{-m})`. -/
def core (m : ℕ) (w : ℂ) : ℂ := (2 : ℂ) - (w ^ m + (w ^ m)⁻¹)

/-- The basic Li summand written as `1 - w^{-m}` (with the exponent as a `ℤ`). -/
def liTerm (m : ℕ) (w : ℂ) : ℂ := (1 : ℂ) - w ^ (-(m : ℤ))

lemma liTerm_add_liTerm_inv (m : ℕ) (w : ℂ) :
    liTerm m w + liTerm m w⁻¹ = core m w := by
  simp [liTerm, core, sub_eq_add_neg, add_assoc, add_left_comm, add_comm]
  norm_num

lemma two_sub_add_inv_eq_neg_sq_div (t : ℂ) (ht : t ≠ 0) :
    (2 : ℂ) - (t + t⁻¹) = -((t - 1) ^ 2) / t := by
  field_simp [ht]
  ring

lemma core_eq_neg_sq_div (m : ℕ) (w : ℂ) (hw : w ≠ 0) :
    core m w = -((w ^ m - 1) ^ 2) / (w ^ m) := by
  have ht : w ^ m ≠ 0 := pow_ne_zero m hw
  simpa [core] using (two_sub_add_inv_eq_neg_sq_div (t := w ^ m) ht)

/-- If `‖w - 1‖ ≤ 1/2` then `‖w‖ ≤ 3/2`. -/
lemma norm_le_three_halves_of_norm_sub_one_le_half {w : ℂ} (hw : ‖w - 1‖ ≤ (1 / 2 : ℝ)) :
    ‖w‖ ≤ (3 / 2 : ℝ) := by
  have hw' : (w - 1) + 1 = w := sub_add_cancel w (1 : ℂ)
  have h := norm_add_le (w - 1) (1 : ℂ)
  have h' := h
  rw [hw'] at h'
  have h'' := h'
  rw [norm_one] at h''
  -- h'' : ‖w‖ ≤ ‖w - 1‖ + 1, hw : ‖w - 1‖ ≤ 1 / 2
  calc ‖w‖ ≤ ‖w - 1‖ + 1 := h''
    _ ≤ 1 / 2 + 1 := by linarith
    _ = 3 / 2 := by norm_num

/-- If `‖w - 1‖ ≤ 1/2` then `1/2 ≤ ‖w‖`. -/
lemma one_half_le_norm_of_norm_sub_one_le_half {w : ℂ} (hw : ‖w - 1‖ ≤ (1 / 2 : ℝ)) :
    (1 / 2 : ℝ) ≤ ‖w‖ := by
  have h1 : w - (w - 1) = (1 : ℂ) := by
    simp [sub_sub_cancel]
  have h := norm_sub_le w (w - 1)
  have h' := h
  rw [h1] at h'
  have h'' := h'
  rw [norm_one] at h''
  linarith [h'', hw]

/-- Algebraic identity used in zero pairing: if `z ≠ 0, 1`, then

`1 - 1/(1-z) = (1 - 1/z)⁻¹`. -/
lemma one_sub_one_div_one_sub_eq_inv_one_sub_one_div {z : ℂ} (hz : z ≠ 0) (hz1 : z ≠ 1) :
    (1 : ℂ) - (1 : ℂ) / (1 - z) = ((1 : ℂ) - (1 : ℂ) / z)⁻¹ := by
  have h1z : (1 - z) ≠ 0 := sub_ne_zero.mpr (Ne.symm hz1)
  field_simp [hz, h1z]
  ring

/-- The paired Li summand (at `z` and `1-z`) collapses to the genus‑1 core term. -/
lemma paired_liTerm_eq_core (m : ℕ) {z : ℂ} (hz : z ≠ 0) (hz1 : z ≠ 1) :
    liTerm m ((1 : ℂ) - (1 : ℂ) / z) + liTerm m ((1 : ℂ) - (1 : ℂ) / (1 - z)) =
      core m ((1 : ℂ) - (1 : ℂ) / z) := by
  set w : ℂ := (1 : ℂ) - (1 : ℂ) / z
  have hw : (1 : ℂ) - (1 : ℂ) / (1 - z) = w⁻¹ := by
    dsimp [w]
    simpa using (one_sub_one_div_one_sub_eq_inv_one_sub_one_div (z := z) hz hz1)
  calc
    liTerm m w + liTerm m ((1 : ℂ) - (1 : ℂ) / (1 - z))
        = liTerm m w + liTerm m w⁻¹ := by
            rw [hw]
    _ = core m w := liTerm_add_liTerm_inv m w
    _ = core m ((1 : ℂ) - (1 : ℂ) / z) := by rfl

/-- Norm bound for the genus-1 paired core term.

If `w` lies within `1/2` of `1`, then `‖core m w‖` is `O(‖w-1‖^2)` with an explicit constant.
This is the estimate used to make the Li zero-sum summable after pairing zeros. -/
lemma norm_core_le_const_mul_norm_sub_one_sq (m : ℕ) {w : ℂ} (hw : ‖w - 1‖ ≤ (1 / 2 : ℝ)) :
    ‖core m w‖ ≤ ((2 : ℝ) ^ m) * (∑ i ∈ Finset.range m, ((3 / 2 : ℝ) ^ i)) ^ 2 * ‖w - 1‖ ^ 2 := by
  have hw_upper : ‖w‖ ≤ (3 / 2 : ℝ) := norm_le_three_halves_of_norm_sub_one_le_half (w := w) hw
  have hw_lower : (1 / 2 : ℝ) ≤ ‖w‖ := one_half_le_norm_of_norm_sub_one_le_half (w := w) hw
  have hw_ne : w ≠ 0 := by
    have : (0 : ℝ) < ‖w‖ := lt_of_lt_of_le (by norm_num) hw_lower
    exact (norm_pos_iff).1 this
  -- geometric sum bound: ‖∑_{i<m} w^i‖ ≤ ∑_{i<m} (3/2)^i
  have hsum_w : ‖∑ i ∈ Finset.range m, w ^ i‖ ≤ ∑ i ∈ Finset.range m, ((3 / 2 : ℝ) ^ i) := by
    refine (norm_sum_le (Finset.range m) (fun i => w ^ i)).trans ?_
    refine Finset.sum_le_sum ?_
    intro i hi
    have : ‖w ^ i‖ = ‖w‖ ^ i := by simp [norm_pow]
    have hpow : ‖w‖ ^ i ≤ (3 / 2 : ℝ) ^ i := pow_le_pow_left₀ (norm_nonneg w) hw_upper i
    simpa [this] using hpow
  -- inverse power bound: ‖(w^m)⁻¹‖ ≤ 2^m
  have hinv_pow : ‖(w ^ m)⁻¹‖ ≤ (2 : ℝ) ^ m := by
    have hpow : (1 / 2 : ℝ) ^ m ≤ ‖w‖ ^ m := pow_le_pow_left₀ (by positivity) hw_lower m
    have hpos : (0 : ℝ) < (1 / 2 : ℝ) ^ m := pow_pos (by norm_num) m
    have : (1 : ℝ) / (‖w‖ ^ m) ≤ (1 : ℝ) / ((1 / 2 : ℝ) ^ m) :=
      one_div_le_one_div_of_le hpos hpow
    simpa [norm_inv, norm_pow] using this
  -- bound ‖w^m - 1‖ via geometric sum
  have hgeom : ‖w ^ m - 1‖ ≤ (∑ i ∈ Finset.range m, ((3 / 2 : ℝ) ^ i)) * ‖w - 1‖ := by
    have hmul : ‖w ^ m - 1‖ = ‖∑ i ∈ Finset.range m, w ^ i‖ * ‖w - 1‖ := by
      have := geom_sum_mul (R := ℂ) w m
      have : w ^ m - 1 = (∑ i ∈ Finset.range m, w ^ i) * (w - 1) := by
        simpa [eq_comm] using this
      simp [this]
    have := mul_le_mul_of_nonneg_right hsum_w (norm_nonneg (w - 1))
    simpa [hmul, mul_assoc] using this
  have hcore : core m w = -((w ^ m - 1) ^ 2) / (w ^ m) := by
    simpa [pow_two] using core_eq_neg_sq_div m w hw_ne
  -- final estimate
  calc
    ‖core m w‖ = ‖-((w ^ m - 1) ^ 2) / (w ^ m)‖ := by simp [hcore]
    _ = ‖((w ^ m - 1) ^ 2) / (w ^ m)‖ := by simp
    _ = ‖(w ^ m - 1) ^ 2‖ * ‖(w ^ m)⁻¹‖ := by simp [div_eq_mul_inv]
    _ = (‖w ^ m - 1‖ ^ 2) * ‖(w ^ m)⁻¹‖ := by simp [pow_two]
    _ ≤ (((∑ i ∈ Finset.range m, ((3 / 2 : ℝ) ^ i)) * ‖w - 1‖) ^ 2) * ‖(w ^ m)⁻¹‖ := by
          gcongr
    _ ≤ (((∑ i ∈ Finset.range m, ((3 / 2 : ℝ) ^ i)) * ‖w - 1‖) ^ 2) * ((2 : ℝ) ^ m) := by
          gcongr
    _ = ((2 : ℝ) ^ m) * (∑ i ∈ Finset.range m, ((3 / 2 : ℝ) ^ i)) ^ 2 * ‖w - 1‖ ^ 2 := by
          ring

end

end LiCriterion
~~~~~~

## Lc.LiCriterion.Pringsheim

Path: `source/Lc/LiCriterion/Pringsheim.lean`

Original source lines: 1–196

Full file SHA256: `8422429e544573eea07852165e414f41c2fe087b0d4bc01baaed59c4740da503`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Lc/LiCriterion/Pringsheim.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.Calculus.Deriv.Star
import Mathlib.Analysis.MellinTransform
import Mathlib.Analysis.SpecialFunctions.Complex.Arg
import Mathlib.Analysis.SpecialFunctions.Pow.Complex
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.NumberTheory.LSeries.RiemannZeta

/-!
Pringsheim-style tools for the reverse direction of Li’s criterion.

The actual Pringsheim step (“a power series with nonnegative coefficients has a singularity on the
positive real axis at its radius of convergence”) is not implemented here yet.

This file collects small, reusable lemmas about complex conjugation and derivatives, which are
needed to reduce “nonnegativity of real parts” to “nonnegativity of coefficients” once we prove
that the relevant Taylor coefficients are real.
-/

open Complex
open scoped ComplexConjugate

namespace LiCriterion

/-! ### Conjugation and derivatives -/

/-- If `f` commutes with complex conjugation, then so does `deriv f` (with `deriv` using the
`0`-convention at nondifferentiable points). -/
lemma deriv_conj_eq_of_conj_invariant (f : ℂ → ℂ) (hf : ∀ z, f (conj z) = conj (f z)) (z : ℂ) :
    deriv f (conj z) = conj (deriv f z) := by
  classical
  by_cases hd : DifferentiableAt ℂ f z
  · have hder : HasDerivAt f (deriv f z) z := hd.hasDerivAt
    have hconj :
        HasDerivAt (conj ∘ f ∘ conj) (conj (deriv f z)) (conj z) :=
      (HasDerivAt.conj_conj (f := f) (f' := deriv f z) (x := z) hder)
    have hfun : (conj ∘ f ∘ conj) = f := by
      funext w
      have hw : f w = conj (f (conj w)) := by
        simpa using (hf (conj w))
      simpa [Function.comp_def] using hw.symm
    have hconj' : HasDerivAt f (conj (deriv f z)) (conj z) := by
      simpa [hfun] using hconj
    have hd_conj : DifferentiableAt ℂ f (conj z) := by
      have hd' :
          DifferentiableAt ℂ (conj ∘ f ∘ conj) (conj z) :=
        (DifferentiableAt.conj_conj (f := f) (x := z) hd)
      simpa [hfun] using hd'
    have hder_conj : HasDerivAt f (deriv f (conj z)) (conj z) := hd_conj.hasDerivAt
    exact (hder_conj.unique hconj')
  · have hd_conj : ¬ DifferentiableAt ℂ f (conj z) := by
      intro h
      have h' :
          DifferentiableAt ℂ (conj ∘ f ∘ conj) (conj (conj z)) :=
        (DifferentiableAt.conj_conj (f := f) (x := conj z) h)
      have hfun : (conj ∘ f ∘ conj) = f := by
        funext w
        have hw : f w = conj (f (conj w)) := by
          simpa using (hf (conj w))
        simpa [Function.comp_def] using hw.symm
      have : DifferentiableAt ℂ f z := by simpa [hfun] using h'
      exact hd this
    simp [deriv_zero_of_not_differentiableAt hd, deriv_zero_of_not_differentiableAt hd_conj]

/-- If `f` commutes with conjugation, then so do all iterated derivatives. -/
lemma iteratedDeriv_conj_eq_of_conj_invariant (f : ℂ → ℂ) (hf : ∀ z, f (conj z) = conj (f z)) :
    ∀ n : ℕ, ∀ z : ℂ, (deriv^[n] f) (conj z) = conj ((deriv^[n] f) z) := by
  intro n
  induction n with
  | zero =>
      intro z
      simpa using hf z
  | succ n ih =>
      intro z
      simp only [Function.iterate_succ', Function.comp_apply]
      -- Apply the `deriv` lemma to `deriv^[n] f`, using the induction hypothesis as the
      -- conjugation commutation.
      have hcomm :
          ∀ w : ℂ, (deriv^[n] f) (conj w) = conj ((deriv^[n] f) w) := ih
      simpa using
        (deriv_conj_eq_of_conj_invariant (f := deriv^[n] f) hcomm z)

/-- In particular, a conjugation-invariant function has conjugation-invariant iterated derivatives
at `0`. -/
lemma conj_iteratedDeriv_zero_of_conj_invariant (f : ℂ → ℂ) (hf : ∀ z, f (conj z) = conj (f z))
    (n : ℕ) :
    conj ((deriv^[n] f) 0) = (deriv^[n] f) 0 := by
  have := iteratedDeriv_conj_eq_of_conj_invariant f hf n (0 : ℂ)
  simpa using this.symm

/-! ### Conjugation for Mellin transforms and `completedRiemannZeta₀`

To show the Li coefficients are real, it is convenient to know that the completed zeta functions
from Mathlib commute with complex conjugation.

Mathlib defines `completedRiemannZeta₀` as a Hurwitz-zeta specialization, ultimately as a Mellin
transform of a real-valued kernel; this section packages the resulting conjugation lemma.
-/

section CompletedZetaConj

open MeasureTheory

private lemma mellin_conj_real (f : ℝ → ℂ) (hf : ∀ t, conj (f t) = f t) (s : ℂ) :
    conj (mellin f s) = mellin f (conj s) := by
  change
    conj (∫ t : ℝ in Set.Ioi 0, (t : ℂ) ^ (s - 1) * f t) =
      ∫ t : ℝ in Set.Ioi 0, (t : ℂ) ^ (conj s - 1) * f t
  have hconj :
      conj (∫ (t : ℝ) in Set.Ioi 0, (t : ℂ) ^ (s - 1) * f t) =
        ∫ (t : ℝ) in Set.Ioi 0, conj ((t : ℂ) ^ (s - 1) * f t) := by
    simpa using
      (integral_conj
        (μ := (volume.restrict (Set.Ioi (0 : ℝ))))
        (f := fun t : ℝ => (t : ℂ) ^ (s - 1) * f t)).symm
  have harg : ∀ t : ℝ, t ∈ Set.Ioi (0 : ℝ) → (t : ℂ).arg ≠ Real.pi := by
    intro t ht
    have ht0 : 0 ≤ t := le_of_lt ht
    have harg0 : (t : ℂ).arg = 0 := Complex.arg_ofReal_of_nonneg ht0
    simpa [harg0] using (Real.pi_ne_zero.symm)
  calc
    conj (∫ (t : ℝ) in Set.Ioi 0, (t : ℂ) ^ (s - 1) * f t)
        = ∫ (t : ℝ) in Set.Ioi 0, conj ((t : ℂ) ^ (s - 1) * f t) := hconj
    _ = ∫ (t : ℝ) in Set.Ioi 0, (t : ℂ) ^ (conj s - 1) * f t := by
      refine setIntegral_congr_fun measurableSet_Ioi ?_
      intro t ht
      have ht' : (t : ℂ).arg ≠ Real.pi := harg t ht
      have hcpow : conj ((t : ℂ) ^ (s - 1)) = (t : ℂ) ^ (conj s - 1) := by
        have h := Complex.cpow_conj (x := (t : ℂ)) (n := s - 1) ht'
        have htconj : conj (t : ℂ) = (t : ℂ) := by simp
        have h' : (t : ℂ) ^ (conj (s - 1)) = conj ((t : ℂ) ^ (s - 1)) := by
          simpa [htconj] using h
        simpa [sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using h'.symm
      calc
        conj ((t : ℂ) ^ (s - 1) * f t)
            = conj ((t : ℂ) ^ (s - 1)) * conj (f t) := by simp [map_mul]
        _ = (t : ℂ) ^ (conj s - 1) * f t := by simp [hf t, hcpow]

private lemma conj_indicator {s : Set ℝ} {f : ℝ → ℂ} (hf : ∀ x, conj (f x) = f x) (x : ℝ) :
    conj (s.indicator f x) = s.indicator f x := by
  by_cases hx : x ∈ s
  · simp [Set.indicator_of_mem, hx, hf]
  · simp [Set.indicator_of_notMem, hx]

private lemma hurwitzEvenFEPair_f_modif_conj (a : UnitAddCircle) (x : ℝ) :
    conj ((HurwitzZeta.hurwitzEvenFEPair a).f_modif x)
      = (HurwitzZeta.hurwitzEvenFEPair a).f_modif x := by
  classical
  simp [WeakFEPair.f_modif, HurwitzZeta.hurwitzEvenFEPair, conj_indicator]

private lemma conj_two : (starRingEnd ℂ) (2 : ℂ) = (2 : ℂ) := by
  simpa using (map_natCast (starRingEnd ℂ) 2)

private lemma conj_inv_two : (starRingEnd ℂ) ((2 : ℂ)⁻¹) = (2 : ℂ)⁻¹ := by
  calc
    (starRingEnd ℂ) ((2 : ℂ)⁻¹) = ((starRingEnd ℂ) (2 : ℂ))⁻¹ := by
      simp
    _ = (2 : ℂ)⁻¹ := by
      rw [conj_two]

private lemma completedHurwitzZetaEven₀_conj (a : UnitAddCircle) (s : ℂ) :
    HurwitzZeta.completedHurwitzZetaEven₀ a (conj s)
      = conj (HurwitzZeta.completedHurwitzZetaEven₀ a s) := by
  have hf : ∀ t : ℝ,
      conj ((HurwitzZeta.hurwitzEvenFEPair a).f_modif t)
        = (HurwitzZeta.hurwitzEvenFEPair a).f_modif t :=
    fun t => hurwitzEvenFEPair_f_modif_conj (a := a) t
  -- Unfold the `Λ₀` / Mellin definitions; then use `mellin_conj_real`.
  unfold HurwitzZeta.completedHurwitzZetaEven₀ WeakFEPair.Λ₀
  simp only [div_eq_mul_inv]
  have hsarg : conj (s * (2 : ℂ)⁻¹) = conj s * (2 : ℂ)⁻¹ := by
    have hinv : conj ((2 : ℂ)⁻¹) = (2 : ℂ)⁻¹ := conj_inv_two
    have hmul : conj (s * (2 : ℂ)⁻¹) = conj s * conj ((2 : ℂ)⁻¹) :=
      map_mul (starRingEnd ℂ) s ((2 : ℂ)⁻¹)
    simp [hinv]
  have hm :
      conj (mellin (HurwitzZeta.hurwitzEvenFEPair a).f_modif (s * (2 : ℂ)⁻¹)) =
        mellin (HurwitzZeta.hurwitzEvenFEPair a).f_modif (conj (s * (2 : ℂ)⁻¹)) :=
    mellin_conj_real (f := (HurwitzZeta.hurwitzEvenFEPair a).f_modif) hf (s * (2 : ℂ)⁻¹)
  rw [map_mul, conj_inv_two]
  simpa [hsarg] using congrArg (fun z => z * (2 : ℂ)⁻¹) hm.symm

/-- `completedRiemannZeta₀` commutes with complex conjugation. -/
lemma completedRiemannZeta₀_conj (s : ℂ) :
    completedRiemannZeta₀ (conj s) = conj (completedRiemannZeta₀ s) := by
  simpa [completedRiemannZeta₀] using
    (completedHurwitzZetaEven₀_conj (a := (0 : UnitAddCircle)) s)

end CompletedZetaConj

end LiCriterion
~~~~~~

## Hadamard.OrderOne.SummabilityMultiplicity

Path: `source/Hadamard/OrderOne/SummabilityMultiplicity.lean`

Original source lines: 1–1178

Full file SHA256: `f5f1a50b99c27faf1f6304df8902629bfa90286248a6924afdd35e061a84823e`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/OrderOne/SummabilityMultiplicity.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Analysis.Normed.Group.InfiniteSum
import Mathlib.Data.Finset.Max
import Mathlib.Order.Filter.AtTopBot.Basic
import Hadamard.OrderOne.TailEstimates

/-!
## Summability of `∑ analyticOrderNatAt(f, ρ) / ‖ρ‖²` from order-≤1 bounds

This is the multiplicity-aware analogue of `Summability.lean`: we weight each zero `ρ` by its
vanishing order `analyticOrderNatAt f ρ`.

The key input is the Jensen/divisor bound upgraded to multiplicities
(`ZeroCounting.sum_zeros_multiplicity_le_of_max_one_maxModulus`) and the derived `O(r^(1+ε))`
bound in `TailEstimates.sum_multiplicity_zeros_le_rpow`.
-/

open scoped BigOperators

namespace Hadamard

open Complex Filter Metric MeromorphicOn Real

namespace OrderOne

/-! ### Dyadic ball finsets (no summability hypothesis) -/

theorem zerosBallFinite_of_entire
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (n : ℕ) : ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n} : Set Z.Zero).Finite := by
  classical
  have hf0 : f 0 ≠ 0 := by
    intro hf0
    rcases (h_zeros_only 0).1 hf0 with ⟨ρ, hρ⟩
    exact (h_z_ne_zero ρ) (by simp [hρ])
  have hRpos : 0 < (2 : ℝ) ^ n := by positivity
  have hD :
      ((MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 : ℝ) ^ n|)).support : Set ℂ).Finite :=
    (MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 : ℝ) ^ n|)).finiteSupport
      (isCompact_closedBall (0 : ℂ) |(2 : ℝ) ^ n|)
  have hImage :
      (Z.z '' ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n} : Set Z.Zero))
        ⊆ (MeromorphicOn.divisor f (closedBall (0 : ℂ) |(2 : ℝ) ^ n|)).support := by
    intro u hu
    rcases hu with ⟨ρ, hρ, rfl⟩
    have hu_mem : Z.z ρ ∈ closedBall (0 : ℂ) |(2 : ℝ) ^ n| := by
      simpa [Metric.mem_closedBall, dist_eq_norm, abs_of_pos hRpos, Set.mem_ofPred_eq] using hρ
    exact
      mem_divisor_support_of_zero (f := f) hf_entire (u := Z.z ρ) (R := (2 : ℝ) ^ n) hu_mem hf0
        (Z.isZero ρ)
  exact
    Set.Finite.of_finite_image (f := Z.z)
      (s := ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n} : Set Z.Zero)) (h := hD.subset hImage)
      (hi := h_inj.injOn)

noncomputable def zerosBallFinset_of_entire
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (n : ℕ) : Finset Z.Zero :=
  (zerosBallFinite_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
        (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) n).toFinset

@[simp]
lemma mem_zerosBallFinset_of_entire_iff
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (n : ℕ) (ρ : Z.Zero) :
    ρ ∈ zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) n ↔
      ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n := by
  classical
  simp [zerosBallFinset_of_entire]

/-! ### Main summability lemma -/

theorem summable_analyticOrderNatAt_div_norm_sq_of_order_le_one
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0) :
    Summable (fun ρ : Z.Zero => (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2) := by
  classical
  -- Use the vanishing-tail criterion for summability.
  refine
    (summable_iff_vanishing_norm
        (f := fun ρ : Z.Zero => (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2)).2 ?_
  intro ε hε
  -- Pick a small exponent `εcount < 1` for the weighted zero-counting bound.
  let εcount : ℝ := (1 : ℝ) / 2
  have hεcount_pos : 0 < εcount := by norm_num [εcount]
  have hεcount_lt1 : εcount < 1 := by norm_num [εcount]
  -- Weighted zero-counting bound `W(r) = O(r^(1+εcount))`.
  obtain ⟨Rcount, Ccount, hCcount_nonneg, hW_le⟩ :=
    sum_multiplicity_zeros_le_rpow (f := f) hf_entire hf_finite hf_order_le Z h_zeros_only h_inj
      h_z_ne_zero εcount hεcount_pos
  -- Choose `nR` so that `max Rcount 1 ≤ 2^nR`.
  let R0 : ℝ := max Rcount 1
  have hR0_le : ∃ nR : ℕ, R0 ≤ (2 : ℝ) ^ nR := by
    have h : ∃ n : ℕ, R0 < (2 : ℝ) ^ n := by
      simpa using (pow_unbounded_of_one_lt R0 (by norm_num : (1 : ℝ) < 2))
    refine ⟨Nat.find h, le_of_lt (Nat.find_spec h)⟩
  obtain ⟨nR, hnR⟩ := hR0_le
  -- Geometric ratio `q = 2^(εcount-1)` with `0 < q < 1`.
  let q : ℝ := (2 : ℝ) ^ (εcount - 1)
  have hq_pos : 0 < q := by
    simpa [q] using Real.rpow_pos_of_pos (by norm_num : (0 : ℝ) < 2) (εcount - 1)
  have hq_lt_one : q < 1 := by
    have hneg : εcount - 1 < 0 := by linarith [hεcount_lt1]
    simpa [q] using Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : (1 : ℝ) < 2) hneg
  have hq_nonneg : 0 ≤ q := le_of_lt hq_pos
  -- Constant controlling the geometric tail.
  let C : ℝ := (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q / (1 - q)
  have hC_nonneg : 0 ≤ C := by
    have hpow_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) :=
      Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
    have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
    have hnum_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q :=
      mul_nonneg (mul_nonneg hpow_nonneg hCcount_nonneg) hq_nonneg
    exact div_nonneg hnum_nonneg (le_of_lt hden_pos)
  -- Choose `n₀` so that `C * q^n₀ < ε`.
  have hlim : Tendsto (fun n : ℕ => C * q ^ n) atTop (nhds (0 : ℝ)) := by
    have hpow : Tendsto (fun n : ℕ => q ^ n) atTop (nhds (0 : ℝ)) :=
      tendsto_pow_atTop_nhds_zero_of_lt_one hq_nonneg hq_lt_one
    simpa [mul_zero] using (Tendsto.const_mul C hpow)
  have h_event : ∀ᶠ n : ℕ in atTop, |C * q ^ n| < ε := by
    have hball : Metric.ball (0 : ℝ) ε ∈ nhds (0 : ℝ) := Metric.ball_mem_nhds _ hε
    have hmem := hlim hball
    simpa [Metric.mem_ball, dist_eq_norm, Real.norm_eq_abs, sub_zero] using hmem
  obtain ⟨N, hN⟩ := (eventually_atTop.1 h_event)
  let n₀ : ℕ := max nR N
  have hn₀_ge_nR : nR ≤ n₀ := le_max_left _ _
  have hn₀_ge_N : N ≤ n₀ := le_max_right _ _
  have hn₀_lt : |C * q ^ n₀| < ε := hN n₀ hn₀_ge_N
  -- Use the dyadic ball `‖Z.z ρ‖ ≤ 2^(n₀+1)` as the "finite head" for the Cauchy criterion.
  refine ⟨
    zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
      (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (n₀ + 1),
    ?_⟩
  intro t ht
  -- If `t` is disjoint from the ball, then each element has norm strictly larger than `2^(n₀+1)`.
  have hcond : ∀ ρ : Z.Zero, ρ ∈ t → (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ := by
    intro ρ hρt
    have hnot :
        ρ ∉
          zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (n₀ + 1) :=
      (Finset.disjoint_left.1 ht) hρt
    have hnot' : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n₀ + 1) := by
      simpa
        [mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero)]
        using hnot
    exact lt_of_not_ge hnot'
  -- Define an indicator function cutting off the "small zeros".
  let g : Z.Zero → ℝ := fun ρ =>
    if (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ then
      (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2
    else 0
  have hg_nonneg : ∀ ρ : Z.Zero, 0 ≤ g ρ := by
    intro ρ
    by_cases hρ : (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖
    · have : 0 ≤ (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2 := by positivity
      simpa [g, hρ] using this
    · simp [g, hρ]
  have hsum_eq :
      (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2) = ∑ ρ ∈ t, g ρ := by
    refine Finset.sum_congr rfl ?_
    intro ρ hρ
    have hρ' := hcond ρ hρ
    simp [g, hρ']
  -- Place `t` inside a large dyadic ball `ball m`.
  have ht_subset :
      ∃ m : ℕ,
        t ⊆
          zerosBallFinset_of_entire
            (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m := by
    classical
    by_cases ht0 : t = ∅
    · refine ⟨0, ?_⟩
      simp [ht0]
    · have ht_ne : t.Nonempty := Finset.nonempty_iff_ne_empty.2 ht0
      let R : ℝ := t.sup' ht_ne fun ρ : Z.Zero => ‖Z.z ρ‖
      have hR : ∀ ρ : Z.Zero, ρ ∈ t → ‖Z.z ρ‖ ≤ R := by
        intro ρ hρ
        exact Finset.le_sup' (f := fun ρ : Z.Zero => ‖Z.z ρ‖) hρ
      have hpow : ∃ m : ℕ, max R 1 < (2 : ℝ) ^ m := by
        simpa using pow_unbounded_of_one_lt (max R 1) (by norm_num : (1 : ℝ) < 2)
      refine ⟨Nat.find hpow, ?_⟩
      intro ρ hρt
      have hρ_leR : ‖Z.z ρ‖ ≤ R := hR ρ hρt
      have hρ_le : ‖Z.z ρ‖ ≤ max R 1 := le_trans hρ_leR (le_max_left _ _)
      have hmax_le : max R 1 ≤ (2 : ℝ) ^ Nat.find hpow := le_of_lt (Nat.find_spec hpow)
      have hρ_ball : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ Nat.find hpow := le_trans hρ_le hmax_le
      exact
        (mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z)
          (h_zeros_only := h_zeros_only) (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) _ _).2
          hρ_ball
  rcases ht_subset with ⟨m, htm⟩
  -- Bound `∑_{ρ ∈ t} g ρ` by a dyadic-shell geometric estimate.
  have hball :
      (∑ ρ ∈
          zerosBallFinset_of_entire
            (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m,
        g ρ)
        ≤ C * ((2 : ℝ) ^ n₀) ^ (εcount - 1) := by
    let w : Z.Zero → ℝ := fun ρ => (analyticOrderNatAt f (Z.z ρ) : ℝ)
    have hsub_ball :
        ∀ k : ℕ,
          zerosBallFinset_of_entire
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ⊆
            zerosBallFinset_of_entire
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) := by
      intro k ρ hρ
      have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k :=
        (mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ρ).1 hρ
      have hk_le : (2 : ℝ) ^ k ≤ (2 : ℝ) ^ (k + 1) :=
        pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_succ k)
      exact
        (mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) ρ).2 (le_trans hnorm hk_le)
    have hshell :
        ∀ k : ℕ, n₀ + 1 ≤ k →
          (∑ ρ ∈
              zerosBallFinset_of_entire
                    (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                    (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) \
                zerosBallFinset_of_entire
                    (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                    (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k,
              g ρ)
            ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q ^ k := by
      intro k hk
      let ball : ℕ → Finset Z.Zero := fun t =>
        zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) t
      let diff : Finset Z.Zero := ball (k + 1) \ ball k
      have hk_pow_le : (2 : ℝ) ^ (n₀ + 1) ≤ (2 : ℝ) ^ k :=
        pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hk
      have hdiff_simp :
          (∑ ρ ∈ diff, g ρ) = ∑ ρ ∈ diff, w ρ / ‖Z.z ρ‖ ^ 2 := by
        refine Finset.sum_congr rfl ?_
        intro ρ hρ
        have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
          intro hle
          have : ρ ∈ ball k :=
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ρ).2 hle
          exact (Finset.mem_sdiff.1 hρ).2 this
        have hlt : (2 : ℝ) ^ k < ‖Z.z ρ‖ := lt_of_not_ge hnot
        have hcond' : (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ :=
          lt_of_lt_of_le (hk_pow_le.trans_lt hlt) (le_rfl)
        simp [g, w, hcond']
      have hterm_le :
          ∀ ρ, ρ ∈ diff → w ρ / ‖Z.z ρ‖ ^ 2 ≤ w ρ / ((2 : ℝ) ^ k) ^ 2 := by
        intro ρ hρ
        have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
          intro hle
          have : ρ ∈ ball k :=
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ρ).2 hle
          exact (Finset.mem_sdiff.1 hρ).2 this
        have hk_le_norm : (2 : ℝ) ^ k ≤ ‖Z.z ρ‖ := le_of_lt (lt_of_not_ge hnot)
        have hk2_pos : 0 < ((2 : ℝ) ^ k) ^ 2 := by positivity
        have hk2_le : ((2 : ℝ) ^ k) ^ 2 ≤ ‖Z.z ρ‖ ^ 2 :=
          pow_le_pow_left₀ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ k) hk_le_norm 2
        have hw_nonneg : 0 ≤ w ρ := by positivity [w]
        have hfrac : (1 : ℝ) / ‖Z.z ρ‖ ^ 2 ≤ (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 := by
          simpa [one_div, inv_pow] using (one_div_le_one_div_of_le hk2_pos hk2_le)
        simpa [div_eq_mul_inv, one_div, mul_assoc, mul_left_comm, mul_comm] using
          (mul_le_mul_of_nonneg_left hfrac hw_nonneg)
      have hsum_le :
          (∑ ρ ∈ diff, w ρ / ‖Z.z ρ‖ ^ 2) ≤ ∑ ρ ∈ diff, w ρ / ((2 : ℝ) ^ k) ^ 2 :=
        Finset.sum_le_sum hterm_le
      have hRcount_le : Rcount ≤ (2 : ℝ) ^ (k + 1) := by
        have hRcount_le_R0 : Rcount ≤ R0 := le_max_left _ _
        have hnR_le_k : nR ≤ k := le_trans hn₀_ge_nR (le_trans (Nat.le_succ n₀) hk)
        have hnR_le_k1 : nR ≤ k + 1 := Nat.le_succ_of_le hnR_le_k
        have hpow : (2 : ℝ) ^ nR ≤ (2 : ℝ) ^ (k + 1) :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hnR_le_k1
        exact le_trans (le_trans hRcount_le_R0 hnR) hpow
      have hcount_ball :
          (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) ≤
            Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + εcount) :=
        hW_le ((2 : ℝ) ^ (k + 1)) hRcount_le
      have hball_finsum :
          (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) =
            ∑ ρ ∈ ball (k + 1), w ρ := by
        have hsupp :
            Function.support (fun ρ : Z.Zero => if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) ⊆
              ball (k + 1) := by
          intro ρ hρ
          have hne :
              (if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) ≠ 0 :=
            Function.mem_support.1 hρ
          have hle : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) := by
            by_contra hle
            apply hne
            simp [hle]
          exact
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) ρ).2 hle
        have this :=
          finsum_eq_sum_of_support_subset
            (f := fun ρ : Z.Zero => if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0)
            (s := ball (k + 1)) hsupp
        have hsum_if :
            (∑ ρ ∈ ball (k + 1), if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) =
              ∑ ρ ∈ ball (k + 1), w ρ := by
          refine Finset.sum_congr rfl ?_
          intro ρ hρ
          have hle : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) :=
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) ρ).1 hρ
          simp [hle]
        simpa [hsum_if] using this
      have hsum_ball :
          (∑ ρ ∈ ball (k + 1), w ρ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + εcount) := by
        simpa [hball_finsum] using hcount_ball
      have hsum_mult_diff :
          (∑ ρ ∈ diff, w ρ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + εcount) := by
        have hdiff_le_ball :
            (∑ ρ ∈ diff, w ρ) ≤ ∑ ρ ∈ ball (k + 1), w ρ := by
          have hw_nonneg :
              ∀ ρ ∈ ball (k + 1), ρ ∉ diff → 0 ≤ w ρ := by
            intro ρ _ _
            positivity [w]
          exact
            Finset.sum_le_sum_of_subset_of_nonneg
              (Finset.sdiff_subset : diff ⊆ ball (k + 1)) hw_nonneg
        exact le_trans hdiff_le_ball hsum_ball
      -- Put everything together and rewrite into `q^k`.
      have hqk : q ^ k = ((2 : ℝ) ^ k) ^ (εcount - 1) := by
        simpa [q] using
          (Real.rpow_pow_comm (x := (2 : ℝ)) (hx := by positivity) (εcount - 1) k)
      have hdiv :
          ((2 : ℝ) ^ k) ^ (εcount - 1) =
            ((2 : ℝ) ^ k) ^ ((1 : ℝ) + εcount) / ((2 : ℝ) ^ k) ^ (2 : ℕ) := by
        have hk_pos : 0 < (2 : ℝ) ^ k := by positivity
        have hsub : ((1 : ℝ) + εcount) - (2 : ℝ) = εcount - 1 := by ring
        simpa [hsub, Real.rpow_natCast ((2 : ℝ) ^ k) 2] using
          (Real.rpow_sub hk_pos ((1 : ℝ) + εcount) (2 : ℝ))
      have hrewrite :
          Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + εcount) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
            = (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q ^ k := by
        have hpow_succ : (2 : ℝ) ^ (k + 1) = (2 : ℝ) * (2 : ℝ) ^ k := by
          simp [pow_succ, mul_comm]
        have hpowk_nonneg : 0 ≤ (2 : ℝ) ^ k := by positivity
        have h2_nonneg : 0 ≤ (2 : ℝ) := by norm_num
        calc
          Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + εcount) *
              ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
              =
              Ccount * (((2 : ℝ) * (2 : ℝ) ^ k) ^ ((1 : ℝ) + εcount)) *
                ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
                simp [hpow_succ]
          _ =
              Ccount * ((2 : ℝ) ^ ((1 : ℝ) + εcount) * ((2 : ℝ) ^ k) ^ ((1 : ℝ) + εcount)) *
                  ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
                have hsplit :
                    ((2 : ℝ) * (2 : ℝ) ^ k) ^ ((1 : ℝ) + εcount) =
                      (2 : ℝ) ^ ((1 : ℝ) + εcount) * ((2 : ℝ) ^ k) ^ ((1 : ℝ) + εcount) := by
                  simpa using
                    (Real.mul_rpow (x := (2 : ℝ)) (y := (2 : ℝ) ^ k) (z := (1 : ℝ) + εcount)
                      h2_nonneg hpowk_nonneg)
                simp [hsplit, mul_assoc,
                  -mul_eq_mul_left_iff, -mul_eq_mul_right_iff]
          _ =
              (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                  (((2 : ℝ) ^ k) ^ ((1 : ℝ) + εcount) / ((2 : ℝ) ^ k) ^ (2 : ℕ)) := by
                simp [div_eq_mul_inv, mul_assoc, mul_comm,
                  -mul_eq_mul_left_iff, -mul_eq_mul_right_iff]
          _ = (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * ((2 : ℝ) ^ k) ^ (εcount - 1) := by
                simp [hdiv, mul_assoc, mul_comm,
                  -mul_eq_mul_left_iff, -mul_eq_mul_right_iff]
          _ = (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q ^ k := by
                simp [hqk]
      have hmain :
          (∑ ρ ∈ diff, g ρ) ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q ^ k := by
        calc
          (∑ ρ ∈ diff, g ρ) = ∑ ρ ∈ diff, w ρ / ‖Z.z ρ‖ ^ 2 := by
            simp [hdiff_simp]
          _ ≤ ∑ ρ ∈ diff, w ρ / ((2 : ℝ) ^ k) ^ 2 := hsum_le
          _ = (∑ ρ ∈ diff, w ρ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
            simp [div_eq_mul_inv, Finset.sum_mul]
          _ ≤ (Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + εcount)) *
                ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
            have hconst_nonneg : 0 ≤ (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 := by positivity
            exact mul_le_mul_of_nonneg_right hsum_mult_diff hconst_nonneg
          _ = (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q ^ k := by
            simpa [mul_assoc, mul_left_comm, mul_comm] using hrewrite
      simpa [ball, diff] using hmain
    -- Sum the shell estimates.
    by_cases hm : m ≤ n₀ + 1
    · have hsum0 :
          (∑ ρ ∈
              zerosBallFinset_of_entire
                (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m,
            g ρ) = 0 := by
        refine Finset.sum_eq_zero ?_
        intro ρ hρ
        have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ m :=
          (mem_zerosBallFinset_of_entire_iff
            (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m ρ).1 hρ
        have hpow : (2 : ℝ) ^ m ≤ (2 : ℝ) ^ (n₀ + 1) :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hm
        have : ¬ (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ := not_lt_of_ge (le_trans hnorm hpow)
        simp [g, this]
      have hrhs_nonneg : 0 ≤ C * ((2 : ℝ) ^ n₀) ^ (εcount - 1) := by
        have : 0 ≤ ((2 : ℝ) ^ n₀) ^ (εcount - 1) :=
          Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ n₀) _
        exact mul_nonneg hC_nonneg this
      simpa [hsum0] using hrhs_nonneg
    · have hm_ge : n₀ + 1 < m := lt_of_not_ge hm
      let ball : ℕ → Finset Z.Zero := fun t =>
        zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) t
      -- Write `m = (n₀+1) + t` for some `t > 0` and sum shells.
      set t' : ℕ := m - (n₀ + 1) with ht'_def
      have ht'_pos : 0 < t' := Nat.sub_pos_of_lt hm_ge
      have hm_eq : m = n₀ + 1 + t' := (Nat.add_sub_cancel' (le_of_lt hm_ge)).symm
      have hind :
          ∀ t : ℕ,
            (∑ ρ ∈ ball (n₀ + 1 + t), g ρ) ≤
              (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                (∑ i ∈ Finset.range t, q ^ (n₀ + 1 + i)) := by
        intro t
        induction t using Nat.rec with
        | zero =>
            have hsum0 :
                (∑ ρ ∈ ball (n₀ + 1), g ρ) = 0 := by
              refine Finset.sum_eq_zero ?_
              intro ρ hρ
              have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n₀ + 1) :=
                (mem_zerosBallFinset_of_entire_iff
                  (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                  (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (n₀ + 1) ρ).1 hρ
              have : ¬ (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ := not_lt_of_ge hnorm
              simp [g, this]
            simp [ball, hsum0]
        | succ j ih =>
            set k : ℕ := n₀ + 1 + j
            have hk : n₀ + 1 ≤ k := Nat.le_add_right _ _
            have hsub : ball k ⊆ ball (k + 1) := by
              simpa [ball] using hsub_ball k
            have hdecomp :=
              (Finset.sum_sdiff (s₁ := ball k) (s₂ := ball (k + 1)) (f := g) hsub).symm
            have hshell_le :
                (∑ ρ ∈ ball (k + 1) \ ball k, g ρ)
                  ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q ^ k := hshell k hk
            have hgeom :
                (∑ i ∈ Finset.range (j + 1), q ^ (n₀ + 1 + i))
                  = (∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) + q ^ k := by
              simpa [k, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using
                (Finset.sum_range_succ (f := fun i => q ^ (n₀ + 1 + i)) j)
            have ih' :
                (∑ ρ ∈ ball k, g ρ) ≤
                  (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                    (∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) := by
              simpa [k, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using ih
            calc
              (∑ ρ ∈ ball (k + 1), g ρ)
                  = (∑ ρ ∈ ball (k + 1) \ ball k, g ρ) + (∑ ρ ∈ ball k, g ρ) := by
                        simpa [k, add_assoc, add_comm, add_left_comm] using hdecomp
              _ ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q ^ k +
                    (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                      (∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) := by
                        gcongr
              _ = (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                    ((∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) + q ^ k) := by
                        ring
              _ = (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                    (∑ i ∈ Finset.range (j + 1), q ^ (n₀ + 1 + i)) := by
                        simp [hgeom]
      have hfinite_le :
          (∑ ρ ∈ ball m, g ρ) ≤
            (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
              (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) := by
        simpa [hm_eq, ball] using hind t'
      have hgeom_le :
          (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) ≤ (q ^ (n₀ + 1)) * (1 - q)⁻¹ := by
        have hsum : Summable (fun i : ℕ => q ^ i) :=
          summable_geometric_of_lt_one (le_of_lt hq_pos) hq_lt_one
        have hsum' : Summable (fun i : ℕ => q ^ (n₀ + 1) * q ^ i) :=
          hsum.mul_left (q ^ (n₀ + 1))
        have hnonneg : ∀ i : ℕ, 0 ≤ q ^ (n₀ + 1) * q ^ i := by
          intro i; positivity
        have hle_tsum :
            (∑ i ∈ Finset.range t', q ^ (n₀ + 1) * q ^ i) ≤ ∑' i : ℕ, q ^ (n₀ + 1) * q ^ i := by
          refine
            Summable.sum_le_tsum
              (s := Finset.range t')
              (f := fun i : ℕ => q ^ (n₀ + 1) * q ^ i) ?_ hsum'
          intro i hi
          exact hnonneg i
        have hpow_add : ∀ i : ℕ, q ^ (n₀ + 1 + i) = q ^ (n₀ + 1) * q ^ i := by
          intro i
          simp [pow_add, mul_assoc]
        have hsum_eq :
            (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) =
              (∑ i ∈ Finset.range t', q ^ (n₀ + 1) * q ^ i) := by
          refine Finset.sum_congr rfl ?_
          intro i hi
          simp [hpow_add i]
        have htsum_eq :
            (∑' i : ℕ, q ^ (n₀ + 1) * q ^ i) = (q ^ (n₀ + 1)) * (1 - q)⁻¹ := by
          have hgeom0 : (∑' i : ℕ, q ^ i) = (1 - q)⁻¹ :=
            tsum_geometric_of_lt_one (h₁ := le_of_lt hq_pos) (h₂ := hq_lt_one)
          calc
            (∑' i : ℕ, q ^ (n₀ + 1) * q ^ i) = (q ^ (n₀ + 1)) * ∑' i : ℕ, q ^ i := by
                rw [tsum_mul_left]
            _ = (q ^ (n₀ + 1)) * (1 - q)⁻¹ := by rw [hgeom0]
        have : (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) ≤ (q ^ (n₀ + 1)) * (1 - q)⁻¹ := by
          have hle_tsum' :
              (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) ≤ ∑' i : ℕ, q ^ (n₀ + 1) * q ^ i := by
            rw [hsum_eq]
            exact hle_tsum
          exact le_trans hle_tsum' (by rw [htsum_eq])
        exact this
      -- Combine and simplify to the desired bound.
      have hqpow : q ^ (n₀ + 1) = q ^ n₀ * q := by simp [pow_succ]
      have hqk : q ^ n₀ = ((2 : ℝ) ^ n₀) ^ (εcount - 1) := by
        simpa [q] using
          (Real.rpow_pow_comm (x := (2 : ℝ)) (hx := by positivity) (εcount - 1) n₀)
      have hfinal :
          (∑ ρ ∈ ball m, g ρ) ≤ C * ((2 : ℝ) ^ n₀) ^ (εcount - 1) := by
        have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
        calc
          (∑ ρ ∈ ball m, g ρ)
              ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * (q ^ (n₀ + 1) * (1 - q)⁻¹) := by
                    have hpow_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) :=
                      Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
                    have hconst_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount :=
                      mul_nonneg hpow_nonneg hCcount_nonneg
                    have hmult :
                        (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                            (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i))
                          ≤ (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount *
                            (q ^ (n₀ + 1) * (1 - q)⁻¹) := by
                      simpa [mul_assoc] using
                        mul_le_mul_of_nonneg_left hgeom_le hconst_nonneg
                    exact le_trans hfinite_le hmult
          _ = (2 : ℝ) ^ ((1 : ℝ) + εcount) * Ccount * q / (1 - q) * q ^ n₀ := by
                    field_simp [hden_pos.ne']
                    ring
          _ = C * q ^ n₀ := by
                    simp [C, mul_assoc, mul_left_comm, mul_comm, div_eq_mul_inv]
          _ = C * ((2 : ℝ) ^ n₀) ^ (εcount - 1) := by
                    simp [hqk]
      simpa [ball] using hfinal
  have hsum_le :
      (∑ ρ ∈ t, g ρ) ≤
        ∑ ρ ∈
            zerosBallFinset_of_entire
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m,
          g ρ := by
    refine Finset.sum_le_sum_of_subset_of_nonneg htm ?_
    intro ρ _ _
    exact hg_nonneg ρ
  have hbound :
      (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2) ≤
        C * ((2 : ℝ) ^ n₀) ^ (εcount - 1) := by
    calc
      (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2) = ∑ ρ ∈ t, g ρ := hsum_eq
      _ ≤
          ∑ ρ ∈ zerosBallFinset_of_entire
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m,
            g ρ := hsum_le
      _ ≤ C * ((2 : ℝ) ^ n₀) ^ (εcount - 1) := hball
  -- Convert `((2^n₀)^(εcount-1))` to `q^n₀` and use `C*q^n₀ < ε`.
  have hqpow : q ^ n₀ = ((2 : ℝ) ^ n₀) ^ (εcount - 1) := by
    simpa [q] using (Real.rpow_pow_comm (x := (2 : ℝ)) (hx := by positivity) (εcount - 1) n₀)
  have hCq_lt : C * q ^ n₀ < ε := by
    have habs : |C * q ^ n₀| = C * q ^ n₀ := by
      have : 0 ≤ C * q ^ n₀ := by
        have : 0 ≤ q ^ n₀ := by positivity
        exact mul_nonneg hC_nonneg this
      rw [abs_of_nonneg this]
    have hlt : |C * q ^ n₀| < ε := hn₀_lt
    rwa [habs] at hlt
  have hsmall : C * ((2 : ℝ) ^ n₀) ^ (εcount - 1) < ε := by
    simpa [hqpow] using hCq_lt
  have hsum_nonneg :
      0 ≤ ∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2 := by
    refine Finset.sum_nonneg ?_
    intro ρ hρ
    positivity
  have hnorm_lt :
      ‖∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2‖ < ε := by
    have hsum_lt :
        (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2) < ε :=
      lt_of_le_of_lt hbound hsmall
    have habs_eq :
        |∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2| =
          ∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2 :=
      abs_of_nonneg hsum_nonneg
    have habs_lt :
        |∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ 2| < ε := by
      simpa [habs_eq] using hsum_lt
    simpa [Real.norm_eq_abs] using habs_lt
  exact hnorm_lt

/-! ### General-order summability at exponent `p + 1` -/

/-- **Summability of `∑ ord_ρ(f) / ‖ρ‖^(p+1)` from `order f ≤ lam`** where
`p = ⌊lam⌋₊`.

This is the general-order analogue of
`summable_analyticOrderNatAt_div_norm_sq_of_order_le_one`: given
`order f ≤ lam`, the multiplicity-weighted sum converges at the exponent
`⌊lam⌋₊ + 1` (which is strictly greater than `lam`, giving a geometric decay
ratio `< 1`).

The proof is the same dyadic shell argument as the order-1 version, but
with:
* `εcount := (p + 1 - lam) / 2` in place of `εcount := 1/2`, ensuring
  `lam + εcount < p + 1` so that `q := 2 ^ ((lam + εcount) - (p + 1))` is in
  `(0, 1)`;
* the exponent `p + 1` in place of `2`;
* the generalized weighted counting bound
  `sum_multiplicity_zeros_le_rpow_of_order_le` in place of
  `sum_multiplicity_zeros_le_rpow`. -/
theorem summable_analyticOrderNatAt_div_norm_pow_of_order_le
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f)
    {lam : ℝ} (hlam_nonneg : 0 ≤ lam) (hf_order_le : order f ≤ lam)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0) :
    Summable (fun ρ : Z.Zero =>
      (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (Nat.floor lam + 1)) := by
  classical
  set p : ℕ := Nat.floor lam with hp_def
  have hlam_lt_p1 : lam < (p : ℝ) + 1 := by
    simpa [p, hp_def] using (Nat.lt_floor_add_one lam)
  -- Pick `εcount > 0` with `lam + εcount < p + 1`, i.e. the midpoint.
  set εcount : ℝ := ((p : ℝ) + 1 - lam) / 2 with hεcount_def
  have hεcount_pos : 0 < εcount := by
    have : 0 < (p : ℝ) + 1 - lam := sub_pos.mpr hlam_lt_p1
    simpa [εcount] using half_pos this
  have hεcount_lt_gap : lam + εcount < (p : ℝ) + 1 := by
    have heq : lam + ((p : ℝ) + 1 - lam) / 2 = (lam + ((p : ℝ) + 1)) / 2 := by ring
    rw [hεcount_def]; rw [heq]; linarith [hlam_lt_p1]
  -- Vanishing-tail criterion for summability.
  refine
    (summable_iff_vanishing_norm
        (f := fun ρ : Z.Zero =>
          (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1))).2 ?_
  intro ε hε
  -- Weighted counting bound at exponent `lam + εcount`.
  obtain ⟨Rcount, Ccount, hCcount_nonneg, hW_le⟩ :=
    Hadamard.OrderOne.sum_multiplicity_zeros_le_rpow_of_order_le (f := f) hf_entire hf_finite
      hf_order_le hlam_nonneg Z h_zeros_only h_inj h_z_ne_zero εcount hεcount_pos
  -- Pick a dyadic `2^nR ≥ max Rcount 1`.
  let R0 : ℝ := max Rcount 1
  have hR0_le : ∃ nR : ℕ, R0 ≤ (2 : ℝ) ^ nR := by
    have h : ∃ n : ℕ, R0 < (2 : ℝ) ^ n := by
      simpa using (pow_unbounded_of_one_lt R0 (by norm_num : (1 : ℝ) < 2))
    refine ⟨Nat.find h, le_of_lt (Nat.find_spec h)⟩
  obtain ⟨nR, hnR⟩ := hR0_le
  -- Geometric ratio `q := 2^((lam + εcount) - (p + 1))`, strictly in `(0, 1)`.
  let q : ℝ := (2 : ℝ) ^ ((lam + εcount) - ((p : ℝ) + 1))
  have hq_pos : 0 < q := by
    simpa [q] using Real.rpow_pos_of_pos (by norm_num : (0 : ℝ) < 2) _
  have hq_lt_one : q < 1 := by
    have hneg : (lam + εcount) - ((p : ℝ) + 1) < 0 := by linarith
    simpa [q] using Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : (1 : ℝ) < 2) hneg
  have hq_nonneg : 0 ≤ q := le_of_lt hq_pos
  -- Geometric tail constant.
  let C : ℝ := (2 : ℝ) ^ (lam + εcount) * Ccount * q / (1 - q)
  have hC_nonneg : 0 ≤ C := by
    have hpow_nonneg : 0 ≤ (2 : ℝ) ^ (lam + εcount) :=
      Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
    have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
    exact div_nonneg (mul_nonneg (mul_nonneg hpow_nonneg hCcount_nonneg) hq_nonneg)
      (le_of_lt hden_pos)
  -- Pick `n₀` with `C * q^n₀ < ε`.
  have hlim : Tendsto (fun n : ℕ => C * q ^ n) atTop (nhds (0 : ℝ)) := by
    have hpow : Tendsto (fun n : ℕ => q ^ n) atTop (nhds (0 : ℝ)) :=
      tendsto_pow_atTop_nhds_zero_of_lt_one hq_nonneg hq_lt_one
    simpa [mul_zero] using (Tendsto.const_mul C hpow)
  have h_event : ∀ᶠ n : ℕ in atTop, |C * q ^ n| < ε := by
    have hball : Metric.ball (0 : ℝ) ε ∈ nhds (0 : ℝ) := Metric.ball_mem_nhds _ hε
    simpa [Metric.mem_ball, dist_eq_norm, Real.norm_eq_abs, sub_zero] using hlim hball
  obtain ⟨N, hN⟩ := (eventually_atTop.1 h_event)
  let n₀ : ℕ := max nR N
  have hn₀_ge_nR : nR ≤ n₀ := le_max_left _ _
  have hn₀_ge_N : N ≤ n₀ := le_max_right _ _
  have hn₀_lt : |C * q ^ n₀| < ε := hN n₀ hn₀_ge_N
  -- Finite head: the dyadic ball `‖Z.z ρ‖ ≤ 2^(n₀+1)`.
  refine ⟨
    zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
      (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (n₀ + 1),
    ?_⟩
  intro t ht
  have hcond : ∀ ρ : Z.Zero, ρ ∈ t → (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ := by
    intro ρ hρt
    have hnot :
        ρ ∉
          zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (n₀ + 1) :=
      (Finset.disjoint_left.1 ht) hρt
    have hnot' : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n₀ + 1) := by
      simpa
        [mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero)]
        using hnot
    exact lt_of_not_ge hnot'
  let g : Z.Zero → ℝ := fun ρ =>
    if (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ then
      (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)
    else 0
  have hg_nonneg : ∀ ρ : Z.Zero, 0 ≤ g ρ := by
    intro ρ
    by_cases hρ : (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖
    · have : 0 ≤ (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1) := by positivity
      simpa [g, hρ] using this
    · simp [g, hρ]
  have hsum_eq :
      (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)) = ∑ ρ ∈ t, g ρ := by
    refine Finset.sum_congr rfl ?_
    intro ρ hρ
    have hρ' := hcond ρ hρ
    simp [g, hρ']
  -- Enclose `t` in a dyadic ball `ball m` for some `m`.
  have ht_subset :
      ∃ m : ℕ,
        t ⊆
          zerosBallFinset_of_entire
            (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m := by
    classical
    by_cases ht0 : t = ∅
    · exact ⟨0, by simp [ht0]⟩
    · have ht_ne : t.Nonempty := Finset.nonempty_iff_ne_empty.2 ht0
      let R : ℝ := t.sup' ht_ne fun ρ : Z.Zero => ‖Z.z ρ‖
      have hR : ∀ ρ : Z.Zero, ρ ∈ t → ‖Z.z ρ‖ ≤ R := by
        intro ρ hρ
        exact Finset.le_sup' (f := fun ρ : Z.Zero => ‖Z.z ρ‖) hρ
      have hpow : ∃ m : ℕ, max R 1 < (2 : ℝ) ^ m := by
        simpa using pow_unbounded_of_one_lt (max R 1) (by norm_num : (1 : ℝ) < 2)
      refine ⟨Nat.find hpow, ?_⟩
      intro ρ hρt
      have hρ_leR : ‖Z.z ρ‖ ≤ R := hR ρ hρt
      have hρ_le : ‖Z.z ρ‖ ≤ max R 1 := le_trans hρ_leR (le_max_left _ _)
      have hmax_le : max R 1 ≤ (2 : ℝ) ^ Nat.find hpow := le_of_lt (Nat.find_spec hpow)
      have hρ_ball : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ Nat.find hpow := le_trans hρ_le hmax_le
      exact
        (mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z)
          (h_zeros_only := h_zeros_only) (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) _ _).2
          hρ_ball
  rcases ht_subset with ⟨m, htm⟩
  -- Dyadic-shell bound for the "cumulative ball sum" of `g`.
  have hball :
      (∑ ρ ∈
          zerosBallFinset_of_entire
            (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m,
        g ρ)
        ≤ C * q ^ n₀ := by
    let w : Z.Zero → ℝ := fun ρ => (analyticOrderNatAt f (Z.z ρ) : ℝ)
    have hsub_ball :
        ∀ k : ℕ,
          zerosBallFinset_of_entire
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ⊆
            zerosBallFinset_of_entire
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) := by
      intro k ρ hρ
      have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k :=
        (mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ρ).1 hρ
      have hk_le : (2 : ℝ) ^ k ≤ (2 : ℝ) ^ (k + 1) :=
        pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_succ k)
      exact
        (mem_zerosBallFinset_of_entire_iff
          (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) ρ).2 (le_trans hnorm hk_le)
    have hshell :
        ∀ k : ℕ, n₀ + 1 ≤ k →
          (∑ ρ ∈
              zerosBallFinset_of_entire
                    (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                    (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) \
                zerosBallFinset_of_entire
                    (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                    (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k,
              g ρ)
            ≤ (2 : ℝ) ^ (lam + εcount) * Ccount * q ^ k := by
      intro k hk
      let ball : ℕ → Finset Z.Zero := fun t =>
        zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) t
      let diff : Finset Z.Zero := ball (k + 1) \ ball k
      have hk_pow_le : (2 : ℝ) ^ (n₀ + 1) ≤ (2 : ℝ) ^ k :=
        pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hk
      have hdiff_simp :
          (∑ ρ ∈ diff, g ρ) = ∑ ρ ∈ diff, w ρ / ‖Z.z ρ‖ ^ (p + 1) := by
        refine Finset.sum_congr rfl ?_
        intro ρ hρ
        have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
          intro hle
          have : ρ ∈ ball k :=
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ρ).2 hle
          exact (Finset.mem_sdiff.1 hρ).2 this
        have hlt : (2 : ℝ) ^ k < ‖Z.z ρ‖ := lt_of_not_ge hnot
        have hcond' : (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ :=
          lt_of_lt_of_le (hk_pow_le.trans_lt hlt) (le_rfl)
        simp [g, w, hcond']
      have hterm_le :
          ∀ ρ, ρ ∈ diff → w ρ / ‖Z.z ρ‖ ^ (p + 1) ≤ w ρ / ((2 : ℝ) ^ k) ^ (p + 1) := by
        intro ρ hρ
        have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
          intro hle
          have : ρ ∈ ball k :=
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) k ρ).2 hle
          exact (Finset.mem_sdiff.1 hρ).2 this
        have hk_le_norm : (2 : ℝ) ^ k ≤ ‖Z.z ρ‖ := le_of_lt (lt_of_not_ge hnot)
        have hk2_pos : 0 < ((2 : ℝ) ^ k) ^ (p + 1) := by positivity
        have hk2_le : ((2 : ℝ) ^ k) ^ (p + 1) ≤ ‖Z.z ρ‖ ^ (p + 1) :=
          pow_le_pow_left₀ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ k) hk_le_norm (p + 1)
        have hw_nonneg : 0 ≤ w ρ := by positivity [w]
        have hfrac : (1 : ℝ) / ‖Z.z ρ‖ ^ (p + 1) ≤ (1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1) := by
          simpa [one_div, inv_pow] using (one_div_le_one_div_of_le hk2_pos hk2_le)
        simpa [div_eq_mul_inv, one_div, mul_assoc, mul_left_comm, mul_comm] using
          (mul_le_mul_of_nonneg_left hfrac hw_nonneg)
      have hsum_le :
          (∑ ρ ∈ diff, w ρ / ‖Z.z ρ‖ ^ (p + 1)) ≤ ∑ ρ ∈ diff, w ρ / ((2 : ℝ) ^ k) ^ (p + 1) :=
        Finset.sum_le_sum hterm_le
      have hRcount_le : Rcount ≤ (2 : ℝ) ^ (k + 1) := by
        have hRcount_le_R0 : Rcount ≤ R0 := le_max_left _ _
        have hnR_le_k : nR ≤ k := le_trans hn₀_ge_nR (le_trans (Nat.le_succ n₀) hk)
        have hnR_le_k1 : nR ≤ k + 1 := Nat.le_succ_of_le hnR_le_k
        have hpow : (2 : ℝ) ^ nR ≤ (2 : ℝ) ^ (k + 1) :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hnR_le_k1
        exact le_trans (le_trans hRcount_le_R0 hnR) hpow
      have hcount_ball :
          (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) ≤
            Ccount * ((2 : ℝ) ^ (k + 1)) ^ (lam + εcount) :=
        hW_le ((2 : ℝ) ^ (k + 1)) hRcount_le
      have hball_finsum :
          (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) =
            ∑ ρ ∈ ball (k + 1), w ρ := by
        have hsupp :
            Function.support (fun ρ : Z.Zero => if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) ⊆
              ball (k + 1) := by
          intro ρ hρ
          have hne : (if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) ≠ 0 :=
            Function.mem_support.1 hρ
          have hle : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) := by
            by_contra hle; apply hne; simp [hle]
          exact
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) ρ).2 hle
        have this :=
          finsum_eq_sum_of_support_subset
            (f := fun ρ : Z.Zero => if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0)
            (s := ball (k + 1)) hsupp
        have hsum_if :
            (∑ ρ ∈ ball (k + 1), if ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) then w ρ else 0) =
              ∑ ρ ∈ ball (k + 1), w ρ := by
          refine Finset.sum_congr rfl ?_
          intro ρ hρ
          have hle : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1) :=
            (mem_zerosBallFinset_of_entire_iff
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (k + 1) ρ).1 hρ
          simp [hle]
        simpa [hsum_if] using this
      have hsum_ball :
          (∑ ρ ∈ ball (k + 1), w ρ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ (lam + εcount) := by
        simpa [hball_finsum] using hcount_ball
      have hsum_mult_diff :
          (∑ ρ ∈ diff, w ρ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ (lam + εcount) := by
        have hdiff_le_ball :
            (∑ ρ ∈ diff, w ρ) ≤ ∑ ρ ∈ ball (k + 1), w ρ := by
          have hw_nonneg : ∀ ρ ∈ ball (k + 1), ρ ∉ diff → 0 ≤ w ρ := by
            intro ρ _ _
            positivity [w]
          exact
            Finset.sum_le_sum_of_subset_of_nonneg
              (Finset.sdiff_subset : diff ⊆ ball (k + 1)) hw_nonneg
        exact le_trans hdiff_le_ball hsum_ball
      -- Put everything together.
      have hpow_rat :
          ((2 : ℝ) ^ k) ^ ((lam + εcount) - ((p : ℝ) + 1)) =
            ((2 : ℝ) ^ k) ^ (lam + εcount) / ((2 : ℝ) ^ k) ^ (p + 1 : ℕ) := by
        have hk_pos : 0 < (2 : ℝ) ^ k := by positivity
        have hsub : (lam + εcount) - ((p : ℝ) + 1) = (lam + εcount) - (↑(p + 1) : ℝ) := by
          push_cast; ring
        have hnat : ((2 : ℝ) ^ k) ^ (p + 1 : ℕ) = ((2 : ℝ) ^ k) ^ ((p + 1 : ℕ) : ℝ) := by
          simpa using (Real.rpow_natCast ((2 : ℝ) ^ k) (p + 1)).symm
        rw [hnat]
        rw [hsub]
        exact Real.rpow_sub hk_pos (lam + εcount) ((p + 1 : ℕ) : ℝ)
      have hqk : q ^ k = ((2 : ℝ) ^ k) ^ ((lam + εcount) - ((p : ℝ) + 1)) := by
        simpa [q] using
          (Real.rpow_pow_comm (x := (2 : ℝ)) (hx := by positivity)
            ((lam + εcount) - ((p : ℝ) + 1)) k)
      have hrewrite :
          Ccount * ((2 : ℝ) ^ (k + 1)) ^ (lam + εcount) *
              ((1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1))
            = (2 : ℝ) ^ (lam + εcount) * Ccount * q ^ k := by
        have hpow_succ : (2 : ℝ) ^ (k + 1) = 2 * (2 : ℝ) ^ k := by
          simp [pow_succ, mul_comm]
        have hpowk_nonneg : 0 ≤ (2 : ℝ) ^ k := by positivity
        have h2_nonneg : (0 : ℝ) ≤ 2 := by norm_num
        calc
          Ccount * ((2 : ℝ) ^ (k + 1)) ^ (lam + εcount) *
              ((1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1))
              =
              Ccount * ((2 * (2 : ℝ) ^ k) ^ (lam + εcount)) *
                ((1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1)) := by
                simp [hpow_succ]
          _ =
              Ccount * ((2 : ℝ) ^ (lam + εcount) * ((2 : ℝ) ^ k) ^ (lam + εcount)) *
                  ((1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1)) := by
                have hsplit :
                    ((2 : ℝ) * (2 : ℝ) ^ k) ^ (lam + εcount) =
                      (2 : ℝ) ^ (lam + εcount) * ((2 : ℝ) ^ k) ^ (lam + εcount) := by
                  simpa using
                    (Real.mul_rpow (x := (2 : ℝ)) (y := (2 : ℝ) ^ k) (z := lam + εcount)
                      h2_nonneg hpowk_nonneg)
                simp [hsplit, mul_assoc,
                  -mul_eq_mul_left_iff, -mul_eq_mul_right_iff]
          _ =
              (2 : ℝ) ^ (lam + εcount) * Ccount *
                  (((2 : ℝ) ^ k) ^ (lam + εcount) / ((2 : ℝ) ^ k) ^ (p + 1)) := by
                simp [div_eq_mul_inv, mul_assoc, mul_comm,
                  -mul_eq_mul_left_iff, -mul_eq_mul_right_iff]
          _ = (2 : ℝ) ^ (lam + εcount) * Ccount *
                (((2 : ℝ) ^ k) ^ ((lam + εcount) - ((p : ℝ) + 1))) := by
                rw [hpow_rat]
          _ = (2 : ℝ) ^ (lam + εcount) * Ccount * q ^ k := by
                rw [← hqk]
      calc
        (∑ ρ ∈ diff, g ρ) = ∑ ρ ∈ diff, w ρ / ‖Z.z ρ‖ ^ (p + 1) := hdiff_simp
        _ ≤ ∑ ρ ∈ diff, w ρ / ((2 : ℝ) ^ k) ^ (p + 1) := hsum_le
        _ = (∑ ρ ∈ diff, w ρ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1)) := by
              simp [div_eq_mul_inv, Finset.sum_mul]
        _ ≤ (Ccount * ((2 : ℝ) ^ (k + 1)) ^ (lam + εcount)) *
              ((1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1)) := by
              have hconst_nonneg : 0 ≤ (1 : ℝ) / ((2 : ℝ) ^ k) ^ (p + 1) := by positivity
              exact mul_le_mul_of_nonneg_right hsum_mult_diff hconst_nonneg
        _ = (2 : ℝ) ^ (lam + εcount) * Ccount * q ^ k := by
              simpa [mul_assoc, mul_left_comm, mul_comm] using hrewrite
    -- Sum the shells from `n₀ + 1` through `m - 1`.
    by_cases hm : m ≤ n₀ + 1
    · have hsum0 :
          (∑ ρ ∈
              zerosBallFinset_of_entire
                (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m,
            g ρ) = 0 := by
        refine Finset.sum_eq_zero ?_
        intro ρ hρ
        have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ m :=
          (mem_zerosBallFinset_of_entire_iff
            (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
            (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m ρ).1 hρ
        have hpow : (2 : ℝ) ^ m ≤ (2 : ℝ) ^ (n₀ + 1) :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hm
        have : ¬ (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ := not_lt_of_ge (le_trans hnorm hpow)
        simp [g, this]
      have hrhs_nonneg : 0 ≤ C * q ^ n₀ := mul_nonneg hC_nonneg (by positivity)
      simpa [hsum0] using hrhs_nonneg
    · have hm_ge : n₀ + 1 < m := lt_of_not_ge hm
      let ball : ℕ → Finset Z.Zero := fun t =>
        zerosBallFinset_of_entire (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
          (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) t
      set t' : ℕ := m - (n₀ + 1) with ht'_def
      have ht'_pos : 0 < t' := Nat.sub_pos_of_lt hm_ge
      have hm_eq : m = n₀ + 1 + t' := (Nat.add_sub_cancel' (le_of_lt hm_ge)).symm
      have hind :
          ∀ t : ℕ,
            (∑ ρ ∈ ball (n₀ + 1 + t), g ρ) ≤
              (2 : ℝ) ^ (lam + εcount) * Ccount *
                (∑ i ∈ Finset.range t, q ^ (n₀ + 1 + i)) := by
        intro t
        induction t using Nat.rec with
        | zero =>
            have hsum0 :
                (∑ ρ ∈ ball (n₀ + 1), g ρ) = 0 := by
              refine Finset.sum_eq_zero ?_
              intro ρ hρ
              have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n₀ + 1) :=
                (mem_zerosBallFinset_of_entire_iff
                  (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
                  (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) (n₀ + 1) ρ).1 hρ
              have : ¬ (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖ := not_lt_of_ge hnorm
              simp [g, this]
            simp [ball, hsum0]
        | succ j ih =>
            set k : ℕ := n₀ + 1 + j
            have hk : n₀ + 1 ≤ k := Nat.le_add_right _ _
            have hsub : ball k ⊆ ball (k + 1) := by
              simpa [ball] using hsub_ball k
            have hdecomp :=
              (Finset.sum_sdiff (s₁ := ball k) (s₂ := ball (k + 1)) (f := g) hsub).symm
            have hshell_le :
                (∑ ρ ∈ ball (k + 1) \ ball k, g ρ)
                  ≤ (2 : ℝ) ^ (lam + εcount) * Ccount * q ^ k := hshell k hk
            have hgeom :
                (∑ i ∈ Finset.range (j + 1), q ^ (n₀ + 1 + i))
                  = (∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) + q ^ k := by
              simpa [k, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using
                (Finset.sum_range_succ (f := fun i => q ^ (n₀ + 1 + i)) j)
            have ih' :
                (∑ ρ ∈ ball k, g ρ) ≤
                  (2 : ℝ) ^ (lam + εcount) * Ccount *
                    (∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) := by
              simpa [k, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using ih
            calc
              (∑ ρ ∈ ball (k + 1), g ρ)
                  = (∑ ρ ∈ ball (k + 1) \ ball k, g ρ) + (∑ ρ ∈ ball k, g ρ) := by
                        simpa [k, add_assoc, add_comm, add_left_comm] using hdecomp
              _ ≤ (2 : ℝ) ^ (lam + εcount) * Ccount * q ^ k +
                    (2 : ℝ) ^ (lam + εcount) * Ccount *
                      (∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) := by
                        gcongr
              _ = (2 : ℝ) ^ (lam + εcount) * Ccount *
                    ((∑ i ∈ Finset.range j, q ^ (n₀ + 1 + i)) + q ^ k) := by
                        ring
              _ = (2 : ℝ) ^ (lam + εcount) * Ccount *
                    (∑ i ∈ Finset.range (j + 1), q ^ (n₀ + 1 + i)) := by
                        simp [hgeom]
      have hfinite_le :
          (∑ ρ ∈ ball m, g ρ) ≤
            (2 : ℝ) ^ (lam + εcount) * Ccount *
              (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) := by
        simpa [hm_eq, ball] using hind t'
      have hgeom_le :
          (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) ≤ (q ^ (n₀ + 1)) * (1 - q)⁻¹ := by
        have hsum : Summable (fun i : ℕ => q ^ i) :=
          summable_geometric_of_lt_one (le_of_lt hq_pos) hq_lt_one
        have hsum' : Summable (fun i : ℕ => q ^ (n₀ + 1) * q ^ i) :=
          hsum.mul_left (q ^ (n₀ + 1))
        have hnonneg : ∀ i : ℕ, 0 ≤ q ^ (n₀ + 1) * q ^ i := by
          intro i; positivity
        have hle_tsum :
            (∑ i ∈ Finset.range t', q ^ (n₀ + 1) * q ^ i) ≤ ∑' i : ℕ, q ^ (n₀ + 1) * q ^ i := by
          refine
            Summable.sum_le_tsum
              (s := Finset.range t')
              (f := fun i : ℕ => q ^ (n₀ + 1) * q ^ i) ?_ hsum'
          intro i hi; exact hnonneg i
        have hpow_add : ∀ i : ℕ, q ^ (n₀ + 1 + i) = q ^ (n₀ + 1) * q ^ i := by
          intro i; simp [pow_add, mul_assoc]
        have hsum_eq :
            (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i)) =
              (∑ i ∈ Finset.range t', q ^ (n₀ + 1) * q ^ i) := by
          refine Finset.sum_congr rfl ?_
          intro i hi; simp [hpow_add i]
        have htsum_eq :
            (∑' i : ℕ, q ^ (n₀ + 1) * q ^ i) = (q ^ (n₀ + 1)) * (1 - q)⁻¹ := by
          have hgeom0 : (∑' i : ℕ, q ^ i) = (1 - q)⁻¹ :=
            tsum_geometric_of_lt_one (h₁ := le_of_lt hq_pos) (h₂ := hq_lt_one)
          calc
            (∑' i : ℕ, q ^ (n₀ + 1) * q ^ i) = (q ^ (n₀ + 1)) * ∑' i : ℕ, q ^ i := by
                rw [tsum_mul_left]
            _ = (q ^ (n₀ + 1)) * (1 - q)⁻¹ := by rw [hgeom0]
        calc
          (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i))
              = (∑ i ∈ Finset.range t', q ^ (n₀ + 1) * q ^ i) := hsum_eq
          _ ≤ ∑' i : ℕ, q ^ (n₀ + 1) * q ^ i := hle_tsum
          _ = (q ^ (n₀ + 1)) * (1 - q)⁻¹ := htsum_eq
      have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
      have hfinal :
          (∑ ρ ∈ ball m, g ρ) ≤ C * q ^ n₀ := by
        calc
          (∑ ρ ∈ ball m, g ρ)
              ≤ (2 : ℝ) ^ (lam + εcount) * Ccount * (q ^ (n₀ + 1) * (1 - q)⁻¹) := by
                have hpow_nonneg : 0 ≤ (2 : ℝ) ^ (lam + εcount) :=
                  Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
                have hconst_nonneg : 0 ≤ (2 : ℝ) ^ (lam + εcount) * Ccount :=
                  mul_nonneg hpow_nonneg hCcount_nonneg
                have hmult :
                    (2 : ℝ) ^ (lam + εcount) * Ccount *
                        (∑ i ∈ Finset.range t', q ^ (n₀ + 1 + i))
                      ≤ (2 : ℝ) ^ (lam + εcount) * Ccount *
                        (q ^ (n₀ + 1) * (1 - q)⁻¹) := by
                  simpa [mul_assoc] using mul_le_mul_of_nonneg_left hgeom_le hconst_nonneg
                exact le_trans hfinite_le hmult
          _ = (2 : ℝ) ^ (lam + εcount) * Ccount * q / (1 - q) * q ^ n₀ := by
                have hqsucc : q ^ (n₀ + 1) = q ^ n₀ * q := by
                  simp [pow_succ]
                rw [hqsucc]
                field_simp [hden_pos.ne']
          _ = C * q ^ n₀ := by
                simp [C, mul_assoc, mul_left_comm, mul_comm, div_eq_mul_inv]
      simpa [ball] using hfinal
  have hsum_le :
      (∑ ρ ∈ t, g ρ) ≤
        ∑ ρ ∈
            zerosBallFinset_of_entire
              (hf_entire := hf_entire) (Z := Z) (h_zeros_only := h_zeros_only)
              (h_inj := h_inj) (h_z_ne_zero := h_z_ne_zero) m,
          g ρ := by
    refine Finset.sum_le_sum_of_subset_of_nonneg htm ?_
    intro ρ _ _
    exact hg_nonneg ρ
  have hbound :
      (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)) ≤ C * q ^ n₀ := by
    calc
      (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)) = ∑ ρ ∈ t, g ρ := hsum_eq
      _ ≤ _ := hsum_le
      _ ≤ C * q ^ n₀ := hball
  have hCq_lt : C * q ^ n₀ < ε := by
    have habs : |C * q ^ n₀| = C * q ^ n₀ := by
      have : 0 ≤ C * q ^ n₀ := mul_nonneg hC_nonneg (by positivity)
      rw [abs_of_nonneg this]
    have hlt : |C * q ^ n₀| < ε := hn₀_lt
    rwa [habs] at hlt
  have hsum_nonneg :
      0 ≤ ∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1) := by
    refine Finset.sum_nonneg ?_
    intro ρ _
    positivity
  have hnorm_lt :
      ‖∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)‖ < ε := by
    have hsum_lt :
        (∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)) < ε :=
      lt_of_le_of_lt hbound hCq_lt
    have habs_eq :
        |∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)| =
          ∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1) :=
      abs_of_nonneg hsum_nonneg
    have habs_lt :
        |∑ ρ ∈ t, (analyticOrderNatAt f (Z.z ρ) : ℝ) / ‖Z.z ρ‖ ^ (p + 1)| < ε := by
      simpa [habs_eq] using hsum_lt
    simpa [Real.norm_eq_abs] using habs_lt
  exact hnorm_lt

end OrderOne

end Hadamard
~~~~~~

## Hadamard.OrderOne.TailEstimates

Path: `source/Hadamard/OrderOne/TailEstimates.lean`

Original source lines: 1–1593

Full file SHA256: `aec94ba321ff4f1104e982729b43b0fcbc23f6448cc4e89194073532391c2fed`

Origin: https://github.com/nicholasbulka/li-criterion-rh-equivalence-lean/blob/35df682f3b709ffe5fbcfdd452dfa964bd622b87/Hadamard/OrderOne/TailEstimates.lean

~~~~~~lean
/-
Copyright (c) 2026 Nicholas Bulka. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Nicholas Bulka
-/
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Archimedean.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Max
import Mathlib.Data.Set.Card
import Mathlib.Topology.Algebra.InfiniteSum.Real
import Hadamard.OrderOne.CofiniteControl
import Hadamard.OrderOne.ZeroCountingBounds

/-! ### Dyadic ball finsets under `∑ 1/‖z ρ‖² < ∞` -/

open scoped BigOperators

-- This module bundles several long tail-estimate developments.
set_option linter.style.longFile 1700

namespace Hadamard

namespace OrderOne

open Real

/-- The finite set of indices with `‖Z.z ρ‖ ≤ 2^n`. -/
theorem zerosBallFinite {f : ℂ → ℂ} (Z : ZeroSet f)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_summable : Summable (fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2))
    (n : ℕ) : ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n} : Set Z.Zero).Finite :=
  Hadamard.OrderOne.finite_norm_le_of_summable_inv_norm_sq
    (z := Z.z) (hz0 := h_z_ne_zero) h_summable (R := (2 : ℝ) ^ n) (by positivity)

/-- The set of indices with `‖Z.z ρ‖ ≤ 2^n`, as a `Finset`. -/
noncomputable def zerosBallFinset {f : ℂ → ℂ} (Z : ZeroSet f)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_summable : Summable (fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2))
    (n : ℕ) : Finset Z.Zero :=
  (zerosBallFinite Z h_z_ne_zero h_summable n).toFinset

@[simp]
lemma mem_zerosBallFinset_iff {f : ℂ → ℂ} (Z : ZeroSet f)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_summable : Summable (fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2))
    (n : ℕ) (ρ : Z.Zero) :
    ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable n ↔ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n := by
  classical
  simp [zerosBallFinset]

@[simp]
lemma card_zerosBallFinset {f : ℂ → ℂ} (Z : ZeroSet f)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_summable : Summable (fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2))
    (n : ℕ) :
    (zerosBallFinset Z h_z_ne_zero h_summable n).card =
      ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n} : Set Z.Zero).ncard := by
  classical
  simpa [zerosBallFinset] using
    (Set.ncard_eq_toFinset_card ({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ n} : Set Z.Zero)
          (zerosBallFinite Z h_z_ne_zero h_summable n)).symm

/-!
Tail estimates for genus‑1 canonical products (order‑≤1 regime).

This module will eventually house the dyadic-shell bounds (Conway XI §1–2) used in the growth
analysis. For now, we start by packaging a convenient `O(r^(1+ε))` bound for the zero-counting
function coming from `ZeroCountingBounds`.
-/

theorem ncard_zeros_le_rpow
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_simple : ∀ ρ : Z.Zero, deriv f (Z.z ρ) ≠ 0) :
    ∀ ε : ℝ, 0 < ε →
      ∃ R₀ C : ℝ, 0 ≤ C ∧
        ∀ r : ℝ, R₀ ≤ r →
          (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero).ncard : ℝ) ≤ C * r ^ ((1 : ℝ) + ε) := by
  intro ε hε
  obtain ⟨R₁, hR₁⟩ :=
    ncard_zeros_le_of_order_le_one (f := f) hf_entire hf_finite hf_order_le Z h_zeros_only h_inj
      h_z_ne_zero h_simple ε hε
  have hlog2_pos : 0 < Real.log 2 := by
    simpa using Real.log_pos (by norm_num : (1 : ℝ) < 2)
  let C : ℝ := ((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2
  refine ⟨max R₁ 1, C, ?_, ?_⟩
  · have hC_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| := by
      have hpow : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) := Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
      exact add_nonneg hpow (abs_nonneg _)
    exact div_nonneg hC_nonneg (le_of_lt hlog2_pos)
  intro r hr
  have hr_ge_R1 : R₁ ≤ r := le_trans (le_max_left _ _) hr
  have hr_ge1 : (1 : ℝ) ≤ r := le_trans (le_max_right _ _) hr
  have hr_nonneg : 0 ≤ r := le_trans (by norm_num : (0 : ℝ) ≤ 1) hr_ge1
  have hcount := hR₁ r hr_ge_R1
  -- First, replace `-log ‖f 0‖` by `|log ‖f 0‖|`.
  have hnum_le :
      (2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖
        ≤ (2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| := by
    have : -Real.log ‖f 0‖ ≤ |Real.log ‖f 0‖| := by
      simpa using (neg_le_abs (Real.log ‖f 0‖))
    linarith
  have hcount' :
      (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ r} : Set Z.Zero).ncard : ℝ)
        ≤ ((2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2 := by
    have hfrac_le :
        ((2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖) / Real.log 2
          ≤ ((2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2 :=
      div_le_div_of_nonneg_right hnum_le (le_of_lt hlog2_pos)
    exact le_trans hcount hfrac_le
  -- Rewrite `(2*r)^(1+ε)` and absorb the constant using `r^(1+ε) ≥ 1`.
  have hrpow_ge1 : (1 : ℝ) ≤ r ^ ((1 : ℝ) + ε) :=
    Real.one_le_rpow hr_ge1 (by linarith [hε] : (0 : ℝ) ≤ (1 : ℝ) + ε)
  have hmul_rpow :
      (2 * r) ^ ((1 : ℝ) + ε)
        = (2 : ℝ) ^ ((1 : ℝ) + ε) * r ^ ((1 : ℝ) + ε) := by
    simpa using
      (Real.mul_rpow (x := (2 : ℝ)) (y := r) (by norm_num : (0 : ℝ) ≤ (2 : ℝ)) hr_nonneg
        (z := (1 : ℝ) + ε))
  have hnum2 :
      (2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|
        ≤ ((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) * r ^ ((1 : ℝ) + ε) := by
    have habs_mul : |Real.log ‖f 0‖| ≤ |Real.log ‖f 0‖| * r ^ ((1 : ℝ) + ε) :=
      le_mul_of_one_le_right (abs_nonneg _) hrpow_ge1
    calc
      (2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|
          = (2 : ℝ) ^ ((1 : ℝ) + ε) * r ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| := by
              simp [hmul_rpow]
      _ ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * r ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| * r ^ ((1 : ℝ) + ε) := by
              gcongr
      _ = ((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) * r ^ ((1 : ℝ) + ε) := by
              ring
  have hfrac2 :
      ((2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2
        ≤ (((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2) * r ^ ((1 : ℝ) + ε) := by
    have := div_le_div_of_nonneg_right hnum2 (le_of_lt hlog2_pos)
    simpa [div_mul_eq_mul_div, mul_assoc] using this
  have := le_trans hcount' hfrac2
  simpa [C, mul_assoc] using this

/-- **General-order multiplicity-weighted zero counting, clean form.**

The `order f ≤ lam` analogue of `sum_multiplicity_zeros_le_rpow`, giving a
constant bound of the form `C * r ^ (lam + ε)` for `r` large. Obtained by
composing the general-order Jensen bound with a rewrite to absorb the
`log ‖f 0‖` term.

This is Step 1 of `tmp-conway/HadamardGeneral.lean` (used to derive
summability of `∑ mult(ρ) / ‖ρ‖^(p+1)` under order `≤ lam`). -/
theorem sum_multiplicity_zeros_le_rpow_of_order_le
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) {lam : ℝ} (hf_order_le : order f ≤ lam)
    (hlam_nonneg : 0 ≤ lam)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0) :
    ∀ ε : ℝ, 0 < ε →
      ∃ R₀ C : ℝ, 0 ≤ C ∧
        ∀ r : ℝ, R₀ ≤ r →
          (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ≤
            C * r ^ (lam + ε) := by
  intro ε hε
  obtain ⟨R₁, hR₁⟩ :=
    OrderOne.sum_multiplicity_zeros_le_of_order_le (f := f) hf_entire hf_finite hf_order_le Z
      h_zeros_only h_inj h_z_ne_zero ε hε
  have hlog2_pos : 0 < Real.log 2 := by
    simpa using Real.log_pos (by norm_num : (1 : ℝ) < 2)
  let C : ℝ := ((2 : ℝ) ^ (lam + ε) + |Real.log ‖f 0‖|) / Real.log 2
  refine ⟨max R₁ 1, C, ?_, ?_⟩
  · have hC_nonneg : 0 ≤ (2 : ℝ) ^ (lam + ε) + |Real.log ‖f 0‖| := by
      have hpow : 0 ≤ (2 : ℝ) ^ (lam + ε) := Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
      exact add_nonneg hpow (abs_nonneg _)
    exact div_nonneg hC_nonneg (le_of_lt hlog2_pos)
  intro r hr
  have hr_ge_R1 : R₁ ≤ r := le_trans (le_max_left _ _) hr
  have hr_ge1 : (1 : ℝ) ≤ r := le_trans (le_max_right _ _) hr
  have hr_nonneg : 0 ≤ r := le_trans (by norm_num : (0 : ℝ) ≤ 1) hr_ge1
  have hcount := hR₁ r hr_ge_R1
  have hnum_le :
      (2 * r) ^ (lam + ε) - Real.log ‖f 0‖
        ≤ (2 * r) ^ (lam + ε) + |Real.log ‖f 0‖| := by
    have : -Real.log ‖f 0‖ ≤ |Real.log ‖f 0‖| := by
      simpa using (neg_le_abs (Real.log ‖f 0‖))
    linarith
  have hcount' :
      (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
        ≤ ((2 * r) ^ (lam + ε) + |Real.log ‖f 0‖|) / Real.log 2 := by
    have hfrac_le :
        ((2 * r) ^ (lam + ε) - Real.log ‖f 0‖) / Real.log 2
          ≤ ((2 * r) ^ (lam + ε) + |Real.log ‖f 0‖|) / Real.log 2 :=
      div_le_div_of_nonneg_right hnum_le (le_of_lt hlog2_pos)
    exact le_trans hcount hfrac_le
  have hlam_eps_nonneg : (0 : ℝ) ≤ lam + ε := add_nonneg hlam_nonneg (le_of_lt hε)
  have hrpow_ge1 : (1 : ℝ) ≤ r ^ (lam + ε) :=
    Real.one_le_rpow hr_ge1 hlam_eps_nonneg
  have hmul_rpow :
      (2 * r) ^ (lam + ε) =
        (2 : ℝ) ^ (lam + ε) * r ^ (lam + ε) := by
    simpa using
      (Real.mul_rpow (x := (2 : ℝ)) (y := r) (by norm_num : (0 : ℝ) ≤ (2 : ℝ)) hr_nonneg
        (z := lam + ε))
  have hnum2 :
      (2 * r) ^ (lam + ε) + |Real.log ‖f 0‖|
        ≤ ((2 : ℝ) ^ (lam + ε) + |Real.log ‖f 0‖|) * r ^ (lam + ε) := by
    have habs_mul : |Real.log ‖f 0‖| ≤ |Real.log ‖f 0‖| * r ^ (lam + ε) :=
      le_mul_of_one_le_right (abs_nonneg _) hrpow_ge1
    calc
      (2 * r) ^ (lam + ε) + |Real.log ‖f 0‖|
          = (2 : ℝ) ^ (lam + ε) * r ^ (lam + ε) + |Real.log ‖f 0‖| := by
              simp [hmul_rpow]
      _ ≤ (2 : ℝ) ^ (lam + ε) * r ^ (lam + ε) + |Real.log ‖f 0‖| * r ^ (lam + ε) := by
              gcongr
      _ = ((2 : ℝ) ^ (lam + ε) + |Real.log ‖f 0‖|) * r ^ (lam + ε) := by
              ring
  have hfrac2 :
      ((2 * r) ^ (lam + ε) + |Real.log ‖f 0‖|) / Real.log 2
        ≤ (((2 : ℝ) ^ (lam + ε) + |Real.log ‖f 0‖|) / Real.log 2) * r ^ (lam + ε) := by
    have := div_le_div_of_nonneg_right hnum2 (le_of_lt hlog2_pos)
    simpa [div_mul_eq_mul_div, mul_assoc] using this
  have := le_trans hcount' hfrac2
  simpa [C, mul_assoc] using this

theorem sum_multiplicity_zeros_le_rpow
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0) :
    ∀ ε : ℝ, 0 < ε →
      ∃ R₀ C : ℝ, 0 ≤ C ∧
        ∀ r : ℝ, R₀ ≤ r →
          (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0) ≤
            C * r ^ ((1 : ℝ) + ε) := by
  intro ε hε
  obtain ⟨R₁, hR₁⟩ :=
    OrderOne.sum_multiplicity_zeros_le_of_order_le_one (f := f) hf_entire hf_finite hf_order_le Z
      h_zeros_only h_inj h_z_ne_zero ε hε
  have hlog2_pos : 0 < Real.log 2 := by
    simpa using Real.log_pos (by norm_num : (1 : ℝ) < 2)
  let C : ℝ := ((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2
  refine ⟨max R₁ 1, C, ?_, ?_⟩
  · have hC_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| := by
      have hpow : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) := Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
      exact add_nonneg hpow (abs_nonneg _)
    exact div_nonneg hC_nonneg (le_of_lt hlog2_pos)
  intro r hr
  have hr_ge_R1 : R₁ ≤ r := le_trans (le_max_left _ _) hr
  have hr_ge1 : (1 : ℝ) ≤ r := le_trans (le_max_right _ _) hr
  have hr_nonneg : 0 ≤ r := le_trans (by norm_num : (0 : ℝ) ≤ 1) hr_ge1
  have hcount := hR₁ r hr_ge_R1
  -- First, replace `-log ‖f 0‖` by `|log ‖f 0‖|`.
  have hnum_le :
      (2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖
        ≤ (2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| := by
    have : -Real.log ‖f 0‖ ≤ |Real.log ‖f 0‖| := by
      simpa using (neg_le_abs (Real.log ‖f 0‖))
    linarith
  have hcount' :
      (∑ᶠ ρ : Z.Zero, if ‖Z.z ρ‖ ≤ r then (analyticOrderNatAt f (Z.z ρ) : ℝ) else 0)
        ≤ ((2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2 := by
    have hfrac_le :
        ((2 * r) ^ ((1 : ℝ) + ε) - Real.log ‖f 0‖) / Real.log 2
          ≤ ((2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2 :=
      div_le_div_of_nonneg_right hnum_le (le_of_lt hlog2_pos)
    exact le_trans hcount hfrac_le
  -- Rewrite `(2*r)^(1+ε)` and absorb the constant using `r^(1+ε) ≥ 1`.
  have hrpow_ge1 : (1 : ℝ) ≤ r ^ ((1 : ℝ) + ε) :=
    Real.one_le_rpow hr_ge1 (by linarith [hε] : (0 : ℝ) ≤ (1 : ℝ) + ε)
  have hmul_rpow :
      (2 * r) ^ ((1 : ℝ) + ε) =
        (2 : ℝ) ^ ((1 : ℝ) + ε) * r ^ ((1 : ℝ) + ε) := by
    simpa using
      (Real.mul_rpow (x := (2 : ℝ)) (y := r) (by norm_num : (0 : ℝ) ≤ (2 : ℝ)) hr_nonneg
        (z := (1 : ℝ) + ε))
  have hnum2 :
      (2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|
        ≤ ((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) * r ^ ((1 : ℝ) + ε) := by
    have habs_mul : |Real.log ‖f 0‖| ≤ |Real.log ‖f 0‖| * r ^ ((1 : ℝ) + ε) :=
      le_mul_of_one_le_right (abs_nonneg _) hrpow_ge1
    calc
      (2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|
          = (2 : ℝ) ^ ((1 : ℝ) + ε) * r ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| := by
              simp [hmul_rpow]
      _ ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * r ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖| * r ^ ((1 : ℝ) + ε) := by
              gcongr
      _ = ((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) * r ^ ((1 : ℝ) + ε) := by
              ring
  have hfrac2 :
      ((2 * r) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2
        ≤ (((2 : ℝ) ^ ((1 : ℝ) + ε) + |Real.log ‖f 0‖|) / Real.log 2) * r ^ ((1 : ℝ) + ε) := by
    have := div_le_div_of_nonneg_right hnum2 (le_of_lt hlog2_pos)
    simpa [div_mul_eq_mul_div, mul_assoc] using this
  have := le_trans hcount' hfrac2
  simpa [C, mul_assoc] using this

/-! ### A dyadic `O(r^ε)` bound for `∑_{‖ρ‖ ≤ r} 1/‖ρ‖` (finite sums) -/

theorem sum_invNorm_le_rpow_of_two_pow
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_simple : ∀ ρ : Z.Zero, deriv f (Z.z ρ) ≠ 0)
    (h_summable : Summable (fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2)) :
    ∀ ε : ℝ, 0 < ε →
      ∃ n₀ : ℕ, ∃ C : ℝ, 0 ≤ C ∧
        ∀ n : ℕ, n₀ ≤ n →
          (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable n, (1 : ℝ) / ‖Z.z ρ‖)
            ≤ C * ((2 : ℝ) ^ n) ^ ε := by
  classical
  intro ε hε
  -- Zero-counting bound `N(r) = O(r^(1+ε))`.
  obtain ⟨Rcount, Ccount, hCcount_nonneg, hN_le⟩ :=
    ncard_zeros_le_rpow (f := f) hf_entire hf_finite hf_order_le Z h_zeros_only h_inj h_z_ne_zero
      h_simple ε hε
  -- Choose `n₀` so that `max Rcount 1 ≤ 2^n₀`.
  let R0 : ℝ := max Rcount 1
  have hR0_le : ∃ n₀ : ℕ, R0 ≤ (2 : ℝ) ^ n₀ := by
    have h : ∃ n : ℕ, R0 < (2 : ℝ) ^ n := by
      simpa using (pow_unbounded_of_one_lt R0 (by norm_num : (1 : ℝ) < 2))
    refine ⟨Nat.find h, le_of_lt (Nat.find_spec h)⟩
  obtain ⟨n₀, hn₀⟩ := hR0_le
  have hRcount_le : Rcount ≤ (2 : ℝ) ^ n₀ := le_trans (le_max_left _ _) hn₀
  have hone_le : (1 : ℝ) ≤ (2 : ℝ) ^ n₀ := le_trans (le_max_right _ _) hn₀
  -- Define the constant `C`.
  let smallSum : ℝ := ∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable n₀, (1 : ℝ) / ‖Z.z ρ‖
  have hsmallSum_nonneg : 0 ≤ smallSum := by
    refine Finset.sum_nonneg ?_
    intro ρ hρ
    positivity
  let q : ℝ := (2 : ℝ) ^ ε
  have hq_pos : 0 < q := by
    simpa [q] using (Real.rpow_pos_of_pos (by norm_num : (0 : ℝ) < 2) ε)
  have hq_gt1 : 1 < q := by
    simpa [q] using (Real.one_lt_rpow (by norm_num : (1 : ℝ) < 2) hε)
  have hq_sub_pos : 0 < q - 1 := sub_pos.mpr hq_gt1
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  let Ctail : ℝ := (2 * Ccount) * q / (q - 1)
  let C : ℝ := smallSum + Ctail
  have hC_nonneg : 0 ≤ C := by
    have hCtail_nonneg : 0 ≤ Ctail := by
      have : 0 ≤ (2 * Ccount) * q := by
        have : 0 ≤ (2 : ℝ) * Ccount := mul_nonneg (by norm_num) hCcount_nonneg
        exact mul_nonneg this (le_of_lt hq_pos)
      exact div_nonneg this (le_of_lt hq_sub_pos)
    exact add_nonneg hsmallSum_nonneg hCtail_nonneg
  refine ⟨n₀, C, hC_nonneg, ?_⟩
  intro n hn
  have hn_eq : n₀ + (n - n₀) = n := Nat.add_sub_of_le hn
  -- Induction on the offset `m = n - n₀`.
  have hmain :
      ∀ m : ℕ,
        (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable (n₀ + m), (1 : ℝ) / ‖Z.z ρ‖)
          ≤ C * ((2 : ℝ) ^ (n₀ + m)) ^ ε := by
    intro m
    induction m with
    | zero =>
        -- Base case: `n = n₀`.
        have hpow_ge1 : (1 : ℝ) ≤ ((2 : ℝ) ^ n₀) ^ ε :=
          Real.one_le_rpow hone_le (le_of_lt hε)
        have hsmall_le_C : smallSum ≤ C := by
          have : 0 ≤ Ctail := by
            have : 0 ≤ (2 * Ccount) * q := by
              have : 0 ≤ (2 : ℝ) * Ccount := mul_nonneg (by norm_num) hCcount_nonneg
              exact mul_nonneg this (le_of_lt hq_pos)
            exact div_nonneg this (le_of_lt hq_sub_pos)
          simpa [C] using (le_add_of_nonneg_right (a := smallSum) (b := Ctail) this)
        -- `smallSum = sum over the ball at radius 2^n₀`.
        have hsmall_eq :
            (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable n₀, ‖Z.z ρ‖⁻¹) = smallSum := by
          simp [smallSum, one_div]
        -- Conclude by `smallSum ≤ C * ((2^n₀)^ε)` since `((2^n₀)^ε) ≥ 1`.
        have : smallSum ≤ C * ((2 : ℝ) ^ n₀) ^ ε := by
          have : smallSum ≤ C := hsmall_le_C
          have : C ≤ C * ((2 : ℝ) ^ n₀) ^ ε := by
            exact le_mul_of_one_le_right hC_nonneg hpow_ge1
          exact le_trans hsmall_le_C this
        simpa [hsmall_eq] using this
    | succ m ih =>
        -- Step: `n := n₀ + m`.
        set k : ℕ := n₀ + m
        have hk_ge : n₀ ≤ k := Nat.le_add_right n₀ m
        let ball : ℕ → Finset Z.Zero := fun t => zerosBallFinset Z h_z_ne_zero h_summable t
        let fterm : Z.Zero → ℝ := fun ρ => (1 : ℝ) / ‖Z.z ρ‖
        have hsub : ball k ⊆ ball (k + 1) := by
          intro ρ hρ
          have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k :=
            (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable k ρ).1 hρ
          have hk_le : (2 : ℝ) ^ k ≤ (2 : ℝ) ^ (k + 1) :=
            pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_succ k)
          exact
            (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (k + 1) ρ).2
              (le_trans hnorm hk_le)
        have hdecomp :
            (∑ ρ ∈ ball (k + 1), fterm ρ) =
              (∑ ρ ∈ ball (k + 1) \ ball k, fterm ρ) + (∑ ρ ∈ ball k, fterm ρ) := by
          simpa [ball, fterm] using
            (Finset.sum_sdiff (s₁ := ball k) (s₂ := ball (k + 1)) (f := fterm) hsub).symm
        -- Bound the increment `ball (k+1) \ ball k`.
        have hdiff :
            (∑ ρ ∈ ball (k + 1) \ ball k, fterm ρ)
              ≤ (2 * Ccount) * ((2 : ℝ) ^ (k + 1)) ^ ε := by
          let diff : Finset Z.Zero := ball (k + 1) \ ball k
          have hterm_le : ∀ ρ, ρ ∈ diff → fterm ρ ≤ (1 : ℝ) / (2 : ℝ) ^ k := by
            intro ρ hρ
            have hρ' : ρ ∈ ball (k + 1) ∧ ρ ∉ ball k := by
              simpa [diff] using (Finset.mem_sdiff.1 hρ)
            have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
              intro hle
              have : ρ ∈ ball k := (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable k ρ).2 hle
              exact hρ'.2 this
            have hk_pos : 0 < (2 : ℝ) ^ k := by positivity
            have hk_le_norm : (2 : ℝ) ^ k ≤ ‖Z.z ρ‖ := le_of_lt (lt_of_not_ge hnot)
            have := one_div_le_one_div_of_le hk_pos hk_le_norm
            simpa [fterm] using this
          have hsum_le_card :
              (∑ ρ ∈ diff, fterm ρ) ≤ (diff.card : ℝ) * ((1 : ℝ) / (2 : ℝ) ^ k) := by
            have hsum_le : (∑ ρ ∈ diff, fterm ρ) ≤ ∑ ρ ∈ diff, (1 : ℝ) / (2 : ℝ) ^ k :=
              Finset.sum_le_sum hterm_le
            calc
              (∑ ρ ∈ diff, fterm ρ) ≤ ∑ ρ ∈ diff, (1 : ℝ) / (2 : ℝ) ^ k := hsum_le
              _ = (diff.card : ℝ) * ((1 : ℝ) / (2 : ℝ) ^ k) := by
                    simp
          have hball_card : ((ball (k + 1)).card : ℝ) =
              (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1)} : Set Z.Zero).ncard : ℝ) := by
            exact_mod_cast (card_zerosBallFinset Z h_z_ne_zero h_summable (n := k + 1))
          have hRcount_le' : Rcount ≤ (2 : ℝ) ^ (k + 1) := by
            have hpow : (2 : ℝ) ^ n₀ ≤ (2 : ℝ) ^ (k + 1) :=
              pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_trans hk_ge (Nat.le_succ _))
            exact le_trans hRcount_le hpow
          have hcount_ball :
              (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1)} : Set Z.Zero).ncard : ℝ)
                ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) :=
            hN_le ((2 : ℝ) ^ (k + 1)) hRcount_le'
          have hdiff_card_le :
              (diff.card : ℝ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) := by
            have hcard_le_ball : (diff.card : ℝ) ≤ ((ball (k + 1)).card : ℝ) := by
              exact_mod_cast
                (Finset.card_le_card (show diff ⊆ ball (k + 1) from Finset.sdiff_subset))
            have hball_le :
                ((ball (k + 1)).card : ℝ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) := by
              simpa [hball_card] using hcount_ball
            exact le_trans hcard_le_ball hball_le
          have hk_nonneg : 0 ≤ (1 : ℝ) / (2 : ℝ) ^ k := by positivity
          have hk_ne : (2 : ℝ) ^ k ≠ 0 := by
            have : (0 : ℝ) < (2 : ℝ) ^ k := by positivity
            exact ne_of_gt this
          have hk1_pos : 0 < (2 : ℝ) ^ (k + 1) := by positivity
          have hrewrite :
              Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / (2 : ℝ) ^ k)
                = (2 * Ccount) * ((2 : ℝ) ^ (k + 1)) ^ ε := by
            -- Expand `r^(1+ε)` and cancel `2^k`.
            calc
              Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / (2 : ℝ) ^ k)
                  =
                    Ccount * (((2 : ℝ) ^ (k + 1)) * ((2 : ℝ) ^ (k + 1)) ^ ε) *
                      ((1 : ℝ) / (2 : ℝ) ^ k) := by
                      simp [Real.rpow_add hk1_pos, Real.rpow_one, mul_assoc]
              _ = Ccount * ((2 : ℝ) ^ (k + 1)) ^ ε * (((2 : ℝ) ^ (k + 1)) / ((2 : ℝ) ^ k)) := by
                      field_simp [hk_ne]
              _ = Ccount * ((2 : ℝ) ^ (k + 1)) ^ ε * (2 : ℝ) := by
                      have : ((2 : ℝ) ^ (k + 1)) / ((2 : ℝ) ^ k) = (2 : ℝ) := by
                        field_simp [hk_ne]
                        simp [pow_succ]
                      simp [this]
              _ = (2 * Ccount) * ((2 : ℝ) ^ (k + 1)) ^ ε := by ring
          -- Assemble.
          have hcalc :
              (∑ ρ ∈ diff, fterm ρ) ≤ (2 * Ccount) * ((2 : ℝ) ^ (k + 1)) ^ ε := by
            calc
              (∑ ρ ∈ diff, fterm ρ) ≤ (diff.card : ℝ) * ((1 : ℝ) / (2 : ℝ) ^ k) := hsum_le_card
              _ ≤ (Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε)) * ((1 : ℝ) / (2 : ℝ) ^ k) := by
                    exact mul_le_mul_of_nonneg_right hdiff_card_le hk_nonneg
              _ = (2 * Ccount) * ((2 : ℝ) ^ (k + 1)) ^ ε := hrewrite
          simpa [diff] using hcalc
        -- Inductive inequality.
        have ih' : (∑ ρ ∈ ball k, fterm ρ) ≤ C * ((2 : ℝ) ^ k) ^ ε := by
          simpa [ball, fterm, k] using ih
        have hk_rpow : ((2 : ℝ) ^ (k + 1)) ^ ε = q * ((2 : ℝ) ^ k) ^ ε := by
          have hpos : 0 ≤ (2 : ℝ) ^ k := by positivity
          have : (2 : ℝ) ^ (k + 1) = (2 : ℝ) ^ k * (2 : ℝ) := by
            simp [pow_succ]
          simpa [q, this, mul_assoc, mul_left_comm, mul_comm] using
            (Real.mul_rpow
              (x := (2 : ℝ) ^ k) (y := (2 : ℝ))
              hpos (by positivity : 0 ≤ (2 : ℝ)) (z := ε))
        have hC_rec : (2 * Ccount) * q + C ≤ C * q := by
          have hCtail_le_C : Ctail ≤ C := by
            simpa [C] using (le_add_of_nonneg_left (a := Ctail) (b := smallSum) hsmallSum_nonneg)
          have hmul_le : Ctail * (q - 1) ≤ C * (q - 1) :=
            mul_le_mul_of_nonneg_right hCtail_le_C (le_of_lt hq_sub_pos)
          have hmul_eq : Ctail * (q - 1) = (2 * Ccount) * q := by
            dsimp [Ctail]
            field_simp [hq_sub_ne]
          have hmain : (2 * Ccount) * q ≤ C * (q - 1) := by
            simpa [hmul_eq] using hmul_le
          have hmain_add : (2 * Ccount) * q + C ≤ C * (q - 1) + C := by
            simpa [add_comm, add_left_comm, add_assoc] using add_le_add_right hmain C
          calc
            (2 * Ccount) * q + C ≤ C * (q - 1) + C := hmain_add
            _ = C * q := by ring
        -- Finish the step.
        calc
          (∑ ρ ∈ ball (k + 1), fterm ρ)
              = (∑ ρ ∈ ball (k + 1) \ ball k, fterm ρ) + (∑ ρ ∈ ball k, fterm ρ) := hdecomp
          _ ≤ (2 * Ccount) * ((2 : ℝ) ^ (k + 1)) ^ ε + C * ((2 : ℝ) ^ k) ^ ε := by
                gcongr
          _ = ((2 * Ccount) * q + C) * ((2 : ℝ) ^ k) ^ ε := by
                simp [hk_rpow, mul_add, mul_assoc, mul_comm]
          _ ≤ (C * q) * ((2 : ℝ) ^ k) ^ ε := by
                gcongr
          _ = C * ((2 : ℝ) ^ (k + 1)) ^ ε := by
                simp [hk_rpow, mul_assoc]
  -- Specialize to `m = n - n₀`.
  simpa [hn_eq] using hmain (n - n₀)

/-! ### Dyadic tail decay for `∑ 1/‖Z.z ρ‖²` -/

private lemma cofinal_zerosBallFinset
    {f : ℂ → ℂ} (Z : ZeroSet f)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_summable : Summable (fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2)) :
    ∀ t : Finset Z.Zero, ∃ n : ℕ, t ⊆ zerosBallFinset Z h_z_ne_zero h_summable n := by
  classical
  intro t
  by_cases ht : t = ∅
  · subst ht
    refine ⟨0, by simp⟩
  · have ht_ne : t.Nonempty := Finset.nonempty_iff_ne_empty.2 ht
    let t' : Finset ℝ := t.image (fun ρ : Z.Zero => ‖Z.z ρ‖)
    have ht'_ne : t'.Nonempty := ht_ne.image _
    let Rmax : ℝ := t'.max' ht'_ne
    have hRmax : ∀ ρ : Z.Zero, ρ ∈ t → ‖Z.z ρ‖ ≤ Rmax := by
      intro ρ hρ
      have : ‖Z.z ρ‖ ∈ t' := Finset.mem_image_of_mem _ hρ
      exact Finset.le_max' t' (‖Z.z ρ‖) this
    have hpow : ∃ n : ℕ, Rmax < (2 : ℝ) ^ n := by
      simpa using (pow_unbounded_of_one_lt Rmax (by norm_num : (1 : ℝ) < 2))
    refine ⟨Nat.find hpow, ?_⟩
    intro ρ hρ
    have hρ_le : ‖Z.z ρ‖ ≤ Rmax := hRmax ρ hρ
    have hρ_lt : ‖Z.z ρ‖ < (2 : ℝ) ^ (Nat.find hpow) := lt_of_le_of_lt hρ_le (Nat.find_spec hpow)
    exact (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable _ ρ).2 (le_of_lt hρ_lt)

theorem tsum_invNorm_sq_tail_le_rpow_of_two_pow
    {f : ℂ → ℂ} (hf_entire : Differentiable ℂ f)
    (hf_finite : hasFiniteOrder f) (hf_order_le : order f ≤ 1)
    (Z : ZeroSet f) [Countable Z.Zero]
    (h_zeros_only : ∀ s : ℂ, f s = 0 ↔ ∃ ρ : Z.Zero, s = Z.z ρ)
    (h_inj : Function.Injective Z.z)
    (h_z_ne_zero : ∀ ρ : Z.Zero, Z.z ρ ≠ 0)
    (h_simple : ∀ ρ : Z.Zero, deriv f (Z.z ρ) ≠ 0)
    (h_summable : Summable (fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2)) :
    ∀ ε : ℝ, 0 < ε → ε < 1 →
      ∃ n₀ : ℕ, ∃ C : ℝ, 0 ≤ C ∧
        ∀ n : ℕ, n₀ ≤ n →
          (∑' ρ : ({ρ : Z.Zero | (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖} : Set Z.Zero),
              (1 : ℝ) / ‖Z.z ρ.val‖ ^ 2)
            ≤ C * ((2 : ℝ) ^ n) ^ (ε - 1) := by
  classical
  intro ε hε0 hε1
  -- Zero-counting bound `N(r) = O(r^(1+ε))`.
  obtain ⟨Rcount, Ccount, hCcount_nonneg, hN_le⟩ :=
    ncard_zeros_le_rpow (f := f) hf_entire hf_finite hf_order_le Z h_zeros_only h_inj h_z_ne_zero
      h_simple ε hε0
  -- Choose `n₀` so that `Rcount ≤ 2^n₀`.
  let R0 : ℝ := max Rcount 1
  have hR0_le : ∃ n₀ : ℕ, R0 ≤ (2 : ℝ) ^ n₀ := by
    have h : ∃ n : ℕ, R0 < (2 : ℝ) ^ n := by
      simpa using (pow_unbounded_of_one_lt R0 (by norm_num : (1 : ℝ) < 2))
    refine ⟨Nat.find h, le_of_lt (Nat.find_spec h)⟩
  obtain ⟨n₀, hn₀⟩ := hR0_le
  have hRcount_le_pow : Rcount ≤ (2 : ℝ) ^ n₀ := le_trans (le_max_left _ _) hn₀
  -- Geometric ratio `q = 2^(ε-1)` with `0 < q < 1` since `ε < 1`.
  let q : ℝ := (2 : ℝ) ^ (ε - 1)
  have hq_pos : 0 < q := by
    simpa [q] using Real.rpow_pos_of_pos (by norm_num : (0 : ℝ) < 2) (ε - 1)
  have hq_lt_one : q < 1 := by
    have hneg : ε - 1 < 0 := by linarith
    simpa [q] using Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : (1 : ℝ) < 2) hneg
  -- Constant controlling the geometric tail.
  let C : ℝ := (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q / (1 - q)
  have hC_nonneg : 0 ≤ C := by
    have hpow_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) :=
      Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
    have hq_nonneg : 0 ≤ q := le_of_lt hq_pos
    have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
    have hnum_nonneg : 0 ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q :=
      mul_nonneg (mul_nonneg hpow_nonneg hCcount_nonneg) hq_nonneg
    exact div_nonneg hnum_nonneg (le_of_lt hden_pos)
  refine ⟨n₀, C, hC_nonneg, ?_⟩
  intro n hn
  -- Work with the indicator function on `Z.Zero`.
  let g : Z.Zero → ℝ := fun ρ =>
    if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0
  have hg_nonneg : ∀ ρ : Z.Zero, 0 ≤ g ρ := by
    intro ρ
    by_cases hρ : (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖
    · have : 0 ≤ (1 : ℝ) / ‖Z.z ρ‖ ^ 2 := by
        have h1 : 0 ≤ (1 : ℝ) := by norm_num
        have hden : 0 ≤ ‖Z.z ρ‖ ^ 2 := sq_nonneg _
        exact div_nonneg h1 hden
      simp [g, hρ]
    · simp [g, hρ]
  -- Bound dyadic-ball partial sums.
  have hball :
      ∀ m : ℕ,
        (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m, g ρ) ≤
          C * ((2 : ℝ) ^ n) ^ (ε - 1) := by
    classical
    intro m
    by_cases hm : m ≤ n + 1
    · have hsum0 :
          (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m, g ρ) = 0 := by
        refine Finset.sum_eq_zero ?_
        intro ρ hρ
        have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ m :=
          (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable m ρ).1 hρ
        have hpow : (2 : ℝ) ^ m ≤ (2 : ℝ) ^ (n + 1) :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hm
        have : ¬ (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ := not_lt_of_ge (le_trans hnorm hpow)
        simp [g, this]
      have hrhs_nonneg : 0 ≤ C * ((2 : ℝ) ^ n) ^ (ε - 1) := by
        have : 0 ≤ ((2 : ℝ) ^ n) ^ (ε - 1) :=
          Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ n) _
        exact mul_nonneg hC_nonneg this
      simpa [hsum0] using hrhs_nonneg
    · have hm_ge : n + 1 < m := lt_of_not_ge hm
      let ball : ℕ → Finset Z.Zero := fun t => zerosBallFinset Z h_z_ne_zero h_summable t
      have hsub_ball : ∀ k : ℕ, ball k ⊆ ball (k + 1) := by
        intro k ρ hρ
        have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k :=
          (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable k ρ).1 hρ
        have hk_le : (2 : ℝ) ^ k ≤ (2 : ℝ) ^ (k + 1) :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_succ k)
        exact
          (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (k + 1) ρ).2
            (le_trans hnorm hk_le)
      have hshell :
          ∀ k : ℕ, n + 1 ≤ k →
            (∑ ρ ∈ ball (k + 1) \ ball k, g ρ)
              ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q ^ k := by
        intro k hk
        let diff : Finset Z.Zero := ball (k + 1) \ ball k
        have hk_pow_le : (2 : ℝ) ^ (n + 1) ≤ (2 : ℝ) ^ k :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hk
        have hdiff_simp :
            (∑ ρ ∈ diff, g ρ) = ∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2 := by
          refine Finset.sum_congr rfl ?_
          intro ρ hρ
          have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
            intro hle
            have : ρ ∈ ball k :=
              (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable k ρ).2 hle
            exact (Finset.mem_sdiff.1 hρ).2 this
          have hlt : (2 : ℝ) ^ k < ‖Z.z ρ‖ := lt_of_not_ge hnot
          have hcond : (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ :=
            lt_of_lt_of_le (hk_pow_le.trans_lt hlt) (le_rfl)
          simp [g, hcond]
        have hterm_le :
            ∀ ρ, ρ ∈ diff → (1 : ℝ) / ‖Z.z ρ‖ ^ 2 ≤ (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 := by
          intro ρ hρ
          have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
            intro hle
            have : ρ ∈ ball k :=
              (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable k ρ).2 hle
            exact (Finset.mem_sdiff.1 hρ).2 this
          have hk_le_norm : (2 : ℝ) ^ k ≤ ‖Z.z ρ‖ := le_of_lt (lt_of_not_ge hnot)
          have hk2_pos : 0 < ((2 : ℝ) ^ k) ^ 2 := by positivity
          have hk2_le : ((2 : ℝ) ^ k) ^ 2 ≤ ‖Z.z ρ‖ ^ 2 :=
            pow_le_pow_left₀ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ k) hk_le_norm 2
          simpa [one_div, inv_pow] using (one_div_le_one_div_of_le hk2_pos hk2_le)
        have hsum_le_card :
            (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
              ≤ (diff.card : ℝ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
          have hsum_le :
              (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                ≤ ∑ ρ ∈ diff, (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 :=
            Finset.sum_le_sum hterm_le
          calc
            (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                ≤ ∑ ρ ∈ diff, (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 := hsum_le
            _ = (diff.card : ℝ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by simp
        have hRcount_le : Rcount ≤ (2 : ℝ) ^ (k + 1) := by
          have hRcount_le_R0 : Rcount ≤ R0 := le_max_left _ _
          have hn0_le_k : n₀ ≤ k := le_trans hn (le_trans (Nat.le_succ n) hk)
          have hn0_le_k1 : n₀ ≤ k + 1 := Nat.le_succ_of_le hn0_le_k
          have hpow : (2 : ℝ) ^ n₀ ≤ (2 : ℝ) ^ (k + 1) :=
            pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hn0_le_k1
          exact le_trans (le_trans hRcount_le_R0 hn₀) hpow
        have hcount_ball :
            (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1)} : Set Z.Zero).ncard : ℝ)
              ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) :=
          hN_le ((2 : ℝ) ^ (k + 1)) hRcount_le
        have hcard_ball :
            ((ball (k + 1)).card : ℝ)
              = (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1)} : Set Z.Zero).ncard : ℝ) := by
          exact_mod_cast (card_zerosBallFinset Z h_z_ne_zero h_summable (n := k + 1))
        have hdiff_card_le :
            (diff.card : ℝ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) := by
          have hdiff_card_le_ball : (diff.card : ℝ) ≤ ((ball (k + 1)).card : ℝ) := by
            exact_mod_cast (Finset.card_le_card (Finset.sdiff_subset : diff ⊆ ball (k + 1)))
          have hball_le :
              ((ball (k + 1)).card : ℝ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) := by
            simpa [hcard_ball] using hcount_ball
          exact le_trans hdiff_card_le_ball hball_le
        have hqk : q ^ k = ((2 : ℝ) ^ k) ^ (ε - 1) := by
          simpa [q] using
            (Real.rpow_pow_comm (x := (2 : ℝ)) (hx := by positivity) (ε - 1) k)
        have hdiv :
            ((2 : ℝ) ^ k) ^ (ε - 1)
              = ((2 : ℝ) ^ k) ^ ((1 : ℝ) + ε) / ((2 : ℝ) ^ k) ^ (2 : ℕ) := by
          have hk_pos : 0 < (2 : ℝ) ^ k := by positivity
          have hsub : ((1 : ℝ) + ε) - (2 : ℝ) = ε - 1 := by ring
          simpa [hsub, (Real.rpow_natCast ((2 : ℝ) ^ k) 2)] using
            (Real.rpow_sub hk_pos ((1 : ℝ) + ε) (2 : ℝ))
        have hrewrite :
            Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
              = (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q ^ k := by
          have hpow_succ : (2 : ℝ) ^ (k + 1) = (2 : ℝ) ^ k * 2 := by
            simp [pow_succ]
          have hpowk_nonneg : 0 ≤ (2 : ℝ) ^ k := by positivity
          have h2_nonneg : 0 ≤ (2 : ℝ) := by norm_num
          calc
            Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
                = Ccount * (((2 : ℝ) ^ k * 2) ^ ((1 : ℝ) + ε)) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
                      simp [hpow_succ]
            _ = Ccount * (((2 : ℝ) ^ k) ^ ((1 : ℝ) + ε) * (2 : ℝ) ^ ((1 : ℝ) + ε)) *
                    ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
                      have hsplit :
                          ((2 : ℝ) ^ k * 2) ^ ((1 : ℝ) + ε)
                            = ((2 : ℝ) ^ k) ^ ((1 : ℝ) + ε) * (2 : ℝ) ^ ((1 : ℝ) + ε) := by
                        simpa using
                          (Real.mul_rpow (x := (2 : ℝ) ^ k) (y := (2 : ℝ)) (z := (1 : ℝ) + ε)
                            hpowk_nonneg h2_nonneg)
                      have hsplit' :
                          ((2 : ℝ) * (2 : ℝ) ^ k) ^ ((1 : ℝ) + ε)
                            = (2 : ℝ) ^ ((1 : ℝ) + ε) * ((2 : ℝ) ^ k) ^ ((1 : ℝ) + ε) := by
                        have h2_nonneg' : 0 ≤ (2 : ℝ) := by norm_num
                        have hpowk_nonneg' : 0 ≤ (2 : ℝ) ^ k := by positivity
                        simpa using
                          (Real.mul_rpow (x := (2 : ℝ)) (y := (2 : ℝ) ^ k) (z := (1 : ℝ) + ε)
                            h2_nonneg' hpowk_nonneg')
                      -- avoid simp-canceling `Ccount`
                      simp [hsplit', mul_assoc, mul_comm,
                        -mul_eq_mul_left_iff, -mul_eq_mul_right_iff]
            _ = (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount *
                    (((2 : ℝ) ^ k) ^ ((1 : ℝ) + ε) / ((2 : ℝ) ^ k) ^ (2 : ℕ)) := by
                      -- Rearrange and rewrite `a * (1 / b)` as `a / b`,
                      -- but avoid simp-canceling `Ccount`.
                      simp [div_eq_mul_inv, mul_assoc, mul_comm,
                        -mul_eq_mul_left_iff, -mul_eq_mul_right_iff]
            _ = (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * (((2 : ℝ) ^ k) ^ (ε - 1)) := by
                      -- `x^(ε-1) = x^(1+ε) / x^2`
                      simpa [mul_assoc] using
                        congrArg
                          (fun t => (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * t)
                          hdiv.symm
            _ = (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q ^ k := by
                      simp [hqk]
        have hcalc :
            (∑ ρ ∈ diff, g ρ)
              ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q ^ k := by
          calc
            (∑ ρ ∈ diff, g ρ) = ∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2 := hdiff_simp
            _ ≤ (diff.card : ℝ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := hsum_le_card
            _ ≤ (Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε)) *
                  ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
                    gcongr
            _ = (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q ^ k := by
                    simpa [mul_assoc, mul_left_comm, mul_comm] using hrewrite
        simpa [diff] using hcalc
      let t : ℕ := m - (n + 1)
      have hm_eq : n + 1 + t = m := Nat.add_sub_of_le (Nat.le_of_lt hm_ge)
      have hind :
          ∀ j : ℕ,
            (∑ ρ ∈ ball (n + 1 + j), g ρ) ≤
              (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * (∑ i ∈ Finset.range j, q ^ (n + 1 + i)) := by
        intro j
        induction j with
        | zero =>
            have hsum0 : (∑ ρ ∈ ball (n + 1), g ρ) = 0 := by
              refine Finset.sum_eq_zero ?_
              intro ρ hρ
              have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n + 1) :=
                (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n := n + 1) ρ).1 hρ
              have : ¬ (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ := not_lt_of_ge hnorm
              simp [g, this]
            -- `∑ i ∈ range 0, _ = 0`
            simp [ball, hsum0]
        | succ j ih =>
            set k : ℕ := n + 1 + j
            have hk : n + 1 ≤ k := Nat.le_add_right _ _
            have hsub : ball k ⊆ ball (k + 1) := hsub_ball k
            have hdecomp :=
              (Finset.sum_sdiff (s₁ := ball k) (s₂ := ball (k + 1)) (f := g) hsub).symm
            have hshell_le :
                (∑ ρ ∈ ball (k + 1) \ ball k, g ρ)
                  ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q ^ k := hshell k hk
            have hgeom :
                (∑ i ∈ Finset.range (j + 1), q ^ (n + 1 + i))
                  = (∑ i ∈ Finset.range j, q ^ (n + 1 + i)) + q ^ k := by
              -- `k = n+1+j` is the new last term.
              simpa [k, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using
                (Finset.sum_range_succ (f := fun i => q ^ (n + 1 + i)) j)
            have ih' : (∑ ρ ∈ ball k, g ρ) ≤
                (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * (∑ i ∈ Finset.range j, q ^ (n + 1 + i)) := by
              simpa [k, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm] using ih
            calc
              (∑ ρ ∈ ball (k + 1), g ρ)
                  = (∑ ρ ∈ ball (k + 1) \ ball k, g ρ) + (∑ ρ ∈ ball k, g ρ) := by
                        simpa [k, add_assoc, add_comm, add_left_comm] using hdecomp
              _ ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * q ^ k +
                    (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * (∑ i ∈ Finset.range j, q ^ (n + 1 + i)) := by
                        gcongr
              _ = (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount *
                    ((∑ i ∈ Finset.range j, q ^ (n + 1 + i)) + q ^ k) := by
                        -- factor out the common scalar
                        set a : ℝ := (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount
                        have :
                            a * q ^ k + a * (∑ i ∈ Finset.range j, q ^ (n + 1 + i))
                              = a * ((∑ i ∈ Finset.range j, q ^ (n + 1 + i)) + q ^ k) := by
                          calc
                            a * q ^ k + a * (∑ i ∈ Finset.range j, q ^ (n + 1 + i))
                                = a * (q ^ k + (∑ i ∈ Finset.range j, q ^ (n + 1 + i))) := by
                                      simp [mul_add]
                            _ = a * ((∑ i ∈ Finset.range j, q ^ (n + 1 + i)) + q ^ k) := by
                                      simp [add_comm, add_left_comm]
                        -- unfold `a` and reassociate
                        simpa [a, mul_assoc, mul_left_comm, mul_comm] using this
              _ = (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount *
                    (∑ i ∈ Finset.range (j + 1), q ^ (n + 1 + i)) := by
                        -- avoid simp-canceling the common factor
                        rw [hgeom.symm]
      have hfinite_le :
          (∑ ρ ∈ ball m, g ρ)
            ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount *
                (∑ i ∈ Finset.range t, q ^ (n + 1 + i)) := by
        simpa [hm_eq, ball] using hind t
      have hgeom_le :
          (∑ i ∈ Finset.range t, q ^ (n + 1 + i))
            ≤ (q ^ (n + 1)) * (1 - q)⁻¹ := by
        have hsum : Summable (fun i : ℕ => q ^ i) :=
          summable_geometric_of_lt_one (le_of_lt hq_pos) hq_lt_one
        have hsum' : Summable (fun i : ℕ => q ^ (n + 1) * q ^ i) :=
          hsum.mul_left (q ^ (n + 1))
        have hnonneg : ∀ i : ℕ, 0 ≤ q ^ (n + 1) * q ^ i := by
          intro i
          positivity
        have hle_tsum :
            (∑ i ∈ Finset.range t, q ^ (n + 1) * q ^ i) ≤ ∑' i : ℕ, q ^ (n + 1) * q ^ i := by
          refine
            Summable.sum_le_tsum
              (s := Finset.range t) (f := fun i : ℕ => q ^ (n + 1) * q ^ i) ?_ hsum'
          intro i hi
          exact hnonneg i
        have hpow_add : ∀ i : ℕ, q ^ (n + 1 + i) = q ^ (n + 1) * q ^ i := by
          intro i
          simp [pow_add, mul_assoc]
        have hsum_eq :
            (∑ i ∈ Finset.range t, q ^ (n + 1 + i)) =
              (∑ i ∈ Finset.range t, q ^ (n + 1) * q ^ i) := by
          refine Finset.sum_congr rfl ?_
          intro i hi
          simp [hpow_add i]
        have htsum_eq :
            (∑' i : ℕ, q ^ (n + 1) * q ^ i) = (q ^ (n + 1)) * (1 - q)⁻¹ := by
          have hgeom0 : (∑' i : ℕ, q ^ i) = (1 - q)⁻¹ :=
            tsum_geometric_of_lt_one (h₁ := le_of_lt hq_pos) (h₂ := hq_lt_one)
          simp [tsum_mul_left, hgeom0]
        have : (∑ i ∈ Finset.range t, q ^ (n + 1 + i))
            ≤ (q ^ (n + 1)) * (1 - q)⁻¹ := by
          exact le_trans (by simpa [hsum_eq] using hle_tsum) (by simp [htsum_eq])
        exact this
      have hq_pow_comm : q ^ n = ((2 : ℝ) ^ n) ^ (ε - 1) := by
        simpa [q] using
          (Real.rpow_pow_comm (x := (2 : ℝ)) (hx := by positivity) (ε - 1) n)
      have hgeom_shift : q ^ (n + 1) = q * ((2 : ℝ) ^ n) ^ (ε - 1) := by
        calc
          q ^ (n + 1) = q ^ n * q := by simp [pow_succ]
          _ = ((2 : ℝ) ^ n) ^ (ε - 1) * q := by simp [hq_pow_comm]
          _ = q * ((2 : ℝ) ^ n) ^ (ε - 1) := by simp [mul_comm]
      have hconst :
          (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * ((q ^ (n + 1)) * (1 - q)⁻¹)
            = C * ((2 : ℝ) ^ n) ^ (ε - 1) := by
        simp [C, hgeom_shift, mul_assoc, mul_left_comm, mul_comm, div_eq_mul_inv]
      calc
        (∑ ρ ∈ ball m, g ρ)
            ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount *
                (∑ i ∈ Finset.range t, q ^ (n + 1 + i)) := hfinite_le
        _ ≤ (2 : ℝ) ^ ((1 : ℝ) + ε) * Ccount * ((q ^ (n + 1)) * (1 - q)⁻¹) := by
              gcongr
        _ = C * ((2 : ℝ) ^ n) ^ (ε - 1) := hconst
  have hfinset :
      ∀ t : Finset Z.Zero,
        (∑ ρ ∈ t, g ρ) ≤ C * ((2 : ℝ) ^ n) ^ (ε - 1) := by
    classical
    intro t
    obtain ⟨m, hm⟩ := cofinal_zerosBallFinset Z h_z_ne_zero h_summable t
    have hle_ball :
        (∑ ρ ∈ t, g ρ) ≤ ∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m, g ρ := by
      refine Finset.sum_le_sum_of_subset_of_nonneg hm ?_
      intro ρ hρ hρnot
      exact hg_nonneg ρ
    exact le_trans hle_ball (hball m)
  have ht_nonneg : 0 ≤ C * ((2 : ℝ) ^ n) ^ (ε - 1) := by
    have : 0 ≤ ((2 : ℝ) ^ n) ^ (ε - 1) :=
      Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ n) _
    exact mul_nonneg hC_nonneg this
  have htsum_g :
      (∑' ρ : Z.Zero, g ρ) ≤ C * ((2 : ℝ) ^ n) ^ (ε - 1) :=
    tsum_le_of_sum_le' ht_nonneg hfinset
  have hsub :
      (∑' ρ : ({ρ : Z.Zero | (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖} : Set Z.Zero),
          (‖Z.z ρ.val‖ ^ 2)⁻¹)
        =
        ∑' ρ : Z.Zero, g ρ := by
    -- rewrite the subtype `tsum` as an indicator `tsum` on `Z.Zero`
    simpa [g, one_div, Set.indicator, Set.mem_ofPred_eq] using
      (tsum_subtype (s := ({ρ : Z.Zero | (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖} : Set Z.Zero))
        (f := fun ρ : Z.Zero => (‖Z.z ρ‖ ^ 2)⁻¹))
  -- work in the `inv` form, then switch back to `1 / _` by simp
  have htail_inv :
      (∑' ρ : ({ρ : Z.Zero | (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖} : Set Z.Zero),
          (‖Z.z ρ.val‖ ^ 2)⁻¹)
        ≤ C * ((2 : ℝ) ^ n) ^ (ε - 1) := by
    rw [hsub]
    exact htsum_g
  simpa [one_div] using htail_inv

  /-
  Obsolete ENNReal/iSup proof attempt (superseded by the proof above).
  -- Zero-counting bound `N(r) = O(r^(1+ε))`.
  obtain ⟨Rcount, Ccount, hCcount_nonneg, hN_le⟩ :=
    ncard_zeros_le_rpow (f := f) hf_entire hf_finite hf_order_le Z h_zeros_only h_inj h_z_ne_zero
      h_simple ε hε0
  -- Choose `n₀` so that `Rcount ≤ 2^(n₀+1)`.
  let R0 : ℝ := max Rcount 1
  have hR0_le : ∃ n₀ : ℕ, R0 ≤ (2 : ℝ) ^ n₀ := by
    have h : ∃ n : ℕ, R0 < (2 : ℝ) ^ n := by
      simpa using (pow_unbounded_of_one_lt R0 (by norm_num : (1 : ℝ) < 2))
    refine ⟨Nat.find h, le_of_lt (Nat.find_spec h)⟩
  obtain ⟨n₀, hn₀⟩ := hR0_le
  have hRcount_le : Rcount ≤ (2 : ℝ) ^ (n₀ + 1) := by
    have hRcount_le_R0 : Rcount ≤ R0 := le_max_left _ _
    have hpow : (2 : ℝ) ^ n₀ ≤ (2 : ℝ) ^ (n₀ + 1) :=
      pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_succ _)
    exact le_trans (le_trans hRcount_le_R0 hn₀) hpow
  -- Geometric ratio `q = 2^(ε-1) = 2^(-(1-ε))`, with `0 < q < 1` since `ε < 1`.
  let q : ℝ := (2 : ℝ) ^ (ε - 1)
  have hq_pos : 0 < q := by
    have : 0 < (2 : ℝ) := by norm_num
    simpa [q] using Real.rpow_pos_of_pos this (ε - 1)
  have hq_lt_one : q < 1 := by
    -- Rewrite as an inverse of `2^(1-ε) > 1`.
    have hpos : 0 < (2 : ℝ) ^ (1 - ε) :=
      Real.rpow_pos_of_pos (by norm_num : (0 : ℝ) < 2) (1 - ε)
    have hone_lt : 1 < (2 : ℝ) ^ (1 - ε) := by
      have : 0 < (1 - ε) := sub_pos.mpr hε1
      simpa using Real.one_lt_rpow (by norm_num : (1 : ℝ) < 2) this
    have hq_inv : q = ((2 : ℝ) ^ (1 - ε))⁻¹ := by
      -- `ε - 1 = -(1 - ε)`.
      have : ε - 1 = -(1 - ε) := by ring
      simp [q, this, Real.rpow_neg (by positivity : (0 : ℝ) ≤ 2) (1 - ε)]
    -- `inv` of something `> 1` is `< 1`.
    simpa [hq_inv] using (inv_lt_one_of_one_lt hone_lt)
  -- Define the tail series over the subtype.
  let tailSet : Set Z.Zero := {ρ : Z.Zero | (2 : ℝ) ^ (n₀ + 1) < ‖Z.z ρ‖}
  -- Constant controlling the geometric tail.
  let Cgeo : ℝ := (2 : ℝ) ^ (1 + ε) * Ccount * q / (1 - q)
  have hCgeo_nonneg : 0 ≤ Cgeo := by
    have hpow_nonneg : 0 ≤ (2 : ℝ) ^ (1 + ε) := Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _
    have hq_nonneg : 0 ≤ q := le_of_lt hq_pos
    have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
    have hnum_nonneg : 0 ≤ (2 : ℝ) ^ (1 + ε) * Ccount * q :=
      mul_nonneg (mul_nonneg hpow_nonneg hCcount_nonneg) hq_nonneg
    exact div_nonneg hnum_nonneg (le_of_lt hden_pos)
  refine ⟨n₀, Cgeo, hCgeo_nonneg, ?_⟩
  intro n hn
  -- Rewrite the tail `tsum` as an `iSup` over dyadic ball finsets.
  -- We work in `ENNReal` to use monotone `iSup` formulas.
  have htail_nonneg :
      ∀ ρ : Z.Zero, 0 ≤ (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0) := by
    intro ρ
    by_cases hρ : (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ <;> simp [hρ, one_div, inv_nonneg, pow_two]
  have htail_summable :
      Summable fun ρ : Z.Zero =>
        (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0) := by
    -- dominated by the globally summable series `1/‖Z.z ρ‖²`
    refine Summable.of_nonneg_of_le (f := fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
      (g := fun ρ : Z.Zero =>
        if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0) ?_ ?_ h_summable
    · intro ρ
      by_cases hρ : (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ <;> simp [hρ, one_div, inv_nonneg, pow_two]
    · intro ρ
      by_cases hρ : (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ <;> simp [hρ]
  have hENN :
      ENNReal.ofReal
          (∑' ρ : ({ρ : Z.Zero | (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖} : Set Z.Zero),
              (1 : ℝ) / ‖Z.z ρ.val‖ ^ 2)
        =
        (⨆ m : ℕ,
          ∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
            ENNReal.ofReal
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)) := by
    -- Convert the subtype sum to an indicator sum over `Z.Zero`,
    -- then apply `iSup` over cofinal balls.
    -- We use `ofReal_tsum_of_nonneg` to move between `ℝ` and `ENNReal`.
    have hsub :
        (∑' ρ : ({ρ : Z.Zero | (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖} : Set Z.Zero),
            (1 : ℝ) / ‖Z.z ρ.val‖ ^ 2)
          =
          ∑' ρ : Z.Zero,
            if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0 := by
      -- `tsum_subtype` with a `Set.indicator`.
      simpa [tsum_subtype, Set.indicator, Set.mem_ofPred_eq]
    -- Move to `ENNReal`.
    have hENN0 :
        ENNReal.ofReal
            (∑' ρ : Z.Zero,
              if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)
          =
          ∑' ρ : Z.Zero,
            ENNReal.ofReal
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0) := by
      simpa using
        (ENNReal.ofReal_tsum_of_nonneg (f := fun ρ : Z.Zero =>
            if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)
          htail_nonneg htail_summable)
    -- Express the `ENNReal` tsum as an `iSup` over dyadic balls.
    have hcofinal := cofinal_zerosBallFinset Z h_z_ne_zero h_summable
    have htsum :
        (∑' ρ : Z.Zero,
            ENNReal.ofReal
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
          =
          (⨆ m : ℕ,
            ∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
              ENNReal.ofReal
                (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)) := by
      simpa using
        (ENNReal.tsum_eq_iSup_sum' (f := fun ρ : Z.Zero =>
              ENNReal.ofReal
                (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
            (s := fun m : ℕ => zerosBallFinset Z h_z_ne_zero h_summable m) hcofinal)
    -- Combine.
    simpa [hsub] using (hENN0.trans htsum)
  -- Bound each partial sum uniformly by a geometric series (in `ℝ`), then convert back to `ℝ`.
  have hpartial :
      ∀ m : ℕ,
        (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
            (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
          ≤ Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1) := by
    intro m
    by_cases hm : m ≤ n + 1
    · -- Then every `ρ` in the dyadic ball has `‖Z.z ρ‖ ≤ 2^(n+1)`, so the indicator is zero.
      have : (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
            (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)) = 0 := by
        refine Finset.sum_eq_zero ?_
        intro ρ hρ
        have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ m :=
          (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable m ρ).1 hρ
        have hpow : (2 : ℝ) ^ m ≤ (2 : ℝ) ^ (n + 1) :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) hm
        have : ¬ (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ := by
          exact not_lt_of_ge (le_trans hnorm hpow)
        simp [this]
      -- Conclude by positivity.
      have hrhs_nonneg : 0 ≤ Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1) := by
        have : 0 ≤ ((2 : ℝ) ^ n) ^ (ε - 1) :=
          Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ n) _
        exact mul_nonneg hCgeo_nonneg this
      simpa [this] using hrhs_nonneg
    · have hmn : n + 1 < m := lt_of_not_ge hm
      -- We estimate by summing dyadic shells from `k = n+1` up to `m-1`.
      let ball : ℕ → Finset Z.Zero := fun t => zerosBallFinset Z h_z_ne_zero h_summable t
      have hsub : ball (n + 1) ⊆ ball m := by
        intro ρ hρ
        have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n + 1) :=
          (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n + 1) ρ).1 hρ
        have hpow : (2 : ℝ) ^ (n + 1) ≤ (2 : ℝ) ^ m :=
          pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_of_lt hmn)
        exact (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable m ρ).2 (le_trans hnorm hpow)
      have hdecomp :
          (∑ ρ ∈ ball m,
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
            =
            (∑ ρ ∈ ball m \ ball (n + 1),
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)) := by
        have hzero :
            (∑ ρ ∈ ball (n + 1),
                (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)) = 0 := by
          refine Finset.sum_eq_zero ?_
          intro ρ hρ
          have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n + 1) :=
            (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n + 1) ρ).1 hρ
          have : ¬ (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ := not_lt_of_ge hnorm
          simp [this]
        -- `sum_sdiff + sum_ball = sum_ball`, so `sum_sdiff = sum_ball`.
        have := (Finset.sum_sdiff (s₁ := ball (n + 1)) (s₂ := ball m)
            (f := fun ρ : Z.Zero =>
              if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0) hsub)
        -- rearrange
        linarith
      -- Shell bound.
      have hshell :
          ∀ k : ℕ, n + 1 ≤ k → k + 1 ≤ m →
            (∑ ρ ∈ ball (k + 1) \ ball k, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
              ≤ (2 : ℝ) ^ (1 + ε) * Ccount * q ^ k := by
        intro k hk hkm
        let diff : Finset Z.Zero := ball (k + 1) \ ball k
        have hterm_le : ∀ ρ, ρ ∈ diff → (1 : ℝ) / ‖Z.z ρ‖ ^ 2 ≤ (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 := by
          intro ρ hρ
          have hρ' : ρ ∈ ball (k + 1) ∧ ρ ∉ ball k := by
            simpa [diff] using (Finset.mem_sdiff.1 hρ)
          have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ k := by
            intro hle
            have : ρ ∈ ball k :=
              (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable k ρ).2 hle
            exact hρ'.2 this
          have hk_pos : 0 < (2 : ℝ) ^ k := by positivity
          have hk_le_norm : (2 : ℝ) ^ k ≤ ‖Z.z ρ‖ := le_of_lt (lt_of_not_ge hnot)
          have hk2_pos : 0 < ((2 : ℝ) ^ k) ^ 2 := by positivity
          have hk2_le : ((2 : ℝ) ^ k) ^ 2 ≤ ‖Z.z ρ‖ ^ 2 :=
            pow_le_pow_left₀ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ k) hk_le_norm 2
          -- `1/‖ρ‖² ≤ 1/(2^k)²`
          simpa [one_div, inv_pow] using (one_div_le_one_div_of_le hk2_pos hk2_le)
        have hsum_le_card :
            (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
              ≤ (diff.card : ℝ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
          have hsum_le :
              (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                ≤ ∑ ρ ∈ diff, (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 :=
            Finset.sum_le_sum hterm_le
          calc
            (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                ≤ ∑ ρ ∈ diff, (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 := hsum_le
            _ = (diff.card : ℝ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by simp
        have hball_card : ((ball (k + 1)).card : ℝ) =
            (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1)} : Set Z.Zero).ncard : ℝ) := by
          exact_mod_cast (card_zerosBallFinset Z h_z_ne_zero h_summable (n := k + 1))
        have hRcount_le' : Rcount ≤ (2 : ℝ) ^ (k + 1) := by
          have hpow : (2 : ℝ) ^ n₀ ≤ (2 : ℝ) ^ (k + 1) :=
            pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_trans hk (Nat.le_succ _))
          have hRcount_le_R0 : Rcount ≤ R0 := le_max_left _ _
          exact le_trans (le_trans hRcount_le_R0 hn₀) hpow
        have hcount_ball :
            (({ρ : Z.Zero | ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (k + 1)} : Set Z.Zero).ncard : ℝ)
              ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) :=
          hN_le ((2 : ℝ) ^ (k + 1)) hRcount_le'
        have hdiff_card_le :
            (diff.card : ℝ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) := by
          have hcard_le_ball : (diff.card : ℝ) ≤ ((ball (k + 1)).card : ℝ) := by
            exact_mod_cast (Finset.card_le_card (show diff ⊆ ball (k + 1) from Finset.sdiff_subset))
          have hball_le :
              ((ball (k + 1)).card : ℝ) ≤ Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) := by
            simpa [hball_card] using hcount_ball
          exact le_trans hcard_le_ball hball_le
        -- Simplify the expression into `const * q^k`.
        have hk1_pos : 0 < (2 : ℝ) ^ (k + 1) := by positivity
        have hk_pos' : 0 < (2 : ℝ) ^ k := by positivity
        have hrewrite :
            Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
              = (2 : ℝ) ^ (1 + ε) * Ccount * q ^ k := by
          -- `((2^(k+1))^(1+ε)) / (2^k)^2 = 2^(1+ε) * (2^(ε-1))^k`.
          have hpowk_pos : 0 < (2 : ℝ) ^ k := by positivity
          have hpowk1_pos : 0 < (2 : ℝ) ^ (k + 1) := by positivity
          -- Convert `q^k` into `2^((ε-1)*k)`.
          have hqk : q ^ k = (2 : ℝ) ^ ((ε - 1) * (k : ℝ)) := by
            -- `q = 2^(ε-1)`.
            have : q = (2 : ℝ) ^ (ε - 1) := rfl
            -- `((2^(ε-1))^k) = 2^((ε-1)*k)`.
            have hmul :
                (2 : ℝ) ^ ((ε - 1) * (k : ℝ)) = ((2 : ℝ) ^ (ε - 1)) ^ (k : ℝ) := by
              simpa [mul_assoc] using
                (Real.rpow_mul (x := (2 : ℝ)) (hx := by positivity) (y := (ε - 1)) (z := (k : ℝ)))
            simpa [q, Real.rpow_natCast] using hmul.symm
          -- Now compute both sides as powers of `2`.
          -- Left side:
          -- `((2^(k+1))^(1+ε)) / (2^k)^2 = 2^( (1+ε)*(k+1) - 2*k ) = 2^( (ε-1)*k + (1+ε) )`.
          have hleft :
              ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
                = (2 : ℝ) ^ (1 + ε) * q ^ k := by
            have h2pos : 0 < (2 : ℝ) := by norm_num
            -- Rewrite `((2^(k+1))^(1+ε))` as `2^((1+ε)*(k+1))`.
            have hA :
                ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε)
                  = (2 : ℝ) ^ (((1 : ℝ) + ε) * ((k + 1 : ℕ) : ℝ)) := by
              -- `2^(k+1) = 2^((k+1):ℝ)` and use `rpow_mul`.
              have : (2 : ℝ) ^ (k + 1) = (2 : ℝ) ^ ((k + 1 : ℕ) : ℝ) := by
                simpa using (Real.rpow_natCast (2 : ℝ) (k + 1)).symm
              calc
                ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε)
                    = ((2 : ℝ) ^ ((k + 1 : ℕ) : ℝ)) ^ ((1 : ℝ) + ε) := by simp [this]
                _ = (2 : ℝ) ^ (((k + 1 : ℕ) : ℝ) * ((1 : ℝ) + ε)) := by
                      simpa [mul_assoc] using
                        (Real.rpow_mul (x := (2 : ℝ)) (hx := by positivity) (y := ((k + 1 : ℕ) : ℝ))
                          (z := ((1 : ℝ) + ε))).symm
                _ = (2 : ℝ) ^ (((1 : ℝ) + ε) * ((k + 1 : ℕ) : ℝ)) := by
                      simp [mul_comm, mul_left_comm, mul_assoc]
            -- Rewrite `1 / (2^k)^2` as `2^(-2*k)`.
            have hB :
                (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 = (2 : ℝ) ^ (-(2 : ℝ) * (k : ℝ)) := by
              have hk2_pos : 0 < ((2 : ℝ) ^ k) ^ 2 := by positivity
              have : (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 = (((2 : ℝ) ^ k) ^ 2)⁻¹ := by
                simp [one_div]
              -- `(2^k)^2 = 2^(2*k)` and invert.
              have hk_pow : ((2 : ℝ) ^ k) ^ 2 = (2 : ℝ) ^ ((2 : ℝ) * (k : ℝ)) := by
                have : ((2 : ℝ) ^ k) ^ (2 : ℝ) = ((2 : ℝ) ^ k) ^ 2 := by
                  simpa using (Real.rpow_natCast ((2 : ℝ) ^ k) 2)
                -- `(2^k)^2 = (2^k)^(2:ℝ) = 2^((k:ℝ)*2)`.
                calc
                  ((2 : ℝ) ^ k) ^ 2 = ((2 : ℝ) ^ k) ^ (2 : ℝ) := by
                        simpa using (Real.rpow_natCast ((2 : ℝ) ^ k) 2).symm
                  _ = (2 : ℝ) ^ ((k : ℝ) * (2 : ℝ)) := by
                        -- `(2^k) = 2^(k:ℝ)` and use `rpow_mul`.
                        have : (2 : ℝ) ^ k = (2 : ℝ) ^ (k : ℝ) := by
                          simpa using (Real.rpow_natCast (2 : ℝ) k).symm
                        calc
                          ((2 : ℝ) ^ k) ^ (2 : ℝ) = ((2 : ℝ) ^ (k : ℝ)) ^ (2 : ℝ) := by simp [this]
                          _ = (2 : ℝ) ^ ((k : ℝ) * (2 : ℝ)) := by
                                simpa [mul_assoc] using
                                  (Real.rpow_mul
                                    (x := (2 : ℝ)) (hx := by positivity)
                                    (y := (k : ℝ)) (z := (2 : ℝ)))
                  _ = (2 : ℝ) ^ ((2 : ℝ) * (k : ℝ)) := by ring_nf
              -- Invert via `rpow_neg`.
              have hbase_nonneg : 0 ≤ (2 : ℝ) := by norm_num
              have : (((2 : ℝ) ^ ((2 : ℝ) * (k : ℝ))) : ℝ)⁻¹ = (2 : ℝ) ^ (-(2 : ℝ) * (k : ℝ)) := by
                simpa [Real.rpow_neg hbase_nonneg ((2 : ℝ) * (k : ℝ)), inv_eq_one_div] using
                  (Real.rpow_neg hbase_nonneg ((2 : ℝ) * (k : ℝ))).symm
              -- Combine.
              simp
                [hk_pow, one_div, Real.rpow_neg hbase_nonneg ((2 : ℝ) * (k : ℝ)),
                  mul_assoc, inv_eq_one_div]
            -- Combine powers.
            have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
            have : ((2 : ℝ) ^ (1 + ε) * q ^ k) = (2 : ℝ) ^ ((1 + ε) + (ε - 1) * (k : ℝ)) := by
              -- `q^k` is a power of 2.
              simp [hqk, Real.rpow_add (by norm_num : (0 : ℝ) < 2), mul_assoc]
            -- Use `rpow_add` on the LHS.
            -- We keep the final form as stated.
            -- This sub-proof is algebraic; we avoid over-simplification.
            -- A short `ring_nf` on exponents works after rewriting everything as `2^(_)`.
            have hmain :
                ((2 : ℝ) ^ (((1 : ℝ) + ε) * ((k + 1 : ℕ) : ℝ))) * ((2 : ℝ) ^ (-(2 : ℝ) * (k : ℝ)))
                  = (2 : ℝ) ^ ((1 + ε) + (ε - 1) * (k : ℝ)) := by
              -- Combine the exponents.
              have hpos2 : (0 : ℝ) < 2 := by norm_num
              -- `2^a * 2^b = 2^(a+b)`.
              calc
                (2 : ℝ) ^ (((1 : ℝ) + ε) * ((k + 1 : ℕ) : ℝ)) * (2 : ℝ) ^ (-(2 : ℝ) * (k : ℝ))
                    = (2 : ℝ) ^ ((((1 : ℝ) + ε) * ((k + 1 : ℕ) : ℝ)) + (-(2 : ℝ) * (k : ℝ))) := by
                        simp [Real.rpow_add hpos2]
                _ = (2 : ℝ) ^ ((1 + ε) + (ε - 1) * (k : ℝ)) := by
                        -- arithmetic on the exponent
                        congr 1
                        ring_nf
            -- Finish.
            -- Replace the two factors using `hA` and `hB`.
            calc
              ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
                  =
                    (2 : ℝ) ^ (((1 : ℝ) + ε) * ((k + 1 : ℕ) : ℝ)) *
                      (2 : ℝ) ^ (-(2 : ℝ) * (k : ℝ)) := by
                      simp [hA, hB]
              _ = (2 : ℝ) ^ ((1 + ε) + (ε - 1) * (k : ℝ)) := hmain
              _ = (2 : ℝ) ^ (1 + ε) * q ^ k := by
                      -- Split the exponent and rewrite `q^k`.
                      have hpos2 : (0 : ℝ) < 2 := by norm_num
                      simp
                        [Real.rpow_add hpos2, hqk,
                          Real.rpow_mul (le_of_lt hpos2) (ε - 1) (k : ℝ),
                          Real.rpow_natCast, q, mul_assoc, mul_comm, mul_left_comm]
          -- Put back the `Ccount` factor.
          calc
            Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)
                =
                  Ccount *
                    (((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2)) := by
                      ring
            _ = Ccount * ((2 : ℝ) ^ (1 + ε) * q ^ k) := by simp [hleft]
            _ = (2 : ℝ) ^ (1 + ε) * Ccount * q ^ k := by ring
        -- Assemble.
        have hcalc :
            (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
              ≤ (2 : ℝ) ^ (1 + ε) * Ccount * q ^ k := by
          calc
            (∑ ρ ∈ diff, (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                ≤ (diff.card : ℝ) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := hsum_le_card
            _ ≤ (Ccount * ((2 : ℝ) ^ (k + 1)) ^ ((1 : ℝ) + ε)) * ((1 : ℝ) / ((2 : ℝ) ^ k) ^ 2) := by
                  -- multiply by a nonnegative constant
                  have hk_nonneg : 0 ≤ (1 : ℝ) / ((2 : ℝ) ^ k) ^ 2 := by positivity
                  exact mul_le_mul_of_nonneg_right hdiff_card_le hk_nonneg
            _ = (2 : ℝ) ^ (1 + ε) * Ccount * q ^ k := by
                  simpa [mul_assoc, mul_left_comm, mul_comm] using hrewrite
        simpa [diff] using hcalc
      -- Use shells up to `m-1`, and bound by a geometric sum.
      have hball_tail :
          (∑ ρ ∈ ball m \ ball (n + 1),
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
            ≤ (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) / (1 - q) := by
        -- Each `ρ` in the shell difference satisfies the indicator, so we can drop it.
        have h_indicator :
            (∑ ρ ∈ ball m \ ball (n + 1),
                (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
              = (∑ ρ ∈ ball m \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2) := by
          refine Finset.sum_congr rfl ?_
          intro ρ hρ
          have hρ' : ρ ∈ ball m ∧ ρ ∉ ball (n + 1) := by
            simpa using (Finset.mem_sdiff.1 hρ)
          have hnot : ¬ ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n + 1) := by
            intro hle
            have : ρ ∈ ball (n + 1) :=
              (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n + 1) ρ).2 hle
            exact hρ'.2 this
          have : (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ := lt_of_not_ge hnot
          simp [this]
        -- Bound by summing shell bounds from `k = n+1` to `m-1`.
        -- We use a crude bound: each increment `ball (k+1) \\ ball k` is bounded by `const * q^k`,
        -- then sum a finite geometric progression.
        -- First, expand the finite sum over `ball m \\ ball (n+1)`
        -- as a telescoping sum of increments.
        have htel :
            (∑ ρ ∈ ball m \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
              ≤ ∑ k ∈ Finset.range (m - (n + 1)),
                  (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + k) := by
          -- Induction on `m - (n+1)` via telescoping.
          let d : ℕ := m - (n + 1)
          have hd : m = n + 1 + d := (Nat.add_sub_of_le (Nat.le_of_lt hmn)).symm
          -- We prove a stronger statement by induction on `d`.
          have hmain :
              ∀ d : ℕ,
                (∑ ρ ∈ ball (n + 1 + d) \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                  ≤ ∑ k ∈ Finset.range d, (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + k) := by
            intro d
            induction d with
            | zero =>
                simp
            | succ d ih =>
                have hsub' : ball (n + 1 + d) ⊆ ball (n + 1 + d.succ) := by
                  intro ρ hρ
                  have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n + 1 + d) :=
                    (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n + 1 + d) ρ).1 hρ
                  have hpow : (2 : ℝ) ^ (n + 1 + d) ≤ (2 : ℝ) ^ (n + 1 + d.succ) :=
                    pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_succ _)
                  exact (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n + 1 + d.succ) ρ).2
                    (le_trans hnorm hpow)
                -- Apply `sum_sdiff` to split the new shell.
                have hsplit :=
                  (Finset.sum_sdiff (s₁ := ball (n + 1 + d)) (s₂ := ball (n + 1 + d.succ))
                      (f := fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2) hsub')
                -- Rearrange and bound the shell term.
                have hshell_bound :
                    (∑ ρ ∈ ball (n + 1 + d.succ) \ ball (n + 1 + d), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                      ≤ (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + d) := by
                  have hn1_le : n + 1 ≤ n + 1 + d := Nat.le_add_right _ _
                  have hk_le : n + 1 + d ≤ n + 1 + d.succ := Nat.le_succ _
                  -- Use the shell lemma with `k = n+1+d`.
                  have := hshell (k := n + 1 + d) hn1_le (Nat.le_succ _)
                  simpa [ball] using this
                -- Combine with induction hypothesis.
                -- `sum(ball(n+1+d.succ)\\ball(n+1)) = shell + sum(ball(n+1+d)\\ball(n+1))`.
                have hrec :
                    (∑ ρ ∈ ball (n + 1 + d.succ) \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                      =
                    (∑ ρ ∈ ball (n + 1 + d.succ) \ ball (n + 1 + d), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                      +
                    (∑ ρ ∈ ball (n + 1 + d) \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2) := by
                  -- use `sdiff` associativity inside `ball (n+1+d.succ)`
                  have hsub1 : ball (n + 1) ⊆ ball (n + 1 + d) := by
                    intro ρ hρ
                    have hnorm : ‖Z.z ρ‖ ≤ (2 : ℝ) ^ (n + 1) :=
                      (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n + 1) ρ).1 hρ
                    have hpow : (2 : ℝ) ^ (n + 1) ≤ (2 : ℝ) ^ (n + 1 + d) :=
                      pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_add_right _ _)
                    exact (mem_zerosBallFinset_iff Z h_z_ne_zero h_summable (n + 1 + d) ρ).2
                      (le_trans hnorm hpow)
                  have hsub2 : ball (n + 1 + d) ⊆ ball (n + 1 + d.succ) := hsub'
                  -- `sdiff` as
                  -- `ball(n+1+d.succ) \\ ball(n+1)
                  --   = (ball(n+1+d.succ) \\ ball(n+1+d)) ∪ (ball(n+1+d) \\ ball(n+1))`
                  -- and the union is disjoint.
                  have hdisj :
                      Disjoint
                        (ball (n + 1 + d.succ) \ ball (n + 1 + d))
                        (ball (n + 1 + d) \ ball (n + 1)) := by
                    refine Finset.disjoint_left.2 ?_
                    intro ρ hρ1 hρ2
                    have hρ1' : ρ ∈ ball (n + 1 + d.succ) ∧ ρ ∉ ball (n + 1 + d) := by
                      simpa using (Finset.mem_sdiff.1 hρ1)
                    have hρ2' : ρ ∈ ball (n + 1 + d) ∧ ρ ∉ ball (n + 1) := by
                      simpa using (Finset.mem_sdiff.1 hρ2)
                    exact hρ1'.2 hρ2'.1
                  -- Use `sum_union` on the disjoint union.
                  have hunion :
                      (ball (n + 1 + d.succ) \ ball (n + 1 + d)) ∪ (ball (n + 1 + d) \ ball (n + 1))
                        = ball (n + 1 + d.succ) \ ball (n + 1) := by
                    -- `sdiff` with nested subsets.
                    ext ρ
                    simp [ball, hsub1, hsub2, Nat.le_add_right, Nat.le_succ]
                  -- Now sum.
                  have hsum_union :=
                    (Finset.sum_union (s₁ := ball (n + 1 + d.succ) \ ball (n + 1 + d))
                      (s₂ := ball (n + 1 + d) \ ball (n + 1))
                      (f := fun ρ : Z.Zero => (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                      hdisj)
                  -- rewrite and rearrange
                  simpa [hunion, add_comm, add_left_comm, add_assoc] using hsum_union.symm
                -- Apply the recursion with bounds.
                calc
                  (∑ ρ ∈ ball (n + 1 + d.succ) \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                      = (∑ ρ ∈ ball (n + 1 + d.succ) \ ball (n + 1 + d), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
                          + (∑ ρ ∈ ball (n + 1 + d) \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2) := by
                          simpa using hrec
                  _ ≤ (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + d) +
                        ∑ k ∈ Finset.range d, (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + k) := by
                          gcongr
                  _ = ∑ k ∈ Finset.range d.succ, (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + k) := by
                          simp [Finset.sum_range_succ, add_assoc, add_left_comm, add_comm]
          -- Specialize to `d = m - (n+1)`.
          simpa [d, hd] using hmain (m - (n + 1))
        -- Convert the finite sum to a geometric bound using `geom_sum_eq`.
        have hgeom :
            ∑ k ∈ Finset.range (m - (n + 1)), (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + k)
              ≤ (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) / (1 - q) := by
          -- Pull out constants and reduce to `∑ q^(n+1+k)`.
          have hconst_nonneg : 0 ≤ (2 : ℝ) ^ (1 + ε) * Ccount := mul_nonneg
              (Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _) hCcount_nonneg
          -- Rewrite as `const * q^(n+1) * ∑ q^k`.
          have hsum :
              ∑ k ∈ Finset.range (m - (n + 1)), (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + k)
                = (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) *
                    ∑ k ∈ Finset.range (m - (n + 1)), q ^ k := by
            simp [mul_assoc, mul_left_comm, mul_comm, pow_add, Finset.mul_sum]
          -- Bound the geometric sum by `1/(1-q)`.
          have hq_ne : q ≠ 1 := ne_of_lt hq_lt_one
          have hgeom_eq : ∑ k ∈ Finset.range (m - (n + 1)), q ^ k =
              (q ^ (m - (n + 1)) - 1) / (q - 1) := geom_sum_eq hq_ne (m - (n + 1))
          have hgeom_eq' :
              (q ^ (m - (n + 1)) - 1) / (q - 1) = (1 - q ^ (m - (n + 1))) / (1 - q) := by
            field_simp
            ring
          have hq_le1 : q ≤ 1 := le_of_lt hq_lt_one
          have hqpow_le1 : q ^ (m - (n + 1)) ≤ 1 := pow_le_one₀ (le_of_lt hq_pos) hq_le1
          have hnum_le : 1 - q ^ (m - (n + 1)) ≤ (1 : ℝ) := by linarith
          have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
          have hsum_q :
              (∑ k ∈ Finset.range (m - (n + 1)), q ^ k) ≤ (1 - q)⁻¹ := by
            -- Use the explicit formula and bound `1 - q^N ≤ 1`.
            calc
              (∑ k ∈ Finset.range (m - (n + 1)), q ^ k)
                  = (1 - q ^ (m - (n + 1))) / (1 - q) := by
                        simpa [hgeom_eq, hgeom_eq', div_eq_mul_inv, sub_eq_add_neg] using hgeom_eq
              _ ≤ (1 : ℝ) / (1 - q) := by
                        gcongr
              _ = (1 - q)⁻¹ := by simp [one_div]
          -- Assemble.
          calc
            ∑ k ∈ Finset.range (m - (n + 1)), (2 : ℝ) ^ (1 + ε) * Ccount * q ^ (n + 1 + k)
                = (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) *
                    ∑ k ∈ Finset.range (m - (n + 1)), q ^ k := hsum
            _ ≤ (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) * (1 - q)⁻¹ := by
                  gcongr
            _ = (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) / (1 - q) := by
                  simp [div_eq_mul_inv, mul_assoc]
        -- Finish.
        have h1 :
            (∑ ρ ∈ ball m \ ball (n + 1), (1 : ℝ) / ‖Z.z ρ‖ ^ 2)
              ≤ (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) / (1 - q) := by
          exact le_trans htel hgeom
        simpa [h_indicator] using h1
      -- Put the pieces together.
      -- `ball m` sum equals sdiff sum, and then apply shell bounds.
      have hsum0 :
          (∑ ρ ∈ ball m,
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
            ≤ (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) / (1 - q) := by
        simpa [hdecomp] using hball_tail
      -- Finally relate the RHS to `Cgeo * (2^n)^(ε-1)` by comparing `q^(n+1)` to `(2^n)^(ε-1)`.
      have hq_pow :
          q ^ (n + 1) ≤ q * ((2 : ℝ) ^ n) ^ (ε - 1) := by
        -- `q^(n+1) = q * q^n`, and `q^n = (2^n)^(ε-1)`.
        have : q ^ (n + 1) = q * q ^ n := by simp [pow_succ, mul_assoc]
        -- `q^n = (2^n)^(ε-1)`.
        have hqn :
            q ^ n = ((2 : ℝ) ^ n) ^ (ε - 1) := by
          -- both sides equal `2^((ε-1)*n)`
          have hpos2 : (0 : ℝ) < 2 := by norm_num
          have hA : q ^ n = (2 : ℝ) ^ ((ε - 1) * (n : ℝ)) := by
            have hmul :
                (2 : ℝ) ^ ((ε - 1) * (n : ℝ)) = ((2 : ℝ) ^ (ε - 1)) ^ (n : ℝ) := by
              simpa [mul_assoc] using
                (Real.rpow_mul (x := (2 : ℝ)) (hx := by positivity) (y := (ε - 1)) (z := (n : ℝ)))
            simpa [q, Real.rpow_natCast] using hmul.symm
          have hB : ((2 : ℝ) ^ n) ^ (ε - 1) = (2 : ℝ) ^ (((n : ℕ) : ℝ) * (ε - 1)) := by
            have : (2 : ℝ) ^ n = (2 : ℝ) ^ ((n : ℕ) : ℝ) := by
              simpa using (Real.rpow_natCast (2 : ℝ) n).symm
            calc
              ((2 : ℝ) ^ n) ^ (ε - 1) = ((2 : ℝ) ^ ((n : ℕ) : ℝ)) ^ (ε - 1) := by simp [this]
              _ = (2 : ℝ) ^ (((n : ℕ) : ℝ) * (ε - 1)) := by
                    simpa [mul_assoc] using
                      (Real.rpow_mul (x := (2 : ℝ)) (hx := by positivity) (y := ((n : ℕ) : ℝ))
                        (z := (ε - 1))).symm
          have hmul' : (ε - 1) * (n : ℝ) = ((n : ℕ) : ℝ) * (ε - 1) := by ring
          simpa [hA, hB, hmul'] using rfl
        -- combine
        simpa [this, hqn, mul_assoc]
      have hCgeo_eq :
          (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) / (1 - q) ≤
            Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1) := by
        -- unfold `Cgeo` and use `hq_pow`.
        have hden_pos : 0 < (1 - q) := sub_pos.mpr hq_lt_one
        have hden_nonneg : 0 ≤ (1 - q) := le_of_lt hden_pos
        have hqpow_le :
            (2 : ℝ) ^ (1 + ε) * Ccount * (q ^ (n + 1)) / (1 - q)
              ≤ (2 : ℝ) ^ (1 + ε) * Ccount * (q * ((2 : ℝ) ^ n) ^ (ε - 1)) / (1 - q) := by
          have hnonneg : 0 ≤ (2 : ℝ) ^ (1 + ε) * Ccount := mul_nonneg
              (Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) _) hCcount_nonneg
          have :=
            mul_le_mul_of_nonneg_left hq_pow
              (mul_nonneg hnonneg (by positivity : 0 ≤ (1 : ℝ) / (1 - q)))
          -- `a*b/(1-q)` is monotone in `b` since denominator is positive.
          -- We use `gcongr` instead of rearranging by hand.
          gcongr
        -- Now rewrite to match `Cgeo`.
        have : (2 : ℝ) ^ (1 + ε) * Ccount * (q * ((2 : ℝ) ^ n) ^ (ε - 1)) / (1 - q)
              = Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1) := by
          simp [Cgeo, mul_assoc, mul_left_comm, mul_comm, div_eq_mul_inv]
        exact le_trans hqpow_le (by simpa [this])
      have hbound :
          (∑ ρ ∈ ball m,
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
            ≤ Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1) :=
        le_trans hsum0 hCgeo_eq
      -- Done.
      exact hbound
  have hENN_le :
      (⨆ m : ℕ,
          ∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
            ENNReal.ofReal
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
        ≤ ENNReal.ofReal (Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1)) := by
    -- bound each term of the `iSup`
    refine iSup_le ?_
    intro m
    -- convert finite sum of `ofReal` back to a real sum
    have hsum_ofReal :
        (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
            ENNReal.ofReal
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
          =
          ENNReal.ofReal
            (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0)) := by
      apply sum_ofReal_eq_ofReal_sum
      intro ρ
      exact htail_nonneg ρ
    -- apply `ofReal` to the real bound
    have hreal_le := hpartial m
    have hENN_le' :
        ENNReal.ofReal
            (∑ ρ ∈ zerosBallFinset Z h_z_ne_zero h_summable m,
              (if (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖ then (1 : ℝ) / ‖Z.z ρ‖ ^ 2 else 0))
          ≤ ENNReal.ofReal (Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1)) :=
      ENNReal.ofReal_le_ofReal hreal_le
    simpa [hsum_ofReal] using hENN_le'
  -- From the ENNReal bound, conclude the real bound.
  have htsum_le :
      ENNReal.ofReal
          (∑' ρ : ({ρ : Z.Zero | (2 : ℝ) ^ (n + 1) < ‖Z.z ρ‖} : Set Z.Zero),
              (1 : ℝ) / ‖Z.z ρ.val‖ ^ 2)
        ≤ ENNReal.ofReal (Cgeo * ((2 : ℝ) ^ n) ^ (ε - 1)) := by
    -- Use `hENN` and then `hENN_le`.
    simpa [hENN] using hENN_le
  -- Finally, unwrap `ENNReal.ofReal` and finish.

-/
end OrderOne

end Hadamard
~~~~~~

