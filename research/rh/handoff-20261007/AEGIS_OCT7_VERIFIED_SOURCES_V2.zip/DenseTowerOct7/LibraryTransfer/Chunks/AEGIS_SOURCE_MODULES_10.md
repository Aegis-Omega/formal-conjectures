# AEGIS source modules 10

Exact pinned or operator archive source. Compilation was not performed during transfer.

## RHKreinFirstCellV1

Path: `source/RHKreinFirstCellV1.lean`

Original source lines: 1–1396

Full file SHA256: `63f82f9d34b7d8bfa06c35036ac5baf9d9929615a76a9efc280d1c8d452ac978`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinCellAnalyticBridgeV1
import AEGISOverlay.RHKreinFiniteIntervalKernelV1
import Mathlib.Analysis.Analytic.IsolatedZeros
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Sinc

/-!
# First serialized cell reduction

This file instantiates the generic M8-to-cell bridge on the actual first cell
of the 2199-cell payload. Exact arithmetic closes the cell geometry, the
degree-seven polynomial lower bound and the final weighted budget. The retained
premises are concrete even Taylor-jet coefficient enclosures; the symbol,
zeroth coefficient, and all odd coefficients are produced in this file.

The decimal rationals below are candidate Taylor coefficients.  The zeroth
and all odd coefficients are proved exact here; the second, fourth, and sixth
coefficients are proved within their rational enclosures.  No all-cells,
pointwise, or RH claim is made.

AUTHORITY_EFFECT = NONE.
-/

open scoped BigOperators

set_option autoImplicit false
set_option maxHeartbeats 200000
noncomputable section

namespace AEGIS.RHKreinFirstCellV1

open AEGIS.RHKreinCellAnalyticBridgeV1
open AEGIS.RHKreinCorrectionM8BoundV1
open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1

/-- The literal first entry of the committed 2199-cell payload. -/
def firstCell : FiniteCellV1 :=
  ⟨0, 75 / 4096, 114511397055347687⟩

theorem firstCell_mem : firstCell ∈ finiteCells := by
  unfold finiteCells
  exact List.mem_cons.mpr (Or.inl rfl)

def firstCenter : ℝ := 0
def firstRadius : ℝ := 75 / 4096

/-- Twelve-decimal centers for the eight normalized Taylor coefficients. -/
def firstJet : ℕ → ℝ
  | 0 => 25181386563 / 62500000000
  | 1 => 0
  | 2 => 2243764096193 / 1000000000000
  | 3 => 0
  | 4 => 2096414380799 / 1000000000000
  | 5 => 0
  | 6 => -190744442117 / 1000000000000
  | 7 => 0
  | _ => 0

def firstJetError (_ : ℕ) : ℝ := 1 / 1000000000000

/-- A decimal rational strictly below the sign-aware polynomial lower bound
for `firstJet` on this nonnegative cell. -/
def firstPolynomialLower : ℝ := 4029021849 / 10000000000

/-- The exact M8 remainder plus the eight enclosure radii used by the bridge. -/
def firstTaylorError : ℝ :=
  (serializedM8Q : ℝ) * firstRadius ^ 8 / 40320 +
    ∑ k ∈ Finset.range 8, firstJetError k * firstRadius ^ k

private theorem firstTaylorError_le :
    firstTaylorError ≤ (1001 / 1000000000 : ℝ) := by
  norm_num [firstTaylorError, firstRadius, firstJetError, serializedM8Q,
    Finset.sum_range_succ]

private theorem firstGroundBudget :
    (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
        (lowerValue firstCell : ℝ) ≤
      (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
        ((-3177232903 / 500000000 : ℝ) - 1 / 16) +
      (firstPolynomialLower - 1001 / 1000000000) := by
  norm_num [firstCell, lowerValue, firstPolynomialLower]

private theorem firstCell_cover (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    |t - firstCenter| ≤ firstRadius := by
  norm_num [firstCell, firstCenter, firstRadius] at hlo hhi ⊢
  rw [abs_le]
  constructor <;> linarith

private theorem firstPolynomialLower_le (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    firstPolynomialLower ≤ jetPolynomial7 firstJet firstCenter t := by
  have hx := firstCell_cover t hlo hhi
  have ht0 : 0 ≤ t := by norm_num [firstCell] at hlo; exact hlo
  have htr : t ≤ firstRadius := by
    norm_num [firstCell, firstRadius] at hhi ⊢
    exact hhi
  have hp6 : t ^ 6 ≤ firstRadius ^ 6 := pow_le_pow_left₀ ht0 htr 6
  have h6 := mul_le_mul_of_nonpos_left hp6
    (by norm_num [firstJet] : firstJet 6 ≤ 0)
  have h2 : 0 ≤ firstJet 2 * t ^ 2 :=
    mul_nonneg (by norm_num [firstJet]) (sq_nonneg t)
  have h4 : 0 ≤ firstJet 4 * t ^ 4 :=
    mul_nonneg (by norm_num [firstJet]) (by positivity)
  norm_num [firstPolynomialLower, firstRadius, firstCenter, firstJet,
    jetPolynomial7, Finset.sum_range_succ] at h2 h4 h6 ⊢
  linarith only [h2, h4, h6]

private theorem firstCell_weight_le (t : ℝ)
    (hlo : (firstCell.lo : ℝ) ≤ t) (hhi : t ≤ (firstCell.hi : ℝ)) :
    (t ^ 2 + 1 / 4) ^ 2 ≤
      (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) := by
  norm_num [firstCell] at hlo hhi
  nlinarith [sq_nonneg t,
    mul_nonneg (sub_nonneg.mpr hhi) (add_nonneg hlo (by norm_num : (0 : ℝ) ≤ 75 / 4096))]

/-! The 128-term endpoint is split into small exact-arithmetic blocks.  This
keeps kernel replay bounded: no single `norm_num` invocation constructs the
enormous reduced denominator of the full partial sum. -/

private theorem firstDigammaPartialLower :
    (-3644384222938337 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 128, quarterTerm 0 n := by
  have h0 : (-1778990475942809 / 500000000000000 : ℝ) ≤
      ∑ n ∈ Finset.range 8, quarterTerm 0 n := by
    norm_num [quarterTerm]
  have h1 : (-45751803709751 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 8 16, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h2 : (-3083795298877 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 16 24, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h3 : (-1935164358237 / 250000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 24 32, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h4 : (-4654313362753 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 32 40, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h5 : (-155349765201 / 50000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 40 48, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h6 : (-2221295982913 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 48 56, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h7 : (-1667071562231 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 56 64, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h8 : (-1297262096897 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 64 72, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h9 : (-1038219382249 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 72 80, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h10 : (-849722915773 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 80 88, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h11 : (-177072106951 / 250000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 88 96, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h12 : (-599452985397 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 96 104, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h13 : (-51391311861 / 100000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 104 112, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h14 : (-445463229723 / 1000000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 112 120, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  have h15 : (-77967009453 / 200000000000000 : ℝ) ≤
      ∑ n ∈ Finset.Ico 120 128, quarterTerm 0 n := by
    rw [Finset.sum_Ico_eq_sum_range]
    norm_num [quarterTerm]
  rw [← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 120 ≤ 128 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 112 ≤ 120 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 104 ≤ 112 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 96 ≤ 104 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 88 ≤ 96 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 80 ≤ 88 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 72 ≤ 80 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 64 ≤ 72 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 56 ≤ 64 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 48 ≤ 56 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 40 ≤ 48 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 32 ≤ 40 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 24 ≤ 32 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 16 ≤ 24 by norm_num),
    ← Finset.sum_range_add_sum_Ico (quarterTerm 0) (show 8 ≤ 16 by norm_num)]
  linarith only [h0, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15]

private theorem firstDigammaLower (t : ℝ) :
    (-371022478788819736651 / 87723000000000000000 : ℝ) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * Complex.I / 2)).re := by
  have hcert := digamma_quarter_certificate_lower 0 128
  have hpartial := firstDigammaPartialLower
  have hzero :
      (-371022478788819736651 / 87723000000000000000 : ℝ) ≤
        (Complex.digamma ((1 / 4 : ℂ) + ((0 : ℝ) : ℂ) * Complex.I / 2)).re := by
    norm_num at hcert ⊢
    linarith only [hcert, hpartial]
  exact hzero.trans (digamma_quarter_mono_of_sq_le 0 t (by simpa using sq_nonneg t))

private theorem firstLogPiUpper :
    Real.log Real.pi ≤ (1144729886 / 1000000000 : ℝ) := by
  let x : ℝ := (1144729886 / 2000000000 : ℝ)
  let p : ℝ := ∑ m ∈ Finset.range 16, x ^ m / m.factorial
  let e : ℝ := |x| ^ 16 * ((17 : ℝ) / (Nat.factorial 16 * 16))
  have hb := Real.exp_bound (x := x) (n := 16) (by norm_num [x]) (by norm_num)
  have hlo : p - e ≤ Real.exp x := by
    rw [abs_sub_le_iff] at hb
    dsimp [p, e]
    linarith [hb.1]
  have hp : 0 ≤ p - e := by
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg]
  have hexp : 0 < Real.exp x := Real.exp_pos x
  have hsquare : (p - e) ^ 2 ≤ (Real.exp x) ^ 2 := by
    nlinarith
  have hpi : Real.pi ≤ (p - e) ^ 2 := by
    have h := Real.pi_lt_d20
    norm_num [p, e, x, Finset.sum_range_succ, abs_of_nonneg] at h ⊢
    linarith
  have hq : Real.exp (1144729886 / 1000000000 : ℝ) = (Real.exp x) ^ 2 := by
    rw [show (1144729886 / 1000000000 : ℝ) = x + x by norm_num [x], Real.exp_add]
    ring
  apply (Real.log_le_iff_le_exp Real.pi_pos).2
  rw [hq]
  exact hpi.trans hsquare

private theorem firstPrimeAmplitudeUpper :
    Real.sqrt 2 * Real.log 2 ≤
      (1414213563 / 1000000000 : ℝ) * (6931471808 / 10000000000 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (1414213563 / 1000000000 : ℝ) := by
    have hs2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    have hs0 := Real.sqrt_nonneg (2 : ℝ)
    nlinarith
  have hl0 := (log_two_enclosure).2
  have hl : Real.log 2 ≤ (6931471808 / 10000000000 : ℝ) := by
    norm_num at hl0 ⊢
    exact hl0.le
  exact mul_le_mul hs hl (Real.log_nonneg (by norm_num)) (by norm_num)

/-- The symbol premise for the first cell, now produced entirely by Lean from
the proved digamma series, monotonicity, and rational transcendental bounds. -/
theorem firstCell_symbol_lower (t : ℝ) :
    (-3177232903 / 500000000 : ℝ) ≤ symbol t := by
  have hd := firstDigammaLower t
  have hlp := firstLogPiUpper
  have hamp := firstPrimeAmplitudeUpper
  have hamp0 : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hcos := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hamp0
  unfold symbol archSymbol
  norm_num at hd hlp hamp ⊢
  linarith only [hd, hlp, hamp, hcos]

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
/-- At center zero the sinc/cosine expression collapses to exact rational
coefficient arithmetic, so the zeroth Taylor coefficient needs no enclosure. -/
theorem firstJet_zero_exact :
    exactJetCoefficient firstCenter 0 = firstJet 0 := by
  norm_num [exactJetCoefficient, firstCenter, firstJet, correctionSymbol,
    hatCoefficient, splineCoefficient, Fin.sum_univ_succ]

private theorem sinc_analyticAt_zero : AnalyticAt ℝ Real.sinc 0 := by
  rw [Real.sinc_eq_dslope]
  rcases Real.analyticAt_sin with ⟨p, hp⟩
  exact ⟨p.fslope, hp.has_fpower_series_dslope_fslope⟩

private theorem sinc_analyticAt (x : ℝ) : AnalyticAt ℝ Real.sinc x := by
  by_cases hx : x = 0
  · simpa [hx] using sinc_analyticAt_zero
  · have hquot : AnalyticAt ℝ (fun y : ℝ => Real.sin y / y) x :=
      Real.analyticAt_sin.div analyticAt_id hx
    apply hquot.congr
    filter_upwards [isOpen_ne.mem_nhds hx] with y hy
    exact (Real.sinc_of_ne_zero hy).symm

private theorem sinc_contDiff (n : WithTop ℕ∞) : ContDiff ℝ n Real.sinc := by
  rw [contDiff_iff_contDiffAt]
  exact fun x => (sinc_analyticAt x).contDiffAt

private theorem odd_iteratedDeriv_zero_of_even
    (f : ℝ → ℝ) (heven : ∀ x, f (-x) = f x) (n : ℕ) :
    iteratedDeriv (2 * n + 1) f 0 = 0 := by
  have h := iteratedDeriv_comp_neg (2 * n + 1) f 0
  have heq : (fun x => f (-x)) = f := by
    funext x
    exact heven x
  rw [heq] at h
  have hsign : (-1 : ℝ) ^ (2 * n + 1) = -1 := by
    rw [pow_add, pow_mul]
    norm_num
  rw [hsign] at h
  norm_num at h
  linarith

private theorem deriv_zero_of_even_secondJet
    (f : ℝ → ℝ) (hf : DifferentiableAt ℝ f 0)
    (heven : ∀ x, f (-x) = f x) : deriv f 0 = 0 := by
  have hneg : HasDerivAt Neg.neg (-1) (0 : ℝ) := hasDerivAt_neg 0
  have hfnegzero : HasDerivAt f (deriv f 0) (-0) := by
    simpa only [neg_zero] using hf.hasDerivAt
  have hcomp : HasDerivAt (f ∘ Neg.neg) (deriv f 0 * (-1)) 0 :=
    hfnegzero.comp 0 hneg
  have heq : (f ∘ Neg.neg) = f := by
    funext x
    exact heven x
  rw [heq] at hcomp
  have hu := hcomp.unique hf.hasDerivAt
  linarith

private theorem sinc_first_derivative_zero : iteratedDeriv 1 Real.sinc 0 = 0 := by
  rw [iteratedDeriv_one]
  have hc : ContDiffAt ℝ 1 Real.sinc 0 := sinc_analyticAt_zero.contDiffAt
  exact deriv_zero_of_even_secondJet Real.sinc
    (hc.differentiableAt (by norm_num)) Real.sinc_neg

private theorem sinc_second_derivative_zero :
    iteratedDeriv 2 Real.sinc 0 = -(1 / 3 : ℝ) := by
  have hs : ContDiffAt ℝ 3 Real.sinc 0 := sinc_analyticAt_zero.contDiffAt
  have hid : ContDiffAt ℝ 3 (fun x : ℝ => x) 0 := contDiffAt_id
  have hmul := iteratedDeriv_mul (n := 3) hid hs
  have heq : (fun x : ℝ => x * Real.sinc x) = Real.sin := by
    funext x
    by_cases hx : x = 0
    · simp [hx]
    · rw [Real.sinc_of_ne_zero hx]
      field_simp
  change iteratedDeriv 3 (fun x : ℝ => x * Real.sinc x) 0 = _ at hmul
  rw [heq] at hmul
  norm_num [Real.iteratedDeriv_odd_sin, iteratedDeriv_fun_id,
    Finset.sum_range_succ] at hmul
  linarith

private theorem sinc_fourth_derivative_zero :
    iteratedDeriv 4 Real.sinc 0 = (1 / 5 : ℝ) := by
  have hs : ContDiffAt ℝ 5 Real.sinc 0 := sinc_analyticAt_zero.contDiffAt
  have hid : ContDiffAt ℝ 5 (fun x : ℝ => x) 0 := contDiffAt_id
  have hmul := iteratedDeriv_mul (n := 5) hid hs
  have heq : (fun x : ℝ => x * Real.sinc x) = Real.sin := by
    funext x
    by_cases hx : x = 0
    · simp [hx]
    · rw [Real.sinc_of_ne_zero hx]
      field_simp
  change iteratedDeriv 5 (fun x : ℝ => x * Real.sinc x) 0 = _ at hmul
  rw [heq] at hmul
  norm_num [Real.iteratedDeriv_odd_sin, iteratedDeriv_fun_id,
    Finset.sum_range_succ] at hmul
  linarith

private theorem sinc_sixth_derivative_zero :
    iteratedDeriv 6 Real.sinc 0 = -(1 / 7 : ℝ) := by
  have hs : ContDiffAt ℝ 7 Real.sinc 0 := sinc_analyticAt_zero.contDiffAt
  have hid : ContDiffAt ℝ 7 (fun x : ℝ => x) 0 := contDiffAt_id
  have hmul := iteratedDeriv_mul (n := 7) hid hs
  have heq : (fun x : ℝ => x * Real.sinc x) = Real.sin := by
    funext x
    by_cases hx : x = 0
    · simp [hx]
    · rw [Real.sinc_of_ne_zero hx]
      field_simp
  change iteratedDeriv 7 (fun x : ℝ => x * Real.sinc x) 0 = _ at hmul
  rw [heq] at hmul
  norm_num [Real.iteratedDeriv_odd_sin, iteratedDeriv_fun_id,
    Finset.sum_range_succ] at hmul
  linarith

private theorem scaled_sinc_second_derivative_zero (c : ℝ) :
    iteratedDeriv 2 (fun x : ℝ => Real.sinc (c * x)) 0 = -(c ^ 2 / 3) := by
  rw [iteratedDeriv_comp_const_mul (sinc_contDiff 2) c]
  simp only [mul_zero]
  rw [sinc_second_derivative_zero]
  ring

private theorem scaled_sinc_fourth_derivative_zero (c : ℝ) :
    iteratedDeriv 4 (fun x : ℝ => Real.sinc (c * x)) 0 = c ^ 4 / 5 := by
  rw [iteratedDeriv_comp_const_mul (sinc_contDiff 4) c]
  simp only [mul_zero]
  rw [sinc_fourth_derivative_zero]
  ring

private theorem scaled_sinc_sixth_derivative_zero (c : ℝ) :
    iteratedDeriv 6 (fun x : ℝ => Real.sinc (c * x)) 0 = -(c ^ 6 / 7) := by
  rw [iteratedDeriv_comp_const_mul (sinc_contDiff 6) c]
  simp only [mul_zero]
  rw [sinc_sixth_derivative_zero]
  ring

private theorem scaled_sinc_first_derivative_zero (c : ℝ) :
    iteratedDeriv 1 (fun x : ℝ => Real.sinc (c * x)) 0 = 0 := by
  rw [iteratedDeriv_comp_const_mul (sinc_contDiff 1) c]
  simp only [mul_zero]
  rw [sinc_first_derivative_zero]
  simp

private theorem power_second_derivative_zero
    (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f)
    (h0 : f 0 = 1) (h1 : iteratedDeriv 1 f 0 = 0) (m : ℕ) :
    iteratedDeriv 2 (fun x => f x ^ m) 0 = m * iteratedDeriv 2 f 0 := by
  induction m with
  | zero => simp [iteratedDeriv_const]
  | succ m ih =>
      have hm := iteratedDeriv_mul (n := 2) (x := (0 : ℝ))
        (hf.pow m).contDiffAt hf.contDiffAt
      change iteratedDeriv 2 (fun x => f x ^ m * f x) 0 = _ at hm
      norm_num [Finset.sum_range_succ, h0, h1, ih] at hm
      change iteratedDeriv 2 (fun x => f x ^ m * f x) 0 = _
      rw [hm]
      push_cast
      ring

private theorem power_fourth_derivative_zero
    (f : ℝ → ℝ) (hf : ContDiff ℝ 4 f) (heven : ∀ x, f (-x) = f x)
    (h0 : f 0 = 1) (m : ℕ) :
    iteratedDeriv 4 (fun x => f x ^ m) 0 =
      m * iteratedDeriv 4 f 0 +
        3 * m * (m - 1) * (iteratedDeriv 2 f 0) ^ 2 := by
  have h1 : iteratedDeriv 1 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f heven 0
  have h3 : iteratedDeriv 3 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f heven 1
  induction m with
  | zero => simp [iteratedDeriv_const]
  | succ m ih =>
      have hpowEven (x : ℝ) : (f (-x)) ^ m = (f x) ^ m := by rw [heven]
      have hm1 : iteratedDeriv 1 (fun x => f x ^ m) 0 = 0 := by
        simpa using odd_iteratedDeriv_zero_of_even (fun x => f x ^ m) hpowEven 0
      have hm3 : iteratedDeriv 3 (fun x => f x ^ m) 0 = 0 := by
        simpa using odd_iteratedDeriv_zero_of_even (fun x => f x ^ m) hpowEven 1
      have hm2 := power_second_derivative_zero f (hf.of_le (by norm_num)) h0 h1 m
      have hmul := iteratedDeriv_mul (n := 4) (x := (0 : ℝ))
        (hf.pow m).contDiffAt hf.contDiffAt
      change iteratedDeriv 4 (fun x => f x ^ m * f x) 0 = _ at hmul
      norm_num [Finset.sum_range_succ, h0, h1, h3, hm1, hm2, hm3] at hmul
      change iteratedDeriv 4 (fun x => f x ^ m * f x) 0 = _
      rw [hmul, ih]
      push_cast
      norm_num [Nat.choose]
      ring

private theorem power_sixth_derivative_zero
    (f : ℝ → ℝ) (hf : ContDiff ℝ 6 f) (heven : ∀ x, f (-x) = f x)
    (h0 : f 0 = 1) (m : ℕ) :
    iteratedDeriv 6 (fun x => f x ^ m) 0 =
      m * iteratedDeriv 6 f 0 +
        15 * m * (m - 1) * iteratedDeriv 4 f 0 * iteratedDeriv 2 f 0 +
        15 * m * (m - 1) * (m - 2) * (iteratedDeriv 2 f 0) ^ 3 := by
  have h1 : iteratedDeriv 1 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f heven 0
  have h3 : iteratedDeriv 3 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f heven 1
  have h5 : iteratedDeriv 5 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f heven 2
  induction m with
  | zero => simp [iteratedDeriv_const]
  | succ m ih =>
      have hpowEven (x : ℝ) : (f (-x)) ^ m = (f x) ^ m := by rw [heven]
      have hm1 : iteratedDeriv 1 (fun x => f x ^ m) 0 = 0 := by
        simpa using odd_iteratedDeriv_zero_of_even (fun x => f x ^ m) hpowEven 0
      have hm3 : iteratedDeriv 3 (fun x => f x ^ m) 0 = 0 := by
        simpa using odd_iteratedDeriv_zero_of_even (fun x => f x ^ m) hpowEven 1
      have hm5 : iteratedDeriv 5 (fun x => f x ^ m) 0 = 0 := by
        simpa using odd_iteratedDeriv_zero_of_even (fun x => f x ^ m) hpowEven 2
      have hm2 := power_second_derivative_zero f (hf.of_le (by norm_num)) h0 h1 m
      have hm4 := power_fourth_derivative_zero f (hf.of_le (by norm_num)) heven h0 m
      have hmul := iteratedDeriv_mul (n := 6) (x := (0 : ℝ))
        (hf.pow m).contDiffAt hf.contDiffAt
      change iteratedDeriv 6 (fun x => f x ^ m * f x) 0 = _ at hmul
      norm_num [Finset.sum_range_succ, h0, h1, h3, h5, hm1, hm2, hm3, hm4,
        hm5, Nat.choose] at hmul
      change iteratedDeriv 6 (fun x => f x ^ m * f x) 0 = _
      rw [hmul, ih]
      push_cast
      ring

private theorem scaled_sinc_pow_second_derivative_zero (c : ℝ) (m : ℕ) :
    iteratedDeriv 2 (fun x : ℝ => Real.sinc (c * x) ^ m) 0 =
      -(m * c ^ 2 / 3) := by
  have hc : ContDiff ℝ 2 (fun x : ℝ => Real.sinc (c * x)) :=
    (sinc_contDiff 2).comp (contDiff_const.mul contDiff_id)
  rw [power_second_derivative_zero _ hc (by simp)
    (scaled_sinc_first_derivative_zero c)]
  rw [scaled_sinc_second_derivative_zero]
  ring

private theorem scaled_sinc_pow_fourth_derivative_zero (c : ℝ) (m : ℕ) :
    iteratedDeriv 4 (fun x : ℝ => Real.sinc (c * x) ^ m) 0 =
      m * c ^ 4 / 5 + m * (m - 1) * c ^ 4 / 3 := by
  let f : ℝ → ℝ := fun x => Real.sinc (c * x)
  have hf : ContDiff ℝ 4 f :=
    (sinc_contDiff 4).comp (contDiff_const.mul contDiff_id)
  have heven (x : ℝ) : f (-x) = f x := by simp [f]
  rw [power_fourth_derivative_zero f hf heven (by simp [f])]
  rw [scaled_sinc_second_derivative_zero, scaled_sinc_fourth_derivative_zero]
  ring

private theorem scaled_sinc_pow_sixth_derivative_zero (c : ℝ) (m : ℕ) :
    iteratedDeriv 6 (fun x : ℝ => Real.sinc (c * x) ^ m) 0 =
      -(m * c ^ 6 / 7) - m * (m - 1) * c ^ 6 -
        5 * m * (m - 1) * (m - 2) * c ^ 6 / 9 := by
  let f : ℝ → ℝ := fun x => Real.sinc (c * x)
  have hf : ContDiff ℝ 6 f :=
    (sinc_contDiff 6).comp (contDiff_const.mul contDiff_id)
  have heven (x : ℝ) : f (-x) = f x := by simp [f]
  rw [power_sixth_derivative_zero f hf heven (by simp [f])]
  rw [scaled_sinc_second_derivative_zero, scaled_sinc_fourth_derivative_zero,
    scaled_sinc_sixth_derivative_zero]
  ring

private theorem scaled_cos_second_derivative_zero (c : ℝ) :
    iteratedDeriv 2 (fun x : ℝ => Real.cos (c * x)) 0 = -c ^ 2 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_cos c]
  simp

private theorem scaled_sin_second_derivative_zero (c : ℝ) :
    iteratedDeriv 2 (fun x : ℝ => Real.sin (c * x)) 0 = 0 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_sin c]
  simp

private theorem scaled_cos_third_derivative_zero (c : ℝ) :
    iteratedDeriv 3 (fun x : ℝ => Real.cos (c * x)) 0 = 0 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_cos c]
  simp

private theorem scaled_cos_fourth_derivative_zero (c : ℝ) :
    iteratedDeriv 4 (fun x : ℝ => Real.cos (c * x)) 0 = c ^ 4 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_cos c]
  simp

private theorem scaled_sin_third_derivative_zero (c : ℝ) :
    iteratedDeriv 3 (fun x : ℝ => Real.sin (c * x)) 0 = -c ^ 3 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_sin c]
  simp

private theorem scaled_sin_fourth_derivative_zero (c : ℝ) :
    iteratedDeriv 4 (fun x : ℝ => Real.sin (c * x)) 0 = 0 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_sin c]
  simp

private theorem scaled_cos_fifth_derivative_zero (c : ℝ) :
    iteratedDeriv 5 (fun x : ℝ => Real.cos (c * x)) 0 = 0 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_cos c]
  simp

private theorem scaled_cos_sixth_derivative_zero (c : ℝ) :
    iteratedDeriv 6 (fun x : ℝ => Real.cos (c * x)) 0 = -c ^ 6 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_cos c]
  simp

private theorem scaled_sin_fifth_derivative_zero (c : ℝ) :
    iteratedDeriv 5 (fun x : ℝ => Real.sin (c * x)) 0 = c ^ 5 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_sin c]
  simp

private theorem scaled_sin_sixth_derivative_zero (c : ℝ) :
    iteratedDeriv 6 (fun x : ℝ => Real.sin (c * x)) 0 = 0 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_sin c]
  simp

private theorem scaled_cos_first_derivative_zero (c : ℝ) :
    iteratedDeriv 1 (fun x : ℝ => Real.cos (c * x)) 0 = 0 := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_cos c]
  simp

private theorem scaled_sin_first_derivative_zero (c : ℝ) :
    iteratedDeriv 1 (fun x : ℝ => Real.sin (c * x)) 0 = c := by
  rw [iteratedDeriv_comp_const_mul Real.contDiff_sin c]
  simp

private theorem monomial_cos_second_derivative_zero (m : ℕ) (c : ℝ) :
    iteratedDeriv 2 (fun x : ℝ => x ^ m * Real.cos (c * x)) 0 =
      (if m = 0 then -c ^ 2 else if m = 2 then 2 else 0) := by
  have hcos : ContDiff ℝ 2 (fun x : ℝ => Real.cos (c * x)) :=
    Real.contDiff_cos.comp (contDiff_const.mul contDiff_id)
  have hmul := iteratedDeriv_mul (n := 2) (x := (0 : ℝ))
    (contDiff_id.pow m).contDiffAt hcos.contDiffAt
  change iteratedDeriv 2 (fun x : ℝ => x ^ m * Real.cos (c * x)) 0 = _ at hmul
  rcases m with (_ | _ | _ | m)
  · norm_num [Finset.sum_range_succ, iteratedDeriv_pow,
      scaled_cos_first_derivative_zero, scaled_cos_second_derivative_zero] at hmul ⊢
  · norm_num [Finset.sum_range_succ, iteratedDeriv_pow, iteratedDeriv_fun_id_zero,
      scaled_cos_first_derivative_zero, scaled_cos_second_derivative_zero] at hmul ⊢
    linarith
  · norm_num [Finset.sum_range_succ, iteratedDeriv_pow,
      scaled_cos_first_derivative_zero, scaled_cos_second_derivative_zero] at hmul ⊢
    linarith
  · have hexp : m + 1 + 1 + 1 - 2 = m + 1 := by omega
    norm_num [Finset.sum_range_succ, iteratedDeriv_pow,
      scaled_cos_first_derivative_zero, scaled_cos_second_derivative_zero] at hmul ⊢
    rw [hexp] at hmul
    simp at hmul
    exact hmul

private theorem monomial_sin_second_derivative_zero (m : ℕ) (c : ℝ) :
    iteratedDeriv 2 (fun x : ℝ => x ^ m * Real.sin (c * x)) 0 =
      (if m = 1 then 2 * c else 0) := by
  have hsin : ContDiff ℝ 2 (fun x : ℝ => Real.sin (c * x)) :=
    Real.contDiff_sin.comp (contDiff_const.mul contDiff_id)
  have hmul := iteratedDeriv_mul (n := 2) (x := (0 : ℝ))
    (contDiff_id.pow m).contDiffAt hsin.contDiffAt
  change iteratedDeriv 2 (fun x : ℝ => x ^ m * Real.sin (c * x)) 0 = _ at hmul
  rcases m with (_ | _ | _ | m)
  · norm_num [Finset.sum_range_succ, iteratedDeriv_pow,
      scaled_sin_first_derivative_zero, scaled_sin_second_derivative_zero] at hmul ⊢
  · norm_num [Finset.sum_range_succ, iteratedDeriv_pow, iteratedDeriv_fun_id_zero,
      scaled_sin_first_derivative_zero, scaled_sin_second_derivative_zero] at hmul ⊢
    linarith
  · norm_num [Finset.sum_range_succ, iteratedDeriv_pow,
      scaled_sin_first_derivative_zero, scaled_sin_second_derivative_zero] at hmul ⊢
    linarith
  · norm_num [Finset.sum_range_succ, iteratedDeriv_pow,
      scaled_sin_first_derivative_zero, scaled_sin_second_derivative_zero] at hmul ⊢
    exact hmul

private theorem monomial_cos_fourth_derivative_zero (m : Fin 5) (c : ℝ) :
    iteratedDeriv 4 (fun x : ℝ => x ^ m.val * Real.cos (c * x)) 0 =
      (if m.val = 0 then c ^ 4 else if m.val = 2 then -12 * c ^ 2
       else if m.val = 4 then 24 else 0) := by
  have hcos : ContDiff ℝ 4 (fun x : ℝ => Real.cos (c * x)) :=
    Real.contDiff_cos.comp (contDiff_const.mul contDiff_id)
  have hmul := iteratedDeriv_mul (n := 4) (x := (0 : ℝ))
    (contDiff_id.pow m.val).contDiffAt hcos.contDiffAt
  change iteratedDeriv 4 (fun x : ℝ => x ^ m.val * Real.cos (c * x)) 0 = _ at hmul
  fin_cases m <;>
    norm_num [Finset.sum_range_succ, iteratedDeriv_pow, iteratedDeriv_fun_id_zero,
      scaled_cos_first_derivative_zero, scaled_cos_second_derivative_zero,
      scaled_cos_third_derivative_zero, scaled_cos_fourth_derivative_zero,
      Nat.choose] at hmul ⊢ <;>
    exact hmul

private theorem monomial_sin_fourth_derivative_zero (m : Fin 5) (c : ℝ) :
    iteratedDeriv 4 (fun x : ℝ => x ^ m.val * Real.sin (c * x)) 0 =
      (if m.val = 1 then -4 * c ^ 3 else if m.val = 3 then 24 * c else 0) := by
  have hsin : ContDiff ℝ 4 (fun x : ℝ => Real.sin (c * x)) :=
    Real.contDiff_sin.comp (contDiff_const.mul contDiff_id)
  have hmul := iteratedDeriv_mul (n := 4) (x := (0 : ℝ))
    (contDiff_id.pow m.val).contDiffAt hsin.contDiffAt
  change iteratedDeriv 4 (fun x : ℝ => x ^ m.val * Real.sin (c * x)) 0 = _ at hmul
  fin_cases m <;>
    norm_num [Finset.sum_range_succ, iteratedDeriv_pow, iteratedDeriv_fun_id_zero,
      scaled_sin_first_derivative_zero, scaled_sin_second_derivative_zero,
      scaled_sin_third_derivative_zero, scaled_sin_fourth_derivative_zero,
      Nat.choose] at hmul ⊢ <;>
    exact hmul

private theorem monomial_cos_sixth_derivative_zero (m : Fin 5) (c : ℝ) :
    iteratedDeriv 6 (fun x : ℝ => x ^ m.val * Real.cos (c * x)) 0 =
      (if m.val = 0 then -c ^ 6 else if m.val = 2 then 30 * c ^ 4
       else if m.val = 4 then -360 * c ^ 2 else 0) := by
  have hcos : ContDiff ℝ 6 (fun x : ℝ => Real.cos (c * x)) :=
    Real.contDiff_cos.comp (contDiff_const.mul contDiff_id)
  have hmul := iteratedDeriv_mul (n := 6) (x := (0 : ℝ))
    (contDiff_id.pow m.val).contDiffAt hcos.contDiffAt
  change iteratedDeriv 6 (fun x : ℝ => x ^ m.val * Real.cos (c * x)) 0 = _ at hmul
  fin_cases m <;>
    norm_num [Finset.sum_range_succ, iteratedDeriv_pow, iteratedDeriv_fun_id_zero,
      scaled_cos_first_derivative_zero, scaled_cos_second_derivative_zero,
      scaled_cos_third_derivative_zero, scaled_cos_fourth_derivative_zero,
      scaled_cos_fifth_derivative_zero, scaled_cos_sixth_derivative_zero,
      Nat.choose] at hmul ⊢ <;>
    exact hmul

private theorem monomial_sin_sixth_derivative_zero (m : Fin 5) (c : ℝ) :
    iteratedDeriv 6 (fun x : ℝ => x ^ m.val * Real.sin (c * x)) 0 =
      (if m.val = 1 then 6 * c ^ 5 else if m.val = 3 then -120 * c ^ 3 else 0) := by
  have hsin : ContDiff ℝ 6 (fun x : ℝ => Real.sin (c * x)) :=
    Real.contDiff_sin.comp (contDiff_const.mul contDiff_id)
  have hmul := iteratedDeriv_mul (n := 6) (x := (0 : ℝ))
    (contDiff_id.pow m.val).contDiffAt hsin.contDiffAt
  change iteratedDeriv 6 (fun x : ℝ => x ^ m.val * Real.sin (c * x)) 0 = _ at hmul
  fin_cases m <;>
    norm_num [Finset.sum_range_succ, iteratedDeriv_pow, iteratedDeriv_fun_id_zero,
      scaled_sin_first_derivative_zero, scaled_sin_second_derivative_zero,
      scaled_sin_third_derivative_zero, scaled_sin_fourth_derivative_zero,
      scaled_sin_fifth_derivative_zero, scaled_sin_sixth_derivative_zero,
      Nat.choose] at hmul ⊢ <;>
    exact hmul

private def firstHatSum (t : ℝ) : ℝ :=
  ∑ j : Fin 199, (hatCoefficient j : ℝ) * Real.cos (hatCenter j * t)

private def firstSplineSum (t : ℝ) : ℝ :=
  ∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
    (if j.val % 2 = 0 then Real.cos ((1619 / 2000) * t)
     else Real.sin ((1619 / 2000) * t))

private def firstHatFactor (t : ℝ) : ℝ := Real.sinc ((1 / 100) * t) ^ 2
private def firstSplineFactor (t : ℝ) : ℝ := Real.sinc ((1 / 2000) * t) ^ 19

private theorem firstHatSum_contDiff : ContDiff ℝ 2 firstHatSum := by
  unfold firstHatSum
  exact ContDiff.sum fun j _ => contDiff_const.mul
    (Real.contDiff_cos.comp (contDiff_const.mul contDiff_id))

private theorem firstSplineSum_contDiff : ContDiff ℝ 2 firstSplineSum := by
  unfold firstSplineSum
  apply ContDiff.sum
  intro j _
  by_cases h : j.val % 2 = 0 <;> simp only [h, if_true, if_false] <;> fun_prop

private theorem firstHatFactor_contDiff : ContDiff ℝ 2 firstHatFactor := by
  exact ((sinc_contDiff 2).comp (contDiff_const.mul contDiff_id)).pow 2

private theorem firstSplineFactor_contDiff : ContDiff ℝ 2 firstSplineFactor := by
  exact ((sinc_contDiff 2).comp (contDiff_const.mul contDiff_id)).pow 19

private theorem firstHatSum_contDiff_four : ContDiff ℝ 4 firstHatSum := by
  unfold firstHatSum
  exact ContDiff.sum fun j _ => contDiff_const.mul
    (Real.contDiff_cos.comp (contDiff_const.mul contDiff_id))

private theorem firstSplineSum_contDiff_four : ContDiff ℝ 4 firstSplineSum := by
  unfold firstSplineSum
  apply ContDiff.sum
  intro j _
  by_cases h : j.val % 2 = 0 <;> simp only [h, if_true, if_false] <;> fun_prop

private theorem firstHatFactor_contDiff_four : ContDiff ℝ 4 firstHatFactor := by
  exact ((sinc_contDiff 4).comp (contDiff_const.mul contDiff_id)).pow 2

private theorem firstSplineFactor_contDiff_four : ContDiff ℝ 4 firstSplineFactor := by
  exact ((sinc_contDiff 4).comp (contDiff_const.mul contDiff_id)).pow 19

private theorem firstHatSum_contDiff_six : ContDiff ℝ 6 firstHatSum := by
  unfold firstHatSum
  exact ContDiff.sum fun j _ => contDiff_const.mul
    (Real.contDiff_cos.comp (contDiff_const.mul contDiff_id))

private theorem firstSplineSum_contDiff_six : ContDiff ℝ 6 firstSplineSum := by
  unfold firstSplineSum
  apply ContDiff.sum
  intro j _
  by_cases h : j.val % 2 = 0 <;> simp only [h, if_true, if_false] <;> fun_prop

private theorem firstHatFactor_contDiff_six : ContDiff ℝ 6 firstHatFactor := by
  exact ((sinc_contDiff 6).comp (contDiff_const.mul contDiff_id)).pow 2

private theorem firstSplineFactor_contDiff_six : ContDiff ℝ 6 firstSplineFactor := by
  exact ((sinc_contDiff 6).comp (contDiff_const.mul contDiff_id)).pow 19

private theorem firstHatSum_even (t : ℝ) : firstHatSum (-t) = firstHatSum t := by
  unfold firstHatSum
  apply Finset.sum_congr rfl
  intro j _
  rw [show hatCenter j * -t = -(hatCenter j * t) by ring, Real.cos_neg]

private theorem firstSplineSum_even (t : ℝ) : firstSplineSum (-t) = firstSplineSum t := by
  unfold firstSplineSum
  apply Finset.sum_congr rfl
  intro j _
  fin_cases j
  · norm_num [Real.cos_neg]
  · norm_num [Real.sin_neg]
  · norm_num [Real.cos_neg]
  · norm_num [Real.sin_neg]
    ring
  · norm_num [Real.cos_neg]

private theorem firstHatFactor_even (t : ℝ) : firstHatFactor (-t) = firstHatFactor t := by
  simp [firstHatFactor]

private theorem firstSplineFactor_even (t : ℝ) :
    firstSplineFactor (-t) = firstSplineFactor t := by
  simp [firstSplineFactor]

private theorem first_zero_of_even (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f)
    (heven : ∀ t, f (-t) = f t) : iteratedDeriv 1 f 0 = 0 := by
  rw [iteratedDeriv_one]
  exact deriv_zero_of_even_secondJet f
    ((hf.differentiable (by norm_num)).differentiableAt) heven

private theorem firstHatSum_second :
    iteratedDeriv 2 firstHatSum 0 =
      ∑ j : Fin 199, -(hatCoefficient j : ℝ) * hatCenter j ^ 2 := by
  unfold firstHatSum
  rw [iteratedDeriv_fun_sum]
  · apply Finset.sum_congr rfl
    intro j _
    rw [iteratedDeriv_const_mul_field, scaled_cos_second_derivative_zero]
    ring
  · intro j _
    exact (contDiff_const.mul
      (Real.contDiff_cos.comp (contDiff_const.mul contDiff_id))).contDiffAt

private theorem firstSplineSum_second :
    iteratedDeriv 2 firstSplineSum 0 =
      ∑ j : Fin 5, (splineCoefficient j : ℝ) *
        (if j.val % 2 = 0 then
          (if j.val = 0 then -((1619 / 2000 : ℝ) ^ 2)
           else if j.val = 2 then 2 else 0)
         else if j.val = 1 then 2 * (1619 / 2000 : ℝ) else 0) := by
  unfold firstSplineSum
  rw [iteratedDeriv_fun_sum]
  · apply Finset.sum_congr rfl
    intro j _
    simp only [mul_assoc]
    rw [iteratedDeriv_const_mul_field]
    fin_cases j
    · norm_num
      rw [scaled_cos_second_derivative_zero]
      ring
    · norm_num
      left
      convert monomial_sin_second_derivative_zero 1 (1619 / 2000) using 1 <;> norm_num
    · norm_num
      rw [monomial_cos_second_derivative_zero]
      norm_num
    · norm_num
      rw [monomial_sin_second_derivative_zero]
      norm_num
    · norm_num
      rw [monomial_cos_second_derivative_zero]
      norm_num
  · intro j _
    by_cases h : j.val % 2 = 0 <;> simp only [h, if_true, if_false] <;> fun_prop

private theorem firstHatSum_fourth :
    iteratedDeriv 4 firstHatSum 0 =
      ∑ j : Fin 199, (hatCoefficient j : ℝ) * hatCenter j ^ 4 := by
  unfold firstHatSum
  rw [iteratedDeriv_fun_sum]
  · apply Finset.sum_congr rfl
    intro j _
    rw [iteratedDeriv_const_mul_field, scaled_cos_fourth_derivative_zero]
  · intro j _
    exact (contDiff_const.mul
      (Real.contDiff_cos.comp (contDiff_const.mul contDiff_id))).contDiffAt

private theorem firstSplineSum_fourth :
    iteratedDeriv 4 firstSplineSum 0 =
      ∑ j : Fin 5, (splineCoefficient j : ℝ) *
        (if j.val = 0 then (1619 / 2000 : ℝ) ^ 4
         else if j.val = 1 then -4 * (1619 / 2000 : ℝ) ^ 3
         else if j.val = 2 then -12 * (1619 / 2000 : ℝ) ^ 2
         else if j.val = 3 then 24 * (1619 / 2000 : ℝ)
         else if j.val = 4 then 24 else 0) := by
  unfold firstSplineSum
  rw [iteratedDeriv_fun_sum]
  · apply Finset.sum_congr rfl
    intro j _
    simp only [mul_assoc]
    rw [iteratedDeriv_const_mul_field]
    by_cases h : j.val % 2 = 0
    · simp only [h, if_true]
      rw [monomial_cos_fourth_derivative_zero j]
      fin_cases j <;> simp_all
    · simp only [h, if_false]
      rw [monomial_sin_fourth_derivative_zero j]
      fin_cases j <;> simp_all
  · intro j _
    by_cases h : j.val % 2 = 0 <;> simp only [h, if_true, if_false] <;> fun_prop

private theorem firstHatSum_sixth :
    iteratedDeriv 6 firstHatSum 0 =
      ∑ j : Fin 199, -(hatCoefficient j : ℝ) * hatCenter j ^ 6 := by
  unfold firstHatSum
  rw [iteratedDeriv_fun_sum]
  · apply Finset.sum_congr rfl
    intro j _
    rw [iteratedDeriv_const_mul_field, scaled_cos_sixth_derivative_zero]
    ring
  · intro j _
    exact (contDiff_const.mul
      (Real.contDiff_cos.comp (contDiff_const.mul contDiff_id))).contDiffAt

private theorem firstSplineSum_sixth :
    iteratedDeriv 6 firstSplineSum 0 =
      ∑ j : Fin 5, (splineCoefficient j : ℝ) *
        (if j.val = 0 then -((1619 / 2000 : ℝ) ^ 6)
         else if j.val = 1 then 6 * (1619 / 2000 : ℝ) ^ 5
         else if j.val = 2 then 30 * (1619 / 2000 : ℝ) ^ 4
         else if j.val = 3 then -120 * (1619 / 2000 : ℝ) ^ 3
         else if j.val = 4 then -360 * (1619 / 2000 : ℝ) ^ 2 else 0) := by
  unfold firstSplineSum
  rw [iteratedDeriv_fun_sum]
  · apply Finset.sum_congr rfl
    intro j _
    simp only [mul_assoc]
    rw [iteratedDeriv_const_mul_field]
    by_cases h : j.val % 2 = 0
    · simp only [h, if_true]
      rw [monomial_cos_sixth_derivative_zero j]
      fin_cases j <;> simp_all
    · simp only [h, if_false]
      rw [monomial_sin_sixth_derivative_zero j]
      fin_cases j <;> simp_all
  · intro j _
    by_cases h : j.val % 2 = 0 <;> simp only [h, if_true, if_false] <;> fun_prop

private theorem correctionSymbol_second_formula :
    iteratedDeriv 2 correctionSymbol 0 =
      (2 / 50 : ℝ) *
        (iteratedDeriv 2 firstHatFactor 0 * firstHatSum 0 +
          iteratedDeriv 2 firstHatSum 0) +
      (iteratedDeriv 2 firstSplineFactor 0 * firstSplineSum 0 +
        iteratedDeriv 2 firstSplineSum 0) := by
  have hh := iteratedDeriv_mul (n := 2) (x := (0 : ℝ))
    firstHatFactor_contDiff.contDiffAt firstHatSum_contDiff.contDiffAt
  have hs := iteratedDeriv_mul (n := 2) (x := (0 : ℝ))
    firstSplineFactor_contDiff.contDiffAt firstSplineSum_contDiff.contDiffAt
  have hh1 := first_zero_of_even firstHatFactor firstHatFactor_contDiff firstHatFactor_even
  have hh2 := first_zero_of_even firstHatSum firstHatSum_contDiff firstHatSum_even
  have hs1 := first_zero_of_even firstSplineFactor firstSplineFactor_contDiff
    firstSplineFactor_even
  have hs2 := first_zero_of_even firstSplineSum firstSplineSum_contDiff firstSplineSum_even
  have hh0 : firstHatFactor 0 = 1 := by simp [firstHatFactor]
  have hs0 : firstSplineFactor 0 = 1 := by simp [firstSplineFactor]
  have heq : correctionSymbol = fun t =>
      (2 / 50 : ℝ) * (firstHatFactor t * firstHatSum t) +
        firstSplineFactor t * firstSplineSum t := by
    funext t
    simp [correctionSymbol, firstHatFactor, firstHatSum, firstSplineFactor,
      firstSplineSum, div_eq_mul_inv, mul_comm, mul_left_comm, mul_assoc]
  rw [heq, iteratedDeriv_fun_add]
  · rw [iteratedDeriv_const_mul_field]
    change iteratedDeriv 2 (fun t => firstHatFactor t * firstHatSum t) 0 = _ at hh
    change iteratedDeriv 2 (fun t => firstSplineFactor t * firstSplineSum t) 0 = _ at hs
    norm_num [Finset.sum_range_succ] at hh hs
    rw [iteratedDeriv_one] at hh1 hh2 hs1 hs2
    rw [hh1, hh2] at hh
    rw [hs1, hs2] at hs
    rw [hh0] at hh
    rw [hs0] at hs
    norm_num at hh hs
    rw [hh, hs]
    ring
  · exact (contDiff_const.mul
      (firstHatFactor_contDiff.mul firstHatSum_contDiff)).contDiffAt
  · exact (firstSplineFactor_contDiff.mul firstSplineSum_contDiff).contDiffAt

set_option maxRecDepth 8192 in
set_option maxHeartbeats 8000000 in
private theorem correctionSymbol_second_enclosure :
    |iteratedDeriv 2 correctionSymbol 0 / 2 -
        (2243764096193 / 1000000000000 : ℝ)| ≤
      (1 / 1000000000000 : ℝ) := by
  have hhatFactor : iteratedDeriv 2 firstHatFactor 0 =
      -(2 * (1 / 100 : ℝ) ^ 2 / 3) := by
    exact scaled_sinc_pow_second_derivative_zero (1 / 100) 2
  have hsplineFactor : iteratedDeriv 2 firstSplineFactor 0 =
      -(19 * (1 / 2000 : ℝ) ^ 2 / 3) := by
    exact scaled_sinc_pow_second_derivative_zero (1 / 2000) 19
  rw [correctionSymbol_second_formula, firstHatSum_second, firstSplineSum_second,
    hhatFactor, hsplineFactor]
  norm_num [firstHatFactor, firstSplineFactor, firstHatSum, firstSplineSum,
    hatCoefficient, splineCoefficient, hatCenter, Fin.sum_univ_succ]

/-- The normalized second Taylor coefficient lies in its serialized
twelve-decimal enclosure by exact rational kernel computation. -/
theorem firstJet_two_enclosure :
    |exactJetCoefficient firstCenter 2 - firstJet 2| ≤ firstJetError 2 := by
  simpa [exactJetCoefficient, firstCenter, firstJet, firstJetError,
    div_eq_mul_inv, mul_comm] using
    correctionSymbol_second_enclosure

private theorem product_fourth_zero_of_even
    (f g : ℝ → ℝ) (hf : ContDiff ℝ 4 f) (hg : ContDiff ℝ 4 g)
    (hfeven : ∀ x, f (-x) = f x) (hgeven : ∀ x, g (-x) = g x) :
    iteratedDeriv 4 (fun x => f x * g x) 0 =
      iteratedDeriv 4 f 0 * g 0 +
        6 * iteratedDeriv 2 f 0 * iteratedDeriv 2 g 0 +
        f 0 * iteratedDeriv 4 g 0 := by
  have hmul := iteratedDeriv_mul (n := 4) (x := (0 : ℝ)) hf.contDiffAt hg.contDiffAt
  have hf1 : iteratedDeriv 1 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f hfeven 0
  have hf3 : iteratedDeriv 3 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f hfeven 1
  have hg1 : iteratedDeriv 1 g 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even g hgeven 0
  have hg3 : iteratedDeriv 3 g 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even g hgeven 1
  change iteratedDeriv 4 (fun x => f x * g x) 0 = _ at hmul
  norm_num [Finset.sum_range_succ, hf1, hf3, hg1, hg3, Nat.choose] at hmul
  rw [hmul]
  ring

private theorem correctionSymbol_fourth_formula :
    iteratedDeriv 4 correctionSymbol 0 =
      (2 / 50 : ℝ) *
        (iteratedDeriv 4 firstHatFactor 0 * firstHatSum 0 +
          6 * iteratedDeriv 2 firstHatFactor 0 * iteratedDeriv 2 firstHatSum 0 +
          iteratedDeriv 4 firstHatSum 0) +
      (iteratedDeriv 4 firstSplineFactor 0 * firstSplineSum 0 +
        6 * iteratedDeriv 2 firstSplineFactor 0 * iteratedDeriv 2 firstSplineSum 0 +
        iteratedDeriv 4 firstSplineSum 0) := by
  have hh := product_fourth_zero_of_even firstHatFactor firstHatSum
    firstHatFactor_contDiff_four firstHatSum_contDiff_four
    firstHatFactor_even firstHatSum_even
  have hs := product_fourth_zero_of_even firstSplineFactor firstSplineSum
    firstSplineFactor_contDiff_four firstSplineSum_contDiff_four
    firstSplineFactor_even firstSplineSum_even
  have hh0 : firstHatFactor 0 = 1 := by simp [firstHatFactor]
  have hs0 : firstSplineFactor 0 = 1 := by simp [firstSplineFactor]
  have heq : correctionSymbol = fun t =>
      (2 / 50 : ℝ) * (firstHatFactor t * firstHatSum t) +
        firstSplineFactor t * firstSplineSum t := by
    funext t
    simp [correctionSymbol, firstHatFactor, firstHatSum, firstSplineFactor,
      firstSplineSum, div_eq_mul_inv, mul_comm, mul_left_comm, mul_assoc]
  rw [heq, iteratedDeriv_fun_add]
  · rw [iteratedDeriv_const_mul_field]
    rw [hh0] at hh
    rw [hs0] at hs
    norm_num at hh hs
    rw [hh, hs]
  · exact (contDiff_const.mul
      (firstHatFactor_contDiff_four.mul firstHatSum_contDiff_four)).contDiffAt
  · exact (firstSplineFactor_contDiff_four.mul firstSplineSum_contDiff_four).contDiffAt

set_option maxRecDepth 8192 in
set_option maxHeartbeats 8000000 in
private theorem correctionSymbol_fourth_enclosure :
    |iteratedDeriv 4 correctionSymbol 0 / 24 -
        (2096414380799 / 1000000000000 : ℝ)| ≤
      (1 / 1000000000000 : ℝ) := by
  have hhatFactor2 : iteratedDeriv 2 firstHatFactor 0 =
      -(2 * (1 / 100 : ℝ) ^ 2 / 3) := by
    exact scaled_sinc_pow_second_derivative_zero (1 / 100) 2
  have hhatFactor4 : iteratedDeriv 4 firstHatFactor 0 =
      2 * (1 / 100 : ℝ) ^ 4 / 5 + 2 * (2 - 1) * (1 / 100 : ℝ) ^ 4 / 3 := by
    exact scaled_sinc_pow_fourth_derivative_zero (1 / 100) 2
  have hsplineFactor2 : iteratedDeriv 2 firstSplineFactor 0 =
      -(19 * (1 / 2000 : ℝ) ^ 2 / 3) := by
    exact scaled_sinc_pow_second_derivative_zero (1 / 2000) 19
  have hsplineFactor4 : iteratedDeriv 4 firstSplineFactor 0 =
      19 * (1 / 2000 : ℝ) ^ 4 / 5 +
        19 * (19 - 1) * (1 / 2000 : ℝ) ^ 4 / 3 := by
    exact scaled_sinc_pow_fourth_derivative_zero (1 / 2000) 19
  rw [correctionSymbol_fourth_formula, firstHatSum_second, firstSplineSum_second,
    firstHatSum_fourth, firstSplineSum_fourth, hhatFactor2, hhatFactor4,
    hsplineFactor2, hsplineFactor4]
  norm_num (config := { maxSteps := 1000000 })
    [firstHatFactor, firstSplineFactor, firstHatSum, firstSplineSum,
      hatCoefficient, splineCoefficient, hatCenter, Fin.sum_univ_succ]

/-- The normalized fourth Taylor coefficient lies in its serialized
twelve-decimal enclosure by exact rational kernel computation. -/
theorem firstJet_four_enclosure :
    |exactJetCoefficient firstCenter 4 - firstJet 4| ≤ firstJetError 4 := by
  simpa [exactJetCoefficient, firstCenter, firstJet, firstJetError,
    Nat.factorial, div_eq_mul_inv, mul_comm] using correctionSymbol_fourth_enclosure

private theorem product_sixth_zero_of_even
    (f g : ℝ → ℝ) (hf : ContDiff ℝ 6 f) (hg : ContDiff ℝ 6 g)
    (hfeven : ∀ x, f (-x) = f x) (hgeven : ∀ x, g (-x) = g x) :
    iteratedDeriv 6 (fun x => f x * g x) 0 =
      iteratedDeriv 6 f 0 * g 0 +
        15 * iteratedDeriv 4 f 0 * iteratedDeriv 2 g 0 +
        15 * iteratedDeriv 2 f 0 * iteratedDeriv 4 g 0 +
        f 0 * iteratedDeriv 6 g 0 := by
  have hmul := iteratedDeriv_mul (n := 6) (x := (0 : ℝ)) hf.contDiffAt hg.contDiffAt
  have hf1 : iteratedDeriv 1 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f hfeven 0
  have hf3 : iteratedDeriv 3 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f hfeven 1
  have hf5 : iteratedDeriv 5 f 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even f hfeven 2
  have hg1 : iteratedDeriv 1 g 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even g hgeven 0
  have hg3 : iteratedDeriv 3 g 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even g hgeven 1
  have hg5 : iteratedDeriv 5 g 0 = 0 := by
    simpa using odd_iteratedDeriv_zero_of_even g hgeven 2
  change iteratedDeriv 6 (fun x => f x * g x) 0 = _ at hmul
  norm_num [Finset.sum_range_succ, hf1, hf3, hf5, hg1, hg3, hg5, Nat.choose] at hmul
  rw [hmul]
  ring

private theorem correctionSymbol_sixth_formula :
    iteratedDeriv 6 correctionSymbol 0 =
      (2 / 50 : ℝ) *
        (iteratedDeriv 6 firstHatFactor 0 * firstHatSum 0 +
          15 * iteratedDeriv 4 firstHatFactor 0 * iteratedDeriv 2 firstHatSum 0 +
          15 * iteratedDeriv 2 firstHatFactor 0 * iteratedDeriv 4 firstHatSum 0 +
          iteratedDeriv 6 firstHatSum 0) +
      (iteratedDeriv 6 firstSplineFactor 0 * firstSplineSum 0 +
        15 * iteratedDeriv 4 firstSplineFactor 0 * iteratedDeriv 2 firstSplineSum 0 +
        15 * iteratedDeriv 2 firstSplineFactor 0 * iteratedDeriv 4 firstSplineSum 0 +
        iteratedDeriv 6 firstSplineSum 0) := by
  have hh := product_sixth_zero_of_even firstHatFactor firstHatSum
    firstHatFactor_contDiff_six firstHatSum_contDiff_six
    firstHatFactor_even firstHatSum_even
  have hs := product_sixth_zero_of_even firstSplineFactor firstSplineSum
    firstSplineFactor_contDiff_six firstSplineSum_contDiff_six
    firstSplineFactor_even firstSplineSum_even
  have hh0 : firstHatFactor 0 = 1 := by simp [firstHatFactor]
  have hs0 : firstSplineFactor 0 = 1 := by simp [firstSplineFactor]
  have heq : correctionSymbol = fun t =>
      (2 / 50 : ℝ) * (firstHatFactor t * firstHatSum t) +
        firstSplineFactor t * firstSplineSum t := by
    funext t
    simp [correctionSymbol, firstHatFactor, firstHatSum, firstSplineFactor,
      firstSplineSum, div_eq_mul_inv, mul_comm, mul_left_comm, mul_assoc]
  rw [heq, iteratedDeriv_fun_add]
  · rw [iteratedDeriv_const_mul_field]
    rw [hh0] at hh
    rw [hs0] at hs
    norm_num at hh hs
    rw [hh, hs]
  · exact (contDiff_const.mul
      (firstHatFactor_contDiff_six.mul firstHatSum_contDiff_six)).contDiffAt
  · exact (firstSplineFactor_contDiff_six.mul firstSplineSum_contDiff_six).contDiffAt

set_option maxRecDepth 8192 in
set_option maxHeartbeats 8000000 in
private theorem correctionSymbol_sixth_enclosure :
    |iteratedDeriv 6 correctionSymbol 0 / 720 -
        (-190744442117 / 1000000000000 : ℝ)| ≤
      (1 / 1000000000000 : ℝ) := by
  have hhatFactor2 : iteratedDeriv 2 firstHatFactor 0 =
      -(2 * (1 / 100 : ℝ) ^ 2 / 3) := by
    exact scaled_sinc_pow_second_derivative_zero (1 / 100) 2
  have hhatFactor4 : iteratedDeriv 4 firstHatFactor 0 =
      2 * (1 / 100 : ℝ) ^ 4 / 5 + 2 * (2 - 1) * (1 / 100 : ℝ) ^ 4 / 3 := by
    exact scaled_sinc_pow_fourth_derivative_zero (1 / 100) 2
  have hhatFactor6 : iteratedDeriv 6 firstHatFactor 0 =
      -(2 * (1 / 100 : ℝ) ^ 6 / 7) - 2 * (2 - 1) * (1 / 100 : ℝ) ^ 6 -
        5 * 2 * (2 - 1) * (2 - 2) * (1 / 100 : ℝ) ^ 6 / 9 := by
    exact scaled_sinc_pow_sixth_derivative_zero (1 / 100) 2
  have hsplineFactor2 : iteratedDeriv 2 firstSplineFactor 0 =
      -(19 * (1 / 2000 : ℝ) ^ 2 / 3) := by
    exact scaled_sinc_pow_second_derivative_zero (1 / 2000) 19
  have hsplineFactor4 : iteratedDeriv 4 firstSplineFactor 0 =
      19 * (1 / 2000 : ℝ) ^ 4 / 5 +
        19 * (19 - 1) * (1 / 2000 : ℝ) ^ 4 / 3 := by
    exact scaled_sinc_pow_fourth_derivative_zero (1 / 2000) 19
  have hsplineFactor6 : iteratedDeriv 6 firstSplineFactor 0 =
      -(19 * (1 / 2000 : ℝ) ^ 6 / 7) -
        19 * (19 - 1) * (1 / 2000 : ℝ) ^ 6 -
        5 * 19 * (19 - 1) * (19 - 2) * (1 / 2000 : ℝ) ^ 6 / 9 := by
    exact scaled_sinc_pow_sixth_derivative_zero (1 / 2000) 19
  rw [correctionSymbol_sixth_formula, firstHatSum_second, firstSplineSum_second,
    firstHatSum_fourth, firstSplineSum_fourth, firstHatSum_sixth,
    firstSplineSum_sixth, hhatFactor2, hhatFactor4, hhatFactor6,
    hsplineFactor2, hsplineFactor4, hsplineFactor6]
  norm_num (config := { maxSteps := 1000000 })
    [firstHatFactor, firstSplineFactor, firstHatSum, firstSplineSum,
      hatCoefficient, splineCoefficient, hatCenter, Fin.sum_univ_succ]

/-- The normalized sixth Taylor coefficient lies in its serialized
twelve-decimal enclosure by exact rational kernel computation. -/
theorem firstJet_six_enclosure :
    |exactJetCoefficient firstCenter 6 - firstJet 6| ≤ firstJetError 6 := by
  simpa [exactJetCoefficient, firstCenter, firstJet, firstJetError,
    Nat.factorial, div_eq_mul_inv, mul_comm] using correctionSymbol_sixth_enclosure

private theorem deriv_zero_of_even
    (f : ℝ → ℝ) (hf : DifferentiableAt ℝ f 0)
    (heven : ∀ x, f (-x) = f x) : deriv f 0 = 0 := by
  have hneg : HasDerivAt Neg.neg (-1) (0 : ℝ) := hasDerivAt_neg 0
  have hfnegzero : HasDerivAt f (deriv f 0) (-0) := by
    simpa only [neg_zero] using hf.hasDerivAt
  have hcomp : HasDerivAt (f ∘ Neg.neg) (deriv f 0 * (-1)) 0 :=
    hfnegzero.comp 0 hneg
  have heq : (f ∘ Neg.neg) = f := by
    funext x
    exact heven x
  rw [heq] at hcomp
  have hu := hcomp.unique hf.hasDerivAt
  linarith

private theorem deriv_odd_of_even
    (f : ℝ → ℝ) (hf : Differentiable ℝ f)
    (heven : ∀ x, f (-x) = f x) : ∀ x, deriv f (-x) = -deriv f x := by
  intro x
  have hneg : HasDerivAt Neg.neg (-1) x := hasDerivAt_neg x
  have hfneg : HasDerivAt f (deriv f (-x)) (-x) := (hf (-x)).hasDerivAt
  have hcomp : HasDerivAt (f ∘ Neg.neg) (deriv f (-x) * (-1)) x :=
    hfneg.comp x hneg
  have heq : (f ∘ Neg.neg) = f := by
    funext y
    exact heven y
  rw [heq] at hcomp
  have hu := hcomp.unique (hf x).hasDerivAt
  linarith

private theorem deriv_even_of_odd
    (f : ℝ → ℝ) (hf : Differentiable ℝ f)
    (hodd : ∀ x, f (-x) = -f x) : ∀ x, deriv f (-x) = deriv f x := by
  intro x
  have hneg : HasDerivAt Neg.neg (-1) x := hasDerivAt_neg x
  have hfneg : HasDerivAt f (deriv f (-x)) (-x) := (hf (-x)).hasDerivAt
  have hcomp : HasDerivAt (f ∘ Neg.neg) (deriv f (-x) * (-1)) x :=
    hfneg.comp x hneg
  have heq : (f ∘ Neg.neg) = fun y => -f y := by
    funext y
    exact hodd y
  rw [heq] at hcomp
  have hu := hcomp.unique (hf x).hasDerivAt.neg
  linarith

/-- For an even C⁸ real function, the third, fifth, and seventh derivatives
at the origin vanish. -/
theorem odd_iteratedDerivs_zero_of_even
    (f : ℝ → ℝ) (hf : ContDiff ℝ 8 f)
    (heven : ∀ x, f (-x) = f x) :
    iteratedDeriv 3 f 0 = 0 ∧ iteratedDeriv 5 f 0 = 0 ∧
      iteratedDeriv 7 f 0 = 0 := by
  have hd (k : ℕ) (hk : k ≤ 7) : Differentiable ℝ (deriv^[k] f) := by
    have hsum : 8 - k + k = 8 := Nat.sub_add_cancel (by omega)
    have hc : ContDiff ℝ (8 - k : ℕ) (deriv^[k] f) := by
      apply ContDiff.iterate_deriv' (8 - k) k
      rw [hsum]
      exact hf
    apply hc.differentiable
    exact_mod_cast (show 8 - k ≠ 0 by omega)
  have h1 := deriv_odd_of_even f (by simpa using hd 0 (by omega)) heven
  have h2 := deriv_even_of_odd (deriv f) (by simpa using hd 1 (by omega)) h1
  have h3 := deriv_odd_of_even (deriv (deriv f))
    (by simpa [Function.iterate_succ_apply] using hd 2 (by omega)) h2
  have h4 := deriv_even_of_odd (deriv (deriv (deriv f)))
    (by simpa [Function.iterate_succ_apply] using hd 3 (by omega)) h3
  have h5 := deriv_odd_of_even (deriv (deriv (deriv (deriv f))))
    (by simpa [Function.iterate_succ_apply] using hd 4 (by omega)) h4
  have h6 := deriv_even_of_odd (deriv (deriv (deriv (deriv (deriv f)))))
    (by simpa [Function.iterate_succ_apply] using hd 5 (by omega)) h5
  have h7 := deriv_odd_of_even (deriv (deriv (deriv (deriv (deriv (deriv f))))))
    (by simpa [Function.iterate_succ_apply] using hd 6 (by omega)) h6
  have h3zero : deriv (deriv (deriv f)) 0 = 0 := by
    have h := h3 0
    norm_num at h
    linarith
  have h5zero : deriv (deriv (deriv (deriv (deriv f)))) 0 = 0 := by
    have h := h5 0
    norm_num at h
    linarith
  have h7zero : deriv (deriv (deriv (deriv (deriv (deriv (deriv f)))))) 0 = 0 := by
    have h := h7 0
    norm_num at h
    linarith
  simpa [iteratedDeriv_eq_iterate, Function.iterate_succ_apply] using
    And.intro h3zero (And.intro h5zero h7zero)

/-- Evenness and C⁸ regularity force the normalized first Taylor coefficient
at the origin to vanish exactly. -/
theorem firstJet_one_exact :
    exactJetCoefficient firstCenter 1 = firstJet 1 := by
  have hdiff : DifferentiableAt ℝ correctionSymbol 0 :=
    (correctionSymbol_contDiff_eight.differentiable (by norm_num)).differentiableAt
  have hderiv : deriv correctionSymbol 0 = 0 :=
    deriv_zero_of_even correctionSymbol hdiff correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, iteratedDeriv_one, hderiv]

/-- Evenness closes the normalized third Taylor coefficient exactly. -/
theorem firstJet_three_exact :
    exactJetCoefficient firstCenter 3 = firstJet 3 := by
  have h := odd_iteratedDerivs_zero_of_even correctionSymbol
    correctionSymbol_contDiff_eight correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, h.1]

/-- Evenness closes the normalized fifth Taylor coefficient exactly. -/
theorem firstJet_five_exact :
    exactJetCoefficient firstCenter 5 = firstJet 5 := by
  have h := odd_iteratedDerivs_zero_of_even correctionSymbol
    correctionSymbol_contDiff_eight correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, h.2.1]

/-- Evenness closes the normalized seventh Taylor coefficient exactly. -/
theorem firstJet_seven_exact :
    exactJetCoefficient firstCenter 7 = firstJet 7 := by
  have h := odd_iteratedDerivs_zero_of_even correctionSymbol
    correctionSymbol_contDiff_eight correctionSymbol_even_v1
  simp [exactJetCoefficient, firstCenter, firstJet, h.2.2]

/-- The first real serialized cell is sound: its symbol lower bound and all
eight Taylor coefficients are kernel-produced above. -/
theorem firstCell_sound_of_jet_enclosures : CellAnalyticSoundV1 firstCell := by
  apply cellAnalyticSound_of_jet_enclosures firstCell firstCenter firstRadius
    firstPolynomialLower firstJet firstJetError
  · norm_num [firstRadius]
  · exact firstCell_cover
  · intro k hk
    by_cases hk0 : k = 0
    · subst k
      rw [firstJet_zero_exact]
      norm_num [firstJetError]
    · by_cases hk1 : k = 1
      · subst k
        rw [firstJet_one_exact]
        norm_num [firstJetError]
      · by_cases hk2 : k = 2
        · subst k
          exact firstJet_two_enclosure
        · by_cases hk3 : k = 3
          · subst k
            rw [firstJet_three_exact]
            norm_num [firstJetError]
          · by_cases hk4 : k = 4
            · subst k
              exact firstJet_four_enclosure
            · by_cases hk5 : k = 5
              · subst k
                rw [firstJet_five_exact]
                norm_num [firstJetError]
              · by_cases hk6 : k = 6
                · subst k
                  exact firstJet_six_enclosure
                · by_cases hk7 : k = 7
                  · subst k
                    rw [firstJet_seven_exact]
                    norm_num [firstJetError]
                  · simp only [Finset.mem_range] at hk
                    omega
  · exact firstPolynomialLower_le
  · intro t hlo hhi
    have hw := firstCell_weight_le t hlo hhi
    have hs := firstCell_symbol_lower t
    have hwp : 0 ≤ (t ^ 2 + 1 / 4) ^ 2 := sq_nonneg _
    have hsMul := mul_le_mul_of_nonneg_left
      (sub_le_sub_right hs (1 / 16)) hwp
    have hsNonpos : (-3177232903 / 500000000 : ℝ) - 1 / 16 ≤ 0 := by
      norm_num
    have hweightSymbol :
        (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
            ((-3177232903 / 500000000 : ℝ) - 1 / 16) ≤
          (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) := by
      exact (mul_le_mul_of_nonpos_right hw hsNonpos).trans hsMul
    have hlowerNonneg : (0 : ℝ) ≤ lowerValue firstCell := by
      norm_num [firstCell, lowerValue]
    have hlowerWeight :
        (t ^ 2 + 1 / 4) ^ 2 * lowerValue firstCell ≤
          (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) * lowerValue firstCell :=
      mul_le_mul_of_nonneg_right hw hlowerNonneg
    have hground := firstGroundBudget
    have herror :
        firstPolynomialLower - 1001 / 1000000000 ≤
          firstPolynomialLower - firstTaylorError := by
      linarith [firstTaylorError_le]
    calc
      (t ^ 2 + 1 / 4) ^ 2 * lowerValue firstCell ≤
          (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) * lowerValue firstCell := hlowerWeight
      _ ≤ (((75 / 4096 : ℝ) ^ 2 + 1 / 4) ^ 2) *
            ((-3177232903 / 500000000 : ℝ) - 1 / 16) +
          (firstPolynomialLower - 1001 / 1000000000) := hground
      _ ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (firstPolynomialLower - firstTaylorError) :=
        add_le_add hweightSymbol herror
      _ = (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (firstPolynomialLower - ((serializedM8Q : ℝ) * firstRadius ^ 8 / 40320 +
            ∑ k ∈ Finset.range 8, firstJetError k * firstRadius ^ k)) := by
        rfl

end AEGIS.RHKreinFirstCellV1

#print axioms AEGIS.RHKreinFirstCellV1.firstCell_sound_of_jet_enclosures
#print axioms AEGIS.RHKreinFirstCellV1.firstCell_symbol_lower
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_zero_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_one_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_two_enclosure
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_four_enclosure
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_six_enclosure
#print axioms AEGIS.RHKreinFirstCellV1.odd_iteratedDerivs_zero_of_even
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_three_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_five_exact
#print axioms AEGIS.RHKreinFirstCellV1.firstJet_seven_exact
~~~~~~

## RHKreinCellAnalyticBridgeV1

Path: `source/RHKreinCellAnalyticBridgeV1.lean`

Original source lines: 1–103

Full file SHA256: `85a236ae4bab9088cd693f8cc794ffa9614df70373c0355e22392ca8ea722198`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinM8AnalyticV1
import AEGISOverlay.RHKreinFiniteCertificateAssemblyV1

/-!
# M8 Taylor bounds to analytic cell soundness

This file removes the division from the remaining cell obligation and then
connects the canonical degree-seven Taylor/jet bound to that weighted target.
It deliberately retains the actual symbol lower bound, jet enclosures, and
polynomial lower bound as premises. No serialized cell or RH claim is proved.

AUTHORITY_EFFECT = NONE.
-/

open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinCellAnalyticBridgeV1

open AEGIS.RHKreinCorrectionM8BoundV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinPrimeSymbolV1

/-- Cell soundness is exactly the division-free weighted inequality. -/
theorem cellAnalyticSound_iff_weighted (c : FiniteCellV1) :
    CellAnalyticSoundV1 c ↔
      ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
        (t ^ 2 + 1 / 4) ^ 2 * (lowerValue c : ℝ) ≤ correctedExpression t := by
  constructor
  · intro hcell t hlo hhi
    rw [correctedExpression_eq_weight_mul_normalizedExcess_v1]
    exact mul_le_mul_of_nonneg_left (hcell t hlo hhi) (weight_pos_v1 t).le
  · intro hweighted t hlo hhi
    have h := hweighted t hlo hhi
    rw [correctedExpression_eq_weight_mul_normalizedExcess_v1] at h
    exact le_of_mul_le_mul_left h (weight_pos_v1 t)

/-- A lower bound for the correction plus an exact weighted budget closes one cell. -/
theorem cellAnalyticSound_of_correction_lower
    (c : FiniteCellV1) (correctionLower : ℝ → ℝ)
    (hcorrection : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      correctionLower t ≤ correctionSymbol t)
    (hbudget : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue c : ℝ) ≤
        (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) + correctionLower t) :
    CellAnalyticSoundV1 c := by
  rw [cellAnalyticSound_iff_weighted]
  intro t hlo hhi
  apply (hbudget t hlo hhi).trans
  unfold correctedExpression
  exact add_le_add_right (hcorrection t hlo hhi) _

/-- The canonical M8 remainder and jet enclosure imply cell soundness once
the symbol and approximating polynomial satisfy the displayed exact budget. -/
theorem cellAnalyticSound_of_jet_enclosures
    (c : FiniteCellV1) (center radius polynomialLower : ℝ) (q e : ℕ → ℝ)
    (hradius : 0 ≤ radius)
    (hcover : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      |t - center| ≤ radius)
    (hjet : ∀ k ∈ Finset.range 8, |exactJetCoefficient center k - q k| ≤ e k)
    (hpolynomial : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      polynomialLower ≤ jetPolynomial7 q center t)
    (hbudget : ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
      (t ^ 2 + 1 / 4) ^ 2 * (lowerValue c : ℝ) ≤
        (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) +
          (polynomialLower - ((serializedM8Q : ℝ) * radius ^ 8 / 40320 +
            ∑ k ∈ Finset.range 8, e k * radius ^ k))) :
    CellAnalyticSoundV1 c := by
  apply cellAnalyticSound_of_correction_lower c
    (fun _ => polynomialLower - ((serializedM8Q : ℝ) * radius ^ 8 / 40320 +
      ∑ k ∈ Finset.range 8, e k * radius ^ k))
  · intro t hlo hhi
    exact correction_lower_of_jet_enclosures center t radius polynomialLower q e
      hradius (hcover t hlo hhi) hjet (hpolynomial t hlo hhi)
  · exact hbudget

end AEGIS.RHKreinCellAnalyticBridgeV1

#print axioms AEGIS.RHKreinCellAnalyticBridgeV1.cellAnalyticSound_iff_weighted
#print axioms AEGIS.RHKreinCellAnalyticBridgeV1.cellAnalyticSound_of_correction_lower
#print axioms AEGIS.RHKreinCellAnalyticBridgeV1.cellAnalyticSound_of_jet_enclosures
~~~~~~

## AEGISOverlay.RHKreinM8AnalyticV1

Path: `source/AEGISOverlay/RHKreinM8AnalyticV1.lean`

Original source lines: 1–154

Full file SHA256: `8cfd6200cda8cf1123d74899a93b8f52d2201421d9f5e0b3d380766998fe4103`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/81bcd289cd6df73901fc97168b00a3b04376eac9/research/rh/m8_kernel_v1/RHKreinM8AnalyticV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinCorrectionM8BoundV1
import AEGISOverlay.RHKreinCorrectionTaylorBridgeV1

/-!
# Canonical M8 and Taylor-jet error transport

The unchanged PR52 producer is rebound to the original monolithic symbol
via a declaration-free import adapter. The one-line compact-support repair
is explicit in the replay manifest. No coefficient or symbol is replaced.

The new cell lemmas include the cell center and expose, rather than assume
away, the remaining analytic Taylor-jet and polynomial-enclosure obligations.
No serialized cell, pointwise certificate or RH statement is concluded.
AUTHORITY_EFFECT = NONE.
-/

open Set MeasureTheory
open scoped BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinM8AnalyticV1

open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinM8CertificateV1
open AEGIS.RHKreinCorrectionM8BoundV1
open AEGIS.RHKreinFiniteIntervalKernelV1

/-- The reused proof now refers directly to the original monolithic definition. -/
theorem correctionSymbol_eighth_abs_le_serialized (t : ℝ) :
    |iteratedDeriv 8 correctionSymbol t| ≤ (serializedM8Q : ℝ) :=
  correctionSymbol_eighth_derivative_le_serialized t

private theorem budget_nonneg : (0 : ℝ) ≤ (serializedM8Q : ℝ) := by
  exact_mod_cast serializedM8Q_pos_v1.le

/-- Degree-seven remainder for every center and argument, including their equality. -/
theorem correction_taylor7_remainder (c x : ℝ) :
    |correctionSymbol x - centeredTaylorEval correctionSymbol 7 c x| ≤
      (serializedM8Q : ℝ) * |x - c| ^ 8 / 40320 := by
  by_cases hcx : c = x
  · subst x
    rw [centeredTaylorEval_self correctionSymbol 7 c
      (correctionSymbol_contDiff_eight.contDiffAt.of_le (by norm_num))]
    simp
  · exact centeredTaylor7_remainder_of_ne correctionSymbol c x
      (serializedM8Q : ℝ) hcx correctionSymbol_contDiff_eight
      correctionSymbol_eighth_abs_le_serialized

/-- A closed cell has a uniform remainder budget, without excluding its center. -/
theorem correction_taylor7_cell_remainder (c x r : ℝ)
    (_hr : 0 ≤ r) (hx : |x - c| ≤ r) :
    |correctionSymbol x - centeredTaylorEval correctionSymbol 7 c x| ≤
      (serializedM8Q : ℝ) * r ^ 8 / 40320 := by
  refine (correction_taylor7_remainder c x).trans ?_
  apply div_le_div_of_nonneg_right
  · exact mul_le_mul_of_nonneg_left
      (pow_le_pow_left₀ (abs_nonneg (x - c)) hx 8) budget_nonneg
  · norm_num

/-- Normalized ordinary derivative used by the degree-seven Taylor jet. -/
def exactJetCoefficient (c : ℝ) (k : ℕ) : ℝ :=
  (k.factorial : ℝ)⁻¹ * iteratedDeriv k correctionSymbol c

/-- A finite approximating polynomial; rational coefficients may be coerced here. -/
def jetPolynomial7 (q : ℕ → ℝ) (c x : ℝ) : ℝ :=
  ∑ k ∈ Finset.range 8, q k * (x - c) ^ k

theorem centeredTaylor_eq_exactJet (c x : ℝ) :
    centeredTaylorEval correctionSymbol 7 c x =
      jetPolynomial7 (exactJetCoefficient c) c x := by
  unfold centeredTaylorEval jetPolynomial7 exactJetCoefficient
  apply Finset.sum_congr rfl
  intro k _
  ring

/-- Coefficient enclosures give a uniform polynomial error over the cell. -/
theorem jetPolynomial7_error (c x r : ℝ) (q e : ℕ → ℝ)
    (hx : |x - c| ≤ r)
    (hjet : ∀ k ∈ Finset.range 8, |exactJetCoefficient c k - q k| ≤ e k) :
    |jetPolynomial7 (exactJetCoefficient c) c x - jetPolynomial7 q c x| ≤
      ∑ k ∈ Finset.range 8, e k * r ^ k := by
  unfold jetPolynomial7
  rw [← Finset.sum_sub_distrib]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro k hk
  rw [← sub_mul, abs_mul, abs_pow]
  have he0 : 0 ≤ e k := (abs_nonneg _).trans (hjet k hk)
  exact mul_le_mul (hjet k hk)
    (pow_le_pow_left₀ (abs_nonneg (x - c)) hx k) (by positivity) he0

/-- Combined analytic remainder and jet-rounding error for the actual correction. -/
theorem correction_jet7_error (c x r : ℝ) (q e : ℕ → ℝ)
    (hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hjet : ∀ k ∈ Finset.range 8, |exactJetCoefficient c k - q k| ≤ e k) :
    |correctionSymbol x - jetPolynomial7 q c x| ≤
      (serializedM8Q : ℝ) * r ^ 8 / 40320 +
        ∑ k ∈ Finset.range 8, e k * r ^ k := by
  calc
    |correctionSymbol x - jetPolynomial7 q c x| ≤
        |correctionSymbol x - centeredTaylorEval correctionSymbol 7 c x| +
          |centeredTaylorEval correctionSymbol 7 c x - jetPolynomial7 q c x| := by
      simpa only [sub_add_sub_cancel] using
        abs_add_le (correctionSymbol x - centeredTaylorEval correctionSymbol 7 c x)
          (centeredTaylorEval correctionSymbol 7 c x - jetPolynomial7 q c x)
    _ ≤ _ := add_le_add (correction_taylor7_cell_remainder c x r hr hx) (by
      rw [centeredTaylor_eq_exactJet]
      exact jetPolynomial7_error c x r q e hx hjet)

/-- The lower cell bound explicitly retains analytic jet-enclosure premises. -/
theorem correction_lower_of_jet_enclosures (c x r lo : ℝ) (q e : ℕ → ℝ)
    (hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hjet : ∀ k ∈ Finset.range 8, |exactJetCoefficient c k - q k| ≤ e k)
    (hpoly : lo ≤ jetPolynomial7 q c x) :
    lo - ((serializedM8Q : ℝ) * r ^ 8 / 40320 +
      ∑ k ∈ Finset.range 8, e k * r ^ k) ≤ correctionSymbol x := by
  have h := (abs_le.mp (correction_jet7_error c x r q e hr hx hjet)).1
  linarith

/-- Specialization with no jet-rounding error; still requires the actual polynomial bound. -/
theorem correction_lower_of_exact_taylor (c x r lo : ℝ)
    (hr : 0 ≤ r) (hx : |x - c| ≤ r)
    (hpoly : lo ≤ centeredTaylorEval correctionSymbol 7 c x) :
    lo - (serializedM8Q : ℝ) * r ^ 8 / 40320 ≤ correctionSymbol x := by
  have h := (abs_le.mp (correction_taylor7_cell_remainder c x r hr hx)).1
  linarith

end AEGIS.RHKreinM8AnalyticV1

#print axioms AEGIS.RHKreinM8AnalyticV1.correctionSymbol_eighth_abs_le_serialized
#print axioms AEGIS.RHKreinM8AnalyticV1.correction_taylor7_remainder
#print axioms AEGIS.RHKreinM8AnalyticV1.correction_taylor7_cell_remainder
#print axioms AEGIS.RHKreinM8AnalyticV1.centeredTaylor_eq_exactJet
#print axioms AEGIS.RHKreinM8AnalyticV1.jetPolynomial7_error
#print axioms AEGIS.RHKreinM8AnalyticV1.correction_jet7_error
#print axioms AEGIS.RHKreinM8AnalyticV1.correction_lower_of_jet_enclosures
#print axioms AEGIS.RHKreinM8AnalyticV1.correction_lower_of_exact_taylor
~~~~~~

## AEGISOverlay.RHKreinCorrectionTaylorBridgeV1

Path: `source/AEGISOverlay/RHKreinCorrectionTaylorBridgeV1.lean`

Original source lines: 1–80

Full file SHA256: `ec16ea498baa39e4ca2f58ba91b9f7423aa26eb63295512335bfca11491d8187`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinCorrectionTaylorBridgeV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinExplicitCorrectionV1
import AEGISOverlay.RHKreinFourierTaylorBoundV1

/-!
# Bind the genuine correction to the finite-interval Taylor kernel

This module is the missing analytic glue between the exact order-19 correction
and the generic finite-cell checker.  It proves that the actual correction has
all moments required through order eight, identifies its real angular Fourier
transform with `correctionSymbol`, and supplies the exact eighth-derivative
norm bound consumed by the Taylor remainder layer.

No finite-grid arithmetic and no RH conclusion is asserted here.
-/

open Complex MeasureTheory FourierTransform

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinCorrectionTaylorBridgeV1

open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFourierTaylorBoundV1

/-- The genuine compactly supported correction has all polynomial moments
required by the eighth-order Fourier Taylor argument. -/
theorem correction_moments_up_to_eight :
    HasMomentsUpToEight correction :=
  hasMomentsUpToEight_of_continuous_compact
    correction correction_continuous correction_hasCompactSupport

/-- The actual angular Fourier correction is C^8. -/
theorem correction_angular_contDiff_eight :
    ContDiff ℝ 8 (angularFourier correction) := by
  unfold angularFourier
  exact (fourier_contDiff_eight correction correction_moments_up_to_eight).comp
    (contDiff_const.mul contDiff_id)

/-- The analytic expression used by the rational certificate is exactly the
real part of the genuine angular Fourier transform. -/
theorem correctionSymbol_eq_re_angularFourier (t : ℝ) :
    correctionSymbol t = (angularFourier correction t).re := by
  unfold angularFourier
  rw [angularScale_mul]
  exact (correction_fourier_re t).symm

/-- Exact eighth-derivative norm bound for the genuine angular correction.
The right-hand side is a time-domain L1 moment and contains no interval
arithmetic premise. -/
theorem correction_angular_eighth_derivative_norm_le (t : ℝ) :
    ‖iteratedDeriv 8 (angularFourier correction) t‖ ≤
      |angularScale| ^ 8 *
        ∫ x : ℝ,
          ‖((-2 * Real.pi * Complex.I * (x : ℂ)) ^ 8) • correction x‖ := by
  exact angular_eighth_derivative_norm_le
    correction correction_moments_up_to_eight t

end AEGIS.RHKreinCorrectionTaylorBridgeV1

#print axioms AEGIS.RHKreinCorrectionTaylorBridgeV1.correction_moments_up_to_eight
#print axioms AEGIS.RHKreinCorrectionTaylorBridgeV1.correction_angular_contDiff_eight
#print axioms AEGIS.RHKreinCorrectionTaylorBridgeV1.correctionSymbol_eq_re_angularFourier
#print axioms AEGIS.RHKreinCorrectionTaylorBridgeV1.correction_angular_eighth_derivative_norm_le
~~~~~~

## AEGISOverlay.RHKreinFiniteCertificateAssemblyV1

Path: `source/AEGISOverlay/RHKreinFiniteCertificateAssemblyV1.lean`

Original source lines: 1–243

Full file SHA256: `29f0f09f44221b9da1a42c420d0bcf450bc7e1e75d0d3a82660f227c151d34ad`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinFiniteCertificateDataV1
import AEGISOverlay.RHKreinRationalCertificateV1
import Mathlib.Tactic

/-!
# Assembly boundary for the finite Krein certificate

The infinite tail is already unconditional in
`RHKreinRationalCertificateV1.corrected_symbol_tail_nonnegative`.
This file isolates the only remaining analytic obligation to the positive
finite interval `[0,300]`.

It also proves the evenness needed to reflect that finite interval to
`[-300,0]`; no numerical certificate is used for these symmetry facts.

The serialized 2199-cell payload is imported, but its stored lower bounds
are not promoted to analytic inequalities here.  That is the remaining
kernel-checker obligation.

AUTHORITY_EFFECT = NONE.
RH is not asserted here.
-/

open Complex
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFiniteCertificateAssemblyV1

open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinRationalCertificateV1

/-- The exact pointwise expression consumed by `PointwiseCertificate`. -/
def correctedExpression (t : ℝ) : ℝ :=
  (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) + correctionSymbol t

/-- The normalized excess used by the numerical 2199-cell certificate. -/
def normalizedExcess (t : ℝ) : ℝ :=
  symbol t + correctionSymbol t / (t ^ 2 + 1 / 4) ^ 2 - 1 / 16

/-- The polynomial weight is strictly positive at every real frequency. -/
theorem weight_pos_v1 (t : ℝ) :
    0 < (t ^ 2 + 1 / 4) ^ 2 := by
  have hbase : 0 < t ^ 2 + 1 / 4 := by
    nlinarith [sq_nonneg t]
  positivity

/-- The checker-normalized expression and the pointwise certificate are
exactly related by the positive polynomial weight. -/
theorem correctedExpression_eq_weight_mul_normalizedExcess_v1 (t : ℝ) :
    correctedExpression t =
      (t ^ 2 + 1 / 4) ^ 2 * normalizedExcess t := by
  unfold correctedExpression normalizedExcess
  have hw : (t ^ 2 + 1 / 4) ^ 2 ≠ 0 := (weight_pos_v1 t).ne'
  field_simp [hw]
  ring

/-- A positive normalized lower bound is sufficient for the actual pointwise
certificate at that frequency. -/
theorem correctedExpression_nonnegative_of_normalizedExcess_v1
    (t : ℝ) (h : 0 ≤ normalizedExcess t) :
    0 ≤ correctedExpression t := by
  rw [correctedExpression_eq_weight_mul_normalizedExcess_v1]
  exact mul_nonneg (weight_pos_v1 t).le h

/-- The real part of the quarter-line digamma is an even function of the
angular frequency.  This follows from the already-proved dependence on t^2. -/
theorem digamma_quarter_even_v1 (t : ℝ) :
    (Complex.digamma ((1 / 4 : ℂ) + ((-t : ℝ) : ℂ) * I / 2)).re =
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * I / 2)).re := by
  apply le_antisymm
  · exact digamma_quarter_mono_of_sq_le (-t) t (by nlinarith)
  · exact digamma_quarter_mono_of_sq_le t (-t) (by nlinarith)

/-- The full first-post-log2 Weil symbol is even. -/
theorem symbol_even_v1 (t : ℝ) :
    symbol (-t) = symbol t := by
  unfold symbol archSymbol
  rw [digamma_quarter_even_v1]
  have hc :
      Real.cos ((-t) * Real.log 2) =
        Real.cos (t * Real.log 2) := by
    rw [show (-t) * Real.log 2 = -(t * Real.log 2) by ring, Real.cos_neg]
  rw [hc]

/-- Every hat contribution in the explicit correction is even. -/
private theorem hat_sum_even_v1 (t : ℝ) :
    (∑ j : Fin 199,
      (hatCoefficient j : ℝ) * Real.cos ((-t) * hatCenter j)) =
    ∑ j : Fin 199,
      (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j) := by
  apply Finset.sum_congr rfl
  intro j _hj
  rw [show (-t) * hatCenter j = -(t * hatCenter j) by ring, Real.cos_neg]

/-- The five derivative columns have the parity encoded by the certificate:
odd powers are paired with sine and even powers with cosine, so the whole
spline correction is even. -/
private theorem spline_sum_even_v1 (t : ℝ) :
    (∑ j : Fin 5, (splineCoefficient j : ℝ) * (-t) ^ j.val *
      (if j.val % 2 = 0 then Real.cos ((-t) * (1619 / 2000))
       else Real.sin ((-t) * (1619 / 2000)))) =
    ∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
      (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
       else Real.sin (t * (1619 / 2000))) := by
  apply Finset.sum_congr rfl
  intro j _hj
  fin_cases j
  · norm_num [Real.cos_neg]
  · norm_num [Real.sin_neg]
  · norm_num [Real.cos_neg]
  · norm_num [Real.sin_neg]
    ring
  · norm_num [Real.cos_neg]

/-- The exact genuine-function correction symbol is even. -/
theorem correctionSymbol_even_v1 (t : ℝ) :
    correctionSymbol (-t) = correctionSymbol t := by
  unfold correctionSymbol
  have h100 : (-t) / 100 = -(t / 100) := by ring
  have h2000 : (-t) / 2000 = -(t / 2000) := by ring
  rw [h100, Real.sinc_neg, h2000, Real.sinc_neg,
    hat_sum_even_v1, spline_sum_even_v1]

/-- Hence the complete corrected expression is orientation-free. -/
theorem correctedExpression_even_v1 (t : ℝ) :
    correctedExpression (-t) = correctedExpression t := by
  unfold correctedExpression
  rw [symbol_even_v1, correctionSymbol_even_v1]
  ring

/-- Analytic meaning of one serialized cell.  The stored dyadic rational
must be a genuine lower bound for the normalized excess throughout that
cell.  This is exactly the assertion the finite checker must kernel-justify. -/
def CellAnalyticSoundV1 (c : FiniteCellV1) : Prop :=
  ∀ t : ℝ, (c.lo : ℝ) ≤ t → t ≤ (c.hi : ℝ) →
    (lowerValue c : ℝ) ≤ normalizedExcess t

/-- All 2199 serialized cells have their intended analytic meaning. -/
def AllCellsAnalyticSoundV1 : Prop :=
  ∀ c, c ∈ finiteCells → CellAnalyticSoundV1 c

/-- The only remaining analytic theorem needed after the already-closed tail. -/
def FiniteIntervalCertificateV1 : Prop :=
  ∀ t : ℝ, 0 ≤ t → t ≤ 300 → 0 ≤ correctedExpression t


/-- Exact reduction of the positive finite interval to the 2199 cell
soundness obligations.  Coverage and positivity of every stored dyadic lower
endpoint come from the kernel-checked payload theorem, not from floating
point output. -/
theorem finiteIntervalCertificate_of_allCellsAnalyticSound_v1
    (hcells : AllCellsAnalyticSoundV1) :
    FiniteIntervalCertificateV1 := by
  intro t ht0 ht300
  obtain ⟨c, hc, hlo, hhi, hlower⟩ :=
    finiteCells_cover_zero_three_hundred_v1 ht0 ht300
  have hsound := hcells c hc t hlo hhi
  have hlower0q : (0 : ℚ) < lowerValue c := by
    exact (by norm_num : (0 : ℚ) < 1 / 100000).trans hlower
  have hlower0 : (0 : ℝ) < (lowerValue c : ℝ) := by
    exact_mod_cast hlower0q
  apply correctedExpression_nonnegative_of_normalizedExcess_v1
  exact hlower0.le.trans hsound

/-- Once the positive finite interval is kernel-certified, evenness plus the
existing tail theorem gives the full pointwise certificate consumed by the
actual Weil quadratic margin theorem. -/
theorem pointwiseCertificate_of_finite_interval_v1
    (hfinite : FiniteIntervalCertificateV1) :
    PointwiseCertificate := by
  intro t
  change 0 ≤ correctedExpression t
  by_cases htail : 300 ≤ |t|
  · unfold correctedExpression
    exact corrected_symbol_tail_nonnegative t htail
  · have habs300 : |t| ≤ 300 := (lt_of_not_ge htail).le
    have hfiniteAbs := hfinite |t| (abs_nonneg t) habs300
    have heven : correctedExpression |t| = correctedExpression t := by
      by_cases ht : 0 ≤ t
      · rw [abs_of_nonneg ht]
      · have htn : t ≤ 0 := le_of_not_ge ht
        rw [abs_of_nonpos htn, correctedExpression_even_v1]
    rw [← heven]
    exact hfiniteAbs

/-- Therefore the entire pointwise order-19 Krein certificate reduces to
one exact statement: analytic soundness of the 2199 serialized cells. -/
theorem pointwiseCertificate_of_allCellsAnalyticSound_v1
    (hcells : AllCellsAnalyticSoundV1) :
    PointwiseCertificate :=
  pointwiseCertificate_of_finite_interval_v1
    (finiteIntervalCertificate_of_allCellsAnalyticSound_v1 hcells)

/-- Once the 2199 analytic cell obligations are discharged, the existing
genuine correction theorem yields the actual repository zero-quadratic
margin on every moment-zero packet of logarithmic half-width at most 2/5. -/
theorem actual_zero_quadratic_margin_of_allCellsAnalyticSound_v1
    (hcells : AllCellsAnalyticSoundV1)
    (g : WeilCompactSmoothGV1) (r a : ℝ)
    (hr0 : 0 ≤ r) (hr : r ≤ 2 / 5)
    (hw : AEGIS.RHDyadicDiagonalV13.HalfWidthAt g r a)
    (hm : WeilMomentConditionsV1 g) :
    (1 / 16) * AEGIS.WeilDisjointEnergyV2.energy g.1 ≤
      (∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho).re := by
  exact actual_zero_quadratic_margin
    (pointwiseCertificate_of_allCellsAnalyticSound_v1 hcells)
    g r a hr0 hr hw hm

end AEGIS.RHKreinFiniteCertificateAssemblyV1

#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.correctedExpression_eq_weight_mul_normalizedExcess_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.digamma_quarter_even_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.symbol_even_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.correctionSymbol_even_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.correctedExpression_even_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.finiteIntervalCertificate_of_allCellsAnalyticSound_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.pointwiseCertificate_of_finite_interval_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.pointwiseCertificate_of_allCellsAnalyticSound_v1
#print axioms AEGIS.RHKreinFiniteCertificateAssemblyV1.actual_zero_quadratic_margin_of_allCellsAnalyticSound_v1
~~~~~~

## AEGISOverlay.RHKreinFiniteCertificateDataV1

Path: `source/AEGISOverlay/RHKreinFiniteCertificateDataV1.lean`

Original source lines: 1–2333

Full file SHA256: `002839dc8f1b1506715be3f10e06526c5d1ae02e0a90cd3e9268026d82f31df5`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinFiniteCertificateDataV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import Mathlib.Tactic

/-!
# Exact payload for the 2199-cell Krein finite certificate

Generated mechanically from
`research/rh/krein_order19_v1/certificate.json`.

This module deliberately proves only exact combinatorial/rational properties
of the serialized payload:

* exactly 2199 cells;
* cells form one contiguous chain from 0 to 300;
* every cell has positive width;
* every stored dyadic lower endpoint exceeds 1/100000.

It does NOT treat the stored lower endpoint as a theorem about the analytic
Krein expression.  That soundness edge is discharged separately by the
kernel-side Taylor/trigonometric/digamma checker.

AUTHORITY_EFFECT = NONE.
RH is not asserted here.
-/

set_option autoImplicit false

namespace AEGIS.RHKreinFiniteCertificateDataV1

structure FiniteCellV1 where
  lo : ℚ
  hi : ℚ
  lower64 : ℤ
deriving DecidableEq, Repr

def lowerValue (c : FiniteCellV1) : ℚ :=
  (c.lower64 : ℚ) / (18446744073709551616 : ℚ)

set_option maxRecDepth 16384 in
def finiteCells : List FiniteCellV1 := [
  ⟨0, 75/4096, 114511397055347687⟩,
  ⟨75/4096, 225/8192, 123598475210567660⟩,
  ⟨225/8192, 525/16384, 289287866131689861⟩,
  ⟨525/16384, 75/2048, 253868912037845735⟩,
  ⟨75/2048, 675/16384, 219222047756099148⟩,
  ⟨675/16384, 375/8192, 185364967441091393⟩,
  ⟨375/8192, 825/16384, 152314342263794501⟩,
  ⟨825/16384, 225/4096, 120083874866890649⟩,
  ⟨225/4096, 975/16384, 88686499373536390⟩,
  ⟨975/16384, 525/8192, 58131795665423643⟩,
  ⟨525/8192, 1125/16384, 28428513002117230⟩,
  ⟨1125/16384, 2325/32768, 307663815114748177⟩,
  ⟨2325/32768, 75/1024, 302493041933652027⟩,
  ⟨75/1024, 2475/32768, 297477874163111897⟩,
  ⟨2475/32768, 1275/16384, 292616690003685633⟩,
  ⟨1275/16384, 2625/32768, 287908278547361549⟩,
  ⟨2625/32768, 675/8192, 283351440368629406⟩,
  ⟨675/8192, 2775/32768, 278944588608926582⟩,
  ⟨2775/32768, 1425/16384, 274686448978948724⟩,
  ⟨1425/16384, 2925/32768, 270575523813757139⟩,
  ⟨2925/32768, 375/4096, 266609968360839334⟩,
  ⟨375/4096, 3075/32768, 262788154433852343⟩,
  ⟨3075/32768, 1575/16384, 259108547028894708⟩,
  ⟨1575/16384, 3225/32768, 255569169304436931⟩,
  ⟨3225/32768, 825/8192, 252168165592266391⟩,
  ⟨825/8192, 3375/32768, 248903403525943915⟩,
  ⟨3375/32768, 1725/16384, 245773452272240636⟩,
  ⟨1725/16384, 3525/32768, 242775671412693504⟩,
  ⟨3525/32768, 225/2048, 239908012363502094⟩,
  ⟨225/2048, 3675/32768, 237168622982317581⟩,
  ⟨3675/32768, 1875/16384, 234554897099979022⟩,
  ⟨1875/16384, 3825/32768, 232065553114413919⟩,
  ⟨3825/32768, 975/8192, 229696938024554474⟩,
  ⟨975/8192, 3975/32768, 227447851079630364⟩,
  ⟨3975/32768, 2025/16384, 225315299677041506⟩,
  ⟨2025/16384, 4125/32768, 223297263559133741⟩,
  ⟨4125/32768, 525/4096, 221391057179244079⟩,
  ⟨525/4096, 4275/32768, 219594310349145174⟩,
  ⟨4275/32768, 2175/16384, 217904705980674126⟩,
  ⟨2175/16384, 4425/32768, 216319720450656937⟩,
  ⟨4425/32768, 1125/8192, 214836501332573689⟩,
  ⟨1125/8192, 4575/32768, 213453254189308143⟩,
  ⟨4575/32768, 2325/16384, 212166237668182264⟩,
  ⟨2325/16384, 4725/32768, 210974032556049135⟩,
  ⟨4725/32768, 75/512, 209873576731301215⟩,
  ⟨75/512, 4875/32768, 208862234958200187⟩,
  ⟨4875/32768, 2475/16384, 207937542286565080⟩,
  ⟨2475/16384, 5025/32768, 207096940867059249⟩,
  ⟨5025/32768, 1275/8192, 206337931616902147⟩,
  ⟨1275/8192, 5175/32768, 205657538531780289⟩,
  ⟨5175/32768, 2625/16384, 205053281974692055⟩,
  ⟨2625/16384, 5325/32768, 204522783306025871⟩,
  ⟨5325/32768, 675/4096, 204063224913088489⟩,
  ⟨675/4096, 5475/32768, 203672737953876096⟩,
  ⟨5475/32768, 2775/16384, 203347530371081182⟩,
  ⟨2775/16384, 5625/32768, 203085745454479620⟩,
  ⟨5625/32768, 1425/8192, 202885277712983559⟩,
  ⟨1425/8192, 5775/32768, 202742819577790372⟩,
  ⟨5775/32768, 2925/16384, 202656211253134868⟩,
  ⟨2925/16384, 5925/32768, 202622942052230905⟩,
  ⟨5925/32768, 375/2048, 202640433915907016⟩,
  ⟨375/2048, 6075/32768, 202706602797442519⟩,
  ⟨6075/32768, 3075/16384, 202818633640982085⟩,
  ⟨3075/16384, 6225/32768, 202974365385807403⟩,
  ⟨6225/32768, 1575/8192, 203171338190949327⟩,
  ⟨1575/8192, 6375/32768, 203407353852207645⟩,
  ⟨6375/32768, 3225/16384, 203679934847609182⟩,
  ⟨3225/16384, 6525/32768, 203986751109559077⟩,
  ⟨6525/32768, 825/4096, 204325895682642209⟩,
  ⟨825/4096, 6675/32768, 204694938744844546⟩,
  ⟨6675/32768, 3375/16384, 205091348782318211⟩,
  ⟨3375/16384, 6825/32768, 205513594258709797⟩,
  ⟨6825/32768, 1725/8192, 205959372766525143⟩,
  ⟨1725/8192, 6975/32768, 206426576887316243⟩,
  ⟨6975/32768, 3525/16384, 206912889697933234⟩,
  ⟨3525/16384, 7125/32768, 207417308457712074⟩,
  ⟨7125/32768, 225/1024, 207936709496838158⟩,
  ⟨225/1024, 7275/32768, 208469844213246254⟩,
  ⟨7275/32768, 3675/16384, 209014325425067749⟩,
  ⟨3675/16384, 7425/32768, 209568826482719625⟩,
  ⟨7425/32768, 1875/8192, 210131855962677516⟩,
  ⟨1875/8192, 7575/32768, 210700383930592001⟩,
  ⟨7575/32768, 3825/16384, 211274115833790473⟩,
  ⟨3825/16384, 7725/32768, 211850543774431577⟩,
  ⟨7725/32768, 975/4096, 212428662630397270⟩,
  ⟨975/4096, 7875/32768, 213006096376038759⟩,
  ⟨7875/32768, 3975/16384, 213582115780054652⟩,
  ⟨3975/16384, 8025/32768, 214154764240363700⟩,
  ⟨8025/32768, 2025/8192, 214722647714436064⟩,
  ⟨2025/8192, 8175/32768, 215284386877587421⟩,
  ⟨8175/32768, 4125/16384, 215838895829308875⟩,
  ⟨4125/16384, 8325/32768, 216384427913995796⟩,
  ⟨8325/32768, 525/2048, 216920358282805602⟩,
  ⟨525/2048, 8475/32768, 217444583217994003⟩,
  ⟨8475/32768, 4275/16384, 217956679862225213⟩,
  ⟨4275/16384, 8625/32768, 218454886347331412⟩,
  ⟨8625/32768, 2175/8192, 218938853072717419⟩,
  ⟨2175/8192, 8775/32768, 219406759851481731⟩,
  ⟨8775/32768, 4425/16384, 219858062479877576⟩,
  ⟨4425/16384, 8925/32768, 220291852870243823⟩,
  ⟨8925/32768, 1125/4096, 220706715782871654⟩,
  ⟨1125/4096, 9075/32768, 221102109004361428⟩,
  ⟨9075/32768, 4575/16384, 221477540018715962⟩,
  ⟨4575/16384, 9225/32768, 221831601833321014⟩,
  ⟨9225/32768, 2325/8192, 222163902358418254⟩,
  ⟨2325/8192, 9375/32768, 222473549046241335⟩,
  ⟨9375/32768, 4725/16384, 222759840971068184⟩,
  ⟨4725/16384, 9525/32768, 223022128591294673⟩,
  ⟨9525/32768, 75/256, 223259814007925568⟩,
  ⟨75/256, 9675/32768, 223472491723746779⟩,
  ⟨9675/32768, 4875/16384, 223659806853228096⟩,
  ⟨4875/16384, 9825/32768, 223820635650385303⟩,
  ⟨9825/32768, 2475/8192, 223955276662129682⟩,
  ⟨2475/8192, 9975/32768, 224062847482025645⟩,
  ⟨9975/32768, 5025/16384, 224142787354678016⟩,
  ⟨5025/16384, 10125/32768, 224195139875615298⟩,
  ⟨10125/32768, 1275/4096, 224219445065866412⟩,
  ⟨1275/4096, 10275/32768, 224215567277678561⟩,
  ⟨10275/32768, 5175/16384, 224183005781761755⟩,
  ⟨5175/16384, 10425/32768, 224121443261804207⟩,
  ⟨10425/32768, 2625/8192, 224031157830755591⟩,
  ⟨2625/8192, 10575/32768, 223911781375790321⟩,
  ⟨10575/32768, 5325/16384, 223762988386173047⟩,
  ⟨5325/16384, 10725/32768, 223584769142096229⟩,
  ⟨10725/32768, 675/2048, 223377288342208260⟩,
  ⟨675/2048, 10875/32768, 223140333468656451⟩,
  ⟨10875/32768, 5475/16384, 222874003234631850⟩,
  ⟨5475/16384, 11025/32768, 222578014040733810⟩,
  ⟨11025/32768, 2775/8192, 222252664206902041⟩,
  ⟨2775/8192, 11175/32768, 221897729025776143⟩,
  ⟨11175/32768, 5625/16384, 221513696498681320⟩,
  ⟨5625/16384, 11325/32768, 221100802903708224⟩,
  ⟨11325/32768, 1425/4096, 220658342100452521⟩,
  ⟨1425/4096, 11475/32768, 220187278674309979⟩,
  ⟨11475/32768, 5775/16384, 219687490163438877⟩,
  ⟨5775/16384, 11625/32768, 219159143134380977⟩,
  ⟨11625/32768, 2925/8192, 218602552006267968⟩,
  ⟨2925/8192, 11775/32768, 218017764019851922⟩,
  ⟨11775/32768, 5925/16384, 217405106231269945⟩,
  ⟨5925/16384, 11925/32768, 216765046339884238⟩,
  ⟨11925/32768, 375/1024, 216098049179186461⟩,
  ⟨375/1024, 12075/32768, 215403478612156427⟩,
  ⟨12075/32768, 6075/16384, 214682613969035672⟩,
  ⟨6075/16384, 12225/32768, 213935626653844990⟩,
  ⟨12225/32768, 3075/8192, 213162540302222608⟩,
  ⟨3075/8192, 12375/32768, 212364044882195055⟩,
  ⟨12375/32768, 6225/16384, 211540131073344130⟩,
  ⟨6225/16384, 12525/32768, 210691587218497494⟩,
  ⟨12525/32768, 1575/4096, 209818630437701490⟩,
  ⟨1575/4096, 12675/32768, 208921861301019394⟩,
  ⟨12675/32768, 6375/16384, 208001573512714404⟩,
  ⟨6375/16384, 12825/32768, 207058029949068754⟩,
  ⟨12825/32768, 3225/8192, 206091865385894027⟩,
  ⟨3225/8192, 12975/32768, 205103674246240666⟩,
  ⟨12975/32768, 6525/16384, 204093460901392109⟩,
  ⟨6525/16384, 13125/32768, 203062554203505131⟩,
  ⟨13125/32768, 825/2048, 202010447510458657⟩,
  ⟨825/2048, 13275/32768, 200938367848595845⟩,
  ⟨13275/32768, 6675/16384, 199846387591734256⟩,
  ⟨6675/16384, 13425/32768, 198735203697233096⟩,
  ⟨13425/32768, 3375/8192, 197605318489788331⟩,
  ⟨3375/8192, 13575/32768, 196457162121311914⟩,
  ⟨13575/32768, 6825/16384, 195291377171895155⟩,
  ⟨6825/16384, 13725/32768, 194108391367399777⟩,
  ⟨13725/32768, 1725/4096, 192908834267055950⟩,
  ⟨1725/4096, 13875/32768, 191693120737598355⟩,
  ⟨13875/32768, 6975/16384, 190461995437906516⟩,
  ⟨6975/16384, 14025/32768, 189215705074336076⟩,
  ⟨14025/32768, 3525/8192, 187954823158653339⟩,
  ⟨3525/8192, 14175/32768, 186680107339693367⟩,
  ⟨14175/32768, 7125/16384, 185392218238476022⟩,
  ⟨7125/16384, 14325/32768, 184091310525233377⟩,
  ⟨14325/32768, 225/512, 182778125105702608⟩,
  ⟨225/512, 14475/32768, 181453162549890803⟩,
  ⟨14475/32768, 7275/16384, 180117092417686597⟩,
  ⟨7275/16384, 14625/32768, 178770337971623522⟩,
  ⟨14625/32768, 3675/8192, 177413486618763763⟩,
  ⟨3675/8192, 14775/32768, 176047008885251498⟩,
  ⟨14775/32768, 7425/16384, 174671808490209317⟩,
  ⟨7425/16384, 14925/32768, 173287844003110125⟩,
  ⟨14925/32768, 1875/4096, 171896188646961932⟩,
  ⟨1875/4096, 15075/32768, 170496963736673464⟩,
  ⟨15075/32768, 7575/16384, 169091122581278446⟩,
  ⟨7575/16384, 15225/32768, 167679075463811680⟩,
  ⟨15225/32768, 3825/8192, 166260961767820745⟩,
  ⟨3825/8192, 15375/32768, 164837882056142720⟩,
  ⟨15375/32768, 7725/16384, 163409833789811408⟩,
  ⟨7725/16384, 15525/32768, 161977774538441549⟩,
  ⟨15525/32768, 975/2048, 160542099994940401⟩,
  ⟨975/2048, 15675/32768, 159103336074465903⟩,
  ⟨15675/32768, 7875/16384, 157661993523645967⟩,
  ⟨7875/16384, 15825/32768, 156218295857458577⟩,
  ⟨15825/32768, 3975/8192, 154773269903895004⟩,
  ⟨3975/8192, 15975/32768, 153327098336602293⟩,
  ⟨15975/32768, 8025/16384, 151880215647736977⟩,
  ⟨8025/16384, 16125/32768, 150433305712899100⟩,
  ⟨16125/32768, 2025/4096, 148986750704156308⟩,
  ⟨2025/4096, 16275/32768, 147541036737295767⟩,
  ⟨16275/32768, 8175/16384, 146096759043712698⟩,
  ⟨8175/16384, 16425/32768, 144654063458307480⟩,
  ⟨16425/32768, 4125/8192, 143213744721479562⟩,
  ⟨4125/8192, 16575/32768, 141776284301116337⟩,
  ⟨16575/32768, 8325/16384, 140341710731357911⟩,
  ⟨8325/16384, 16725/32768, 138910968589152600⟩,
  ⟨16725/32768, 525/1024, 137484271360596858⟩,
  ⟨525/1024, 16875/32768, 136062058161641122⟩,
  ⟨16875/32768, 8475/16384, 134644716759925840⟩,
  ⟨8475/16384, 17025/32768, 133232997042973575⟩,
  ⟨17025/32768, 4275/8192, 131826768806756414⟩,
  ⟨4275/8192, 17175/32768, 130426807526445860⟩,
  ⟨17175/32768, 8625/16384, 129033417987552786⟩,
  ⟨8625/16384, 17325/32768, 127647119531357714⟩,
  ⟨17325/32768, 2175/4096, 126267956940616592⟩,
  ⟨2175/4096, 17475/32768, 124896735500332043⟩,
  ⟨17475/32768, 8775/16384, 123533644747920745⟩,
  ⟨8775/16384, 17625/32768, 122179081276009437⟩,
  ⟨17625/32768, 4425/8192, 120833234613837635⟩,
  ⟨4425/8192, 17775/32768, 119496773723031367⟩,
  ⟨17775/32768, 8925/16384, 118169742520820414⟩,
  ⟨8925/16384, 17925/32768, 116852798336517525⟩,
  ⟨17925/32768, 1125/2048, 115545973273997785⟩,
  ⟨1125/2048, 18075/32768, 114249631404384818⟩,
  ⟨18075/32768, 9075/16384, 112964471430201746⟩,
  ⟨9075/16384, 18225/32768, 111690421275650970⟩,
  ⟨18225/32768, 4575/8192, 110427602878630717⟩,
  ⟨4575/8192, 18375/32768, 109177014615868850⟩,
  ⟨18375/32768, 9225/16384, 107938468197177241⟩,
  ⟨9225/16384, 18525/32768, 106712239659406603⟩,
  ⟨18525/32768, 2325/4096, 105498789799083000⟩,
  ⟨2325/4096, 18675/32768, 104298351487208871⟩,
  ⟨18675/32768, 9375/16384, 103111203131064385⟩,
  ⟨9375/16384, 18825/32768, 101937391332077761⟩,
  ⟨18825/32768, 4725/8192, 100777283571539355⟩,
  ⟨4725/8192, 18975/32768, 99631285550246169⟩,
  ⟨18975/32768, 9525/16384, 98499500570924799⟩,
  ⟨9525/16384, 19125/32768, 97382276929704691⟩,
  ⟨19125/32768, 75/128, 96279863052346016⟩,
  ⟨75/128, 19275/32768, 95192269886655255⟩,
  ⟨19275/32768, 9675/16384, 94119883864072421⟩,
  ⟨9675/16384, 19425/32768, 93062649660571692⟩,
  ⟨19425/32768, 4875/8192, 92021088005410920⟩,
  ⟨4875/8192, 19575/32768, 90995275550731063⟩,
  ⟨19575/32768, 9825/16384, 89985454703727497⟩,
  ⟨9825/16384, 19725/32768, 88991689998331793⟩,
  ⟨19725/32768, 2475/4096, 88014212757311338⟩,
  ⟨2475/4096, 19875/32768, 87053214946444556⟩,
  ⟨19875/32768, 9975/16384, 86108841692291660⟩,
  ⟨9975/16384, 20025/32768, 85181127986433573⟩,
  ⟨20025/32768, 5025/8192, 84270547443266859⟩,
  ⟨5025/8192, 20175/32768, 83377043344267258⟩,
  ⟨20175/32768, 10125/16384, 82500720780950036⟩,
  ⟨10125/16384, 20325/32768, 81641636874641522⟩,
  ⟨20325/32768, 1275/2048, 80800143455958804⟩,
  ⟨1275/2048, 20475/32768, 79976269838446772⟩,
  ⟨20475/32768, 10275/16384, 79170061778298452⟩,
  ⟨10275/16384, 20625/32768, 78381722347450612⟩,
  ⟨20625/32768, 5175/8192, 77611195553128718⟩,
  ⟨5175/8192, 20775/32768, 76858784525789038⟩,
  ⟨20775/32768, 10425/16384, 76124395872286299⟩,
  ⟨10425/16384, 20925/32768, 75408363520899258⟩,
  ⟨20925/32768, 2625/4096, 74710484803489092⟩,
  ⟨2625/4096, 21075/32768, 74031050493356508⟩,
  ⟨21075/32768, 10575/16384, 73370021581424989⟩,
  ⟨10575/16384, 21225/32768, 72727437650860474⟩,
  ⟨21225/32768, 5325/8192, 72103487039216121⟩,
  ⟨5325/8192, 21375/32768, 71498162015380035⟩,
  ⟨21375/32768, 10725/16384, 70911326825944324⟩,
  ⟨10725/16384, 21525/32768, 70343473488669260⟩,
  ⟨21525/32768, 675/1024, 69794207710941500⟩,
  ⟨675/1024, 21675/32768, 69263762238206534⟩,
  ⟨21675/32768, 10875/16384, 68752101277346896⟩,
  ⟨10875/16384, 21825/32768, 68259332215139496⟩,
  ⟨21825/32768, 5475/8192, 67785363047265427⟩,
  ⟨5475/8192, 21975/32768, 67330244331674416⟩,
  ⟨21975/32768, 11025/16384, 66894098301908409⟩,
  ⟨11025/16384, 22125/32768, 66476915923660760⟩,
  ⟨22125/32768, 2775/4096, 66078483887263857⟩,
  ⟨2775/4096, 22275/32768, 65699210871977277⟩,
  ⟨22275/32768, 11175/16384, 65338615213321550⟩,
  ⟨11175/16384, 22425/32768, 64996903348756981⟩,
  ⟨22425/32768, 5625/8192, 64674078132596236⟩,
  ⟨5625/8192, 22575/32768, 64370142916530192⟩,
  ⟨22575/32768, 11325/16384, 64085032911561022⟩,
  ⟨11325/16384, 22725/32768, 63818683463645994⟩,
  ⟨22725/32768, 1425/2048, 63571372681797912⟩,
  ⟨1425/2048, 22875/32768, 63342623652732469⟩,
  ⟨22875/32768, 11475/16384, 63132712637894220⟩,
  ⟨11475/16384, 23025/32768, 62941227712498843⟩,
  ⟨23025/32768, 5775/8192, 62768442766192234⟩,
  ⟨5775/8192, 23175/32768, 62614353978159763⟩,
  ⟨23175/32768, 11625/16384, 62478816887763263⟩,
  ⟨11625/16384, 23325/32768, 62361753268394981⟩,
  ⟨23325/32768, 2925/4096, 62262876437898629⟩,
  ⟨2925/4096, 23475/32768, 62182718490567017⟩,
  ⟨23475/32768, 11775/16384, 62120640860876430⟩,
  ⟨11775/16384, 23625/32768, 62076825257413225⟩,
  ⟨23625/32768, 5925/8192, 62051309668329223⟩,
  ⟨5925/8192, 23775/32768, 62043716939142756⟩,
  ⟨23775/32768, 11925/16384, 62054144611006907⟩,
  ⟨11925/16384, 23925/32768, 62082477440764944⟩,
  ⟨23925/32768, 375/512, 62128940101151811⟩,
  ⟨375/512, 24075/32768, 62192856740304214⟩,
  ⟨24075/32768, 12075/16384, 62274782098651001⟩,
  ⟨12075/16384, 24225/32768, 62374095537523474⟩,
  ⟨24225/32768, 6075/8192, 62490995806348140⟩,
  ⟨6075/8192, 24375/32768, 62625191376888505⟩,
  ⟨24375/32768, 12225/16384, 62776797861190983⟩,
  ⟨12225/16384, 24525/32768, 62945577579356175⟩,
  ⟨24525/32768, 3075/4096, 63131562650717460⟩,
  ⟨3075/4096, 24675/32768, 63334361684486394⟩,
  ⟨24675/32768, 12375/16384, 63554196275223738⟩,
  ⟨12375/16384, 24825/32768, 63790934439571817⟩,
  ⟨24825/32768, 6225/8192, 64044230550451773⟩,
  ⟨6225/8192, 24975/32768, 64314210738413906⟩,
  ⟨24975/32768, 12525/16384, 64600442459811979⟩,
  ⟨12525/16384, 25125/32768, 64903239996370300⟩,
  ⟨25125/32768, 1575/2048, 65222220644759699⟩,
  ⟨1575/2048, 25275/32768, 65557337497532686⟩,
  ⟨25275/32768, 12675/16384, 65908395032534268⟩,
  ⟨12675/16384, 25425/32768, 66275257808222454⟩,
  ⟨25425/32768, 6375/8192, 66657916356806014⟩,
  ⟨6375/8192, 25575/32768, 67056353903559090⟩,
  ⟨25575/32768, 12825/16384, 67470059830308884⟩,
  ⟨12825/16384, 25725/32768, 67899201538261449⟩,
  ⟨25725/32768, 3225/4096, 68343592997557408⟩,
  ⟨3225/4096, 25875/32768, 68803106410740141⟩,
  ⟨25875/32768, 12975/16384, 69277533051391016⟩,
  ⟨12975/16384, 26025/32768, 69766861256134255⟩,
  ⟨26025/32768, 6525/8192, 70270861857688173⟩,
  ⟨6525/8192, 26175/32768, 70789295318877408⟩,
  ⟨26175/32768, 13125/16384, 71322321808200684⟩,
  ⟨13125/16384, 26325/32768, 71869612051989909⟩,
  ⟨26325/32768, 825/1024, 72431028538161150⟩,
  ⟨825/1024, 26475/32768, 73006356999329775⟩,
  ⟨26475/32768, 13275/16384, 73595712746636987⟩,
  ⟨13275/16384, 26625/32768, 74198719720501419⟩,
  ⟨26625/32768, 6675/8192, 74815197615537399⟩,
  ⟨6675/8192, 26775/32768, 75445227849481342⟩,
  ⟨26775/32768, 13425/16384, 76088605355406578⟩,
  ⟨13425/16384, 26925/32768, 76745046291657817⟩,
  ⟨26925/32768, 3375/4096, 77414253484411180⟩,
  ⟨3375/4096, 27075/32768, 78096605717574509⟩,
  ⟨27075/32768, 13575/16384, 78791508416228281⟩,
  ⟨13575/16384, 27225/32768, 79498972538058274⟩,
  ⟨27225/32768, 6825/8192, 80218998202678677⟩,
  ⟨6825/8192, 27375/32768, 80951091468000841⟩,
  ⟨27375/32768, 13725/16384, 81695297232967739⟩,
  ⟨13725/16384, 27525/32768, 82451579117631273⟩,
  ⟨27525/32768, 1725/2048, 83219407651936252⟩,
  ⟨1725/2048, 27675/32768, 83999065917278081⟩,
  ⟨27675/32768, 13875/16384, 84790137692155276⟩,
  ⟨13875/16384, 27825/32768, 85592538221078569⟩,
  ⟨27825/32768, 6975/8192, 86406171133296873⟩,
  ⟨6975/8192, 27975/32768, 87230789374969712⟩,
  ⟨27975/32768, 14025/16384, 88066409120734844⟩,
  ⟨14025/16384, 28125/32768, 88912553845910209⟩,
  ⟨28125/32768, 3525/4096, 89769421472558933⟩,
  ⟨3525/4096, 28275/32768, 90636716129303506⟩,
  ⟨28275/32768, 14175/16384, 91514199510820765⟩,
  ⟨14175/16384, 28425/32768, 92401757981858365⟩,
  ⟨28425/32768, 7125/8192, 93299196952867815⟩,
  ⟨7125/8192, 28575/32768, 94206515757102528⟩,
  ⟨28575/32768, 14325/16384, 95123633310667479⟩,
  ⟨14325/16384, 28725/32768, 96049973651154760⟩,
  ⟨28725/32768, 225/256, 96985981529029854⟩,
  ⟨225/256, 28875/32768, 97931057071804294⟩,
  ⟨28875/32768, 14475/16384, 98885001585686586⟩,
  ⟨14475/16384, 29025/32768, 99847878515998281⟩,
  ⟨29025/32768, 7275/8192, 100819601141881438⟩,
  ⟨7275/8192, 29175/32768, 101799865480629938⟩,
  ⟨29175/32768, 14625/16384, 102788492289145314⟩,
  ⟨14625/16384, 29325/32768, 103785358897541150⟩,
  ⟨29325/32768, 3675/4096, 104790467409380668⟩,
  ⟨3675/4096, 29475/32768, 105803397112393280⟩,
  ⟨29475/32768, 14775/16384, 106824263887198380⟩,
  ⟨14775/16384, 29625/32768, 107852689436888863⟩,
  ⟨29625/32768, 7425/8192, 108888697884437141⟩,
  ⟨7425/8192, 29775/32768, 109932162283061543⟩,
  ⟨29775/32768, 14925/16384, 110982669887067237⟩,
  ⟨14925/16384, 29925/32768, 112040276482089400⟩,
  ⟨29925/32768, 1875/2048, 113104750498610439⟩,
  ⟨1875/2048, 30075/32768, 114176124944090475⟩,
  ⟨30075/32768, 15075/16384, 115253937760524630⟩,
  ⟨15075/16384, 30225/32768, 116338403844584389⟩,
  ⟨30225/32768, 7575/8192, 117429107261973582⟩,
  ⟨7575/8192, 30375/32768, 118525963889865966⟩,
  ⟨30375/32768, 15225/16384, 119628809670712742⟩,
  ⟨15225/16384, 30525/32768, 120737605194758613⟩,
  ⟨30525/32768, 3825/4096, 121852162468305219⟩,
  ⟨3825/4096, 30675/32768, 122972351108556375⟩,
  ⟨30675/32768, 15375/16384, 124097821892297517⟩,
  ⟨15375/16384, 30825/32768, 125228696136115588⟩,
  ⟨30825/32768, 7725/8192, 126364808210303201⟩,
  ⟨7725/8192, 30975/32768, 127505912273595420⟩,
  ⟨30975/32768, 15525/16384, 128651888471774109⟩,
  ⟨15525/16384, 31125/32768, 129802673722116656⟩,
  ⟨31125/32768, 975/1024, 130957989024476412⟩,
  ⟨975/1024, 31275/32768, 132117886037929017⟩,
  ⟨31275/32768, 15675/16384, 133281924637249628⟩,
  ⟨15675/16384, 31425/32768, 134450272467779665⟩,
  ⟨31425/32768, 7875/8192, 135622603867013143⟩,
  ⟨7875/8192, 31575/32768, 136798857433779500⟩,
  ⟨31575/32768, 15825/16384, 137979030451531710⟩,
  ⟨15825/16384, 31725/32768, 139162762858714808⟩,
  ⟨31725/32768, 3975/4096, 140350099114384419⟩,
  ⟨3975/4096, 31875/32768, 141540864400436052⟩,
  ⟨31875/32768, 15975/16384, 142734872974180807⟩,
  ⟨15975/16384, 32025/32768, 143931929289140367⟩,
  ⟨32025/32768, 8025/8192, 145131964407704255⟩,
  ⟨8025/8192, 32175/32768, 146335034975207603⟩,
  ⟨32175/32768, 16125/16384, 147540706403402701⟩,
  ⟨16125/16384, 32325/32768, 148749014454750193⟩,
  ⟨32325/32768, 2025/2048, 149959916072293158⟩,
  ⟨2025/2048, 32475/32768, 151173081659699582⟩,
  ⟨32475/32768, 16275/16384, 152388653192371748⟩,
  ⟨16275/16384, 32625/32768, 153606211864336398⟩,
  ⟨32625/32768, 8175/8192, 154825877649755144⟩,
  ⟨8175/8192, 32775/32768, 156047280708389439⟩,
  ⟨32775/32768, 16425/16384, 157270588470010544⟩,
  ⟨16425/16384, 32925/32768, 158495547370345388⟩,
  ⟨32925/32768, 4125/4096, 159721961790712709⟩,
  ⟨4125/4096, 33075/32768, 160949901341074418⟩,
  ⟨33075/32768, 16575/16384, 162178943386290070⟩,
  ⟨16575/16384, 33225/32768, 163409274219579327⟩,
  ⟨33225/32768, 8325/8192, 164640726504350943⟩,
  ⟨8325/8192, 33375/32768, 165873123459957505⟩,
  ⟨33375/32768, 16725/16384, 167106415278527261⟩,
  ⟨16725/16384, 33525/32768, 168340266859802172⟩,
  ⟨33525/32768, 525/512, 169574884107293153⟩,
  ⟨525/512, 33675/32768, 170809912857925227⟩,
  ⟨33675/32768, 16875/16384, 172045470263010482⟩,
  ⟨16875/16384, 33825/32768, 173281320206545196⟩,
  ⟨33825/32768, 8475/8192, 174517353856748843⟩,
  ⟨8475/8192, 33975/32768, 175753454426685873⟩,
  ⟨33975/32768, 17025/16384, 176989494542054164⟩,
  ⟨17025/16384, 34125/32768, 178225611171242930⟩,
  ⟨34125/32768, 4275/4096, 179461384265003262⟩,
  ⟨4275/4096, 34275/32768, 180696864379535689⟩,
  ⟨34275/32768, 17175/16384, 181931954790242055⟩,
  ⟨17175/16384, 34425/32768, 183166550056561567⟩,
  ⟨34425/32768, 8625/8192, 184400467354613939⟩,
  ⟨8625/8192, 34575/32768, 185633720870336625⟩,
  ⟨34575/32768, 17325/16384, 186866314082490669⟩,
  ⟨17325/16384, 34725/32768, 188097899438517562⟩,
  ⟨34725/32768, 2175/2048, 189328531636388881⟩,
  ⟨2175/2048, 34875/32768, 190558052422419231⟩,
  ⟨34875/32768, 17475/16384, 191786497591273074⟩,
  ⟨17475/16384, 35025/32768, 193013621370082838⟩,
  ⟨35025/32768, 8775/8192, 194239375358976924⟩,
  ⟨8775/8192, 35175/32768, 195463839326330787⟩,
  ⟨35175/32768, 17625/16384, 196686739687063771⟩,
  ⟨17625/16384, 35325/32768, 197908071787415328⟩,
  ⟨35325/32768, 4425/4096, 199127613551216836⟩,
  ⟨4425/4096, 35475/32768, 200345479581850067⟩,
  ⟨35475/32768, 17775/16384, 201561568773168151⟩,
  ⟨17775/16384, 35625/32768, 202775773203230614⟩,
  ⟨35625/32768, 8925/8192, 203987768268627137⟩,
  ⟨8925/8192, 35775/32768, 205197979102802568⟩,
  ⟨35775/32768, 17925/16384, 206405790162165595⟩,
  ⟨17925/16384, 35925/32768, 207611609008294619⟩,
  ⟨35925/32768, 1125/1024, 208814941676012240⟩,
  ⟨1125/1024, 36075/32768, 210016041990986590⟩,
  ⟨36075/32768, 18075/16384, 211214537767052707⟩,
  ⟨18075/16384, 36225/32768, 212410529293949435⟩,
  ⟨36225/32768, 9075/8192, 213603970911713672⟩,
  ⟨9075/8192, 36375/32768, 214794878829250531⟩,
  ⟨36375/32768, 18225/16384, 215982916709339279⟩,
  ⟨18225/16384, 36525/32768, 217168223035908275⟩,
  ⟨36525/32768, 4575/4096, 218350788929671725⟩,
  ⟨4575/4096, 36675/32768, 219530187077149930⟩,
  ⟨36675/32768, 18375/16384, 220706669143494443⟩,
  ⟨18375/16384, 36825/32768, 221880204822039778⟩,
  ⟨36825/32768, 9225/8192, 223050548454589115⟩,
  ⟨9225/8192, 36975/32768, 224217792593451055⟩,
  ⟨36975/32768, 18525/16384, 225381815072339981⟩,
  ⟨18525/16384, 37125/32768, 226542485212516630⟩,
  ⟨37125/32768, 2325/2048, 227699873250014762⟩,
  ⟨2325/2048, 37275/32768, 228853766125415579⟩,
  ⟨37275/32768, 18675/16384, 230004287080023248⟩,
  ⟨18675/16384, 37425/32768, 231151276690674517⟩,
  ⟨37425/32768, 9375/8192, 232294638124472167⟩,
  ⟨9375/8192, 37575/32768, 233434404294190206⟩,
  ⟨37575/32768, 18825/16384, 234570531746197257⟩,
  ⟨18825/16384, 37725/32768, 235703040293015825⟩,
  ⟨37725/32768, 4725/4096, 236831803679599847⟩,
  ⟨4725/4096, 37875/32768, 237956551776522990⟩,
  ⟨37875/32768, 18975/16384, 239077557820252720⟩,
  ⟨18975/16384, 38025/32768, 240194606055681892⟩,
  ⟨38025/32768, 9525/8192, 241307749306052218⟩,
  ⟨9525/8192, 38175/32768, 242416964883556436⟩,
  ⟨38175/32768, 19125/16384, 243522017731907490⟩,
  ⟨19125/16384, 38325/32768, 244622940433353396⟩,
  ⟨38325/32768, 75/64, 245719965070271769⟩,
  ⟨75/64, 38475/32768, 246812629647533086⟩,
  ⟨38475/32768, 19275/16384, 247901221782134211⟩,
  ⟨19275/16384, 38625/32768, 248985541796166524⟩,
  ⟨38625/32768, 9675/8192, 250065520698566401⟩,
  ⟨9675/8192, 38775/32768, 251141289216104716⟩,
  ⟨38775/32768, 19425/16384, 252212628348887828⟩,
  ⟨19425/16384, 38925/32768, 253279655802483443⟩,
  ⟨38925/32768, 4875/4096, 254342277079816710⟩,
  ⟨4875/4096, 39075/32768, 255400529389197457⟩,
  ⟨39075/32768, 19575/16384, 256454167758817054⟩,
  ⟨19575/16384, 39225/32768, 257503285432844864⟩,
  ⟨39225/32768, 9825/8192, 258547900522320721⟩,
  ⟨9825/8192, 39375/32768, 259587956583345708⟩,
  ⟨39375/32768, 19725/16384, 260623459291781673⟩,
  ⟨19725/16384, 39525/32768, 261654339850447104⟩,
  ⟨39525/32768, 2475/2048, 262680592468677908⟩,
  ⟨2475/2048, 39675/32768, 263702136695324045⟩,
  ⟨39675/32768, 19875/16384, 264718954092554379⟩,
  ⟨19875/16384, 39825/32768, 265731089886405316⟩,
  ⟨39825/32768, 9975/8192, 266738514762192895⟩,
  ⟨9975/8192, 39975/32768, 267741193086628994⟩,
  ⟨39975/32768, 20025/16384, 268739083752350146⟩,
  ⟨20025/16384, 40125/32768, 269732140485383992⟩,
  ⟨40125/32768, 5025/4096, 270720378992784730⟩,
  ⟨5025/4096, 40275/32768, 271703810160790934⟩,
  ⟨40275/32768, 20175/16384, 272682370299936238⟩,
  ⟨20175/16384, 40425/32768, 273656127878454938⟩,
  ⟨40425/32768, 10125/8192, 274624939157479994⟩,
  ⟨10125/8192, 40575/32768, 275588930338789922⟩,
  ⟨40575/32768, 20325/16384, 276547878053184321⟩,
  ⟨20325/16384, 40725/32768, 277501966385710539⟩,
  ⟨40725/32768, 1275/1024, 278451099180978890⟩,
  ⟨1275/1024, 40875/32768, 279395311591489727⟩,
  ⟨40875/32768, 20475/16384, 280334565566352802⟩,
  ⟨20475/16384, 41025/32768, 281268817801754718⟩,
  ⟨41025/32768, 10275/8192, 282198088228098199⟩,
  ⟨10275/8192, 20625/16384, 3403059561109952⟩,
  ⟨20625/16384, 5175/4096, 6791095022204652⟩,
  ⟨5175/4096, 20775/16384, 10149346711023776⟩,
  ⟨20775/16384, 10425/8192, 13478025910915012⟩,
  ⟨10425/8192, 20925/16384, 16777056072130777⟩,
  ⟨20925/16384, 2625/2048, 20046627420627545⟩,
  ⟨2625/2048, 21075/16384, 23286714855292097⟩,
  ⟨21075/16384, 10575/8192, 26497354429977053⟩,
  ⟨10575/8192, 21225/16384, 29678713126542560⟩,
  ⟨21225/16384, 5325/4096, 32831021175358083⟩,
  ⟨5325/4096, 21375/16384, 35954230021289368⟩,
  ⟨21375/16384, 10725/8192, 39048424043065709⟩,
  ⟨10725/8192, 21525/16384, 42113960602703134⟩,
  ⟨21525/16384, 675/512, 45150646398467973⟩,
  ⟨675/512, 21675/16384, 48158973778527881⟩,
  ⟨21675/16384, 10875/8192, 51138817642211495⟩,
  ⟨10875/8192, 21825/16384, 54090467180107744⟩,
  ⟨21825/16384, 5475/4096, 57014213418703346⟩,
  ⟨5475/4096, 21975/16384, 59910075802011928⟩,
  ⟨21975/16384, 11025/8192, 62778283601298390⟩,
  ⟨11025/8192, 22125/16384, 65619071728301920⟩,
  ⟨22125/16384, 2775/2048, 68432475999413269⟩,
  ⟨2775/2048, 22275/16384, 71219017982890925⟩,
  ⟨22275/16384, 11175/8192, 73978540850709470⟩,
  ⟨11175/8192, 22425/16384, 76711447179075531⟩,
  ⟨22425/16384, 5625/4096, 79418078090154224⟩,
  ⟨5625/4096, 22575/16384, 82098442958954117⟩,
  ⟨22575/16384, 11325/8192, 84752904739017910⟩,
  ⟨11325/8192, 22725/16384, 87381702414425662⟩,
  ⟨22725/16384, 1425/1024, 89985084936612472⟩,
  ⟨1425/1024, 22875/16384, 92563249192246549⟩,
  ⟨22875/16384, 11475/8192, 95116541026967252⟩,
  ⟨11475/8192, 23025/16384, 97645047446761511⟩,
  ⟨23025/16384, 5775/4096, 100149215842704504⟩,
  ⟨5775/4096, 23175/16384, 102629301216006212⟩,
  ⟨23175/16384, 11625/8192, 105085509714254154⟩,
  ⟨11625/8192, 23325/16384, 107518133030581948⟩,
  ⟨23325/16384, 2925/2048, 109927343490280454⟩,
  ⟨2925/2048, 23475/16384, 112313676859073329⟩,
  ⟨23475/16384, 11775/8192, 114677139141327437⟩,
  ⟨11775/8192, 23625/16384, 117018306770241865⟩,
  ⟨23625/16384, 5925/4096, 119337228302019521⟩,
  ⟨5925/4096, 23775/16384, 121634247561514259⟩,
  ⟨23775/16384, 11925/8192, 123909733172453281⟩,
  ⟨11925/8192, 23925/16384, 126163937464313048⟩,
  ⟨23925/16384, 375/256, 128397207020497928⟩,
  ⟨375/256, 24075/16384, 130609706275569864⟩,
  ⟨24075/16384, 12075/8192, 132801899165346094⟩,
  ⟨12075/8192, 24225/16384, 134974070306118293⟩,
  ⟨24225/16384, 6075/4096, 137126460882459246⟩,
  ⟨6075/4096, 24375/16384, 139259270845576272⟩,
  ⟨24375/16384, 12225/8192, 141373002553190844⟩,
  ⟨12225/8192, 24525/16384, 143467980841089873⟩,
  ⟨24525/16384, 3075/2048, 145544282719013569⟩,
  ⟨3075/2048, 24675/16384, 147602359621933081⟩,
  ⟨24675/16384, 12375/8192, 149642554236119126⟩,
  ⟨12375/8192, 24825/16384, 151665103185580596⟩,
  ⟨24825/16384, 6225/4096, 153670272854673849⟩,
  ⟨6225/4096, 24975/16384, 155658498961216553⟩,
  ⟨24975/16384, 12525/8192, 157629974755604845⟩,
  ⟨12525/8192, 25125/16384, 159585061698765765⟩,
  ⟨25125/16384, 1575/1024, 161524087026162789⟩,
  ⟨1575/1024, 25275/16384, 163447169758770201⟩,
  ⟨25275/16384, 12675/8192, 165354841275877026⟩,
  ⟨12675/8192, 25425/16384, 167247392959909601⟩,
  ⟨25425/16384, 6375/4096, 169125012497735183⟩,
  ⟨6375/4096, 25575/16384, 170987957219232603⟩,
  ⟨25575/16384, 12825/8192, 172836555630429927⟩,
  ⟨12825/8192, 25725/16384, 174671206255686154⟩,
  ⟨25725/16384, 3225/2048, 176492102669165695⟩,
  ⟨3225/2048, 25875/16384, 178299546393519690⟩,
  ⟨25875/16384, 12975/8192, 180093874318926895⟩,
  ⟨12975/8192, 26025/16384, 181875291089710327⟩,
  ⟨26025/16384, 6525/4096, 183644176078698263⟩,
  ⟨6525/4096, 26175/16384, 185400707455704838⟩,
  ⟨26175/16384, 13125/8192, 187145205657045928⟩,
  ⟨13125/8192, 26325/16384, 188877893270496330⟩,
  ⟨26325/16384, 825/512, 190599101054140521⟩,
  ⟨825/512, 26475/16384, 192309200682235248⟩,
  ⟨26475/16384, 13275/8192, 194008260996877197⟩,
  ⟨13275/8192, 26625/16384, 195696666863692803⟩,
  ⟨26625/16384, 6675/4096, 197374603613791459⟩,
  ⟨6675/4096, 26775/16384, 199042299005198877⟩,
  ⟨26775/16384, 13425/8192, 200700194311995822⟩,
  ⟨13425/8192, 26925/16384, 202348397074952992⟩,
  ⟨26925/16384, 3375/2048, 203987021294627254⟩,
  ⟨3375/2048, 27075/16384, 205616602781287689⟩,
  ⟨27075/16384, 13575/8192, 207237207219176496⟩,
  ⟨13575/8192, 27225/16384, 208849079045344134⟩,
  ⟨27225/16384, 6825/4096, 210452475353593188⟩,
  ⟨6825/4096, 27375/16384, 212047558849414825⟩,
  ⟨27375/16384, 13725/8192, 213634674662932991⟩,
  ⟨13725/8192, 27525/16384, 215213973248407512⟩,
  ⟨27525/16384, 1725/1024, 216785581961254401⟩,
  ⟨1725/1024, 27675/16384, 218349914606361792⟩,
  ⟨27675/16384, 13875/8192, 219906983475826047⟩,
  ⟨13875/8192, 27825/16384, 221457124426534122⟩,
  ⟨27825/16384, 6975/4096, 223000443126949974⟩,
  ⟨6975/4096, 27975/16384, 224537196528747313⟩,
  ⟨27975/16384, 14025/8192, 226067551564032831⟩,
  ⟨14025/8192, 28125/16384, 227591688509559769⟩,
  ⟨28125/16384, 3525/2048, 229109765834195807⟩,
  ⟨3525/2048, 28275/16384, 230622095495779793⟩,
  ⟨28275/16384, 14175/8192, 232128657345958126⟩,
  ⟨14175/8192, 28425/16384, 233629826322532689⟩,
  ⟨28425/16384, 7125/4096, 235125543249198335⟩,
  ⟨7125/4096, 28575/16384, 236616177848659928⟩,
  ⟨28575/16384, 14325/8192, 238101701413944137⟩,
  ⟨14325/8192, 28725/16384, 239582410496150055⟩,
  ⟨28725/16384, 225/128, 241058411758958081⟩,
  ⟨225/128, 28875/16384, 242529861133232984⟩,
  ⟨28875/16384, 14475/8192, 243996794677817419⟩,
  ⟨14475/8192, 29025/16384, 245459469464229181⟩,
  ⟨29025/16384, 7275/4096, 246918023437253776⟩,
  ⟨7275/4096, 29175/16384, 248372541415019765⟩,
  ⟨29175/16384, 14625/8192, 249823023375311288⟩,
  ⟨14625/8192, 29325/16384, 251269932290752357⟩,
  ⟨29325/16384, 3675/2048, 252712959549423540⟩,
  ⟨3675/2048, 29475/16384, 254152432314065432⟩,
  ⟨29475/16384, 14775/8192, 255588523465564497⟩,
  ⟨14775/8192, 29625/16384, 257021184976934386⟩,
  ⟨29625/16384, 7425/4096, 258450592116985453⟩,
  ⟨7425/4096, 29775/16384, 259876870659919677⟩,
  ⟨29775/16384, 14925/8192, 261299959651936786⟩,
  ⟨14925/8192, 29925/16384, 262720125399371149⟩,
  ⟨29925/16384, 1875/1024, 264137345072322182⟩,
  ⟨1875/1024, 30075/16384, 265551752504586165⟩,
  ⟨30075/16384, 15075/8192, 266963398138262839⟩,
  ⟨15075/8192, 30225/16384, 268372317934873841⟩,
  ⟨30225/16384, 7575/4096, 269778636375129585⟩,
  ⟨7575/4096, 15225/8192, 216379066120412⟩,
  ⟨15225/8192, 3825/2048, 6052653854954892⟩,
  ⟨3825/2048, 15375/8192, 11850607101881627⟩,
  ⟨15375/8192, 7725/4096, 17611011634812445⟩,
  ⟨7725/4096, 15525/8192, 23334535822820753⟩,
  ⟨15525/8192, 975/512, 29021678084012167⟩,
  ⟨975/512, 15675/8192, 34673083499168663⟩,
  ⟨15675/8192, 7875/4096, 40287588245702934⟩,
  ⟨7875/4096, 15825/8192, 45852124393952521⟩,
  ⟨15825/8192, 3975/2048, 51382406115606509⟩,
  ⟨3975/2048, 15975/8192, 56878919007308933⟩,
  ⟨15975/8192, 8025/4096, 62341734234196985⟩,
  ⟨8025/4096, 16125/8192, 67771199625060379⟩,
  ⟨16125/8192, 2025/1024, 73167498925004644⟩,
  ⟨2025/1024, 16275/8192, 78530653851581065⟩,
  ⟨16275/8192, 8175/4096, 83860770315457954⟩,
  ⟨8175/4096, 16425/8192, 89157937714099980⟩,
  ⟨16425/8192, 4125/2048, 94422201134658014⟩,
  ⟨4125/2048, 16575/8192, 99653423933067814⟩,
  ⟨16575/8192, 8325/4096, 104851673126280026⟩,
  ⟨8325/4096, 16725/8192, 110016739789213896⟩,
  ⟨16725/8192, 525/256, 115148656864464469⟩,
  ⟨525/256, 16875/8192, 120247157098104523⟩,
  ⟨16875/8192, 8475/4096, 125312186912558344⟩,
  ⟨8475/4096, 17025/8192, 130343465100632441⟩,
  ⟨17025/8192, 4275/2048, 135340864996532291⟩,
  ⟨4275/2048, 17175/8192, 140304209229525350⟩,
  ⟨17175/8192, 8625/4096, 145233170699796773⟩,
  ⟨8625/4096, 17325/8192, 150127619618064344⟩,
  ⟨17325/8192, 2175/1024, 154987212946554688⟩,
  ⟨2175/1024, 17475/8192, 159811740756338768⟩,
  ⟨17475/8192, 8775/4096, 164600992552457732⟩,
  ⟨8775/4096, 17625/8192, 169354656280640778⟩,
  ⟨17625/8192, 4425/2048, 174072389067063995⟩,
  ⟨4425/2048, 17775/8192, 178754095663414085⟩,
  ⟨17775/8192, 8925/4096, 183399378975089936⟩,
  ⟨8925/4096, 17925/8192, 188007992867252431⟩,
  ⟨17925/8192, 1125/512, 192579737103574157⟩,
  ⟨1125/512, 18075/8192, 197114325921553188⟩,
  ⟨18075/8192, 9075/4096, 201611558811032299⟩,
  ⟨9075/4096, 18225/8192, 206071153547303696⟩,
  ⟨18225/8192, 4575/2048, 210492952297487156⟩,
  ⟨4575/2048, 18375/8192, 214876719654425337⟩,
  ⟨18375/8192, 9225/4096, 219222176307767988⟩,
  ⟨9225/4096, 18525/8192, 223529348078965910⟩,
  ⟨18525/8192, 2325/1024, 227797910961253535⟩,
  ⟨2325/1024, 18675/8192, 232027711861825900⟩,
  ⟨18675/8192, 9375/4096, 236218733907228894⟩,
  ⟨9375/4096, 18825/8192, 240370721329984332⟩,
  ⟨18825/8192, 4725/2048, 244483764775885349⟩,
  ⟨4725/2048, 18975/8192, 248557650425725719⟩,
  ⟨18975/8192, 9525/4096, 252592376772175141⟩,
  ⟨9525/4096, 19125/8192, 256587881621482956⟩,
  ⟨19125/8192, 75/32, 260544215734802111⟩,
  ⟨75/32, 19275/8192, 264461337134258625⟩,
  ⟨19275/8192, 9675/4096, 268339354466577843⟩,
  ⟨9675/4096, 4875/2048, 1290901549878210⟩,
  ⟨4875/2048, 9825/4096, 16090131219576297⟩,
  ⟨9825/4096, 2475/1024, 30616344854343919⟩,
  ⟨2475/1024, 9975/4096, 44872801827732691⟩,
  ⟨9975/4096, 5025/2048, 58863269958970185⟩,
  ⟨5025/2048, 10125/4096, 72591619678835476⟩,
  ⟨10125/4096, 1275/512, 86062154159680705⟩,
  ⟨1275/512, 10275/4096, 99279266750673941⟩,
  ⟨10275/4096, 5175/2048, 112247786771302211⟩,
  ⟨5175/2048, 10425/4096, 124972530369055905⟩,
  ⟨10425/4096, 2625/1024, 137458712763747971⟩,
  ⟨2625/1024, 10575/4096, 149711632275076431⟩,
  ⟨10575/4096, 5325/2048, 161736721417300601⟩,
  ⟨5325/2048, 10725/4096, 173539587704281358⟩,
  ⟨10725/4096, 675/256, 185125873499685349⟩,
  ⟨675/256, 10875/4096, 195109487434615229⟩,
  ⟨10875/4096, 5475/2048, 196562728167097775⟩,
  ⟨5475/2048, 11025/4096, 198027068916119172⟩,
  ⟨11025/4096, 2775/1024, 199505753102645157⟩,
  ⟨2775/1024, 11175/4096, 201002025394966445⟩,
  ⟨11175/4096, 5625/2048, 202518964544655333⟩,
  ⟨5625/2048, 11325/4096, 204059622543400384⟩,
  ⟨11325/4096, 1425/512, 205626893270558716⟩,
  ⟨1425/512, 11475/4096, 207223494797931019⟩,
  ⟨11475/4096, 5775/2048, 208852077196430257⟩,
  ⟨5775/2048, 11625/4096, 210514963565613155⟩,
  ⟨11625/4096, 2925/1024, 212214314858258378⟩,
  ⟨2925/1024, 11775/4096, 213952147566029543⟩,
  ⟨11775/4096, 5925/2048, 215730074101548712⟩,
  ⟨5925/2048, 11925/4096, 217549577919315531⟩,
  ⟨11925/4096, 375/128, 219411847904663558⟩,
  ⟨375/128, 12075/4096, 221317828109500878⟩,
  ⟨12075/4096, 6075/2048, 223268163954633164⟩,
  ⟨6075/2048, 12225/4096, 225263266914792071⟩,
  ⟨12225/4096, 3075/1024, 227303270071990648⟩,
  ⟨3075/1024, 12375/4096, 229388074271039102⟩,
  ⟨12375/4096, 6225/2048, 231517336180832461⟩,
  ⟨6225/2048, 12525/4096, 233690437737343507⟩,
  ⟨12525/4096, 1575/512, 235906567174639850⟩,
  ⟨1575/512, 12675/4096, 238164697446517183⟩,
  ⟨12675/4096, 6375/2048, 240463613718393437⟩,
  ⟨6375/2048, 12825/4096, 242801908069249313⟩,
  ⟨12825/4096, 3225/1024, 245178021409424530⟩,
  ⟨3225/1024, 12975/4096, 247590279475389797⟩,
  ⟨12975/4096, 6525/2048, 250036842381629584⟩,
  ⟨6525/2048, 13125/4096, 252515814968753776⟩,
  ⟨13125/4096, 825/256, 255025192076866443⟩,
  ⟨825/256, 13275/4096, 257562940474652158⟩,
  ⟨13275/4096, 6675/2048, 260126983377067859⟩,
  ⟨6675/2048, 13425/4096, 262715224461760703⟩,
  ⟨13425/4096, 3375/1024, 265325585353709299⟩,
  ⟨3375/1024, 13575/4096, 267956011488124345⟩,
  ⟨13575/4096, 6825/2048, 270604491724042795⟩,
  ⟨6825/2048, 1725/512, 5385591559948970⟩,
  ⟨1725/512, 6975/2048, 15916251219631014⟩,
  ⟨6975/2048, 3525/1024, 15364428842309603⟩,
  ⟨3525/1024, 7125/2048, 4595772285083604⟩,
  ⟨7125/2048, 14325/4096, 273758643993803006⟩,
  ⟨14325/4096, 225/64, 271482377807919341⟩,
  ⟨225/64, 14475/4096, 269316386314371838⟩,
  ⟨14475/4096, 7275/2048, 267259007525457430⟩,
  ⟨7275/2048, 14625/4096, 265308763199830664⟩,
  ⟨14625/4096, 3675/1024, 263464357833703167⟩,
  ⟨3675/1024, 14775/4096, 261724663016055617⟩,
  ⟨14775/4096, 7425/2048, 260088747011871755⟩,
  ⟨7425/2048, 14925/4096, 258555804889248793⟩,
  ⟨14925/4096, 1875/512, 257125203672838461⟩,
  ⟨1875/512, 15075/4096, 255796437709733655⟩,
  ⟨15075/4096, 7575/2048, 254569138936761925⟩,
  ⟨7575/2048, 15225/4096, 253443052393827291⟩,
  ⟨15225/4096, 3825/1024, 252417993628332810⟩,
  ⟨3825/1024, 15375/4096, 251493909593857946⟩,
  ⟨15375/4096, 7725/2048, 250670708305793577⟩,
  ⟨7725/2048, 15525/4096, 249948438686927376⟩,
  ⟨15525/4096, 975/256, 249327275143700776⟩,
  ⟨975/256, 15675/4096, 248807301774339892⟩,
  ⟨15675/4096, 7875/2048, 248388647039963829⟩,
  ⟨7875/2048, 15825/4096, 248071400890497897⟩,
  ⟨15825/4096, 3975/1024, 247855633516548048⟩,
  ⟨3975/1024, 15975/4096, 247741380705330441⟩,
  ⟨15975/4096, 8025/2048, 247728649220558562⟩,
  ⟨8025/2048, 16125/4096, 247817351207744029⟩,
  ⟨16125/4096, 2025/512, 248007300233040834⟩,
  ⟨2025/512, 16275/4096, 248298265735458520⟩,
  ⟨16275/4096, 8175/2048, 248689908189078268⟩,
  ⟨8175/2048, 16425/4096, 249181740736648718⟩,
  ⟨16425/4096, 4125/1024, 249773233796384449⟩,
  ⟨4125/1024, 16575/4096, 250463665358312959⟩,
  ⟨16575/4096, 8325/2048, 251252252499683662⟩,
  ⟨8325/2048, 16725/4096, 252138008995647147⟩,
  ⟨16725/4096, 525/128, 253119901061893553⟩,
  ⟨525/128, 16875/4096, 254196698592260007⟩,
  ⟨16875/4096, 8475/2048, 255367079164037916⟩,
  ⟨8475/2048, 17025/4096, 256629579474002009⟩,
  ⟨17025/4096, 4275/1024, 257982649756316666⟩,
  ⟨4275/1024, 17175/4096, 259424562074820277⟩,
  ⟨17175/4096, 8625/2048, 260953524140588528⟩,
  ⟨8625/2048, 17325/4096, 262567587143876559⟩,
  ⟨17325/4096, 2175/512, 264264785687468323⟩,
  ⟨2175/512, 17475/4096, 266043019122031226⟩,
  ⟨17475/4096, 8775/2048, 267900089016630333⟩,
  ⟨8775/2048, 17625/4096, 269833786196032572⟩,
  ⟨17625/4096, 4425/1024, 271841858230896282⟩,
  ⟨4425/1024, 8925/2048, 2829809349716924⟩,
  ⟨8925/2048, 1125/256, 11643588676351086⟩,
  ⟨1125/256, 9075/2048, 20968344274405805⟩,
  ⟨9075/2048, 4575/1024, 30775499637506259⟩,
  ⟨4575/1024, 9225/2048, 41037345002228300⟩,
  ⟨9225/2048, 2325/512, 51727266277648837⟩,
  ⟨2325/512, 9375/2048, 54241403399046555⟩,
  ⟨9375/2048, 4725/1024, 54068766261128206⟩,
  ⟨4725/1024, 9525/2048, 54266934291712222⟩,
  ⟨9525/2048, 75/16, 54823707847171626⟩,
  ⟨75/16, 9675/2048, 55728836362909442⟩,
  ⟨9675/2048, 4875/1024, 56909816645863584⟩,
  ⟨4875/1024, 9825/2048, 58283903773219873⟩,
  ⟨9825/2048, 2475/512, 59989837883321804⟩,
  ⟨2475/512, 9975/2048, 62024056584115890⟩,
  ⟨9975/2048, 5025/1024, 64383950861302440⟩,
  ⟨5025/1024, 10125/2048, 67067632146792735⟩,
  ⟨10125/2048, 1275/256, 70073584123313118⟩,
  ⟨1275/256, 10275/2048, 73400247099689485⟩,
  ⟨10275/2048, 5175/1024, 77045630574023263⟩,
  ⟨5175/1024, 10425/2048, 81007121544679118⟩,
  ⟨10425/2048, 2625/512, 85281072551704032⟩,
  ⟨2625/512, 10575/2048, 89862637122712985⟩,
  ⟨10575/2048, 5325/1024, 94745515529645996⟩,
  ⟨5325/1024, 10725/2048, 99921972233595176⟩,
  ⟨10725/2048, 675/128, 105382520566149357⟩,
  ⟨675/128, 10875/2048, 111116306043265126⟩,
  ⟨10875/2048, 5475/1024, 117110837613473769⟩,
  ⟨5475/1024, 11025/2048, 123352341979692006⟩,
  ⟨11025/2048, 2775/512, 129825914823425505⟩,
  ⟨2775/512, 11175/2048, 136515783612563894⟩,
  ⟨11175/2048, 5625/1024, 143405550536491518⟩,
  ⟨5625/1024, 11325/2048, 150478600867992637⟩,
  ⟨11325/2048, 1425/256, 157718357931611342⟩,
  ⟨1425/256, 11475/2048, 165108629574656903⟩,
  ⟨11475/2048, 5775/1024, 172633924356218996⟩,
  ⟨5775/1024, 11625/2048, 180279721971787379⟩,
  ⟨11625/2048, 2925/512, 188032822019762582⟩,
  ⟨2925/512, 11775/2048, 195881311102135755⟩,
  ⟨11775/2048, 5925/1024, 188791226239751391⟩,
  ⟨5925/1024, 11925/2048, 181193897219990259⟩,
  ⟨11925/2048, 375/64, 173793451243354888⟩,
  ⟨375/64, 12075/2048, 166595628347659640⟩,
  ⟨12075/2048, 6075/1024, 159607607588104834⟩,
  ⟨6075/1024, 12225/2048, 152837725726795298⟩,
  ⟨12225/2048, 3075/512, 146295399595563812⟩,
  ⟨3075/512, 12375/2048, 139990863005536885⟩,
  ⟨12375/2048, 6225/1024, 133934956680531251⟩,
  ⟨6225/1024, 12525/2048, 128138752278899163⟩,
  ⟨12525/2048, 1575/256, 122613305892025874⟩,
  ⟨1575/256, 12675/2048, 117369312960341497⟩,
  ⟨12675/2048, 6375/1024, 112416777461509362⟩,
  ⟨6375/1024, 12825/2048, 107764740044597563⟩,
  ⟨12825/2048, 3225/512, 103421039991807802⟩,
  ⟨3225/512, 12975/2048, 99392084816744158⟩,
  ⟨12975/2048, 6525/1024, 95682626542291987⟩,
  ⟨6525/1024, 13125/2048, 92295756303015085⟩,
  ⟨13125/2048, 825/128, 89232793657689286⟩,
  ⟨825/128, 13275/2048, 86493345609476628⟩,
  ⟨13275/2048, 6675/1024, 84075362581713667⟩,
  ⟨6675/1024, 13425/2048, 81975304750454496⟩,
  ⟨13425/2048, 3375/512, 80188365705144145⟩,
  ⟨3375/512, 13575/2048, 78708696651780795⟩,
  ⟨13575/2048, 6825/1024, 77529720402085612⟩,
  ⟨6825/1024, 13725/2048, 76644428971688364⟩,
  ⟨13725/2048, 1725/256, 76045723430136980⟩,
  ⟨1725/256, 13875/2048, 75726743245106960⟩,
  ⟨13875/2048, 6975/1024, 74359426508187292⟩,
  ⟨6975/1024, 14025/2048, 66969086065398092⟩,
  ⟨14025/2048, 3525/512, 59913661549593929⟩,
  ⟨3525/512, 14175/2048, 53195282848665993⟩,
  ⟨14175/2048, 7125/1024, 46817347616152654⟩,
  ⟨7125/1024, 14325/2048, 40784565515815046⟩,
  ⟨14325/2048, 225/32, 35102373551472385⟩,
  ⟨225/32, 14475/2048, 29778472995745443⟩,
  ⟨14475/2048, 7275/1024, 24821427496096932⟩,
  ⟨7275/1024, 14625/2048, 20240559466582871⟩,
  ⟨14625/2048, 3675/512, 16045810763646976⟩,
  ⟨3675/512, 14775/2048, 12247507638707958⟩,
  ⟨14775/2048, 7425/1024, 8855980159601138⟩,
  ⟨7425/1024, 14925/2048, 5881218757867767⟩,
  ⟨14925/2048, 1875/256, 3332561579155603⟩,
  ⟨1875/256, 15075/2048, 1218247936311858⟩,
  ⟨15075/2048, 30225/4096, 267531733596680390⟩,
  ⟨30225/4096, 7575/1024, 267123341020502806⟩,
  ⟨7575/1024, 30375/4096, 266775928670502018⟩,
  ⟨30375/4096, 15225/2048, 266489883791249065⟩,
  ⟨15225/2048, 30525/4096, 266265453557909232⟩,
  ⟨30525/4096, 3825/512, 266102708561474174⟩,
  ⟨3825/512, 30675/4096, 266001680271367677⟩,
  ⟨30675/4096, 15375/2048, 265962194124531268⟩,
  ⟨15375/2048, 30825/4096, 265984018595925250⟩,
  ⟨30825/4096, 7725/1024, 266066731640452776⟩,
  ⟨7725/1024, 30975/4096, 266209852115398336⟩,
  ⟨30975/4096, 15525/2048, 266412740115543478⟩,
  ⟨15525/2048, 31125/4096, 266674644447346412⟩,
  ⟨31125/4096, 975/128, 266994704506399312⟩,
  ⟨975/128, 15675/2048, 380474241617455⟩,
  ⟨15675/2048, 7875/1024, 2257981690784855⟩,
  ⟨7875/1024, 15825/2048, 4552160042061320⟩,
  ⟨15825/2048, 3975/512, 7251817741335977⟩,
  ⟨3975/512, 15975/2048, 10345067708536352⟩,
  ⟨15975/2048, 8025/1024, 13819733295307493⟩,
  ⟨8025/1024, 16125/2048, 17663848435735977⟩,
  ⟨16125/2048, 2025/256, 21866103374058631⟩,
  ⟨2025/256, 16275/2048, 26416196335710013⟩,
  ⟨16275/2048, 8175/1024, 31305244779979900⟩,
  ⟨8175/1024, 16425/2048, 36526081305162666⟩,
  ⟨16425/2048, 4125/512, 42073550259049598⟩,
  ⟨4125/512, 16575/2048, 47944539927046708⟩,
  ⟨16575/2048, 8325/1024, 54138146056008882⟩,
  ⟨8325/1024, 16725/2048, 60655674737931077⟩,
  ⟨16725/2048, 525/64, 67500286627575206⟩,
  ⟨525/64, 16875/2048, 74558479671454392⟩,
  ⟨16875/2048, 8475/1024, 81950776191291007⟩,
  ⟨8475/1024, 17025/2048, 89689277058645498⟩,
  ⟨17025/2048, 4275/512, 97781652744041797⟩,
  ⟨4275/512, 17175/2048, 106235394275306835⟩,
  ⟨17175/2048, 8625/1024, 115057393807168013⟩,
  ⟨8625/1024, 17325/2048, 124253120840035956⟩,
  ⟨17325/2048, 2175/256, 133826260119589814⟩,
  ⟨2175/256, 17475/2048, 143777965701406670⟩,
  ⟨17475/2048, 8775/1024, 154106715318430429⟩,
  ⟨8775/1024, 17625/2048, 164807486275007156⟩,
  ⟨17625/2048, 4425/512, 175871894129510469⟩,
  ⟨4425/512, 17775/2048, 187287719567696440⟩,
  ⟨17775/2048, 8925/1024, 199039144747883293⟩,
  ⟨8925/1024, 17925/2048, 211106647963368556⟩,
  ⟨17925/2048, 1125/128, 223467542084427736⟩,
  ⟨1125/128, 18075/2048, 236096137563243861⟩,
  ⟨18075/2048, 9075/1024, 248964339901164766⟩,
  ⟨9075/1024, 4575/512, 2381120641217106⟩,
  ⟨4575/512, 9225/1024, 54678010910635407⟩,
  ⟨9225/1024, 2325/256, 106888987645477008⟩,
  ⟨2325/256, 9375/1024, 128327333835461397⟩,
  ⟨9375/1024, 4725/512, 136960529844089691⟩,
  ⟨4725/512, 9525/1024, 146329851717987705⟩,
  ⟨9525/1024, 75/8, 156469065167712664⟩,
  ⟨75/8, 9675/1024, 167490199818432755⟩,
  ⟨9675/1024, 4875/512, 126107505240952958⟩,
  ⟨4875/512, 9825/1024, 81771606711698024⟩,
  ⟨9825/1024, 2475/256, 38866866745343581⟩,
  ⟨2475/256, 19875/2048, 269047412385122264⟩,
  ⟨19875/2048, 9975/1024, 259045154508109140⟩,
  ⟨9975/1024, 20025/2048, 249382928976652010⟩,
  ⟨20025/2048, 5025/512, 240060251145873475⟩,
  ⟨5025/512, 20175/2048, 231068139470344699⟩,
  ⟨20175/2048, 10125/1024, 222389555995571723⟩,
  ⟨10125/1024, 20325/2048, 213999723295758557⟩,
  ⟨20325/2048, 1275/128, 205866960163118540⟩,
  ⟨1275/128, 20475/2048, 197953941495896665⟩,
  ⟨20475/2048, 10275/1024, 190218973491735261⟩,
  ⟨10275/1024, 20625/2048, 182617784441357880⟩,
  ⟨20625/2048, 5175/512, 175105271363285276⟩,
  ⟨5175/512, 20775/2048, 167637584926299476⟩,
  ⟨20775/2048, 10425/1024, 160174118791621623⟩,
  ⟨10425/1024, 20925/2048, 152679487048046832⟩,
  ⟨20925/2048, 2625/256, 145125562136327197⟩,
  ⟨2625/256, 21075/2048, 137493143682921469⟩,
  ⟨21075/2048, 10575/1024, 129773491696127395⟩,
  ⟨10575/1024, 21225/2048, 121969462580655737⟩,
  ⟨21225/2048, 5325/512, 114096277408564466⟩,
  ⟨5325/512, 21375/2048, 106181855782407695⟩,
  ⟨21375/2048, 10725/1024, 98266590642489767⟩,
  ⟨10725/1024, 21525/2048, 90402713172159666⟩,
  ⟨21525/2048, 675/64, 82652999668841063⟩,
  ⟨675/64, 21675/2048, 75089130592394569⟩,
  ⟨21675/2048, 10875/1024, 67789429495394245⟩,
  ⟨10875/1024, 21825/2048, 60836297412408626⟩,
  ⟨21825/2048, 5475/512, 49715627894192943⟩,
  ⟨5475/512, 21975/2048, 37085964483950459⟩,
  ⟨21975/2048, 11025/1024, 25031866974576925⟩,
  ⟨11025/1024, 22125/2048, 13625368583499634⟩,
  ⟨22125/2048, 2775/256, 2926336530348934⟩,
  ⟨2775/256, 44475/4096, 262169540309935012⟩,
  ⟨44475/4096, 22275/2048, 259880296404095267⟩,
  ⟨22275/2048, 44625/4096, 257750712865636896⟩,
  ⟨44625/4096, 11175/1024, 255781942718423878⟩,
  ⟨11175/1024, 44775/4096, 253973893639240704⟩,
  ⟨44775/4096, 22425/2048, 252325137548740897⟩,
  ⟨22425/2048, 44925/4096, 250832914176810649⟩,
  ⟨44925/4096, 5625/512, 249493088478099494⟩,
  ⟨5625/512, 45075/4096, 248300203093850945⟩,
  ⟨45075/4096, 22575/2048, 247247395273063412⟩,
  ⟨22575/2048, 45225/4096, 246326556209155400⟩,
  ⟨45225/4096, 11325/1024, 245528233769703274⟩,
  ⟨11325/1024, 45375/4096, 244841828105690476⟩,
  ⟨45375/4096, 22725/2048, 244255510787736486⟩,
  ⟨22725/2048, 45525/4096, 243756471716566861⟩,
  ⟨45525/4096, 1425/128, 243330856004145845⟩,
  ⟨1425/128, 45675/4096, 242964009836687970⟩,
  ⟨45675/4096, 22875/2048, 242640538981444895⟩,
  ⟨22875/2048, 45825/4096, 242344451861416713⟩,
  ⟨45825/4096, 11475/1024, 242059388002445581⟩,
  ⟨11475/1024, 45975/4096, 241768615902962886⟩,
  ⟨45975/4096, 23025/2048, 241455391420642653⟩,
  ⟨23025/2048, 46125/4096, 241102997533041345⟩,
  ⟨46125/4096, 5775/512, 240695026233061197⟩,
  ⟨5775/512, 46275/4096, 240215502052539117⟩,
  ⟨46275/4096, 23175/2048, 239649123701540660⟩,
  ⟨23175/2048, 46425/4096, 238981473498536055⟩,
  ⟨46425/4096, 11625/1024, 238199178484377354⟩,
  ⟨11625/1024, 46575/4096, 237290097307304365⟩,
  ⟨46575/4096, 23325/2048, 236243455031737630⟩,
  ⟨23325/2048, 46725/4096, 235050346776690424⟩,
  ⟨46725/4096, 2925/256, 233703528387961249⟩,
  ⟨2925/256, 46875/4096, 232197854574031845⟩,
  ⟨46875/4096, 23475/2048, 230530212379741386⟩,
  ⟨23475/2048, 47025/4096, 228699890057742019⟩,
  ⟨47025/4096, 11775/1024, 226708549723738794⟩,
  ⟨11775/1024, 47175/4096, 224560419048621928⟩,
  ⟨47175/4096, 23625/2048, 222262352483557357⟩,
  ⟨23625/2048, 47325/4096, 219823902140486518⟩,
  ⟨47325/4096, 5925/512, 217257395642486110⟩,
  ⟨5925/512, 47475/4096, 214577854513379895⟩,
  ⟨47475/4096, 23775/2048, 211803119788234463⟩,
  ⟨23775/2048, 47625/4096, 208953808497394124⟩,
  ⟨47625/4096, 11925/1024, 206053059684022840⟩,
  ⟨11925/1024, 47775/4096, 203126764128296715⟩,
  ⟨47775/4096, 23925/2048, 200203107935598086⟩,
  ⟨23925/2048, 47925/4096, 197312627209900246⟩,
  ⟨47925/4096, 375/32, 194488010380969232⟩,
  ⟨375/32, 48075/4096, 191763739989379439⟩,
  ⟨48075/4096, 24075/2048, 189176016846910240⟩,
  ⟨24075/2048, 48225/4096, 186762417889321376⟩,
  ⟨48225/4096, 12075/1024, 184561492805289366⟩,
  ⟨12075/1024, 48375/4096, 182612648406647473⟩,
  ⟨48375/4096, 24225/2048, 180955568582883431⟩,
  ⟨24225/2048, 48525/4096, 179629913942070824⟩,
  ⟨48525/4096, 6075/512, 178675049344806049⟩,
  ⟨6075/512, 48675/4096, 178129330105286447⟩,
  ⟨48675/4096, 24375/2048, 178030073213323092⟩,
  ⟨24375/2048, 48825/4096, 178412598669288087⟩,
  ⟨48825/4096, 12225/1024, 179310238769343573⟩,
  ⟨12225/1024, 48975/4096, 180753617217533351⟩,
  ⟨48975/4096, 24525/2048, 182770280932458462⟩,
  ⟨24525/2048, 49125/4096, 185384119759450236⟩,
  ⟨49125/4096, 3075/256, 188615096462771183⟩,
  ⟨3075/256, 49275/4096, 192478617518943445⟩,
  ⟨49275/4096, 24675/2048, 196985381692096628⟩,
  ⟨24675/2048, 49425/4096, 202140461923678947⟩,
  ⟨49425/4096, 12375/1024, 207943546828547111⟩,
  ⟨12375/1024, 49575/4096, 214388225988291692⟩,
  ⟨49575/4096, 24825/2048, 221461720274049449⟩,
  ⟨24825/2048, 49725/4096, 229144716821792404⟩,
  ⟨49725/4096, 6225/512, 237411234034245200⟩,
  ⟨6225/512, 49875/4096, 246228077985009512⟩,
  ⟨49875/4096, 24975/2048, 255555225422095057⟩,
  ⟨24975/2048, 50025/4096, 265345418604314302⟩,
  ⟨50025/4096, 12525/1024, 275544371055336763⟩,
  ⟨12525/1024, 50175/4096, 286091192318868470⟩,
  ⟨50175/4096, 25125/2048, 296917904285202473⟩,
  ⟨25125/2048, 50325/4096, 307950104230244929⟩,
  ⟨50325/4096, 1575/128, 319107379238705670⟩,
  ⟨1575/128, 25275/2048, 2270545330955180⟩,
  ⟨25275/2048, 12675/1024, 25929087089857077⟩,
  ⟨12675/1024, 25425/2048, 48340565048714629⟩,
  ⟨25425/2048, 6375/512, 68655334546388656⟩,
  ⟨6375/512, 25575/2048, 86022880728186363⟩,
  ⟨25575/2048, 12825/1024, 99631960155831185⟩,
  ⟨12825/1024, 25725/2048, 108754747349163225⟩,
  ⟨25725/2048, 3225/256, 112797413902201823⟩,
  ⟨3225/256, 25875/2048, 111352859079659865⟩,
  ⟨25875/2048, 12975/1024, 104249188014548907⟩,
  ⟨12975/1024, 26025/2048, 91639919346062204⟩,
  ⟨26025/2048, 6525/512, 74035720632284073⟩,
  ⟨6525/512, 26175/2048, 52374104215022123⟩,
  ⟨26175/2048, 13125/1024, 28077808377216927⟩,
  ⟨13125/1024, 26325/2048, 2964887551262295⟩,
  ⟨26325/2048, 52725/4096, 288784907567589764⟩,
  ⟨52725/4096, 825/64, 275629374380308620⟩,
  ⟨825/64, 52875/4096, 263678404877057408⟩,
  ⟨52875/4096, 26475/2048, 253389637112007238⟩,
  ⟨26475/2048, 53025/4096, 245263076028052469⟩,
  ⟨53025/4096, 13275/1024, 239841921363867910⟩,
  ⟨13275/1024, 53175/4096, 237713050285571362⟩,
  ⟨53175/4096, 26625/2048, 239506814366456008⟩,
  ⟨26625/2048, 53325/4096, 245897695491928853⟩,
  ⟨53325/4096, 6675/512, 257603998549404593⟩,
  ⟨6675/512, 26775/2048, 20213950675339294⟩,
  ⟨26775/2048, 13425/1024, 97263131278378552⟩,
  ⟨13425/1024, 26925/2048, 212694078071470233⟩,
  ⟨26925/2048, 3375/256, 374404163244962870⟩,
  ⟨3375/256, 13575/1024, 312002814055830784⟩,
  ⟨13575/1024, 6825/512, 1112980723159861128⟩,
  ⟨6825/512, 1725/128, 1592997214006460427⟩,
  ⟨1725/128, 3525/256, 1506115282290475668⟩,
  ⟨3525/256, 225/16, 12443247346660080964⟩,
  ⟨225/16, 3675/256, 34204484757758310239⟩,
  ⟨3675/256, 1875/128, 56788923487387728494⟩,
  ⟨1875/128, 3825/256, 71779532630297359448⟩,
  ⟨3825/256, 975/64, 58970117552182960246⟩,
  ⟨975/64, 3975/256, 33229076373854455887⟩,
  ⟨3975/256, 2025/128, 10453708220752151467⟩,
  ⟨2025/128, 8175/512, 5561121208203770861⟩,
  ⟨8175/512, 4125/256, 1644169327841461557⟩,
  ⟨4125/256, 16575/1024, 1253557553084994232⟩,
  ⟨16575/1024, 8325/512, 592376082816074254⟩,
  ⟨8325/512, 16725/1024, 7212593714941958⟩,
  ⟨16725/1024, 33525/2048, 164627164510329097⟩,
  ⟨33525/2048, 525/32, 93383145458908280⟩,
  ⟨525/32, 33675/2048, 71557888340922255⟩,
  ⟨33675/2048, 16875/1024, 88607839460340144⟩,
  ⟨16875/1024, 33825/2048, 134789440007093288⟩,
  ⟨33825/2048, 8475/512, 201261355632681584⟩,
  ⟨8475/512, 33975/2048, 280160314325154055⟩,
  ⟨33975/2048, 17025/1024, 364357888254935939⟩,
  ⟨17025/1024, 4275/256, 58806481565276350⟩,
  ⟨4275/256, 17175/1024, 220858859482306417⟩,
  ⟨17175/1024, 8625/512, 340230471552511222⟩,
  ⟨8625/512, 17325/1024, 405415103516159764⟩,
  ⟨17325/1024, 2175/128, 417202910448263273⟩,
  ⟨2175/128, 17475/1024, 385249863568040032⟩,
  ⟨17475/1024, 8775/512, 324334024620189350⟩,
  ⟨8775/512, 17625/1024, 251270649799539947⟩,
  ⟨17625/1024, 4425/256, 182070309041630722⟩,
  ⟨4425/256, 17775/1024, 129754270095155308⟩,
  ⟨17775/1024, 8925/512, 102894257605088485⟩,
  ⟨8925/512, 17925/1024, 105312384314985375⟩,
  ⟨17925/1024, 1125/64, 136238398642529810⟩,
  ⟨1125/64, 18075/1024, 190960350457100581⟩,
  ⟨18075/1024, 9075/512, 262158652790785204⟩,
  ⟨9075/512, 4575/256, 150554746373075817⟩,
  ⟨4575/256, 2325/128, 300663696662976432⟩,
  ⟨2325/128, 9375/512, 266070588053352629⟩,
  ⟨9375/512, 4725/256, 21152916831632938⟩,
  ⟨4725/256, 18975/1024, 181289927378910560⟩,
  ⟨18975/1024, 9525/512, 130477787207823804⟩,
  ⟨9525/512, 19125/1024, 87424181631070670⟩,
  ⟨19125/1024, 75/4, 49423864959705436⟩,
  ⟨75/4, 19275/1024, 13125977620795908⟩,
  ⟨19275/1024, 38625/2048, 258699691706081989⟩,
  ⟨38625/2048, 9675/512, 251632872762984922⟩,
  ⟨9675/512, 38775/2048, 243449392650436879⟩,
  ⟨38775/2048, 19425/1024, 233929034414733380⟩,
  ⟨19425/1024, 38925/2048, 222939789275691788⟩,
  ⟨38925/2048, 4875/256, 210443522571306277⟩,
  ⟨4875/256, 39075/2048, 196495562637489918⟩,
  ⟨39075/2048, 19575/1024, 181241097968394301⟩,
  ⟨19575/1024, 39225/2048, 164911780979881953⟩,
  ⟨39225/2048, 9825/512, 147804069138873982⟩,
  ⟨9825/512, 39375/2048, 130265095735819390⟩,
  ⟨39375/2048, 19725/1024, 112672285525202435⟩,
  ⟨19725/1024, 39525/2048, 95410666523983958⟩,
  ⟨39525/2048, 2475/128, 78849528763794279⟩,
  ⟨2475/128, 39675/2048, 63319083284175809⟩,
  ⟨39675/2048, 19875/1024, 49088339440170679⟩,
  ⟨19875/1024, 39825/2048, 36346066598535095⟩,
  ⟨39825/2048, 9975/512, 25185669060220471⟩,
  ⟨9975/512, 39975/2048, 15592830043977543⟩,
  ⟨39975/2048, 20025/1024, 7447690698887438⟩,
  ⟨20025/1024, 40125/2048, 526445226931800⟩,
  ⟨40125/2048, 80325/4096, 245899089539171788⟩,
  ⟨80325/4096, 5025/256, 245268798511430547⟩,
  ⟨5025/256, 80475/4096, 244739312734451633⟩,
  ⟨80475/4096, 40275/2048, 244256149386235105⟩,
  ⟨40275/2048, 80625/4096, 243763006587894218⟩,
  ⟨80625/4096, 20175/1024, 243202902983627119⟩,
  ⟨20175/1024, 80775/4096, 242519471439682486⟩,
  ⟨80775/4096, 40425/2048, 241658562554057486⟩,
  ⟨40425/2048, 80925/4096, 240569486619010430⟩,
  ⟨80925/4096, 10125/512, 239206975830409538⟩,
  ⟨10125/512, 81075/4096, 237532601069912667⟩,
  ⟨81075/4096, 40575/2048, 235516888262730565⟩,
  ⟨40575/2048, 81225/4096, 233140785958836993⟩,
  ⟨81225/4096, 20325/1024, 230397729677257246⟩,
  ⟨20325/1024, 81375/4096, 227296450652058557⟩,
  ⟨81375/4096, 40725/2048, 223861854825157441⟩,
  ⟨40725/2048, 81525/4096, 220137556235246078⟩,
  ⟨81525/4096, 1275/64, 216187633313619057⟩,
  ⟨1275/64, 81675/4096, 212098781954209035⟩,
  ⟨81675/4096, 40875/2048, 207982315332737789⟩,
  ⟨40875/2048, 81825/4096, 203975850754923718⟩,
  ⟨81825/4096, 20475/1024, 200245311134946561⟩,
  ⟨20475/1024, 81975/4096, 196986440360457268⟩,
  ⟨81975/4096, 41025/2048, 194426630601377570⟩,
  ⟨41025/2048, 82125/4096, 192826096536705738⟩,
  ⟨82125/4096, 10275/512, 192479616000235973⟩,
  ⟨10275/512, 82275/4096, 193717120399698995⟩,
  ⟨82275/4096, 41175/2048, 196905210451321547⟩,
  ⟨41175/2048, 82425/4096, 202422047966442920⟩,
  ⟨82425/4096, 20625/1024, 210632277182572732⟩,
  ⟨20625/1024, 82575/4096, 222107172904932335⟩,
  ⟨82575/4096, 41325/2048, 237364304228809800⟩,
  ⟨41325/2048, 82725/4096, 256959297278618762⟩,
  ⟨82725/4096, 5175/256, 281485307434041771⟩,
  ⟨5175/256, 41475/2048, 34947342449791232⟩,
  ⟨41475/2048, 20775/1024, 125970827136354308⟩,
  ⟨20775/1024, 41625/2048, 250885790161304156⟩,
  ⟨41625/2048, 10425/512, 416177311250561179⟩,
  ⟨10425/512, 20925/1024, 222951069313832745⟩,
  ⟨20925/1024, 2625/128, 935540363407449395⟩,
  ⟨2625/128, 5325/256, 523355552107132964⟩,
  ⟨5325/256, 675/32, 6688207099159928694⟩,
  ⟨675/32, 5475/256, 20806350510308636580⟩,
  ⟨5475/256, 2775/128, 36799494255131566548⟩,
  ⟨2775/128, 5625/256, 47869308761418106586⟩,
  ⟨5625/256, 1425/64, 43641030251148048494⟩,
  ⟨1425/64, 5775/256, 40309075218576406428⟩,
  ⟨5775/256, 2925/128, 40785743503455473373⟩,
  ⟨2925/128, 5925/256, 45497827785065760201⟩,
  ⟨5925/256, 375/16, 51216367317260174656⟩,
  ⟨375/16, 6075/256, 48644345437578272550⟩,
  ⟨6075/256, 3075/128, 40068636279861653346⟩,
  ⟨3075/128, 6225/256, 35150029356473474847⟩,
  ⟨6225/256, 1575/64, 32271479941437767831⟩,
  ⟨1575/64, 6375/256, 32205240525763853753⟩,
  ⟨6375/256, 3225/128, 26939740355348829474⟩,
  ⟨3225/128, 6525/256, 15745363349948486856⟩,
  ⟨6525/256, 825/32, 5282140229835688017⟩,
  ⟨825/32, 6675/256, 34501452839859003⟩,
  ⟨6675/256, 13425/512, 320526045142186398⟩,
  ⟨13425/512, 26925/1024, 236970945083407140⟩,
  ⟨26925/1024, 3375/128, 61760530189056916⟩,
  ⟨3375/128, 54075/2048, 238487783663304911⟩,
  ⟨54075/2048, 27075/1024, 223752182209017348⟩,
  ⟨27075/1024, 13575/512, 8488615545265673⟩,
  ⟨13575/512, 27225/1024, 55045824100087372⟩,
  ⟨27225/1024, 6825/256, 120091575811811221⟩,
  ⟨6825/256, 27375/1024, 186621007762452414⟩,
  ⟨27375/1024, 13725/512, 244860718672793693⟩,
  ⟨13725/512, 1725/64, 114885225939364108⟩,
  ⟨1725/64, 13875/512, 192270695604134184⟩,
  ⟨13875/512, 6975/256, 173438674276160116⟩,
  ⟨6975/256, 14025/512, 46846046878790434⟩,
  ⟨14025/512, 28125/1024, 203583700623312001⟩,
  ⟨28125/1024, 3525/128, 169797615160816406⟩,
  ⟨3525/128, 28275/1024, 128645645518976886⟩,
  ⟨28275/1024, 14175/512, 77358794687267717⟩,
  ⟨14175/512, 28425/1024, 15655207485506114⟩,
  ⟨28425/1024, 56925/2048, 224338452109255217⟩,
  ⟨56925/2048, 7125/256, 201334739972532577⟩,
  ⟨7125/256, 57075/2048, 178261828628791277⟩,
  ⟨57075/2048, 28575/1024, 156429222410772086⟩,
  ⟨28575/1024, 57225/2048, 137422944407808302⟩,
  ⟨57225/2048, 14325/512, 123101352866369415⟩,
  ⟨14325/512, 57375/2048, 115585881201811824⟩,
  ⟨57375/2048, 28725/1024, 117246391520326129⟩,
  ⟨28725/1024, 57525/2048, 130566236719625367⟩,
  ⟨57525/2048, 225/8, 157801753992259539⟩,
  ⟨225/8, 57675/2048, 202541561159158230⟩,
  ⟨57675/2048, 28875/1024, 267912606355774836⟩,
  ⟨28875/1024, 14475/512, 74164173942477920⟩,
  ⟨14475/512, 29025/1024, 377253948886142650⟩,
  ⟨29025/1024, 7275/256, 829798309141546524⟩,
  ⟨7275/256, 3675/128, 963980839800906916⟩,
  ⟨3675/128, 7425/256, 4725632275482821385⟩,
  ⟨7425/256, 1875/64, 12303577382102827407⟩,
  ⟨1875/64, 7575/256, 22182688041002160786⟩,
  ⟨7575/256, 3825/128, 31454421354555964427⟩,
  ⟨3825/128, 7725/256, 38270223626796925587⟩,
  ⟨7725/256, 975/32, 42492792986478133882⟩,
  ⟨975/32, 7875/256, 46297616682233213827⟩,
  ⟨7875/256, 3975/128, 51696315925614246940⟩,
  ⟨3975/128, 8025/256, 57009351344367524485⟩,
  ⟨8025/256, 2025/64, 60310954248655567742⟩,
  ⟨2025/64, 8175/256, 59101770772104430851⟩,
  ⟨8175/256, 4125/128, 56868604794036469923⟩,
  ⟨4125/128, 8325/256, 54335420253743641848⟩,
  ⟨8325/256, 525/16, 49649473348167085911⟩,
  ⟨525/16, 8475/256, 42666524733949405649⟩,
  ⟨8475/256, 4275/128, 35044117076067665170⟩,
  ⟨4275/128, 8625/256, 28664542063059777806⟩,
  ⟨8625/256, 2175/64, 23651298214232267737⟩,
  ⟨2175/64, 8775/256, 17432617641248328306⟩,
  ⟨8775/256, 4425/128, 10184358236534958151⟩,
  ⟨4425/128, 8925/256, 3625009629380192799⟩,
  ⟨8925/256, 1125/32, 161310822734576557⟩,
  ⟨1125/32, 18075/512, 184834118151115602⟩,
  ⟨18075/512, 36225/1024, 265156894386466887⟩,
  ⟨36225/1024, 9075/256, 139050268457329020⟩,
  ⟨9075/256, 36375/1024, 80588416234081935⟩,
  ⟨36375/1024, 18225/512, 60110427248778241⟩,
  ⟨18225/512, 36525/1024, 61971878283218081⟩,
  ⟨36525/1024, 4575/128, 72852604363152697⟩,
  ⟨4575/128, 36675/1024, 88121370257580516⟩,
  ⟨36675/1024, 18375/512, 112372764263990078⟩,
  ⟨18375/512, 36825/1024, 155943136759426984⟩,
  ⟨36825/1024, 9225/256, 235482734045587035⟩,
  ⟨9225/256, 18525/512, 249556775914480995⟩,
  ⟨18525/512, 2325/64, 867431785603401643⟩,
  ⟨2325/64, 9375/256, 1529303848022709057⟩,
  ⟨9375/256, 4725/128, 5595318166435162644⟩,
  ⟨4725/128, 9525/256, 11309443365216732532⟩,
  ⟨9525/256, 75/2, 17300101758081030361⟩,
  ⟨75/2, 9675/256, 23073316038399856432⟩,
  ⟨9675/256, 4875/128, 29390550743138000258⟩,
  ⟨4875/128, 9825/256, 36145892261671506800⟩,
  ⟨9825/256, 2475/64, 42606330240813348839⟩,
  ⟨2475/64, 9975/256, 48005194862953326923⟩,
  ⟨9975/256, 5025/128, 52364910910784568208⟩,
  ⟨5025/128, 10125/256, 55863187858492841658⟩,
  ⟨10125/256, 1275/32, 57291793353423480890⟩,
  ⟨1275/32, 10275/256, 57155761844653237346⟩,
  ⟨10275/256, 5175/128, 56201768601996431463⟩,
  ⟨5175/128, 10425/256, 54831636372172424493⟩,
  ⟨10425/256, 2625/64, 52480138552279083828⟩,
  ⟨2625/64, 10575/256, 48034053158325801860⟩,
  ⟨10575/256, 5325/128, 42196363332397858776⟩,
  ⟨5325/128, 10725/256, 35965285759490463302⟩,
  ⟨10725/256, 675/16, 30471767237658631536⟩,
  ⟨675/16, 10875/256, 25913416424847954378⟩,
  ⟨10875/256, 5475/128, 21752418074056718432⟩,
  ⟨5475/128, 11025/256, 17752135227418133546⟩,
  ⟨11025/256, 2775/64, 14413284132507257247⟩,
  ⟨2775/64, 11175/256, 11427660492231358542⟩,
  ⟨11175/256, 5625/128, 9666024645365538264⟩,
  ⟨5625/128, 11325/256, 9335320680634168169⟩,
  ⟨11325/256, 1425/32, 10244559393263304303⟩,
  ⟨1425/32, 11475/256, 12262101684072840568⟩,
  ⟨11475/256, 5775/128, 15285888169686457830⟩,
  ⟨5775/128, 11625/256, 18990617131392433852⟩,
  ⟨11625/256, 2925/64, 22666389037963479869⟩,
  ⟨2925/64, 11775/256, 26565765422689727268⟩,
  ⟨11775/256, 5925/128, 30755792622257833615⟩,
  ⟨5925/128, 11925/256, 35032761294983369599⟩,
  ⟨11925/256, 375/8, 39092770225963875439⟩,
  ⟨375/8, 12075/256, 42545563788554076771⟩,
  ⟨12075/256, 6075/128, 44715565814528222255⟩,
  ⟨6075/128, 12225/256, 46399181344080888307⟩,
  ⟨12225/256, 3075/64, 47482077558445665756⟩,
  ⟨3075/64, 12375/256, 47857240472444231640⟩,
  ⟨12375/256, 6225/128, 47534253645307220864⟩,
  ⟨6225/128, 12525/256, 46621521866357993781⟩,
  ⟨12525/256, 1575/32, 45275784646107323051⟩,
  ⟨1575/32, 12675/256, 43708171601817843909⟩,
  ⟨12675/256, 6375/128, 42022475539023521616⟩,
  ⟨6375/128, 12825/256, 39966979963094726037⟩,
  ⟨12825/256, 3225/64, 37372113139573730162⟩,
  ⟨3225/64, 12975/256, 34979528715242936995⟩,
  ⟨12975/256, 6525/128, 33024875194299032953⟩,
  ⟨6525/128, 13125/256, 30697211814072772714⟩,
  ⟨13125/256, 825/16, 28817042921742711618⟩,
  ⟨825/16, 13275/256, 27480618858100284638⟩,
  ⟨13275/256, 6675/128, 26702773617431655749⟩,
  ⟨6675/128, 13425/256, 26562190723400488509⟩,
  ⟨13425/256, 3375/64, 27044758666127452873⟩,
  ⟨3375/64, 13575/256, 27942046710237042535⟩,
  ⟨13575/256, 6825/128, 29039358471842723461⟩,
  ⟨6825/128, 13725/256, 30384115230188536721⟩,
  ⟨13725/256, 1725/32, 31977511701116948571⟩,
  ⟨1725/32, 13875/256, 33741852008703127694⟩,
  ⟨13875/256, 6975/128, 35439299274227406756⟩,
  ⟨6975/128, 14025/256, 36399348326774799128⟩,
  ⟨14025/256, 3525/64, 36295600856918118707⟩,
  ⟨3525/64, 14175/256, 35871637909326639831⟩,
  ⟨14175/256, 7125/128, 35326477648214294263⟩,
  ⟨7125/128, 14325/256, 34708855587104371101⟩,
  ⟨14325/256, 225/4, 34139939526475638391⟩,
  ⟨225/4, 14475/256, 33717574402806128930⟩,
  ⟨14475/256, 7275/128, 33400828723458695086⟩,
  ⟨7275/128, 14625/256, 33288959139073173948⟩,
  ⟨14625/256, 3675/64, 33499257383546083989⟩,
  ⟨3675/64, 14775/256, 34190889579048617188⟩,
  ⟨14775/256, 7425/128, 35363704468696361857⟩,
  ⟨7425/128, 14925/256, 36888161173270996642⟩,
  ⟨14925/256, 1875/32, 38675908419346053492⟩,
  ⟨1875/32, 15075/256, 40258891933113218083⟩,
  ⟨15075/256, 7575/128, 41333555247387747218⟩,
  ⟨7575/128, 15225/256, 42219218865096322257⟩,
  ⟨15225/256, 3825/64, 43254665544021248423⟩,
  ⟨3825/64, 15375/256, 44254350480742540256⟩,
  ⟨15375/256, 7725/128, 45127771819030544745⟩,
  ⟨7725/128, 15525/256, 45879162890211280270⟩,
  ⟨15525/256, 975/16, 46377825967600875592⟩,
  ⟨975/16, 15675/256, 46556713370751115133⟩,
  ⟨15675/256, 7875/128, 46364035323981866945⟩,
  ⟨7875/128, 15825/256, 45758779082621244644⟩,
  ⟨15825/256, 3975/64, 44747651752920057583⟩,
  ⟨3975/64, 15975/256, 43335568596468289085⟩,
  ⟨15975/256, 8025/128, 41153052536397218667⟩,
  ⟨8025/128, 16125/256, 38135099555443714012⟩,
  ⟨16125/256, 2025/32, 35014329532993700983⟩,
  ⟨2025/32, 16275/256, 31850997819575224673⟩,
  ⟨16275/256, 8175/128, 28322651153930965485⟩,
  ⟨8175/128, 16425/256, 25104189572495306100⟩,
  ⟨16425/256, 4125/64, 22522975056342017697⟩,
  ⟨4125/64, 16575/256, 20725904174264530870⟩,
  ⟨16575/256, 8325/128, 19836008844171692695⟩,
  ⟨8325/128, 16725/256, 19917180707493879393⟩,
  ⟨16725/256, 525/8, 21055006033955428714⟩,
  ⟨525/8, 16875/256, 23295916571680315990⟩,
  ⟨16875/256, 8475/128, 26568285360613457964⟩,
  ⟨8475/128, 17025/256, 30507806744008426929⟩,
  ⟨17025/256, 4275/64, 34393841441455534538⟩,
  ⟨4275/64, 17175/256, 38822729623718477832⟩,
  ⟨17175/256, 8625/128, 43621781767089955697⟩,
  ⟨8625/128, 17325/256, 48556870752020253189⟩,
  ⟨17325/256, 2175/32, 53354481056577179855⟩,
  ⟨2175/32, 17475/256, 57440390455589897557⟩,
  ⟨17475/256, 8775/128, 60503231477487924820⟩,
  ⟨8775/128, 17625/256, 62729617527090254602⟩,
  ⟨17625/256, 4425/64, 64036135965961729826⟩,
  ⟨4425/64, 17775/256, 64287172105888235822⟩,
  ⟨17775/256, 8925/128, 63435279174586085898⟩,
  ⟨8925/128, 17925/256, 61515487003551396779⟩,
  ⟨17925/256, 1125/16, 58596984606129230130⟩,
  ⟨1125/16, 18075/256, 53796487572312826672⟩,
  ⟨18075/256, 9075/128, 48291098975050224701⟩,
  ⟨9075/128, 18225/256, 42364572322980758824⟩,
  ⟨18225/256, 4575/64, 36300971224472322580⟩,
  ⟨4575/64, 18375/256, 30389414521217598657⟩,
  ⟨18375/256, 9225/128, 24924304541051107333⟩,
  ⟨9225/128, 18525/256, 20163561678268430355⟩,
  ⟨18525/256, 2325/32, 16307999440507456282⟩,
  ⟨2325/32, 18675/256, 13128244118879767079⟩,
  ⟨18675/256, 9375/128, 11238028835210598405⟩,
  ⟨9375/128, 18825/256, 10874644282072173164⟩,
  ⟨18825/256, 4725/64, 12112364210595998045⟩,
  ⟨4725/64, 18975/256, 14921307844119240148⟩,
  ⟨18975/256, 9525/128, 18367031556140534790⟩,
  ⟨9525/128, 19125/256, 22933073931990331599⟩,
  ⟨19125/256, 75, 28592080435399737219⟩,
  ⟨75, 19275/256, 35098184277852114608⟩,
  ⟨19275/256, 9675/128, 42141466896705250934⟩,
  ⟨9675/128, 19425/256, 49361396863342214529⟩,
  ⟨19425/256, 4875/64, 56400043386381153986⟩,
  ⟨4875/64, 19575/256, 62826861089796672258⟩,
  ⟨19575/256, 9825/128, 68439072990087094461⟩,
  ⟨9825/128, 19725/256, 72954010767113769251⟩,
  ⟨19725/256, 2475/32, 75738566889748552160⟩,
  ⟨2475/32, 19875/256, 76628982151860098354⟩,
  ⟨19875/256, 9975/128, 75945833766493957873⟩,
  ⟨9975/128, 20025/256, 73131433017889443514⟩,
  ⟨20025/256, 5025/64, 68519255877029700369⟩,
  ⟨5025/64, 20175/256, 62686740005363562248⟩,
  ⟨20175/256, 10125/128, 55929762889445079825⟩,
  ⟨10125/128, 20325/256, 48589921368344725189⟩,
  ⟨20325/256, 1275/16, 41023810314239017273⟩,
  ⟨1275/16, 20475/256, 33545155555367237322⟩,
  ⟨20475/256, 10275/128, 26511947928480702486⟩,
  ⟨10275/128, 20625/256, 20314554325652176132⟩,
  ⟨20625/256, 5175/64, 15290783261894983806⟩,
  ⟨5175/64, 20775/256, 11703081782097524631⟩,
  ⟨20775/256, 10425/128, 9738035491293049674⟩,
  ⟨10425/128, 20925/256, 9388608033160032093⟩,
  ⟨20925/256, 2625/32, 9802778464131754040⟩,
  ⟨2625/32, 21075/256, 11282662150941439605⟩,
  ⟨21075/256, 10575/128, 14401225662996645339⟩,
  ⟨10575/128, 21225/256, 19020824614562147999⟩,
  ⟨21225/256, 5325/64, 24934350207305269906⟩,
  ⟨5325/64, 21375/256, 31854443424826388664⟩,
  ⟨21375/256, 10725/128, 39424595006713804011⟩,
  ⟨10725/128, 21525/256, 47191917097103037090⟩,
  ⟨21525/256, 675/8, 54805295640602994292⟩,
  ⟨675/8, 21675/256, 61955227398568890420⟩,
  ⟨21675/256, 10875/128, 68305819635770349286⟩,
  ⟨10875/128, 21825/256, 73547546629424079151⟩,
  ⟨21825/256, 5475/64, 77420958112728677515⟩,
  ⟨5475/64, 21975/256, 79532139516613105899⟩,
  ⟨21975/256, 11025/128, 79253988954615103255⟩,
  ⟨11025/128, 22125/256, 76963025891518368165⟩,
  ⟨22125/256, 2775/32, 72877222464254650974⟩,
  ⟨2775/32, 22275/256, 67536948758490481827⟩,
  ⟨22275/256, 11175/128, 61219320361311946766⟩,
  ⟨11175/128, 22425/256, 54227372050915778667⟩,
  ⟨22425/256, 5625/64, 46874222165155586752⟩,
  ⟨5625/64, 22575/256, 39546373560431510910⟩,
  ⟨22575/256, 11325/128, 32642963103175380764⟩,
  ⟨11325/128, 22725/256, 26501356713913075393⟩,
  ⟨22725/256, 1425/16, 21414051964395726369⟩,
  ⟨1425/16, 22875/256, 17614698913060895213⟩,
  ⟨22875/256, 11475/128, 15271582003244189071⟩,
  ⟨11475/128, 23025/256, 13510871405610137684⟩,
  ⟨23025/256, 5775/64, 13371919258277588322⟩,
  ⟨5775/64, 23175/256, 14857319188578081723⟩,
  ⟨23175/256, 11625/128, 17747625146193425781⟩,
  ⟨11625/128, 23325/256, 21454875153821443989⟩,
  ⟨23325/256, 2925/32, 26256514916933251473⟩,
  ⟨2925/32, 23475/256, 31945707271847426152⟩,
  ⟨23475/256, 11775/128, 38157187043737576481⟩,
  ⟨11775/128, 23625/256, 44675683293158380051⟩,
  ⟨23625/256, 5925/64, 51177022828070320383⟩,
  ⟨5925/64, 23775/256, 57341223396358579076⟩,
  ⟨23775/256, 11925/128, 62875771045395803023⟩,
  ⟨11925/128, 23925/256, 67531050777563289855⟩,
  ⟨23925/256, 375/4, 70346328281843193876⟩,
  ⟨375/4, 24075/256, 71761184002190472143⟩,
  ⟨24075/256, 12075/128, 71960122001715428424⟩,
  ⟨12075/128, 24225/256, 70980618056895630299⟩,
  ⟨24225/256, 6075/64, 68915685784140916706⟩,
  ⟨6075/64, 24375/256, 65907036794441973538⟩,
  ⟨24375/256, 12225/128, 61634417644177818956⟩,
  ⟨12225/128, 24525/256, 56503361212060719815⟩,
  ⟨24525/256, 3075/32, 51131312959988073059⟩,
  ⟨3075/32, 24675/256, 45796804070845327770⟩,
  ⟨24675/256, 12375/128, 40761402952772548270⟩,
  ⟨12375/128, 24825/256, 36265087317110515773⟩,
  ⟨24825/256, 6225/64, 32515247087758762737⟩,
  ⟨6225/64, 24975/256, 29109299607114085598⟩,
  ⟨24975/256, 12525/128, 26323872790676944559⟩,
  ⟨12525/128, 25125/256, 24686742708147068559⟩,
  ⟨25125/256, 1575/16, 24241444282614567983⟩,
  ⟨1575/16, 25275/256, 24973028705632547801⟩,
  ⟨25275/256, 12675/128, 26806091004280480382⟩,
  ⟨12675/128, 25425/256, 29607576031490895364⟩,
  ⟨25425/256, 6375/64, 33122632120145472064⟩,
  ⟨6375/64, 25575/256, 37037555998717465452⟩,
  ⟨25575/256, 12825/128, 40783727589946842879⟩,
  ⟨12825/128, 25725/256, 44651167927521594432⟩,
  ⟨25725/256, 3225/32, 48482076548673923389⟩,
  ⟨3225/32, 25875/256, 52086024392349270039⟩,
  ⟨25875/256, 12975/128, 54953717371135539566⟩,
  ⟨12975/128, 26025/256, 56680370583568822177⟩,
  ⟨26025/256, 6525/64, 57848280053871475227⟩,
  ⟨6525/64, 26175/256, 58447817058096584443⟩,
  ⟨26175/256, 13125/128, 58504768569229456311⟩,
  ⟨13125/128, 26325/256, 58073088668103677661⟩,
  ⟨26325/256, 825/8, 57208539995033978203⟩,
  ⟨825/8, 26475/256, 55973898622138983721⟩,
  ⟨26475/256, 13275/128, 54515185643786999013⟩,
  ⟨13275/128, 26625/256, 52982855826442082649⟩,
  ⟨26625/256, 6675/64, 51489660963758662692⟩,
  ⟨6675/64, 26775/256, 49627964124371909875⟩,
  ⟨26775/256, 13425/128, 47765157107652668087⟩,
  ⟨13425/128, 26925/256, 46101673407053238481⟩,
  ⟨26925/256, 3375/32, 43980966582550774839⟩,
  ⟨3375/32, 27075/256, 42343690391358930834⟩,
  ⟨27075/256, 13575/128, 41238070195557756606⟩,
  ⟨13575/128, 27225/256, 40675022667508991682⟩,
  ⟨27225/256, 6825/64, 40634484357891970888⟩,
  ⟨6825/64, 27375/256, 41067926734502511248⟩,
  ⟨27375/256, 13725/128, 41871328557625489741⟩,
  ⟨13725/128, 27525/256, 42905298404103219701⟩,
  ⟨27525/256, 1725/16, 44143749167964335312⟩,
  ⟨1725/16, 27675/256, 45481945634804189187⟩,
  ⟨27675/256, 13875/128, 46817139616730602411⟩,
  ⟨13875/128, 27825/256, 48055159910339694168⟩,
  ⟨27825/256, 6975/64, 48931692347076480621⟩,
  ⟨6975/64, 27975/256, 48177961086120330732⟩,
  ⟨27975/256, 14025/128, 47135646333653452336⟩,
  ⟨14025/128, 28125/256, 45994950439809567861⟩,
  ⟨28125/256, 3525/32, 44844864938276638876⟩,
  ⟨3525/32, 28275/256, 43786191099154084039⟩,
  ⟨28275/256, 14175/128, 42922998810982749391⟩,
  ⟨14175/128, 28425/256, 42304285449731455884⟩,
  ⟨28425/256, 7125/64, 42016721254034410440⟩,
  ⟨7125/64, 28575/256, 42186489245468168876⟩,
  ⟨28575/256, 14325/128, 42862116794168799610⟩,
  ⟨14325/128, 28725/256, 44060172966434331172⟩,
  ⟨28725/256, 225/2, 45762747925018072959⟩,
  ⟨225/2, 28875/256, 47918402275310898706⟩,
  ⟨28875/256, 14475/128, 49765766447444245282⟩,
  ⟨14475/128, 29025/256, 51594491252751914861⟩,
  ⟨29025/256, 7275/64, 53081027568495438895⟩,
  ⟨7275/64, 29175/256, 54490841093164136263⟩,
  ⟨29175/256, 14625/128, 55922743766068970647⟩,
  ⟨14625/128, 29325/256, 57271629130123818326⟩,
  ⟨29325/256, 3675/32, 58427212419642998715⟩,
  ⟨3675/32, 29475/256, 59196055669900802242⟩,
  ⟨29475/256, 14775/128, 59552912920430674370⟩,
  ⟨14775/128, 29625/256, 59442712292561548853⟩,
  ⟨29625/256, 7425/64, 58820194789263831130⟩,
  ⟨7425/64, 29775/256, 57668916616436989250⟩,
  ⟨29775/256, 14925/128, 56003670631074299284⟩,
  ⟨14925/128, 29925/256, 53421537477203423961⟩,
  ⟨29925/256, 1875/16, 49959323071924988791⟩,
  ⟨1875/16, 30075/256, 46310810026470649905⟩,
  ⟨30075/256, 15075/128, 42662248174912477698⟩,
  ⟨15075/128, 30225/256, 38992938790010242011⟩,
  ⟨30225/256, 7575/64, 35228423965819666838⟩,
  ⟨7575/64, 30375/256, 32047890732431884343⟩,
  ⟨30375/256, 15225/128, 29627512992623779822⟩,
  ⟨15225/128, 30525/256, 28167543021104722311⟩,
  ⟨30525/256, 3825/32, 27805273731604667071⟩,
  ⟨3825/32, 30675/256, 28607497909115134283⟩,
  ⟨30675/256, 15375/128, 30580149636896986930⟩,
  ⟨15375/128, 30825/256, 33665198135204835555⟩,
  ⟨30825/256, 7725/64, 37513374299151867932⟩,
  ⟨7725/64, 30975/256, 41443405605956092851⟩,
  ⟨30975/256, 15525/128, 46044662932379769758⟩,
  ⟨15525/128, 31125/256, 51110616417651011473⟩,
  ⟨31125/256, 975/8, 56399114590693894414⟩,
  ⟨975/8, 31275/256, 61646747557283211443⟩,
  ⟨31275/256, 15675/128, 66585603690933703639⟩,
  ⟨15675/128, 31425/256, 70327896253069507472⟩,
  ⟨31425/256, 7875/64, 73077078756338262244⟩,
  ⟨7875/64, 31575/256, 74871145262507588104⟩,
  ⟨31575/256, 15825/128, 75580012904640389930⟩,
  ⟨15825/128, 31725/256, 75127833468297502135⟩,
  ⟨31725/256, 3975/32, 73498320134398353024⟩,
  ⟨3975/32, 31875/256, 70729114520449146419⟩,
  ⟨31875/256, 15975/128, 65960328290956620194⟩,
  ⟨15975/128, 32025/256, 60372328438746668382⟩,
  ⟨32025/256, 8025/64, 54228851324225560993⟩,
  ⟨8025/64, 32175/256, 47826447026258107622⟩,
  ⟨32175/256, 16125/128, 41480705806266704296⟩,
  ⟨16125/128, 32325/256, 35509478189413577685⟩,
  ⟨32325/256, 2025/16, 30174549821598252858⟩,
  ⟨2025/16, 32475/256, 25763881444588009695⟩,
  ⟨32475/256, 16275/128, 22309766301753249299⟩,
  ⟨16275/128, 32625/256, 19783796898274434440⟩,
  ⟨32625/256, 8175/64, 18799476500625519327⟩,
  ⟨8175/64, 32775/256, 19440483830057449148⟩,
  ⟨32775/256, 16425/128, 21698393728877430058⟩,
  ⟨16425/128, 32925/256, 24715779567399039408⟩,
  ⟨32925/256, 4125/32, 28913780770429705980⟩,
  ⟨4125/32, 33075/256, 34326813241878291397⟩,
  ⟨33075/256, 16575/128, 40705877672640067263⟩,
  ⟨16575/128, 33225/256, 47750469277160081991⟩,
  ⟨33225/256, 8325/64, 55122284904382646319⟩,
  ⟨8325/64, 33375/256, 62461348208198745063⟩,
  ⟨33375/256, 16725/128, 69317113115334851188⟩,
  ⟨16725/128, 33525/256, 75429617663875476496⟩,
  ⟨33525/256, 525/4, 80497460565718583058⟩,
  ⟨525/4, 33675/256, 84261380116475298530⟩,
  ⟨33675/256, 16875/128, 85889917632234796939⟩,
  ⟨16875/128, 33825/256, 85813515423569478004⟩,
  ⟨33825/256, 8475/64, 83588937119775358002⟩,
  ⟨8475/64, 33975/256, 79405616830409444559⟩,
  ⟨33975/256, 17025/128, 73904155941839478802⟩,
  ⟨17025/128, 34125/256, 67348993167456102617⟩,
  ⟨34125/256, 4275/32, 60058841611510237441⟩,
  ⟨4275/32, 34275/256, 52390433389547066550⟩,
  ⟨34275/256, 17175/128, 44698997379648687926⟩,
  ⟨17175/128, 34425/256, 37325082447691360420⟩,
  ⟨34425/256, 8625/64, 30681272972102667049⟩,
  ⟨8625/64, 34575/256, 25111406235539672478⟩,
  ⟨34575/256, 17325/128, 20893006169283939959⟩,
  ⟨17325/128, 34725/256, 18235890806228030304⟩,
  ⟨34725/256, 2175/16, 17272409815661240012⟩,
  ⟨2175/16, 34875/256, 17447278139357304636⟩,
  ⟨34875/256, 17475/128, 18236371269544380445⟩,
  ⟨17475/128, 35025/256, 20718293526143939942⟩,
  ⟨35025/256, 8775/64, 24775641247661828900⟩,
  ⟨8775/64, 35175/256, 30207187312731574913⟩,
  ⟨35175/256, 17625/128, 36744319873656272304⟩,
  ⟨17625/128, 35325/256, 44065490774523091518⟩,
  ⟨35325/256, 4425/32, 51767140873933916455⟩,
  ⟨4425/32, 35475/256, 59467101868025839651⟩,
  ⟨35475/256, 17775/128, 66838710567063677488⟩,
  ⟨17775/128, 35625/256, 73524299407693679251⟩,
  ⟨35625/256, 8925/64, 79202874847498164821⟩,
  ⟨8925/64, 35775/256, 83605426903176160919⟩,
  ⟨35775/256, 17925/128, 86443952820940235256⟩,
  ⟨17925/128, 35925/256, 86784971387714615619⟩,
  ⟨35925/256, 1125/8, 85524307145043886573⟩,
  ⟨1125/8, 36075/256, 82069163210198867167⟩,
  ⟨36075/256, 18075/128, 77220826162391360267⟩,
  ⟨18075/128, 36225/256, 71294466315105505943⟩,
  ⟨36225/256, 9075/64, 64589404161557753467⟩,
  ⟨9075/64, 36375/256, 57399126095913412195⟩,
  ⟨36375/256, 18225/128, 50091723585220384787⟩,
  ⟨18225/128, 36525/256, 43066736433587324854⟩,
  ⟨36525/256, 4575/32, 36665698339925912164⟩,
  ⟨4575/32, 36675/256, 31194625618281983569⟩,
  ⟨36675/256, 18375/128, 26908488242860825421⟩,
  ⟨18375/128, 36825/256, 23999079786139849961⟩,
  ⟨36825/256, 9225/64, 21749853322634983411⟩,
  ⟨9225/64, 36975/256, 20943232141720526254⟩,
  ⟨36975/256, 18525/128, 21745452688333537499⟩,
  ⟨18525/128, 37125/256, 24096291437559613422⟩,
  ⟨37125/256, 2325/16, 27526700951985303559⟩,
  ⟨2325/16, 37275/256, 31767816251332789258⟩,
  ⟨37275/256, 18675/128, 36991747934387969552⟩,
  ⟨18675/128, 37425/256, 42848560651464502875⟩,
  ⟨37425/256, 9375/64, 49115395511411643022⟩,
  ⟨9375/64, 37575/256, 55481808602286049108⟩,
  ⟨37575/256, 18825/128, 61635311324491268975⟩,
  ⟨18825/128, 37725/256, 67281547108599386511⟩,
  ⟨37725/256, 4725/32, 72158585011172964751⟩,
  ⟨4725/32, 37875/256, 75444117652637132412⟩,
  ⟨37875/256, 18975/128, 77241511029319985177⟩,
  ⟨18975/128, 38025/256, 77877131066926333678⟩,
  ⟨38025/256, 9525/64, 77363598869322081184⟩,
  ⟨9525/64, 38175/256, 75770809368940670970⟩,
  ⟨38175/256, 19125/128, 73221009541772224324⟩,
  ⟨19125/128, 38325/256, 69860045284423911851⟩,
  ⟨38325/256, 150, 65127498090562825754⟩,
  ⟨150, 38475/256, 60036148030580423784⟩,
  ⟨38475/256, 19275/128, 54877528346797648754⟩,
  ⟨19275/128, 38625/256, 49910895456725504502⟩,
  ⟨38625/256, 9675/64, 45376804965642327695⟩,
  ⟨9675/64, 38775/256, 41484662993072676753⟩,
  ⟨38775/256, 19425/128, 38022797268672368762⟩,
  ⟨19425/128, 38925/256, 34906245358185695435⟩,
  ⟨38925/256, 4875/32, 32862068156428480168⟩,
  ⟨4875/32, 39075/256, 31953328699552480485⟩,
  ⟨39075/256, 19575/128, 32183318067664029741⟩,
  ⟨19575/128, 39225/256, 33497014266375420436⟩,
  ⟨39225/256, 9825/64, 35786215143641002771⟩,
  ⟨9825/64, 39375/256, 38848039294577127868⟩,
  ⟨39375/256, 19725/128, 42505399072313067966⟩,
  ⟨19725/128, 39525/256, 46214683636718980872⟩,
  ⟨39525/256, 2475/16, 49775814304545971982⟩,
  ⟨2475/16, 39675/256, 53364379355538690852⟩,
  ⟨39675/256, 19875/128, 56797483684819834972⟩,
  ⟨19875/128, 39825/256, 59764312551186289555⟩,
  ⟨39825/256, 9975/64, 61455077466477922387⟩,
  ⟨9975/64, 39975/256, 62646697043922632669⟩,
  ⟨39975/256, 20025/128, 63323752219926588691⟩,
  ⟨20025/128, 40125/256, 63503104058808504743⟩,
  ⟨40125/256, 5025/32, 63230797540248082925⟩,
  ⟨5025/32, 40275/256, 62572365702462719437⟩,
  ⟨40275/256, 20175/128, 61573660375437440569⟩,
  ⟨20175/128, 40425/256, 60352850296858370864⟩,
  ⟨40425/256, 10125/64, 59054097289191287827⟩,
  ⟨10125/64, 40575/256, 57782170988295869503⟩,
  ⟨40575/256, 20325/128, 56605536867411692171⟩,
  ⟨20325/128, 40725/256, 54913038532793712906⟩,
  ⟨40725/256, 1275/8, 53504212785855570846⟩,
  ⟨1275/8, 40875/256, 51541140566141227320⟩,
  ⟨40875/256, 20475/128, 49915447458335164304⟩,
  ⟨20475/128, 41025/256, 48763073335074185152⟩,
  ⟨41025/256, 10275/64, 48103143381624576821⟩,
  ⟨10275/64, 41175/256, 47922661813237921656⟩,
  ⟨41175/256, 20625/128, 48178862433168179839⟩,
  ⟨20625/128, 41325/256, 48793858724185591178⟩,
  ⟨41325/256, 5175/32, 49615826152702649971⟩,
  ⟨5175/32, 41475/256, 50624650291997115952⟩,
  ⟨41475/256, 20775/128, 51724592528290745659⟩,
  ⟨20775/128, 41625/256, 52820094076369909070⟩,
  ⟨41625/256, 10425/64, 53824996525742255900⟩,
  ⟨10425/64, 41775/256, 54667145187341965700⟩,
  ⟨41775/256, 20925/128, 54220034631875780198⟩,
  ⟨20925/128, 41925/256, 52947499809246157980⟩,
  ⟨41925/256, 2625/16, 51568491056413193200⟩,
  ⟨2625/16, 42075/256, 50179009873022755825⟩,
  ⟨42075/256, 21075/128, 48885667599606869997⟩,
  ⟨21075/128, 42225/256, 47798404217869369192⟩,
  ⟨42225/256, 10575/64, 47002887221971245719⟩,
  ⟨10575/64, 42375/256, 46551476750207841499⟩,
  ⟨42375/256, 21225/128, 46583876752694365657⟩,
  ⟨21225/128, 42525/256, 47158232145429803289⟩,
  ⟨42525/256, 5325/32, 48297390669412202945⟩,
  ⟨5325/32, 42675/256, 49989502395062571410⟩,
  ⟨42675/256, 21375/128, 52186906729000286535⟩,
  ⟨21375/128, 42825/256, 54371427425385125104⟩,
  ⟨42825/256, 10725/64, 56340246009807036736⟩,
  ⟨10725/64, 42975/256, 58483109540348125403⟩,
  ⟨42975/256, 21525/128, 60088094374827568291⟩,
  ⟨21525/128, 43125/256, 61725720827571940601⟩,
  ⟨43125/256, 675/4, 63282929503220445123⟩,
  ⟨675/4, 43275/256, 64641375984455595913⟩,
  ⟨43275/256, 21675/128, 65631898429961559676⟩,
  ⟨21675/128, 43425/256, 66173653532697064466⟩,
  ⟨43425/256, 10875/64, 66219001706537033021⟩,
  ⟨10875/64, 43575/256, 65712508735354192200⟩,
  ⟨43575/256, 21825/128, 64629189923425911324⟩,
  ⟨21825/128, 43725/256, 62978214851545151905⟩,
  ⟨43725/256, 5475/32, 60603296206676343723⟩,
  ⟨5475/32, 43875/256, 57026523251954361564⟩,
  ⟨43875/256, 21975/128, 53186350069221632842⟩,
  ⟨21975/128, 44025/256, 49273851995722126937⟩,
  ⟨44025/256, 11025/64, 45488862194788925372⟩,
  ⟨11025/64, 44175/256, 41594851572399381220⟩,
  ⟨44175/256, 22125/128, 37970545476769854486⟩,
  ⟨22125/128, 44325/256, 35069968218321993144⟩,
  ⟨44325/256, 2775/16, 33093043021134835797⟩,
  ⟨2775/16, 44475/256, 32210538222564489510⟩,
  ⟨44475/256, 22275/128, 32509763125194711042⟩,
  ⟨22275/128, 44625/256, 34019117754201545755⟩,
  ⟨44625/256, 11175/64, 36704880684643483743⟩,
  ⟨11175/64, 44775/256, 40471122262212879683⟩,
  ⟨44775/256, 22425/128, 44218030467844932805⟩,
  ⟨22425/128, 44925/256, 48704686231512106725⟩,
  ⟨44925/256, 5625/32, 53762052467000287237⟩,
  ⟨5625/32, 45075/256, 59153254856419633896⟩,
  ⟨45075/256, 22575/128, 64615917067173414935⟩,
  ⟨22575/128, 45225/256, 69875183077066448080⟩,
  ⟨45225/256, 11325/64, 74530640234647556526⟩,
  ⟨11325/64, 45375/256, 77758589052664715312⟩,
  ⟨45375/256, 22725/128, 80064057613491389779⟩,
  ⟨22725/128, 45525/256, 81296861272383532622⟩,
  ⟨45525/256, 1425/8, 81356573491706609110⟩,
  ⟨1425/8, 45675/256, 80200221521314685626⟩,
  ⟨45675/256, 22875/128, 77846310609759275949⟩,
  ⟨22875/128, 45825/256, 73665526123741542415⟩,
  ⟨45825/256, 11475/64, 68287444589101411708⟩,
  ⟨11475/64, 45975/256, 62222344874776314539⟩,
  ⟨45975/256, 23025/128, 55758720018862309050⟩,
  ⟨23025/128, 46125/256, 49211619182205276457⟩,
  ⟨46125/256, 5775/32, 42907030273952329368⟩,
  ⟨5775/32, 46275/256, 37145799691194106923⟩,
  ⟨46275/256, 23175/128, 32181690228661443558⟩,
  ⟨23175/128, 46425/256, 28331899405567601721⟩,
  ⟨46425/256, 11625/64, 25340089252706490573⟩,
  ⟨11625/64, 46575/256, 23607872756063502286⟩,
  ⟨46575/256, 23325/128, 23489948971389910409⟩,
  ⟨23325/128, 46725/256, 25012190880340704726⟩,
  ⟨46725/256, 2925/16, 27635385156746285962⟩,
  ⟨2925/16, 46875/256, 31237737471816962239⟩,
  ⟨46875/256, 23475/128, 36159233155456860170⟩,
  ⟨23475/128, 47025/256, 42175190240630560375⟩,
  ⟨47025/256, 11775/64, 49003024822456946588⟩,
  ⟨11775/64, 47175/256, 56315878628033718638⟩,
  ⟨47175/256, 23625/128, 63758751051612468115⟩,
  ⟨23625/128, 47325/256, 70909524655838690586⟩,
  ⟨47325/256, 5925/32, 77443423941941998063⟩,
  ⟨5925/32, 47475/256, 83060733513001683296⟩,
  ⟨47475/256, 23775/128, 87477143957102959983⟩,
  ⟨23775/128, 47625/256, 90308524450201161701⟩,
  ⟨47625/256, 11925/64, 90976473314164026063⟩,
  ⟨11925/64, 47775/256, 89767835559891589332⟩,
  ⟨47775/256, 23925/128, 86253475195998888942⟩,
  ⟨23925/128, 47925/256, 81320772542680140012⟩,
  ⟨47925/256, 375/2, 75206025528078276631⟩,
  ⟨375/2, 48075/256, 68205329147810636291⟩,
  ⟨48075/256, 24075/128, 60659872713385409187⟩,
  ⟨24075/128, 48225/256, 52932667985610993792⟩,
  ⟨48225/256, 12075/64, 45359919252148579428⟩,
  ⟨12075/64, 48375/256, 38337037429274596511⟩,
  ⟨48375/256, 24225/128, 32238026738240248027⟩,
  ⟨24225/128, 48525/256, 27363785400206756627⟩,
  ⟨48525/256, 6075/32, 23954584666440346862⟩,
  ⟨6075/32, 48675/256, 22178163097248042064⟩,
  ⟨48675/256, 24375/128, 22083294803615112564⟩,
  ⟨24375/128, 48825/256, 22249505828787403424⟩,
  ⟨48825/256, 12225/64, 23915341149958045499⟩,
  ⟨12225/64, 48975/256, 27211274290129688024⟩,
  ⟨48975/256, 24525/128, 31972397443138236494⟩,
  ⟨24525/128, 49125/256, 37961917613618041133⟩,
  ⟨49125/256, 3075/16, 44883046474353500905⟩,
  ⟨3075/16, 49275/256, 52376954266798281070⟩,
  ⟨49275/256, 24675/128, 60026166586348242689⟩,
  ⟨24675/128, 49425/256, 67522436211653157308⟩,
  ⟨49425/256, 12375/64, 74501615195348284080⟩,
  ⟨12375/64, 49575/256, 80627430993759995614⟩,
  ⟨49575/256, 24825/128, 85607985953212796819⟩,
  ⟨24825/128, 49725/256, 89210099233836535698⟩,
  ⟨49725/256, 6225/32, 90518844653546506578⟩,
  ⟨6225/32, 49875/256, 90026284179873735782⟩,
  ⟨49875/256, 24975/128, 87795316077309858421⟩,
  ⟨24975/128, 50025/256, 83617095741179876388⟩,
  ⟨50025/256, 12525/64, 78254017832730418650⟩,
  ⟨12525/64, 50175/256, 71983333441050802210⟩,
  ⟨50175/256, 25125/128, 65101810248976499797⟩,
  ⟨25125/128, 50325/256, 57915841454412636161⟩,
  ⟨50325/256, 1575/8, 50841065178156964900⟩,
  ⟨1575/8, 50475/256, 44222503040783814211⟩,
  ⟨50475/256, 25275/128, 38377415447174748690⟩,
  ⟨25275/128, 50625/256, 33579655756584467220⟩,
  ⟨50625/256, 12675/64, 30046643783502892591⟩,
  ⟨12675/64, 50775/256, 27405090521057811367⟩,
  ⟨50775/256, 25425/128, 25836159185006862438⟩,
  ⟨25425/128, 50925/256, 25846500176051476956⟩,
  ⟨50925/256, 6375/32, 27412705407155395647⟩,
  ⟨6375/32, 51075/256, 30401040592065396102⟩,
  ⟨51075/256, 25575/128, 34148532497414502680⟩,
  ⟨25575/128, 51225/256, 38791423800893120006⟩,
  ⟨51225/256, 12825/64, 44202497280002791459⟩,
  ⟨12825/64, 51375/256, 50136294350749876060⟩,
  ⟨51375/256, 25725/128, 56312945549595846426⟩,
  ⟨25725/128, 51525/256, 62425540775269329934⟩,
  ⟨51525/256, 3225/16, 68177958243918065455⟩,
  ⟨3225/16, 51675/256, 73299534043193491155⟩,
  ⟨51675/256, 25875/128, 77268724539308163688⟩,
  ⟨25875/128, 51825/256, 79530222778153047071⟩,
  ⟨51825/256, 12975/64, 80690128343636861445⟩,
  ⟨12975/64, 51975/256, 80734477752936442790⟩,
  ⟨51975/256, 26025/128, 79706252291891261380⟩,
  ⟨26025/128, 52125/256, 77701164559639287201⟩,
  ⟨52125/256, 6525/32, 74854096909576440258⟩,
  ⟨6525/32, 52275/256, 71055064831301975328⟩,
  ⟨52275/256, 26175/128, 66294882800731318557⟩,
  ⟨26175/128, 52425/256, 61348460117901424412⟩,
  ⟨52425/256, 13125/64, 56468837522528707860⟩,
  ⟨13125/64, 52575/256, 51895936741959671914⟩,
  ⟨52575/256, 26325/128, 47844490531359838878⟩,
  ⟨26325/128, 52725/256, 44436534930297145511⟩,
  ⟨52725/256, 825/4, 40958309456017009712⟩,
  ⟨825/4, 52875/256, 38460916569417591280⟩,
  ⟨52875/256, 26475/128, 37031059889847099103⟩,
  ⟨26475/128, 53025/256, 36697735600123202752⟩,
  ⟨53025/256, 13275/64, 37433065684679355640⟩,
  ⟨13275/64, 53175/256, 39155860256946913509⟩,
  ⟨53175/256, 26625/128, 41717418982211159405⟩,
  ⟨26625/128, 53325/256, 44912534369785180105⟩,
  ⟨53325/256, 6675/32, 48562502572096893558⟩,
  ⟨6675/32, 53475/256, 51967403622616190403⟩,
  ⟨53475/256, 26775/128, 55327354558180830681⟩,
  ⟨26775/128, 53625/256, 58617600614057308797⟩,
  ⟨53625/256, 13425/64, 61674964432187750735⟩,
  ⟨13425/64, 53775/256, 63571275258115263153⟩,
  ⟨53775/256, 26925/128, 64851954518636621336⟩,
  ⟨26925/128, 53925/256, 65667972340524245418⟩,
  ⟨53925/256, 3375/16, 66025357054935357563⟩,
  ⟨3375/16, 54075/256, 65958846162235127476⟩,
  ⟨54075/256, 27075/128, 65527779587694586618⟩,
  ⟨27075/128, 54225/256, 64786648536582945741⟩,
  ⟨54225/256, 13575/64, 63795413957265426287⟩,
  ⟨13575/64, 54375/256, 62710482769131360502⟩,
  ⟨54375/256, 27225/128, 61629981118778501831⟩,
  ⟨27225/128, 54525/256, 60642841622227678151⟩,
  ⟨54525/256, 6825/32, 59533712581409464304⟩,
  ⟨6825/32, 54675/256, 58202820658252617037⟩,
  ⟨54675/256, 27375/128, 56603484773224534832⟩,
  ⟨27375/128, 54825/256, 54951143771862229312⟩,
  ⟨54825/256, 13725/64, 53714394386074846456⟩,
  ⟨13725/64, 54975/256, 52920669284764475815⟩,
  ⟨54975/256, 27525/128, 52566511703328554225⟩,
  ⟨27525/128, 55125/256, 52619775080526323284⟩,
  ⟨55125/256, 1725/8, 53023645214779235229⟩,
  ⟨1725/8, 55275/256, 53640564565949473684⟩,
  ⟨55275/256, 27675/128, 54428930536172544449⟩,
  ⟨27675/128, 55425/256, 55316314710412217545⟩,
  ⟨55425/256, 13875/64, 56213547807939825247⟩,
  ⟨13875/64, 55575/256, 57039235654881678903⟩,
  ⟨55575/256, 27825/128, 57725633576199295399⟩,
  ⟨27825/128, 55725/256, 57832444312892368315⟩,
  ⟨55725/256, 6975/32, 56553854099341088306⟩,
  ⟨6975/32, 55875/256, 55027309057222988717⟩,
  ⟨55875/256, 27975/128, 53475517411623520399⟩,
  ⟨27975/128, 56025/256, 52007085331684060526⟩,
  ⟨56025/256, 14025/64, 50735686278361006074⟩,
  ⟨14025/64, 56175/256, 49765631344659565835⟩,
  ⟨56175/256, 28125/128, 49154213068547724945⟩,
  ⟨28125/128, 56325/256, 49016603534100583692⟩,
  ⟨56325/256, 3525/16, 49436776839964050811⟩,
  ⟨3525/16, 56475/256, 50446511937878202180⟩,
  ⟨56475/256, 28275/128, 52043029955583352253⟩,
  ⟨28275/128, 56625/256, 54186950396655782484⟩,
  ⟨56625/256, 14175/64, 56708550178553813473⟩,
  ⟨14175/64, 56775/256, 58727288188749383388⟩,
  ⟨56775/256, 28425/128, 61027615860152278649⟩,
  ⟨28425/128, 56925/256, 63165658175753674973⟩,
  ⟨56925/256, 7125/32, 64945935437149151756⟩,
  ⟨7125/32, 57075/256, 66663842207673071876⟩,
  ⟨57075/256, 28575/128, 68197720369440525865⟩,
  ⟨28575/128, 57225/256, 69403588146119930565⟩,
  ⟨57225/256, 14325/64, 70140242336361254714⟩,
  ⟨14325/64, 57375/256, 70373349202383328332⟩,
  ⟨57375/256, 28725/128, 70037871227701879012⟩,
  ⟨28725/128, 57525/256, 69098863937034273271⟩,
  ⟨57525/256, 225, 67555672194236998072⟩,
  ⟨225, 57675/256, 65444208615270243018⟩,
  ⟨57675/256, 28875/128, 62017690473353411029⟩,
  ⟨28875/128, 57825/256, 58109338794607527157⟩,
  ⟨57825/256, 14475/64, 54046840436042985137⟩,
  ⟨14475/64, 57975/256, 50036806605318999927⟩,
  ⟨57975/256, 29025/128, 46208604499431545207⟩,
  ⟨29025/128, 58125/256, 42304335723641102266⟩,
  ⟨58125/256, 7275/32, 38973778289265590565⟩,
  ⟨7275/32, 58275/256, 36490132249868354728⟩,
  ⟨58275/256, 29175/128, 35066947705919732897⟩,
  ⟨29175/128, 58425/256, 34815683395234470238⟩,
  ⟨58425/256, 14625/64, 35790544955656001689⟩,
  ⟨14625/64, 58575/256, 37983815519063993029⟩,
  ⟨58575/256, 29325/128, 41324401458116018493⟩,
  ⟨29325/128, 58725/256, 45087170408157450430⟩,
  ⟨58725/256, 3675/16, 49336332573756372191⟩,
  ⟨3675/16, 58875/256, 54260371902115084455⟩,
  ⟨58875/256, 29475/128, 59633170325233031491⟩,
  ⟨29475/128, 59025/256, 65197589151093901830⟩,
  ⟨59025/256, 14775/64, 70678122451976811842⟩,
  ⟨14775/64, 59175/256, 75794927248947390272⟩,
  ⟨59175/256, 29625/128, 79838501347378116340⟩,
  ⟨29625/128, 59325/256, 82642349915791740360⟩,
  ⟨59325/256, 7425/32, 84414320761388131227⟩,
  ⟨7425/32, 59475/256, 85029285084951498094⟩,
  ⟨59475/256, 29775/128, 84417872089878477917⟩,
  ⟨29775/128, 59625/256, 82571841124137368281⟩,
  ⟨59625/256, 14925/64, 79188061836885410722⟩,
  ⟨14925/64, 59775/256, 74161298974729766546⟩,
  ⟨59775/256, 29925/128, 68320484805978663679⟩,
  ⟨29925/128, 59925/256, 61939622193495900402⟩,
  ⟨59925/256, 1875/8, 55325769824566780104⟩,
  ⟨1875/8, 60075/256, 48803948378017160324⟩,
  ⟨60075/256, 30075/128, 42693898670777455159⟩,
  ⟨30075/128, 60225/256, 37263329232296789837⟩,
  ⟨60225/256, 15075/64, 32827996638974755991⟩,
  ⟨15075/64, 60375/256, 29538288666875585946⟩,
  ⟨60375/256, 30225/128, 27129078628997560840⟩,
  ⟨30225/128, 60525/256, 26213242915834338626⟩,
  ⟨60525/256, 7575/32, 26934136887992335334⟩,
  ⟨7575/32, 60675/256, 29146945286705017495⟩,
  ⟨60675/256, 30375/128, 32054163131588977193⟩,
  ⟨30375/128, 60825/256, 36366018206177507515⟩,
  ⟨60825/256, 15225/64, 41888262132510161327⟩,
  ⟨15225/64, 60975/256, 48363591729747755588⟩,
  ⟨60975/256, 30525/128, 55483994818881284650⟩,
  ⟨30525/128, 61125/256, 62905767497354629628⟩,
  ⟨61125/256, 3825/16, 70240426092168715926⟩,
  ⟨3825/16, 61275/256, 77102226197148686309⟩,
  ⟨61275/256, 30675/128, 83200986814557267777⟩,
  ⟨30675/128, 61425/256, 88230969065589674341⟩,
  ⟨61425/256, 15375/64, 91937146157779789617⟩,
  ⟨15375/64, 61575/256, 93708152626136456629⟩,
  ⟨61575/256, 30825/128, 93541685312554040633⟩,
  ⟨30825/128, 61725/256, 90906449672793429563⟩,
  ⟨61725/256, 7725/32, 86665046059010275572⟩,
  ⟨7725/32, 61875/256, 81125626986974156985⟩,
  ⟨61875/256, 30975/128, 74555555867550030940⟩,
  ⟨30975/128, 62025/256, 67274155381891162217⟩,
  ⟨62025/256, 15525/64, 59636847499587276413⟩,
  ⟨15525/64, 62175/256, 51990264389818225203⟩,
  ⟨62175/256, 31125/128, 44687601419503550268⟩,
  ⟨31125/128, 62325/256, 38136639424668830584⟩,
  ⟨62325/256, 975/4, 32658948680249897599⟩,
  ⟨975/4, 62475/256, 28522874160009583982⟩,
  ⟨62475/256, 31275/128, 25930142403084132398⟩,
  ⟨31275/128, 62625/256, 25005817501220579545⟩,
  ⟨62625/256, 15675/64, 25039005996998938354⟩,
  ⟨15675/64, 62775/256, 25891747170466972782⟩,
  ⟨62775/256, 31425/128, 28346616145315574583⟩,
  ⟨31425/128, 62925/256, 32339627836161937415⟩,
  ⟨62925/256, 7875/32, 37670194723955798652⟩,
  ⟨7875/32, 63075/256, 44072426047608770305⟩,
  ⟨63075/256, 31575/128, 51228681062208049943⟩,
  ⟨31575/128, 63225/256, 58720752427537073304⟩,
  ⟨63225/256, 15825/64, 66235656789461903091⟩,
  ⟨15825/64, 63375/256, 73418068448098915863⟩,
  ⟨63375/256, 31725/128, 79920954103791965063⟩,
  ⟨31725/128, 63525/256, 85433440134419630507⟩,
  ⟨63525/256, 3975/16, 89696068095044308278⟩,
  ⟨3975/16, 63675/256, 92125815698774830265⟩,
  ⟨63675/256, 31875/128, 92442843066718749285⟩,
  ⟨31875/128, 63825/256, 91222445879163004106⟩,
  ⟨63825/256, 15975/64, 88084898630897707252⟩,
  ⟨15975/64, 63975/256, 83388961091107565779⟩,
  ⟨63975/256, 32025/128, 77659602318571821480⟩,
  ⟨32025/128, 64125/256, 71183636178044257411⟩,
  ⟨64125/256, 8025/32, 64242912732377461114⟩,
  ⟨8025/32, 64275/256, 57217554802745726704⟩,
  ⟨64275/256, 32175/128, 50468724325147013096⟩,
  ⟨32175/128, 64425/256, 44321616635717979524⟩,
  ⟨64425/256, 16125/64, 39066300132005202107⟩,
  ⟨16125/64, 64575/256, 34943744406995093220⟩,
  ⟨64575/256, 32325/128, 31977710385180230206⟩,
  ⟨32325/128, 64725/256, 29648354614171407057⟩,
  ⟨64725/256, 2025/8, 28845960648256500863⟩,
  ⟨2025/8, 64875/256, 29586008132267223389⟩,
  ⟨64875/256, 32475/128, 31807455309108804869⟩,
  ⟨32475/128, 65025/256, 35217538116526580522⟩,
  ⟨65025/256, 16275/64, 39245394253310714440⟩,
  ⟨16275/64, 65175/256, 44134529844961942868⟩,
  ⟨65175/256, 32625/128, 49650752854995302916⟩,
  ⟨32625/128, 65325/256, 55555542314566558301⟩,
  ⟨65325/256, 8175/32, 61551534046961800458⟩,
  ⟨8175/32, 65475/256, 67344462258989927412⟩,
  ⟨65475/256, 32775/128, 72657942078341681580⟩,
  ⟨32775/128, 65625/256, 77247003926500885109⟩,
  ⟨65625/256, 16425/64, 80037885798587083918⟩,
  ⟨16425/64, 65775/256, 81726300879258240904⟩,
  ⟨65775/256, 32925/128, 82346127095738522680⟩,
  ⟨32925/128, 65925/256, 81911586352975112584⟩,
  ⟨65925/256, 4125/16, 80489732388857849481⟩,
  ⟨4125/16, 66075/256, 78194956912814309306⟩,
  ⟨66075/256, 33075/128, 75152606194309290798⟩,
  ⟨33075/128, 66225/256, 71023030435196923332⟩,
  ⟨66225/256, 16575/64, 66352553584265433115⟩,
  ⟨16575/64, 66375/256, 61619952610046324464⟩,
  ⟨66375/256, 33225/128, 57062366501910493160⟩,
  ⟨33225/128, 66525/256, 52898243079038944166⟩,
  ⟨66525/256, 8325/32, 49316653262595994562⟩,
  ⟨8325/32, 66675/256, 45821931422774551934⟩,
  ⟨66675/256, 33375/128, 42896312488534398116⟩,
  ⟨33375/128, 66825/256, 40956634242171731080⟩,
  ⟨66825/256, 16725/64, 40058252783061392631⟩,
  ⟨16725/64, 66975/256, 40201433021191445631⟩,
  ⟨66975/256, 33525/128, 41333430150999378168⟩,
  ⟨33525/128, 67125/256, 43353313176466708477⟩,
  ⟨67125/256, 525/2, 46052861591363062278⟩,
  ⟨525/2, 67275/256, 49320729074268303178⟩,
  ⟨67275/256, 33675/128, 52784006740047943015⟩,
  ⟨33675/128, 67425/256, 55915400497723057724⟩,
  ⟨67425/256, 16875/64, 59035512937093137439⟩,
  ⟨16875/64, 67575/256, 62014247278949186714⟩,
  ⟨67575/256, 33825/128, 64295222885020208231⟩,
  ⟨33825/128, 67725/256, 65663976781981351308⟩,
  ⟨67725/256, 8475/32, 66620808785919383445⟩,
  ⟨8475/32, 67875/256, 67160513648174070263⟩,
  ⟨67875/256, 33975/128, 67305630483915868696⟩,
  ⟨33975/128, 68025/256, 67103033410736193888⟩,
  ⟨68025/256, 17025/64, 66612109386409863178⟩,
  ⟨17025/64, 68175/256, 65867834391915158393⟩,
  ⟨68175/256, 34125/128, 64997797664642812102⟩,
  ⟨34125/128, 68325/256, 64107529284748446917⟩,
  ⟨68325/256, 4275/16, 63280855698316905554⟩,
  ⟨4275/16, 68475/256, 62588608807077418739⟩,
  ⟨68475/256, 34275/128, 61532613959669311718⟩,
  ⟨34275/128, 68625/256, 60342500772983296011⟩,
  ⟨68625/256, 17175/64, 58677081600343431943⟩,
  ⟨17175/64, 68775/256, 57366006586421383742⟩,
  ⟨68775/256, 34425/128, 56445367969685189225⟩,
  ⟨34425/128, 68925/256, 55922193615349756581⟩,
  ⟨68925/256, 8625/32, 55775912583179321608⟩,
  ⟨8625/32, 69075/256, 55961582978864937636⟩,
  ⟨69075/256, 34575/128, 56384091455734058317⟩,
  ⟨34575/128, 69225/256, 56954271669388953852⟩,
  ⟨69225/256, 17325/64, 57633661069198391427⟩,
  ⟨17325/64, 69375/256, 58340052103223627193⟩,
  ⟨69375/256, 34725/128, 58997008480866024600⟩,
  ⟨34725/128, 69525/256, 59539678395269972766⟩,
  ⟨69525/256, 2175/8, 59919602219143843188⟩,
  ⟨2175/8, 69675/256, 58992365005074000072⟩,
  ⟨69675/256, 34875/128, 57377754101045106484⟩,
  ⟨34875/128, 69825/256, 55699615632494214088⟩,
  ⟨69825/256, 17475/64, 54085850784951076953⟩,
  ⟨17475/64, 69975/256, 52651822953680302836⟩,
  ⟨69975/256, 35025/128, 51512159508269369316⟩,
  ⟨35025/128, 70125/256, 50743135608670707676⟩,
  ⟨70125/256, 8775/32, 50422726180478604978⟩,
  ⟨8775/32, 70275/256, 50664955651616228979⟩,
  ⟨70275/256, 35175/128, 51511048446520392365⟩,
  ⟨35175/128, 70425/256, 52968289100134734842⟩,
  ⟨70425/256, 17625/64, 55007381238456885722⟩,
  ⟨17625/64, 70575/256, 57561955858003987685⟩,
  ⟨70575/256, 35325/128, 59860747863462797318⟩,
  ⟨35325/128, 70725/256, 62200316747879744595⟩,
  ⟨70725/256, 4425/16, 64751365814626233741⟩,
  ⟨4425/16, 70875/256, 66789974096787776568⟩,
  ⟨70875/256, 35475/128, 68642919674918408700⟩,
  ⟨35475/128, 71025/256, 70334437024937793346⟩,
  ⟨71025/256, 17775/64, 71739988188066727782⟩,
  ⟨17775/64, 71175/256, 72677961290079713034⟩,
  ⟨71175/256, 35625/128, 73111376438769155663⟩,
  ⟨35625/128, 71325/256, 72971795057121275369⟩,
  ⟨71325/256, 8925/32, 72213964937293998679⟩,
  ⟨8925/32, 71475/256, 70826332895016571170⟩,
  ⟨71475/256, 35775/128, 68833929621456347582⟩,
  ⟨35775/128, 71625/256, 65860937055320722215⟩,
  ⟨71625/256, 17925/64, 61963726955125233587⟩,
  ⟨17925/64, 71775/256, 57829103586217722700⟩,
  ⟨71775/256, 35925/128, 53661127638950609389⟩,
  ⟨35925/128, 71925/256, 49675708843629704005⟩,
  ⟨71925/256, 1125/4, 45831938056802121662⟩,
  ⟨1125/4, 72075/256, 42120591065024094660⟩,
  ⟨72075/256, 36075/128, 39172740821913042060⟩,
  ⟨36075/128, 72225/256, 37219009077002101449⟩,
  ⟨72225/256, 18075/64, 36406953492797705749⟩,
  ⟨18075/64, 72375/256, 36816590714827993408⟩,
  ⟨72375/256, 36225/128, 38467365614891850971⟩,
  ⟨36225/128, 72525/256, 41315349267561722928⟩,
  ⟨72525/256, 9075/32, 45044039312199338209⟩,
  ⟨9075/32, 72675/256, 48975455917825541031⟩,
  ⟨72675/256, 36375/128, 53677701363841592201⟩,
  ⟨36375/128, 72825/256, 58939479854321474902⟩,
  ⟨72825/256, 18225/64, 64513606093519063944⟩,
  ⟨18225/64, 72975/256, 70128923752627177551⟩,
  ⟨72975/256, 36525/128, 75503827866848874858⟩,
  ⟨36525/128, 73125/256, 80328350592313688223⟩,
  ⟨73125/256, 4575/16, 83699985636891160303⟩,
  ⟨4575/16, 73275/256, 85996898306860396316⟩,
  ⟨73275/256, 36675/128, 87174100695476841079⟩,
  ⟨36675/128, 73425/256, 87136277119626350230⟩,
  ⟨73425/256, 18375/64, 85847601074449380118⟩,
  ⟨18375/64, 73575/256, 83335316994818667458⟩,
  ⟨73575/256, 36825/128, 78776843013534291589⟩,
  ⟨36825/128, 73725/256, 73267239524003626995⟩,
  ⟨73725/256, 9225/32, 67081719606665541985⟩,
  ⟨9225/32, 73875/256, 60514110820461957177⟩,
  ⟨73875/256, 36975/128, 53883184931980029455⟩,
  ⟨36975/128, 74025/256, 47516838592219463820⟩,
  ⟨74025/256, 18525/64, 41704635189558221886⟩,
  ⟨18525/64, 74175/256, 36734945680596581152⟩,
  ⟨74175/256, 37125/128, 32909817319581078527⟩,
  ⟨37125/128, 74325/256, 30141978879964443903⟩,
  ⟨74325/256, 2325/8, 28438091340563109377⟩,
  ⟨2325/8, 74475/256, 28337376526911609148⟩,
  ⟨74475/256, 37275/128, 29865357826866533971⟩,
  ⟨37275/128, 74625/256, 32271810930467473136⟩,
  ⟨74625/256, 18675/64, 35897183183146336667⟩,
  ⟨18675/64, 74775/256, 40831489120612120243⟩,
  ⟨74775/256, 37425/128, 46847187888198408126⟩,
  ⟨37425/128, 74925/256, 53660259301488430365⟩,
  ⟨74925/256, 9375/32, 60943960401312425375⟩,
  ⟨9375/32, 75075/256, 68342397307750534517⟩,
  ⟨75075/256, 37575/128, 75432093011805206076⟩,
  ⟨37575/128, 75225/256, 81921968616004036649⟩,
  ⟨75225/256, 18825/64, 87494418567306733631⟩,
  ⟨18825/64, 75375/256, 91869923819927433544⟩,
  ⟨75375/256, 37725/128, 94826449415807491625⟩,
  ⟨37725/128, 75525/256, 95529811399656382409⟩,
  ⟨75525/256, 4725/16, 94093575381016347376⟩,
  ⟨4725/16, 75675/256, 90621416486973318393⟩,
  ⟨75675/256, 37875/128, 85754397742716000603⟩,
  ⟨37875/128, 75825/256, 79726672195662509435⟩,
  ⟨75825/256, 18975/64, 72830448680976350127⟩,
  ⟨18975/64, 75975/256, 65401506938582552692⟩,
  ⟨75975/256, 38025/128, 57795610520683792960⟩,
  ⟨38025/128, 76125/256, 50338217255136082127⟩,
  ⟨76125/256, 9525/32, 43436459645533897362⟩,
  ⟨9525/32, 76275/256, 37438859649047660816⟩,
  ⟨76275/256, 38175/128, 32637953436899254899⟩,
  ⟨38175/128, 76425/256, 29266754129246516189⟩,
  ⟨76425/256, 19125/64, 27487196444279702094⟩,
  ⟨19125/64, 76575/256, 27149115276698782472⟩,
  ⟨76575/256, 38325/128, 27459343772969649179⟩,
  ⟨38325/128, 76725/256, 29033375186341163408⟩,
  ⟨76725/256, 300, 32194117315680057239⟩
]

def cellPayloadOK (expected : ℚ) (c : FiniteCellV1) : Bool :=
  decide (c.lo = expected ∧ c.lo < c.hi ∧
    (1 / 100000 : ℚ) < lowerValue c)

def chainPayloadOK : ℚ → List FiniteCellV1 → Bool
  | x, [] => decide (x = 300)
  | x, c :: cs => cellPayloadOK x c && chainPayloadOK c.hi cs


set_option maxRecDepth 16384 in
set_option maxHeartbeats 32000000 in
theorem finiteCells_count_v1 : finiteCells.length = 2199 := by
  decide

set_option maxRecDepth 32768 in
set_option maxHeartbeats 128000000 in
theorem finiteCells_payload_valid_v1 :
    chainPayloadOK 0 finiteCells = true := by
  norm_num [chainPayloadOK, cellPayloadOK, lowerValue, finiteCells]

/-- The exact payload has at least one cell. -/
theorem finiteCells_ne_nil_v1 : finiteCells ≠ [] := by
  intro h
  have hc := finiteCells_count_v1
  rw [h] at hc
  simp at hc

/-- A payload accepted by the executable chain checker covers [start,300].
The returned cell also carries the serialized strict lower-bound fact. -/
theorem exists_cell_of_chainPayloadOK_v1
    {start : ℚ} {cells : List FiniteCellV1}
    (hchain : chainPayloadOK start cells = true) (hne : cells ≠ [])
    {t : ℝ} (hstart : (start : ℝ) ≤ t) (hfinish : t ≤ 300) :
    ∃ c ∈ cells,
      (c.lo : ℝ) ≤ t ∧ t ≤ (c.hi : ℝ) ∧
        (1 / 100000 : ℚ) < lowerValue c := by
  induction cells generalizing start with
  | nil =>
      exact False.elim (hne rfl)
  | cons c cs ih =>
      simp only [chainPayloadOK, Bool.and_eq_true] at hchain
      rcases hchain with ⟨hcell, hrest⟩
      simp only [cellPayloadOK, decide_eq_true_eq] at hcell
      rcases hcell with ⟨hcstart, hwidth, hlower⟩
      have hleft : (c.lo : ℝ) ≤ t := by
        rw [hcstart]
        exact hstart
      by_cases ht : t ≤ (c.hi : ℝ)
      · exact ⟨c, by simp, hleft, ht, hlower⟩
      · have hnext : (c.hi : ℝ) ≤ t := le_of_lt (lt_of_not_ge ht)
        by_cases hcs : cs = []
        · subst cs
          simp only [chainPayloadOK, decide_eq_true_eq] at hrest
          have hc300 : (c.hi : ℝ) = 300 := by exact_mod_cast hrest
          have h300le : (300 : ℝ) ≤ t := by simpa [hc300] using hnext
          have ht300 : t = 300 := le_antisymm hfinish h300le
          rw [ht300, hc300] at ht
          exact False.elim (ht le_rfl)
        · obtain ⟨d, hdmem, hdlo, hdhi, hdlower⟩ :=
            ih hrest hcs hnext
          exact ⟨d, by simp [hdmem], hdlo, hdhi, hdlower⟩

/-- The exact 2199-cell payload covers every real frequency in [0,300], and
the cell containing that frequency has serialized dyadic lower endpoint
strictly above 1/100000. -/
theorem finiteCells_cover_zero_three_hundred_v1
    {t : ℝ} (ht0 : 0 ≤ t) (ht300 : t ≤ 300) :
    ∃ c ∈ finiteCells,
      (c.lo : ℝ) ≤ t ∧ t ≤ (c.hi : ℝ) ∧
        (1 / 100000 : ℚ) < lowerValue c := by
  exact exists_cell_of_chainPayloadOK_v1 finiteCells_payload_valid_v1
    finiteCells_ne_nil_v1 (by simpa using ht0) ht300

end AEGIS.RHKreinFiniteCertificateDataV1

#print axioms AEGIS.RHKreinFiniteCertificateDataV1.finiteCells_count_v1
#print axioms AEGIS.RHKreinFiniteCertificateDataV1.finiteCells_payload_valid_v1
~~~~~~

## AEGISOverlay.RHKreinRationalCertificateV1

Path: `source/AEGISOverlay/RHKreinRationalCertificateV1.lean`

Original source lines: 1–231

Full file SHA256: `22b4e5a540176b87314154582bb7da6cdbb602b99c340bcdbc1bb9441865d4e1`

Origin: Operator source archive; see archive_source_records.json

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinDigammaMonotonicityV1
import RHKreinPrimeSymbolV1
import AEGISOverlay.RHKreinExplicitCorrectionV1

/-!
# Exact infinite-tail bounds for the rational order-19 certificate

The digamma endpoint is evaluated in exact rational arithmetic. The existing
series and monotonicity theorems transport it to every real frequency outside
[-300, 300]. All logarithmic and prime factors refer to the actual symbol in
`RHKreinPrimeSymbolV1`. No ball-arithmetic output is a theorem premise.
-/

open Complex
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinRationalCertificateV1

open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.RHKreinDigammaMonotonicityV1
open AEGIS.RHKreinPrimeSymbolV1
open AEGIS.RHKreinSymbolIntegrationV1
open AEGIS.RHKreinExplicitCorrectionV1

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
/-- Exact rational endpoint calculation, with sixty-four proved series terms. -/
theorem digamma_tail_endpoint :
    (4 : ℝ) ≤ -(5792 / 10000 : ℝ) +
      (∑ n ∈ Finset.range 64, quarterTerm 300 n) -
      (3 / 4 : ℝ) * (1 / ((64 : ℝ) + 1 / 4) +
        1 / ((64 : ℝ) + 1 / 4) ^ 2) := by
  norm_num [quarterTerm, Finset.sum_range_succ]

/-- The actual quarter-line digamma real part is at least four on the tail. -/
theorem digamma_tail_lower (t : ℝ) (ht : 300 ≤ |t|) :
    (4 : ℝ) ≤ (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * I / 2)).re := by
  have hs : (300 : ℝ) ^ 2 ≤ t ^ 2 := by
    nlinarith [sq_abs t, abs_nonneg t]
  exact digamma_tail_endpoint.trans
    (digamma_quarter_certificate_lower_of_sq_le 300 t 64 hs)

private theorem log_two_le_seven_tenths : Real.log 2 ≤ (7 / 10 : ℝ) := by
  have h := Real.log_two_lt_d9
  norm_num at h
  linarith

private theorem log_pi_le_seven_fifths : Real.log Real.pi ≤ (7 / 5 : ℝ) := by
  have h : Real.log Real.pi ≤ Real.log 4 :=
    Real.log_le_log Real.pi_pos Real.pi_lt_four.le
  have he : Real.log (4 : ℝ) = 2 * Real.log 2 := by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.log_pow]
    norm_num
  rw [he] at h
  linarith [log_two_le_seven_tenths]

private theorem prime_amplitude_le_twenty_one_twentieths :
    Real.sqrt 2 * Real.log 2 ≤ (21 / 20 : ℝ) := by
  have hs : Real.sqrt 2 ≤ (3 / 2 : ℝ) := by
    have hh := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    nlinarith [Real.sqrt_nonneg (2 : ℝ)]
  have hl : 0 ≤ Real.log (2 : ℝ) := Real.log_nonneg (by norm_num)
  have hm := mul_le_mul hs log_two_le_seven_tenths hl (by norm_num : (0 : ℝ) ≤ 3 / 2)
  norm_num at hm
  exact hm

/-- A uniform positive lower bound for the actual finite-window Weil symbol. -/
theorem actual_symbol_tail_lower (t : ℝ) (ht : 300 ≤ |t|) :
    (3 / 2 : ℝ) ≤ symbol t := by
  have hp : 0 ≤ Real.sqrt 2 * Real.log 2 :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.log_nonneg (by norm_num))
  have hc := mul_le_mul_of_nonneg_left (Real.cos_le_one (t * Real.log 2)) hp
  simp only [mul_one] at hc
  unfold symbol archSymbol
  linarith [digamma_tail_lower t ht, log_pi_le_seven_fifths,
    prime_amplitude_le_twenty_one_twentieths]

/-- A polynomial envelope for the exact certificate fits below its rational
spectral budget on the entire infinite tail. -/
theorem correction_polynomial_tail_bound (x : ℝ) (hx : 300 ≤ x) :
    772000 + 4900 * x + 292 * x ^ 2 + 13 * x ^ 3 + x ^ 4 ≤
      (17 / 16 : ℝ) * (x ^ 2 + 1 / 4) ^ 2 := by
  have hy : 0 ≤ x - 300 := by linarith
  have hp : 0 ≤ (x - 300) ^ 4 / 16 + 62 * (x - 300) ^ 3 +
      (696273 / 32 : ℝ) * (x - 300) ^ 2 +
      (12240875 / 4 : ℝ) * (x - 300) + 32454608017 / 256 := by positivity
  nlinarith only [hp]

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
/-- Exact coefficient arithmetic, independent of interval-enclosure output. -/
theorem hat_coefficient_budget :
    (∑ j : Fin 199, |(hatCoefficient j : ℝ)|) ≤ 18125000 := by
  have h : (∑ j : Fin 199, |hatCoefficient j|) ≤ (18125000 : ℚ) := by
    norm_num [hatCoefficient, Fin.sum_univ_succ]
  exact_mod_cast h

private theorem spline_coefficient_budget (j : Fin 5) :
    |(splineCoefficient j : ℝ)| ≤ ![(47000 : ℝ), 4900, 292, 13, 1] j := by
  fin_cases j <;> norm_num [splineCoefficient]

private theorem abs_phase_le_one (j : Fin 5) (t : ℝ) :
    |if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
      else Real.sin (t * (1619 / 2000))| ≤ 1 := by
  split_ifs
  · exact Real.abs_cos_le_one _
  · exact Real.abs_sin_le_one _

/-- A global polynomial bound for the Fourier expression of the actual
rational genuine-function correction. -/
theorem abs_correctionSymbol_le_polynomial (t : ℝ) :
    |correctionSymbol t| ≤
      772000 + 4900 * |t| + 292 * |t| ^ 2 + 13 * |t| ^ 3 + |t| ^ 4 := by
  have hh : |∑ j : Fin 199, (hatCoefficient j : ℝ) *
      Real.cos (t * hatCenter j)| ≤ 18125000 := by
    calc
      |∑ j : Fin 199, (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j)| ≤
          ∑ j : Fin 199, |(hatCoefficient j : ℝ) * Real.cos (t * hatCenter j)| :=
        Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ j : Fin 199, |(hatCoefficient j : ℝ)| := by
        apply Finset.sum_le_sum
        intro j _
        rw [abs_mul]
        exact mul_le_of_le_one_right (abs_nonneg _) (Real.abs_cos_le_one _)
      _ ≤ 18125000 := hat_coefficient_budget
  have hhat : |(2 / 50 : ℝ) * Real.sinc (t / 100) ^ 2 *
      (∑ j : Fin 199, (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j))| ≤
      725000 := by
    have hp : |Real.sinc (t / 100)| ^ 2 ≤ 1 :=
      pow_le_one₀ (abs_nonneg _) (Real.abs_sinc_le_one _)
    rw [abs_mul, abs_mul, abs_pow]
    norm_num
    have hb := mul_le_mul hp hh (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 1)
    rw [sq_abs] at hb
    nlinarith only [hb]
  have hs : |∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
      (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
        else Real.sin (t * (1619 / 2000)))| ≤
      47000 + 4900 * |t| + 292 * |t| ^ 2 + 13 * |t| ^ 3 + |t| ^ 4 := by
    calc
      |∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
          (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
            else Real.sin (t * (1619 / 2000)))| ≤
          ∑ j : Fin 5, |(splineCoefficient j : ℝ) * t ^ j.val *
            (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
              else Real.sin (t * (1619 / 2000)))| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ j : Fin 5, (![(47000 : ℝ), 4900, 292, 13, 1] j) * |t| ^ j.val := by
        apply Finset.sum_le_sum
        intro j _
        rw [abs_mul, abs_mul, abs_pow]
        calc
          |(splineCoefficient j : ℝ)| * |t| ^ j.val *
              |if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
                else Real.sin (t * (1619 / 2000))| ≤
              |(splineCoefficient j : ℝ)| * |t| ^ j.val :=
            mul_le_of_le_one_right (mul_nonneg (abs_nonneg _) (pow_nonneg (abs_nonneg _) _))
              (abs_phase_le_one j t)
          _ ≤ _ := mul_le_mul_of_nonneg_right (spline_coefficient_budget j)
            (pow_nonneg (abs_nonneg _) _)
      _ = _ := by simp [Fin.sum_univ_succ]; ring
  have he : |Real.sinc (t / 2000) ^ 19 *
      (∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
        (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
          else Real.sin (t * (1619 / 2000))))| ≤
      47000 + 4900 * |t| + 292 * |t| ^ 2 + 13 * |t| ^ 3 + |t| ^ 4 := by
    rw [abs_mul, abs_pow]
    calc
      _ ≤ 1 * |∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
          (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
            else Real.sin (t * (1619 / 2000)))| :=
        mul_le_mul_of_nonneg_right
          (pow_le_one₀ (abs_nonneg _) (Real.abs_sinc_le_one _)) (abs_nonneg _)
      _ ≤ _ := by simpa only [one_mul] using hs
  unfold correctionSymbol
  exact (abs_add_le _ _).trans (by linarith only [hhat, he])

/-- The explicit correction has a uniform rational normalized tail budget. -/
theorem actual_correction_tail_bound (t : ℝ) (ht : 300 ≤ |t|) :
    |correctionSymbol t| ≤ (17 / 16 : ℝ) * (t ^ 2 + 1 / 4) ^ 2 := by
  simpa only [sq_abs] using (abs_correctionSymbol_le_polynomial t).trans
    (correction_polynomial_tail_bound |t| ht)

/-- Unconditional pointwise certificate for the entire infinite tail,
with a positive reserve in the exact convention consumed by the Weil bridge. -/
theorem corrected_symbol_tail (t : ℝ) (ht : 300 ≤ |t|) :
    (3 / 8 : ℝ) * (t ^ 2 + 1 / 4) ^ 2 ≤
      (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) + correctionSymbol t := by
  have hs := actual_symbol_tail_lower t ht
  have hc := actual_correction_tail_bound t ht
  have hl := neg_abs_le (correctionSymbol t)
  have hw : 0 ≤ (t ^ 2 + 1 / 4) ^ 2 := sq_nonneg _
  have hm := mul_le_mul_of_nonneg_left hs hw
  nlinarith only [hc, hl, hm]

/-- The required nonnegative sign follows without a numerical tail premise. -/
theorem corrected_symbol_tail_nonnegative (t : ℝ) (ht : 300 ≤ |t|) :
    0 ≤ (t ^ 2 + 1 / 4) ^ 2 * (symbol t - 1 / 16) + correctionSymbol t := by
  exact (by positivity : (0 : ℝ) ≤ (3 / 8 : ℝ) * (t ^ 2 + 1 / 4) ^ 2).trans
    (corrected_symbol_tail t ht)

end AEGIS.RHKreinRationalCertificateV1

#print axioms AEGIS.RHKreinRationalCertificateV1.digamma_tail_endpoint
#print axioms AEGIS.RHKreinRationalCertificateV1.digamma_tail_lower
#print axioms AEGIS.RHKreinRationalCertificateV1.actual_symbol_tail_lower
#print axioms AEGIS.RHKreinRationalCertificateV1.correction_polynomial_tail_bound

#print axioms AEGIS.RHKreinRationalCertificateV1.hat_coefficient_budget
#print axioms AEGIS.RHKreinRationalCertificateV1.abs_correctionSymbol_le_polynomial
#print axioms AEGIS.RHKreinRationalCertificateV1.actual_correction_tail_bound
#print axioms AEGIS.RHKreinRationalCertificateV1.corrected_symbol_tail
#print axioms AEGIS.RHKreinRationalCertificateV1.corrected_symbol_tail_nonnegative
~~~~~~

## AEGISOverlay.RHKreinDigammaMonotonicityV1

Path: `source/AEGISOverlay/RHKreinDigammaMonotonicityV1.lean`

Original source lines: 1–102

Full file SHA256: `bbd169ac6380565d3616c732c7ab69c3b130bb4f7a529923efa8b799e27f2d7c`

Origin: https://github.com/tarikskalic33/formal-conjectures/blob/e279d5765b2dc0cb8b4ec4f62b8db96b4dc69121/AEGISOverlay/RHKreinDigammaMonotonicityV1.lean

~~~~~~lean
/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinDigammaLowerBoundV1

/-!
# Quarter-line digamma monotonicity for exact certificate endpoints

The established complex digamma series is mapped through the real part.
Each explicit term increases with the square of the angular frequency.
Absolute summability permits termwise comparison. This justifies using a
finite-interval left endpoint and a single infinite-tail starting point in
`research/rh/krein_order19_v1/certify.py`.
-/

open Complex
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinDigammaMonotonicityV1

open AEGIS.RHKreinDigammaLowerBoundV1
open AEGIS.WeilDigammaIntegralReductionV1
open AEGIS.WeilDigammaSeriesRealV1
open AEGIS.WeilDigammaSeriesHalfPlaneV1

/-- Every rational summand increases with squared angular frequency. -/
theorem quarterTerm_mono_of_sq_le (s t : ℝ) (hst : s ^ 2 ≤ t ^ 2) (n : ℕ) :
    quarterTerm s n ≤ quarterTerm t n := by
  have hx : (0 : ℝ) < (n : ℝ) + 1 / 4 := by positivity
  have hd : 0 < ((n : ℝ) + 1 / 4) ^ 2 + s ^ 2 / 4 := by positivity
  have hden : ((n : ℝ) + 1 / 4) ^ 2 + s ^ 2 / 4 ≤
      ((n : ℝ) + 1 / 4) ^ 2 + t ^ 2 / 4 := by linarith
  have hdiv := div_le_div_of_nonneg_left hx.le hd hden
  unfold quarterTerm
  linarith

/-- The established complex series supplies this exact real `HasSum`. -/
theorem quarterTerm_hasSum (t : ℝ) :
    HasSum (quarterTerm t)
      ((Complex.digamma (quarterPoint t)).re + Real.eulerMascheroniConstant) := by
  have hz : 0 < (quarterPoint t).re := by norm_num [quarterPoint]
  have hs : Summable (seriesTerm (quarterPoint t)) :=
    (summable_norm_seriesTerm_v1 (quarterPoint t) hz).of_norm
  have hc := hs.hasSum
  rw [← digamma_series_halfPlane_v1 (quarterPoint t) hz] at hc
  simpa only [← quarterTerm_eq_seriesTerm_re, Complex.add_re, Complex.ofReal_re]
    using Complex.hasSum_re hc

/-- Actual Mathlib digamma comparison, valid for arbitrary real frequencies. -/
theorem digamma_quarter_mono_of_sq_le (s t : ℝ) (hst : s ^ 2 ≤ t ^ 2) :
    (Complex.digamma ((1 / 4 : ℂ) + (s : ℂ) * I / 2)).re ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * I / 2)).re := by
  have hs := quarterTerm_hasSum s
  have ht := quarterTerm_hasSum t
  have h := le_of_tendsto_of_tendsto' hs.tendsto_sum_nat ht.tendsto_sum_nat
    (fun N : ℕ => Finset.sum_le_sum
      (fun n (_hn : n ∈ Finset.range N) => quarterTerm_mono_of_sq_le s t hst n))
  dsimp [quarterPoint] at h
  linarith

/-- The actual digamma real part is nondecreasing on nonnegative frequencies. -/
theorem digamma_quarter_monotoneOn_nonnegative :
    MonotoneOn (fun t : ℝ =>
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * I / 2)).re) (Set.Ici 0) := by
  intro s hs t ht hst
  apply digamma_quarter_mono_of_sq_le s t
  have hpos : 0 ≤ t + s := add_nonneg ht hs
  nlinarith [mul_nonneg (sub_nonneg.mpr hst) hpos]

/-- The rational lower bound at one frequency holds at every larger squared
frequency. This is the finite-grid endpoint and infinite-tail interface. -/
theorem digamma_quarter_certificate_lower_of_sq_le
    (s t : ℝ) (N : ℕ) (hst : s ^ 2 ≤ t ^ 2) :
    -(5792 / 10000 : ℝ) + (∑ n ∈ Finset.range N, quarterTerm s n) -
        (3 / 4 : ℝ) * (1 / ((N : ℝ) + 1 / 4) +
          1 / ((N : ℝ) + 1 / 4) ^ 2) ≤
      (Complex.digamma ((1 / 4 : ℂ) + (t : ℂ) * I / 2)).re :=
  (digamma_quarter_certificate_lower s N).trans (digamma_quarter_mono_of_sq_le s t hst)

end AEGIS.RHKreinDigammaMonotonicityV1

#print axioms AEGIS.RHKreinDigammaMonotonicityV1.quarterTerm_mono_of_sq_le
#print axioms AEGIS.RHKreinDigammaMonotonicityV1.quarterTerm_hasSum
#print axioms AEGIS.RHKreinDigammaMonotonicityV1.digamma_quarter_mono_of_sq_le
#print axioms AEGIS.RHKreinDigammaMonotonicityV1.digamma_quarter_monotoneOn_nonnegative
#print axioms AEGIS.RHKreinDigammaMonotonicityV1.digamma_quarter_certificate_lower_of_sq_le
~~~~~~

