# AEGIS source modules 8

Exact pinned or operator archive source. Compilation was not performed during transfer.

## WeilDigammaSeriesHalfPlaneV1

Path: `source/WeilDigammaSeriesHalfPlaneV1.lean`

Original source lines: 1–295

Full file SHA256: `58c647d29a7c499c65d0d5c8362c43fadced78341e102c269619d7d8ba37f0b6`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilDigammaSeriesHalfPlaneV1.lean

~~~~~~lean
import WeilDigammaSeriesRealV1
import Mathlib.Analysis.Complex.Convex
import Mathlib.Analysis.Complex.LocallyUniformLimit
import Mathlib.Analysis.Analytic.IsolatedZeros
import Mathlib.Tactic

/-!
AEGIS Ω — completion of Gauss's digamma series on the open right half-plane.

This module analytically continues the real-axis theorem from
`WeilDigammaSeriesRealV1` to every `z` with `0 < z.re`.  The series is
shown holomorphic by a local Weierstrass M-test using the exact rational
factorization

  1/(n+1) - 1/(z+n) = (z-1)/((n+1)(z+n)).

The identity theorem then transports the already-established positive-real-axis
identity to the full connected right half-plane.  Composing with the existing
`tsum_seriesTerm_eq_integral` theorem removes the remaining Gauss-digamma
integral dependency at source level.

AUTHORITY_EFFECT = NONE.
No RH conclusion is asserted here.
-/

open Set Filter
open scoped Topology BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilDigammaSeriesHalfPlaneV1

open AEGIS.WeilDigammaIntegralReductionV1
open AEGIS.WeilDigammaSeriesRealV1

local notation "γ" => Real.eulerMascheroniConstant

def RightHalfPlaneV1 : Set ℂ := {z : ℂ | 0 < z.re}

theorem isOpen_rightHalfPlane_v1 : IsOpen RightHalfPlaneV1 := by
  exact Complex.continuous_re.isOpen_preimage (Ioi (0 : ℝ)) isOpen_Ioi

theorem isPreconnected_rightHalfPlane_v1 : IsPreconnected RightHalfPlaneV1 := by
  simpa [RightHalfPlaneV1] using (convex_halfSpace_re_gt (0 : ℝ)).isPreconnected

private theorem seriesTerm_factor_v1 (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    seriesTerm z n =
      (z - 1) / (((n : ℂ) + 1) * (z + n)) := by
  have hn1 : ((n : ℂ) + 1) ≠ 0 := Nat.cast_add_one_ne_zero n
  have hzn : z + (n : ℂ) ≠ 0 := by
    intro h
    have hre := congrArg Complex.re h
    simp at hre
    linarith
  unfold seriesTerm
  rw [eq_div_iff (mul_ne_zero hn1 hzn)]
  field_simp
  ring

private theorem seriesTerm_differentiableOn_v1 (n : ℕ) :
    DifferentiableOn ℂ (fun z : ℂ => seriesTerm z n) RightHalfPlaneV1 := by
  intro z hz
  have hzn : z + (n : ℂ) ≠ 0 := by
    intro h
    have hre := congrArg Complex.re h
    simp [RightHalfPlaneV1] at hz
    simp at hre
    linarith
  have hn1 : ((n : ℂ) + 1) ≠ 0 := Nat.cast_add_one_ne_zero n
  apply DifferentiableAt.differentiableWithinAt
  unfold seriesTerm
  fun_prop

/-- The digamma-series tsum is holomorphic at every point of the open right
half-plane.  The bound is local, so no false global uniformity claim is used. -/
private theorem differentiableAt_series_tsum_v1
    (z0 : ℂ) (hz0 : z0 ∈ RightHalfPlaneV1) :
    DifferentiableAt ℂ (fun z : ℂ => ∑' n : ℕ, seriesTerm z n) z0 := by
  have hz0re : 0 < z0.re := hz0
  let δ : ℝ := min (1 / 2 : ℝ) (z0.re / 4)
  have hδpos : 0 < δ := by
    dsimp [δ]
    positivity
  have hδle1 : δ ≤ 1 := by
    dsimp [δ]
    linarith [min_le_left (1 / 2 : ℝ) (z0.re / 4)]
  have h4δ : 4 * δ ≤ z0.re := by
    dsimp [δ]
    have h := min_le_right (1 / 2 : ℝ) (z0.re / 4)
    linarith
  let U : Set ℂ := Metric.ball z0 δ
  have hUopen : IsOpen U := Metric.isOpen_ball
  have hz0U : z0 ∈ U := by
    simpa [U] using Metric.mem_ball_self (x := z0) hδpos

  let A : ℝ := δ + ‖z0 - 1‖
  have hA0 : 0 ≤ A := by
    dsimp [A]
    positivity
  let majorant : ℕ → ℝ := fun n =>
    (A / δ) * (1 / (((n : ℝ) + 1) ^ 2))
  have hmajorant : Summable majorant := by
    have hp :
        Summable (fun n : ℕ => 1 / (((n : ℝ) + 1) ^ 2)) := by
      have h := (Real.summable_one_div_nat_pow (p := 2)).2 (by norm_num)
      have h2 :=
        (summable_nat_add_iff
          (f := fun n : ℕ => 1 / ((n : ℝ) ^ 2)) 1).2 h
      refine h2.congr fun n => ?_
      push_cast
      ring
    exact hp.mul_left (A / δ)

  have hterm :
      ∀ n : ℕ, DifferentiableOn ℂ (fun z : ℂ => seriesTerm z n) U := by
    intro n z hz
    have hzdist : ‖z - z0‖ < δ := by
      simpa [U, Metric.mem_ball, dist_eq_norm] using hz
    have hreabs : |z.re - z0.re| ≤ ‖z - z0‖ := by
      simpa [Complex.sub_re] using Complex.abs_re_le_norm (z - z0)
    have hreldiff : |z.re - z0.re| < δ :=
      lt_of_le_of_lt hreabs hzdist
    have hzre : δ < z.re := by
      have hlow := (abs_lt.mp hreldiff).1
      nlinarith
    have hzre0 : 0 < z.re := lt_trans hδpos hzre
    have hzn : z + (n : ℂ) ≠ 0 := by
      intro h
      have hre := congrArg Complex.re h
      simp at hre
      linarith
    have hn1 : ((n : ℂ) + 1) ≠ 0 := Nat.cast_add_one_ne_zero n
    apply DifferentiableAt.differentiableWithinAt
    unfold seriesTerm
    fun_prop

  have hbound :
      ∀ n : ℕ, ∀ z ∈ U, ‖seriesTerm z n‖ ≤ majorant n := by
    intro n z hz
    have hzdist : ‖z - z0‖ < δ := by
      simpa [U, Metric.mem_ball, dist_eq_norm] using hz
    have hreabs : |z.re - z0.re| ≤ ‖z - z0‖ := by
      simpa [Complex.sub_re] using Complex.abs_re_le_norm (z - z0)
    have hreldiff : |z.re - z0.re| < δ :=
      lt_of_le_of_lt hreabs hzdist
    have hzre : δ < z.re := by
      have hlow := (abs_lt.mp hreldiff).1
      nlinarith
    have hzre0 : 0 < z.re := lt_trans hδpos hzre
    have hnum : ‖z - 1‖ ≤ A := by
      rw [show z - 1 = (z - z0) + (z0 - 1) by ring]
      calc
        ‖(z - z0) + (z0 - 1)‖
            ≤ ‖z - z0‖ + ‖z0 - 1‖ := norm_add_le _ _
        _ ≤ δ + ‖z0 - 1‖ := by linarith
        _ = A := by rfl
    have hn0 : (0 : ℝ) ≤ n := Nat.cast_nonneg n
    have hn1pos : 0 < (n : ℝ) + 1 := by positivity
    have hδn :
        δ * ((n : ℝ) + 1) ≤ (n : ℝ) + z.re := by
      have hmul :
          δ * (n : ℝ) ≤ (n : ℝ) := by
        have := mul_le_mul_of_nonneg_right hδle1 hn0
        nlinarith
      nlinarith
    have hnormzn :
        (n : ℝ) + z.re ≤ ‖z + (n : ℂ)‖ := by
      have h := Complex.re_le_norm (z + (n : ℂ))
      simp [Complex.add_re] at h
      linarith
    have hdenlower :
        δ * ((n : ℝ) + 1) ≤ ‖z + (n : ℂ)‖ :=
      hδn.trans hnormzn
    have hnormn1 : ‖((n : ℂ) + 1)‖ = (n : ℝ) + 1 := by
      simpa [Nat.cast_add, Nat.cast_one] using
        (Complex.norm_natCast (n + 1))
    have hdenpos : 0 < ‖z + (n : ℂ)‖ := by
      have : 0 < δ * ((n : ℝ) + 1) := mul_pos hδpos hn1pos
      exact this.trans_le hdenlower
    rw [seriesTerm_factor_v1 z hzre0 n, norm_div, norm_mul, hnormn1]
    calc
      ‖z - 1‖ / (((n : ℝ) + 1) * ‖z + (n : ℂ)‖)
          ≤ A / (((n : ℝ) + 1) *
              (δ * ((n : ℝ) + 1))) := by
            apply div_le_div₀
            · exact hA0
            · exact hnum
            · exact mul_pos hn1pos (mul_pos hδpos hn1pos)
            · exact mul_le_mul_of_nonneg_left
                hdenlower (by positivity)
      _ = (A / δ) * (1 / (((n : ℝ) + 1) ^ 2)) := by
            field_simp [hδpos.ne', hn1pos.ne']
      _ = majorant n := by rfl

  have hdiff :
      DifferentiableOn ℂ
        (fun z : ℂ => ∑' n : ℕ, seriesTerm z n) U :=
    Complex.differentiableOn_tsum_of_summable_norm
      hmajorant hterm hUopen hbound
  exact hdiff.differentiableAt (hUopen.mem_nhds hz0U)

theorem analyticOnNhd_series_tsum_v1 :
    AnalyticOnNhd ℂ
      (fun z : ℂ => ∑' n : ℕ, seriesTerm z n)
      RightHalfPlaneV1 := by
  apply DifferentiableOn.analyticOnNhd
  · intro z hz
    exact (differentiableAt_series_tsum_v1 z hz).differentiableWithinAt
  · exact isOpen_rightHalfPlane_v1

theorem analyticOnNhd_digamma_add_gamma_v1 :
    AnalyticOnNhd ℂ
      (fun z : ℂ => Complex.digamma z + (γ : ℂ))
      RightHalfPlaneV1 := by
  have hGammaDiff :
      DifferentiableOn ℂ Complex.Gamma RightHalfPlaneV1 := by
    intro z hz
    have hzre : 0 < z.re := hz
    exact
      (Complex.differentiableAt_Gamma z (by
        intro m hm
        have hre := congrArg Complex.re hm
        simp at hre
        linarith)).differentiableWithinAt
  have hGammaAnal :
      AnalyticOnNhd ℂ Complex.Gamma RightHalfPlaneV1 :=
    hGammaDiff.analyticOnNhd isOpen_rightHalfPlane_v1
  have hDigammaAnal :
      AnalyticOnNhd ℂ Complex.digamma RightHalfPlaneV1 := by
    have hfun : Complex.digamma = fun z => deriv Complex.Gamma z / Complex.Gamma z := by
      funext z
      simp [Complex.digamma_def, logDeriv_apply]
    rw [hfun]
    exact hGammaAnal.deriv.div hGammaAnal
      (fun z hz => Complex.Gamma_ne_zero_of_re_pos hz)
  exact hDigammaAnal.add analyticOnNhd_const

private theorem one_mem_closure_real_axis_equalities_v1 :
    (1 : ℂ) ∈ closure
      ({z : ℂ |
          Complex.digamma z + (γ : ℂ) =
            ∑' n : ℕ, seriesTerm z n} \ {(1 : ℂ)}) := by
  let s : ℕ → ℂ := fun n =>
    (1 : ℂ) + 1 / ((n + 1 : ℕ) : ℂ)
  have hs_tend : Tendsto s atTop (𝓝 (1 : ℂ)) := by
    have hzero :
        Tendsto (fun n : ℕ => 1 / ((n + 1 : ℕ) : ℂ))
          atTop (𝓝 0) :=
      by simpa [Nat.cast_add, Nat.cast_one] using
          tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℂ)
    simpa [s] using (tendsto_const_nhds.add hzero)
  refine mem_closure_of_tendsto hs_tend ?_
  exact Filter.Eventually.of_forall (fun n => by
    constructor
    · let x : ℝ := 1 + 1 / ((n + 1 : ℕ) : ℝ)
      have hx : 0 < x := by
        dsimp [x]
        positivity
      have hreal := digamma_series_ofReal_v1 x hx
      simpa [s, x] using hreal
    · simpa [s] using (Nat.cast_add_one_ne_zero n : ((n : ℂ) + 1) ≠ 0))

/-- The missing series representation of the complex digamma function on the
entire open right half-plane. -/
theorem digamma_series_halfPlane_v1 (z : ℂ) (hz : 0 < z.re) :
    Complex.digamma z + (γ : ℂ) =
      ∑' n : ℕ, seriesTerm z n := by
  let F : ℂ → ℂ := fun w => Complex.digamma w + (γ : ℂ)
  let G : ℂ → ℂ := fun w => ∑' n : ℕ, seriesTerm w n
  have hEq : EqOn F G RightHalfPlaneV1 := by
    refine
      analyticOnNhd_digamma_add_gamma_v1.eqOn_of_preconnected_of_mem_closure
        analyticOnNhd_series_tsum_v1
        isPreconnected_rightHalfPlane_v1
        (z₀ := (1 : ℂ))
        (by simp [RightHalfPlaneV1])
        ?_
    simpa [F, G] using one_mem_closure_real_axis_equalities_v1
  exact hEq hz

/-- Full Gauss integral representation, now derived from the pinned Mathlib
trust surface plus the existing AEGIS series-to-integral theorem. -/
theorem gauss_digamma_integral_v1 (z : ℂ) (hz : 0 < z.re) :
    Complex.digamma z + (γ : ℂ) =
      ∫ u in Ioi (0 : ℝ), gaussIntegrand z u := by
  rw [digamma_series_halfPlane_v1 z hz]
  exact tsum_seriesTerm_eq_integral z hz

end AEGIS.WeilDigammaSeriesHalfPlaneV1

#print axioms AEGIS.WeilDigammaSeriesHalfPlaneV1.analyticOnNhd_series_tsum_v1
#print axioms AEGIS.WeilDigammaSeriesHalfPlaneV1.analyticOnNhd_digamma_add_gamma_v1
#print axioms AEGIS.WeilDigammaSeriesHalfPlaneV1.digamma_series_halfPlane_v1
#print axioms AEGIS.WeilDigammaSeriesHalfPlaneV1.gauss_digamma_integral_v1
~~~~~~

## WeilDigammaSeriesRealV1

Path: `source/WeilDigammaSeriesRealV1.lean`

Original source lines: 1–315

Full file SHA256: `38a2da47f96e36e43d064a19b386d94439ac531ad3c468401d6348708d9eb464`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilDigammaSeriesRealV1.lean

~~~~~~lean
import WeilDigammaIntegralReductionV1
import Mathlib.Analysis.SpecialFunctions.Gamma.Digamma
import Mathlib.Analysis.SpecialFunctions.Gamma.BohrMollerup
import Mathlib.NumberTheory.Harmonic.GammaDeriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic

/-!
AEGIS Ω — real-axis completion of the Gauss digamma series dependency.

This module closes the missing real-positive-axis half of the decomposition

  ψ(z) + γ = ∑_{n≥0} (1/(n+1) - 1/(z+n))

without importing Gauss's integral formula as an axiom.  The proof uses only
pinned Mathlib facts already present at 0df444a3:

* convexity of `log ∘ Real.Gamma`;
* the Gamma recurrence;
* `harmonic n - log n → γ`;
* `log (n+a) - log n → 0`;
* the existing AEGIS absolute-summability bound for `seriesTerm`.

This file intentionally proves the identity first for `x > 0`, viewed inside
`ℂ`.  Analytic continuation to the full half-plane `0 < re z` is a separate
next module so that a failure there cannot erase this closed real-axis slice.

AUTHORITY_EFFECT = NONE.
RH is not asserted here.
-/

open Set Filter
open scoped Topology BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilDigammaSeriesRealV1

open AEGIS.WeilDigammaIntegralReductionV1

local notation "γ" => Real.eulerMascheroniConstant

/-- Real specialization of the complex AEGIS digamma-series summand. -/
def realSeriesTerm (x : ℝ) (n : ℕ) : ℝ :=
  1 / ((n : ℝ) + 1) - 1 / (x + n)

/-- The existing complex summand is exactly the coercion of the real one on the
positive real axis. -/
theorem seriesTerm_ofReal_v1 (x : ℝ) (n : ℕ) :
    seriesTerm (x : ℂ) n = (realSeriesTerm x n : ℂ) := by
  simp [seriesTerm, realSeriesTerm]

/-- Absolute summability of the AEGIS complex series term follows from the
already-proved kernel-integral majorant. -/
theorem summable_norm_seriesTerm_v1 (z : ℂ) (hz : 0 < z.re) :
    Summable (fun n : ℕ => ‖seriesTerm z n‖) := by
  refine Summable.of_nonneg_of_le
    (fun n => norm_nonneg (seriesTerm z n))
    (fun n => ?_)
    (summable_integral_norm_kernelTerm z hz)
  rw [← integral_kernelTerm z hz n]
  exact MeasureTheory.norm_integral_le_integral_norm _

/-- Local copy of the standard real-restriction uniqueness argument used
privately in Mathlib's `GammaDeriv`: if a holomorphic function agrees with a
real function on the real axis, its complex derivative there is the coerced
real derivative. -/
private lemma complex_deriv_of_real_restriction
    {F : ℂ → ℂ} {g : ℝ → ℝ} {g' x : ℝ}
    (hF : DifferentiableAt ℂ F x)
    (hg : HasDerivAt g g' x)
    (hFg : ∀ y : ℝ, F y = g y) :
    HasDerivAt F (g' : ℂ) x := by
  refine HasDerivAt.congr_deriv hF.hasDerivAt ?_
  rw [← (funext hFg ▸ hF.hasDerivAt.comp_ofReal.deriv :)]
  exact hg.ofReal_comp.deriv

/-- On the positive real axis, Mathlib's complex digamma is the coercion of
the derivative of `log Γ`. -/
theorem digamma_ofReal_eq_logGamma_deriv_v1 (x : ℝ) (hx : 0 < x) :
    Complex.digamma (x : ℂ) =
      ((deriv (Real.log ∘ Real.Gamma) x : ℝ) : ℂ) := by
  let f : ℝ → ℝ := Real.log ∘ Real.Gamma
  have hGreal : DifferentiableAt ℝ Real.Gamma x :=
    Real.differentiableAt_Gamma (by
      intro m hm
      have hmnonpos : -(m : ℝ) ≤ 0 := neg_nonpos.mpr (Nat.cast_nonneg m)
      linarith)
  have hGne : Real.Gamma x ≠ 0 :=
    Real.Gamma_ne_zero (by
      intro m hm
      have hmnonpos : -(m : ℝ) ≤ 0 := neg_nonpos.mpr (Nat.cast_nonneg m)
      linarith)
  have hGcomplex : DifferentiableAt ℂ Complex.Gamma (x : ℂ) :=
    Complex.differentiableAt_Gamma _ (by
      intro m hm
      have hre := congrArg Complex.re hm
      simp at hre
      linarith)
  have hGc :
      HasDerivAt Complex.Gamma ((deriv Real.Gamma x : ℝ) : ℂ) (x : ℂ) :=
    complex_deriv_of_real_restriction
      hGcomplex hGreal.hasDerivAt (fun y => Complex.Gamma_ofReal y)
  have hGammaCast : Complex.Gamma (x : ℂ) = (Real.Gamma x : ℂ) :=
    Complex.Gamma_ofReal x
  have hlogDeriv :
      deriv f x = deriv Real.Gamma x / Real.Gamma x := by
    simpa [f, Function.comp_def] using
      deriv.log hGreal hGne
  rw [Complex.digamma_def, logDeriv_apply, hGc.deriv, hGammaCast, hlogDeriv,
    Complex.ofReal_div]

/-- Iterated logarithmic-Gamma derivative recurrence. -/
private theorem logGamma_deriv_shift_v1 (x : ℝ) (hx : 0 < x) (n : ℕ) :
    deriv (Real.log ∘ Real.Gamma) (x + (n : ℝ)) =
      deriv (Real.log ∘ Real.Gamma) x +
        ∑ k ∈ Finset.range n, 1 / (x + (k : ℝ)) := by
  let f : ℝ → ℝ := Real.log ∘ Real.Gamma
  have hrec (y : ℝ) (hy : 0 < y) :
      f (y + 1) = f y + Real.log y := by
    simp only [f, Function.comp_apply, Real.Gamma_add_one hy.ne',
      Real.log_mul hy.ne' (Real.Gamma_pos_of_pos hy).ne', add_comm]
  have hdiff {y : ℝ} (hy : 0 < y) : DifferentiableAt ℝ f y := by
    refine ((Real.differentiableAt_Gamma ?_).log (Real.Gamma_ne_zero ?_))
    · intro m hm
      have hmnonpos : -(m : ℝ) ≤ 0 := neg_nonpos.mpr (Nat.cast_nonneg m)
      linarith
    · intro m hm
      have hmnonpos : -(m : ℝ) ≤ 0 := neg_nonpos.mpr (Nat.cast_nonneg m)
      linarith
  have hderRec (y : ℝ) (hy : 0 < y) :
      deriv f (y + 1) = deriv f y + 1 / y := by
    rw [← deriv_comp_add_const, one_div, ← Real.deriv_log,
      ← deriv_add (hdiff <| by positivity) (Real.differentiableAt_log hy.ne')]
    apply EventuallyEq.deriv_eq
    filter_upwards [eventually_gt_nhds hy] using hrec
  induction n with
  | zero =>
      simp
  | succ n ih =>
      have hyn : 0 < x + (n : ℝ) := by positivity
      rw [Nat.cast_succ]
      rw [show x + ((n : ℝ) + 1) = (x + (n : ℝ)) + 1 by ring]
      rw [hderRec (x + (n : ℝ)) hyn, ih, Finset.sum_range_succ]
      ring

/-- The shifted logarithmic-Gamma derivative has the expected logarithmic
asymptotic along the positive real ray. -/
private theorem logGamma_deriv_shift_sub_log_tendsto_zero_v1
    (x : ℝ) (hx : 0 < x) :
    Tendsto
      (fun n : ℕ =>
        deriv (Real.log ∘ Real.Gamma) (x + (n : ℝ)) - Real.log n)
      atTop (𝓝 0) := by
  let f : ℝ → ℝ := Real.log ∘ Real.Gamma
  have hc : ConvexOn ℝ (Ioi 0) f := Real.convexOn_log_Gamma
  have hrec (y : ℝ) (hy : 0 < y) :
      f (y + 1) = f y + Real.log y := by
    simp only [f, Function.comp_apply, Real.Gamma_add_one hy.ne',
      Real.log_mul hy.ne' (Real.Gamma_pos_of_pos hy).ne', add_comm]
  have hdiff {y : ℝ} (hy : 0 < y) : DifferentiableAt ℝ f y := by
    refine ((Real.differentiableAt_Gamma ?_).log (Real.Gamma_ne_zero ?_))
    · intro m hm
      have hmnonpos : -(m : ℝ) ≤ 0 := neg_nonpos.mpr (Nat.cast_nonneg m)
      linarith
    · intro m hm
      have hmnonpos : -(m : ℝ) ≤ 0 := neg_nonpos.mpr (Nat.cast_nonneg m)
      linarith
  have hLB (n : ℕ) (hn : 0 < n) :
      Real.log ((n : ℝ) + (x - 1)) ≤ deriv f (x + (n : ℝ)) := by
    let a : ℝ := x + (n : ℝ) - 1
    let b : ℝ := x + (n : ℝ)
    have hn1_nat : 1 ≤ n := Nat.one_le_iff_ne_zero.mpr (Nat.ne_of_gt hn)
    have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn1_nat
    have ha : 0 < a := by
      dsimp [a]
      linarith
    have hb : 0 < b := by
      dsimp [b]
      positivity
    have hab : a < b := by
      dsimp [a, b]
      linarith
    have hs :=
      hc.slope_le_deriv (mem_Ioi.mpr ha) (mem_Ioi.mpr hb) hab (hdiff hb)
    have hslope : slope f a b = Real.log a := by
      rw [slope_def_field]
      have hab1 : b - a = 1 := by
        dsimp [a, b]
        ring
      rw [hab1, div_one]
      have hab2 : a + 1 = b := by
        dsimp [a, b]
        ring
      rw [← hab2, hrec a ha, add_sub_cancel_left]
    calc
      Real.log ((n : ℝ) + (x - 1)) = Real.log a := by
        congr 1
        dsimp [a]
        ring
      _ = slope f a b := hslope.symm
      _ ≤ deriv f b := hs
      _ = deriv f (x + (n : ℝ)) := by rfl
  have hUB (n : ℕ) :
      deriv f (x + (n : ℝ)) ≤ Real.log ((n : ℝ) + x) := by
    let a : ℝ := x + (n : ℝ)
    let b : ℝ := a + 1
    have ha : 0 < a := by
      dsimp [a]
      positivity
    have hb : 0 < b := by
      dsimp [b]
      positivity
    have hab : a < b := by
      dsimp [b]
      linarith
    have hs :=
      hc.deriv_le_slope (mem_Ioi.mpr ha) (mem_Ioi.mpr hb) hab (hdiff ha)
    have hslope : slope f a b = Real.log a := by
      rw [slope_def_field]
      have hab1 : b - a = 1 := by
        dsimp [b]
        ring
      rw [hab1, div_one]
      rw [show b = a + 1 by rfl, hrec a ha, add_sub_cancel_left]
    simpa [a, add_comm] using hs.trans_eq hslope
  have hlow :
      Tendsto
        (fun n : ℕ =>
          Real.log ((n : ℝ) + (x - 1)) - Real.log n)
        atTop (𝓝 0) := by
    simpa [Function.comp_def] using
      (Real.tendsto_log_comp_add_sub_log (x - 1)).comp
        tendsto_natCast_atTop_atTop
  have hupp :
      Tendsto
        (fun n : ℕ =>
          Real.log ((n : ℝ) + x) - Real.log n)
        atTop (𝓝 0) := by
    simpa [Function.comp_def] using
      (Real.tendsto_log_comp_add_sub_log x).comp
        tendsto_natCast_atTop_atTop
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' hlow hupp ?_ ?_
  · filter_upwards [eventually_gt_atTop 0] with n hn
    exact sub_le_sub_right (hLB n hn) _
  · filter_upwards with n
    exact sub_le_sub_right (hUB n) _

/-- Real positive-axis Gauss digamma series. -/
theorem real_digamma_series_v1 (x : ℝ) (hx : 0 < x) :
    HasSum (realSeriesTerm x)
      (γ + deriv (Real.log ∘ Real.Gamma) x) := by
  have hsumComplex :=
    summable_norm_seriesTerm_v1 (x : ℂ) (by simpa using hx)
  have hsumNorm :
      Summable (fun n : ℕ => ‖realSeriesTerm x n‖) := by
    simpa [seriesTerm_ofReal_v1, Complex.norm_real] using hsumComplex
  rw [hasSum_iff_tendsto_nat_of_summable_norm hsumNorm]
  have hshift :=
    logGamma_deriv_shift_sub_log_tendsto_zero_v1 x hx
  have hmain :=
    (Real.tendsto_harmonic_sub_log.sub hshift).add
      (tendsto_const_nhds :
        Tendsto (fun _ : ℕ => deriv (Real.log ∘ Real.Gamma) x)
          atTop (𝓝 (deriv (Real.log ∘ Real.Gamma) x)))
  convert hmain using 1
  · funext n
    have hharm :
        (harmonic n : ℝ) =
          ∑ k ∈ Finset.range n, 1 / ((k : ℝ) + 1) := by
      simp [harmonic, one_div]
    have hshiftEq :=
      logGamma_deriv_shift_v1 x hx n
    unfold realSeriesTerm
    rw [Finset.sum_sub_distrib, ← hharm]
    have hrecip :
        (∑ k ∈ Finset.range n, 1 / (x + (k : ℝ))) =
          deriv (Real.log ∘ Real.Gamma) (x + (n : ℝ)) -
            deriv (Real.log ∘ Real.Gamma) x := by
      linarith
    rw [hrecip]
    ring
  · ring

/-- The missing digamma-series half on the positive real axis, in exactly the
complex `seriesTerm` language used by the existing AEGIS reduction. -/
theorem digamma_series_ofReal_v1 (x : ℝ) (hx : 0 < x) :
    Complex.digamma (x : ℂ) + (γ : ℂ) =
      ∑' n : ℕ, seriesTerm (x : ℂ) n := by
  have hs := real_digamma_series_v1 x hx
  have htsum := hs.tsum_eq
  have hcast := congrArg (fun r : ℝ => (r : ℂ)) htsum
  rw [Complex.ofReal_tsum] at hcast
  calc
    Complex.digamma (x : ℂ) + (γ : ℂ) =
        ((deriv (Real.log ∘ Real.Gamma) x + γ : ℝ) : ℂ) := by
          rw [digamma_ofReal_eq_logGamma_deriv_v1 x hx, Complex.ofReal_add]
    _ = ((γ + deriv (Real.log ∘ Real.Gamma) x : ℝ) : ℂ) := by
          congr 1
          ring
    _ = ∑' n : ℕ, (realSeriesTerm x n : ℂ) := hcast.symm
    _ = ∑' n : ℕ, seriesTerm (x : ℂ) n := by
          apply tsum_congr
          intro n
          exact (seriesTerm_ofReal_v1 x n).symm

end AEGIS.WeilDigammaSeriesRealV1

#print axioms AEGIS.WeilDigammaSeriesRealV1.summable_norm_seriesTerm_v1
#print axioms AEGIS.WeilDigammaSeriesRealV1.digamma_ofReal_eq_logGamma_deriv_v1
#print axioms AEGIS.WeilDigammaSeriesRealV1.logGamma_deriv_shift_v1
#print axioms AEGIS.WeilDigammaSeriesRealV1.logGamma_deriv_shift_sub_log_tendsto_zero_v1
#print axioms AEGIS.WeilDigammaSeriesRealV1.real_digamma_series_v1
#print axioms AEGIS.WeilDigammaSeriesRealV1.digamma_series_ofReal_v1
~~~~~~

## WeilDigammaIntegralReductionV1

Path: `source/WeilDigammaIntegralReductionV1.lean`

Original source lines: 1–314

Full file SHA256: `8204c5433d37654eb0b439a6807e88088eef288f9d3be116e21c482a7738759e`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilDigammaIntegralReductionV1.lean

~~~~~~lean
/-
AEGIS Ω — the series-to-integral reduction behind Gauss's digamma integral, V1.

`WeilPairedHadamardIdentityV1.md` (lane #490) carries exactly one
`[EXTERNAL-THEOREM]` dependency: Gauss's integral representation of the
digamma function (DLMF 5.9.16),

    ψ(z) + γ = ∫_0^∞ (exp (-u) - exp (-z u)) / (1 - exp (-u)) du,   Re z > 0,

used at `z = s/2` in its Section 5.  Mathlib 0df444a3 has `digamma` (as
`logDeriv Gamma`) but not this representation — `Gamma/Digamma.lean` lists it
as an open TODO.

Gauss's formula factors into two independent halves:

  (a)  ∑_{n≥0} (1/(n+1) - 1/(z+n)) = ∫_0^∞ (exp (-u) - exp (-z u))/(1 - exp (-u)) du
  (b)  ψ(z) + γ = ∑_{n≥0} (1/(n+1) - 1/(z+n))                    [series form of ψ]

This module proves (a), unconditionally, for every `z` with `0 < z.re`, from
Mathlib's trust surface only.  Half (b) — the series representation of
`digamma` — is NOT proven here and remains the open half of the dependency.

What this module does NOT do: it does not prove Gauss's formula, it does not
touch `digamma`, it proves no part of `WeilPairedHadamardIdentityV1`, and it
proves nothing about the Weil criterion or RH.  It removes one of the two
obstructions to importing that single external theorem, and nothing more.
-/
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.Analysis.PSeries
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Tactic

open Set Filter MeasureTheory
open scoped Topology

namespace AEGIS.WeilDigammaIntegralReductionV1

/-- `n`-th summand of the digamma-type series `∑ (1/(n+1) - 1/(z+n))`. -/
noncomputable def seriesTerm (z : ℂ) (n : ℕ) : ℂ :=
  1 / ((n : ℂ) + 1) - 1 / (z + n)

/-- `n`-th summand of the geometric expansion of the Gauss integrand. -/
noncomputable def kernelTerm (z : ℂ) (n : ℕ) (u : ℝ) : ℂ :=
  Complex.exp (-((n : ℂ) + 1) * u) - Complex.exp (-(z + n) * u)

/-- The Gauss integrand. -/
noncomputable def gaussIntegrand (z : ℂ) (u : ℝ) : ℂ :=
  (Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)) / (1 - Complex.exp (-(u : ℂ)))

/-! ### Step 1 — each summand is the integral of its kernel term -/

theorem integrableOn_kernelTerm (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    IntegrableOn (kernelTerm z n) (Ioi (0 : ℝ)) := by
  have h1 : (-((n : ℂ) + 1)).re < 0 := by
    simp only [Complex.neg_re, Complex.add_re, Complex.natCast_re, Complex.one_re, neg_lt_zero]
    positivity
  have h2 : (-(z + (n : ℂ))).re < 0 := by
    simp only [Complex.neg_re, Complex.add_re, Complex.natCast_re, neg_lt_zero]
    positivity
  exact (integrableOn_exp_mul_complex_Ioi h1 0).sub (integrableOn_exp_mul_complex_Ioi h2 0)

theorem integral_kernelTerm (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    (∫ u in Ioi (0 : ℝ), kernelTerm z n u) = seriesTerm z n := by
  have h1 : (-((n : ℂ) + 1)).re < 0 := by
    simp only [Complex.neg_re, Complex.add_re, Complex.natCast_re, Complex.one_re, neg_lt_zero]
    positivity
  have h2 : (-(z + (n : ℂ))).re < 0 := by
    simp only [Complex.neg_re, Complex.add_re, Complex.natCast_re, neg_lt_zero]
    positivity
  have hne1 : ((n : ℂ) + 1) ≠ 0 := by
    intro h
    rw [h] at h1
    simp at h1
  have hne2 : (z + (n : ℂ)) ≠ 0 := by
    intro h
    rw [h] at h2
    simp at h2
  simp only [kernelTerm]
  rw [integral_sub (integrableOn_exp_mul_complex_Ioi h1 0)
      (integrableOn_exp_mul_complex_Ioi h2 0),
    integral_exp_mul_complex_Ioi h1 0, integral_exp_mul_complex_Ioi h2 0]
  simp only [Complex.ofReal_zero, mul_zero, Complex.exp_zero, div_neg, neg_div, neg_neg,
    seriesTerm]

/-! ### Step 2 — a uniform majorant for the kernel terms -/

/-- Two-regime bound on `exp (-u) - exp (-z u)`: the linear factor `u` comes from
the cancellation at `u = 0`, and is what makes the majorant summable in `n`. -/
theorem norm_exp_diff_le (z : ℂ) {u : ℝ} (hu : 0 < u) :
    ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
      ≤ 2 * (1 + ‖z - 1‖) * u * Real.exp (-(min 1 z.re * u)) := by
  set C := ‖z - 1‖ with hCdef
  set m := min 1 z.re with hmdef
  have hC0 : 0 ≤ C := norm_nonneg _
  have hm1 : m ≤ 1 := min_le_left _ _
  have hmre : m ≤ z.re := min_le_right _ _
  have hfac : Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)
      = Complex.exp (-(u : ℂ)) * (1 - Complex.exp (-(z - 1) * u)) := by
    have h : Complex.exp (-(u : ℂ)) * Complex.exp (-(z - 1) * u)
        = Complex.exp (-z * u) := by
      rw [← Complex.exp_add]; congr 1; ring
    rw [mul_sub, mul_one, h]
  have hnorm1 : ‖Complex.exp (-(u : ℂ))‖ = Real.exp (-u) := by
    rw [Complex.norm_exp]; simp
  have hnorm2 : ‖Complex.exp (-z * (u : ℂ))‖ = Real.exp (-(z.re * u)) := by
    rw [Complex.norm_exp]; simp
  have hexp1 : Real.exp (-u) ≤ Real.exp (-(m * u)) := by
    apply Real.exp_le_exp.2
    nlinarith
  have hexp2 : Real.exp (-(z.re * u)) ≤ Real.exp (-(m * u)) := by
    apply Real.exp_le_exp.2
    nlinarith
  have hpos := Real.exp_pos (-(m * u))
  by_cases h : C * u ≤ 1
  · have harg : ‖-(z - 1) * (u : ℂ)‖ ≤ 1 := by
      rw [norm_mul, norm_neg, Complex.norm_real, Real.norm_of_nonneg hu.le]
      exact h
    have hb : ‖Complex.exp (-(z - 1) * (u : ℂ)) - 1‖ ≤ 2 * (C * u) := by
      have := Complex.norm_exp_sub_one_le harg
      rw [norm_mul, norm_neg, Complex.norm_real, Real.norm_of_nonneg hu.le] at this
      exact this
    have hb' : ‖1 - Complex.exp (-(z - 1) * (u : ℂ))‖ ≤ 2 * (C * u) := by
      rw [norm_sub_rev]; exact hb
    calc ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
        = Real.exp (-u) * ‖1 - Complex.exp (-(z - 1) * (u : ℂ))‖ := by
          rw [hfac, norm_mul, hnorm1]
      _ ≤ Real.exp (-(m * u)) * (2 * (C * u)) := by
          apply mul_le_mul hexp1 hb' (norm_nonneg _) hpos.le
      _ ≤ 2 * (1 + C) * u * Real.exp (-(m * u)) := by nlinarith
  · push_neg at h
    have hu1 : 1 ≤ (1 + C) * u := by nlinarith
    calc ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
        ≤ ‖Complex.exp (-(u : ℂ))‖ + ‖Complex.exp (-z * (u : ℂ))‖ := norm_sub_le _ _
      _ = Real.exp (-u) + Real.exp (-(z.re * u)) := by rw [hnorm1, hnorm2]
      _ ≤ 2 * Real.exp (-(m * u)) := by linarith
      _ ≤ 2 * (1 + C) * u * Real.exp (-(m * u)) := by nlinarith

theorem norm_kernelTerm_le (z : ℂ) (n : ℕ) {u : ℝ} (hu : 0 < u) :
    ‖kernelTerm z n u‖
      ≤ 2 * (1 + ‖z - 1‖) * u * Real.exp (-(((n : ℝ) + min 1 z.re) * u)) := by
  have hfac : kernelTerm z n u
      = Complex.exp (-(n : ℂ) * u) * (Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)) := by
    simp only [kernelTerm, mul_sub]
    congr 1
    · rw [← Complex.exp_add]; congr 1; ring
    · rw [← Complex.exp_add]; congr 1; ring
  have hnorm : ‖Complex.exp (-(n : ℂ) * (u : ℝ))‖ = Real.exp (-((n : ℝ) * u)) := by
    rw [Complex.norm_exp]; simp
  rw [hfac, norm_mul, hnorm]
  have hb := norm_exp_diff_le z hu
  have hp := Real.exp_pos (-((n : ℝ) * u))
  calc Real.exp (-((n : ℝ) * u)) * ‖Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)‖
      ≤ Real.exp (-((n : ℝ) * u)) * (2 * (1 + ‖z - 1‖) * u * Real.exp (-(min 1 z.re * u))) := by
        exact mul_le_mul_of_nonneg_left hb hp.le
    _ = 2 * (1 + ‖z - 1‖) * u * Real.exp (-(((n : ℝ) + min 1 z.re) * u)) := by
        rw [show -(((n : ℝ) + min 1 z.re) * u) = -((n : ℝ) * u) + -(min 1 z.re * u) by ring,
          Real.exp_add]
        ring

/-! ### Step 3 — the majorant integrates to `O(n⁻²)` -/

/-- `u * exp (-(b * u)) ≤ 1 / b` for `b > 0`: the only input is `x + 1 ≤ exp x`. -/
theorem mul_exp_neg_le (b : ℝ) (hb : 0 < b) (u : ℝ) (hu : 0 ≤ u) :
    u * Real.exp (-(b * u)) ≤ 1 / b := by
  have h1 : b * u ≤ Real.exp (b * u) := by
    have := Real.add_one_le_exp (b * u)
    linarith
  have hkey : (b * u) * Real.exp (-(b * u)) ≤ 1 := by
    have h2 : (b * u) * Real.exp (-(b * u)) ≤ Real.exp (b * u) * Real.exp (-(b * u)) :=
      mul_le_mul_of_nonneg_right h1 (Real.exp_pos _).le
    rwa [← Real.exp_add, show b * u + -(b * u) = 0 by ring, Real.exp_zero] at h2
  rw [le_div_iff₀ hb]
  calc u * Real.exp (-(b * u)) * b = (b * u) * Real.exp (-(b * u)) := by ring
    _ ≤ 1 := hkey

theorem integral_norm_kernelTerm_le (z : ℂ) (hz : 0 < z.re) (n : ℕ) :
    (∫ u in Ioi (0 : ℝ), ‖kernelTerm z n u‖)
      ≤ 8 * (1 + ‖z - 1‖) / (((n : ℝ) + min 1 z.re) ^ 2) := by
  set C := ‖z - 1‖ with hCdef
  set m := min 1 z.re with hmdef
  have hm0 : 0 < m := lt_min one_pos hz
  set a : ℝ := (n : ℝ) + m with hadef
  have ha0 : 0 < a := by positivity
  set b : ℝ := a / 2 with hbdef
  have hb0 : 0 < b := by positivity
  set K : ℝ := 2 * (1 + C) with hKdef
  have hK0 : 0 < K := by
    have : (0 : ℝ) ≤ C := norm_nonneg _
    simp only [hKdef]; linarith
  have hmaj : IntegrableOn (fun u : ℝ => K / b * Real.exp (-b * u)) (Ioi (0 : ℝ)) :=
    (integrableOn_exp_mul_Ioi (a := -b) (by linarith) 0).const_mul _
  have hle : ∀ u ∈ Ioi (0 : ℝ), ‖kernelTerm z n u‖ ≤ K / b * Real.exp (-b * u) := by
    intro u hu
    rw [mem_Ioi] at hu
    have h1 : ‖kernelTerm z n u‖ ≤ K * u * Real.exp (-(a * u)) := norm_kernelTerm_le z n hu
    have hsplit : Real.exp (-(a * u)) = Real.exp (-(b * u)) * Real.exp (-(b * u)) := by
      rw [← Real.exp_add]
      congr 1
      simp only [hbdef]
      ring
    have h2 : u * Real.exp (-(b * u)) ≤ 1 / b := mul_exp_neg_le b hb0 u hu.le
    have hp := Real.exp_pos (-(b * u))
    have : K * u * Real.exp (-(a * u)) = K * (u * Real.exp (-(b * u))) * Real.exp (-(b * u)) := by
      rw [hsplit]; ring
    rw [this] at h1
    have h3 : K * (u * Real.exp (-(b * u))) ≤ K * (1 / b) :=
      mul_le_mul_of_nonneg_left h2 hK0.le
    have h4 : K * (u * Real.exp (-(b * u))) * Real.exp (-(b * u))
        ≤ K * (1 / b) * Real.exp (-(b * u)) := mul_le_mul_of_nonneg_right h3 hp.le
    calc ‖kernelTerm z n u‖ ≤ K * (u * Real.exp (-(b * u))) * Real.exp (-(b * u)) := h1
      _ ≤ K * (1 / b) * Real.exp (-(b * u)) := h4
      _ = K / b * Real.exp (-b * u) := by rw [neg_mul]; ring
  have hnn : ∀ᵐ u ∂(volume.restrict (Ioi (0 : ℝ))), (0 : ℝ) ≤ ‖kernelTerm z n u‖ :=
    Filter.Eventually.of_forall (fun u => norm_nonneg _)
  have hlea : (fun u => ‖kernelTerm z n u‖)
      ≤ᵐ[volume.restrict (Ioi (0 : ℝ))] fun u => K / b * Real.exp (-b * u) :=
    (ae_restrict_iff' measurableSet_Ioi).2 (Filter.Eventually.of_forall hle)
  have hmono := integral_mono_of_nonneg hnn hmaj hlea
  have hval : (∫ u in Ioi (0 : ℝ), K / b * Real.exp (-b * u)) = K / b * (1 / b) := by
    rw [integral_const_mul, integral_exp_mul_Ioi (a := -b) (by linarith) 0]
    simp
  rw [hval] at hmono
  have hfin : K / b * (1 / b) = 8 * (1 + C) / (a ^ 2) := by
    field_simp [hbdef, hKdef]
    ring
  rw [hfin] at hmono
  exact hmono

theorem summable_integral_norm_kernelTerm (z : ℂ) (hz : 0 < z.re) :
    Summable fun n : ℕ => ∫ u in Ioi (0 : ℝ), ‖kernelTerm z n u‖ := by
  set C := ‖z - 1‖ with hCdef
  set m := min 1 z.re with hmdef
  have hm0 : 0 < m := lt_min one_pos hz
  have hm1 : m ≤ 1 := min_le_left _ _
  have hC0 : (0 : ℝ) ≤ C := norm_nonneg _
  have hps : Summable fun n : ℕ => 1 / ((n : ℝ) + 1) ^ 2 := by
    have h := (Real.summable_one_div_nat_pow (p := 2)).2 (by norm_num)
    have h2 := (summable_nat_add_iff (f := fun n : ℕ => 1 / ((n : ℝ)) ^ 2) 1).2 h
    refine h2.congr fun n => ?_
    push_cast
    ring
  refine Summable.of_nonneg_of_le (fun n => integral_nonneg fun u => norm_nonneg _)
    (fun n => integral_norm_kernelTerm_le z hz n) ?_
  have hbound : ∀ n : ℕ, 8 * (1 + C) / (((n : ℝ) + m) ^ 2)
      ≤ (8 * (1 + C) / m ^ 2) * (1 / ((n : ℝ) + 1) ^ 2) := by
    intro n
    have h1 : m * ((n : ℝ) + 1) ≤ (n : ℝ) + m := by
      have : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
      nlinarith
    have h2 : (0 : ℝ) < m * ((n : ℝ) + 1) := by positivity
    have h3 : (m * ((n : ℝ) + 1)) ^ 2 ≤ ((n : ℝ) + m) ^ 2 := by nlinarith
    have h4 : (0 : ℝ) < (m * ((n : ℝ) + 1)) ^ 2 := by positivity
    have h5 : (0 : ℝ) ≤ 8 * (1 + C) := by linarith
    calc 8 * (1 + C) / (((n : ℝ) + m) ^ 2)
        ≤ 8 * (1 + C) / ((m * ((n : ℝ) + 1)) ^ 2) := by
          apply div_le_div_of_nonneg_left h5 h4 h3
      _ = (8 * (1 + C) / m ^ 2) * (1 / ((n : ℝ) + 1) ^ 2) := by
          field_simp
  exact Summable.of_nonneg_of_le
    (fun n => by positivity)
    hbound (hps.mul_left _)

/-! ### Step 4 — the pointwise geometric sum -/

theorem tsum_kernelTerm (z : ℂ) {u : ℝ} (hu : 0 < u) :
    ∑' n : ℕ, kernelTerm z n u = gaussIntegrand z u := by
  have hr : ‖Complex.exp (-(u : ℂ))‖ < 1 := by
    rw [Complex.norm_exp]
    simp only [Complex.neg_re, Complex.ofReal_re]
    exact Real.exp_lt_one_iff.2 (by linarith)
  have hterm : ∀ n : ℕ, kernelTerm z n u
      = (Complex.exp (-(u : ℂ)) - Complex.exp (-z * u)) * Complex.exp (-(u : ℂ)) ^ n := by
    intro n
    rw [← Complex.exp_nat_mul]
    simp only [kernelTerm, sub_mul]
    congr 1
    · rw [← Complex.exp_add]; congr 1; ring
    · rw [← Complex.exp_add]; congr 1; ring
  simp only [hterm, gaussIntegrand]
  rw [tsum_mul_left, tsum_geometric_of_norm_lt_one hr]
  rw [div_eq_mul_inv]

/-! ### Step 5 — the reduction -/

/-- **The series-to-integral half of Gauss's digamma integral.**  For every `z`
with `0 < z.re`,

    ∑_{n≥0} (1/(n+1) - 1/(z+n)) = ∫_0^∞ (exp (-u) - exp (-z u)) / (1 - exp (-u)) du.

No axiom beyond Mathlib's standard trust surface; `digamma` does not appear. -/
theorem tsum_seriesTerm_eq_integral (z : ℂ) (hz : 0 < z.re) :
    ∑' n : ℕ, seriesTerm z n = ∫ u in Ioi (0 : ℝ), gaussIntegrand z u := by
  have key := integral_tsum_of_summable_integral_norm
    (F := fun (n : ℕ) (u : ℝ) => kernelTerm z n u)
    (μ := volume.restrict (Ioi (0 : ℝ)))
    (fun n => integrableOn_kernelTerm z hz n)
    (summable_integral_norm_kernelTerm z hz)
  have hL : (∑' n : ℕ, ∫ u in Ioi (0 : ℝ), kernelTerm z n u) = ∑' n : ℕ, seriesTerm z n := by
    exact tsum_congr fun n => integral_kernelTerm z hz n
  have hR : (∫ u in Ioi (0 : ℝ), ∑' n : ℕ, kernelTerm z n u)
      = ∫ u in Ioi (0 : ℝ), gaussIntegrand z u := by
    refine setIntegral_congr_fun measurableSet_Ioi fun u hu => ?_
    exact tsum_kernelTerm z (mem_Ioi.1 hu)
  rw [← hL, key, hR]

end AEGIS.WeilDigammaIntegralReductionV1

#print axioms AEGIS.WeilDigammaIntegralReductionV1.integral_kernelTerm
#print axioms AEGIS.WeilDigammaIntegralReductionV1.norm_exp_diff_le
#print axioms AEGIS.WeilDigammaIntegralReductionV1.norm_kernelTerm_le
#print axioms AEGIS.WeilDigammaIntegralReductionV1.integral_norm_kernelTerm_le
#print axioms AEGIS.WeilDigammaIntegralReductionV1.summable_integral_norm_kernelTerm
#print axioms AEGIS.WeilDigammaIntegralReductionV1.tsum_kernelTerm
#print axioms AEGIS.WeilDigammaIntegralReductionV1.tsum_seriesTerm_eq_integral
~~~~~~

## WeilAutocorrelationExplicitFormulaV10

Path: `source/WeilAutocorrelationExplicitFormulaV10.lean`

Original source lines: 1–90

Full file SHA256: `e0d49f362c156bea93da3b0b331546104287671a36bc0580f484d680db29f307`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilAutocorrelationExplicitFormulaV10.lean

~~~~~~lean
import WeilExplicitFormulaV10
import RHFinalClosureSpineV1
import WeilAutocorrelationClosureV1
import WeilAutocorrelationPoleAggregationV1
import WeilAutocorrelationRealityV1
import Mathlib.Tactic

/-!
AEGIS Ω — autocorrelation specialization of the whole explicit formula V10.

For a compact-smooth g satisfying the repository's two Mellin moment
conditions, the endpoint pole term of its multiplicative autocorrelation
vanishes.  The whole explicit formula therefore becomes

  WeilExplicitRightSideV1 (Autocorrelation g)
    = - sum_rho m_rho M(Autocorrelation g)(rho).

This is the exact arithmetic/zero-side quadratic identity needed by the final
sign problem.  No sign is inferred here.

AUTHORITY_EFFECT = NONE.
-/

open Complex
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilAutocorrelationExplicitFormulaV10

open AEGIS.WeilExplicitFormulaV10

/-- Whole explicit formula specialized to the actual autocorrelation carrier. -/
theorem autocorrelation_explicit_formula_v10
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g) :
    WeilExplicitRightSideV1 (WeilAutocorrelationV1 g) =
      - (∑' rho : RiemannNontrivialZeroIndexV2,
          WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho) := by
  have hEF :=
    weil_compact_smooth_explicit_formula_v1
      (WeilAutocorrelationCompactSmoothV1 g)
  have hpole :=
    weil_moment_conditions_autocorrelation_pole_term_zero_v1 g hm
  change
    (∑' rho : RiemannNontrivialZeroIndexV2,
      WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho) =
      mellin (WeilAutocorrelationV1 g) 0 +
        mellin (WeilAutocorrelationV1 g) 1 -
        WeilExplicitRightSideV1 (WeilAutocorrelationV1 g) at hEF
  rw [hpole, zero_sub] at hEF
  exact neg_eq_iff_eq_neg.mp hEF.symm

/-- The final arithmetic sign is exactly nonnegativity of the real part of
the canonical zero quadratic. -/
theorem autocorrelation_arithmetic_nonpositive_iff_zero_nonnegative_v10
    (g : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 g) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re ≤ 0 ↔
      0 ≤
        (∑' rho : RiemannNontrivialZeroIndexV2,
          WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho).re := by
  rw [autocorrelation_explicit_formula_v10 g hm]
  simp

/-- Repository final-sign residual rewritten with no arithmetic expression
left: it is precisely universal nonnegativity of the canonical zero
quadratic on the moment-zero compact-smooth class. -/
theorem final_sign_residual_iff_zero_quadratic_nonnegative_v10 :
    AEGIS.RHFinalClosureV1.FinalSignResidualV1 ↔
      ∀ g : WeilCompactSmoothGV1,
        WeilMomentConditionsV1 g →
        0 ≤
          (∑' rho : RiemannNontrivialZeroIndexV2,
            WeilZeroIndexSummandV1 (WeilAutocorrelationV1 g) rho).re := by
  unfold AEGIS.RHFinalClosureV1.FinalSignResidualV1
  constructor
  · intro h g hm
    exact
      (autocorrelation_arithmetic_nonpositive_iff_zero_nonnegative_v10
        g hm).mp (h g hm)
  · intro h g hm
    exact
      (autocorrelation_arithmetic_nonpositive_iff_zero_nonnegative_v10
        g hm).mpr (h g hm)

end AEGIS.WeilAutocorrelationExplicitFormulaV10

#print axioms AEGIS.WeilAutocorrelationExplicitFormulaV10.autocorrelation_explicit_formula_v10
#print axioms AEGIS.WeilAutocorrelationExplicitFormulaV10.autocorrelation_arithmetic_nonpositive_iff_zero_nonnegative_v10
#print axioms AEGIS.WeilAutocorrelationExplicitFormulaV10.final_sign_residual_iff_zero_quadratic_nonnegative_v10
~~~~~~

## WeilExplicitFormulaV10

Path: `source/WeilExplicitFormulaV10.lean`

Original source lines: 1–243

Full file SHA256: `cb1fd815d27f121d85f6ba89a4dfba05de2b0760526664e8b1b7db47a2401452`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilExplicitFormulaV10.lean

~~~~~~lean
import WeilXiLogDerivDecompositionV10
import WeilFixedLineArithmeticV10
import WeilFixedLineCompletedGammaV10
import WeilFixedLineZeroSideV10
import Mathlib.Tactic

/-!
AEGIS Ω — whole normalized Weil explicit formula V10.

This module composes the already-isolated fixed-line pieces:

* canonical zero side:
    I_c[2 xi'/xi * H] = 2 Z(f);
* elementary xi poles:
    I_c[(1/s + 1/(s-1)) H] = M f(0) + M f(1);
* completed Gamma factor:
    I_c[(-log(pi)/2 + psi(s/2)/2) H]
      = -ArchConst*f(1) - ArchIntegral(f);
* zeta logarithmic derivative:
    I_c[(zeta'/zeta) H] = -PrimeSum(f).

Together with the pinned-compatible pointwise decomposition of xi'/xi, this
gives the repository-native identity

  Z(f) = M f(0) + M f(1) - WeilExplicitRightSideV1(f).

No sign inequality and no RH conclusion is used or asserted here.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology Complex MeasureTheory
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilExplicitFormulaV10

open AEGIS.WeilXiLogDerivDecompositionV10
open AEGIS.WeilFixedLineArithmeticV10
open AEGIS.WeilFixedLineCompletedGammaV10
open AEGIS.WeilFixedLineZeroSideV10

private def PoleProfileV10
    (f : WeilCompactSmoothGV1) (c t : ℝ) : ℂ :=
  (1 / ((c : ℂ) + (t : ℂ) * I) +
    1 / (((c : ℂ) + (t : ℂ) * I) - 1)) *
    WeilPairedMellinProfileV5 f c t

private def GammaProfileV10
    (f : WeilCompactSmoothGV1) (c t : ℝ) : ℂ :=
  WeilCompletedGammaFactorV10 c t *
    WeilPairedMellinProfileV5 f c t

private def ZetaProfileV10
    (f : WeilCompactSmoothGV1) (c t : ℝ) : ℂ :=
  (deriv riemannZeta ((c : ℂ) + (t : ℂ) * I) /
    riemannZeta ((c : ℂ) + (t : ℂ) * I)) *
    WeilPairedMellinProfileV5 f c t

private def XiProfileV10
    (f : WeilCompactSmoothGV1) (c t : ℝ) : ℂ :=
  (2 * _root_.logDeriv LiCriterion.riemannXi
    ((c : ℂ) + (t : ℂ) * I)) *
    WeilPairedMellinProfileV5 f c t

private theorem pole_profile_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    Integrable (PoleProfileV10 f c) := by
  have h0 :=
    paired_profile_cauchy_integrable_v10 f c 0 (by
      simp
      linarith)
  have h1 :=
    paired_profile_cauchy_integrable_v10 f c 1 (by
      simpa using hc)
  exact (h0.add h1).congr
    (Filter.Eventually.of_forall fun t => by
      unfold PoleProfileV10
      simp only [sub_zero, Pi.add_apply]
      ring_nf)

private theorem gamma_profile_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    Integrable (GammaProfileV10 f c) := by
  exact weil_fixed_line_completed_gamma_integrable_v10 f c hc

private theorem zeta_profile_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    Integrable (ZetaProfileV10 f c) := by
  have hn :=
    fixed_line_neg_zeta_logDeriv_integrable_v10 f c hc
  exact hn.neg.congr
    (Filter.Eventually.of_forall fun t => by
      unfold ZetaProfileV10
      simp only [Pi.neg_apply]
      ring_nf)

/-- Pointwise decomposition of the doubled xi profile into the three
normalized explicit-formula pieces. -/
private theorem xi_profile_pointwise_v10
    (f : WeilCompactSmoothGV1) (c t : ℝ) (hc : 1 < c) :
    XiProfileV10 f c t =
      2 * (PoleProfileV10 f c t +
        GammaProfileV10 f c t +
        ZetaProfileV10 f c t) := by
  have hxi :=
    xi_logDeriv_fixed_line_decomposition_v10 c t hc
  unfold XiProfileV10 PoleProfileV10 GammaProfileV10 ZetaProfileV10
  rw [hxi]
  ring

/-- Fixed-line assembly before cancelling the common factor 2. -/
theorem whole_explicit_formula_on_fixed_line_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    2 * (∑' rho : RiemannNontrivialZeroIndexV2,
      WeilZeroIndexSummandV1 f.1 rho) =
      2 * (mellin f.1 0 + mellin f.1 1 -
        WeilExplicitRightSideV1 f.1) := by
  let k : ℂ := 1 / (2 * Real.pi)

  have hP := pole_profile_integrable_v10 f c hc
  have hG := gamma_profile_integrable_v10 f c hc
  have hZ := zeta_profile_integrable_v10 f c hc

  have hsum : Integrable
      (fun t : ℝ =>
        PoleProfileV10 f c t +
          GammaProfileV10 f c t +
          ZetaProfileV10 f c t) :=
    (hP.add hG).add hZ

  have hdecomp :
      (∫ t : ℝ, XiProfileV10 f c t) =
        2 * (∫ t : ℝ,
          (PoleProfileV10 f c t +
            GammaProfileV10 f c t +
            ZetaProfileV10 f c t)) := by
    calc
      (∫ t : ℝ, XiProfileV10 f c t)
        =
      ∫ t : ℝ,
        2 * (PoleProfileV10 f c t +
          GammaProfileV10 f c t +
          ZetaProfileV10 f c t) := by
            apply integral_congr_ae
            exact Filter.Eventually.of_forall
              (fun t => xi_profile_pointwise_v10 f c t hc)
      _ =
      2 * (∫ t : ℝ,
        (PoleProfileV10 f c t +
          GammaProfileV10 f c t +
          ZetaProfileV10 f c t)) := by
            rw [integral_const_mul]

  have hsplit :
      (∫ t : ℝ,
        (PoleProfileV10 f c t +
          GammaProfileV10 f c t +
          ZetaProfileV10 f c t)) =
      (∫ t : ℝ, PoleProfileV10 f c t) +
      (∫ t : ℝ, GammaProfileV10 f c t) +
      (∫ t : ℝ, ZetaProfileV10 f c t) := by
    have h1 := integral_add (hP.add hG) hZ
    have h2 := integral_add hP hG
    simp only [Pi.add_apply] at h1
    rw [h1, h2]

  have hzero :=
    normalized_two_xi_logDeriv_eq_two_aegis_zero_tsum_v10
      f c hc
  have hpole :=
    fixed_line_poles_eq_mellin_endpoints_v10 f c hc
  have hgamma :=
    weil_fixed_line_completed_gamma_eq_archimedean_v10 f c hc
  have hzeta :=
    fixed_line_zeta_logDeriv_eq_neg_primeSum_v10 f c hc

  have hnorm :
      k * (∫ t : ℝ, XiProfileV10 f c t) =
        2 * (
          k * (∫ t : ℝ, PoleProfileV10 f c t) +
          k * (∫ t : ℝ, GammaProfileV10 f c t) +
          k * (∫ t : ℝ, ZetaProfileV10 f c t)) := by
    rw [hdecomp, hsplit]
    ring

  have hk : k = (1 / (2 * Real.pi) : ℂ) := rfl
  rw [hk] at hnorm

  have hzero' :
      (1 / (2 * Real.pi) : ℂ) *
        (∫ t : ℝ, XiProfileV10 f c t) =
      2 * (∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 f.1 rho) := by
    simpa [XiProfileV10] using hzero

  have hpole' :
      (1 / (2 * Real.pi) : ℂ) *
        (∫ t : ℝ, PoleProfileV10 f c t) =
      mellin f.1 0 + mellin f.1 1 := by
    simpa [PoleProfileV10] using hpole

  have hgamma' :
      (1 / (2 * Real.pi) : ℂ) *
        (∫ t : ℝ, GammaProfileV10 f c t) =
      -WeilArchimedeanConstantV1 * f.1 1 -
        WeilArchimedeanIntegralV1 f.1 := by
    simpa [GammaProfileV10] using hgamma

  have hzeta' :
      (1 / (2 * Real.pi) : ℂ) *
        (∫ t : ℝ, ZetaProfileV10 f c t) =
      -WeilPrimeSumV1 f.1 := by
    simpa [ZetaProfileV10] using hzeta

  rw [hzero', hpole', hgamma', hzeta'] at hnorm
  unfold WeilExplicitRightSideV1
  linear_combination hnorm

/-- The first whole repository-native normalized explicit formula.

This is the theorem name used by the RH assumption census as the next whole
identity target.  The fixed line is specialized to c=2; the preceding theorem
shows the result is independent of that arbitrary choice. -/
theorem weil_compact_smooth_explicit_formula_v1
    (f : WeilCompactSmoothGV1) :
    (∑' rho : RiemannNontrivialZeroIndexV2,
      WeilZeroIndexSummandV1 f.1 rho) =
      mellin f.1 0 + mellin f.1 1 -
        WeilExplicitRightSideV1 f.1 := by
  have h :=
    whole_explicit_formula_on_fixed_line_v10
      f 2 (by norm_num : (1 : ℝ) < 2)
  have htwo : (2 : ℂ) ≠ 0 := by norm_num
  apply (mul_left_cancel₀ htwo)
  simpa only [mul_sub] using h

end AEGIS.WeilExplicitFormulaV10

#print axioms AEGIS.WeilExplicitFormulaV10.whole_explicit_formula_on_fixed_line_v10
#print axioms AEGIS.WeilExplicitFormulaV10.weil_compact_smooth_explicit_formula_v1
~~~~~~

## WeilXiLogDerivDecompositionV10

Path: `source/WeilXiLogDerivDecompositionV10.lean`

Original source lines: 1–310

Full file SHA256: `b55523198d63b3ad12149e7ebaed92530b5b8bfd2b9fa15c4e732874cf25c34f`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilXiLogDerivDecompositionV10.lean

~~~~~~lean
import WeilFixedLineCompletedGammaV10
import WeilFixedLineZeroSideV10
import ZeroCountingBoundV1
import Mathlib.Analysis.SpecialFunctions.Gamma.Deligne
import Mathlib.Analysis.SpecialFunctions.Gamma.Digamma
import Mathlib.Analysis.SpecialFunctions.Pow.Deriv
import Mathlib.Analysis.Calculus.LogDeriv
import Mathlib.NumberTheory.LSeries.Dirichlet
import Mathlib.Tactic

/-!
AEGIS Ω — pinned-compatible xi logarithmic-derivative decomposition V10.

On Re(s) > 1 this module derives, on the exact Mathlib pin used by the RH
lane,

  xi'/xi(s)
    = 1/s + 1/(s-1)
      - (log pi)/2 + (1/2) psi(s/2)
      + zeta'/zeta(s).

No newer Mathlib convenience theorem is imported: the Gamma_R logarithmic
derivative is rebuilt from the pinned const-cpow derivative, Gamma chain rule,
and the pinned definition of digamma.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology Complex
open scoped Topology

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilXiLogDerivDecompositionV10

/-- Logarithmic derivative of Deligne's real Gamma factor on the positive
half-plane, proved against the pinned Mathlib API. -/
theorem logDeriv_GammaR_v10 (s : ℂ) (hs : 0 < s.re) :
    _root_.logDeriv Complex.Gammaℝ s =
      -(((Real.log Real.pi : ℝ) : ℂ) / 2) +
        (1 / 2 : ℂ) * Complex.digamma (s / 2) := by
  let p : ℂ → ℂ := fun z => (Real.pi : ℂ) ^ (-z / 2)
  let g : ℂ → ℂ := fun z => Complex.Gamma (z / 2)

  have hpi : (Real.pi : ℂ) ≠ 0 := by
    exact Complex.ofReal_ne_zero.mpr Real.pi_ne_zero

  have hpDer :
      HasDerivAt p
        ((Real.pi : ℂ) ^ (-s / 2) *
          Complex.log (Real.pi : ℂ) * (-1 / 2)) s := by
    have hlin :
        HasDerivAt (fun z : ℂ => -z / 2) (-1 / 2) s := by
      simpa using (hasDerivAt_id s).neg.div_const 2
    simpa [p] using hlin.const_cpow (Or.inl hpi)

  have hpne : p s ≠ 0 := by
    dsimp [p]
    rw [Complex.cpow_def_of_ne_zero hpi]
    exact Complex.exp_ne_zero _

  have hs2 : 0 < (s / 2).re := by
    simpa using (div_pos hs (by norm_num : (0 : ℝ) < 2))

  have hGammaNe : Complex.Gamma (s / 2) ≠ 0 :=
    Complex.Gamma_ne_zero_of_re_pos hs2

  have hGammaDiff : DifferentiableAt ℂ Complex.Gamma (s / 2) :=
    Complex.differentiableAt_Gamma (s / 2) (by
      intro m h
      have hre := congrArg Complex.re h
      simp at hre
      have hm : (0 : ℝ) ≤ m := Nat.cast_nonneg m
      linarith)

  have hhalf :
      DifferentiableAt ℂ (fun z : ℂ => z / 2) s := by
    fun_prop

  have hgDiff : DifferentiableAt ℂ g s := by
    dsimp [g]
    exact hGammaDiff.comp s hhalf

  have hgNe : g s ≠ 0 := by
    simpa [g] using hGammaNe

  have hpLog :
      _root_.logDeriv p s =
        -(((Real.log Real.pi : ℝ) : ℂ) / 2) := by
    rw [_root_.logDeriv_apply, hpDer.deriv]
    have hlog :
        Complex.log (Real.pi : ℂ) = (Real.log Real.pi : ℂ) := by
      rw [← Complex.ofReal_log Real.pi_pos.le]
    rw [hlog]
    dsimp [p] at hpne ⊢
    field_simp [hpne]

  have hgLog :
      _root_.logDeriv g s =
        (1 / 2 : ℂ) * Complex.digamma (s / 2) := by
    have hcomp :=
      _root_.logDeriv_comp
        (f := Complex.Gamma)
        (g := fun z : ℂ => z / 2)
        hGammaDiff hhalf
    change _root_.logDeriv g s =
      (1 / 2 : ℂ) * Complex.digamma (s / 2)
    dsimp [g]
    rw [show (fun z : ℂ => Complex.Gamma (z / 2)) =
        Complex.Gamma ∘ (fun z : ℂ => z / 2) by rfl,
      hcomp, ← Complex.digamma_def]
    simp
    ring

  change
    _root_.logDeriv (fun z : ℂ =>
      (Real.pi : ℂ) ^ (-z / 2) * Complex.Gamma (z / 2)) s =
      _
  rw [_root_.logDeriv_mul s hpne hgNe
    hpDer.differentiableAt hgDiff, hpLog, hgLog]

/-- Local factorization of xi by the four nonconstant factors on Re(s)>1. -/
private theorem xi_factorization_eventually_v10
    (s : ℂ) (hs : 1 < s.re) :
    LiCriterion.riemannXi =ᶠ[𝓝 s]
      (fun z : ℂ =>
        (1 / 2 : ℂ) *
          (((z * (z - 1)) * Complex.Gammaℝ z) * riemannZeta z)) := by
  have hopen : IsOpen {z : ℂ | 1 < z.re} := by
    exact Complex.continuous_re.isOpen_preimage (Ioi (1 : ℝ)) isOpen_Ioi
  have hsMem : s ∈ {z : ℂ | 1 < z.re} := hs
  filter_upwards [hopen.mem_nhds hsMem] with z hz
  have hz0 : z ≠ 0 := by
    intro h
    subst z
    norm_num at hz
  have hz1 : z ≠ 1 := by
    intro h
    subst z
    norm_num at hz
  have hGamma : Complex.Gammaℝ z ≠ 0 :=
    Complex.Gammaℝ_ne_zero_of_re_pos (lt_trans zero_lt_one hz)
  have hxi :
      LiCriterion.riemannXi z =
        (1 / 2 : ℂ) * z * (z - 1) * completedRiemannZeta z := by
    simpa [LiCriterion.riemannXi, XiZeros.riemannXi] using
      (XiZeros.xi_eq_half_s_sm1_Lambda (s := z) hz0 hz1)
  have hzetaDef :=
    riemannZeta_def_of_ne_zero hz0
  have hcompleted :
      completedRiemannZeta z =
        Complex.Gammaℝ z * riemannZeta z := by
    rw [hzetaDef]
    field_simp [hGamma]
  rw [hxi, hcompleted]
  ring

/-- Pointwise xi logarithmic-derivative decomposition on Re(s)>1. -/
theorem xi_logDeriv_decomposition_v10
    (s : ℂ) (hs : 1 < s.re) :
    _root_.logDeriv LiCriterion.riemannXi s =
      1 / s + 1 / (s - 1) +
        (-(((Real.log Real.pi : ℝ) : ℂ) / 2) +
          (1 / 2 : ℂ) * Complex.digamma (s / 2)) +
        deriv riemannZeta s / riemannZeta s := by
  have hs0 : s ≠ 0 := by
    intro h
    subst s
    norm_num at hs
  have hs1 : s ≠ 1 := by
    intro h
    subst s
    norm_num at hs
  have hGamma : Complex.Gammaℝ s ≠ 0 :=
    Complex.Gammaℝ_ne_zero_of_re_pos (lt_trans zero_lt_one hs)
  have hzeta : riemannZeta s ≠ 0 :=
    riemannZeta_ne_zero_of_one_lt_re hs

  have hGammaDiff : DifferentiableAt ℂ Complex.Gammaℝ s := by
    have hGdef : Complex.Gammaℝ =
        fun z : ℂ => (Real.pi : ℂ) ^ (-z / 2) * Complex.Gamma (z / 2) := by
      funext z
      exact Complex.Gammaℝ_def z
    rw [hGdef]
    apply DifferentiableAt.mul
    · have hpi0 : (Real.pi : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr Real.pi_ne_zero
      exact ((differentiableAt_id.neg).div_const 2).const_cpow (Or.inl hpi0)
    · have hs2 : 0 < (s / 2).re := by
        simpa using (div_pos (lt_trans zero_lt_one hs)
          (by norm_num : (0 : ℝ) < 2))
      exact
        (Complex.differentiableAt_Gamma (s / 2) (by
          intro m h
          have hre := congrArg Complex.re h
          simp at hre
          have hm : (0 : ℝ) ≤ m := Nat.cast_nonneg m
          linarith)).comp s (by fun_prop)

  have hzetaDiff : DifferentiableAt ℂ riemannZeta s :=
    differentiableAt_riemannZeta hs1

  let A : ℂ → ℂ := fun z => z
  let B : ℂ → ℂ := fun z => z - 1
  let C : ℂ → ℂ := Complex.Gammaℝ
  let D : ℂ → ℂ := riemannZeta

  have hAne : A s ≠ 0 := hs0
  have hBne : B s ≠ 0 := sub_ne_zero.mpr hs1
  have hCne : C s ≠ 0 := hGamma
  have hDne : D s ≠ 0 := hzeta

  have hAd : DifferentiableAt ℂ A s := by
    dsimp [A]
    fun_prop
  have hBd : DifferentiableAt ℂ B s := by
    dsimp [B]
    fun_prop
  have hCd : DifferentiableAt ℂ C s := by
    simpa [C] using hGammaDiff
  have hDd : DifferentiableAt ℂ D s := by
    simpa [D] using hzetaDiff

  have hAB :
      _root_.logDeriv (fun z => A z * B z) s =
        _root_.logDeriv A s + _root_.logDeriv B s :=
    _root_.logDeriv_mul s hAne hBne hAd hBd
  have hABC :
      _root_.logDeriv (fun z => (A z * B z) * C z) s =
        _root_.logDeriv (fun z => A z * B z) s +
          _root_.logDeriv C s :=
    _root_.logDeriv_mul s
      (mul_ne_zero hAne hBne) hCne (hAd.mul hBd) hCd
  have hABCD :
      _root_.logDeriv (fun z => ((A z * B z) * C z) * D z) s =
        _root_.logDeriv (fun z => (A z * B z) * C z) s +
          _root_.logDeriv D s :=
    _root_.logDeriv_mul s
      (mul_ne_zero (mul_ne_zero hAne hBne) hCne) hDne
      ((hAd.mul hBd).mul hCd) hDd

  have hxiEq :=
    (_root_.logDeriv_congr_nhds
      (xi_factorization_eventually_v10 s hs)).eq_of_nhds

  have hconst :
      _root_.logDeriv
        (fun z : ℂ =>
          (1 / 2 : ℂ) * (((z * (z - 1)) * Complex.Gammaℝ z) *
            riemannZeta z)) s =
      _root_.logDeriv
        (fun z : ℂ => (((z * (z - 1)) * Complex.Gammaℝ z) *
          riemannZeta z)) s := by
    exact _root_.logDeriv_const_mul s (1 / 2 : ℂ) (by norm_num)

  have hAlog : _root_.logDeriv A s = 1 / s := by
    simpa [A] using (_root_.logDeriv_id' s)
  have hBlog : _root_.logDeriv B s = 1 / (s - 1) := by
    dsimp [B]
    simp [_root_.logDeriv_apply, hs1]
  have hClog :
      _root_.logDeriv C s =
        -(((Real.log Real.pi : ℝ) : ℂ) / 2) +
          (1 / 2 : ℂ) * Complex.digamma (s / 2) := by
    simpa [C] using logDeriv_GammaR_v10 s (lt_trans zero_lt_one hs)
  have hDlog :
      _root_.logDeriv D s =
        deriv riemannZeta s / riemannZeta s := by
    rfl

  calc
    _root_.logDeriv LiCriterion.riemannXi s
      = _root_.logDeriv
          (fun z : ℂ =>
            (1 / 2 : ℂ) * (((z * (z - 1)) * Complex.Gammaℝ z) *
              riemannZeta z)) s := hxiEq
    _ = _root_.logDeriv
          (fun z : ℂ => (((z * (z - 1)) * Complex.Gammaℝ z) *
            riemannZeta z)) s := hconst
    _ =
      _root_.logDeriv
        (fun z => ((A z * B z) * C z) * D z) s := by rfl
    _ =
      (_root_.logDeriv A s + _root_.logDeriv B s) +
        _root_.logDeriv C s + _root_.logDeriv D s := by
          rw [hABCD, hABC, hAB]
    _ = _ := by
      rw [hAlog, hBlog, hClog, hDlog]

/-- Fixed-line form consumed by the whole explicit-formula assembly. -/
theorem xi_logDeriv_fixed_line_decomposition_v10
    (c t : ℝ) (hc : 1 < c) :
    _root_.logDeriv LiCriterion.riemannXi
        ((c : ℂ) + (t : ℂ) * I) =
      1 / ((c : ℂ) + (t : ℂ) * I) +
      1 / (((c : ℂ) + (t : ℂ) * I) - 1) +
      AEGIS.WeilFixedLineCompletedGammaV10.WeilCompletedGammaFactorV10 c t +
      deriv riemannZeta ((c : ℂ) + (t : ℂ) * I) /
        riemannZeta ((c : ℂ) + (t : ℂ) * I) := by
  have hs : 1 < (((c : ℂ) + (t : ℂ) * I)).re := by
    simpa using hc
  simpa [AEGIS.WeilFixedLineCompletedGammaV10.WeilCompletedGammaFactorV10]
    using xi_logDeriv_decomposition_v10
      ((c : ℂ) + (t : ℂ) * I) hs

end AEGIS.WeilXiLogDerivDecompositionV10

#print axioms AEGIS.WeilXiLogDerivDecompositionV10.logDeriv_GammaR_v10
#print axioms AEGIS.WeilXiLogDerivDecompositionV10.xi_logDeriv_decomposition_v10
#print axioms AEGIS.WeilXiLogDerivDecompositionV10.xi_logDeriv_fixed_line_decomposition_v10
~~~~~~

## WeilFixedLineZeroSideV10

Path: `source/WeilFixedLineZeroSideV10.lean`

Original source lines: 1–222

Full file SHA256: `f73e90478d261cf1a3864f9792d8c61d7a5b64b988790c08ba01238ca845225c`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineZeroSideV10.lean

~~~~~~lean
import WeilPairedZeroEvaluationV9
import WeilPairedHadamardTsumFusionV1
import WeilZeroCarrierBridgeV10
import Mathlib.Topology.Algebra.InfiniteSum.Module
import Mathlib.Tactic

/-!
AEGIS Ω — paired zero-side fixed-line assembly V10.

This module composes:
* V5 fixed-line paired-Hadamard/Fubini assembly;
* the re-bound paired-kernel tsum fusion;
* V9 paired-zero integral evaluation;
* the public V10 AEGIS/LiCriterion zero-carrier equivalence;
* the provider involution rho ↦ 1-rho and multiplicity preservation.

The result identifies the normalized fixed-line xi log-derivative integral with
the canonical multiplicity-weighted AEGIS zeta-zero tsum.

AUTHORITY_EFFECT = NONE.
-/

open Complex Filter MeasureTheory
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilFixedLineZeroSideV10

open AEGIS.WeilPairedZeroEvaluationV9
open AEGIS.WeilZeroCarrierBridgeV10

def XiMellinZeroTermV10
    (f : ℝ → ℂ) (rho : LiCriterion.NontrivialZero) : ℂ :=
  (analyticOrderNatAt LiCriterion.riemannXi rho.val : ℂ) *
    mellin f rho.val

def XiPairedMellinZeroTermV10
    (f : ℝ → ℂ) (rho : LiCriterion.NontrivialZero) : ℂ :=
  (analyticOrderNatAt LiCriterion.riemannXi rho.val : ℂ) *
    (mellin f rho.val + mellin f (1 - rho.val))

/-- Summability of the provider-indexed zero functional follows by reindexing
the already-proved AEGIS canonical zero sum through the public carrier
equivalence. -/
theorem xi_mellin_zero_summable_v10
    (f : WeilCompactSmoothGV1) :
    Summable (XiMellinZeroTermV10 f.1) := by
  let e := aegisLiNontrivialZeroEquivV10
  have hA := weil_compact_smooth_zero_summable_v1 f
  have hcomp :
      Summable (fun rho : RiemannNontrivialZeroIndexV2 =>
        XiMellinZeroTermV10 f.1 (e rho)) := by
    apply hA.congr
    intro rho
    unfold XiMellinZeroTermV10 WeilZeroIndexSummandV1
    rw [aegisLiNontrivialZeroEquivV10_val,
      xi_zeta_multiplicity_eq_v10]
  exact e.summable_iff.mp hcomp

/-- Reindexing the provider zero tsum onto the AEGIS carrier gives exactly the
canonical AEGIS zero functional. -/
theorem xi_mellin_zero_tsum_eq_aegis_v10
    (f : WeilCompactSmoothGV1) :
    (∑' rho : LiCriterion.NontrivialZero,
      XiMellinZeroTermV10 f.1 rho) =
      ∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 f.1 rho := by
  let e := aegisLiNontrivialZeroEquivV10
  calc
    (∑' rho : LiCriterion.NontrivialZero,
      XiMellinZeroTermV10 f.1 rho)
      =
      ∑' rho : RiemannNontrivialZeroIndexV2,
        XiMellinZeroTermV10 f.1 (e rho) := by
          exact (e.tsum_eq (XiMellinZeroTermV10 f.1)).symm
    _ =
      ∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 f.1 rho := by
          apply tsum_congr
          intro rho
          unfold XiMellinZeroTermV10 WeilZeroIndexSummandV1
          rw [aegisLiNontrivialZeroEquivV10_val,
            xi_zeta_multiplicity_eq_v10]

/-- The reflected provider zero family is summable and has the same tsum as the
unreflected family. -/
theorem xi_reflected_mellin_zero_tsum_eq_v10
    (f : WeilCompactSmoothGV1) :
    (∑' rho : LiCriterion.NontrivialZero,
      (analyticOrderNatAt LiCriterion.riemannXi rho.val : ℂ) *
        mellin f.1 (1 - rho.val)) =
      ∑' rho : LiCriterion.NontrivialZero,
        XiMellinZeroTermV10 f.1 rho := by
  let P := XiMellinZeroTermV10 f.1
  calc
    (∑' rho : LiCriterion.NontrivialZero,
      (analyticOrderNatAt LiCriterion.riemannXi rho.val : ℂ) *
        mellin f.1 (1 - rho.val))
      =
      ∑' rho : LiCriterion.NontrivialZero,
        P (LiCriterion.pairedZero rho) := by
          apply tsum_congr
          intro rho
          exact
            (pairedZero_weighted_mellin_v10 f.1 rho).symm
    _ =
      ∑' rho : LiCriterion.NontrivialZero, P rho := by
          exact LiCriterion.pairedZeroEquiv.tsum_eq P

/-- The paired provider zero tsum is exactly twice the ordinary provider zero
functional. -/
theorem xi_paired_mellin_zero_tsum_eq_two_v10
    (f : WeilCompactSmoothGV1) :
    (∑' rho : LiCriterion.NontrivialZero,
      XiPairedMellinZeroTermV10 f.1 rho) =
      2 * (∑' rho : LiCriterion.NontrivialZero,
        XiMellinZeroTermV10 f.1 rho) := by
  let P := XiMellinZeroTermV10 f.1
  let R : LiCriterion.NontrivialZero → ℂ := fun rho =>
    (analyticOrderNatAt LiCriterion.riemannXi rho.val : ℂ) *
      mellin f.1 (1 - rho.val)
  have hP : Summable P := xi_mellin_zero_summable_v10 f
  have hPpair :
      Summable (fun rho : LiCriterion.NontrivialZero =>
        P (LiCriterion.pairedZero rho)) :=
    LiCriterion.pairedZeroEquiv.summable_iff.mpr hP
  have hR : Summable R := by
    apply hPpair.congr
    intro rho
    exact pairedZero_weighted_mellin_v10 f.1 rho
  have hreflect :
      (∑' rho : LiCriterion.NontrivialZero, R rho) =
        ∑' rho : LiCriterion.NontrivialZero, P rho := by
    simpa [R, P] using xi_reflected_mellin_zero_tsum_eq_v10 f
  have hadd := hP.tsum_add hR
  calc
    (∑' rho : LiCriterion.NontrivialZero,
      XiPairedMellinZeroTermV10 f.1 rho)
      =
      ∑' rho : LiCriterion.NontrivialZero, (P rho + R rho) := by
        apply tsum_congr
        intro rho
        simp [XiPairedMellinZeroTermV10, P, R,
          XiMellinZeroTermV10, mul_add]
    _ =
      (∑' rho : LiCriterion.NontrivialZero, P rho) +
        (∑' rho : LiCriterion.NontrivialZero, R rho) := hadd
    _ =
      2 * (∑' rho : LiCriterion.NontrivialZero, P rho) := by
        rw [hreflect]
        ring

/-- V5 + V9: normalized fixed-line integral of 2 ξ'/ξ against the actual
paired Mellin profile equals the paired provider zero tsum. -/
theorem normalized_two_xi_logDeriv_eq_paired_zero_tsum_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (2 * _root_.logDeriv LiCriterion.riemannXi
          ((c : ℂ) + (t : ℂ) * I)) *
            WeilPairedMellinProfileV5 f c t) =
      ∑' rho : LiCriterion.NontrivialZero,
        XiPairedMellinZeroTermV10 f.1 rho := by
  have hv5 :=
    riemannXi_paired_mellin_logDeriv_fixed_line_integral_v5 f c hc
  rw [hv5]
  rw [← tsum_mul_left]
  apply tsum_congr
  intro rho
  have hv9 :=
    paired_zero_kernel_integral_evaluation_v9 f c hc rho
  let m : ℂ :=
    (analyticOrderNatAt LiCriterion.riemannXi rho.val : ℂ)
  calc
    (1 / (2 * Real.pi) : ℂ) *
      (∫ t : ℝ,
        (m * WeilPairedZeroKernelV3 c t rho) *
          WeilPairedMellinProfileV5 f c t)
      =
      m * ((1 / (2 * Real.pi) : ℂ) *
        ∫ t : ℝ,
          WeilPairedZeroKernelV3 c t rho *
            WeilPairedMellinProfileV5 f c t) := by
        have hfun :
            (fun t : ℝ =>
              (m * WeilPairedZeroKernelV3 c t rho) *
                WeilPairedMellinProfileV5 f c t) =
            (fun t : ℝ =>
              m * (WeilPairedZeroKernelV3 c t rho *
                WeilPairedMellinProfileV5 f c t)) := by
          funext t
          ring
        rw [hfun, integral_const_mul]
        ring
    _ =
      m * (mellin f.1 rho.val + mellin f.1 (1 - rho.val)) := by
        rw [hv9]
    _ = XiPairedMellinZeroTermV10 f.1 rho := by
        rfl

/-- Final zero-side identification on the canonical AEGIS carrier. -/
theorem normalized_two_xi_logDeriv_eq_two_aegis_zero_tsum_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (2 * _root_.logDeriv LiCriterion.riemannXi
          ((c : ℂ) + (t : ℂ) * I)) *
            WeilPairedMellinProfileV5 f c t) =
      2 * (∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroIndexSummandV1 f.1 rho) := by
  rw [normalized_two_xi_logDeriv_eq_paired_zero_tsum_v10 f c hc,
    xi_paired_mellin_zero_tsum_eq_two_v10 f,
    xi_mellin_zero_tsum_eq_aegis_v10 f]

end AEGIS.WeilFixedLineZeroSideV10

#print axioms AEGIS.WeilFixedLineZeroSideV10.xi_mellin_zero_tsum_eq_aegis_v10
#print axioms AEGIS.WeilFixedLineZeroSideV10.xi_paired_mellin_zero_tsum_eq_two_v10
#print axioms AEGIS.WeilFixedLineZeroSideV10.normalized_two_xi_logDeriv_eq_paired_zero_tsum_v10
#print axioms AEGIS.WeilFixedLineZeroSideV10.normalized_two_xi_logDeriv_eq_two_aegis_zero_tsum_v10
~~~~~~

## WeilPairedZeroEvaluationV9

Path: `source/WeilPairedZeroEvaluationV9.lean`

Original source lines: 1–300

Full file SHA256: `77c73f19fae41bc4133709f8d8fa59fa889a3d994dcfd8abb8462b4a49c6450c`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPairedZeroEvaluationV9.lean

~~~~~~lean
import WeilReciprocalPairedTestV8
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.Tactic

/-!
AEGIS Ω — paired-zero fixed-line evaluation v9.

This module formalizes Section 3 of WeilPairedHadamardIdentityV1.md on top of
the exact-head GREEN V4–V8 fixed-line chain.

For
  H_f,c(t) = M f(c+it) + M f(1-c-it)
and
  K_rho(c,t) = 1/(c+it-rho) + 1/(c+it-(1-rho)),
the target is

  (1/(2*pi)) * integral K_rho(c,t) * H_f,c(t) dt
    = M f(rho) + M f(1-rho).

The proof uses only already-established repository ingredients:
- whole-line exponential substitution for the Mellin transform;
- V6 fixed-line Cauchy/Laplace kernel evaluation;
- V8 reciprocal paired-test closure and Mellin identity;
- the involutive symmetry of the paired test in logarithmic coordinates.

No zero-series summation, gamma/digamma normalization, whole explicit formula,
arithmetic sign inequality, global Weil positivity, or RH conclusion is
asserted here.

AUTHORITY_EFFECT = NONE
RH = NOT_PROVEN
-/

open Set Filter Topology Complex MeasureTheory
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilPairedZeroEvaluationV9

/-- Log-coordinate Mellin integrand. -/
def WeilLogMellinIntegrandV9
    (f : WeilCompactSmoothGV1) (a : ℂ) (v : ℝ) : ℂ :=
  Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v)

private theorem exp_real_cpow_sub_one_v9
    (a : ℂ) (v : ℝ) :
    (((Real.exp v : ℝ) : ℂ) *
      (((Real.exp v : ℝ) : ℂ) ^ (a - 1))) =
      Complex.exp (a * (v : ℂ)) := by
  have hx : (((Real.exp v : ℝ) : ℂ) ≠ 0) := by
    exact Complex.ofReal_ne_zero.mpr (Real.exp_ne_zero v)
  rw [Complex.cpow_def_of_ne_zero hx]
  have hlog :
      Complex.log (((Real.exp v : ℝ) : ℂ)) = (v : ℂ) := by
    rw [← Complex.ofReal_log (Real.exp_pos v).le, Real.log_exp]
  rw [hlog, Complex.ofReal_exp, ← Complex.exp_add]
  congr 1
  ring

/-- Exact whole-line logarithmic representation of the Mellin transform. -/
theorem mellin_eq_log_integral_v9
    (f : WeilCompactSmoothGV1) (a : ℂ) :
    mellin f.1 a = ∫ v : ℝ, WeilLogMellinIntegrandV9 f a v := by
  unfold mellin
  simp only [smul_eq_mul]
  symm
  calc
    (∫ v : ℝ, WeilLogMellinIntegrandV9 f a v) =
        ∫ v : ℝ,
          Real.exp v •
            ((((Real.exp v : ℝ) : ℂ) ^ (a - 1)) *
              f.1 (Real.exp v)) := by
      apply integral_congr_ae
      filter_upwards [] with v
      unfold WeilLogMellinIntegrandV9
      change
        Complex.exp (a * (v : ℂ)) * f.1 (Real.exp v) =
          ((Real.exp v : ℝ) : ℂ) *
            ((((Real.exp v : ℝ) : ℂ) ^ (a - 1)) *
              f.1 (Real.exp v))
      rw [← mul_assoc, exp_real_cpow_sub_one_v9]
    _ = ∫ x : ℝ in Ioi (0 : ℝ),
          ((x : ℂ) ^ (a - 1)) * f.1 x := by
      have h := MeasureTheory.integral_image_eq_integral_abs_deriv_smul
        MeasurableSet.univ
        (fun x _ => (Real.hasDerivAt_exp x).hasDerivWithinAt)
        Real.exp_injective.injOn
        (fun x : ℝ => ((x : ℂ) ^ (a - 1)) * f.1 x)
      rw [Set.image_univ, Real.range_exp, Measure.restrict_univ] at h
      rw [h]
      congr 1
      funext v
      rw [abs_of_pos (Real.exp_pos v)]

/-- Compact positive support makes every log-coordinate Mellin integrand
integrable for every complex exponent. -/
private theorem log_mellin_integrable_v9
    (f : WeilCompactSmoothGV1) (a : ℂ) :
    Integrable (WeilLogMellinIntegrandV9 f a) := by
  let K : Set ℝ := Real.log '' tsupport f.1
  have hK : IsCompact K := by
    apply f.2.2.1.image_of_continuousOn
    exact Real.continuousOn_log.mono (by
      intro x hx
      have hx0 : x ≠ 0 := ne_of_gt (f.2.2.2 hx)
      simpa using hx0)
  have hsupp :
      tsupport (WeilLogMellinIntegrandV9 f a) ⊆ K := by
    apply closure_minimal ?_ hK.isClosed
    intro v hv
    by_contra hvK
    apply hv
    have hf0 : f.1 (Real.exp v) = 0 := by
      by_contra hne
      apply hvK
      exact ⟨Real.exp v, subset_tsupport _ hne, Real.log_exp v⟩
    simp [WeilLogMellinIntegrandV9, hf0]
  have hcompact : HasCompactSupport (WeilLogMellinIntegrandV9 f a) :=
    hK.of_isClosed_subset (isClosed_tsupport _) hsupp
  have hfc : Continuous f.1 := f.2.1.continuous
  have hcont : Continuous (WeilLogMellinIntegrandV9 f a) := by
    unfold WeilLogMellinIntegrandV9
    fun_prop
  exact hcont.integrable_of_hasCompactSupport hcompact

/-- The V8 paired test is fixed by reciprocal reflection:
q(e^{-v}) = e^v q(e^v). -/
theorem paired_test_exp_neg_v9
    (f : WeilCompactSmoothGV1) (v : ℝ) :
    (WeilPairedTestV8 f).1 (Real.exp (-v)) =
      ((Real.exp v : ℝ) : ℂ) *
        (WeilPairedTestV8 f).1 (Real.exp v) := by
  change
    f.1 (Real.exp (-v)) +
        (((Real.exp (-v))⁻¹ : ℝ) : ℂ) *
          f.1 ((Real.exp (-v))⁻¹) =
      ((Real.exp v : ℝ) : ℂ) *
        (f.1 (Real.exp v) +
          (((Real.exp v)⁻¹ : ℝ) : ℂ) *
            f.1 ((Real.exp v)⁻¹))
  rw [Real.exp_neg, inv_inv]
  push_cast
  have he : Complex.exp (v : ℂ) ≠ 0 := Complex.exp_ne_zero _
  rw [mul_add, ← mul_assoc, mul_inv_cancel₀ he, one_mul]
  ring

/-- Reflection of the paired-test log-Mellin integrand exchanges a with 1-a. -/
theorem paired_log_reflection_v9
    (f : WeilCompactSmoothGV1) (a : ℂ) (v : ℝ) :
    WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a (-v) =
      WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) (1 - a) v := by
  unfold WeilLogMellinIntegrandV9
  rw [paired_test_exp_neg_v9, Complex.ofReal_exp, ← mul_assoc, ← Complex.exp_add]
  congr 2
  push_cast
  ring

/-- The negative half-line for exponent a equals the positive half-line for
the reflected exponent 1-a. -/
theorem paired_log_negative_eq_positive_v9
    (f : WeilCompactSmoothGV1) (a : ℂ) :
    (∫ v : ℝ in Iic (0 : ℝ),
      WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v) =
      ∫ v : ℝ in Ioi (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) (1 - a) v := by
  have hneg0 := integral_comp_neg_Ioi
    (0 : ℝ)
    (fun v : ℝ => WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v)
  rw [neg_zero] at hneg0
  rw [← hneg0]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro v hv
  exact paired_log_reflection_v9 f a v

/-- The two positive log tails of the reciprocal paired test reconstruct the
full paired Mellin value. -/
theorem paired_positive_log_tails_eq_mellin_pair_v9
    (f : WeilCompactSmoothGV1) (a : ℂ) :
    (∫ v : ℝ in Ioi (0 : ℝ),
      WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v) +
    (∫ v : ℝ in Ioi (0 : ℝ),
      WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) (1 - a) v) =
      mellin f.1 a + mellin f.1 (1 - a) := by
  have hint :=
    log_mellin_integrable_v9 (WeilPairedTestV8 f) a
  have hsplit :=
    intervalIntegral.integral_Iic_add_Ioi (b := (0 : ℝ))
      (f := WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a)
      hint.integrableOn hint.integrableOn
  have hneg := paired_log_negative_eq_positive_v9 f a
  calc
    (∫ v : ℝ in Ioi (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v) +
      (∫ v : ℝ in Ioi (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) (1 - a) v)
        =
      (∫ v : ℝ in Iic (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v) +
      (∫ v : ℝ in Ioi (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v) := by
          rw [hneg]
          ring
    _ = ∫ v : ℝ,
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v := hsplit
    _ = mellin (WeilPairedTestV8 f).1 a :=
      (mellin_eq_log_integral_v9 (WeilPairedTestV8 f) a).symm
    _ = mellin f.1 a + mellin f.1 (1 - a) :=
      weil_paired_test_mellin_v8 f a

/-- Each single fixed-line Cauchy kernel times the concrete paired Mellin
profile is integrable whenever Re(a)<c. -/
private theorem paired_profile_cauchy_integrable_v9
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    Integrable (fun t : ℝ =>
      (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
        WeilPairedMellinProfileV5 f c t) := by
  let k : ℝ → ℂ := fun t =>
    1 / (((c : ℂ) + (t : ℂ) * I) - a)
  let delta : ℝ := c - a.re
  have hdelta : 0 < delta := by
    dsimp [delta]
    linarith
  have hne : ∀ t : ℝ,
      ((c : ℂ) + (t : ℂ) * I) - a ≠ 0 := by
    intro t h
    have hre := congrArg Complex.re h
    simp at hre
    linarith
  have hkcont : Continuous k := by
    dsimp [k]
    exact continuous_const.div (by fun_prop) hne
  have hkbound : ∀ t : ℝ, ‖k t‖ ≤ 1 / delta := by
    intro t
    have hre :
        delta ≤ (((c : ℂ) + (t : ℂ) * I) - a).re := by
      dsimp [delta]
      simp
    have hnorm :
        delta ≤ ‖((c : ℂ) + (t : ℂ) * I) - a‖ :=
      hre.trans (Complex.re_le_norm _)
    dsimp [k]
    rw [norm_div, norm_one]
    exact one_div_le_one_div_of_le hdelta hnorm
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  exact hH.bdd_mul hkcont.aestronglyMeasurable
    (Filter.Eventually.of_forall hkbound)

/-- V6 specialized to the V8 paired test and rewritten to the concrete V5
profile. -/
theorem paired_profile_cauchy_integral_eq_log_tail_v9
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
          WeilPairedMellinProfileV5 f c t) =
      ∫ v : ℝ in Ioi (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) a v := by
  have h :=
    weil_fixed_line_kernel_integral_log_v6
      (WeilPairedTestV8 f) c a ha
  simpa only [WeilFixedLineMellinV6,
    WeilLogMellinIntegrandV9,
    weil_paired_test_fixed_line_profile_v8] using h

/-- Load-bearing paired-zero evaluation from the mathematical proof note. -/
theorem paired_zero_kernel_integral_evaluation_v9
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c)
    (rho : LiCriterion.NontrivialZero) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        WeilPairedZeroKernelV3 c t rho *
          WeilPairedMellinProfileV5 f c t) =
      mellin f.1 rho.val + mellin f.1 (1 - rho.val) := by
  have hrho : rho.val.re < c :=
    rho.property.2.2.trans hc
  have hone : (1 - rho.val).re < c := by
    simp
    linarith [rho.property.2.1, hc]
  have hint_rho :=
    paired_profile_cauchy_integrable_v9 f c rho.val hrho
  have hint_one :=
    paired_profile_cauchy_integrable_v9 f c (1 - rho.val) hone
  simp_rw [WeilPairedZeroKernelV3, add_mul]
  rw [integral_add hint_rho hint_one, mul_add]
  rw [paired_profile_cauchy_integral_eq_log_tail_v9 f c rho.val hrho]
  rw [paired_profile_cauchy_integral_eq_log_tail_v9 f c (1 - rho.val) hone]
  exact paired_positive_log_tails_eq_mellin_pair_v9 f rho.val

end AEGIS.WeilPairedZeroEvaluationV9

#print axioms AEGIS.WeilPairedZeroEvaluationV9.mellin_eq_log_integral_v9
#print axioms AEGIS.WeilPairedZeroEvaluationV9.paired_test_exp_neg_v9
#print axioms AEGIS.WeilPairedZeroEvaluationV9.paired_log_reflection_v9
#print axioms AEGIS.WeilPairedZeroEvaluationV9.paired_log_negative_eq_positive_v9
#print axioms AEGIS.WeilPairedZeroEvaluationV9.paired_positive_log_tails_eq_mellin_pair_v9
#print axioms AEGIS.WeilPairedZeroEvaluationV9.paired_profile_cauchy_integral_eq_log_tail_v9
#print axioms AEGIS.WeilPairedZeroEvaluationV9.paired_zero_kernel_integral_evaluation_v9
~~~~~~

## WeilPairedHadamardTsumFusionV1

Path: `source/WeilPairedHadamardTsumFusionV1.lean`

Original source lines: 1–181

Full file SHA256: `f230e64bcbe4bb6fe089756d0c3281fd2a5131d4d4591cf25f1c6117e856a827`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilPairedHadamardTsumFusionV1.lean

~~~~~~lean
import WeilPairedHadamardFixedLineV1
import Lc.LiCriterion.HadamardSummabilityBridge
import Lc.LiCriterion.XiGrowth
import Hadamard.OrderOne.LogDeriv
import Mathlib.Tactic

/-!
AEGIS Ω — paired Hadamard single-tsum fusion v1.

This module closes only the summability/fusion step left open by
`WeilPairedHadamardFixedLineV1`: each multiplicity-weighted genus-one
log-derivative family is summable away from the zero set, and the difference
of the two absolutely summable families may therefore be fused into the single
paired partial-fraction `tsum`.

No transport to the AEGIS zeta-zero carrier, Mellin evaluation, whole explicit
formula, sign inequality, global Weil positivity, or RH theorem is asserted.
-/

open Complex Filter
open scoped BigOperators

set_option autoImplicit false

noncomputable section

/-- Multiplicity-weighted genus-one Hadamard terms are absolutely summable at
any evaluation point away from the completed-zeta zero set.  The proof mirrors
the provider's unweighted log-derivative majorant, now using the provider's
multiplicity-weighted inverse-square summability. -/
theorem riemannXi_weighted_hadamard_term_summable_v1
    (x : ℂ) (hx : ∀ ρ : LiCriterion.NontrivialZero, x ≠ ρ.val) :
    Summable (fun ρ : LiCriterion.NontrivialZero =>
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (x / (ρ.val * (x - ρ.val)))) := by
  have hweighted :=
    LiCriterion.xi_weighted_genus_one_of_hadamard_order_one
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      LiCriterion.XiGrowth.riemannXi_order_le_one
  have hunweighted :=
    LiCriterion.xi_genus_one_of_hadamard_order_one
      LiCriterion.XiGrowth.riemannXi_hasFiniteOrder
      LiCriterion.XiGrowth.riemannXi_order_le_one
  by_cases hx0 : x = 0
  · subst x
    simpa using
      (summable_zero : Summable (fun _ : LiCriterion.NontrivialZero => (0 : ℂ)))
  have hx_norm_pos : 0 < ‖x‖ := norm_pos_iff.mpr hx0
  let g : LiCriterion.NontrivialZero → ℝ := fun ρ =>
    (2 * ‖x‖) *
      ((analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) / ‖ρ.val‖ ^ 2)
  have hg : Summable g := by
    simpa [g, mul_assoc, mul_left_comm, mul_comm] using
      hweighted.mul_left (2 * ‖x‖)
  refine Summable.of_norm_bounded_eventually
    (f := fun ρ : LiCriterion.NontrivialZero =>
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (x / (ρ.val * (x - ρ.val))))
    (g := g) hg ?_
  let S : Set LiCriterion.NontrivialZero :=
    {ρ | ‖ρ.val‖ ≤ (2 : ℝ) * ‖x‖}
  have hSfinite : S.Finite :=
    Hadamard.OrderOne.finite_norm_le_of_summable_inv_norm_sq
      (z := fun ρ : LiCriterion.NontrivialZero => ρ.val)
      (fun ρ => ρ.ne_zero) hunweighted
      (R := (2 : ℝ) * ‖x‖) (by nlinarith [hx_norm_pos])
  have hnotS : ∀ᶠ ρ in (cofinite : Filter LiCriterion.NontrivialZero), ρ ∉ S := by
    have : (Sᶜ : Set LiCriterion.NontrivialZero) ∈
        (cofinite : Filter LiCriterion.NontrivialZero) := by
      exact Filter.mem_cofinite.2 (by simpa using hSfinite)
    simpa using this
  filter_upwards [hnotS] with ρ hρ
  have hz_gt : (2 : ℝ) * ‖x‖ < ‖ρ.val‖ := by
    have : ¬ ‖ρ.val‖ ≤ (2 : ℝ) * ‖x‖ := by simpa [S] using hρ
    exact lt_of_not_ge this
  have hz_pos : 0 < ‖ρ.val‖ := norm_pos_iff.mpr ρ.ne_zero
  have hdist_pos : 0 < ‖x - ρ.val‖ :=
    norm_pos_iff.mpr (sub_ne_zero.mpr (hx ρ))
  have hdist_lower : (1 / 2 : ℝ) * ‖ρ.val‖ ≤ ‖x - ρ.val‖ := by
    have hx_lt : ‖x‖ < (1 / 2 : ℝ) * ‖ρ.val‖ := by linarith [hz_gt]
    have hsub_lt : (1 / 2 : ℝ) * ‖ρ.val‖ < ‖ρ.val‖ - ‖x‖ := by
      linarith [hx_lt]
    have hsub_le : ‖ρ.val‖ - ‖x‖ ≤ ‖x - ρ.val‖ := by
      have h := norm_sub_norm_le ρ.val x
      simpa [norm_sub_rev] using h
    exact le_trans (le_of_lt hsub_lt) hsub_le
  have hhalf_pos : 0 < (1 / 2 : ℝ) * ‖ρ.val‖ ^ 2 := by positivity
  have hden_le :
      (1 / 2 : ℝ) * ‖ρ.val‖ ^ 2 ≤ ‖ρ.val‖ * ‖x - ρ.val‖ := by
    have h := mul_le_mul_of_nonneg_left hdist_lower (le_of_lt hz_pos)
    simpa [pow_two, mul_assoc, mul_left_comm, mul_comm] using h
  have hinv_le :
      (1 : ℝ) / (‖ρ.val‖ * ‖x - ρ.val‖) ≤
        (2 : ℝ) * ((1 : ℝ) / ‖ρ.val‖ ^ 2) := by
    have h' :
        (1 : ℝ) / (‖ρ.val‖ * ‖x - ρ.val‖) ≤
          (1 : ℝ) / ((1 / 2 : ℝ) * ‖ρ.val‖ ^ 2) :=
      one_div_le_one_div_of_le hhalf_pos hden_le
    have heq :
        (1 : ℝ) / ((1 / 2 : ℝ) * ‖ρ.val‖ ^ 2) =
          (2 : ℝ) * ((1 : ℝ) / ‖ρ.val‖ ^ 2) := by
      field_simp
    exact h'.trans_eq heq
  have hnorm :
      ‖x / (ρ.val * (x - ρ.val))‖ ≤
        (2 * ‖x‖) * ((1 : ℝ) / ‖ρ.val‖ ^ 2) := by
    have heq :
        ‖x / (ρ.val * (x - ρ.val))‖ =
          ‖x‖ * ((1 : ℝ) / (‖ρ.val‖ * ‖x - ρ.val‖)) := by
      simp [div_eq_mul_inv, mul_comm]
    rw [heq]
    have hmul := mul_le_mul_of_nonneg_left hinv_le (norm_nonneg x)
    simpa [mul_assoc, mul_left_comm, mul_comm] using hmul
  have hm_nonneg :
      0 ≤ (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) := by positivity
  calc
    ‖(analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (x / (ρ.val * (x - ρ.val)))‖ =
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) *
          ‖x / (ρ.val * (x - ρ.val))‖ := by simp
    _ ≤ (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℝ) *
          ((2 * ‖x‖) * ((1 : ℝ) / ‖ρ.val‖ ^ 2)) :=
      mul_le_mul_of_nonneg_left hnorm hm_nonneg
    _ = g ρ := by
      simp [g, div_eq_mul_inv, mul_assoc, mul_left_comm, mul_comm]

/-- The already pointwise-paired partial-fraction kernel is summable with the
same analytic multiplicities. -/
theorem riemannXi_paired_kernel_summable_v1
    (s : ℂ)
    (hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val)
    (h1s : ∀ ρ : LiCriterion.NontrivialZero, 1 - s ≠ ρ.val) :
    Summable (fun ρ : LiCriterion.NontrivialZero =>
      (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
        (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val)))) := by
  have ha := riemannXi_weighted_hadamard_term_summable_v1 s hs
  have hb := riemannXi_weighted_hadamard_term_summable_v1 (1 - s) h1s
  have hsub := ha.sub hb
  have hfun :
      (fun ρ : LiCriterion.NontrivialZero =>
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            (s / (ρ.val * (s - ρ.val))) -
          (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
            ((1 - s) / (ρ.val * ((1 - s) - ρ.val)))) =
      (fun ρ : LiCriterion.NontrivialZero =>
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val)))) := by
    funext ρ
    rw [← mul_sub]
    congr 1
    exact paired_hadamard_partial_fraction_v1
      s ρ.val ρ.ne_zero (hs ρ) (h1s ρ)
  rw [hfun] at hsub
  exact hsub

/-- The difference-of-two-tsums theorem from #519 is exactly one absolutely
summable paired partial-fraction `tsum`. -/
theorem riemannXi_paired_hadamard_tsum_v1
    (s : ℂ)
    (hs : ∀ ρ : LiCriterion.NontrivialZero, s ≠ ρ.val)
    (h1s : ∀ ρ : LiCriterion.NontrivialZero, 1 - s ≠ ρ.val) :
    2 * _root_.logDeriv LiCriterion.riemannXi s =
      ∑' ρ : LiCriterion.NontrivialZero,
        (analyticOrderNatAt LiCriterion.riemannXi ρ.val : ℂ) *
          (1 / (s - ρ.val) + 1 / (s - (1 - ρ.val))) := by
  rw [riemannXi_paired_hadamard_difference_v1 s hs h1s]
  have ha := riemannXi_weighted_hadamard_term_summable_v1 s hs
  have hb := riemannXi_weighted_hadamard_term_summable_v1 (1 - s) h1s
  rw [← ha.tsum_sub hb]
  apply tsum_congr
  intro ρ
  rw [← mul_sub]
  congr 1
  exact paired_hadamard_partial_fraction_v1
    s ρ.val ρ.ne_zero (hs ρ) (h1s ρ)

end

#print axioms riemannXi_weighted_hadamard_term_summable_v1
#print axioms riemannXi_paired_kernel_summable_v1
#print axioms riemannXi_paired_hadamard_tsum_v1
~~~~~~

## WeilZeroCarrierBridgeV10

Path: `source/WeilZeroCarrierBridgeV10.lean`

Original source lines: 1–119

Full file SHA256: `fa4c1989b248d5117e3478862b7934250c0a9ef5f190b7d87ab650fe3a2942f8`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilZeroCarrierBridgeV10.lean

~~~~~~lean
import ZeroCountingMellinSummabilityV1
import Lc.LiCriterion.Basic
import Mathlib.Analysis.Analytic.Order
import Mathlib.Tactic

/-!
AEGIS Ω — public zero-carrier equivalence and reflection multiplicity bridge V10.

The existing counting/summability lane already contained the mathematical map
from the AEGIS nontrivial-zeta-zero carrier to the provider's
`LiCriterion.NontrivialZero`, but that map was private.  This module exposes
the actual equivalence and proves multiplicity preservation under both the
carrier identification and the provider involution `rho ↦ 1-rho`.

AUTHORITY_EFFECT = NONE.
-/

open Complex

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilZeroCarrierBridgeV10

/-- The AEGIS zero carrier and the pinned LiCriterion carrier encode exactly
the same nontrivial zeta zeros. -/
noncomputable def aegisLiNontrivialZeroEquivV10 :
    RiemannNontrivialZeroIndexV2 ≃ LiCriterion.NontrivialZero where
  toFun rho := by
    have hstrip :=
      riemann_zeta_nontrivial_zero_critical_strip_v1 rho.2.1 rho.2.2
    exact ⟨rho.1, rho.2.1, hstrip.1, hstrip.2⟩
  invFun rho := by
    refine ⟨rho.1, rho.2.1, ?_⟩
    intro htriv
    rcases htriv with ⟨n, hn⟩
    have hpos : 0 < rho.1.re := rho.2.2.1
    have hre := congrArg Complex.re hn
    rw [hre] at hpos
    have hnonpos : (-2 * ((n : ℂ) + 1)).re ≤ 0 := by
      simp
      positivity
    exact (not_lt_of_ge hnonpos) hpos
  left_inv rho := by
    apply Subtype.ext
    rfl
  right_inv rho := by
    apply Subtype.ext
    rfl

@[simp] theorem aegisLiNontrivialZeroEquivV10_val
    (rho : RiemannNontrivialZeroIndexV2) :
    (aegisLiNontrivialZeroEquivV10 rho).val = rho.1 := rfl

@[simp] theorem aegisLiNontrivialZeroEquivV10_symm_val
    (rho : LiCriterion.NontrivialZero) :
    (aegisLiNontrivialZeroEquivV10.symm rho).1 = rho.val := rfl

/-- Public version of the existing pointwise xi/zeta multiplicity
identification. -/
theorem xi_zeta_multiplicity_eq_v10
    (rho : RiemannNontrivialZeroIndexV2) :
    analyticOrderNatAt LiCriterion.riemannXi rho.1 =
      analyticOrderNatAt riemannZeta rho.1 := by
  simpa using
    li_xi_zeta_multiplicity_eq_v1
      (aegisLiNontrivialZeroEquivV10 rho)

/-- Analytic order of xi is invariant under the provider involution
`rho ↦ 1-rho`. -/
theorem xi_pairedZero_multiplicity_eq_v10
    (rho : LiCriterion.NontrivialZero) :
    analyticOrderNatAt LiCriterion.riemannXi
        (LiCriterion.pairedZero rho).val =
      analyticOrderNatAt LiCriterion.riemannXi rho.val := by
  let g : ℂ → ℂ := fun z => 1 - z
  have hg : AnalyticAt ℂ g rho.val := by
    fun_prop
  have hgd : deriv g rho.val ≠ 0 := by
    dsimp [g]
    simp
  have hcomp :=
    analyticOrderAt_comp_of_deriv_ne_zero
      (f := LiCriterion.riemannXi)
      (g := g)
      (z₀ := rho.val)
      hg hgd
  have hfun :
      LiCriterion.riemannXi ∘ g = LiCriterion.riemannXi := by
    funext z
    dsimp [Function.comp_def, g]
    exact (LiCriterion.xi_functional_equation z).symm
  have horder :
      analyticOrderAt LiCriterion.riemannXi
          (LiCriterion.pairedZero rho).val =
        analyticOrderAt LiCriterion.riemannXi rho.val := by
    rw [LiCriterion.pairedZero_val]
    change
      analyticOrderAt LiCriterion.riemannXi (g rho.val) =
        analyticOrderAt LiCriterion.riemannXi rho.val
    rw [← hcomp]
    rw [hfun]
  exact congrArg ENat.toNat horder

/-- The provider involution is the value-level reflection `rho ↦ 1-rho`
and preserves the multiplicity-weighted Mellin coefficient. -/
theorem pairedZero_weighted_mellin_v10
    (f : ℝ → ℂ) (rho : LiCriterion.NontrivialZero) :
    (analyticOrderNatAt LiCriterion.riemannXi
        (LiCriterion.pairedZero rho).val : ℂ) *
        mellin f (LiCriterion.pairedZero rho).val =
      (analyticOrderNatAt LiCriterion.riemannXi rho.val : ℂ) *
        mellin f (1 - rho.val) := by
  rw [xi_pairedZero_multiplicity_eq_v10, LiCriterion.pairedZero_val]

end AEGIS.WeilZeroCarrierBridgeV10

#print axioms AEGIS.WeilZeroCarrierBridgeV10.xi_zeta_multiplicity_eq_v10
#print axioms AEGIS.WeilZeroCarrierBridgeV10.xi_pairedZero_multiplicity_eq_v10
~~~~~~

## WeilFixedLineArithmeticV10

Path: `source/WeilFixedLineArithmeticV10.lean`

Original source lines: 1–305

Full file SHA256: `4954ae2e172f8620eb410f94acfb076b3f238c6d88a65cc66ad1128d01b22521`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilFixedLineArithmeticV10.lean

~~~~~~lean
import WeilXiLogDerivDecompositionV10
import WeilPairedZeroEvaluationV9
import WeilPrimeLineIdentityV1
import WeilPrimeSummabilityV1
import WeilPoleTermV1
import WeilFixedLineCompletedGammaV10
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Tactic

/-!
AEGIS Ω — fixed-line pole and prime assembly V10.

This module closes the two elementary/arithmetic pieces of the normalized
explicit formula against the actual V5 paired Mellin profile.

* Pole contribution:
    I_c[(1/s + 1/(s-1)) H] = M f(0) + M f(1).
* Prime contribution:
    I_c[(zeta'/zeta) H] = - WeilPrimeSumV1 f.

The prime theorem is the existing kernelized von-Mangoldt line identity
applied to the V8 reciprocal-paired test; a finite-support-safe nat reindex
identifies its RHS with the repository's shifted prime-power sum.

AUTHORITY_EFFECT = NONE.
-/

open Set Filter Topology Complex MeasureTheory
open scoped BigOperators

set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilFixedLineArithmeticV10

open AEGIS.WeilPairedZeroEvaluationV9

/-- Public version of the Cauchy/profile integrability used internally by V9. -/
theorem paired_profile_cauchy_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (a : ℂ) (ha : a.re < c) :
    Integrable (fun t : ℝ =>
      (1 / (((c : ℂ) + (t : ℂ) * I) - a)) *
        WeilPairedMellinProfileV5 f c t) := by
  let k : ℝ → ℂ := fun t =>
    1 / (((c : ℂ) + (t : ℂ) * I) - a)
  let delta : ℝ := c - a.re
  have hdelta : 0 < delta := by
    dsimp [delta]
    linarith
  have hne : ∀ t : ℝ,
      ((c : ℂ) + (t : ℂ) * I) - a ≠ 0 := by
    intro t h
    have hre := congrArg Complex.re h
    simp at hre
    linarith
  have hkcont : Continuous k := by
    dsimp [k]
    exact continuous_const.div (by fun_prop) hne
  have hkbound : ∀ t : ℝ, ‖k t‖ ≤ 1 / delta := by
    intro t
    have hre :
        delta ≤ (((c : ℂ) + (t : ℂ) * I) - a).re := by
      dsimp [delta]
      simp
    have hnorm :
        delta ≤ ‖((c : ℂ) + (t : ℂ) * I) - a‖ :=
      hre.trans (Complex.re_le_norm _)
    dsimp [k]
    rw [norm_div, norm_one]
    exact one_div_le_one_div_of_le hdelta hnorm
  have hH :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  exact hH.bdd_mul hkcont.aestronglyMeasurable
    (Filter.Eventually.of_forall hkbound)

/-- The elementary xi poles evaluate to the two Mellin endpoints. -/
theorem fixed_line_poles_eq_mellin_endpoints_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (1 / ((c : ℂ) + (t : ℂ) * I) +
          1 / (((c : ℂ) + (t : ℂ) * I) - 1)) *
          WeilPairedMellinProfileV5 f c t) =
      mellin f.1 0 + mellin f.1 1 := by
  have h0c : (0 : ℂ).re < c := by
    simp
    linarith
  have h1c : (1 : ℂ).re < c := by
    simpa using hc
  have h0i :=
    paired_profile_cauchy_integrable_v10 f c 0 h0c
  have h1i :=
    paired_profile_cauchy_integrable_v10 f c 1 h1c
  have h0 :=
    paired_profile_cauchy_integral_eq_log_tail_v9 f c 0 h0c
  have h1 :=
    paired_profile_cauchy_integral_eq_log_tail_v9 f c 1 h1c
  have hpair :=
    paired_positive_log_tails_eq_mellin_pair_v9 f (0 : ℂ)
  calc
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (1 / ((c : ℂ) + (t : ℂ) * I) +
          1 / (((c : ℂ) + (t : ℂ) * I) - 1)) *
          WeilPairedMellinProfileV5 f c t)
      =
      ((1 / (2 * Real.pi) : ℂ) *
        ∫ t : ℝ,
          (1 / (((c : ℂ) + (t : ℂ) * I) - 0)) *
            WeilPairedMellinProfileV5 f c t) +
      ((1 / (2 * Real.pi) : ℂ) *
        ∫ t : ℝ,
          (1 / (((c : ℂ) + (t : ℂ) * I) - 1)) *
            WeilPairedMellinProfileV5 f c t) := by
        rw [show
          (fun t : ℝ =>
            (1 / ((c : ℂ) + (t : ℂ) * I) +
              1 / (((c : ℂ) + (t : ℂ) * I) - 1)) *
              WeilPairedMellinProfileV5 f c t) =
          (fun t : ℝ =>
            (1 / (((c : ℂ) + (t : ℂ) * I) - 0)) *
              WeilPairedMellinProfileV5 f c t +
            (1 / (((c : ℂ) + (t : ℂ) * I) - 1)) *
              WeilPairedMellinProfileV5 f c t) by
                funext t
                simp [add_mul]]
        rw [integral_add h0i h1i]
        ring
    _ =
      (∫ v : ℝ in Ioi (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) 0 v) +
      (∫ v : ℝ in Ioi (0 : ℝ),
        WeilLogMellinIntegrandV9 (WeilPairedTestV8 f) 1 v) := by
          rw [h0, h1]
    _ = mellin f.1 0 + mellin f.1 1 := by
          simpa using hpair

/-- The raw von-Mangoldt evaluation of the V8 paired test is exactly the
repository's shifted prime-power sum. -/
theorem paired_test_vonMangoldt_tsum_eq_primeSum_v10
    (f : WeilCompactSmoothGV1) :
    (∑' n : ℕ,
      (ArithmeticFunction.vonMangoldt n : ℂ) *
        (WeilPairedTestV8 f).1 (n : ℝ)) =
      WeilPrimeSumV1 f.1 := by
  let R : ℕ → ℂ := fun n =>
    (ArithmeticFunction.vonMangoldt n : ℂ) *
      (WeilPairedTestV8 f).1 (n : ℝ)
  have hshift :
      (fun n : ℕ => R (n + 1)) = WeilPrimeTermV1 f.1 := by
    funext n
    unfold R WeilPrimeTermV1
    rw [weil_paired_test_apply_v8]
    unfold WeilReciprocalFnV8
    push_cast
    ring
  have hsumShift : Summable (fun n : ℕ => R (n + 1)) := by
    rw [hshift]
    exact weil_compact_smooth_prime_summable_v1 f
  have hsumR : Summable R := by
    exact (summable_nat_add_iff 1).mp hsumShift
  unfold WeilPrimeSumV1
  calc
    (∑' n : ℕ,
      (ArithmeticFunction.vonMangoldt n : ℂ) *
        (WeilPairedTestV8 f).1 (n : ℝ))
      = ∑' n : ℕ, R n := by rfl
    _ = R 0 + ∑' n : ℕ, R (n + 1) := hsumR.tsum_eq_zero_add
    _ = ∑' n : ℕ, R (n + 1) := by
          simp [R]
    _ = ∑' n : ℕ, WeilPrimeTermV1 f.1 n := by
          rw [hshift]

/-- Uniform L1 integrability of the von-Mangoldt fixed-line product against
the paired Mellin profile. -/
theorem fixed_line_neg_zeta_logDeriv_integrable_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    Integrable
      (fun t : ℝ =>
        (-deriv riemannZeta ((c : ℂ) + (t : ℂ) * I) /
          riemannZeta ((c : ℂ) + (t : ℂ) * I)) *
          WeilPairedMellinProfileV5 f c t) := by
  let a : ℕ → ℂ := fun n =>
    (ArithmeticFunction.vonMangoldt n : ℂ)
  let H : ℝ → ℂ := fun t => WeilPairedMellinProfileV5 f c t
  have ha : LSeriesSummable a (c : ℂ) := by
    dsimp [a]
    exact ArithmeticFunction.LSeriesSummable_vonMangoldt (by simpa using hc)
  have hH : Integrable H :=
    (weil_paired_mellin_profile_has_vertical_norm_moments_two_v5 f c).1
  let C : ℝ := ∑' n : ℕ, ‖LSeries.term a (c : ℂ) n‖
  have hC0 : 0 ≤ C := tsum_nonneg (fun _ => norm_nonneg _)
  have hbound :
      ∀ t : ℝ,
        ‖LSeries a ((c : ℂ) + (t : ℂ) * I)‖ ≤ C := by
    intro t
    have hat :
        LSeriesSummable a ((c : ℂ) + (t : ℂ) * I) :=
      LSeriesSummable.of_re_le_re (by simp) ha
    calc
      ‖LSeries a ((c : ℂ) + (t : ℂ) * I)‖
        ≤ ∑' n : ℕ,
          ‖LSeries.term a ((c : ℂ) + (t : ℂ) * I) n‖ :=
            norm_tsum_le_tsum_norm hat.norm
      _ = C := by
        apply tsum_congr
        intro n
        exact lseries_term_vertical_norm_v1 a c t n
  have hmajor : Integrable (fun t : ℝ => C * ‖H t‖) :=
    hH.norm.const_mul C
  have hLmeas :
      AEStronglyMeasurable
        (fun t : ℝ =>
          LSeries a ((c : ℂ) + (t : ℂ) * I)) := by
    have hcont :
        Continuous
          (fun t : ℝ =>
            LSeries a ((c : ℂ) + (t : ℂ) * I)) := by
              unfold LSeries
              refine continuous_tsum (u := fun n => ‖LSeries.term a (c : ℂ) n‖)
                (fun n => ?_) ha.norm (fun n t => ?_)
              · rcases eq_or_ne n 0 with rfl | hn
                · simp only [LSeries.term_zero]
                  exact continuous_const
                · simp only [LSeries.term_of_ne_zero hn]
                  have hn' : (n : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr hn
                  refine continuous_const.div
                    ((by fun_prop : Continuous fun t : ℝ => (c : ℂ) + (t : ℂ) * I).const_cpow
                      (Or.inl hn')) (fun t => ?_)
                  rw [Complex.cpow_def_of_ne_zero hn']
                  exact Complex.exp_ne_zero _
              · exact (lseries_term_vertical_norm_v1 a c t n).le
    exact hcont.aestronglyMeasurable
  have hprod :
      Integrable
        (fun t : ℝ =>
          LSeries a ((c : ℂ) + (t : ℂ) * I) * H t) := by
    refine hmajor.mono'
      (hLmeas.mul hH.aestronglyMeasurable)
      (Filter.Eventually.of_forall fun t => ?_)
    rw [norm_mul]
    exact mul_le_mul_of_nonneg_right (hbound t) (norm_nonneg _)
  exact hprod.congr
    (Filter.Eventually.of_forall fun t => by
      have hz :=
        WeilPoleTerm.vonMangoldt_lseries_eq_neg_logDeriv_v1
          (s := (c : ℂ) + (t : ℂ) * I)
          (by simpa using hc)
      dsimp [a, H] at hz ⊢
      rw [hz, neg_div])

/-- The zeta logarithmic-derivative contribution is minus the repository
prime-power sum. -/
theorem fixed_line_zeta_logDeriv_eq_neg_primeSum_v10
    (f : WeilCompactSmoothGV1) (c : ℝ) (hc : 1 < c) :
    ((1 / (2 * Real.pi) : ℂ) *
      ∫ t : ℝ,
        (deriv riemannZeta ((c : ℂ) + (t : ℂ) * I) /
          riemannZeta ((c : ℂ) + (t : ℂ) * I)) *
          WeilPairedMellinProfileV5 f c t) =
      -WeilPrimeSumV1 f.1 := by
  have hprime :=
    weil_compact_smooth_prime_line_identity_v1
      (WeilPairedTestV8 f) c hc
  have hsum :=
    paired_test_vonMangoldt_tsum_eq_primeSum_v10 f
  have hnegInt :=
    fixed_line_neg_zeta_logDeriv_integrable_v10 f c hc
  have hsign :
      (∫ t : ℝ,
        (deriv riemannZeta ((c : ℂ) + (t : ℂ) * I) /
          riemannZeta ((c : ℂ) + (t : ℂ) * I)) *
          WeilPairedMellinProfileV5 f c t) =
      - ∫ t : ℝ,
        (-deriv riemannZeta ((c : ℂ) + (t : ℂ) * I) /
          riemannZeta ((c : ℂ) + (t : ℂ) * I)) *
          WeilPairedMellinProfileV5 f c t := by
    rw [← integral_neg]
    apply integral_congr_ae
    exact Filter.Eventually.of_forall (fun t => by ring)
  rw [hsign]
  have hprofile :
      ∀ t : ℝ,
        mellin (WeilPairedTestV8 f).1
          ((c : ℂ) + (t : ℂ) * I) =
          WeilPairedMellinProfileV5 f c t :=
    weil_paired_test_fixed_line_profile_v8 f c
  simp_rw [hprofile] at hprime
  change
    (1 / (2 * Real.pi) : ℂ) *
      (-(∫ t : ℝ,
        (-deriv riemannZeta ((c : ℂ) + (t : ℂ) * I) /
          riemannZeta ((c : ℂ) + (t : ℂ) * I)) *
          WeilPairedMellinProfileV5 f c t)) =
      -WeilPrimeSumV1 f.1
  have hp : ((1 / (2 * Real.pi) : ℝ) : ℂ) =
      (1 / (2 * Real.pi) : ℂ) := by norm_num
  rw [← hp, mul_neg, ← Complex.real_smul, hprime, hsum]

end AEGIS.WeilFixedLineArithmeticV10

#print axioms AEGIS.WeilFixedLineArithmeticV10.fixed_line_poles_eq_mellin_endpoints_v10
#print axioms AEGIS.WeilFixedLineArithmeticV10.paired_test_vonMangoldt_tsum_eq_primeSum_v10
#print axioms AEGIS.WeilFixedLineArithmeticV10.fixed_line_neg_zeta_logDeriv_integrable_v10
#print axioms AEGIS.WeilFixedLineArithmeticV10.fixed_line_zeta_logDeriv_eq_neg_primeSum_v10
~~~~~~

## RHFinalClosureSpineV1

Path: `source/RHFinalClosureSpineV1.lean`

Original source lines: 1–76

Full file SHA256: `7f6b7f44d8ff9158138daf45214d23c72728aaf4b914a0d9adeb7f30436255e6`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/RHFinalClosureSpineV1.lean

~~~~~~lean
import WeilAutocorrelationClosureV1
import WeilSeparatedArchBridgeV31
import Mathlib.Tactic

/-!
AEGIS Ω — final RH closure spine v1.

This module does not assert RH. It consolidates the already-existing proof
surface into one exact final sign target.

FinalSignResidualV1 is the universal arithmetic nonpositivity statement
already isolated by the restricted Bombieri/Weil criterion work:

  ∀ g, moments(g) →
    Re (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)) ≤ 0.

The repository has already proved that convergence/reality are automatic for
the autocorrelation carrier, so this residual is exactly equivalent to
WeilCompactSmoothNegativityV1.

The V3.1 retained three-block theorem is then recorded as an actual solved
subclass of this sign target.

No assumption, axiom, parameter, sorry, or RH promotion is introduced.
-/

open Set MeasureTheory Complex

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHFinalClosureV1

/-- The one remaining arithmetic sign proposition after autocorrelation
closure, convergence, and reality have been discharged. -/
def FinalSignResidualV1 : Prop :=
  ∀ g : WeilCompactSmoothGV1,
    WeilMomentConditionsV1 g →
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 g)).re ≤ 0

/-- The final sign residual is exactly the repository's restricted
Bombieri/Weil negativity predicate. -/
theorem final_sign_residual_iff_weil_negativity_v1 :
    FinalSignResidualV1 ↔ WeilCompactSmoothNegativityV1 := by
  simpa [FinalSignResidualV1] using
    (Iff.symm weil_compact_smooth_negativity_iff_unconditional_real_inequality_v1)

/-- V3.1 already proves the final sign inequality on the retained
correlation-window width-1/16 three-block family generated by width-1/32 packets. -/
theorem retained_three_block_sign_v1
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : AEGIS.WeilThreeBlockTranslatedPacketsV22.WidthOneThirtyTwoAt g a)
    (hm : WeilMomentConditionsV1 g)
    (z0 z1 z2 : ℂ) :
    (WeilExplicitRightSideV1
      (WeilAutocorrelationV1
        (AEGIS.WeilMixedAlgebraV2.combo z0 z1 z2
          (AEGIS.WeilThreeBlockTranslatedPacketsV22.gMinus g)
          (AEGIS.WeilThreeBlockTranslatedPacketsV22.gZero g)
          (AEGIS.WeilThreeBlockTranslatedPacketsV22.gPlus g)))).re ≤ 0 := by
  have h :=
    AEGIS.WeilSeparatedArchBridgeV31.three_block_bound_of_moments
      g a hw hm z0 z1 z2
  have hE :
      0 ≤ AEGIS.WeilDisjointEnergyV2.energy
        (AEGIS.WeilMixedAlgebraV2.combo z0 z1 z2
          (AEGIS.WeilThreeBlockTranslatedPacketsV22.gMinus g)
          (AEGIS.WeilThreeBlockTranslatedPacketsV22.gZero g)
          (AEGIS.WeilThreeBlockTranslatedPacketsV22.gPlus g)).1 :=
    AEGIS.WeilDisjointEnergyV2.energy_nonnegative _
  nlinarith

end AEGIS.RHFinalClosureV1

#print axioms AEGIS.RHFinalClosureV1.final_sign_residual_iff_weil_negativity_v1
#print axioms AEGIS.RHFinalClosureV1.retained_three_block_sign_v1
~~~~~~

## WeilSeparatedArchBridgeV31

Path: `source/WeilSeparatedArchBridgeV31.lean`

Original source lines: 1–431

Full file SHA256: `e334fc87b9d6066f5af9ad2dc98e69128527c4bcee4097c33d433ae5e366be31`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilSeparatedArchBridgeV31.lean

~~~~~~lean
import WeilThreeBlockCrossAssemblyV30
import Mathlib.MeasureTheory.Integral.Prod

/-!
Separated Archimedean bridge for the actual mixed correlation.
Moment transport below derives the weighted correlation integral from the
repository moments, including compact support and the Fubini justification.
No global Weil sign or RH conclusion is asserted.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilSeparatedArchBridgeV31

/-- Total width of the support-difference / correlation interval generated by
two retained packet supports. Each packet has total log-width 1/32, so the
difference interval has total width 1/16. -/
def CorrelationSupportDifferenceWidthV31 : ℝ := (1 : ℝ) / 16

theorem twice_packet_width_eq_correlation_width_v31 :
    2 * ((1 : ℝ) / 32) = CorrelationSupportDifferenceWidthV31 := by
  norm_num [CorrelationSupportDifferenceWidthV31]

open AEGIS.WeilMixedClosureV2
open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilThreeBlockCrossPrimeV28

theorem logLift_continuous (p : WeilCompactSmoothGV1) :
    Continuous (logLift p.1) := by
  unfold logLift
  exact (by fun_prop : Continuous (fun t : ℝ => (Real.exp (t / 2) : ℂ))).mul
    (p.2.1.continuous.comp Real.continuous_exp)

theorem logCross_continuous (p q : WeilCompactSmoothGV1) :
    Continuous (logCrossV28 p q) := by
  change Continuous (fun u : ℝ => logCrossV28 p q u)
  simp_rw [logCross_eq_mixed_v28]
  exact (by fun_prop : Continuous (fun u : ℝ => (Real.exp (u / 2) : ℂ))).mul
    ((smooth p q).continuous.comp Real.continuous_exp)

theorem logCross_zero_outside
    (p q : WeilCompactSmoothGV1) (plo phi qlo qhi u : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi)
    (hu : u < plo - qhi ∨ phi - qlo < u) : logCrossV28 p q u = 0 := by
  unfold logCrossV28
  apply integral_eq_zero_of_ae
  filter_upwards [] with v
  by_cases hp0 : logLift p.1 (v + u) = 0
  · simp [hp0]
  by_cases hq0 : logLift q.1 v = 0
  · simp [hq0]
  have hpI := hp (subset_tsupport _ hp0)
  have hqI := hq (subset_tsupport _ hq0)
  exfalso
  rcases hu with hu | hu <;> linarith [hpI.1, hpI.2, hqI.1, hqI.2]

def weightedCrossIntegrand
    (p q : WeilCompactSmoothGV1) (lam : ℝ) (z : ℝ × ℝ) : ℂ :=
  (Real.exp (lam * z.1) : ℂ) * logLift p.1 (z.2 + z.1) * conj (logLift q.1 z.2)

theorem weightedCrossIntegrand_integrable
    (p q : WeilCompactSmoothGV1) (lam plo phi qlo qhi : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi) :
    Integrable (weightedCrossIntegrand p q lam) (volume.prod volume) := by
  have hc : Continuous (weightedCrossIntegrand p q lam) := by
    unfold weightedCrossIntegrand
    exact ((by fun_prop : Continuous (fun z : ℝ × ℝ =>
      (Real.exp (lam * z.1) : ℂ))).mul
      ((logLift_continuous p).comp (continuous_snd.add continuous_fst))).mul
      (continuous_conj.comp ((logLift_continuous q).comp continuous_snd))
  have hk : HasCompactSupport (weightedCrossIntegrand p q lam) := by
    apply HasCompactSupport.of_support_subset_isCompact
      ((isCompact_Icc : IsCompact (Icc (plo - qhi) (phi - qlo))).prod
        (isCompact_Icc : IsCompact (Icc qlo qhi)))
    intro z hz
    have hp0 : logLift p.1 (z.2 + z.1) ≠ 0 := by
      intro h
      exact hz (by simp [weightedCrossIntegrand, h])
    have hq0 : logLift q.1 z.2 ≠ 0 := by
      intro h
      exact hz (by simp [weightedCrossIntegrand, h])
    have hpI := hp (subset_tsupport _ hp0)
    have hqI := hq (subset_tsupport _ hq0)
    exact ⟨⟨by linarith [hpI.1, hqI.2], by linarith [hpI.2, hqI.1]⟩, hqI⟩
  exact hc.integrable_of_hasCompactSupport hk

theorem weighted_logCross_integrable
    (p q : WeilCompactSmoothGV1) (lam plo phi qlo qhi : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi) :
    Integrable (fun u : ℝ => (Real.exp (lam * u) : ℂ) * logCrossV28 p q u) := by
  have hi := (weightedCrossIntegrand_integrable p q lam plo phi qlo qhi hp hq).integral_prod_left
  simpa only [weightedCrossIntegrand, logCrossV28, mul_assoc, integral_const_mul] using hi

/-- Fubini and additive translation transport a zero weighted packet moment
to a zero weighted mixed-correlation moment. -/
theorem weighted_logCross_moment_zero
    (p q : WeilCompactSmoothGV1) (lam plo phi qlo qhi : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi)
    (hm : (∫ s : ℝ, (Real.exp (lam * s) : ℂ) * logLift p.1 s) = 0) :
    (∫ u : ℝ, (Real.exp (lam * u) : ℂ) * logCrossV28 p q u) = 0 := by
  have hi := weightedCrossIntegrand_integrable p q lam plo phi qlo qhi hp hq
  calc
    (∫ u : ℝ, (Real.exp (lam * u) : ℂ) * logCrossV28 p q u) =
        ∫ u : ℝ, ∫ v : ℝ, weightedCrossIntegrand p q lam (u, v) := by
      simp only [weightedCrossIntegrand, logCrossV28, mul_assoc, integral_const_mul]
    _ = ∫ v : ℝ, ∫ u : ℝ, weightedCrossIntegrand p q lam (u, v) :=
      integral_integral_swap hi
    _ = 0 := by
      apply integral_eq_zero_of_ae
      filter_upwards [] with v
      have he (u : ℝ) : Real.exp (lam * u) =
          Real.exp (-lam * v) * Real.exp (lam * (u + v)) := by
        rw [← Real.exp_add]
        congr 1
        ring
      have hinner : (∫ u : ℝ, weightedCrossIntegrand p q lam (u, v)) =
          (Real.exp (-lam * v) : ℂ) *
            (∫ u : ℝ, (Real.exp (lam * (u + v)) : ℂ) * logLift p.1 (u + v)) *
              conj (logLift q.1 v) := by
        erw [← integral_const_mul, ← integral_mul_const]
        apply integral_congr_ae
        filter_upwards [] with u
        unfold weightedCrossIntegrand
        rw [he u, Complex.ofReal_mul, add_comm v u]
        ring
      have hshift := integral_add_right_eq_self (μ := volume)
        (fun s : ℝ => (Real.exp (lam * s) : ℂ) * logLift p.1 s) v
      erw [hinner, hshift, hm, mul_zero, zero_mul]
      rfl

theorem logCross_plus_moment_zero
    (p q : WeilCompactSmoothGV1) (plo phi qlo qhi : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi)
    (hm : WeilMomentConditionsV1 p) :
    (∫ u : ℝ, (Real.exp (u / 2) : ℂ) * logCrossV28 p q u) = 0 := by
  have hz : (∫ s : ℝ, (Real.exp ((1 / 2 : ℝ) * s) : ℂ) * logLift p.1 s) = 0 := by
    simpa only [one_div_mul_eq_div, logMomentPlus] using
      (logMomentPlus_eq_repository p).trans hm.2
  simpa only [one_div_mul_eq_div] using
    weighted_logCross_moment_zero p q (1 / 2) plo phi qlo qhi hp hq hz

theorem logCross_minus_moment_zero
    (p q : WeilCompactSmoothGV1) (plo phi qlo qhi : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi)
    (hm : WeilMomentConditionsV1 p) :
    (∫ u : ℝ, (Real.exp (-u / 2) : ℂ) * logCrossV28 p q u) = 0 := by
  have hn (s : ℝ) : (-1 / 2 : ℝ) * s = -s / 2 := by ring
  have hz : (∫ s : ℝ, (Real.exp ((-1 / 2 : ℝ) * s) : ℂ) * logLift p.1 s) = 0 := by
    simpa only [hn, logMomentMinus] using (logMomentMinus_eq_repository p).trans hm.1
  simpa only [hn] using weighted_logCross_moment_zero p q (-1 / 2) plo phi qlo qhi hp hq hz

private theorem kernel_algebra (x y z w m : ℂ)
    (hx : x ≠ 0) (hd : 1 - w ≠ 0)
    (hy : y = x⁻¹) (hz : z * z = y) (hw : x * w = y) :
    x * ((1 / x * m) / (x - y)) = z / (1 - w) * (z * m) := by
  have hden : x - y = x * (1 - w) := by rw [mul_sub, mul_one, hw]
  calc
    x * ((1 / x * m) / (x - y)) = x⁻¹ * m / (1 - w) := by
      rw [hden]
      field_simp [hx, hd]
      <;> ring
    _ = y * m / (1 - w) := by rw [hy]
    _ = z / (1 - w) * (z * m) := by rw [← hz]; ring

/-- Exact conversion of the repository Archimedean integral for strictly
ordered logarithmic supports. Both centre and positive-displacement terms
vanish by support; the surviving term has the stated negative log shift. -/
theorem separated_arch_eq_log_kernel
    (p q : WeilCompactSmoothGV1) (plo phi qlo qhi : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi)
    (hsep : phi < qlo) :
    WeilArchimedeanIntegralV1 (mixed p q) =
      ∫ u in Ioi (0 : ℝ),
        ((Real.exp (-u / 2) / (1 - Real.exp (-2 * u)) : ℝ) : ℂ) *
          logCrossV28 p q (-u) := by
  have hzero (u : ℝ) (hu : 0 ≤ u) : mixed p q (Real.exp u) = 0 := by
    have hc := logCross_zero_outside p q plo phi qlo qhi u hp hq
      (Or.inr (by linarith))
    rw [logCross_eq_mixed_v28] at hc
    exact (mul_eq_zero.mp hc).resolve_left (by simp)
  have hcenter : mixed p q 1 = 0 := by simpa using hzero 0 le_rfl
  unfold WeilArchimedeanIntegralV1
  rw [← show (∫ u in Ioi (0 : ℝ), Real.exp u •
      WeilArchimedeanIntegrandV1 (mixed p q) (Real.exp u)) =
        ∫ x in Ioi (1 : ℝ), WeilArchimedeanIntegrandV1 (mixed p q) x from
      by simpa using (integral_comp_exp_Ioi (WeilArchimedeanIntegrandV1 (mixed p q)) 0)]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro u hu
  change 0 < u at hu
  have heinv : (Real.exp u)⁻¹ = Real.exp (-u) := (Real.exp_neg u).symm
  simp only [WeilArchimedeanIntegrandV1, hzero u hu.le, hcenter,
    mul_zero, sub_zero, zero_add, Complex.real_smul, heinv,
    logCross_eq_mixed_v28, neg_div, Complex.ofReal_div, Complex.ofReal_sub,
    Complex.ofReal_one]
  apply kernel_algebra
  · simp
  · exact_mod_cast (ne_of_gt (sub_pos.mpr
      (Real.exp_lt_one_iff.mpr (by linarith))) : (1 - Real.exp (-2 * u) : ℝ) ≠ 0)
  · simp [Real.exp_neg]
  · rw [← Complex.ofReal_mul]
    congr 1
    rw [← Real.exp_add]
    congr 1
    ring
  · rw [← Complex.ofReal_mul]
    congr 1
    rw [← Real.exp_add]
    congr 1
    ring

/-- A single centred exponential subtraction works for both retained gaps. -/
theorem centered_arch_kernel_bound (u : ℝ)
    (hu : Real.log 2 - 1 / 32 ≤ u) :
    |Real.exp (-u / 2) / (1 - Real.exp (-2 * u)) -
      (6 / 5 : ℝ) * Real.exp (-u / 2)| ≤ (4 / 25 : ℝ) := by
  have hx : Real.exp (-2 * u) ≤ (4 / 15 : ℝ) := by
    have he2 : Real.exp (2 * Real.log 2) = (4 : ℝ) := by
      rw [two_mul, Real.exp_add, Real.exp_log (by norm_num : (0 : ℝ) < 2)]
      norm_num
    calc
      Real.exp (-2 * u) ≤ Real.exp (1 / 16 - 2 * Real.log 2) :=
        Real.exp_le_exp.mpr (by linarith)
      _ = Real.exp (1 / 16) / 4 := by rw [Real.exp_sub, he2]
      _ ≤ 4 / 15 := by
        linarith [AEGIS.WeilThreeBlockAnalyticConstantsV21.exp_one_over_16_upper]
  have hx0 := (Real.exp_pos (-2 * u)).le
  have hy0 := (Real.exp_pos (-u / 2)).le
  have hy4 : Real.exp (-u / 2) ^ 4 = Real.exp (-2 * u) := by
    rw [show Real.exp (-u / 2) ^ 4 =
      (Real.exp (-u / 2) * Real.exp (-u / 2)) *
      (Real.exp (-u / 2) * Real.exp (-u / 2)) by ring]
    rw [← Real.exp_add, ← Real.exp_add]
    congr 1
    ring
  have hy : Real.exp (-u / 2) ≤ (4 / 5 : ℝ) := by
    by_contra h
    have hlt : (4 / 5 : ℝ) ≤ Real.exp (-u / 2) := (lt_of_not_ge h).le
    have hh : (4 / 5 : ℝ) ^ 4 ≤ Real.exp (-u / 2) ^ 4 := by gcongr
    rw [hy4] at hh
    norm_num only [show (4 / 5 : ℝ) ^ 4 = 256 / 625 by norm_num] at hh
    linarith
  have hd : 0 < 1 - Real.exp (-2 * u) := by linarith
  have hrlo : (1 : ℝ) ≤ 1 / (1 - Real.exp (-2 * u)) := by
    apply (le_div_iff₀ hd).mpr
    linarith
  have hrhi : 1 / (1 - Real.exp (-2 * u)) ≤ (7 / 5 : ℝ) := by
    apply (div_le_iff₀ hd).mpr
    linarith
  have hr : |1 / (1 - Real.exp (-2 * u)) - (6 / 5 : ℝ)| ≤ (1 / 5 : ℝ) := by
    rw [abs_le]
    constructor <;> linarith
  calc
    |Real.exp (-u / 2) / (1 - Real.exp (-2 * u)) -
      (6 / 5 : ℝ) * Real.exp (-u / 2)| =
        Real.exp (-u / 2) * |1 / (1 - Real.exp (-2 * u)) - (6 / 5 : ℝ)| := by
      calc
        _ = |Real.exp (-u / 2) * (1 / (1 - Real.exp (-2 * u)) - (6 / 5 : ℝ))| := by
          congr 1
          ring
        _ = _ := by rw [abs_mul, abs_of_nonneg hy0]
    _ ≤ (4 / 5 : ℝ) * (1 / 5 : ℝ) := mul_le_mul hy hr (abs_nonneg _) (by norm_num)
    _ = 4 / 25 := by norm_num

/-- Integrate the centred kernel using the support-difference interval and
the actual weighted correlation moment.

Load-bearing width convention:
- each retained packet has total log-support width 1/32;
- the mixed support-difference interval has total width 1/16. -/
theorem separated_arch_norm_bound
    (p q : WeilCompactSmoothGV1) (plo phi qlo qhi E : ℝ)
    (hp : LogSupportIn p plo phi) (hq : LogSupportIn q qlo qhi)
    (hgap : Real.log 2 - 1 / 32 ≤ qlo - phi)
    (hwidth : (qhi - plo) - (qlo - phi) = CorrelationSupportDifferenceWidthV31)
    (hm : WeilMomentConditionsV1 p) (hE : 0 ≤ E)
    (hR : ∀ u : ℝ, ‖logCrossV28 p q u‖ ≤ E) :
    ‖WeilArchimedeanIntegralV1 (mixed p q)‖ ≤ (1 / 100 : ℝ) * E := by
  let lo := qlo - phi
  let hi := qhi - plo
  let K : ℝ → ℝ := fun u => Real.exp (-u / 2) / (1 - Real.exp (-2 * u))
  let F : ℝ → ℂ := fun u => (K u : ℂ) * logCrossV28 p q (-u)
  let M : ℝ → ℂ := fun u => (Real.exp (-u / 2) : ℂ) * logCrossV28 p q (-u)
  have hlo : 0 < lo := by
    dsimp [lo]
    linarith [log_two_gt_one_thirty_two]
  have hzero (u : ℝ) (hu : u ∉ Icc lo hi) : logCrossV28 p q (-u) = 0 := by
    apply logCross_zero_outside p q plo phi qlo qhi (-u) hp hq
    by_cases hlow : u < lo
    · right
      dsimp [lo] at hlow
      linarith
    · have hhigh : hi < u := lt_of_not_ge (fun h => hu ⟨le_of_not_gt hlow, h⟩)
      left
      dsimp [hi] at hhigh
      linarith
  have hFfull : (∫ u in Icc lo hi, F u) = ∫ u, F u :=
    setIntegral_eq_integral_of_forall_compl_eq_zero (fun u hu => by simp [F, hzero u hu])
  have hFpos : (∫ u in Ioi (0 : ℝ), F u) = ∫ u, F u := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro u hu
    have hnot : u ∉ Icc lo hi := by
      intro h
      exact hu (lt_of_lt_of_le hlo h.1)
    simp [F, hzero u hnot]
  have harch : WeilArchimedeanIntegralV1 (mixed p q) = ∫ u in Icc lo hi, F u := by
    rw [separated_arch_eq_log_kernel p q plo phi qlo qhi hp hq (by dsimp [lo] at hlo; linarith)]
    exact hFpos.trans hFfull.symm
  have hMfull : (∫ u, M u) = 0 := by
    have ht := integral_neg_eq_self
      (fun u : ℝ => (Real.exp (u / 2) : ℂ) * logCrossV28 p q u) volume
    exact ht.trans (logCross_plus_moment_zero p q plo phi qlo qhi hp hq hm)
  have hMzero : (∫ u in Icc lo hi, M u) = 0 := by
    rw [setIntegral_eq_integral_of_forall_compl_eq_zero (f := M) (s := Icc lo hi)
      (fun u hu => by simp [M, hzero u hu])]
    exact hMfull
  have hMc : Continuous M := by
    dsimp [M]
    exact (by fun_prop : Continuous (fun u : ℝ => (Real.exp (-u / 2) : ℂ))).mul
      ((logCross_continuous p q).comp continuous_neg)
  have hKc : ContinuousOn K (Icc lo hi) := by
    apply ContinuousOn.div (by fun_prop) (by fun_prop)
    intro u hu
    have hup : 0 < u := lt_of_lt_of_le hlo hu.1
    exact ne_of_gt (sub_pos.mpr (Real.exp_lt_one_iff.mpr (by linarith)))
  have hFc : ContinuousOn F (Icc lo hi) :=
    (Complex.continuous_ofReal.comp_continuousOn hKc).mul
      (((logCross_continuous p q).comp continuous_neg).continuousOn)
  have hcancel : (∫ u in Icc lo hi, F u) =
      ∫ u in Icc lo hi, F u - (6 / 5 : ℂ) * M u := by
    rw [integral_sub hFc.integrableOn_Icc (hMc.integrableOn_Icc.const_mul _),
      integral_const_mul, hMzero, mul_zero, sub_zero]
  have hpoint (u : ℝ) (hu : u ∈ Icc lo hi) :
      ‖F u - (6 / 5 : ℂ) * M u‖ ≤ (4 / 25 : ℝ) * E := by
    have hku := centered_arch_kernel_bound u (hgap.trans hu.1)
    have heq : F u - (6 / 5 : ℂ) * M u =
        (((K u - (6 / 5 : ℝ) * Real.exp (-u / 2)) : ℝ) : ℂ) * logCrossV28 p q (-u) := by
      dsimp [F, M]
      push_cast
      ring
    rw [heq, norm_mul, Complex.norm_real, Real.norm_eq_abs]
    exact mul_le_mul hku (hR (-u)) (norm_nonneg _) (by norm_num)
  rw [harch, hcancel]
  calc
    ‖∫ u in Icc lo hi, F u - (6 / 5 : ℂ) * M u‖ ≤
        (4 / 25 : ℝ) * E * (volume.restrict (Icc lo hi)).real univ := by
      apply norm_integral_le_of_norm_le_const
      filter_upwards [self_mem_ae_restrict measurableSet_Icc] with u hu
      exact hpoint u hu
    _ = (1 / 100 : ℝ) * E := by
      have hw : hi - lo = (1 / 16 : ℝ) := by
        simpa [CorrelationSupportDifferenceWidthV31] using hwidth
      simp [Measure.real, Real.volume_Icc, hw]
      <;> ring

theorem translated_arch_norm_bound
    (g : WeilCompactSmoothGV1) (a d1 d2 : ℝ)
    (hw : WidthOneThirtyTwoAt g a) (hm : WeilMomentConditionsV1 g)
    (hd : Real.log 2 ≤ d2 - d1) :
    ‖WeilArchimedeanIntegralV1 (mixed (translatePacket g d1) (translatePacket g d2))‖ ≤
      (1 / 100 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy g.1 := by
  apply separated_arch_norm_bound (translatePacket g d1) (translatePacket g d2)
    (a - 1 / 64 + d1) (a + 1 / 64 + d1)
    (a - 1 / 64 + d2) (a + 1 / 64 + d2)
    (AEGIS.WeilDisjointEnergyV2.energy g.1)
  · exact translate_logSupportIn g d1 _ _ hw
  · exact translate_logSupportIn g d2 _ _ hw
  · linarith
  · norm_num [CorrelationSupportDifferenceWidthV31]
    ring
  · exact translate_preserves_moments g d1 hm
  · exact AEGIS.WeilDisjointEnergyV2.energy_nonnegative g.1
  · intro u
    rw [logCross_translate_eq_logCorrelation_v28]
    exact AEGIS.WeilWidthArchCorrelationV25.norm_logCorrelation_le_energy_v25 g _

theorem three_arch_bounds_of_moments
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) (hm : WeilMomentConditionsV1 g) :
    ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gZero g))‖ ≤
        (1 / 100 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy g.1 ∧
    ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gPlus g))‖ ≤
        (1 / 100 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy g.1 ∧
    ‖WeilArchimedeanIntegralV1 (mixed (gZero g) (gPlus g))‖ ≤
        (1 / 100 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy g.1 := by
  refine ⟨translated_arch_norm_bound g a (-Real.log 2) 0 hw hm (by linarith), ?_, ?_⟩
  · exact translated_arch_norm_bound g a (-Real.log 2) (Real.log 2) hw hm
      (by linarith [Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 2)])
  · exact translated_arch_norm_bound g a 0 (Real.log 2) hw hm (by linarith)

theorem three_cross_bounds_of_moments
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) (hm : WeilMomentConditionsV1 g) :
    ‖AEGIS.WeilMixedAlgebraV2.B (gMinus g) (gZero g)‖ ≤
        (51 / 100 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy g.1 ∧
    ‖AEGIS.WeilMixedAlgebraV2.B (gMinus g) (gPlus g)‖ ≤
        (9 / 25 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy g.1 ∧
    ‖AEGIS.WeilMixedAlgebraV2.B (gZero g) (gPlus g)‖ ≤
        (51 / 100 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy g.1 := by
  obtain ⟨h01, h02, h12⟩ := three_arch_bounds_of_moments g a hw hm
  exact AEGIS.WeilThreeBlockCrossAssemblyV30.three_cross_bounds_of_arch g a hw h01 h02 h12

theorem three_block_bound_of_moments
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) (hm : WeilMomentConditionsV1 g)
    (z0 z1 z2 : ℂ) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1
      (AEGIS.WeilMixedAlgebraV2.combo z0 z1 z2 (gMinus g) (gZero g) (gPlus g)))).re ≤
      -(1 / 10 : ℝ) * AEGIS.WeilDisjointEnergyV2.energy
        (AEGIS.WeilMixedAlgebraV2.combo z0 z1 z2 (gMinus g) (gZero g) (gPlus g)).1 := by
  obtain ⟨h01, h02, h12⟩ := three_arch_bounds_of_moments g a hw hm
  exact AEGIS.WeilThreeBlockCrossAssemblyV30.three_block_bound_of_arch
    g a hw z0 z1 z2 h01 h02 h12

end AEGIS.WeilSeparatedArchBridgeV31

#print axioms AEGIS.WeilSeparatedArchBridgeV31.twice_packet_width_eq_correlation_width_v31
#print axioms AEGIS.WeilSeparatedArchBridgeV31.weightedCrossIntegrand_integrable
#print axioms AEGIS.WeilSeparatedArchBridgeV31.weighted_logCross_integrable
#print axioms AEGIS.WeilSeparatedArchBridgeV31.weighted_logCross_moment_zero
#print axioms AEGIS.WeilSeparatedArchBridgeV31.logCross_plus_moment_zero
#print axioms AEGIS.WeilSeparatedArchBridgeV31.logCross_minus_moment_zero
#print axioms AEGIS.WeilSeparatedArchBridgeV31.separated_arch_eq_log_kernel
#print axioms AEGIS.WeilSeparatedArchBridgeV31.centered_arch_kernel_bound
#print axioms AEGIS.WeilSeparatedArchBridgeV31.separated_arch_norm_bound
#print axioms AEGIS.WeilSeparatedArchBridgeV31.translated_arch_norm_bound
#print axioms AEGIS.WeilSeparatedArchBridgeV31.three_arch_bounds_of_moments
#print axioms AEGIS.WeilSeparatedArchBridgeV31.three_cross_bounds_of_moments
#print axioms AEGIS.WeilSeparatedArchBridgeV31.three_block_bound_of_moments
~~~~~~

## WeilThreeBlockCrossAssemblyV30

Path: `source/WeilThreeBlockCrossAssemblyV30.lean`

Original source lines: 1–245

Full file SHA256: `72c665829f668375d4cbd959253523df6f14ba0277cf37c831fdc74d7795360c`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockCrossAssemblyV30.lean

~~~~~~lean
import WeilThreeBlockPrimeEvaluationV30
import WeilThreeBlockNormBridgeV21

/-!
Conditional assembly over the actual repository integrals.
The original three-bound interface is retained. Translation invariance reduces
the strengthened interface to two Archimedean bounds. Moment cancellation of
the separated rank-one kernel is proved below; its connection to the complete
Archimedean integral and the two quantitative bounds remain obligations.
-/
open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilThreeBlockCrossAssemblyV30
open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilMixedClosureV2
open AEGIS.WeilMixedAlgebraV2
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilThreeBlockCrossPrimeWindowV29
open AEGIS.WeilThreeBlockPrimeEvaluationV30
open AEGIS.WeilThreeBlockAnalyticConstantsV21
open AEGIS.WeilThreeBlockNormBridgeV21
open AEGIS.WeilWidthArchIntegralV27

theorem adjacent_rational_arch_margin :
    (75 / 9086 : ℝ) < 1 / 100 := by norm_num

theorem outer_rational_arch_margin :
    (15 / 13216 : ℝ) < 1 / 100 := by norm_num

private theorem mixed_bound_of_prime_and_arch
    (p q : WeilCompactSmoothGV1) (E c k : ℝ)
    (hE : 0 ≤ E) (hc : 0 ≤ c) (hck : c ≤ k)
    (hzero : mixed p q 1 = 0)
    (hprime : WeilPrimeSumV1 (mixed p q) = ((c * E : ℝ) : ℂ))
    (harch : ‖WeilArchimedeanIntegralV1 (mixed p q)‖ ≤ (1 / 100 : ℝ) * E) :
    ‖B p q‖ ≤ (k + 1 / 100) * E := by
  have hp : ‖WeilPrimeSumV1 (mixed p q)‖ = c * E := by
    rw [hprime, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (mul_nonneg hc hE)]
  unfold B WeilExplicitRightSideV1
  rw [hzero, mul_zero, add_zero]
  calc
    ‖WeilPrimeSumV1 (mixed p q) + WeilArchimedeanIntegralV1 (mixed p q)‖
        ≤ ‖WeilPrimeSumV1 (mixed p q)‖ + ‖WeilArchimedeanIntegralV1 (mixed p q)‖ := norm_add_le _ _
    _ ≤ c * E + (1 / 100 : ℝ) * E := by rw [hp]; exact add_le_add (le_refl _) harch
    _ ≤ (k + 1 / 100) * E := by nlinarith [mul_le_mul_of_nonneg_right hck hE]

theorem three_cross_bounds_of_arch
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a)
    (harch01 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gZero g))‖ ≤
      (1 / 100 : ℝ) * energy g.1)
    (harch02 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gPlus g))‖ ≤
      (1 / 100 : ℝ) * energy g.1)
    (harch12 : ‖WeilArchimedeanIntegralV1 (mixed (gZero g) (gPlus g))‖ ≤
      (1 / 100 : ℝ) * energy g.1) :
    ‖B (gMinus g) (gZero g)‖ ≤ (51 / 100 : ℝ) * energy g.1 ∧
    ‖B (gMinus g) (gPlus g)‖ ≤ (9 / 25 : ℝ) * energy g.1 ∧
    ‖B (gZero g) (gPlus g)‖ ≤ (51 / 100 : ℝ) * energy g.1 := by
  have hE := energy_nonnegative g.1
  have hlog : 0 ≤ Real.log 2 := Real.log_nonneg (by norm_num)
  have h01zero : mixed (gMinus g) (gZero g) 1 = 0 := by
    simpa using adjacent_mixed_nat_zero_v29 g a hw 1 (by norm_num)
  have h02zero : mixed (gMinus g) (gPlus g) 1 = 0 := by
    simpa using outer_mixed_nat_zero_v29 g a hw 1 (by norm_num)
  have h12zero : mixed (gZero g) (gPlus g) 1 = 0 := by
    rw [adjacent_mixed_shift_eq g 1 (by norm_num)]
    exact h01zero
  constructor
  · convert mixed_bound_of_prime_and_arch (gMinus g) (gZero g) (energy g.1)
      (Real.log 2 / Real.sqrt 2) (1 / 2) hE
      (div_nonneg hlog (Real.sqrt_nonneg _)) prime_adjacent_scalar_upper.le
      h01zero (adjacent_prime_sum_exact g a hw) harch01 using 1 <;> norm_num
  constructor
  · convert mixed_bound_of_prime_and_arch (gMinus g) (gPlus g) (energy g.1)
      (Real.log 2 / 2) (7 / 20) hE (div_nonneg hlog (by norm_num))
      prime_outer_scalar_upper.le h02zero (outer_prime_sum_exact g a hw) harch02
      using 1 <;> norm_num
  · convert mixed_bound_of_prime_and_arch (gZero g) (gPlus g) (energy g.1)
      (Real.log 2 / Real.sqrt 2) (1 / 2) hE
      (div_nonneg hlog (Real.sqrt_nonneg _)) prime_adjacent_scalar_upper.le
      h12zero (right_adjacent_prime_sum_exact g a hw) harch12 using 1 <;> norm_num

theorem three_block_bound_of_arch
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a)
    (z0 z1 z2 : ℂ)
    (harch01 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gZero g))‖ ≤
      (1 / 100 : ℝ) * energy g.1)
    (harch02 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gPlus g))‖ ≤
      (1 / 100 : ℝ) * energy g.1)
    (harch12 : ‖WeilArchimedeanIntegralV1 (mixed (gZero g) (gPlus g))‖ ≤
      (1 / 100 : ℝ) * energy g.1) :
    (WeilExplicitRightSideV1
      (WeilAutocorrelationV1 (combo z0 z1 z2 (gMinus g) (gZero g) (gPlus g)))).re ≤
      -(1 / 10 : ℝ) * energy (combo z0 z1 z2 (gMinus g) (gZero g) (gPlus g)).1 := by
  obtain ⟨hd01, hd02, hd12⟩ := three_blocks_pairwise_disjoint g a hw
  obtain ⟨he0, he1, he2⟩ := three_blocks_energy g
  obtain ⟨hb01, hb02, hb12⟩ := three_cross_bounds_of_arch g a hw harch01 harch02 harch12
  have hw0 := translate_logSupportIn g (-Real.log 2) _ _ hw
  have hw1 := translate_logSupportIn g 0 _ _ hw
  have hw2 := translate_logSupportIn g (Real.log 2) _ _ hw
  have h0 : WidthOneThirtyTwoAt (gMinus g) (a - Real.log 2) := by
    change LogSupportIn (translatePacket g (-Real.log 2))
      (a - Real.log 2 - 1 / 64) (a - Real.log 2 + 1 / 64)
    convert hw0 using 1 <;> ring
  have h1 : WidthOneThirtyTwoAt (gZero g) a := by
    simpa [WidthOneThirtyTwoAt, gZero] using hw1
  have h2 : WidthOneThirtyTwoAt (gPlus g) (a + Real.log 2) := by
    change LogSupportIn (translatePacket g (Real.log 2))
      (a + Real.log 2 - 1 / 64) (a + Real.log 2 + 1 / 64)
    convert hw2 using 1 <;> ring
  have hl01 : l2 (gMinus g).1 * l2 (gZero g).1 = energy g.1 := by
    rw [l2, l2, he0, he1, ← pow_two, Real.sq_sqrt (energy_nonnegative g.1)]
  have hl02 : l2 (gMinus g).1 * l2 (gPlus g).1 = energy g.1 := by
    rw [l2, l2, he0, he2, ← pow_two, Real.sq_sqrt (energy_nonnegative g.1)]
  have hl12 : l2 (gZero g).1 * l2 (gPlus g).1 = energy g.1 := by
    rw [l2, l2, he1, he2, ← pow_two, Real.sq_sqrt (energy_nonnegative g.1)]
  apply actual_three_block_l2_bound z0 z1 z2 (gMinus g) (gZero g) (gPlus g)
      hd01 hd02 hd12
  · simpa [square_l2] using width_diagonal_103_over_100_v27 (gMinus g) _ h0
  · simpa [square_l2] using width_diagonal_103_over_100_v27 (gZero g) _ h1
  · simpa [square_l2] using width_diagonal_103_over_100_v27 (gPlus g) _ h2
  · simpa only [mul_assoc, hl01] using hb01
  · simpa only [mul_assoc, hl02] using hb02
  · simpa only [mul_assoc, hl12] using hb12

/-- Both adjacent Archimedean integrals are exactly equal, without a width or
moment hypothesis. -/
theorem adjacent_arch_integral_eq (g : WeilCompactSmoothGV1) :
    WeilArchimedeanIntegralV1 (mixed (gZero g) (gPlus g)) =
      WeilArchimedeanIntegralV1 (mixed (gMinus g) (gZero g)) := by
  unfold WeilArchimedeanIntegralV1
  apply setIntegral_congr_fun measurableSet_Ioi
  intro x hx
  have hpos : 0 < x := lt_trans (by norm_num) hx
  simp only [WeilArchimedeanIntegrandV1,
    adjacent_mixed_shift_eq g x hpos,
    adjacent_mixed_shift_eq g (x⁻¹) (inv_pos.mpr hpos),
    adjacent_mixed_shift_eq g 1 (by norm_num)]

/-- Only the adjacent and outer estimates are independent obligations. -/
theorem three_cross_bounds_of_two_arch
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a)
    (harch01 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gZero g))‖ ≤
      (1 / 100 : ℝ) * energy g.1)
    (harch02 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gPlus g))‖ ≤
      (1 / 100 : ℝ) * energy g.1) :
    ‖B (gMinus g) (gZero g)‖ ≤ (51 / 100 : ℝ) * energy g.1 ∧
    ‖B (gMinus g) (gPlus g)‖ ≤ (9 / 25 : ℝ) * energy g.1 ∧
    ‖B (gZero g) (gPlus g)‖ ≤ (51 / 100 : ℝ) * energy g.1 := by
  exact three_cross_bounds_of_arch g a hw harch01 harch02
    (by simpa only [adjacent_arch_integral_eq] using harch01)

theorem three_block_bound_of_two_arch
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a)
    (z0 z1 z2 : ℂ)
    (harch01 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gZero g))‖ ≤
      (1 / 100 : ℝ) * energy g.1)
    (harch02 : ‖WeilArchimedeanIntegralV1 (mixed (gMinus g) (gPlus g))‖ ≤
      (1 / 100 : ℝ) * energy g.1) :
    (WeilExplicitRightSideV1
      (WeilAutocorrelationV1 (combo z0 z1 z2 (gMinus g) (gZero g) (gPlus g)))).re ≤
      -(1 / 10 : ℝ) * energy (combo z0 z1 z2 (gMinus g) (gZero g) (gPlus g)).1 := by
  exact three_block_bound_of_arch g a hw z0 z1 z2 harch01 harch02
    (by simpa only [adjacent_arch_integral_eq] using harch01)

/-- Subtract the moment-cancelled term directly; no infinite series is needed. -/
theorem arch_kernel_sub_rank_one (v : ℝ) (hv : 0 < v) :
    Real.exp (-v / 2) / (1 - Real.exp (-2 * v)) - Real.exp (-v / 2) =
      Real.exp (-5 * v / 2) / (1 - Real.exp (-2 * v)) := by
  have he : Real.exp (-2 * v) < 1 := by
    rw [Real.exp_lt_one_iff]
    linarith
  have hd : 1 - Real.exp (-2 * v) ≠ 0 := ne_of_gt (sub_pos.mpr he)
  have hm : Real.exp (-v / 2) * Real.exp (-2 * v) = Real.exp (-5 * v / 2) := by
    rw [← Real.exp_add]
    congr 1
    ring
  apply (eq_div_iff hd).mpr
  rw [sub_mul, div_mul_cancel₀ _ hd]
  nlinarith [hm]

/-- The separated leading exponential term vanishes by the repository's
minus moment. This is an iterated-integral identity, not yet the change of
variables/Fubini identification with the actual Archimedean integral. -/
theorem arch_rank_one_moment_zero
    (p q : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 p) :
    (∫ s : ℝ, ∫ t : ℝ,
      ((Real.exp (-s / 2) : ℂ) *
        AEGIS.WeilLogCoordinateIsometryV21.logLift p.1 s) *
      ((Real.exp (t / 2) : ℂ) *
        conj (AEGIS.WeilLogCoordinateIsometryV21.logLift q.1 t))) = 0 := by
  simp_rw [integral_const_mul]
  rw [integral_mul_const]
  change logMomentMinus p * _ = 0
  rw [logMomentMinus_eq_repository, hm.1, zero_mul]

/-- The rank-one cancellation in the actual difference-kernel normalization. -/
theorem arch_exp_difference_moment_zero
    (p q : WeilCompactSmoothGV1) (hm : WeilMomentConditionsV1 p) :
    (∫ s : ℝ, ∫ t : ℝ,
      (Real.exp (-(s - t) / 2) : ℂ) *
        AEGIS.WeilLogCoordinateIsometryV21.logLift p.1 s *
        conj (AEGIS.WeilLogCoordinateIsometryV21.logLift q.1 t)) = 0 := by
  rw [← arch_rank_one_moment_zero p q hm]
  apply integral_congr_ae
  filter_upwards [] with s
  apply integral_congr_ae
  filter_upwards [] with t
  have he : Real.exp (-(s - t) / 2) = Real.exp (-s / 2) * Real.exp (t / 2) := by
    rw [← Real.exp_add]
    congr 1
    ring
  rw [he, Complex.ofReal_mul]
  ring

/-- On a separated support, the remainder kernel is bounded by its value at
the minimal positive separation. -/
theorem arch_remainder_le_at_gap (δ v : ℝ) (hδ : 0 < δ) (hv : δ ≤ v) :
    Real.exp (-5 * v / 2) / (1 - Real.exp (-2 * v)) ≤
      Real.exp (-5 * δ / 2) / (1 - Real.exp (-2 * δ)) := by
  have hn : Real.exp (-5 * v / 2) ≤ Real.exp (-5 * δ / 2) :=
    Real.exp_le_exp.mpr (by linarith)
  have he : Real.exp (-2 * v) ≤ Real.exp (-2 * δ) :=
    Real.exp_le_exp.mpr (by linarith)
  have hp : 0 < 1 - Real.exp (-2 * δ) := by
    apply sub_pos.mpr
    rw [Real.exp_lt_one_iff]
    linarith
  have hpv : 0 < 1 - Real.exp (-2 * v) := lt_of_lt_of_le hp (by linarith)
  apply (div_le_div_iff₀ hpv hp).mpr
  exact (mul_le_mul_of_nonneg_right hn hp.le).trans
    (mul_le_mul_of_nonneg_left (by linarith) (Real.exp_pos (-5 * δ / 2)).le)

end AEGIS.WeilThreeBlockCrossAssemblyV30

#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.three_cross_bounds_of_arch
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.three_block_bound_of_arch
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.adjacent_arch_integral_eq
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.three_cross_bounds_of_two_arch
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.three_block_bound_of_two_arch
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.arch_kernel_sub_rank_one
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.arch_rank_one_moment_zero
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.arch_exp_difference_moment_zero
#print axioms AEGIS.WeilThreeBlockCrossAssemblyV30.arch_remainder_le_at_gap
~~~~~~

## WeilThreeBlockPrimeEvaluationV30

Path: `source/WeilThreeBlockPrimeEvaluationV30.lean`

Original source lines: 1–177

Full file SHA256: `f081664968e867a19c6cbd5b927c2a69524afd6104af2b513eb5c5eb4b70c5fd`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockPrimeEvaluationV30.lean

~~~~~~lean
import WeilThreeBlockCrossPrimeWindowV29

/-!
Candidate source, not yet kernel replayed.
Evaluates the actual prime sums after V2.9 window isolation.
No Archimedean bound or RH theorem is assumed or asserted here.
-/
open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilThreeBlockPrimeEvaluationV30
open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilMixedClosureV2
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilThreeBlockCrossPrimeV28
open AEGIS.WeilThreeBlockCrossPrimeWindowV29

theorem adjacent_prime_sum_single
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a) :
    WeilPrimeSumV1 (mixed (gMinus g) (gZero g)) =
      WeilPrimeTermV1 (mixed (gMinus g) (gZero g)) 1 := by
  unfold WeilPrimeSumV1
  apply tsum_eq_single 1
  intro n hn
  have hp := adjacent_mixed_nat_zero_v29 g a hw (n + 1) (by omega)
  have hi := adjacent_mixed_inv_nat_zero_v29 g a hw (n + 1)
    (by omega) (by omega)
  simp only [WeilPrimeTermV1, hp, hi, mul_zero, add_zero]

theorem outer_prime_sum_single
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a) :
    WeilPrimeSumV1 (mixed (gMinus g) (gPlus g)) =
      WeilPrimeTermV1 (mixed (gMinus g) (gPlus g)) 3 := by
  unfold WeilPrimeSumV1
  apply tsum_eq_single 3
  intro n hn
  have hp := outer_mixed_nat_zero_v29 g a hw (n + 1) (by omega)
  have hi := outer_mixed_inv_nat_zero_v29 g a hw (n + 1)
    (by omega) (by omega)
  simp only [WeilPrimeTermV1, hp, hi, mul_zero, add_zero]

theorem exp_log_two_half : Real.exp (Real.log 2 / 2) = Real.sqrt 2 := by
  have he : Real.exp (Real.log 2 / 2) ^ 2 = (2 : ℝ) := by
    rw [pow_two, ← Real.exp_add]
    rw [show Real.log 2 / 2 + Real.log 2 / 2 = Real.log 2 by ring]
    exact Real.exp_log (by norm_num)
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have hp := Real.exp_pos (Real.log 2 / 2)
  have hsp := Real.sqrt_nonneg (2 : ℝ)
  nlinarith

theorem adjacent_mixed_reciprocal_center (g : WeilCompactSmoothGV1) :
    mixed (gMinus g) (gZero g) ((2 : ℝ)⁻¹) =
      (Real.sqrt 2 : ℂ) * (energy g.1 : ℂ) := by
  have h := mixed_translate_center_v28 g (-Real.log 2) 0
  have he : Real.exp ((-Real.log 2 - 0) / 2) = (Real.sqrt 2)⁻¹ := by
    rw [show (-Real.log 2 - 0) / 2 = -(Real.log 2 / 2) by ring,
      Real.exp_neg, exp_log_two_half]
  have hx : Real.exp (-Real.log 2 - 0) = (2 : ℝ)⁻¹ := by
    rw [sub_zero, Real.exp_neg, Real.exp_log (by norm_num)]
  change (Real.exp ((-Real.log 2 - 0) / 2) : ℂ) *
    mixed (gMinus g) (gZero g) (Real.exp (-Real.log 2 - 0)) = _ at h
  rw [he, hx, Complex.ofReal_inv] at h
  have hs : (Real.sqrt 2 : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (Real.sqrt_pos.mpr (by norm_num : (0 : ℝ) < 2)))
  calc
    mixed (gMinus g) (gZero g) ((2 : ℝ)⁻¹) =
        (Real.sqrt 2 : ℂ) * ((Real.sqrt 2 : ℂ)⁻¹ *
          mixed (gMinus g) (gZero g) ((2 : ℝ)⁻¹)) := by field_simp
    _ = (Real.sqrt 2 : ℂ) * (energy g.1 : ℂ) := by rw [h]

theorem outer_mixed_reciprocal_center (g : WeilCompactSmoothGV1) :
    mixed (gMinus g) (gPlus g) ((4 : ℝ)⁻¹) =
      2 * (energy g.1 : ℂ) := by
  have h := mixed_translate_center_v28 g (-Real.log 2) (Real.log 2)
  have he : Real.exp ((-Real.log 2 - Real.log 2) / 2) = (2 : ℝ)⁻¹ := by
    rw [show (-Real.log 2 - Real.log 2) / 2 = -Real.log 2 by ring,
      Real.exp_neg, Real.exp_log (by norm_num)]
  have hx : Real.exp (-Real.log 2 - Real.log 2) = (4 : ℝ)⁻¹ := by
    rw [sub_eq_add_neg, Real.exp_add, Real.exp_neg,
      Real.exp_log (by norm_num)]
    norm_num
  change (Real.exp ((-Real.log 2 - Real.log 2) / 2) : ℂ) *
    mixed (gMinus g) (gPlus g) (Real.exp (-Real.log 2 - Real.log 2)) = _ at h
  rw [he, hx] at h
  simp only [Complex.ofReal_inv, Complex.ofReal_ofNat] at h
  calc
    mixed (gMinus g) (gPlus g) ((4 : ℝ)⁻¹) =
        (2 : ℂ) * ((2 : ℂ)⁻¹ * mixed (gMinus g) (gPlus g) ((4 : ℝ)⁻¹)) := by ring
    _ = 2 * (energy g.1 : ℂ) := by rw [h]

theorem adjacent_prime_sum_exact
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a) :
    WeilPrimeSumV1 (mixed (gMinus g) (gZero g)) =
      ((Real.log 2 / Real.sqrt 2 * energy g.1 : ℝ) : ℂ) := by
  rw [adjacent_prime_sum_single g a hw]
  have hp : mixed (gMinus g) (gZero g) (2 : ℝ) = 0 := by
    simpa only [Nat.cast_ofNat] using adjacent_mixed_nat_zero_v29 g a hw 2 (by norm_num)
  have hv : ArithmeticFunction.vonMangoldt 2 = Real.log 2 :=
    ArithmeticFunction.vonMangoldt_apply_prime (by norm_num)
  change (ArithmeticFunction.vonMangoldt 2 : ℂ) *
    (mixed (gMinus g) (gZero g) (2 : ℝ) + (1 / (2 : ℂ)) *
      mixed (gMinus g) (gZero g) ((2 : ℝ)⁻¹)) = _
  rw [hp, adjacent_mixed_reciprocal_center, hv]
  push_cast
  have hs : (Real.sqrt 2 : ℂ) ^ 2 = 2 := by
    exact_mod_cast (Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2))
  have hn : (Real.sqrt 2 : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (Real.sqrt_pos.mpr (by norm_num : (0 : ℝ) < 2)))
  have hscalar : (1 / (2 : ℂ)) * (Real.sqrt 2 : ℂ) =
      1 / (Real.sqrt 2 : ℂ) := by
    field_simp
    linear_combination hs
  calc
    (Real.log 2 : ℂ) * (0 + 1 / 2 *
        ((Real.sqrt 2 : ℂ) * (energy g.1 : ℂ))) =
      (Real.log 2 : ℂ) * ((1 / 2 * (Real.sqrt 2 : ℂ)) *
        (energy g.1 : ℂ)) := by ring
    _ = _ := by rw [hscalar]; ring

theorem outer_prime_sum_exact
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a) :
    WeilPrimeSumV1 (mixed (gMinus g) (gPlus g)) =
      ((Real.log 2 / 2 * energy g.1 : ℝ) : ℂ) := by
  rw [outer_prime_sum_single g a hw]
  have hp : mixed (gMinus g) (gPlus g) (4 : ℝ) = 0 := by
    simpa only [Nat.cast_ofNat] using outer_mixed_nat_zero_v29 g a hw 4 (by norm_num)
  have hv : ArithmeticFunction.vonMangoldt 4 = Real.log 2 := by
    rw [show (4 : ℕ) = 2 ^ 2 by norm_num,
      ArithmeticFunction.vonMangoldt_apply_pow (by norm_num)]
    exact ArithmeticFunction.vonMangoldt_apply_prime (by norm_num)
  change (ArithmeticFunction.vonMangoldt 4 : ℂ) *
    (mixed (gMinus g) (gPlus g) (4 : ℝ) + (1 / (4 : ℂ)) *
      mixed (gMinus g) (gPlus g) ((4 : ℝ)⁻¹)) = _
  rw [hp, outer_mixed_reciprocal_center, hv]
  push_cast
  ring

theorem adjacent_mixed_shift_eq
    (g : WeilCompactSmoothGV1) (x : ℝ) (hx : 0 < x) :
    mixed (gZero g) (gPlus g) x = mixed (gMinus g) (gZero g) x := by
  have h1 := exp_half_mul_mixed_translate_v28 g 0 (Real.log 2) (Real.log x)
  have h2 := exp_half_mul_mixed_translate_v28 g (-Real.log 2) 0 (Real.log x)
  have he : (Real.exp (Real.log x / 2) : ℂ) ≠ 0 := by simp
  apply mul_left_cancel₀ he
  have h1' : (Real.exp (Real.log x / 2) : ℂ) *
      mixed (gZero g) (gPlus g) x =
      AEGIS.WeilWidthArchCorrelationV25.logCorrelationV25 g (Real.log x + Real.log 2) := by
    simpa [gZero, gPlus, Real.exp_log hx] using h1
  have h2' : (Real.exp (Real.log x / 2) : ℂ) *
      mixed (gMinus g) (gZero g) x =
      AEGIS.WeilWidthArchCorrelationV25.logCorrelationV25 g (Real.log x + Real.log 2) := by
    simpa [gMinus, gZero, Real.exp_log hx, sub_neg_eq_add] using h2
  exact h1'.trans h2'.symm

theorem right_adjacent_prime_sum_exact
    (g : WeilCompactSmoothGV1) (a : ℝ) (hw : WidthOneThirtyTwoAt g a) :
    WeilPrimeSumV1 (mixed (gZero g) (gPlus g)) =
      ((Real.log 2 / Real.sqrt 2 * energy g.1 : ℝ) : ℂ) := by
  calc
    WeilPrimeSumV1 (mixed (gZero g) (gPlus g)) =
        WeilPrimeSumV1 (mixed (gMinus g) (gZero g)) := by
      unfold WeilPrimeSumV1
      apply tsum_congr
      intro n
      have hn : (0 : ℝ) < ((n + 1 : ℕ) : ℝ) := by positivity
      simp only [WeilPrimeTermV1,
        adjacent_mixed_shift_eq g _ hn,
        adjacent_mixed_shift_eq g _ (inv_pos.mpr hn)]
    _ = _ := adjacent_prime_sum_exact g a hw

end AEGIS.WeilThreeBlockPrimeEvaluationV30

#print axioms AEGIS.WeilThreeBlockPrimeEvaluationV30.adjacent_prime_sum_exact
#print axioms AEGIS.WeilThreeBlockPrimeEvaluationV30.outer_prime_sum_exact
#print axioms AEGIS.WeilThreeBlockPrimeEvaluationV30.right_adjacent_prime_sum_exact
~~~~~~

## WeilThreeBlockCrossPrimeWindowV29

Path: `source/WeilThreeBlockCrossPrimeWindowV29.lean`

Original source lines: 1–220

Full file SHA256: `2fe243388829ccd3a1c924a33865f65de7c72c3970e97a69246e2b419eabc05f`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockCrossPrimeWindowV29.lean

~~~~~~lean
import WeilThreeBlockCrossPrimeV28
import Mathlib.Tactic

/-!
AEGIS Ω — translated three-block prime window isolation V2.9.

Using the exact V2.8 transport and the already kernel-verified
  exp(1/32) < 65/63,
this module proves that the translated mixed correlations, whose total support-difference window has width 1/16 (radius 1/32), can hit
reciprocal positive integers only at:
* m = 2 for adjacent blocks;
* m = 4 for the two-step outer blocks.

All positive-integer samples vanish.  No prime-sum evaluation, Archimedean
cross bound, global Weil positivity, or RH conclusion is asserted here.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilThreeBlockCrossPrimeWindowV29

open AEGIS.WeilMixedClosureV2
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilThreeBlockAnalyticConstantsV21
open AEGIS.WeilArchimedeanCothTailV1
open AEGIS.WeilThreeBlockCrossPrimeV28

private theorem nat_eq_two_of_log_window_v29
    {m : ℕ} (hm : 0 < m)
    (hwin :
      |Real.log (m : ℝ) - Real.log 2| ≤ (1 / 32 : ℝ)) :
    m = 2 := by
  have hmpos : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm
  have habs := (abs_le.mp hwin)
  have hup_log :
      Real.log (m : ℝ) ≤ Real.log 2 + (1 / 32 : ℝ) := by
    linarith [habs.2]
  have hlo_log :
      Real.log 2 - (1 / 32 : ℝ) ≤ Real.log (m : ℝ) := by
    linarith [habs.1]
  have hup := Real.exp_le_exp.mpr hup_log
  have hlo := Real.exp_le_exp.mpr hlo_log
  have hlog2 : Real.exp (Real.log 2) = (2 : ℝ) :=
    Real.exp_log (by norm_num)
  rw [Real.exp_add, hlog2] at hup
  rw [sub_eq_add_neg, Real.exp_add, hlog2] at hlo
  rw [Real.exp_log hmpos] at hup hlo
  have hlt3r : (m : ℝ) < 3 := by
    nlinarith [exp_one_div_32_lt]
  have hgt1r : (1 : ℝ) < (m : ℝ) := by
    nlinarith [exp_neg_one_div_32_gt]
  have hlt3 : m < 3 := by exact_mod_cast hlt3r
  have hgt1 : 1 < m := by exact_mod_cast hgt1r
  omega

private theorem nat_eq_four_of_log_window_v29
    {m : ℕ} (hm : 0 < m)
    (hwin :
      |Real.log (m : ℝ) - Real.log 4| ≤ (1 / 32 : ℝ)) :
    m = 4 := by
  have hmpos : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm
  have habs := (abs_le.mp hwin)
  have hup_log :
      Real.log (m : ℝ) ≤ Real.log 4 + (1 / 32 : ℝ) := by
    linarith [habs.2]
  have hlo_log :
      Real.log 4 - (1 / 32 : ℝ) ≤ Real.log (m : ℝ) := by
    linarith [habs.1]
  have hup := Real.exp_le_exp.mpr hup_log
  have hlo := Real.exp_le_exp.mpr hlo_log
  have hlog4 : Real.exp (Real.log 4) = (4 : ℝ) :=
    Real.exp_log (by norm_num)
  rw [Real.exp_add, hlog4] at hup
  rw [sub_eq_add_neg, Real.exp_add, hlog4] at hlo
  rw [Real.exp_log hmpos] at hup hlo
  have hlt5r : (m : ℝ) < 5 := by
    nlinarith [exp_one_div_32_lt]
  have hgt3r : (3 : ℝ) < (m : ℝ) := by
    nlinarith [exp_neg_one_div_32_gt]
  have hlt5 : m < 5 := by exact_mod_cast hlt5r
  have hgt3 : 3 < m := by exact_mod_cast hgt3r
  omega

private theorem log_four_eq_two_log_two_v29 :
    Real.log 4 = 2 * Real.log 2 := by
  rw [show (4 : ℝ) = 2 ^ (2 : ℕ) by norm_num, Real.log_pow]
  norm_num

/-- Every positive-integer sample of the adjacent mixed correlation is outside
its translated support window. -/
theorem adjacent_mixed_nat_zero_v29
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (m : ℕ) (hm : 0 < m) :
    mixed (gMinus g) (gZero g) (m : ℝ) = 0 := by
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := by
    exact_mod_cast (Nat.one_le_iff_ne_zero.mpr (Nat.ne_of_gt hm))
  have hlogm : 0 ≤ Real.log (m : ℝ) :=
    Real.log_nonneg hm1
  have hL : (1 / 32 : ℝ) < Real.log 2 := by
    linarith [log_two_lower]
  have harg : (0 : ℝ) < Real.log (m : ℝ) + Real.log 2 := by
    linarith [Real.log_pos (by norm_num : (1 : ℝ) < 2)]
  have hfar :
      (1 / 32 : ℝ) <
        |Real.log (m : ℝ) + 0 - (-Real.log 2)| := by
    rw [show Real.log (m : ℝ) + 0 - (-Real.log 2) =
        Real.log (m : ℝ) + Real.log 2 by ring,
      abs_of_pos harg]
    linarith
  have hz :=
    mixed_translate_zero_of_width_v28
      g a (-Real.log 2) 0 (Real.log (m : ℝ)) hw hfar
  have hexp : Real.exp (Real.log (m : ℝ)) = (m : ℝ) :=
    Real.exp_log (by exact_mod_cast hm)
  simpa [gMinus, gZero, hexp] using hz

/-- Except for m=2, every reciprocal positive-integer sample of the adjacent
mixed correlation is outside the translated support window. -/
theorem adjacent_mixed_inv_nat_zero_v29
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (m : ℕ) (hm : 0 < m) (hne : m ≠ 2) :
    mixed (gMinus g) (gZero g) ((m : ℝ)⁻¹) = 0 := by
  have hfar0 :
      (1 / 32 : ℝ) <
        |Real.log (m : ℝ) - Real.log 2| := by
    by_contra hnot
    have hle :
        |Real.log (m : ℝ) - Real.log 2| ≤ (1 / 32 : ℝ) :=
      le_of_not_gt hnot
    exact hne (nat_eq_two_of_log_window_v29 hm hle)
  have harg_eq :
      -Real.log (m : ℝ) + 0 - (-Real.log 2) =
        -(Real.log (m : ℝ) - Real.log 2) := by
    ring
  have hfar :
      (1 / 32 : ℝ) <
        |-Real.log (m : ℝ) + 0 - (-Real.log 2)| := by
    rw [harg_eq, abs_neg]
    exact hfar0
  have hz :=
    mixed_translate_zero_of_width_v28
      g a (-Real.log 2) 0 (-Real.log (m : ℝ)) hw hfar
  have hexp :
      Real.exp (-Real.log (m : ℝ)) = ((m : ℝ)⁻¹) := by
    rw [Real.exp_neg, Real.exp_log (by exact_mod_cast hm)]
  simpa [gMinus, gZero, hexp] using hz

/-- Every positive-integer sample of the outer mixed correlation is outside
its translated support window. -/
theorem outer_mixed_nat_zero_v29
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (m : ℕ) (hm : 0 < m) :
    mixed (gMinus g) (gPlus g) (m : ℝ) = 0 := by
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := by
    exact_mod_cast (Nat.one_le_iff_ne_zero.mpr (Nat.ne_of_gt hm))
  have hlogm : 0 ≤ Real.log (m : ℝ) :=
    Real.log_nonneg hm1
  have hL : (1 / 32 : ℝ) < Real.log 2 := by
    linarith [log_two_lower]
  have harg : (0 : ℝ) <
      Real.log (m : ℝ) + Real.log 2 - (-Real.log 2) := by
    linarith [Real.log_pos (by norm_num : (1 : ℝ) < 2)]
  have hfar :
      (1 / 32 : ℝ) <
        |Real.log (m : ℝ) + Real.log 2 - (-Real.log 2)| := by
    rw [abs_of_pos harg]
    linarith
  have hz :=
    mixed_translate_zero_of_width_v28
      g a (-Real.log 2) (Real.log 2) (Real.log (m : ℝ)) hw hfar
  have hexp : Real.exp (Real.log (m : ℝ)) = (m : ℝ) :=
    Real.exp_log (by exact_mod_cast hm)
  simpa [gMinus, gPlus, hexp] using hz

/-- Except for m=4, every reciprocal positive-integer sample of the outer
mixed correlation is outside the translated support window. -/
theorem outer_mixed_inv_nat_zero_v29
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (m : ℕ) (hm : 0 < m) (hne : m ≠ 4) :
    mixed (gMinus g) (gPlus g) ((m : ℝ)⁻¹) = 0 := by
  have hfar0 :
      (1 / 32 : ℝ) <
        |Real.log (m : ℝ) - Real.log 4| := by
    by_contra hnot
    have hle :
        |Real.log (m : ℝ) - Real.log 4| ≤ (1 / 32 : ℝ) :=
      le_of_not_gt hnot
    exact hne (nat_eq_four_of_log_window_v29 hm hle)
  have hlog4 := log_four_eq_two_log_two_v29
  have harg_eq :
      -Real.log (m : ℝ) + Real.log 2 - (-Real.log 2) =
        -(Real.log (m : ℝ) - Real.log 4) := by
    rw [hlog4]
    ring
  have hfar :
      (1 / 32 : ℝ) <
        |-Real.log (m : ℝ) + Real.log 2 - (-Real.log 2)| := by
    rw [harg_eq, abs_neg]
    exact hfar0
  have hz :=
    mixed_translate_zero_of_width_v28
      g a (-Real.log 2) (Real.log 2) (-Real.log (m : ℝ)) hw hfar
  have hexp :
      Real.exp (-Real.log (m : ℝ)) = ((m : ℝ)⁻¹) := by
    rw [Real.exp_neg, Real.exp_log (by exact_mod_cast hm)]
  simpa [gMinus, gPlus, hexp] using hz

end AEGIS.WeilThreeBlockCrossPrimeWindowV29

#print axioms AEGIS.WeilThreeBlockCrossPrimeWindowV29.adjacent_mixed_nat_zero_v29
#print axioms AEGIS.WeilThreeBlockCrossPrimeWindowV29.adjacent_mixed_inv_nat_zero_v29
#print axioms AEGIS.WeilThreeBlockCrossPrimeWindowV29.outer_mixed_nat_zero_v29
#print axioms AEGIS.WeilThreeBlockCrossPrimeWindowV29.outer_mixed_inv_nat_zero_v29
~~~~~~

## WeilThreeBlockCrossPrimeV28

Path: `source/WeilThreeBlockCrossPrimeV28.lean`

Original source lines: 1–196

Full file SHA256: `d27f40814b7da5b4755c7e63c9fa54d536a383341c086182c71b996f2b949991`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockCrossPrimeV28.lean

~~~~~~lean
import WeilWidthArchIntegralV27
import Mathlib.Tactic

/-!
AEGIS Ω — translated three-block mixed-correlation transport V2.8.

This lane attacks only the remaining cross-term frontier after V2.7 closed the
retained width-1/32 diagonal estimate.

For arbitrary compact-smooth packets a,b define the additive-coordinate mixed
correlation
  X_{a,b}(u) = ∫ logLift(a)(v+u) * conj(logLift(b)(v)) dv.
It satisfies
  X_{a,b}(u) = exp(u/2) * mixed(a,b)(exp u).

For two translates of one retained packet g this collapses to the already
verified V2.5 autocorrelation:
  exp(u/2) * mixed(T_d1 g,T_d2 g)(exp u)
    = C_g(u + d2 - d1).

This module also proves two-sided width vanishing.  It does not yet assert the
51/100 or 9/25 cross B bounds, global Weil positivity, or RH.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilThreeBlockCrossPrimeV28

open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilMixedClosureV2
open AEGIS.WeilMixedAlgebraV2
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilWidthArchCorrelationV25
open AEGIS.WeilDiagonalKernelReductionV21

def logCrossV28
    (a b : WeilCompactSmoothGV1) (u : ℝ) : ℂ :=
  ∫ v : ℝ, logLift a.1 (v + u) * conj (logLift b.1 v)

/-- Exact multiplicative-to-additive identity for the actual repository mixed
correlation. -/
theorem logCross_eq_mixed_v28
    (a b : WeilCompactSmoothGV1) (u : ℝ) :
    logCrossV28 a b u =
      (Real.exp (u / 2) : ℂ) * mixed a b (Real.exp u) := by
  unfold logCrossV28 mixed
  rw [integral_exp_substitution_complex]
  rw [← integral_const_mul]
  apply integral_congr_ae
  filter_upwards [] with v
  unfold logLift
  rw [Complex.star_def, map_mul]
  simp only [Complex.conj_ofReal, Complex.real_smul]
  have harg :
      Real.exp u * Real.exp v = Real.exp (v + u) := by
    rw [← Real.exp_add]
    congr 1
    ring
  rw [harg]
  have hscalar :
      (Real.exp (u / 2) : ℂ) * (Real.exp v : ℂ) =
        (Real.exp ((v + u) / 2) : ℂ) *
          (Real.exp (v / 2) : ℂ) := by
    norm_cast
    rw [← Real.exp_add, ← Real.exp_add]
    congr 1
    ring
  calc
    (Real.exp ((v + u) / 2) : ℂ) * a.1 (Real.exp (v + u)) *
        ((Real.exp (v / 2) : ℂ) * conj (b.1 (Real.exp v)))
        =
      ((Real.exp ((v + u) / 2) : ℂ) *
          (Real.exp (v / 2) : ℂ)) *
        (a.1 (Real.exp (v + u)) * conj (b.1 (Real.exp v))) := by
          ring
    _ =
      ((Real.exp (u / 2) : ℂ) * (Real.exp v : ℂ)) *
        (a.1 (Real.exp (v + u)) * conj (b.1 (Real.exp v))) := by
          rw [← hscalar]
    _ =
      (Real.exp (u / 2) : ℂ) *
        ((Real.exp v : ℂ) *
          (a.1 (Real.exp (v + u)) * conj (b.1 (Real.exp v)))) := by
          ring

/-- Translating both packets converts the mixed log correlation into the base
packet's V2.5 autocorrelation, depending only on the relative shift. -/
theorem logCross_translate_eq_logCorrelation_v28
    (g : WeilCompactSmoothGV1) (d1 d2 u : ℝ) :
    logCrossV28 (translatePacket g d1) (translatePacket g d2) u =
      logCorrelationV25 g (u + d2 - d1) := by
  unfold logCrossV28 logCorrelationV25
  simp_rw [logLift_translate]
  let F : ℝ → ℂ := fun w =>
    logLift g.1 (w + (u + d2 - d1)) * conj (logLift g.1 w)
  calc
    (∫ v : ℝ,
      logLift g.1 (v + u - d1) * conj (logLift g.1 (v - d2)))
        =
      ∫ v : ℝ, F (v + (-d2)) := by
        apply integral_congr_ae
        filter_upwards [] with v
        dsimp [F]
        congr 2
        congr 1
        ring
    _ = ∫ w : ℝ, F w := integral_add_right_eq_self F (-d2)
    _ = ∫ w : ℝ,
      logLift g.1 (w + (u + d2 - d1)) * conj (logLift g.1 w) := by
        rfl

/-- Load-bearing transport identity for the retained translated packet family. -/
theorem exp_half_mul_mixed_translate_v28
    (g : WeilCompactSmoothGV1) (d1 d2 u : ℝ) :
    (Real.exp (u / 2) : ℂ) *
        mixed (translatePacket g d1) (translatePacket g d2) (Real.exp u) =
      logCorrelationV25 g (u + d2 - d1) := by
  rw [← logCross_eq_mixed_v28]
  exact logCross_translate_eq_logCorrelation_v28 g d1 d2 u

/-- Width-1/32 support kills the V2.5 log correlation on both sides of the
difference-support interval. -/
theorem logCorrelation_zero_of_width_abs_v28
    (g : WeilCompactSmoothGV1) (a u : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (hu : (1 / 32 : ℝ) < |u|) :
    logCorrelationV25 g u = 0 := by
  unfold logCorrelationV25
  apply integral_eq_zero_of_ae
  filter_upwards [] with v
  by_cases h0 : logLift g.1 v = 0
  · simp [h0]
  · by_cases h1 : logLift g.1 (v + u) = 0
    · simp [h1]
    · have hm0 : v ∈ tsupport (logLift g.1) :=
        subset_tsupport _ h0
      have hm1 : v + u ∈ tsupport (logLift g.1) :=
        subset_tsupport _ h1
      have hv := hw hm0
      have hvu := hw hm1
      have habs : |u| ≤ (1 / 32 : ℝ) := by
        rw [abs_le]
        constructor <;> linarith [hv.1, hv.2, hvu.1, hvu.2]
      exact False.elim ((not_le_of_gt hu) habs)

/-- Hence the actual translated mixed correlation vanishes whenever its
relative log displacement lies outside the width-1/32 window. -/
theorem mixed_translate_zero_of_width_v28
    (g : WeilCompactSmoothGV1) (a d1 d2 u : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (hu : (1 / 32 : ℝ) < |u + d2 - d1|) :
    mixed (translatePacket g d1) (translatePacket g d2) (Real.exp u) = 0 := by
  have h :=
    exp_half_mul_mixed_translate_v28 g d1 d2 u
  rw [logCorrelation_zero_of_width_abs_v28 g a (u + d2 - d1) hw hu] at h
  have he : (Real.exp (u / 2) : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (Real.exp_ne_zero _)
  exact (mul_eq_zero.mp h).resolve_left he

/-- The centered log correlation is exactly the packet energy, as a complex
number. -/
theorem logCorrelation_zero_eq_energy_v28
    (g : WeilCompactSmoothGV1) :
    logCorrelationV25 g 0 = (energy g.1 : ℂ) := by
  rw [logCorrelation_eq_autocorrelation_v25]
  simp only [zero_div, Real.exp_zero, Complex.ofReal_one, one_mul]
  apply Complex.ext
  · simpa using
      (AEGIS.WeilDiagonalKernelReductionV21.autocorrelation_one_re_eq_energy g)
  · simpa using (weil_autocorrelation_one_real_v1 g)

/-- Exact center value for any pair of translates. -/
theorem mixed_translate_center_v28
    (g : WeilCompactSmoothGV1) (d1 d2 : ℝ) :
    (Real.exp ((d1 - d2) / 2) : ℂ) *
        mixed (translatePacket g d1) (translatePacket g d2)
          (Real.exp (d1 - d2)) =
      (energy g.1 : ℂ) := by
  have h :=
    exp_half_mul_mixed_translate_v28 g d1 d2 (d1 - d2)
  have hz : d1 - d2 + d2 - d1 = 0 := by ring
  rw [hz, logCorrelation_zero_eq_energy_v28] at h
  exact h

end AEGIS.WeilThreeBlockCrossPrimeV28

#print axioms AEGIS.WeilThreeBlockCrossPrimeV28.logCross_eq_mixed_v28
#print axioms AEGIS.WeilThreeBlockCrossPrimeV28.logCross_translate_eq_logCorrelation_v28
#print axioms AEGIS.WeilThreeBlockCrossPrimeV28.exp_half_mul_mixed_translate_v28
#print axioms AEGIS.WeilThreeBlockCrossPrimeV28.logCorrelation_zero_of_width_abs_v28
#print axioms AEGIS.WeilThreeBlockCrossPrimeV28.mixed_translate_zero_of_width_v28
#print axioms AEGIS.WeilThreeBlockCrossPrimeV28.mixed_translate_center_v28
~~~~~~

## WeilWidthArchIntegralV27

Path: `source/WeilWidthArchIntegralV27.lean`

Original source lines: 1–248

Full file SHA256: `eb61e1af8b015b3b6f3a3aaa94a6b639a90714095c0de8d9dec168964a0ec505`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilWidthArchIntegralV27.lean

~~~~~~lean
import WeilWidthArchBudgetV26
import Mathlib.MeasureTheory.Integral.IntegralEqImproper
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.Tactic

/-!
AEGIS Ω — width-1/32 actual Archimedean integral budget V2.7.

This module performs the final integration step above the pointwise V2.6
Archimedean bounds.

1. Substitute x = exp u in the actual repository Archimedean integral.
2. Split (0,∞) into (0,1/32] and (1/32,∞).
3. Integrate the V2.6 inner pointwise majorant exactly.
4. Use the V2.6 exact outer-tail identity and the V2.4 coth tail.
5. Discharge the sole V2.4 Archimedean-budget premise.

The resulting 103/100 diagonal coercive estimate is only for the retained
width-1/32 packet class.  No off-diagonal estimate, global Weil sign, or RH
conclusion is asserted here.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilWidthArchIntegralV27

open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilWidthArchBudgetV26
open AEGIS.WeilDiagonalKernelReductionV21
open AEGIS.WeilWidthDiagonalArchFrontierV24
open AEGIS.WeilMixedAlgebraV2

private def archLogComplexV27
    (g : WeilCompactSmoothGV1) (u : ℝ) : ℂ :=
  Real.exp u •
    WeilArchimedeanIntegrandV1
      (WeilAutocorrelationV1 g) (Real.exp u)

/-- The exponential pullback of the actual Archimedean integrand is
integrable on the positive logarithmic half-line. -/
theorem arch_log_complex_integrableOn_v27
    (g : WeilCompactSmoothGV1) :
    IntegrableOn (archLogComplexV27 g) (Ioi (0 : ℝ)) := by
  have hbase :
      IntegrableOn
        (WeilArchimedeanIntegrandV1 (WeilAutocorrelationV1 g))
        (Ioi (1 : ℝ)) := by
    simpa only [weil_autocorrelation_compact_smooth_coe_v1] using
      (weil_compact_smooth_archimedean_integrable_v1
        (WeilAutocorrelationCompactSmoothV1 g))
  have hpull :=
    (integrableOn_comp_exp_Ioi
      (WeilArchimedeanIntegrandV1 (WeilAutocorrelationV1 g)) 0).2
      (by simpa using hbase)
  change IntegrableOn
    (fun u : ℝ => Real.exp u •
      WeilArchimedeanIntegrandV1
        (WeilAutocorrelationV1 g) (Real.exp u))
    (Ioi (0 : ℝ))
  exact hpull

/-- The real transformed integrand from V2.6 is integrable on (0,∞). -/
theorem width_arch_log_integrableOn_v27
    (g : WeilCompactSmoothGV1) :
    IntegrableOn (widthArchLogIntegrandV26 g) (Ioi (0 : ℝ)) := by
  have hcomplex := arch_log_complex_integrableOn_v27 g
  have hreal :
      IntegrableOn (fun u : ℝ => (archLogComplexV27 g u).re)
        (Ioi (0 : ℝ)) := hcomplex.re
  refine hreal.congr ?_
  filter_upwards [self_mem_ae_restrict measurableSet_Ioi] with u hu
  unfold archLogComplexV27
  have hre :
      (Real.exp u •
        WeilArchimedeanIntegrandV1
          (WeilAutocorrelationV1 g) (Real.exp u)).re =
        Real.exp u *
          (WeilArchimedeanIntegrandV1
            (WeilAutocorrelationV1 g) (Real.exp u)).re := by
    simp only [Complex.real_smul, Complex.mul_re,
      Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
  rw [hre]
  exact exp_mul_archimedean_re_eq_log_v26 g hu

/-- Exact x=exp(u) conversion for the real part of the actual repository
Archimedean integral. -/
theorem archimedean_real_eq_log_integral_v27
    (g : WeilCompactSmoothGV1) :
    (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re =
      ∫ u in Ioi (0 : ℝ), widthArchLogIntegrandV26 g u := by
  let G : ℝ → ℂ :=
    WeilArchimedeanIntegrandV1 (WeilAutocorrelationV1 g)
  have hcomplex := arch_log_complex_integrableOn_v27 g
  change IntegrableOn
    (fun u : ℝ => Real.exp u • G (Real.exp u))
    (Ioi (0 : ℝ)) at hcomplex
  have hchange :
      (∫ u in Ioi (0 : ℝ), Real.exp u • G (Real.exp u)) =
        ∫ x in Ioi (1 : ℝ), G x := by
    simpa using (integral_comp_exp_Ioi G 0)
  unfold WeilArchimedeanIntegralV1
  change (∫ x in Ioi (1 : ℝ), G x).re =
    ∫ u in Ioi (0 : ℝ), widthArchLogIntegrandV26 g u
  calc
    (∫ x in Ioi (1 : ℝ), G x).re =
        (∫ u in Ioi (0 : ℝ), Real.exp u • G (Real.exp u)).re := by
          exact congrArg Complex.re hchange.symm
    _ = ∫ u in Ioi (0 : ℝ),
          (Real.exp u • G (Real.exp u)).re := by
          exact (integral_re hcomplex).symm
    _ = ∫ u in Ioi (0 : ℝ), widthArchLogIntegrandV26 g u := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro u hu
          dsimp [G]
          simpa only [Complex.mul_re, Complex.ofReal_re,
            Complex.ofReal_im, zero_mul, sub_zero] using
            (exp_mul_archimedean_re_eq_log_v26 g hu)

/-- Exact split of the transformed integral at the retained width 1/32. -/
theorem width_arch_log_split_v27
    (g : WeilCompactSmoothGV1) :
    (∫ u in Ioi (0 : ℝ), widthArchLogIntegrandV26 g u) =
      (∫ u in Ioc (0 : ℝ) (1 / 32 : ℝ),
        widthArchLogIntegrandV26 g u) +
      ∫ u in Ioi (1 / 32 : ℝ), widthArchLogIntegrandV26 g u := by
  have hfull := width_arch_log_integrableOn_v27 g
  have hinner :
      IntegrableOn (widthArchLogIntegrandV26 g)
        (Ioc (0 : ℝ) (1 / 32 : ℝ)) :=
    hfull.mono_set (by
      intro u hu
      exact hu.1)
  have htail :
      IntegrableOn (widthArchLogIntegrandV26 g)
        (Ioi (1 / 32 : ℝ)) :=
    hfull.mono_set (by
      intro u hu
      change (1 / 32 : ℝ) < u at hu
      change (0 : ℝ) < u
      linarith)
  rw [← Set.Ioc_union_Ioi_eq_Ioi (by norm_num : (0 : ℝ) ≤ 1 / 32),
    setIntegral_union Set.Ioc_disjoint_Ioi_same measurableSet_Ioi hinner htail]

/-- The inner window integrates to at most diagonalSmallV21 times the packet
energy. -/
theorem width_arch_inner_integral_le_v27
    (g : WeilCompactSmoothGV1) :
    (∫ u in Ioc (0 : ℝ) (1 / 32 : ℝ),
      widthArchLogIntegrandV26 g u) ≤
      energy g.1 * diagonalSmallV21 := by
  let C : ℝ :=
    energy g.1 * (Real.exp (1 / 64 : ℝ) / 2)
  have hfull := width_arch_log_integrableOn_v27 g
  have hinner :
      IntegrableOn (widthArchLogIntegrandV26 g)
        (Ioc (0 : ℝ) (1 / 32 : ℝ)) :=
    hfull.mono_set (by
      intro u hu
      exact hu.1)
  have hconst : IntegrableOn (fun _ : ℝ => C)
      (Ioc (0 : ℝ) (1 / 32 : ℝ)) := by
    exact continuous_const.integrableOn_Ioc
  have hmono :
      (∫ u in Ioc (0 : ℝ) (1 / 32 : ℝ),
        widthArchLogIntegrandV26 g u) ≤
      ∫ _u in Ioc (0 : ℝ) (1 / 32 : ℝ), C := by
    refine setIntegral_mono_on hinner hconst measurableSet_Ioc ?_
    intro u hu
    dsimp [C]
    exact width_arch_log_inner_pointwise_v26 g hu.1 hu.2
  calc
    (∫ u in Ioc (0 : ℝ) (1 / 32 : ℝ),
      widthArchLogIntegrandV26 g u)
        ≤ ∫ _u in Ioc (0 : ℝ) (1 / 32 : ℝ), C := hmono
    _ = (1 / 32 : ℝ) * C := by
      rw [setIntegral_const, smul_eq_mul,
        Real.volume_real_Ioc_of_le (by norm_num : (0 : ℝ) ≤ 1 / 32)]
      ring
    _ = energy g.1 * diagonalSmallV21 := by
      dsimp [C]
      unfold diagonalSmallV21
      ring

/-- Outside the retained width, the transformed integral is exactly minus the
packet energy times the V2.4 coth tail. -/
theorem width_arch_tail_integral_eq_v27
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) :
    (∫ u in Ioi (1 / 32 : ℝ), widthArchLogIntegrandV26 g u) =
      -energy g.1 * diagonalTailV24 := by
  calc
    (∫ u in Ioi (1 / 32 : ℝ), widthArchLogIntegrandV26 g u)
        =
      ∫ u in Ioi (1 / 32 : ℝ),
        (-energy g.1) * (1 / Real.sinh u) := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro u hu
          rw [width_arch_log_tail_eq_v26 g a hw hu]
          ring
    _ = (-energy g.1) *
        (∫ u in Ioi (1 / 32 : ℝ), 1 / Real.sinh u) := by
          rw [integral_const_mul]
    _ = -energy g.1 * diagonalTailV24 := by
          rfl

/-- The sole V2.4 Archimedean-budget premise is now discharged for every
retained width-1/32 packet. -/
theorem width_archimedean_budget_v27
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) :
    (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re ≤
      energy g.1 * (diagonalSmallV21 - diagonalTailV24) := by
  rw [archimedean_real_eq_log_integral_v27,
    width_arch_log_split_v27]
  have hinner := width_arch_inner_integral_le_v27 g
  have htail := width_arch_tail_integral_eq_v27 g a hw
  calc
    (∫ u in Ioc (0 : ℝ) (1 / 32 : ℝ),
        widthArchLogIntegrandV26 g u) +
        ∫ u in Ioi (1 / 32 : ℝ), widthArchLogIntegrandV26 g u
        ≤ energy g.1 * diagonalSmallV21 +
          (-energy g.1 * diagonalTailV24) := by
            exact add_le_add hinner (le_of_eq htail)
    _ = energy g.1 * (diagonalSmallV21 - diagonalTailV24) := by
          ring

/-- Unconditional retained-packet diagonal coercivity: the former Archimedean
budget premise is no longer present. -/
theorem width_diagonal_103_over_100_v27
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) :
    (103 / 100 : ℝ) * energy g.1 ≤ -(B g g).re := by
  exact width_diagonal_103_over_100_of_arch_budget_v24
    g a hw (width_archimedean_budget_v27 g a hw)

end AEGIS.WeilWidthArchIntegralV27

#print axioms AEGIS.WeilWidthArchIntegralV27.arch_log_complex_integrableOn_v27
#print axioms AEGIS.WeilWidthArchIntegralV27.archimedean_real_eq_log_integral_v27
#print axioms AEGIS.WeilWidthArchIntegralV27.width_arch_inner_integral_le_v27
#print axioms AEGIS.WeilWidthArchIntegralV27.width_arch_tail_integral_eq_v27
#print axioms AEGIS.WeilWidthArchIntegralV27.width_archimedean_budget_v27
#print axioms AEGIS.WeilWidthArchIntegralV27.width_diagonal_103_over_100_v27
~~~~~~

## WeilWidthArchBudgetV26

Path: `source/WeilWidthArchBudgetV26.lean`

Original source lines: 1–259

Full file SHA256: `8e1d3a45e94c5770550e4e0657ef80133a9621b0aa01f160e890c971787cb054`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilWidthArchBudgetV26.lean

~~~~~~lean
import WeilWidthArchCorrelationV25
import Mathlib.Analysis.SpecialFunctions.Trigonometric.DerivHyp
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Tactic

/-!
AEGIS Ω — width-1/32 actual Archimedean budget V2.6.

This lane converts the V2.5 logarithmic autocorrelation estimates into the
actual repository Archimedean diagonal integrand.

For x = exp u and A = WeilAutocorrelationV1 g,

  exp(u) * Re(WeilArchimedeanIntegrandV1 A (exp u))
    = (exp(u) * Re A(exp u) - energy(g)) / sinh(u).

The V2.5 bound
  ||A(exp u)|| <= exp(-u/2) * energy(g)
then gives the exact small-window majorant consumed by the V2.4 frontier,
while width support makes the outer tail exact.

No off-diagonal estimate, global Weil sign, or RH conclusion is asserted here.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilWidthArchBudgetV26

open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilWidthArchCorrelationV25
open AEGIS.WeilDiagonalKernelReductionV21
open AEGIS.WeilWidthDiagonalArchFrontierV24

def widthArchLogIntegrandV26
    (g : WeilCompactSmoothGV1) (u : ℝ) : ℝ :=
  (Real.exp u *
      (WeilAutocorrelationV1 g (Real.exp u)).re -
    energy g.1) / Real.sinh u

/-- V2.5 immediately gives the multiplicative autocorrelation decay on a
positive logarithmic displacement. -/
theorem autocorrelation_exp_norm_le_v26
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    ‖WeilAutocorrelationV1 g (Real.exp u)‖ ≤
      Real.exp (-u / 2) * energy g.1 := by
  have h :=
    norm_logCorrelation_le_energy_v25 g u
  rw [logCorrelation_eq_autocorrelation_v25] at h
  have hepos : 0 < Real.exp (u / 2) := Real.exp_pos _
  have hmul :
      Real.exp (u / 2) *
          ‖WeilAutocorrelationV1 g (Real.exp u)‖ ≤
        energy g.1 := by
    simpa [norm_mul, Complex.norm_exp] using h
  have hdiv :
      ‖WeilAutocorrelationV1 g (Real.exp u)‖ ≤
        energy g.1 / Real.exp (u / 2) := by
    rw [le_div_iff₀ hepos]
    simpa [mul_comm] using hmul
  calc
    ‖WeilAutocorrelationV1 g (Real.exp u)‖
        ≤ energy g.1 / Real.exp (u / 2) := hdiv
    _ = Real.exp (-u / 2) * energy g.1 := by
      rw [show -u / 2 = -(u / 2) by ring, Real.exp_neg]
      simp [div_eq_mul_inv, mul_comm]

/-- Real-part form used by the Archimedean numerator. -/
theorem autocorrelation_exp_re_le_v26
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    Real.exp u *
        (WeilAutocorrelationV1 g (Real.exp u)).re ≤
      Real.exp (u / 2) * energy g.1 := by
  have hre :
      (WeilAutocorrelationV1 g (Real.exp u)).re ≤
        ‖WeilAutocorrelationV1 g (Real.exp u)‖ :=
    Complex.re_le_norm _
  have hnorm := autocorrelation_exp_norm_le_v26 g u
  have hexp : 0 ≤ Real.exp u := (Real.exp_pos u).le
  have h1 := mul_le_mul_of_nonneg_left (hre.trans hnorm) hexp
  calc
    Real.exp u *
        (WeilAutocorrelationV1 g (Real.exp u)).re
        ≤ Real.exp u *
          (Real.exp (-u / 2) * energy g.1) := h1
    _ = Real.exp (u / 2) * energy g.1 := by
      calc
        Real.exp u * (Real.exp (-u / 2) * energy g.1)
            = (Real.exp u * Real.exp (-u / 2)) * energy g.1 := by ring
        _ = Real.exp (u + (-u / 2)) * energy g.1 := by
          rw [Real.exp_add]
        _ = Real.exp (u / 2) * energy g.1 := by
          congr 2
          ring

/-- Exact pointwise logarithmic form of the repository Archimedean diagonal
integrand. -/
theorem exp_mul_archimedean_re_eq_log_v26
    (g : WeilCompactSmoothGV1) {u : ℝ} (hu : 0 < u) :
    Real.exp u *
        (WeilArchimedeanIntegrandV1
          (WeilAutocorrelationV1 g) (Real.exp u)).re =
      widthArchLogIntegrandV26 g u := by
  let x : ℝ := Real.exp u
  let A : ℝ → ℂ := WeilAutocorrelationV1 g
  let E : ℝ := energy g.1
  have hxpos : 0 < x := by
    dsimp [x]
    exact Real.exp_pos u
  have hxC : (x : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hxpos.ne'
  have hrec : A x⁻¹ = (x : ℂ) * conj (A x) := by
    dsimp [A]
    exact weil_autocorrelation_reciprocal_v1 g hxpos
  have hcenter_re : (A 1).re = E := by
    dsimp [A, E]
    exact AEGIS.WeilDiagonalKernelReductionV21.autocorrelation_one_re_eq_energy g
  have hcenter_im : (A 1).im = 0 := by
    dsimp [A]
    exact weil_autocorrelation_one_real_v1 g
  have hcenter : A 1 = (E : ℂ) := by
    apply Complex.ext
    · simpa using hcenter_re
    · simpa using hcenter_im
  have hnum :
      A x + (1 / (x : ℂ)) * A x⁻¹ -
          (2 / (x : ℂ)) * A 1 =
        ((2 * (A x).re - 2 * E / x : ℝ) : ℂ) := by
    rw [hrec, hcenter]
    apply Complex.ext
    · simp [hxC]
      field_simp [hxpos.ne']
      ring
    · simp [hxC]
  have hden :
      (x : ℂ) - ((x⁻¹ : ℝ) : ℂ) =
        ((x - x⁻¹ : ℝ) : ℂ) := by
    norm_cast
  have hsinh : 0 < Real.sinh u := by
    exact AEGIS.WeilArchimedeanCothTailV1.sinh_pos_of_pos hu
  have hdenR : x - x⁻¹ = 2 * Real.sinh u := by
    dsimp [x]
    rw [Real.sinh_eq, Real.exp_neg]
    ring
  unfold WeilArchimedeanIntegrandV1
  change x *
      ((A x + (1 / (x : ℂ)) * A x⁻¹ -
          (2 / (x : ℂ)) * A 1) /
        ((x : ℂ) - ((x⁻¹ : ℝ) : ℂ))).re =
    widthArchLogIntegrandV26 g u
  rw [hnum, hden, Complex.div_ofReal_re]
  unfold widthArchLogIntegrandV26
  dsimp [x, A, E]
  rw [hdenR]
  field_simp [hsinh.ne']

private theorem exp_sub_one_le_self_mul_exp_v26
    {v : ℝ} (hv : 0 ≤ v) :
    Real.exp v - 1 ≤ v * Real.exp v := by
  have h := Real.add_one_le_exp (-v)
  have hm :=
    mul_le_mul_of_nonneg_left h (Real.exp_pos v).le
  have hexp : Real.exp v * Real.exp (-v) = 1 := by
    rw [← Real.exp_add]
    simp
  rw [hexp] at hm
  nlinarith

/-- On the retained inner log-window, the transformed real Archimedean
integrand is bounded by the exact constant that integrates to
diagonalSmallV21 times energy. -/
theorem width_arch_log_inner_pointwise_v26
    (g : WeilCompactSmoothGV1) {u : ℝ}
    (hu0 : 0 < u) (huw : u ≤ (1 / 32 : ℝ)) :
    widthArchLogIntegrandV26 g u ≤
      energy g.1 * (Real.exp (1 / 64 : ℝ) / 2) := by
  have hE : 0 ≤ energy g.1 := energy_nonnegative g.1
  have hsinh : 0 < Real.sinh u :=
    AEGIS.WeilArchimedeanCothTailV1.sinh_pos_of_pos hu0
  have hnum :=
    autocorrelation_exp_re_le_v26 g u
  have hnum' :
      Real.exp u * (WeilAutocorrelationV1 g (Real.exp u)).re -
          energy g.1 ≤
        energy g.1 * (Real.exp (u / 2) - 1) := by
    nlinarith
  have huv : 0 ≤ u / 2 := by linarith
  have hexp :=
    exp_sub_one_le_self_mul_exp_v26 huv
  have hsinh_ge : u ≤ Real.sinh u :=
    Real.self_le_sinh_iff.mpr hu0.le
  have hexpmono :
      Real.exp (u / 2) ≤ Real.exp (1 / 64 : ℝ) := by
    apply Real.exp_le_exp.mpr
    linarith
  have hkernel :
      (Real.exp (u / 2) - 1) / Real.sinh u ≤
        Real.exp (1 / 64 : ℝ) / 2 := by
    rw [div_le_iff₀ hsinh]
    have h1 :
        Real.exp (u / 2) - 1 ≤
          (u / 2) * Real.exp (u / 2) := hexp
    have h2 :
        (u / 2) * Real.exp (u / 2) ≤
          (Real.sinh u / 2) * Real.exp (1 / 64 : ℝ) := by
      exact mul_le_mul
        (by linarith [hsinh_ge])
        hexpmono
        (Real.exp_pos _).le
        (by linarith [hu0])
    calc
      Real.exp (u / 2) - 1
          ≤ (u / 2) * Real.exp (u / 2) := h1
      _ ≤ (Real.sinh u / 2) * Real.exp (1 / 64 : ℝ) := h2
      _ = (Real.exp (1 / 64 : ℝ) / 2) * Real.sinh u := by ring
  unfold widthArchLogIntegrandV26
  have hdiv :
      (Real.exp u * (WeilAutocorrelationV1 g (Real.exp u)).re -
          energy g.1) / Real.sinh u ≤
        (energy g.1 * (Real.exp (u / 2) - 1)) / Real.sinh u := by
    exact div_le_div_of_nonneg_right hnum' hsinh.le
  calc
    (Real.exp u * (WeilAutocorrelationV1 g (Real.exp u)).re -
        energy g.1) / Real.sinh u
        ≤ energy g.1 *
            ((Real.exp (u / 2) - 1) / Real.sinh u) := by
          simpa [mul_div_assoc] using hdiv
    _ ≤ energy g.1 * (Real.exp (1 / 64 : ℝ) / 2) :=
      mul_le_mul_of_nonneg_left hkernel hE

/-- Outside the width difference-support, the transformed integrand is exactly
the negative 1/sinh tail. -/
theorem width_arch_log_tail_eq_v26
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    {u : ℝ} (hu : (1 / 32 : ℝ) < u) :
    widthArchLogIntegrandV26 g u =
      -energy g.1 / Real.sinh u := by
  have hC := logCorrelation_zero_of_width_v25 g a u hw hu
  rw [logCorrelation_eq_autocorrelation_v25] at hC
  have he :
      (Real.exp (u / 2) : ℂ) ≠ 0 := by
    exact Complex.ofReal_ne_zero.mpr (Real.exp_ne_zero _)
  have hA :
      WeilAutocorrelationV1 g (Real.exp u) = 0 := by
    exact (mul_eq_zero.mp hC).resolve_left he
  unfold widthArchLogIntegrandV26
  rw [hA]
  simp

end AEGIS.WeilWidthArchBudgetV26

#print axioms AEGIS.WeilWidthArchBudgetV26.autocorrelation_exp_norm_le_v26
#print axioms AEGIS.WeilWidthArchBudgetV26.exp_mul_archimedean_re_eq_log_v26
#print axioms AEGIS.WeilWidthArchBudgetV26.width_arch_log_inner_pointwise_v26
#print axioms AEGIS.WeilWidthArchBudgetV26.width_arch_log_tail_eq_v26
~~~~~~

## WeilWidthArchCorrelationV25

Path: `source/WeilWidthArchCorrelationV25.lean`

Original source lines: 1–247

Full file SHA256: `b778712a5002a6d419800649951f503202ec0e966983a4c9d1843996d97194b4`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilWidthArchCorrelationV25.lean

~~~~~~lean
import WeilWidthDiagonalArchFrontierV24
import Mathlib.MeasureTheory.Integral.IntegralEqImproper
import Mathlib.Tactic

/-!
AEGIS Ω — width-1/32 logarithmic autocorrelation core V2.5.

For h(t)=exp(t/2) g(exp t), define
  C_g(u)=∫ h(v+u) conj(h(v)) dv.

This module proves three facts needed by the remaining Archimedean diagonal
budget:
1. C_g(u)=exp(u/2) A_g(exp u), where A_g is the repository autocorrelation;
2. ||C_g(u)|| <= energy(g), by the elementary 2ab <= a^2+b^2 bound and
   translation invariance of Lebesgue measure;
3. C_g(u)=0 for u>1/32 when g has the retained width-1/32 logarithmic support.

No Archimedean integral inequality, off-diagonal estimate, global Weil sign,
or RH conclusion is asserted here.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate BigOperators
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilWidthArchCorrelationV25

open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilThreeBlockTranslatedPacketsV22

def logCorrelationV25 (g : WeilCompactSmoothGV1) (u : ℝ) : ℂ :=
  ∫ v : ℝ, logLift g.1 (v + u) * conj (logLift g.1 v)

private theorem logLift_continuous_v25 (g : WeilCompactSmoothGV1) :
    Continuous (logLift g.1) := by
  unfold logLift
  have hscalar : Continuous (fun t : ℝ =>
      (Real.exp (t / 2) : ℂ)) := by
    fun_prop
  have hpacket : Continuous (fun t : ℝ =>
      g.1 (Real.exp t)) :=
    g.2.1.continuous.comp Real.continuous_exp
  exact hscalar.mul hpacket

private theorem logLift_hasCompactSupport_v25 (g : WeilCompactSmoothGV1) :
    HasCompactSupport (logLift g.1) := by
  let K : Set ℝ := Real.log '' tsupport g.1
  have hK : IsCompact K := by
    have hlog : ContinuousOn Real.log (tsupport g.1) := by
      intro x hx
      exact (Real.continuousAt_log (ne_of_gt (g.2.2.2 hx))).continuousWithinAt
    exact g.2.2.1.image_of_continuousOn hlog
  apply HasCompactSupport.of_support_subset_isCompact hK
  intro t ht
  have hg : g.1 (Real.exp t) ≠ 0 := by
    intro hzero
    apply ht
    simp [logLift, hzero]
  have hm : Real.exp t ∈ tsupport g.1 := subset_tsupport _ hg
  refine ⟨Real.exp t, hm, ?_⟩
  simp

theorem logLift_sq_integrable_v25 (g : WeilCompactSmoothGV1) :
    Integrable (fun v : ℝ => ‖logLift g.1 v‖ ^ 2) := by
  have hc : Continuous (fun v : ℝ => ‖logLift g.1 v‖ ^ 2) := by
    exact (logLift_continuous_v25 g).norm.pow 2
  have hk : HasCompactSupport (fun v : ℝ => ‖logLift g.1 v‖ ^ 2) := by
    have hbase := logLift_hasCompactSupport_v25 g
    apply HasCompactSupport.intro hbase
    intro v hv
    have hz : logLift g.1 v = 0 := image_eq_zero_of_notMem_tsupport hv
    simp [hz]
  exact hc.integrable_of_hasCompactSupport hk

theorem shifted_logLift_sq_integrable_v25
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    Integrable (fun v : ℝ => ‖logLift g.1 (v + u)‖ ^ 2) := by
  have hc : Continuous (fun v : ℝ => ‖logLift g.1 (v + u)‖ ^ 2) := by
    exact ((logLift_continuous_v25 g).comp (by fun_prop)).norm.pow 2
  let K : Set ℝ := (fun t : ℝ => t - u) '' tsupport (logLift g.1)
  have hK : IsCompact K :=
    (logLift_hasCompactSupport_v25 g).image (by fun_prop)
  have hk : HasCompactSupport (fun v : ℝ => ‖logLift g.1 (v + u)‖ ^ 2) := by
    apply HasCompactSupport.of_support_subset_isCompact hK
    intro v hv
    have hne : logLift g.1 (v + u) ≠ 0 := by
      intro hz
      apply hv
      simp [hz]
    have hm : v + u ∈ tsupport (logLift g.1) := subset_tsupport _ hne
    refine ⟨v + u, hm, ?_⟩
    ring
  exact hc.integrable_of_hasCompactSupport hk

theorem shifted_logLift_sq_integral_v25
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    (∫ v : ℝ, ‖logLift g.1 (v + u)‖ ^ 2) = energy g.1 := by
  calc
    (∫ v : ℝ, ‖logLift g.1 (v + u)‖ ^ 2)
        = ∫ v : ℝ, ‖logLift g.1 v‖ ^ 2 := by
            simpa using
              (integral_add_right_eq_self
                (fun v : ℝ => ‖logLift g.1 v‖ ^ 2) u)
    _ = energy g.1 := logLift_energy_eq_packet_energy g

theorem logCorrelation_integrable_v25
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    Integrable
      (fun v : ℝ => logLift g.1 (v + u) * conj (logLift g.1 v)) := by
  let M : ℝ → ℝ := fun v =>
    (1 / 2 : ℝ) *
      (‖logLift g.1 (v + u)‖ ^ 2 + ‖logLift g.1 v‖ ^ 2)
  have hM : Integrable M := by
    unfold M
    exact
      ((shifted_logLift_sq_integrable_v25 g u).add
        (logLift_sq_integrable_v25 g)).const_mul (1 / 2 : ℝ)
  have hmeas :
      AEStronglyMeasurable
        (fun v : ℝ => logLift g.1 (v + u) * conj (logLift g.1 v)) := by
    exact
      ((logLift_continuous_v25 g).comp (by fun_prop)).aestronglyMeasurable.mul
        (continuous_conj.comp (logLift_continuous_v25 g)).aestronglyMeasurable
  refine hM.mono' hmeas (Filter.Eventually.of_forall fun v => ?_)
  have hab :
      ‖logLift g.1 (v + u)‖ * ‖logLift g.1 v‖ ≤
        (1 / 2 : ℝ) *
          (‖logLift g.1 (v + u)‖ ^ 2 + ‖logLift g.1 v‖ ^ 2) := by
    nlinarith [sq_nonneg (‖logLift g.1 (v + u)‖ - ‖logLift g.1 v‖)]
  simpa [M, norm_mul, norm_conj] using hab

/-- Exact multiplicative-to-additive autocorrelation identity. -/
theorem logCorrelation_eq_autocorrelation_v25
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    logCorrelationV25 g u =
      (Real.exp (u / 2) : ℂ) *
        WeilAutocorrelationV1 g (Real.exp u) := by
  unfold logCorrelationV25 WeilAutocorrelationV1
  rw [AEGIS.WeilThreeBlockTranslatedPacketsV22.integral_exp_substitution_complex]
  rw [← integral_const_mul]
  apply integral_congr_ae
  filter_upwards [] with v
  unfold logLift
  rw [Complex.star_def, map_mul]
  simp only [Complex.conj_ofReal, Complex.real_smul]
  have harg :
      Real.exp u * Real.exp v = Real.exp (v + u) := by
    rw [← Real.exp_add]
    congr 1
    ring
  rw [harg]
  have hscalar :
      (Real.exp (u / 2) : ℂ) * (Real.exp v : ℂ) =
        (Real.exp ((v + u) / 2) : ℂ) *
          (Real.exp (v / 2) : ℂ) := by
    norm_cast
    rw [← Real.exp_add, ← Real.exp_add]
    congr 1
    ring
  calc
    (Real.exp ((v + u) / 2) : ℂ) * g.1 (Real.exp (v + u)) *
        ((Real.exp (v / 2) : ℂ) * conj (g.1 (Real.exp v)))
        =
      ((Real.exp ((v + u) / 2) : ℂ) *
          (Real.exp (v / 2) : ℂ)) *
        (g.1 (Real.exp (v + u)) * conj (g.1 (Real.exp v))) := by ring
    _ =
      ((Real.exp (u / 2) : ℂ) * (Real.exp v : ℂ)) *
        (g.1 (Real.exp (v + u)) * conj (g.1 (Real.exp v))) := by
          rw [← hscalar]
    _ =
      (Real.exp (u / 2) : ℂ) *
        ((Real.exp v : ℂ) *
          (g.1 (Real.exp (v + u)) * conj (g.1 (Real.exp v)))) := by ring

/-- The L2 autocorrelation is bounded by the packet energy.  This uses only
2ab <= a^2+b^2, avoiding any additional Hilbert-space API. -/
theorem norm_logCorrelation_le_energy_v25
    (g : WeilCompactSmoothGV1) (u : ℝ) :
    ‖logCorrelationV25 g u‖ ≤ energy g.1 := by
  let q : ℝ → ℂ := fun v =>
    logLift g.1 (v + u) * conj (logLift g.1 v)
  let M : ℝ → ℝ := fun v =>
    (1 / 2 : ℝ) *
      (‖logLift g.1 (v + u)‖ ^ 2 + ‖logLift g.1 v‖ ^ 2)
  have hq : Integrable q := by
    simpa [q] using logCorrelation_integrable_v25 g u
  have hM : Integrable M := by
    unfold M
    exact
      ((shifted_logLift_sq_integrable_v25 g u).add
        (logLift_sq_integrable_v25 g)).const_mul (1 / 2 : ℝ)
  have hpoint : ∀ v : ℝ, ‖q v‖ ≤ M v := by
    intro v
    have hab :
        ‖logLift g.1 (v + u)‖ * ‖logLift g.1 v‖ ≤
          (1 / 2 : ℝ) *
            (‖logLift g.1 (v + u)‖ ^ 2 + ‖logLift g.1 v‖ ^ 2) := by
      nlinarith [sq_nonneg (‖logLift g.1 (v + u)‖ - ‖logLift g.1 v‖)]
    simpa [q, M, norm_mul, norm_conj] using hab
  calc
    ‖logCorrelationV25 g u‖
        = ‖∫ v : ℝ, q v‖ := by rfl
    _ ≤ ∫ v : ℝ, ‖q v‖ := norm_integral_le_integral_norm _
    _ ≤ ∫ v : ℝ, M v := by
      exact integral_mono hq.norm hM hpoint
    _ = (1 / 2 : ℝ) *
        ((∫ v : ℝ, ‖logLift g.1 (v + u)‖ ^ 2) +
          ∫ v : ℝ, ‖logLift g.1 v‖ ^ 2) := by
      unfold M
      rw [integral_const_mul, integral_add
        (shifted_logLift_sq_integrable_v25 g u)
        (logLift_sq_integrable_v25 g)]
    _ = energy g.1 := by
      rw [shifted_logLift_sq_integral_v25,
        logLift_energy_eq_packet_energy]
      ring

/-- Width-1/32 support makes the additive autocorrelation vanish strictly
outside the difference-support interval. -/
theorem logCorrelation_zero_of_width_v25
    (g : WeilCompactSmoothGV1) (a u : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (hu : (1 / 32 : ℝ) < u) :
    logCorrelationV25 g u = 0 := by
  unfold logCorrelationV25
  apply integral_eq_zero_of_ae
  filter_upwards [] with v
  by_cases h0 : logLift g.1 v = 0
  · simp [h0]
  · by_cases h1 : logLift g.1 (v + u) = 0
    · simp [h1]
    · have hm0 : v ∈ tsupport (logLift g.1) := subset_tsupport _ h0
      have hm1 : v + u ∈ tsupport (logLift g.1) := subset_tsupport _ h1
      have hv := hw hm0
      have hvu := hw hm1
      exfalso
      linarith [hv.1, hv.2, hvu.1, hvu.2, hu]

end AEGIS.WeilWidthArchCorrelationV25

#print axioms AEGIS.WeilWidthArchCorrelationV25.logLift_sq_integrable_v25
#print axioms AEGIS.WeilWidthArchCorrelationV25.logCorrelation_eq_autocorrelation_v25
#print axioms AEGIS.WeilWidthArchCorrelationV25.norm_logCorrelation_le_energy_v25
#print axioms AEGIS.WeilWidthArchCorrelationV25.logCorrelation_zero_of_width_v25
~~~~~~

## WeilWidthDiagonalArchFrontierV24

Path: `source/WeilWidthDiagonalArchFrontierV24.lean`

Original source lines: 1–76

Full file SHA256: `c0628419fb4a768335a059e6de29a38bd19e257b846d13bffdbf72f39b0f44d5`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilWidthDiagonalArchFrontierV24.lean

~~~~~~lean
import WeilDiagonalKernelReductionV21
import WeilWidthPrimeVanishingV23
import WeilArchimedeanCothTailV1

/-!
AEGIS Ω — width-1/32 diagonal Archimedean frontier V2.4.

This module composes three already separately verified pieces:
1. exact width-1/32 diagonal prime-sum vanishing;
2. the symbolic actual-repository diagonal reduction;
3. the explicit coth-tail theorem at w = 1/32.

The result discharges the discrete prime term and the tail threshold in the
103/100 diagonal estimate.  Exactly one analytic premise remains: the
Archimedean integral budget identifying the actual repository Archimedean
kernel with the small-minus-tail bound.

No off-diagonal bound, universal sign, global Weil positivity, or RH result is
asserted here.
-/

open Set MeasureTheory Complex
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilWidthDiagonalArchFrontierV24

open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilMixedAlgebraV2
open AEGIS.WeilDiagonalKernelReductionV21
open AEGIS.WeilWidthPrimeVanishingV23
open AEGIS.WeilThreeBlockTranslatedPacketsV22
open AEGIS.WeilArchimedeanCothTailV1

/-- The exact width-1/32 Archimedean tail used by the retained diagonal
certificate. -/
def diagonalTailV24 : ℝ :=
  ∫ u in Ioi (1 / 32 : ℝ), 1 / Real.sinh u

/-- The coth-tail theorem discharges the retained certificate threshold. -/
theorem diagonal_tail_gt_six_log_two_v24 :
    6 * Real.log 2 < diagonalTailV24 := by
  simpa [diagonalTailV24] using
    AEGIS.WeilArchimedeanCothTailV1.six_log_two_lt_integral_one_div_sinh_Ioi

/-- Width support discharges the entire diagonal prime contribution. -/
theorem width_diagonal_prime_sum_zero_v24
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a) :
    WeilPrimeSumV1 (WeilAutocorrelationV1 g) = 0 :=
  AEGIS.WeilWidthPrimeVanishingV23.diagonal_prime_sum_zero g a hw

/-- The exact load-bearing diagonal frontier.

After the already verified prime and coth-tail transitions are composed, the
103/100 coercive diagonal estimate follows from one and only one remaining
analytic statement: the actual Archimedean integral budget below. -/
theorem width_diagonal_103_over_100_of_arch_budget_v24
    (g : WeilCompactSmoothGV1) (a : ℝ)
    (hw : WidthOneThirtyTwoAt g a)
    (harch :
      (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re ≤
        energy g.1 * (diagonalSmallV21 - diagonalTailV24)) :
    (103 / 100 : ℝ) * energy g.1 ≤ -(B g g).re := by
  exact
    actual_diagonal_103_over_100
      g diagonalTailV24
      (width_diagonal_prime_sum_zero_v24 g a hw)
      (le_of_lt diagonal_tail_gt_six_log_two_v24)
      harch

end AEGIS.WeilWidthDiagonalArchFrontierV24

#print axioms AEGIS.WeilWidthDiagonalArchFrontierV24.diagonal_tail_gt_six_log_two_v24
#print axioms AEGIS.WeilWidthDiagonalArchFrontierV24.width_diagonal_prime_sum_zero_v24
#print axioms AEGIS.WeilWidthDiagonalArchFrontierV24.width_diagonal_103_over_100_of_arch_budget_v24
~~~~~~

## WeilDiagonalKernelReductionV21

Path: `source/WeilDiagonalKernelReductionV21.lean`

Original source lines: 1–131

Full file SHA256: `99cbe5c671c174ecd798ea5f10b7ef6a3870f23f8782c3cb28fad0f5e92bfe0b`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilDiagonalKernelReductionV21.lean

~~~~~~lean
import WeilMixedAlgebraV2
import WeilLogCoordinateIsometryV21
import WeilThreeBlockAnalyticConstantsV21

/-!
AEGIS Ω — width-1/32 diagonal symbolic reduction V2.1

FORMAL_MATH_EVIDENCE_ONLY.

This module binds the diagonal bookkeeping to the ACTUAL repository mixed form
`B`, without dividing by the packet energy.  It deliberately leaves the hard
continuous analysis as explicit hypotheses.

It does NOT prove:
* diagonal prime-sum vanishing for a width-1/32 packet;
* the Archimedean kernel integral inequality;
* the coth/tail lower bound;
* the six actual B-bounds;
* global Weil sign or RH.
-/

open Set Function MeasureTheory Complex
open scoped ComplexConjugate
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilDiagonalKernelReductionV21

open AEGIS.WeilMixedClosureV2
open AEGIS.WeilMixedAlgebraV2
open AEGIS.WeilDisjointEnergyV2
open AEGIS.WeilLogCoordinateIsometryV21
open AEGIS.WeilThreeBlockAnalyticConstantsV21

def diagonalKappaV21 : ℝ :=
  Real.log (4 * Real.pi) + Real.eulerMascheroniConstant

def diagonalSmallV21 : ℝ :=
  ((1 : ℝ) / 64) * Real.exp ((1 : ℝ) / 64)

/-- At the identity, the real part of the repository autocorrelation is exactly
its ordinary Lebesgue L2 energy. -/
theorem autocorrelation_one_re_eq_energy
    (g : WeilCompactSmoothGV1) :
    (WeilAutocorrelationV1 g 1).re = energy g.1 := by
  have hint :
      IntegrableOn (fun y : ℝ => g.1 y * star (g.1 y)) (Ioi 0) := by
    simpa only [one_mul] using
      (weil_autocorrelation_integrand_integrable_v1 g 1)
  rw [packet_energy_eq_positive_energy g]
  unfold WeilAutocorrelationV1
  simp only [one_mul]
  rw [← RCLike.re_eq_complex_re]
  rw [← integral_re hint]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro y hy
  calc
    (g.1 y * star (g.1 y)).re = Complex.normSq (g.1 y) := by
      have hmul := congrArg Complex.re (Complex.mul_conj (g.1 y))
      simpa only [Complex.star_def, Complex.ofReal_re] using hmul
    _ = ‖g.1 y‖ ^ 2 := Complex.normSq_eq_norm_sq (g.1 y)

/-- If the diagonal prime part vanishes, the real part of the ACTUAL repository
mixed form is kappa times the actual packet energy plus the real Archimedean
integral. -/
theorem actual_diagonal_rhs_decomposition
    (g : WeilCompactSmoothGV1)
    (hprime : WeilPrimeSumV1 (WeilAutocorrelationV1 g) = 0) :
    (B g g).re =
      diagonalKappaV21 * energy g.1 +
        (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re := by
  unfold B
  rw [diagonal_eq]
  unfold WeilExplicitRightSideV1
  rw [hprime]
  have hcenter := autocorrelation_one_re_eq_energy g
  simp only [zero_add, Complex.add_re]
  unfold WeilArchimedeanConstantV1 diagonalKappaV21
  simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
  rw [hcenter]

/-- Pure quotient-free reduction.  The difficult continuous estimate is kept
as one explicit Archimedean premise. -/
theorem actual_diagonal_from_arch_budget
    (g : WeilCompactSmoothGV1)
    (tail small : ℝ)
    (hprime : WeilPrimeSumV1 (WeilAutocorrelationV1 g) = 0)
    (harch :
      (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re ≤
        energy g.1 * (small - tail)) :
    energy g.1 * (tail - diagonalKappaV21 - small) ≤ -(B g g).re := by
  rw [actual_diagonal_rhs_decomposition g hprime]
  nlinarith

/-- Once the width-1/32 tail dominates `6 log 2`, the already kernel-verified
constant layer converts the symbolic analytic budget into the exact diagonal
hypothesis consumed by `actual_three_block_bound`. -/
theorem actual_diagonal_103_over_100
    (g : WeilCompactSmoothGV1)
    (tail : ℝ)
    (hprime : WeilPrimeSumV1 (WeilAutocorrelationV1 g) = 0)
    (htail : 6 * Real.log 2 ≤ tail)
    (harch :
      (WeilArchimedeanIntegralV1 (WeilAutocorrelationV1 g)).re ≤
        energy g.1 * (diagonalSmallV21 - tail)) :
    (103 / 100 : ℝ) * energy g.1 ≤ -(B g g).re := by
  have hE : 0 ≤ energy g.1 := energy_nonnegative g.1
  have hbase :
      (103 / 100 : ℝ) <
        6 * Real.log 2 - diagonalKappaV21 - diagonalSmallV21 := by
    unfold diagonalKappaV21 diagonalSmallV21
    nlinarith [certificate_diagonal_threshold, diagonal_constant_floor]
  have hshift :
      6 * Real.log 2 - diagonalKappaV21 - diagonalSmallV21 ≤
        tail - diagonalKappaV21 - diagonalSmallV21 := by
    linarith
  have hconst := mul_le_mul_of_nonneg_left hbase.le hE
  have htailmul := mul_le_mul_of_nonneg_left hshift hE
  have hanalytic :=
    actual_diagonal_from_arch_budget
      g tail diagonalSmallV21 hprime harch
  calc
    (103 / 100 : ℝ) * energy g.1
        = energy g.1 * (103 / 100 : ℝ) := by ring
    _ ≤ energy g.1 *
          (6 * Real.log 2 - diagonalKappaV21 - diagonalSmallV21) := hconst
    _ ≤ energy g.1 *
          (tail - diagonalKappaV21 - diagonalSmallV21) := htailmul
    _ ≤ -(B g g).re := hanalytic

end AEGIS.WeilDiagonalKernelReductionV21
~~~~~~

## WeilMixedAlgebraV2

Path: `source/WeilMixedAlgebraV2.lean`

Original source lines: 1–254

Full file SHA256: `6259d769cb0f529f62a4ed8fa8446e256883bbb0464976436e921bd40be37c00`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilMixedAlgebraV2.lean

~~~~~~lean
import WeilMixedClosureV2
import WeilThreeBlockComplexV2

/-!
Linearity and Hermitian symmetry of the ACTUAL repository arithmetic RHS.
The final theorem derives the V2 coefficient application from six explicitly
stated analytic bounds. Those six bounds are not proved by this module.
No logarithmic change of variables, global positivity, or RH is asserted.
-/
open Set Function MeasureTheory Complex
open scoped ContDiff ComplexConjugate
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilMixedAlgebraV2
open AEGIS.WeilMixedClosureV2 AEGIS.WeilThreeBlockComplexV2

theorem sum_support (a b : WeilCompactSmoothGV1) :
    tsupport (fun t => a.1 t + b.1 t) ⊆ tsupport a.1 ∪ tsupport b.1 := by
  apply closure_minimal ?_ ((isClosed_tsupport _).union (isClosed_tsupport _))
  intro t ht
  by_cases ha : t ∈ tsupport a.1
  · exact Or.inl ha
  · right
    by_contra hb
    exact ht (by simp [image_eq_zero_of_notMem_tsupport ha,
      image_eq_zero_of_notMem_tsupport hb])

def addPacket (a b : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  ⟨fun t => a.1 t + b.1 t, a.2.1.add b.2.1,
    (a.2.2.1.union b.2.2.1).of_isClosed_subset (isClosed_tsupport _) (sum_support a b),
    fun x hx =>
      (sum_support a b hx).elim
        (fun ha => a.2.2.2 ha)
        (fun hb => b.2.2.2 hb)⟩

theorem scale_support (z : ℂ) (a : WeilCompactSmoothGV1) :
    tsupport (fun t => z * a.1 t) ⊆ tsupport a.1 := by
  apply closure_minimal ?_ (isClosed_tsupport _)
  intro t ht
  by_contra ha
  exact ht (by simp [image_eq_zero_of_notMem_tsupport ha])

def scalePacket (z : ℂ) (a : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  ⟨fun t => z * a.1 t, contDiff_const.mul a.2.1,
    a.2.2.1.of_isClosed_subset (isClosed_tsupport _) (scale_support z a),
    (scale_support z a).trans a.2.2.2⟩

theorem mixed_add_left (a b c : WeilCompactSmoothGV1) :
    mixed (addPacket a b) c = fun x => mixed a c x + mixed b c x := by
  funext x
  change (∫ y in Ioi (0 : ℝ), (a.1 (x*y) + b.1 (x*y)) * star (c.1 y)) = _
  simp_rw [add_mul]
  exact integral_add (integrand_integrable a c x) (integrand_integrable b c x)

theorem mixed_add_right (a b c : WeilCompactSmoothGV1) :
    mixed a (addPacket b c) = fun x => mixed a b x + mixed a c x := by
  funext x
  change (∫ y in Ioi (0 : ℝ), a.1 (x*y) * star (b.1 y + c.1 y)) = _
  simp_rw [star_add, mul_add]
  exact integral_add (integrand_integrable a b x) (integrand_integrable a c x)

theorem mixed_scale_left (z : ℂ) (a b : WeilCompactSmoothGV1) :
    mixed (scalePacket z a) b = fun x => z * mixed a b x := by
  funext x
  change (∫ y in Ioi (0 : ℝ), (z * a.1 (x*y)) * star (b.1 y)) = _
  simp_rw [mul_assoc]
  exact integral_const_mul z _

theorem mixed_scale_right (z : ℂ) (a b : WeilCompactSmoothGV1) :
    mixed a (scalePacket z b) = fun x => star z * mixed a b x := by
  funext x
  change (∫ y in Ioi (0 : ℝ), a.1 (x*y) * star (z * b.1 y)) = _
  have hp : (fun y : ℝ => a.1 (x*y) * star (z * b.1 y)) =
      fun y => star z * (a.1 (x*y) * star (b.1 y)) := by
    funext y
    simp only [star_mul]
    ring
  rw [hp]
  exact integral_const_mul (star z) _

theorem prime_add (f g : ℝ → ℂ) :
    WeilPrimeTermV1 (fun x => f x + g x) =
      fun n => WeilPrimeTermV1 f n + WeilPrimeTermV1 g n := by
  funext n
  dsimp [WeilPrimeTermV1]
  ring

theorem arch_add (f g : ℝ → ℂ) :
    WeilArchimedeanIntegrandV1 (fun x => f x + g x) =
      fun x => WeilArchimedeanIntegrandV1 f x + WeilArchimedeanIntegrandV1 g x := by
  funext x
  dsimp [WeilArchimedeanIntegrandV1]
  ring

theorem prime_scale (z : ℂ) (f : ℝ → ℂ) :
    WeilPrimeTermV1 (fun x => z * f x) = fun n => z * WeilPrimeTermV1 f n := by
  funext n
  dsimp [WeilPrimeTermV1]
  ring

theorem arch_scale (z : ℂ) (f : ℝ → ℂ) :
    WeilArchimedeanIntegrandV1 (fun x => z * f x) =
      fun x => z * WeilArchimedeanIntegrandV1 f x := by
  funext x
  dsimp [WeilArchimedeanIntegrandV1]
  ring

/-- Additivity is used only with the actual convergence premises. -/
theorem rhs_add (f g : ℝ → ℂ)
    (hf : WeilExplicitRightSideConvergentV1 f)
    (hg : WeilExplicitRightSideConvergentV1 g) :
    WeilExplicitRightSideV1 (fun x => f x + g x) =
      WeilExplicitRightSideV1 f + WeilExplicitRightSideV1 g := by
  unfold WeilExplicitRightSideV1 WeilPrimeSumV1 WeilArchimedeanIntegralV1
  rw [prime_add, arch_add, hf.1.tsum_add hg.1, integral_add hf.2 hg.2]
  dsimp
  ring

theorem rhs_scale (z : ℂ) (f : ℝ → ℂ) :
    WeilExplicitRightSideV1 (fun x => z * f x) = z * WeilExplicitRightSideV1 f := by
  unfold WeilExplicitRightSideV1 WeilPrimeSumV1 WeilArchimedeanIntegralV1
  rw [prime_scale, arch_scale, tsum_mul_left, integral_const_mul]
  dsimp
  ring

def B (a b : WeilCompactSmoothGV1) : ℂ := WeilExplicitRightSideV1 (mixed a b)

theorem B_add_left (a b c : WeilCompactSmoothGV1) :
    B (addPacket a b) c = B a c + B b c := by
  unfold B
  rw [mixed_add_left]
  exact rhs_add _ _ (rhs_convergent a c) (rhs_convergent b c)

theorem B_add_right (a b c : WeilCompactSmoothGV1) :
    B a (addPacket b c) = B a b + B a c := by
  unfold B
  rw [mixed_add_right]
  exact rhs_add _ _ (rhs_convergent a b) (rhs_convergent a c)

theorem B_scale_left (z : ℂ) (a b : WeilCompactSmoothGV1) :
    B (scalePacket z a) b = z * B a b := by
  unfold B
  rw [mixed_scale_left, rhs_scale]

theorem B_scale_right (z : ℂ) (a b : WeilCompactSmoothGV1) :
    B a (scalePacket z b) = star z * B a b := by
  unfold B
  rw [mixed_scale_right, rhs_scale]

theorem reflected (f g : ℝ → ℂ)
    (h : ∀ x : ℝ, 0 < x → f x⁻¹ = (x : ℂ) * conj (g x))
    {x : ℝ} (hx : 0 < x) : (1 / (x : ℂ)) * f x⁻¹ = conj (g x) := by
  rw [h x hx]
  have hxC : (x : ℂ) ≠ 0 := by exact_mod_cast hx.ne'
  simp [div_eq_mul_inv, ← mul_assoc, hxC]

theorem rhs_paired_conjugate (f g : ℝ → ℂ)
    (hfg : ∀ x : ℝ, 0 < x → f x⁻¹ = (x : ℂ) * conj (g x))
    (hgf : ∀ x : ℝ, 0 < x → g x⁻¹ = (x : ℂ) * conj (f x)) :
    WeilExplicitRightSideV1 g = conj (WeilExplicitRightSideV1 f) := by
  have h1 : g 1 = conj (f 1) := by simpa using hgf 1 zero_lt_one
  have hp : WeilPrimeSumV1 g = conj (WeilPrimeSumV1 f) := by
    change (∑' n : ℕ, WeilPrimeTermV1 g n) = star (∑' n : ℕ, WeilPrimeTermV1 f n)
    rw [tsum_star]
    apply tsum_congr
    intro n
    have hn : (0 : ℝ) < (n + 1 : ℕ) := by positivity
    have hfx : (1 / ((n + 1 : ℕ) : ℂ)) * f (((n + 1 : ℕ) : ℝ)⁻¹) =
        conj (g ((n + 1 : ℕ) : ℝ)) := by
      simpa only [Complex.ofReal_natCast] using reflected f g hfg hn
    have hgx : (1 / ((n + 1 : ℕ) : ℂ)) * g (((n + 1 : ℕ) : ℝ)⁻¹) =
        conj (f ((n + 1 : ℕ) : ℝ)) := by
      simpa only [Complex.ofReal_natCast] using reflected g f hgf hn
    simp only [WeilPrimeTermV1]
    rw [hfx, hgx]
    simp [Complex.star_def, add_comm]
  have ha : WeilArchimedeanIntegralV1 g = conj (WeilArchimedeanIntegralV1 f) := by
    unfold WeilArchimedeanIntegralV1
    rw [← integral_conj]
    apply setIntegral_congr_fun measurableSet_Ioi
    intro x hx
    change WeilArchimedeanIntegrandV1 g x =
      conj (WeilArchimedeanIntegrandV1 f x)
    unfold WeilArchimedeanIntegrandV1
    have hx0 : 0 < x := lt_trans zero_lt_one hx
    have hfx := reflected f g hfg hx0
    have hgx := reflected g f hgf hx0
    have hxC : (x : ℂ) ≠ 0 := by
      exact_mod_cast hx0.ne'
    rw [hgx, hfx, h1]
    simp [div_eq_mul_inv, add_comm, Complex.conj_ofNat]
  simp only [WeilExplicitRightSideV1, hp, ha, h1, map_add, map_mul,
    WeilArchimedeanConstantV1, Complex.conj_ofReal]

theorem B_hermitian (a b : WeilCompactSmoothGV1) : B b a = conj (B a b) := by
  apply rhs_paired_conjugate
  · intro x hx
    exact reciprocal a b hx
  · intro x hx
    exact reciprocal b a hx

def combo (z0 z1 z2 : ℂ) (g0 g1 g2 : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  addPacket (addPacket (scalePacket z0 g0) (scalePacket z1 g1)) (scalePacket z2 g2)

/-- The exact complex coefficient expansion, with the correct conjugation and factor 2. -/
theorem actual_expansion (z0 z1 z2 : ℂ) (g0 g1 g2 : WeilCompactSmoothGV1) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 (combo z0 z1 z2 g0 g1 g2))).re =
      -AEGIS.WeilThreeBlockComplexV2.diagonal z0 z1 z2
          (-(B g0 g0).re) (-(B g1 g1).re) (-(B g2 g2).re) +
        AEGIS.WeilThreeBlockComplexV2.cross z0 z1 z2
          (B g0 g1) (B g0 g2) (B g1 g2) := by
  change (B (combo z0 z1 z2 g0 g1 g2) (combo z0 z1 z2 g0 g1 g2)).re = _
  unfold combo
  simp only [B_add_left, B_add_right, B_scale_left, B_scale_right]
  rw [B_hermitian g0 g1, B_hermitian g0 g2, B_hermitian g1 g2]
  have h00im : (B g0 g0).im = 0 := by
    have h := congrArg Complex.im (B_hermitian g0 g0)
    simp only [Complex.conj_im] at h
    linarith
  have h11im : (B g1 g1).im = 0 := by
    have h := congrArg Complex.im (B_hermitian g1 g1)
    simp only [Complex.conj_im] at h
    linarith
  have h22im : (B g2 g2).im = 0 := by
    have h := congrArg Complex.im (B_hermitian g2 g2)
    simp only [Complex.conj_im] at h
    linarith
  unfold AEGIS.WeilThreeBlockComplexV2.diagonal AEGIS.WeilThreeBlockComplexV2.cross
  simp only [Complex.star_def, Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im,
    Complex.conj_re, Complex.conj_im, Complex.sq_norm, Complex.normSq_apply,
    h00im, h11im, h22im]
  ring

theorem actual_three_block_bound (z0 z1 z2 : ℂ) (g0 g1 g2 : WeilCompactSmoothGV1)
    (r0 r1 r2 : ℝ)
    (h0 : (103 / 100 : ℝ) * r0 ^ 2 ≤ -(B g0 g0).re)
    (h1 : (103 / 100 : ℝ) * r1 ^ 2 ≤ -(B g1 g1).re)
    (h2 : (103 / 100 : ℝ) * r2 ^ 2 ≤ -(B g2 g2).re)
    (h01 : ‖B g0 g1‖ ≤ (51 / 100 : ℝ) * r0 * r1)
    (h02 : ‖B g0 g2‖ ≤ (9 / 25 : ℝ) * r0 * r2)
    (h12 : ‖B g1 g2‖ ≤ (51 / 100 : ℝ) * r1 * r2) :
    (WeilExplicitRightSideV1 (WeilAutocorrelationV1 (combo z0 z1 z2 g0 g1 g2))).re ≤
      -(1 / 10 : ℝ) * weightedEnergy z0 z1 z2 r0 r1 r2 := by
  rw [actual_expansion]
  exact quotient_free_margin z0 z1 z2 (B g0 g1) (B g0 g2) (B g1 g2)
    r0 r1 r2 (-(B g0 g0).re) (-(B g1 g1).re) (-(B g2 g2).re)
    h0 h1 h2 h01 h02 h12

theorem actual_combo_convergent (z0 z1 z2 : ℂ) (g0 g1 g2 : WeilCompactSmoothGV1) :
    WeilExplicitRightSideConvergentV1
      (WeilAutocorrelationV1 (combo z0 z1 z2 g0 g1 g2)) :=
  weil_autocorrelation_explicit_right_side_convergent_v1 _

end AEGIS.WeilMixedAlgebraV2
~~~~~~

## WeilMixedClosureV2

Path: `source/WeilMixedClosureV2.lean`

Original source lines: 1–114

Full file SHA256: `def6148deca54152e9f6c8a4c0c3c489c4933a1dcca7b379db8e05cbac14eea5`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilMixedClosureV2.lean

~~~~~~lean
import WeilAutocorrelationClosureV1

/-!
Actual mixed multiplicative correlation, with the repository's dy normalization.
This closes support, smoothness, integral existence, and arithmetic convergence.
It does NOT prove the logarithmic kernel identity or any sign estimate.
-/
open Set Function MeasureTheory Complex
open scoped ContDiff Convolution ComplexConjugate
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilMixedClosureV2

def mixed (a b : WeilCompactSmoothGV1) (x : ℝ) : ℂ :=
  ∫ y in Ioi (0 : ℝ), a.1 (x * y) * star (b.1 y)

def envelope (a b : WeilCompactSmoothGV1) : Set ℝ :=
  (fun p : ℝ × ℝ => p.1 / p.2) '' (tsupport a.1 ×ˢ tsupport b.1)

theorem diagonal_eq (a : WeilCompactSmoothGV1) : mixed a a = WeilAutocorrelationV1 a := rfl

theorem envelope_compact (a b : WeilCompactSmoothGV1) : IsCompact (envelope a b) := by
  apply (a.2.2.1.prod b.2.2.1).image_of_continuousOn
  exact continuous_fst.continuousOn.div continuous_snd.continuousOn
    (fun p hp => ne_of_gt (b.2.2.2 hp.2))

theorem envelope_positive (a b : WeilCompactSmoothGV1) : envelope a b ⊆ Ioi 0 := by
  rintro x ⟨p, hp, rfl⟩
  change 0 < p.1 / p.2
  exact div_pos (show 0 < p.1 from a.2.2.2 hp.1)
    (show 0 < p.2 from b.2.2.2 hp.2)

theorem support_subset (a b : WeilCompactSmoothGV1) : tsupport (mixed a b) ⊆ envelope a b := by
  apply closure_minimal ?_ (envelope_compact a b).isClosed
  intro x hx
  by_contra hnot
  apply hx
  apply integral_eq_zero_of_ae
  filter_upwards [] with y
  by_cases hy : b.1 y = 0
  · simp [hy]
  · have hyK : y ∈ tsupport b.1 := subset_tsupport b.1 hy
    have hxy : a.1 (x * y) = 0 := by
      by_contra hxy
      apply hnot
      refine ⟨(x * y, y), ⟨subset_tsupport a.1 hxy, hyK⟩, ?_⟩
      exact mul_div_cancel_right₀ x (ne_of_gt (b.2.2.2 hyK))
    simp [hxy]

theorem compact_support (a b : WeilCompactSmoothGV1) : HasCompactSupport (mixed a b) :=
  (envelope_compact a b).of_isClosed_subset (isClosed_tsupport _) (support_subset a b)

theorem positive_support (a b : WeilCompactSmoothGV1) : tsupport (mixed a b) ⊆ Ioi 0 :=
  (support_subset a b).trans (envelope_positive a b)

theorem integrand_integrable (a b : WeilCompactSmoothGV1) (x : ℝ) :
    IntegrableOn (fun y : ℝ => a.1 (x * y) * star (b.1 y)) (Ioi 0) := by
  have hc : Continuous (fun y : ℝ => a.1 (x * y) * star (b.1 y)) :=
    (a.2.1.continuous.comp (continuous_const.mul continuous_id)).mul
      (continuous_star.comp b.2.1.continuous)
  have hk : HasCompactSupport (fun y : ℝ => a.1 (x * y) * star (b.1 y)) := by
    apply HasCompactSupport.intro b.2.2.1
    intro y hy
    simp [image_eq_zero_of_notMem_tsupport hy]
  exact (hc.integrable_of_hasCompactSupport hk).integrableOn

theorem smooth (a b : WeilCompactSmoothGV1) : ContDiff ℝ ∞ (mixed a b) := by
  let F : ℝ → ℝ → ℂ := fun p z => a.1 (p * (-z)) * conj (b.1 (-z))
  have hF : ContDiff ℝ ∞ (fun q : ℝ × ℝ => F q.1 q.2) :=
    (a.2.1.comp (contDiff_fst.mul contDiff_snd.neg)).mul
      (Complex.conjCLE.contDiff.comp (b.2.1.comp contDiff_snd.neg))
  have hsupport : ∀ p z : ℝ, p ∈ (univ : Set ℝ) →
      z ∉ (fun y : ℝ => -y) '' tsupport b.1 → F p z = 0 := by
    intro p z _ hz
    have hneg : -z ∉ tsupport b.1 := by
      intro h
      exact hz ⟨-z, h, neg_neg z⟩
    simp [F, image_eq_zero_of_notMem_tsupport hneg]
  have H := contDiffOn_convolution_right_with_param_comp
    (μ := volume.restrict (Ioi (0 : ℝ))) (ContinuousLinearMap.lsmul ℝ ℝ)
    (v := fun _ : ℝ => (0 : ℝ)) (n := (⊤ : ℕ∞)) contDiffOn_const
    isOpen_univ (b.2.2.1.image continuous_neg) hsupport
    (locallyIntegrable_const (μ := volume.restrict (Ioi (0 : ℝ))) (1 : ℝ))
    hF.contDiffOn
  rw [← contDiffOn_univ]
  change ContDiffOn ℝ ∞
    (fun x : ℝ => ∫ y in Ioi (0 : ℝ), a.1 (x * y) * star (b.1 y)) univ
  simpa only [convolution, F, zero_sub, neg_neg,
    ContinuousLinearMap.lsmul_apply, one_smul, Complex.star_def] using H

def asPacket (a b : WeilCompactSmoothGV1) : WeilCompactSmoothGV1 :=
  ⟨mixed a b, smooth a b, compact_support a b, positive_support a b⟩

theorem asPacket_coe (a b : WeilCompactSmoothGV1) : (asPacket a b).1 = mixed a b := rfl

theorem rhs_convergent (a b : WeilCompactSmoothGV1) :
    WeilExplicitRightSideConvergentV1 (mixed a b) :=
  weil_compact_smooth_explicit_right_side_convergent_v1 (asPacket a b)

/-- This is an identity for the actual mixed integral, not a new normalization. -/
theorem reciprocal (a b : WeilCompactSmoothGV1) {x : ℝ} (hx : 0 < x) :
    mixed a b x⁻¹ = (x : ℂ) * conj (mixed b a x) := by
  have hchange := integral_comp_mul_left_Ioi'
    (fun y : ℝ => a.1 (x⁻¹ * y) * conj (b.1 y)) 0 hx
  simp only [mul_zero, inv_mul_cancel_left₀ hx.ne'] at hchange
  have hconj : (∫ y in Ioi (0 : ℝ), a.1 y * conj (b.1 (x * y))) =
      conj (∫ y in Ioi (0 : ℝ), b.1 (x * y) * conj (a.1 y)) := by
    rw [← integral_conj]
    apply integral_congr_ae
    filter_upwards [] with y
    simp [mul_comm]
  simpa only [mixed, Complex.star_def, hconj, Complex.real_smul] using hchange.symm

end AEGIS.WeilMixedClosureV2
~~~~~~

## WeilThreeBlockComplexV2

Path: `source/WeilThreeBlockComplexV2.lean`

Original source lines: 1–90

Full file SHA256: `8d07d516aea197a4a0b122d273724bba895e441f5417dcb84135dd9d21a285cb`

Origin: https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/2c3d041b633147ec97c7ef753aa9d157a47bb9f5/sovereign-omega-v2/formal/bridges/lean/WeilThreeBlockComplexV2.lean

~~~~~~lean
import WeilThreeBlockRationalV1
import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic

/-!
Quotient-free complex coefficient lift of the checked rational certificate.
All diagonal and pairwise analytic estimates remain explicit hypotheses.
No nonzero block-norm assumption. No operator-norm or global Weil conclusion.
-/
open Complex
open scoped ComplexConjugate
set_option autoImplicit false
noncomputable section
namespace AEGIS.WeilThreeBlockComplexV2
open AEGIS.WeilThreeBlockRationalV1

def weightedEnergy (z0 z1 z2 : ℂ) (r0 r1 r2 : ℝ) : ℝ :=
  energy (‖z0‖ * r0) (‖z1‖ * r1) (‖z2‖ * r2)

def diagonal (z0 z1 z2 : ℂ) (d0 d1 d2 : ℝ) : ℝ :=
  ‖z0‖ ^ 2 * d0 + ‖z1‖ ^ 2 * d1 + ‖z2‖ ^ 2 * d2

def cross (z0 z1 z2 b01 b02 b12 : ℂ) : ℝ :=
  2 * (z0 * star z1 * b01 + z0 * star z2 * b02 + z1 * star z2 * b12).re

theorem energy_expansion (z0 z1 z2 : ℂ) (r0 r1 r2 : ℝ) :
    weightedEnergy z0 z1 z2 r0 r1 r2 =
      ‖z0‖ ^ 2 * r0 ^ 2 + ‖z1‖ ^ 2 * r1 ^ 2 + ‖z2‖ ^ 2 * r2 ^ 2 := by
  unfold weightedEnergy energy
  ring

theorem weighted_diagonal (z0 z1 z2 : ℂ) (r0 r1 r2 d0 d1 d2 : ℝ)
    (h0 : (103 / 100 : ℝ) * r0 ^ 2 ≤ d0)
    (h1 : (103 / 100 : ℝ) * r1 ^ 2 ≤ d1)
    (h2 : (103 / 100 : ℝ) * r2 ^ 2 ≤ d2) :
    (103 / 100 : ℝ) * weightedEnergy z0 z1 z2 r0 r1 r2 ≤
      diagonal z0 z1 z2 d0 d1 d2 := by
  have h0' := mul_le_mul_of_nonneg_left h0 (sq_nonneg ‖z0‖)
  have h1' := mul_le_mul_of_nonneg_left h1 (sq_nonneg ‖z1‖)
  have h2' := mul_le_mul_of_nonneg_left h2 (sq_nonneg ‖z2‖)
  rw [energy_expansion]
  unfold diagonal
  nlinarith

theorem weighted_pair (z w b : ℂ) (c r s : ℝ) (hb : ‖b‖ ≤ c * r * s) :
    (z * star w * b).re ≤ c * (‖z‖ * r) * (‖w‖ * s) := by
  calc
    (z * star w * b).re ≤ ‖z * star w * b‖ := Complex.re_le_norm _
    _ = (‖z‖ * ‖w‖) * ‖b‖ := by simp only [norm_mul, norm_star]
    _ ≤ (‖z‖ * ‖w‖) * (c * r * s) :=
      mul_le_mul_of_nonneg_left hb (mul_nonneg (norm_nonneg _) (norm_nonneg _))
    _ = c * (‖z‖ * r) * (‖w‖ * s) := by ring

theorem weighted_cross (z0 z1 z2 b01 b02 b12 : ℂ) (r0 r1 r2 : ℝ)
    (h01 : ‖b01‖ ≤ (51 / 100 : ℝ) * r0 * r1)
    (h02 : ‖b02‖ ≤ (9 / 25 : ℝ) * r0 * r2)
    (h12 : ‖b12‖ ≤ (51 / 100 : ℝ) * r1 * r2) :
    cross z0 z1 z2 b01 b02 b12 ≤
      offdiagMajorant (‖z0‖ * r0) (‖z1‖ * r1) (‖z2‖ * r2) := by
  have h01' := weighted_pair z0 z1 b01 (51/100) r0 r1 h01
  have h02' := weighted_pair z0 z2 b02 (9/25) r0 r2 h02
  have h12' := weighted_pair z1 z2 b12 (51/100) r1 r2 h12
  unfold cross offdiagMajorant
  simp only [Complex.add_re]
  linarith

theorem quotient_free_margin (z0 z1 z2 b01 b02 b12 : ℂ) (r0 r1 r2 d0 d1 d2 : ℝ)
    (h0 : (103 / 100 : ℝ) * r0 ^ 2 ≤ d0)
    (h1 : (103 / 100 : ℝ) * r1 ^ 2 ≤ d1)
    (h2 : (103 / 100 : ℝ) * r2 ^ 2 ≤ d2)
    (h01 : ‖b01‖ ≤ (51 / 100 : ℝ) * r0 * r1)
    (h02 : ‖b02‖ ≤ (9 / 25 : ℝ) * r0 * r2)
    (h12 : ‖b12‖ ≤ (51 / 100 : ℝ) * r1 * r2) :
    -diagonal z0 z1 z2 d0 d1 d2 + cross z0 z1 z2 b01 b02 b12 ≤
      -(1 / 10 : ℝ) * weightedEnergy z0 z1 z2 r0 r1 r2 := by
  exact finite_budget_margin (‖z0‖ * r0) (‖z1‖ * r1) (‖z2‖ * r2)
    (diagonal z0 z1 z2 d0 d1 d2) (cross z0 z1 z2 b01 b02 b12)
    (weighted_diagonal z0 z1 z2 r0 r1 r2 d0 d1 d2 h0 h1 h2)
    (weighted_cross z0 z1 z2 b01 b02 b12 r0 r1 r2 h01 h02 h12)

/-- Nonnegativity applies to arbitrary complex coefficients, including all zero. -/
theorem energy_nonnegative (z0 z1 z2 : ℂ) (r0 r1 r2 : ℝ) :
    0 ≤ weightedEnergy z0 z1 z2 r0 r1 r2 := energy_nonneg _ _ _

/-- A concrete negative control for dropping conjugation from a pair. -/
theorem conjugation_matters :
    ((Complex.I) * star (Complex.I) * (1 : ℂ)).re ≠
      ((Complex.I) * (Complex.I) * (1 : ℂ)).re := by norm_num

end AEGIS.WeilThreeBlockComplexV2
~~~~~~

