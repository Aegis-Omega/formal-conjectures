# AEGIS prenos u ChatGPT Spaces

Prenesen je rezultat za petnaestu ćeliju k1 zajedno sa 155 projektnih i provider Lean modula u potpunom lokalnom import lancu. Izvorni rezultat, exact-rational Python provjera, candidate visibility patch, ulazi, receipt i checkpoint sačuvani su u `research_packet/` i u originalnom RI ZIP-u.

## Sadržaj

| Putanja | Sadržaj |
|---|---|
| `source/` | 155 potrebnih modula u putanjama koje odgovaraju importima; originalne putanje lokalnog research izvora sačuvane su paralelno |
| `dependency_closure.json` | Import graf, tačna izvorna veza, Git blob i SHA256 za svaki modul |
| `MODULE_INDEX.md` | Indeks svih modula i čitljivih dijelova na Space stranici |
| `PINS.json` | Tačni repository commitovi, toolchain i Lake package pinovi te identitet ulaznih arhiva |
| `provenance/upstream/` | Nepromijenjeni pinovani izvornici preuzeti putem postojećeg GitHub konektora |
| `provenance/compatibility.patch` | Eksplicitna rekonstrukcija već dokumentovanih compatibility korekcija, odvojena od novog candidate patcha |
| `provenance/harness/` | Nepromijenjeni PR53 replay.py i bind_pr52.py; zahtijevaju svoje tačne checkoutove |
| `source/evidence-*` | Sačuvani dostupni tekstualni dokazi, logovi i replay upute; to nisu novi replay rezultati |

## Granice

Import graf nema neriješenih projektnih/provider modula. Biblioteke Mathlib, Batteries, Aesop, Qq, Plausible, ProofWidgets, ImportGraph i LeanSearchClient sačuvane su kao exact package pinovi u Lake manifestu. Njihov kompletan izvor, Lean izvršni programi i `.olean` cache nisu ugrađeni u ovaj paket. Potrebno je postojeće ili naknadno pripremljeno okruženje na tim pinovima za kompilaciju. Ovo je prenos izvora i istraživačkih rezultata, ne pun git checkout ili izvršeno deployment okruženje.

Dvije compatibility transformacije su vezane za pinovane upute: ExplicitCorrection compact-support redak iz PR53 replay.py i tri Factorization zamjene iz baseline provider workflowa. Izvorni blobovi su sačuvani, a izmijenjeni blobovi navedeni u import grafu. Candidate visibility patch iz RI rezultata ostaje odvojen i nije primijenjen na preneseni K0 modul.

Racionalno uključivanje intervala provjerava se bez mreže i bez dodatnih Python paketa:

```bash
python3 verify_transfer.py
python3 research_packet/check_existing_taylor_budget.py --input research_packet/source-input.json --reference-receipt research_packet/source-receipt.json --output /tmp/aegis-k1-result.json
```

Završni k1 Lean dokaz nije kompiliran ni axiom-auditiran u ovom prenosu. Sljedeća nezavršena obaveza je hat-sine error lemma i rational composition zatim kernel replay u Formal Verification, uz samo dopuštene standardne axiome propext, Classical.choice i Quot.sound. Formalna tvrdnja se ne izvodi iz uspješnog prenosa ili Python provjere.
