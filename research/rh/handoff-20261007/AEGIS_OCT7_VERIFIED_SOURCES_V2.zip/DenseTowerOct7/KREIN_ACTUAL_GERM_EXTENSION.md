# Global bounded positive extensions of an actual narrow zeta-kernel germ

7 October 2026. Ordinary mathematical argument, with the classical interval
extension theorem explicitly identified below. This is NOT an identity with
the full zero kernel, an RH proof, a new RH equivalence, or a new Lean replay.
The named opaque `detectingPacket` in `DenseFixedPacketSign` is not silently
replaced. We use the already constructed family of genuine narrow detectors.

## Precise theorem and reused actual inputs

Choose ONCE a nonzero genuine zeta-detecting packet g from the existing narrow
construction with logarithmic support in [-r,r], r=9/128. Both exponential
moments vanish and all actual nontrivial zero coefficients are nonzero.
This existence is an existing ordinary proof, PORT_PENDING; it is not assumed
from a numerical experiment or a new certificate predicate.

Let h(u)=exp(u/2)g(exp u), let K be its ACTUAL canonical translation zero
kernel, and let Q=K(0), a real number. Put

    r0=9/64, a=2(r0-r)=9/64, delta=1/10,
    H(x)=integral h(u)exp(ixu)du,
    mu_h(dx)=|H(x)|²dx/(2pi),
    R_h(t)=integral exp(ixt)mu_h(dx)
          =integral h(v)conj(h(v+t))dv.

The existing source `nine_over_64_coercive`, the full explicit formula and
the exact energy isometry jointly prove

    Q_zero(f)>=delta*energy(f)

for EVERY original legal compact smooth packet f of logarithmic half-width
at most r0. All coefficients, zero multiplicities, prime powers, Gamma/pole
and moment terms are retained in that reused result.

**New theorem.** There exist two different continuous positive-definite
functions F_+,F_- on the WHOLE real line, such that

    |F_+(t)|<=Q, |F_-(t)|<=Q             for EVERY real t,
    F_+(t)=F_-(t)=K(t)                  for EVERY |t|<a,
    F_+(T)-F_-(T)=delta*||h||_2²>0,      T=log2.

The actual K itself is NOT asserted to equal either extension globally.
In particular this supplies bounded positive extensions of an actual local
germ, not the boundedness of the actual kernel required by RH.

## Step 1: the residual is genuinely locally positive definite

Put J(t)=K(t)-delta R_h(t). The actual kernel is continuous and Hermitian
K(-t)=conj K(t); the Fourier correlation has the same properties. Thus J
has both properties without RH.

Take arbitrary finitely many shifts t_1,...,t_n with ALL pair differences
in (-a,a), and arbitrary complex coefficients c_1,...,c_n. Their total
range is less than a. The logarithmic lift of

    f=sum_j c_j T_(t_j)g

is sum_j c_j h(u-t_j), supported inside the one interval
[min_j t_j-r,max_j t_j+r]. Its half-width is

    r+(max_j t_j-min_j t_j)/2 < r+a/2=r0.

Every summand and hence f preserves both moments. The actual full Gram
expansion and the energy correlation give, in the SAME orientation,

    Q_zero(f)=sum_(i,j) c_j conj(c_i) K(t_j-t_i),
    energy(f)=sum_(i,j) c_j conj(c_i) R_h(t_j-t_i).

The energy sign convention matters: the plus Fourier H gives R_h(t)=C(-t),
not C(t), for C(t)=integral h(v+t)conj h(v)dv. The full actual coercivity
therefore gives

    sum_(i,j)c_j conj(c_i)J(t_j-t_i)>=0.

This checks local positive definiteness for EVERY finite coefficient vector,
not merely four phases or all 2-by-2 minors. Reversing both differences and
coefficient conjugations gives the usual positive-kernel convention. This
step has not used any global sign on the translation family.

## Step 2: interval extension, with its exact mathematical obligation

Use Krein's ONE-DIMENSIONAL interval extension theorem: a continuous complex
positive-definite function on an open interval (-a,a) extends to a continuous
positive-definite function on all of R. Local positive definiteness means
the finite Gram condition whenever every difference lies in that interval,
which is exactly what Step1 checked. No assertion about multidimensional
domains or arbitrary disconnected sets is used here.

The exact author-proof source read is P. E. T. Jorgensen and R. Niedzialomski,
*Extension of positive definite functions*, arXiv:1212.3047v3, Corollary7.9,
p.25. Its Definition(1), p.1, uses a function on Omega-Omega and arbitrary
finite points of Omega with complex coefficients. Here choose Omega=(0,a),
so Omega-Omega=(-a,a); choosing Omega=(-a,a) would double the required domain
and is NOT the application made. The proof uses the interval reflection and
complex conjugation to obtain a selfadjoint extension in the locally positive
kernel space. That operator construction does not identify zeta's full spectrum.
The PDF SHA256 is
1184604a8c330fd4fffc894b592458fdce636dcab10633c78acbc79f1112aede.
The source's Bochner theorem is Theorem3.3, p.10, with the same plus Fourier
convention. The original1940 Krein paper is bibliographically identified in
that source but is not claimed to have been fetched/read in this continuation.

By Bochner's theorem the extension is

    J_ext(t)=integral exp(ixt)nu(dx)

for a positive finite Borel measure nu, with
nu(R)=J(0)=Q-delta||h||_2²>=0. Neither interval extension nor Bochner
requires RH, analyticity, a unique measure, known zero locations, or a
coincidence with the actual prime/Gamma expression outside (-a,a).

Primary/exact source and independent hypothesis review are recorded in
KreinGermSource/ and KreinGermReview/. These are literature/ordinary proof
dependencies, not newly kernel-verified Lean declarations.

## Step 3: two explicit distinct extensions of the ACTUAL germ

Because h is compact smooth, its Fourier transform decays faster than any
fixed power, so mu_h is a finite positive measure with every polynomial
moment. Its correlation R_h is supported in [-2r,2r].

Fix T=log2, already one of the requested dense-group generators. The exact
elementary bound log2>1/2>9/32 gives T>2r+a=18/64. For completeness,
log2=integral_1^2 dx/x>integral_1^2 dx/2=1/2; no decimal approximation is
used. Define actual positive finite measures

    rho_+(dx)=nu(dx)+delta(1+cos(Tx))mu_h(dx),
    rho_-(dx)=nu(dx)+delta(1-cos(Tx))mu_h(dx).

Both densities 1+/-cos(Tx) are nonnegative. Since T>2r, correlation support
gives integral cos(Tx)mu_h(dx)=0. Thus both total masses are

    nu(R)+delta mu_h(R)=Q.

Their characteristic functions F_+,F_- are continuous positive definite
and have |F_+(t)|,|F_-(t)|<=Q for EVERY real t. Exact Fourier expansion yields

    F_+(t)=J_ext(t)+delta R_h(t)
             +(delta/2)[R_h(t+T)+R_h(t-T)],
    F_-(t)=J_ext(t)+delta R_h(t)
             -(delta/2)[R_h(t+T)+R_h(t-T)].

For |t|<a, both |t+T| and |t-T| exceed 2r. Hence the last bracket vanishes,
and J_ext(t)=J(t) from Step2 gives EXACTLY F_+(t)=F_-(t)=K(t) there.
At t=T, R_h(2T)=0 and R_h(0)=||h||_2², so

    F_+(T)-F_-(T)=delta||h||_2²>0.

The extensions already disagree at the very first dyadic generator log2.
Thus at least one cannot equal actual K globally, including on the requested
dense log2/log3 group.
We do not infer that neither does, or that K is unbounded. Under RH K can
itself be one bounded positive extension; this construction is compatible
with that possibility.

No interchange of an unbounded moment series is used in Step3. All Fourier
integrals are of finite measures, the cosine expansion is finite, and the
correlation support statement follows from disjoint supports. No moment
finiteness of nu is needed for this theorem.

## Why this does not complete the detecting-packet proof

The new theorem supplies actual bounded positive GLOBAL objects matching a
genuine zeta kernel on an entire interval, rather than hypothetical kernels
with only matching derivatives. It closes the construction part of this
particular positive-representation attempt. It also supplies an exact failure
of uniqueness: continuity, the whole local germ, every derivative there,
Hermitian structure, moments and global positive definiteness do not choose
one global extension.

The existing RH criterion uses the ACTUAL zero translation kernel for ALL
signed shifts in Zlog2+Zlog3. Substituting F_+ or F_- outside (-a,a) would
change the mathematical object; no such substitution was made. An independent
global prime/Gamma identification selecting the actual K is still required.
There is no new RH-equivalent premise above this construction, but there is
also no proved unconditional arrow from this construction to RH.

The actual narrow kernel is smooth but not real analytic at zero, by the
separately reviewed positive-moment/Carleman argument. Thus an analytic
identity principle cannot be imported to force the desired identification.
The Laplace resolvent's analyticity is in a DIFFERENT complex variable, not
an assertion that K(t) is analytic in t.

This is a failed GLOBAL IDENTIFICATION attempt with a surviving precise
unconditional local-to-global extension theorem, not an RH proof or a claim
that every operator/recursive route is impossible.
