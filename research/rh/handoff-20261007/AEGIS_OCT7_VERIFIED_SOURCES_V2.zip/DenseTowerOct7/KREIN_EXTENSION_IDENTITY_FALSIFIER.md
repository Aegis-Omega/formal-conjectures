# The constructed positive extensions cannot be the full actual zero kernel

7 October 2026. Complete ordinary falsification of a specific global
identification attempt. It reuses the same actual narrow detector and the
extensions from KREIN_ACTUAL_GERM_EXTENSION.md. No RH assumption is left in
either conclusion; no new RH equivalence or Lean replay is claimed.

## 1. Neither of those explicit positive extensions equals actual K globally

In the preceding construction, both F_+ and F_- are Fourier transforms of
positive finite measures

    rho_+ = nu+delta(1+cos(Tx))mu_h,
    rho_- = nu+delta(1-cos(Tx))mu_h,
    T=log2, delta=1/10,
    mu_h(dx)=|H(x)|²dx/(2pi), T>diam(supp h).

The new conclusion is stronger than mere nonuniqueness: NEITHER function
can equal the actual detecting kernel on ALL real translations.

Suppose, for contradiction, that F_epsilon(t)=K_g(t) for every real t, for
one of the signs epsilon. The proved bound |F_epsilon(t)|<=Q would give
`PacketKernelBoundV1 g`. The existing unconditional source theorem

    AEGIS.RHDetectingPacketCriterionV1.
        riemannHypothesis_of_detecting_bounded_kernel

applies to ANY actual compact smooth g whose coefficient is nonzero at every
actual nontrivial zero. That is exactly the reused narrow detector's
specification. Its only other premise is the bound just deduced from the
ASSUMED identification. Therefore RH follows inside this contradiction.
RH has not been assumed as an input to the final result.

Under the thus-deduced RH, every centered exponent is i gamma_rho with real
gamma_rho. The exact coefficient formula becomes

    a_rho=m_rho |M(g)(rho)|²>=0,

including the original multiplicities. The already proved norm-summability
gives the positive finite PURELY ATOMIC measure

    mu_Z=sum_rho a_rho delta_(gamma_rho),
    K_g(t)=integral exp(ixt)mu_Z(dx).

The actual zero carrier is countable, so S={gamma_rho} is countable and
mu_Z(R\S)=0. Fourier transforms of finite measures on R are injective; hence
the assumed equality of kernels implies rho_epsilon=mu_Z.

For completeness that injectivity needs no analytic continuation in t.
If a finite signed/complex measure sigma has zero Fourier transform for
all real t, Fourier inversion and Fubini give integral phi d sigma=0 for
every compact smooth phi: its Fourier transform decays faster than any
fixed power and is integrable, while sigma has finite variation.
Smooth compact tests are dense in continuous compact tests by mollification;
finite Borel measures on R are regular, so these equalities imply sigma=0.
Apply this to rho_epsilon-mu_Z.

But mu_h is absolutely continuous, and

    mu_epsilon=(1+epsilon cos(Tx))mu_h

is a positive absolutely continuous measure of total mass ||h||_2²>0.
The mass statement uses integral cos(Tx)mu_h=0 from correlation support,
not a numerical oscillation estimate. In particular mu_epsilon(S)=0.
Since nu is positive,

    rho_epsilon(R\S)>=delta*mu_epsilon(R\S)
                      =delta*||h||_2²>0,

contradicting mu_Z(R\S)=0. The contradiction discharges the assumed global
identification for each sign. Thus both constructed global bounded positive
extensions, despite matching the ENTIRE actual local germ, are different
mathematical objects from the actual full zero kernel.

This is not a counterexample to RH: if RH is true, K itself is a bounded
pure-point positive kernel, while the two artificially completed extensions
have an unavoidable positive absolutely continuous part. If RH is false,
the reused detecting-kernel theorem already rules out its boundedness.
The argument only rejects the specified extension construction as an exact
global representation.

## 2. No uniform positive energy floor on this detector's full cyclic orbit

There is a related exact obstruction to a proposed two-energy invariant.
For the SAME actual narrow detector, the following statement is FALSE:

    exists delta>0, for every finite real-shift/coefficient family,
      Q_zero(sum_j c_j T_(t_j)g)
        >=delta*energy(sum_j c_j T_(t_j)g).

The domain includes all finite complex coefficient vectors and all real
shifts. This rejects global STRICT coercivity, not global semidefinite
positivity, which remains the RH task.

The same strict-coercivity statement is false even if shifts are restricted
to the EXACT dense group Zlog2+Zlog3. For each fixed finite coefficient
vector, both full Gram values are finite sums of the continuous functions
K(t_j-t_i) and R_h(t_j-t_i). Independently approximating every real location
by points of that dense group extends a claimed nonnegative coercive defect
from the group to all real locations. This is a finite-dimensional continuity
argument with the same fixed g and delta; no dense function-span inference
or exchange of infinite sums is introduced.

Proof. Suppose such a delta exists. Taking every two-point combination with
the four phases gives nonnegative zero quadratics because energy>=0. The
already proved Hermitian four-phase bound then bounds actual K uniformly;
the existing detecting theorem deduces RH inside this contradiction.
Consequently mu_Z above is a positive finite pure-point measure and mu_h is
a positive finite absolutely continuous measure with mass ||h||²>0.

The exact full Gram and energy identities turn the supposed coercivity into
positive definiteness on R of

    J(t)=K_g(t)-delta R_h(t),

which is the Fourier transform of the FINITE SIGNED measure
sigma=mu_Z-delta mu_h. Bochner's theorem supplies a positive finite measure
with that same Fourier transform; finite-measure injectivity, proved above,
forces sigma itself to be positive. Yet

    sigma(R\S)=-delta||h||²<0,

a contradiction. QED.

Equivalently, for every delta>0 there is a finite actual legal translated
combination u of this one packet with Q_zero(u)<delta*energy(u). The proof
does not assert Q_zero(u)<0, which would be incompatible with RH. It does
not give a numerical witness or a kernel-verified port of the classical
Bochner/measure steps. The witness has positive energy, since a smooth
packet with zero energy is identically zero and has zero quadratic.
The locations can all be chosen in the exact log2/log3 group, by the preceding
continuity argument. Floors depending on the finite window or tower size,
and tending to zero, are NOT excluded. The target sign is semidefinite and
must not be silently strengthened to the false uniform positive floor.

## Source, implication direction and trust audit

The reused actual detecting theorem was read at fork PR42 head
ff5cd5d98399c9eeba059abe2e7b138d3d30aabe, path
AEGISOverlay/RHDetectingPacketCriterionV1.lean, blob
a3f44c834df57f6e6849eb0fb52b2d7db8e18a40. It quantifies over arbitrary g,
its explicit all-zero detection hypothesis, and `PacketKernelBoundV1 g`;
it does not require the opaque named detector or a supplied RH premise.
Those existing source bytes and historical kernel audit are preserved.

RH is used ONLY after it has been derived from a contradiction hypothesis,
and that hypothesis is discharged. Neither conclusion has RH, actual
global positivity, an unidentified certificate or a new axiom as an input.
The finite-measure uniqueness proof uses full Fourier equality, not local
germ equality; this distinction is the point of the counterexample.

The construction of the narrow detector and the ordinary classical measure
arguments remain PORT_PENDING. These new negative results are complete
ordinary arguments under the original proven analytic inputs, not a final
formal RH result or a claim that every positive representation is impossible.
