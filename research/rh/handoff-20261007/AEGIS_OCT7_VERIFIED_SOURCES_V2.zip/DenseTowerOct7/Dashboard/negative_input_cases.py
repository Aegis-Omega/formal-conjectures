"""Adversarial metadata tests; no source files or proof objects are changed."""
from pathlib import Path
import copy
import hashlib
import json
import sys
from check_dashboard import check

OUT=Path(__file__).resolve().parent
report=json.loads((OUT/'DASHBOARD.json').read_text())
index=json.loads((OUT/'EVIDENCE_INDEX.json').read_text())
cases=[]
for name in ['rh_true','altered_hash','missing_item','reordered_items','mixed_source_tuple']:
    a=copy.deepcopy(report)
    b=copy.deepcopy(index)
    if name=='rh_true':
        a['rh_proven']=True
    elif name=='altered_hash':
        b['records'][0]['sha256']='0'*64
    elif name=='missing_item':
        b['records'].pop(5)
    elif name=='reordered_items':
        b['records'][0],b['records'][1]=b['records'][1],b['records'][0]
    else:
        r=a['results'][0]
        r['source_url']=r['source_url'].replace(r['source_commit'],'0'*40)
    try:
        check(a,b)
    except ValueError as e:
        cases.append(dict(case=name,status='REJECTED',reason=str(e)))
    else:
        raise RuntimeError('Malformed input accepted: '+name)
result=dict(status='PASS_NEGATIVE_METADATA_CASES',optimized=bool(sys.flags.optimize),
    cases=cases,actual_source_files_altered=False,fresh_math_or_kernel_replay=False,
    checker_sha256=hashlib.sha256((OUT/'check_dashboard.py').read_bytes()).hexdigest(),
    report_sha256=hashlib.sha256((OUT/'DASHBOARD.json').read_bytes()).hexdigest())
mode='OPTIMIZED' if sys.flags.optimize else 'NORMAL'
(OUT/f'NEGATIVE_INPUT_CHECKS_{mode}_FINAL.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
