import WeilZeroTwoPointV11

/-!
Exact two-channel butterfly for the ACTUAL zero kernel, without positivity.
This identity exposes the mixed terms required by a recursive tower; it does
not produce any arithmetic sign or a Riemann-hypothesis proof.
-/

open Complex
open scoped BigOperators ComplexConjugate
set_option autoImplicit false
noncomputable section

namespace AEGIS.WeilTowerButterflyOct7

open AEGIS.WeilZeroTwoPointV11
open AEGIS.WeilZeroTranslationV11

theorem translation_factor_add
    (rho : RiemannNontrivialZeroIndexV2) (a b : ℝ) :
    WeilZeroTranslationFactorV11 rho a * WeilZeroTranslationFactorV11 rho b =
      WeilZeroTranslationFactorV11 rho (a + b) := by
  unfold WeilZeroTranslationFactorV11
  rw [← Complex.exp_add]
  congr 1
  push_cast
  ring

/-- Translating the two-point packet generates BOTH endpoint mixed kernels. -/
theorem twoPoint_translation_kernel
    (g : WeilCompactSmoothGV1) (a b : ℝ) (c : ℂ) :
    WeilZeroTranslationKernelV11 (WeilTwoPointTranslateV11 g a c) b =
      (1 + c * conj c) * WeilZeroTranslationKernelV11 g b +
        c * WeilZeroTranslationKernelV11 g (a + b) +
        conj c * WeilZeroTranslationKernelV11 g (b - a) := by
  have h0 := zero_translation_kernel_summable_v11 g b
  have h1 := zero_translation_kernel_summable_v11 g (a + b)
  have h2 := zero_translation_kernel_summable_v11 g (b - a)
  unfold WeilZeroTranslationKernelV11
  calc
    (∑' rho : RiemannNontrivialZeroIndexV2,
        WeilZeroCoefficientV11 (WeilTwoPointTranslateV11 g a c) rho *
          WeilZeroTranslationFactorV11 rho b) =
      ∑' rho : RiemannNontrivialZeroIndexV2,
        ((1 + c * conj c) *
            (WeilZeroCoefficientV11 g rho * WeilZeroTranslationFactorV11 rho b) +
          c * (WeilZeroCoefficientV11 g rho *
            WeilZeroTranslationFactorV11 rho (a + b)) +
          conj c * (WeilZeroCoefficientV11 g rho *
            WeilZeroTranslationFactorV11 rho (b - a))) := by
      apply tsum_congr
      intro rho
      rw [twoPoint_zero_summand_expansion_v11]
      rw [show b - a = -a + b by ring]
      rw [← translation_factor_add rho a b, ← translation_factor_add rho (-a) b]
      ring
    _ = _ := by
      rw [((h0.mul_left (1 + c * conj c)).add (h1.mul_left c)).tsum_add
        (h2.mul_left (conj c))]
      rw [(h0.mul_left (1 + c * conj c)).tsum_add (h1.mul_left c)]
      rw [h0.tsum_mul_left, h1.tsum_mul_left, h2.tsum_mul_left]

/-- Plus and minus eliminate the new endpoint terms only after adding outputs. -/
theorem plus_minus_kernel_sum
    (g : WeilCompactSmoothGV1) (a b : ℝ) :
    WeilZeroTranslationKernelV11 (WeilTwoPointTranslateV11 g a 1) b +
      WeilZeroTranslationKernelV11 (WeilTwoPointTranslateV11 g a (-1)) b =
        4 * WeilZeroTranslationKernelV11 g b := by
  rw [twoPoint_translation_kernel, twoPoint_translation_kernel]
  simp only [map_one, map_neg]
  ring

/-- Subtraction retains the sum of the first/last mixed terms. -/
theorem plus_minus_kernel_difference
    (g : WeilCompactSmoothGV1) (a b : ℝ) :
    WeilZeroTranslationKernelV11 (WeilTwoPointTranslateV11 g a 1) b -
      WeilZeroTranslationKernelV11 (WeilTwoPointTranslateV11 g a (-1)) b =
        2 * (WeilZeroTranslationKernelV11 g (a + b) +
          WeilZeroTranslationKernelV11 g (b - a)) := by
  rw [twoPoint_translation_kernel, twoPoint_translation_kernel]
  simp only [map_one, map_neg]
  ring

/-- The second channel resolves the antisymmetric endpoint combination. -/
theorem imaginary_phase_kernel_difference
    (g : WeilCompactSmoothGV1) (a b : ℝ) :
    WeilZeroTranslationKernelV11 (WeilTwoPointTranslateV11 g a Complex.I) b -
      WeilZeroTranslationKernelV11 (WeilTwoPointTranslateV11 g a (-Complex.I)) b =
        2 * Complex.I * (WeilZeroTranslationKernelV11 g (a + b) -
          WeilZeroTranslationKernelV11 g (b - a)) := by
  rw [twoPoint_translation_kernel, twoPoint_translation_kernel]
  simp only [map_neg, Complex.conj_I]
  ring

/-- Exact four-corner assembly: the two diagonal directions retain BOTH diagonals
of the rectangle. No moment or sign hypothesis has been inserted. -/
theorem four_corner_quadratic
    (g : WeilCompactSmoothGV1) (a b : ℝ) (c e : ℂ) :
    WeilAutocorrelationZeroQuadraticV11
      (WeilTwoPointTranslateV11 (WeilTwoPointTranslateV11 g a c) b e) =
        (1 + c * conj c) * (1 + e * conj e) *
          WeilAutocorrelationZeroQuadraticV11 g +
        (1 + e * conj e) *
          (c * WeilZeroTranslationKernelV11 g a +
            conj c * WeilZeroTranslationKernelV11 g (-a)) +
        (1 + c * conj c) *
          (e * WeilZeroTranslationKernelV11 g b +
            conj e * WeilZeroTranslationKernelV11 g (-b)) +
        e * c * WeilZeroTranslationKernelV11 g (a + b) +
        e * conj c * WeilZeroTranslationKernelV11 g (b - a) +
        conj e * c * WeilZeroTranslationKernelV11 g (a - b) +
        conj e * conj c * WeilZeroTranslationKernelV11 g (-(a + b)) := by
  rw [twoPoint_zero_quadratic_expansion_v11,
    twoPoint_zero_quadratic_expansion_v11,
    twoPoint_translation_kernel, twoPoint_translation_kernel]
  rw [show a + -b = a - b by ring, show -b - a = -(a + b) by ring]
  ring

end AEGIS.WeilTowerButterflyOct7

#print axioms AEGIS.WeilTowerButterflyOct7.translation_factor_add
#print axioms AEGIS.WeilTowerButterflyOct7.twoPoint_translation_kernel
#print axioms AEGIS.WeilTowerButterflyOct7.plus_minus_kernel_sum
#print axioms AEGIS.WeilTowerButterflyOct7.plus_minus_kernel_difference
#print axioms AEGIS.WeilTowerButterflyOct7.imaginary_phase_kernel_difference
#print axioms AEGIS.WeilTowerButterflyOct7.four_corner_quadratic
