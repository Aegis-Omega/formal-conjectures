# Independent source review of the actual tower butterfly

Reviewed 7 October2026 by `/root/dashboard_draft_oct7`. The exact root
source snapshot, digest, and original dependency digests are in
`SOURCE_REVIEW_RECEIPT.json`. This is an ordinary algebra/source review,
not a compiler run or fresh axiom audit.

**Decision:** all six statements and their mathematical arguments are
correct for the actual definitions read here. They retain the full mixed
terms. None produces positivity or a uniform translation bound.

## Actual definitions and licensed operations

The imported original `WeilZeroCoefficientV11` is

\[
a_\rho=m_\rho M(g)(\rho)\overline{M(g)(1-\bar\rho)}.
\]

The carrier is `RiemannNontrivialZeroIndexV2`, and the actual multiplicity
`analyticOrderNatAt riemannZeta rho.1` is retained. The actual kernel is
\(K_g(t)=\sum_\rho a_\rho\exp((\rho-1/2)t)\).
No real-part or critical-line replacement has been introduced.

The previously defined two-point packet is exactly
\(g+cT_ag\), with centered Mellin factor
\(M(T_ag)(s)=e^{(s-1/2)a}M(g)(s)\). Conjugating the reflected second
Mellin factor produces \(e^{-(\rho-1/2)a}\), without any assertion that
the exponent is imaginary. Thus the diagonal factor cancellation
\(e^{(\rho-1/2)a}e^{-(\rho-1/2)a}=1\) is unconditional.

`zero_translation_kernel_summable_v11 g t` is proved in the source from
the full autocorrelation norm summability and the unconditional strict
critical strip. Its dominating factor is \(e^{|t|/2}\), for each fixed
\(t\). The new proof uses this theorem at \(b,a+b,b-a\), and then scalar
linearity and finite addition of summable series. This is valid; it does
not replace the varying bounds by a single constant for all shifts.

## The six statements

1. `translation_factor_add`: the centered exponential character obeys
   \(E_\rho(a)E_\rho(b)=E_\rho(a+b)\), by the complex exponential law.

2. `twoPoint_translation_kernel`: multiplying the exact old per-zero
   two-point expansion by \(E_\rho(b)\) gives
   \[
   K_{g+cT_ag}(b)
   =(1+|c|^2)K_g(b)+cK_g(a+b)+\bar cK_g(b-a).
   \]
   Both endpoint kernels survive. The proof explicitly pays the three
   summability conditions needed to move the finite algebra through
   `tsum`.

3. `plus_minus_kernel_sum`: substituting \(c=1,-1\) and adding gives
   \(K_{g+T_ag}(b)+K_{g-T_ag}(b)=4K_g(b)\). This cancels mixed terms
   only in the sum of the outputs.

4. `plus_minus_kernel_difference`: subtracting those outputs gives
   \(2[K_g(a+b)+K_g(b-a)]\); both endpoint terms remain.

5. `imaginary_phase_kernel_difference`: the phases \(i,-i\) give
   \(2i[K_g(a+b)-K_g(b-a)]\). This is the second algebra channel, not a
   positivity inequality.

6. `four_corner_quadratic`: the nested packet
   \((1+eT_b)(1+cT_a)g\) contains four sites. The actual quadratic has
   the diagonal product \((1+|c|^2)(1+|e|^2)Q(g)\), two axis mixed
   pairs, and all four rectangle contributions
   \[
   ecK_g(a+b)+e\bar cK_g(b-a)
   +\bar ecK_g(a-b)+\bar e\bar cK_g(-(a+b)).
   \]
   The new source includes each one, even when some shifts coincide.
   No independence, decorrelation or support separation is assumed.

The parameters visible in the new theorem statements are only the
actual legal packet, real shifts, complex coefficients, and zero index
where needed. `autoImplicit=false` is enabled. No sign premise, detector
bound, `hRH`, positivity instance, placeholder or new mathematical axiom
was added. The exact imported endpoint axioms still require the root's
fresh compiler and `#print axioms` run; this review does not invent it.

## Adversarial test: the tempting two-energy inference is false

A finite reflected/conjugate quartet gives the model

\[
K(t)=\tfrac14\sum_{z\in\{1/4+i,1/4-i,-1/4+i,-1/4-i\}}e^{zt}
=\cosh(t/4)\cos t,
\qquad Q=K(0)=1.
\]

It has the original character algebra, reflection/conjugation symmetry,
Hermitian relation \(K(-t)=\overline{K(t)}\), and finite absolute
summability. All six butterfly identities remain exact. At \(a=2\pi\),
however, \(K(a)=\cosh(\pi/2)>1\), so

\[
Q(g+T_ag)=2+2\cosh(\pi/2)>0,
\qquad Q(g-T_ag)=2-2\cosh(\pi/2)<0.
\]

Their sum is still \(4Q=4\). A positive sum or positive parent energy
does not force positivity of both children. The corresponding two-point
matrix has positive diagonal1 and negative determinant
\(1-\cosh^2(\pi/2)\).

This is a counterexample to a generic sign inference from the exact
algebra. It is neither a model of the actual zeta prime-side identity nor
a counterexample to RH. A successful sign recurrence must supply an
additional unconditional arithmetic input controlling the same mixed
terms; symmetry and the two channels alone cannot do that.

No new equivalence was proved here. The review accepts the algebra as a
useful exact accounting tool and leaves the same full detecting-packet
sign obligation unfilled.
