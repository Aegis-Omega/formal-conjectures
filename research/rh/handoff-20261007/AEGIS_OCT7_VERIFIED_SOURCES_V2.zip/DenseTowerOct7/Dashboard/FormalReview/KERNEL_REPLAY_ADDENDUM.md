# Actual independent scoped kernel replay

The ordinary algebra review was followed by a real separate-agent
execution of `DenseTowerOct7/Formal/replay_butterfly.py`. It created the
fresh source/object directory
`DenseTowerOct7/Formal/scoped-replay-20261007T050235.915744Z`.

The actual Lean4.33.1 `--trust=0` compilation and separate pinned
`leanchecker` both exit0. All six theorem axiom lists are precisely
`[propext, Classical.choice, Quot.sound]`. The new source and generated
object match the root replay byte for byte:

- Source SHA256: `16d94d65c7da59bdfb74c7bd82f88c9fdbfabd1199b3cbeab5e50d720039531b`.
- OLEAN SHA256: `227e1a3da495a1cda5c8bdf874f941755d8d4883f48604ea24ed86a9bdd5a9d1`.
- Independent actual replay receipt SHA256: `52556361661696ce42d96587155a09f68d17d5a37498d944722c8a29b49618e2`.

An additional real `#check @...` and `#print axioms` audit for all six
declarations also exits0. Its complete output is preserved in
`full-type-audit.stdout.txt`; it exposes only the stated packet, real
shift, complex coefficient and zero-index parameters. No sign or RH
premise is hidden in the new endpoints. The consolidated source/object/
command/type/axiom bindings are in `INDEPENDENT_KERNEL_REPLAY_RECEIPT.json`,
SHA256 `c1978ce9c4aeb6130599065084b497f7607969df86b0960c2ac0fdd4527fba99`.

Scope: separate agent, same host and pinned engine. The imported objects
are identified and reused, not rebuilt as a complete transitive source
closure. This confirms the actual algebra identities, not positivity,
uniform boundedness, an independent external-environment replay or RH.
`rh_proven` remains false.
