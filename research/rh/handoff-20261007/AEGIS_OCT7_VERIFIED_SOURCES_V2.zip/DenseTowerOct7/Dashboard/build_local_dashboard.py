"""Read-only recovery of existing evidence; never posts or asserts RH closure."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path('/workspace/aegis-research/work')
OUT = ROOT / 'DenseTowerOct7/Dashboard'
HEAD = 'c721361f7c5ac2b9d1a05abece40c87315a4a81b'
BASE = '4361d4e8491e4caba73683d12a98eb5e452922e2'
PINS = {
    'lean_version': '4.33.1',
    'lean_compiler_commit': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6',
    'mathlib_commit': '0df444a360eaa60ab8c11dca51a86af692955474',
    'formal_conjectures_commit': '02da1ad1288b4881ea1f8e575fbe84af7db04364',
}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def jwrite(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')

def run_json(args):
    return json.loads(subprocess.check_output(args, text=True))

issue = run_json(['gh', 'issue', 'view', '693', '--repo',
    'google-deepmind/formal-conjectures', '--json',
    'number,title,url,body,createdAt,updatedAt,state,comments'])
jwrite('ISSUE_693_SNAPSHOT.json', issue)
public_requests = [
    ('tarikskalic33/formal-conjectures', PINS['formal_conjectures_commit'],
        'FormalConjectures/Millennium/RiemannHypothesis.lean'),
    ('tarikskalic33/formal-conjectures', '2ce4139c5c7cc122bc71acac22d1339d12ef1aa2',
        'AegisRH/PR606/RHRestrictedWeilCriterionV13.lean'),
    ('Aegis-Omega/AEGIS-OMEGA', 'e1f54414085d2cfb9d9751af28c42ee1894cfa4b',
        'research/rh/krein_primal_convergence_v2.py'),
    ('Aegis-Omega/AEGIS-OMEGA', '2c3d041b633147ec97c7ef753aa9d157a47bb9f5',
        'sovereign-omega-v2/formal/bridges/lean/WeilZeroTwoPointV11.lean'),
]
public = []
for repo, commit, path in public_requests:
    entry = run_json(['gh', 'api',
        f'repos/{repo}/contents/{path}?ref={commit}', '--jq',
        '{sha,html_url,path}'])
    entry.update(repository=repo, commit=commit)
    public.append(entry)
jwrite('PUBLIC_SOURCE_LINKS.json', public)

records = []
def evidence(path, role, source_head=HEAD):
    p = Path(path) if path.startswith('/') else ROOT / path
    if not p.is_file():
        raise RuntimeError(f'Missing actual evidence: {p}')
    ident = f'e{len(records)+1:02d}'
    record = dict(id=ident, path=str(p), role=role,
        sha256=sha(p), bytes=p.stat().st_size,
        source_head=source_head, public_artifact_url=None)
    if p.is_relative_to(ROOT):
        rel = str(p.relative_to(ROOT))
        blob = subprocess.run(['git', '-C', str(ROOT), 'rev-parse',
            f'{source_head}:{rel}'], capture_output=True, text=True)
        if blob.returncode == 0:
            contents = subprocess.check_output(['git', '-C', str(ROOT),
                'cat-file', 'blob', blob.stdout.strip()])
            if hashlib.sha256(contents).hexdigest() != record['sha256']:
                raise RuntimeError(f'File differs from claimed source commit: {p}')
            record['git_blob'] = blob.stdout.strip()
            record['git_contents_match'] = True
        else:
            record['git_blob'] = None
            record['git_contents_match'] = None
            record['source_commit_scope'] = 'Referenced inherited input; this path is not claimed to exist in the local commit.'
    records.append(record)
    return ident

oct3 = '/workspace/aegis-research/evidence/rh-continuation-oct3b-20261003T174604Z/'
v4 = '/workspace/aegis-research/evidence/rh-breakthrough-v4-20261003T051724Z/'
e_oct_final = evidence(oct3+'RH_FINAL_EVIDENCE.json', 'Prior unfinished final-state report')
e_v4_final = evidence(v4+'RH_FINAL_EVIDENCE.json', 'Prior unfinished final-state report', BASE)
e_checkpoint = evidence('BreakthroughContinuationOct3B/FinalPackage/CONTINUATION_CHECKPOINT.md', 'Human-readable continuation')
e_source_zip = evidence(oct3+'RH_CONTINUATION_SOURCE.zip', 'Local immutable source archive; not yet publicly attached')
e_source_manifest = evidence(oct3+'SOURCE_MANIFEST.json', 'Local immutable source manifest')

t = 'BreakthroughContinuationOct3B/LiveSources/CICompatibility/PR13/TargetIntegration/'
e_target_receipt = evidence(t+'RESULT.json', 'Actual compiler/checker/type audit and failed target probe')
e_probe = evidence(t+'sources/ExactRHTargetProbe.lean', 'Literal failed exact-RH proof attempt')
e_probe_log = evidence(t+'logs/literal-exact-RH-target-probe.log', 'Actual unsolved-goal compiler output')
e_type_log = evidence(t+'logs/full-type-and-axiom-audit.log', 'Expanded type and axiom output')
e_target_bindings = evidence(t+'INPUT_SOURCE_BINDINGS.json', 'Exact public commit/blob bindings')

e_id_source = evidence('BreakthroughV4Oct3/ArithmeticKernel/WeilTranslatedArithmeticKernelOct3.lean', 'Full translated identity source', BASE)
e_id_receipt = evidence('BreakthroughV4Oct3/FinalPackage/identity-replay-20261003T050255.188563Z/RECEIPT.json', 'First scoped source replay', BASE)
e_id_receipt_2 = evidence('BreakthroughV4Oct3/FinalPackage/identity-replay-20261003T050401.269389Z/RECEIPT.json', 'Separate-agent scoped source replay on same host', BASE)
e_id_manifest = evidence('BreakthroughV4Oct3/ArithmeticKernel/SOURCE_MANIFEST.json', 'Original imported source bindings', BASE)

e_width = evidence('BreakthroughContinuationOct3B/RootKernel/EXACT_L105_EXISTING_PROOF_TRANSPORT.md', 'Exact target/form-domain adapter, ordinary proof')
e_width_bindings = evidence('BreakthroughContinuationOct3B/RootKernel/LP_SOURCE_BINDING.json', 'LP and reused analytic/certificate input bindings')
e_width_review = evidence('BreakthroughContinuationOct3B/AnalyticBootstrap/FinalReviews/EXACT_L105_REVIEW_RECEIPT.json', 'Independent ordinary adapter review; no new kernel or Arb replay')
e_retained = evidence('RETAINED_GAP_COMPOSITION_V4.md', 'Existing full low-block/complement/mixed written completion')
e_arb = evidence('low-block-full-arb.json', 'Existing literal interval matrix, inherited provenance limitations')

e_euler = evidence('BreakthroughContinuationOct3B/AnalyticBootstrap/EulerCritic/ACTUAL_EULER_HERGLOTZ_OBSTRUCTION.md', 'Full actual-zeta rational countertest and positive kernels')
e_euler_review = evidence('BreakthroughContinuationOct3B/AnalyticBootstrap/EulerCritic/Independent/EULER_HERGLOTZ_REVIEW.md', 'Separate ordinary proof reconstruction')
e_variance = evidence('BreakthroughContinuationOct3B/PrimeSigned/ADDITIVE_VARIANCE_AND_MAJOR_ARC_ATTACK.md', 'Actual fixed-packet variance/central-major-arc attack')
e_variance_review = evidence('BreakthroughContinuationOct3B/LiveSources/PrimeReview/VarianceReview/REVIEW_RECEIPT.json', 'Independent ordinary review of final manuscript')
e_analytic_result = evidence('BreakthroughContinuationOct3B/AnalyticBootstrap/RESULT_STATE.json', 'Scoped ordinary proof statuses')

e_ci = evidence('BreakthroughContinuationOct3B/LiveSources/CICompatibility/RESULT.json', 'Aggregate scoped local compatibility receipts')
e_ci_review = evidence('BreakthroughContinuationOct3B/LiveSources/CICompatibility/INDEPENDENT_DIFF_REVIEW_RECEIPT.json', 'Statement/hypothesis preservation review')
for name in ['PR1/receipt.json', 'PR9/receipt.json', 'PR11/RESULT.json', 'PR13/RESULT.json']:
    evidence('BreakthroughContinuationOct3B/LiveSources/CICompatibility/'+name, 'Per-module actual compiler/checker receipt')

standard_axioms = ['propext', 'Classical.choice', 'Quot.sound']
results = [
  dict(id='conditional_rh_target_composition',
    exact_statement='UniversalZeroQuadraticNonnegativeV10 -> _root_.RiemannHypothesis',
    quantifiers='forall legal compact smooth g with both endpoint moments; full sum over all actual nontrivial zeta zeros',
    assumptions=['UniversalZeroQuadraticNonnegativeV10 is an explicit input, not discharged'],
    source_commit='2ce4139c5c7cc122bc71acac22d1339d12ef1aa2',
    source_url=public[1]['html_url'], source_blob=public[1]['sha'],
    proof_status='KERNEL_VERIFIED_UNDER_STATED_HYPOTHESIS',
    composition_status='ACTUAL_EXACT_TARGET_PROBE_FAILED_WITH_EXPLICIT_RESIDUAL',
    actual_probe_exit_code=1, actual_residual='AEGIS.RHMillenniumGateV10.UniversalZeroQuadraticNonnegativeV10',
    kernel_scope='Unchanged terminal module compiled trust=0, separate pinned leanchecker, identified imports reused',
    axioms=standard_axioms, rh_closed=False,
    evidence_ids=[e_target_receipt,e_probe,e_probe_log,e_type_log,e_target_bindings]),
  dict(id='translated_full_arithmetic_identity',
    exact_statement='forall g:WeilCompactSmoothGV1, WeilMomentConditionsV1 g -> forall t:Real, WeilZeroTranslationKernelV11 g t = -WeilExplicitRightSideV1 (translatePacket (WeilAutocorrelationCompactSmoothV1 g) t).1',
    assumptions=['Both original endpoint moments', 'Original legal compact smooth class'],
    source_commit=BASE, source_url=None,
    proof_status='KERNEL_VERIFIED', composition_status='UNCONDITIONAL_IDENTITY_NO_SIGN_BOUND',
    kernel_scope='Fresh source of this module and wrapper; trust=0 and pinned leanchecker; imported source/object identities bound but not rebuilt from source',
    axioms=standard_axioms, independent_replay_scope='Separate agent, same host and pinned engine; no independent external environment',
    rh_closed=False, evidence_ids=[e_id_source,e_id_receipt,e_id_receipt_2,e_id_manifest]),
  dict(id='existing_rational_width_transport',
    exact_statement='For every finite complex combination of the moment-zero sine-product LP basis at exact FULL width L=21/20, Q(f) >= (1/1000)*norm_L2(f)^2',
    domain='Existing extended analytic form domain D on interval radius21/40; all finite complex mixed coefficients retained',
    assumptions=['Recovered complete written low-block, full-complement and mixed-coupling proof inputs', 'Inherited interval matrix'],
    source_commit=HEAD, source_url=None,
    imported_diagnostic_source=dict(repository=public[2]['repository'],
        commit=public[2]['commit'], path=public[2]['path'],
        git_blob=public[2]['sha'], url=public[2]['html_url']),
    proof_status='WRITTEN_PROOF_RECOVERED_AND_ORDINARY_ADAPTER_REVIEWED',
    composition_status='ANALYTIC_LEAN_PORT_PENDING',
    limitations=['Does not apply to larger exact binary representation of1.05', 'No fixed finite dual-hat feasibility theorem', 'No arbitrary-support globalization', 'Original matrix pre-start digest not recovered; no invented provenance', 'Scalar completion kernel pass is not full analytic/certificate soundness'],
    fresh_arb_replay=False, rh_closed=False,
    evidence_ids=[e_width,e_width_bindings,e_width_review,e_retained,e_arb]),
  dict(id='actual_euler_positive_real_countertest',
    exact_statement="Re[-zeta'/zeta](5+i*pi/log2) < -7/15552",
    assumptions=['Actual Euler/von-Mangoldt identity only on Re(s)>1', 'Whole n>=3 tail paid by exact integral comparison'],
    source_commit=HEAD, source_url=None,
    proof_status='COMPLETE_ORDINARY_ARGUMENT_INDEPENDENTLY_REVIEWED',
    composition_status='FALSIFIES_POSITIVE_REAL_INFERENCE_NOT_RH',
    preserved_true_result='For every sigma>1, the finite Gram kernel sum_ij c_i conj(c_j) D(sigma+i(t_i-t_j)) is nonnegative',
    kernel_replay=False, rh_closed=False,
    evidence_ids=[e_euler,e_euler_review,e_analytic_result]),
  dict(id='signed_prime_variance_bound_insufficient',
    exact_statement='For the SAME fixed detecting correlation C and fixed compact nonnegative weight w, the paid actual PNT/variance estimates give a logarithmic upper scale T-.3706*(T-A)^(.6)/(log(T-A))^(.2)+O(log T), tending to +infinity',
    assumptions=['Actual unconditional Johnston-Yang theta estimate with published finite verified-zero-height input stated', 'Fixed C, w, all prime powers/background/Archimedean transport paid'],
    source_commit=HEAD, source_url=None,
    proof_status='COMPLETE_ORDINARY_TRANSPORT_INDEPENDENTLY_REVIEWED',
    composition_status='ATTEMPT_DOES_NOT_GIVE_T_UNIFORM_BOUND',
    exact_remaining_term='Signed central q=1 contribution in the exact centered Mangoldt Fourier identity for this SAME fixed packet',
    kernel_replay=False, rh_closed=False,
    evidence_ids=[e_variance,e_variance_review]),
  dict(id='sampled_ci_compatibility_repairs',
    exact_statement='Local repaired affected modules for fork PR1, PR9, PR11, PR13 pass trust=0 and the pinned leanchecker, preserving theorem statements and explicit hypotheses',
    assumptions=['Exact source heads and imported cache bindings in per-module receipts'],
    source_commit=HEAD, source_url=None,
    proof_status='SCOPED_AFFECTED_MODULE_KERNEL_REPLAY_PASS',
    composition_status='NO_HOSTED_STATUS_CHANGE_NO_FINAL_RH_CLOSURE',
    axioms=standard_axioms, whole_project_build=False, hosted_dispatch=False,
    rh_closed=False, evidence_ids=[e_ci,e_ci_review])
]

identity_receipt = json.loads((ROOT / 'BreakthroughV4Oct3/FinalPackage/identity-replay-20261003T050255.188563Z/RECEIPT.json').read_text())
measured = [dict(name=r['name'], elapsed_seconds=r['elapsed_seconds'],
                exit_code=r['exit_code'])
            for r in identity_receipt['records']
            if r['name'] in ['compile-WeilTranslatedArithmeticKernelOct3','check-WeilTranslatedArithmeticKernelOct3']]
report = dict(schema='aegis.partial-negative-dashboard.v1',
    prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    draft_only=True, posted=False, remote_writes=False,
    report_scope='Recovered Oct3 evidence; Oct7 read-only dashboard assembly. Not a new Oct7 mathematical or kernel replay.',
    issue_url=issue['url'], issue_scope='Reporting process/dashboard request; issue body contains no RH theorem or DenseFixedPacketSign definition',
    report_source_commit=HEAD, inherited_source_commit=BASE,
    pins=PINS, canonical_target='_root_.RiemannHypothesis for Mathlib analytically continued riemannZeta',
    external_sorry_body_used=False, rh_proven=False, final_theorem=None,
    full_final_clean_build=False, final_independent_rh_replay=False,
    results=results,
    resources=dict(model_identifier=None, model_parameters=None,
        training_or_inference_flops=None, total_compute_seconds=None,
        ram_peak_bytes=None, energy_kwh=None,
        reason='Not recorded in the bound attempt evidence; unknown fields stay null.',
        selected_recorded_command_limits={'threads':1,'lean_memory_limit_megabytes':4096},
        selected_actual_command_timings=measured,
        timing_receipt_evidence_id=e_id_receipt,
        resource_scope='Selected commands only; not the whole research run or measured RAM peak.'),
    one_selected_open_mathematical_obligation='exists ONE C:Real, forall t:Real, norm(WeilZeroTranslationKernelV11 SAME_detectingPacket t)<=C',
    publication_scope='Public source URLs were read-only verified at exact commits; newly composed local sources/receipts have no public URLs yet.',
    status_distinction=['Proof under hypotheses','Ordinary proof','Arb evidence','Scoped kernel replay','Full final RH closure'])
jwrite('DASHBOARD.json',report)
jwrite('EVIDENCE_INDEX.json',dict(schema='aegis.dashboard.evidence-index.v1',
    local_only=True, records=records, public_sources=public))

draft = '''A concrete pilot report for the proposed negative-results / partial-progress dashboard: an AEGIS RH attempt, **RH not proved**. The report separates written mathematics, interval evidence, kernel-checked implications, failed proof composition and execution failures.

The exact target is Mathlib's `RiemannHypothesis` for its analytically continued zeta, with every original quantifier. The external conjecture's `sorry` body was not used. Pins: Lean **4.33.1**, compiler `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, Mathlib `0df444a360eaa60ab8c11dca51a86af692955474`, FormalConjectures `02da1ad1288b4881ea1f8e575fbe84af7db04364`.

| Independently assessable outcome | Exact scope and evidence level |
|---|---|
| **An implication survives; its final application fails.** The unchanged terminal theorem has type `UniversalZeroQuadraticNonnegativeV10 → RiemannHypothesis`. | It passed `--trust=0`, the pinned `leanchecker`, and the three-standard-axiom audit. Applying it to the exact RH target actually exits1 with `⊢ UniversalZeroQuadraticNonnegativeV10`. The all-test-function positivity input is not discharged. Receipts e06–e10. |
| **Full translated explicit-formula identity.** For every original legal compact smooth packet with both moments and every real translation, `K_g(t) = -RHS(translate(autocorrelation(g),t))`. | New composition source replayed by separate agents on the same host. All zero multiplicities and arithmetic terms retained. It is an unconditional identity, with no sign or uniform bound conclusion. Receipts e11–e14. |
| **Existing proof reused at rational full width21/20.** Every finite complex LP-basis combination satisfies `Q(f) ≥ ‖f‖₂²/1000`. | Exact domain/normalization adapter to an existing written low-block/complement proof, with interval inputs and all mixed terms. Complete analytic Lean port remains pending. This is neither unrestricted support nor proof of a particular dual-hat certificate. The exact binary literal1.05 is slightly larger than21/20. Evidence e15–e19. |
| **A proposed positivity inference is false for actual zeta.** `Re[-ζ′/ζ](5+iπ/log2) < -7/15552`. | Complete ordinary rational-tail argument, independently reconstructed. Nonnegative prime-power coefficients do give positive-definite Gram kernels on `Re(s)>1`; they do not give a positive-real logarithmic derivative or an unpaid descent to the critical line. Evidence e20–e21. |
| **Signed prime-window estimates still grow.** Unconditional PNT/variance transport for the same fixed detecting packet does not yield a uniform translation bound. | The strongest applied bound has logarithmic upper scale `T-.3706(T-A)^.6/(log(T-A))^.2+O(log T) → +∞`. Central major-arc cancellation remains unpaid. This rejects the attempted estimate, not RH or all other approaches. Evidence e22–e23. |
| **Compiler repair is separate from mathematical closure.** Affected modules from sampled fork PR1,9,11,13 now pass locally. | Statements/hypotheses were preserved; `--trust=0`, `leanchecker`, axioms `[propext, Classical.choice, Quot.sound]`. Imported objects were identified and reused. No whole-project/final-closure clean build or hosted status change is claimed. Evidence e25–e30. |

**Remaining mathematical obligation:** one constant bounding the full translation kernel of the same detecting packet for every real translation. No support cap, alternate packet or RH-equivalent positivity assumption is inserted to fill it.

Exact public sources: [canonical target](https://github.com/tarikskalic33/formal-conjectures/blob/02da1ad1288b4881ea1f8e575fbe84af7db04364/FormalConjectures/Millennium/RiemannHypothesis.lean), [terminal implication](https://github.com/tarikskalic33/formal-conjectures/blob/2ce4139c5c7cc122bc71acac22d1339d12ef1aa2/AegisRH/PR606/RHRestrictedWeilCriterionV13.lean), [original LP diagnostic](https://github.com/Aegis-Omega/AEGIS-OMEGA/blob/e1f54414085d2cfb9d9751af28c42ee1894cfa4b/research/rh/krein_primal_convergence_v2.py). New composition/repair sources and logs remain local at commit `c721361f7c5ac2b9d1a05abece40c87315a4a81b`; `EVIDENCE_INDEX.json` identifies exact bytes and availability. Those artifacts need publication before this is an independently reproducible upstream submission.

Selected recorded resource data: one identity-module compile took **5.593178680s** and its separate checker **7.586180103s**, with `-j1 -M4096`. These are command timings and configured limits, not whole-run compute or measured RAM. Exact model/settings, total FLOPS, peak RAM and energy were not recorded, so those dashboard fields are `null`.

Suggested dashboard rule: store separate proof, application, replay and availability fields. A failed final composition should retain its exact unsolved type; a unavailable/billing-blocked runner should not be labeled a mathematical counterexample; a finite/scoped replay should not appear as final conjecture closure.
'''
(OUT/'UPSTREAM_CONTRIBUTION_DRAFT.md').write_text(draft)
(OUT/'README.md').write_text('''# Local review draft for upstream issue693

Nothing in this directory was posted, pushed or dispatched. The upstream issue requests reporting of failed attempts and partial progress; it does not state a DenseFixedPacketSign theorem. This assembly recovers Oct3 results with their exact scopes; root research continues separately on the same detecting packet.

`UPSTREAM_CONTRIBUTION_DRAFT.md` is the proposed text. `DASHBOARD.json` is fail-closed machine-readable state. `EVIDENCE_INDEX.json` contains literal hashes and local availability for each cited item. `ISSUE_693_SNAPSHOT.json` and `PUBLIC_SOURCE_LINKS.json` record this run's read-only source retrieval. Local source commits are deliberately not assigned fictitious GitHub URLs.

Validate metadata and evidence byte identities with:

```sh
python3 /workspace/aegis-research/work/DenseTowerOct7/Dashboard/check_dashboard.py
```

That validation is neither a fresh mathematical proof nor a Lean/RH replay. Model/FLOPS/kWh/whole-run time and measured peak RAM stay unknown. No full dependency source rebuild is claimed for imported cached objects. Full analytic certificate soundness and unrestricted positivity remain distinct.
''')
print(json.dumps(dict(status='LOCAL_DRAFT_CREATED', results=len(results), evidence_records=len(records), rh_proven=False)))
