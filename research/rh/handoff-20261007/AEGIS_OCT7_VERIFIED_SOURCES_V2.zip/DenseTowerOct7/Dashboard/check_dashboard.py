"""Validate local evidence binding and fail-closed reporting, not mathematics."""
from pathlib import Path
import hashlib
import json
import re
import sys

OUT = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def check(report, index):
    require(report.get('rh_proven') is False, 'No unconditional RH proof in this report')
    require(report.get('final_theorem') is None, 'A final RH theorem has not been produced')
    for flag in ['posted','remote_writes','full_final_clean_build','final_independent_rh_replay']:
        require(report.get(flag) is False, f'Unexpected assertion: {flag}')
    require(report.get('draft_only') is True, 'This is a local unposted draft')
    entries = index['records']
    ids = [r['id'] for r in entries]
    require(len(ids) == len(set(ids)), 'Duplicate evidence identifier')
    require(ids == [f'e{i+1:02d}' for i in range(len(ids))], 'Missing or reordered evidence')
    for r in entries:
        p = Path(r['path'])
        require(p.is_file(), f'Missing evidence {r["id"]}')
        contents = p.read_bytes()
        require(len(contents) == r['bytes'], f'Altered size {r["id"]}')
        require(hashlib.sha256(contents).hexdigest() == r['sha256'], f'Altered evidence {r["id"]}')
    require(len(report['results']) == 6, 'Unexpected result set')
    for r in report['results']:
        require(r.get('rh_closed') is False, f'Unexpected RH closure: {r["id"]}')
        require(bool(r['evidence_ids']) and set(r['evidence_ids']) <= set(ids), 'Unbound result evidence')
        if r.get('source_url') is not None:
            require(f'/blob/{r["source_commit"]}/' in r['source_url'], 'Mixed result commit/URL tuple')
        original = r.get('imported_diagnostic_source')
        if original:
            require(f'/blob/{original["commit"]}/' in original['url'], 'Mixed imported source tuple')
    by_id = {r['id']:r for r in entries}
    for ident in ['e01','e02']:
        final = json.loads(Path(by_id[ident]['path']).read_text())
        require(final['rh_proven'] is False and final['final_theorem'] is None, 'Prior evidence disagrees')
    log = Path(by_id['e08']['path']).read_text()
    require('error: unsolved goals' in log and 'UniversalZeroQuadraticNonnegativeV10' in log, 'Missing actual residual output')
    audit = Path(by_id['e09']['path']).read_text()
    require('UniversalZeroQuadraticNonnegativeV10 → RiemannHypothesis' in audit, 'Wrong terminal type')
    require('sorryAx' not in audit, 'Unexpected axiom in selected endpoint audit')
    require(report['resources']['model_identifier'] is None, 'Exact model was not logged')
    require(report['resources']['energy_kwh'] is None, 'Energy was not measured')
    draft = (OUT/'UPSTREAM_CONTRIBUTION_DRAFT.md').read_text()
    referenced = set(re.findall(r'\be\d\d\b',draft))
    require(referenced <= set(ids), 'Draft cites a nonexistent evidence item')
    return len(entries)

def main():
    report=json.loads((OUT/'DASHBOARD.json').read_text())
    index=json.loads((OUT/'EVIDENCE_INDEX.json').read_text())
    count=check(report,index)
    receipt=dict(status='PASS_METADATA_AND_BYTE_BINDING',evidence_records=count,
        results=len(report['results']),rh_proven=False,
        fresh_math_or_kernel_replay=False,posted=False,
        report_sha256=hashlib.sha256((OUT/'DASHBOARD.json').read_bytes()).hexdigest(),
        evidence_index_sha256=hashlib.sha256((OUT/'EVIDENCE_INDEX.json').read_bytes()).hexdigest(),
        checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (OUT/'VALIDATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps(receipt,sort_keys=True))

if __name__=='__main__':
    try:
        main()
    except (ValueError,KeyError,OSError,json.JSONDecodeError) as e:
        print(json.dumps({'status':'REJECTED','reason':str(e)}),file=sys.stderr)
        sys.exit(1)
