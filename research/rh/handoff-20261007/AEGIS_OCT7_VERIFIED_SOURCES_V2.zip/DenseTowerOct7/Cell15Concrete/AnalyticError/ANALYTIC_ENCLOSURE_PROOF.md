# Premise-free fifteenth-cell first-jet enclosure

The following actual coefficient bound is proved in pinned Lean, without an
analytic or numerical certificate premise:

```lean
AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure :
  |AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient
      AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter 1
     - (347860160497 / 10^12 : ℝ)| ≤ 1 / 10^12
```

Here the center is exactly `5025/65536`, the midpoint of public zero-based cell
14 (one-based fifteenth), with endpoints `2475/32768`, `1275/16384`, and payload
`292616690003685633`. The coefficient is the actual normalized first ordinary
derivative of the unchanged public correction symbol. No redefinition of the
correction, prime coefficients, support, or jet is used.

## Complete derivative identity

Write S(x)=sinc(x), D(x)=(x cos(x)-sin(x))/x², and

H(t)=Σ_{j:Fin 199} a_j cos(tu_j),
H'(t)=Σ_j a_j[-u_j sin(tu_j)].

For j:Fin 5 let P_j(t) be cos(1619t/2000) for even j and
sin(1619t/2000) for odd j. Put

E(t)=Σ_j b_j t^j P_j(t),
E'(t)=Σ_j b_j[j t^(j-1) P_j(t)+t^j P'_j(t)].

The zero-degree polynomial derivative is zero, since its integer coefficient
j vanishes. The original correction is

F(t)=(2/50) S(t/100)^2 H(t)+S(t/2000)^19 E(t).

For t≠0, all scaled sinc quotients are regular, and the product and chain rules
give the exact four-term identity

F'(t)=(2/50)[(2 S(t/100) D(t/100)/100)H(t)+S(t/100)^2 H'(t)]
      +(19 S(t/2000)^18 D(t/2000)/2000)E(t)
      +S(t/2000)^19 E'(t).

`RHKreinCorrectionDerivativeOct7.lean` proves this from the actual imported
`correctionSymbol` and transports it to `exactJetCoefficient t 1`. All 199 hat
terms and all five spline terms remain in the identity, including the two
chain factors 1/100 and 1/2000 and both differentiated power factors.

## Existing low-degree Taylor bounds

The public generic adapter identifies the real and imaginary parts of the
existing 16-term complex exponential polynomial with the degree-14 cosine
and degree-15 sine polynomials. It also identifies the existing 8-term sinc
polynomial with its degree-6 ordinary polynomial. The reused proved bounds are

|cos x-C(x)|, |sin x-T(x)| ≤ |x|^16·17/(16!·16)  for |x|≤1,

|sinc x-U(x)| ≤ |x|^8·9/(8!·8)/x  for 0<x and |x|≤1.

The actual 199 phases at c=5025/65536 all lie in [0,48039/131072], strictly
inside [0,1]. Exact cell/phase proofs discharge every pointwise hypothesis.
The resulting uniform hat sine/cosine error is at most 10^-20. The edge phase
sin/cos error is at most 10^-30. The two sinc errors are at most 10^-25 and
10^-34, respectively. The actual and polynomial sinc magnitudes are at most
one. The derived D-polynomial errors are at most 10^-50 and 10^-56; its
polynomial magnitudes are at most one and the actual D magnitudes at most two.
All these statements are kernel-proved rational inequalities.

A separate optional module reuses the 17-term exponential theorem. Its last
term is real, so the same degree-15 sine polynomial satisfies the sharper
|x|^17·18/(17!·17) bound. The main coarse coefficient enclosure does not require
this improvement or a degree-53 port.

## Full signed-sum and product budgets

Replace sin, cos, sinc and D everywhere in the complete four-term formula by
T, C, U and D_P(x)=(x C(x)-T(x))/x². This defines the exact rational surrogate
R(t). The coefficient vectors and all powers are unchanged.

The proved absolute coefficient budget Σ|a_j|≤18125000 and |u_j|≤5 give

|H|≤18125000, |H-H_P|≤18125000·10^-20, |H_P|≤20000000,
|H'|≤90625000, |H'-H'_P|≤90625000·10^-20, |H'_P|≤100000000.

The actual five spline coefficients have Σ|b_j|≤60000. The center satisfies
0<c<1. Both phase and phase derivative magnitudes are at most one. Consequently

|E|≤60000, |E-E_P|≤60000·10^-30, |E_P|≤100000,
|E'|≤300000, |E'-E'_P|≤300000·10^-30, |E'_P|≤500000.

Weighted finite-sum triangle inequalities pay all signed coefficients. For
products use the exact identity

ab-a_P b_P = a(b-b_P)+(a-a_P)b_P,

so the proved error is |a|·e_b+|b_P|·e_a. The existing unit-norm power lemma
pays |S^n-U^n|≤n|S-U| for every required n. Thus mixed terms and all 18/19
power contributions are paid. Exact rational arithmetic in the final Lean
module bounds the complete error

|F'(c)-R(c)|≤10^-13.

No numerical JSON, hash, receipt predicate, hformula, or positivity assumption
is a premise of this theorem.

## Exact scalar enclosure and final triangle

The existing signed hat-moment factorization reduces the complete 199-hat
polynomial to moments. The already proved even moments through degree 10 are
reused; the actual degree 12, 14 and 16 moments are proved by exact rational
arithmetic. The full derivative surrogate is preserved, including all five
spline columns and the power-19 term. Kernel rational arithmetic proves

|R(c)-347860160497148/10^15|≤10^-14.

The fine rational center differs from the serialized coarse jet by exactly
148/10^15. Therefore

|exactJetCoefficient(c,1)-347860160497/10^12|
 ≤ 10^-13+10^-14+148/10^15
 = 258/10^15 < 10^-12.

This is the premise-free final endpoint; the stated conclusion follows by
weakening the strict rational inequality.

## Executed verification and exact scope

Lean 4.33.1, compiler 819816b2e0a3bf405af45ae5c7af2491d8f5bee6,
Mathlib 0df444a360eaa60ab8c11dca51a86af692955474. The source was compiled
fresh with explicit --trust=0, and the pinned leanchecker independently
checked the endpoint module. A separate agent independently invoked a second
fresh source compile and checker. Both complete endpoint types have no
premises; both axiom audits are exactly propext, Classical.choice, Quot.sound.

Primary receipt: scoped-replay-20261007T061004.484237Z/RECEIPT.json,
SHA256 d7c29f6ba96d6958763a0bfd30a6943e129ace02231fd80122c6ecb1b1d027c5.
Independent receipt: scoped-replay-20261007T061154.404255Z/RECEIPT.json,
SHA256 156fe07c280ba2f3522fdd538f360b90c6493a301012a1e50225a88db35d22aa.
Both use identified imported objects rather than a fresh rebuild of the entire
transitive closure. This is independent same-host replay, not another machine.

The raw emitted OLEAN hashes differ only in the embedded absolute source
pathname; the five differing bytes and all other byte equality were audited
without modifying either object. Source bytes, scripts and imported input
bindings agree. Both raw hashes remain separately recorded.

The originally supplied library source has now been fully restored from its
readable parts with SHA256/Git blob matches. Its fifteenth reduction has the
same literal cell, midpoint, target and radius. Its derivative formula is
algebraically the same complete formula above. The separate original-namespace
transport status and actual attempted replay are in OriginalTargetIntegration;
that transport is not silently supplied by a definition-only namespace shim.

The frozen replay script has an inherited stale introductory docstring saying
it is not the coefficient enclosure. The actual compiled source, commands,
printed types, and audited receipts check the coefficient enclosure explicitly.
The frozen reported_zip_available=false field refers to the raw ZIP container,
not the subsequently restored complete text sources. These historical bytes
are preserved without rewriting their identity.

This proves exactly the k=1 enclosure of one cell. It does not prove its other
seven jets, whole-cell soundness, all 2199 cells, global Weil positivity, or RH.
The finer two-unit/10^15 interval and the user's specific reported Fraction
width/margin have separate ordinary rational verification; they are not the
conclusion of this kernel endpoint. RH_PROVEN remains false.
