import RHKreinCell15SumBoundsOct7
import RHKreinCell15DerivativeErrorsOct7
import RHKreinCell15ScalarClosureOct7
import PowerProductError

set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 3000000
noncomputable section

namespace AEGIS.RHKreinCell15AnalyticErrorOct7

open AEGIS.RHKreinCell15PhasesOct7
open AEGIS.RHKreinCell15PointwiseOct7
open AEGIS.RHKreinCorrectionDerivativeOct7
open AEGIS.RHKreinCell15ScalarBudgetOct7
open AEGIS.RHKreinCell15ScalarClosureOct7
open AEGIS.RHKreinCell15SumBoundsOct7
open AEGIS.RHKreinSincIntervalV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.PR53TrigTaylorIntegration

theorem product_error (a ap b bp A B ea eb : ℝ)
    (ha : |a| ≤ A) (hbp : |bp| ≤ B)
    (hea : |a - ap| ≤ ea) (heb : |b - bp| ≤ eb) :
    |a * b - ap * bp| ≤ A * eb + B * ea := by
  have hA : 0 ≤ A := (abs_nonneg _).trans ha
  have hB : 0 ≤ B := (abs_nonneg _).trans hbp
  calc
    |a * b - ap * bp| = |a * (b - bp) + (a - ap) * bp| := by congr 1; ring
    _ ≤ |a * (b - bp)| + |(a - ap) * bp| := abs_add_le _ _
    _ = |a| * |b - bp| + |bp| * |a - ap| := by
      rw [abs_mul, abs_mul]; ring
    _ ≤ A * eb + B * ea := add_le_add
      (mul_le_mul ha heb (abs_nonneg _) hA)
      (mul_le_mul hbp hea (abs_nonneg _) hB)

theorem sum_error (a ap b bp ea eb : ℝ)
    (ha : |a - ap| ≤ ea) (hb : |b - bp| ≤ eb) :
    |(a + b) - (ap + bp)| ≤ ea + eb := by
  calc
    _ = |(a - ap) + (b - bp)| := by congr 1; ring
    _ ≤ |a - ap| + |b - bp| := abs_add_le _ _
    _ ≤ ea + eb := add_le_add ha hb

theorem scale_error (k a ap e : ℝ) (h : |a - ap| ≤ e) :
    |k * a - k * ap| ≤ |k| * e := by
  rw [← mul_sub, abs_mul]
  exact mul_le_mul_of_nonneg_left h (abs_nonneg _)

theorem hat_D_error :
    |sincDerivative (fifteenthCenter / 100) - sincDerivativeP (fifteenthCenter / 100)| ≤
      (1 / 10 ^ (50 : ℕ) : ℝ) := by
  simpa only [sincDerivativeP, sincDerivativePolynomial] using hat_sincDerivative_error

theorem edge_D_error :
    |sincDerivative (fifteenthCenter / 2000) - sincDerivativeP (fifteenthCenter / 2000)| ≤
      (1 / 10 ^ (56 : ℕ) : ℝ) := by
  simpa only [sincDerivativeP, sincDerivativePolynomial] using edge_sincDerivative_error

theorem hat_Dpoly_abs : |sincDerivativeP (fifteenthCenter / 100)| ≤ 1 := by
  simpa only [sincDerivativeP, sincDerivativePolynomial] using hat_sincDerivative_polynomial_abs

theorem edge_Dpoly_abs : |sincDerivativeP (fifteenthCenter / 2000)| ≤ 1 := by
  simpa only [sincDerivativeP, sincDerivativePolynomial] using edge_sincDerivative_polynomial_abs

theorem hat_factor_abs :
    |2 * Real.sinc (fifteenthCenter / 100) * sincDerivative (fifteenthCenter / 100) / 100| ≤
      (1 / 25 : ℝ) := by
  have h : |Real.sinc (fifteenthCenter / 100) * sincDerivative (fifteenthCenter / 100)| ≤ 2 := by
    rw [abs_mul]
    simpa using mul_le_mul (Real.abs_sinc_le_one _) hat_sincDerivative_abs
      (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 1)
  calc
    _ = |Real.sinc (fifteenthCenter / 100) * sincDerivative (fifteenthCenter / 100)| / 50 := by
      rw [abs_div, abs_mul, abs_mul]
      norm_num
      ring
    _ ≤ 2 / 50 := div_le_div_of_nonneg_right h (by norm_num)
    _ = _ := by norm_num

theorem hat_factor_error :
    |(2 * Real.sinc (fifteenthCenter / 100) * sincDerivative (fifteenthCenter / 100) / 100) -
      (2 * sincPolynomial7 (fifteenthCenter / 100) * sincDerivativeP (fifteenthCenter / 100) / 100)| ≤
      (1 / 50 : ℝ) * (1 / 10 ^ (50 : ℕ) + 1 / 10 ^ (25 : ℕ)) := by
  have h := product_error _ _ _ _ 1 1 _ _
    (Real.abs_sinc_le_one _) hat_Dpoly_abs hat_sinc_error hat_D_error
  have hs := scale_error (1 / 50) _ _ _ h
  convert hs using 1 <;> first | ring | norm_num

theorem hat_sinc_square_error :
    |Real.sinc (fifteenthCenter / 100) ^ 2 - sincPolynomial7 (fifteenthCenter / 100) ^ 2| ≤
      (2 / 10 ^ (25 : ℕ) : ℝ) := by
  have h := power_error_unit _ _ _ 2 (Real.abs_sinc_le_one _)
    hat_sinc_polynomial_abs hat_sinc_error
  norm_num at h ⊢
  exact h

theorem edge_sinc_power_error (n : ℕ) :
    |Real.sinc (fifteenthCenter / 2000) ^ n - sincPolynomial7 (fifteenthCenter / 2000) ^ n| ≤
      (n : ℝ) / 10 ^ (34 : ℕ) := by
  simpa [div_eq_mul_inv] using power_error_unit _ _ _ n (Real.abs_sinc_le_one _)
    edge_sinc_polynomial_abs edge_sinc_error

theorem edge_factor_abs :
    |19 * Real.sinc (fifteenthCenter / 2000) ^ 18 * sincDerivative (fifteenthCenter / 2000) / 2000| ≤
      (19 / 1000 : ℝ) := by
  have hp : |Real.sinc (fifteenthCenter / 2000) ^ 18| ≤ 1 := by
    rw [abs_pow]
    exact pow_le_one₀ (abs_nonneg _) (Real.abs_sinc_le_one _)
  have h : |Real.sinc (fifteenthCenter / 2000) ^ 18 * sincDerivative (fifteenthCenter / 2000)| ≤ 2 := by
    rw [abs_mul]
    simpa using mul_le_mul hp edge_sincDerivative_abs
      (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 1)
  calc
    _ = (19 / 2000 : ℝ) *
      |Real.sinc (fifteenthCenter / 2000) ^ 18 * sincDerivative (fifteenthCenter / 2000)| := by
      rw [abs_div, abs_mul, abs_mul]
      norm_num
      ring
    _ ≤ (19 / 2000 : ℝ) * 2 := mul_le_mul_of_nonneg_left h (by norm_num)
    _ = _ := by norm_num

theorem edge_factor_error :
    |(19 * Real.sinc (fifteenthCenter / 2000) ^ 18 * sincDerivative (fifteenthCenter / 2000) / 2000) -
      (19 * sincPolynomial7 (fifteenthCenter / 2000) ^ 18 * sincDerivativeP (fifteenthCenter / 2000) / 2000)| ≤
      (19 / 2000 : ℝ) * (1 / 10 ^ (56 : ℕ) + 18 / 10 ^ (34 : ℕ)) := by
  have hp : |Real.sinc (fifteenthCenter / 2000) ^ 18| ≤ 1 := by
    rw [abs_pow]
    exact pow_le_one₀ (abs_nonneg _) (Real.abs_sinc_le_one _)
  have h := product_error _ _ _ _ 1 1 _ _ hp edge_Dpoly_abs
    (edge_sinc_power_error 18) edge_D_error
  have hs := scale_error (19 / 2000) _ _ _ h
  convert hs using 1 <;> first | ring | norm_num

/-- Complete analytic error: every original finite term and sinc power is paid. -/
theorem correctionFirstFormula_surrogate_error :
    |correctionFirstFormula fifteenthCenter - scalar_surrogate fifteenthCenter| ≤
      (1 / 10 ^ (13 : ℕ) : ℝ) := by
  have h1 := product_error _ _ _ _ (1 / 25) 20000000 _ _
    hat_factor_abs hat_sumP_abs hat_factor_error hat_sum_error
  have hsh : |Real.sinc (fifteenthCenter / 100) ^ 2| ≤ 1 := by
    rw [abs_pow]
    exact pow_le_one₀ (abs_nonneg _) (Real.abs_sinc_le_one _)
  have h2 := product_error _ _ _ _ 1 100000000 _ _
    hsh hat_derivative_sumP_abs hat_sinc_square_error hat_derivative_sum_error
  have hh := scale_error (2 / 50) _ _ _ (sum_error _ _ _ _ _ _ h1 h2)
  have h3 := product_error _ _ _ _ (19 / 1000) 100000 _ _
    edge_factor_abs spline_sumP_abs edge_factor_error spline_sum_error
  have hse : |Real.sinc (fifteenthCenter / 2000) ^ 19| ≤ 1 := by
    rw [abs_pow]
    exact pow_le_one₀ (abs_nonneg _) (Real.abs_sinc_le_one _)
  have h4 := product_error _ _ _ _ 1 500000 _ _
    hse spline_derivative_sumP_abs (edge_sinc_power_error 19) spline_derivative_sum_error
  have h := sum_error _ _ _ _ _ _ (sum_error _ _ _ _ _ _ hh h3) h4
  change |correctionFirstFormula fifteenthCenter - scalar_surrogate fifteenthCenter| ≤ _
  refine h.trans ?_
  norm_num

theorem fifteenthCenter_k1_enclosure :
    |exactJetCoefficient fifteenthCenter 1 - (347860160497 / 10 ^ (12 : ℕ) : ℝ)| ≤
      (1 / 10 ^ (12 : ℕ) : ℝ) := by
  rw [exactJetCoefficient_one_firstFormula fifteenthCenter (ne_of_gt fifteenthCenter_pos)]
  have hs : |scalar_surrogate fifteenthCenter - (347860160497148 / 10 ^ (15 : ℕ) : ℝ)| ≤
      (1 / 10 ^ (14 : ℕ) : ℝ) := by
    have h := scalar_surrogate_cell15
    norm_num [fifteenthCenter] at h ⊢
    exact h
  have hnear : |(347860160497148 / 10 ^ (15 : ℕ) : ℝ) -
      (347860160497 / 10 ^ (12 : ℕ) : ℝ)| ≤ (148 / 10 ^ (15 : ℕ) : ℝ) := by norm_num
  have htotal := (abs_sub_le (correctionFirstFormula fifteenthCenter)
    (scalar_surrogate fifteenthCenter) (347860160497148 / 10 ^ (15 : ℕ))).trans
    (add_le_add correctionFirstFormula_surrogate_error hs)
  have hfinal := (abs_sub_le (correctionFirstFormula fifteenthCenter)
    (347860160497148 / 10 ^ (15 : ℕ)) (347860160497 / 10 ^ (12 : ℕ))).trans
    (add_le_add htotal hnear)
  exact hfinal.trans (by norm_num)

end AEGIS.RHKreinCell15AnalyticErrorOct7

#check @AEGIS.RHKreinCell15AnalyticErrorOct7.correctionFirstFormula_surrogate_error
#check @AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure
#print axioms AEGIS.RHKreinCell15AnalyticErrorOct7.correctionFirstFormula_surrogate_error
#print axioms AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure
