# Pointwise budgets at the public fifteenth midpoint

These thirteen premise-free bounds use the actual public PR53 midpoint c=5025/65536. They retain the existing degree-fifteen sine, degree-fourteen cosine, and degree-six sinc polynomials. No final derivative coefficient enclosure is asserted in these helper modules.

The generic exponential remainder with sixteen terms bounds both trig coordinates by E(x)=|x|^16*17/(16*16!). The phase module already proves every hat phase lies between zero and 48039/131072. Monotonicity of the sixteenth power and exact rational arithmetic therefore give every hat cosine error at most 10^(-20). The actual rational edge phase gives both sine and cosine errors at most 10^(-30).

The existing eight-term sine bound, divided by the positive sinc phase, gives errors at most 10^(-25) at c/100 and 10^(-34) at c/2000. Exact rational evaluation proves that both sinc polynomial values have absolute value at most one.

For the sinc derivative D(x)=(x*cos(x)-sin(x))/x^2, the helper polynomial is exactly Dp(x)=(x*cosPolynomial15(x)-sinPolynomial15(x))/x^2. Their difference has numerator x*(cos(x)-cosPolynomial15(x))-(sin(x)-sinPolynomial15(x)). The triangle inequality bounds this by |x|*E(x)+E(x), which is then divided by the proved-positive x^2. Exact rational substitution gives derivative errors at most 10^(-50) for c/100 and 10^(-56) for c/2000. Exact polynomial evaluation proves |Dp|≤1 at both phases. Adding the error proves |D|≤2 at both phases. All input positivity, absolute phase bounds, and numerical inequalities are discharged inside the pointwise theorems; no final error bound is taken as a premise.

Each module passed a fresh pinned --trust=0 compile and separate leanchecker replay. All thirteen endpoint axiom lists contain only propext, Classical.choice, and Quot.sound. The builds identify and reuse imported objects; they are not clean rebuilds of the whole transitive closure. The generic actual correction derivative is separately proved and checked. Composing these budgets with all original hat and spline coefficients is the parent assembly task.
