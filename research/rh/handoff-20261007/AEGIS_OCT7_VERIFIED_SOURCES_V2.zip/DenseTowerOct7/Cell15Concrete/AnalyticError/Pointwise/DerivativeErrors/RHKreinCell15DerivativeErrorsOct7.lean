import RHKreinCell15PhasesOct7
import RHKreinTrig15Sinc6PublicOct7
import RHKreinCorrectionDerivativeOct7

/-!
Pointwise derivative errors at the actual imported public fifteenth center.
These follow from the public order-16 exponential sine and cosine estimates.
No final correction coefficient enclosure or RH conclusion is asserted.
-/

set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 1500000
noncomputable section

namespace AEGIS.RHKreinCell15PointwiseOct7

open AEGIS.RHKreinCell15PhasesOct7
open AEGIS.RHKreinTrig15Sinc6PublicOct7
open AEGIS.RHKreinCorrectionDerivativeOct7

/-- Rational normal form for the quotient-based sinc derivative. -/
def sincDerivativePolynomial (x : ℝ) : ℝ :=
  (x * cosPolynomial15 x - sinPolynomial15 x) / x ^ 2

private theorem sincDerivative_error_exp16 (x : ℝ) (hx0 : 0 < x) (hx : |x| ≤ 1) :
    |sincDerivative x - sincDerivativePolynomial x| ≤
      (|x| * (|x| ^ 16 * (17 / (20922789888000 * 16) : ℝ)) +
        |x| ^ 16 * (17 / (20922789888000 * 16) : ℝ)) / x ^ 2 := by
  have hx2 : 0 < x ^ 2 := by positivity
  have hc := cos_degree15_error x hx
  have hs := sin_degree15_error x hx
  have hnum : x * Real.cos x - Real.sin x -
      (x * cosPolynomial15 x - sinPolynomial15 x) =
      x * (Real.cos x - cosPolynomial15 x) -
        (Real.sin x - sinPolynomial15 x) := by ring
  have hn : |x * (Real.cos x - cosPolynomial15 x) -
      (Real.sin x - sinPolynomial15 x)| ≤
      |x| * (|x| ^ 16 * (17 / (20922789888000 * 16) : ℝ)) +
        |x| ^ 16 * (17 / (20922789888000 * 16) : ℝ) := by
    calc
      |x * (Real.cos x - cosPolynomial15 x) -
          (Real.sin x - sinPolynomial15 x)| =
          |x * (Real.cos x - cosPolynomial15 x) +
            -(Real.sin x - sinPolynomial15 x)| := by rw [sub_eq_add_neg]
      _ ≤ |x * (Real.cos x - cosPolynomial15 x)| +
          |-(Real.sin x - sinPolynomial15 x)| := abs_add_le _ _
      _ = |x| * |Real.cos x - cosPolynomial15 x| +
          |Real.sin x - sinPolynomial15 x| := by rw [abs_mul, abs_neg]
      _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hc (abs_nonneg x)) hs
  unfold sincDerivative sincDerivativePolynomial
  rw [← sub_div, hnum, abs_div, abs_of_pos hx2]
  exact div_le_div_of_nonneg_right hn (le_of_lt hx2)

theorem hat_sincDerivative_error :
    |sincDerivative (fifteenthCenter / 100) -
        sincDerivativePolynomial (fifteenthCenter / 100)| ≤
      (1 / 10 ^ 50 : ℝ) := by
  have hx0 : 0 < fifteenthCenter / 100 := by norm_num [fifteenthCenter]
  have hx1 : |fifteenthCenter / 100| ≤ 1 := by norm_num [fifteenthCenter]
  have h := sincDerivative_error_exp16 (fifteenthCenter / 100) hx0 hx1
  refine h.trans ?_
  norm_num [fifteenthCenter]

theorem edge_sincDerivative_error :
    |sincDerivative (fifteenthCenter / 2000) -
        sincDerivativePolynomial (fifteenthCenter / 2000)| ≤
      (1 / 10 ^ 56 : ℝ) := by
  have hx0 : 0 < fifteenthCenter / 2000 := by norm_num [fifteenthCenter]
  have hx1 : |fifteenthCenter / 2000| ≤ 1 := by norm_num [fifteenthCenter]
  have h := sincDerivative_error_exp16 (fifteenthCenter / 2000) hx0 hx1
  refine h.trans ?_
  norm_num [fifteenthCenter]

theorem hat_sincDerivative_polynomial_abs :
    |sincDerivativePolynomial (fifteenthCenter / 100)| ≤ 1 := by
  norm_num [sincDerivativePolynomial, cosPolynomial15, sinPolynomial15, fifteenthCenter]

theorem edge_sincDerivative_polynomial_abs :
    |sincDerivativePolynomial (fifteenthCenter / 2000)| ≤ 1 := by
  norm_num [sincDerivativePolynomial, cosPolynomial15, sinPolynomial15, fifteenthCenter]

theorem hat_sincDerivative_abs :
    |sincDerivative (fifteenthCenter / 100)| ≤ 2 := by
  calc
    |sincDerivative (fifteenthCenter / 100)| =
        |(sincDerivative (fifteenthCenter / 100) -
          sincDerivativePolynomial (fifteenthCenter / 100)) +
          sincDerivativePolynomial (fifteenthCenter / 100)| := by congr 1; ring
    _ ≤ |sincDerivative (fifteenthCenter / 100) -
          sincDerivativePolynomial (fifteenthCenter / 100)| +
          |sincDerivativePolynomial (fifteenthCenter / 100)| := abs_add_le _ _
    _ ≤ (1 / 10 ^ 50 : ℝ) + 1 :=
      add_le_add hat_sincDerivative_error hat_sincDerivative_polynomial_abs
    _ ≤ 2 := by norm_num

theorem edge_sincDerivative_abs :
    |sincDerivative (fifteenthCenter / 2000)| ≤ 2 := by
  calc
    |sincDerivative (fifteenthCenter / 2000)| =
        |(sincDerivative (fifteenthCenter / 2000) -
          sincDerivativePolynomial (fifteenthCenter / 2000)) +
          sincDerivativePolynomial (fifteenthCenter / 2000)| := by congr 1; ring
    _ ≤ |sincDerivative (fifteenthCenter / 2000) -
          sincDerivativePolynomial (fifteenthCenter / 2000)| +
          |sincDerivativePolynomial (fifteenthCenter / 2000)| := abs_add_le _ _
    _ ≤ (1 / 10 ^ 56 : ℝ) + 1 :=
      add_le_add edge_sincDerivative_error edge_sincDerivative_polynomial_abs
    _ ≤ 2 := by norm_num

end AEGIS.RHKreinCell15PointwiseOct7

#check @AEGIS.RHKreinCell15PointwiseOct7.hat_sincDerivative_error
#check @AEGIS.RHKreinCell15PointwiseOct7.edge_sincDerivative_error
#check @AEGIS.RHKreinCell15PointwiseOct7.hat_sincDerivative_polynomial_abs
#check @AEGIS.RHKreinCell15PointwiseOct7.edge_sincDerivative_polynomial_abs
#check @AEGIS.RHKreinCell15PointwiseOct7.hat_sincDerivative_abs
#check @AEGIS.RHKreinCell15PointwiseOct7.edge_sincDerivative_abs
#print axioms AEGIS.RHKreinCell15PointwiseOct7.hat_sincDerivative_error
#print axioms AEGIS.RHKreinCell15PointwiseOct7.edge_sincDerivative_error
#print axioms AEGIS.RHKreinCell15PointwiseOct7.hat_sincDerivative_polynomial_abs
#print axioms AEGIS.RHKreinCell15PointwiseOct7.edge_sincDerivative_polynomial_abs
#print axioms AEGIS.RHKreinCell15PointwiseOct7.hat_sincDerivative_abs
#print axioms AEGIS.RHKreinCell15PointwiseOct7.edge_sincDerivative_abs
