import RHKreinCell15PhasesOct7
import RHKreinCorrectionDerivativeOct7

/-!
Premise-free exact analytic budgets at the actual public fifteenth midpoint.
The existing degree-six sinc and degree-fifteen trig polynomials are reused.
No final coefficient enclosure or RH conclusion is asserted by this module.
-/

set_option autoImplicit false
set_option maxRecDepth 8192
set_option maxHeartbeats 1500000
noncomputable section

namespace AEGIS.RHKreinCell15PointwiseOct7

open AEGIS.RHKreinCell15PhasesOct7
open AEGIS.RHKreinSincIntervalV1
open AEGIS.RHKreinTrig15Sinc6PublicOct7
open AEGIS.RHKreinExplicitCorrectionV1

theorem hat_sinc_polynomial_abs :
    |sincPolynomial7 (fifteenthCenter / 100)| ≤ (1 : ℝ) := by
  norm_num [fifteenthCenter, sincPolynomial7]

theorem edge_sinc_polynomial_abs :
    |sincPolynomial7 (fifteenthCenter / 2000)| ≤ (1 : ℝ) := by
  norm_num [fifteenthCenter, sincPolynomial7]

theorem hat_sinc_error :
    |Real.sinc (fifteenthCenter / 100) -
        sincPolynomial7 (fifteenthCenter / 100)| ≤
      (1 / 10 ^ 25 : ℝ) := by
  exact fifteenthCenter_hat_sinc_error.trans (by norm_num [fifteenthCenter])

theorem edge_sinc_error :
    |Real.sinc (fifteenthCenter / 2000) -
        sincPolynomial7 (fifteenthCenter / 2000)| ≤
      (1 / 10 ^ 34 : ℝ) := by
  exact fifteenthCenter_edge_sinc_error.trans (by norm_num [fifteenthCenter])

theorem hat_cosine_uniform_error (j : Fin 199) :
    |Real.cos (fifteenthCenter * hatCenter j) -
        cosPolynomial15 (fifteenthCenter * hatCenter j)| ≤
      (1 / 10 ^ 20 : ℝ) := by
  have h := fifteenthCenter_hat_cosine_error j
  have hx : |fifteenthCenter * hatCenter j| ≤
      (48039 / 131072 : ℝ) := by
    simpa [abs_of_nonneg (fifteenthCenter_hat_phase j).1] using
      (fifteenthCenter_hat_phase j).2
  have hp := pow_le_pow_left₀
    (abs_nonneg (fifteenthCenter * hatCenter j)) hx 16
  refine h.trans ?_
  calc
    |fifteenthCenter * hatCenter j| ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) ≤
      (48039 / 131072 : ℝ) ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) :=
      mul_le_mul_of_nonneg_right hp (by positivity)
    _ ≤ _ := by norm_num

theorem edge_sine_uniform_error :
    |Real.sin (fifteenthCenter * (1619 / 2000 : ℝ)) -
        sinPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 10 ^ 30 : ℝ) := by
  exact fifteenthCenter_edge_sine_error.trans (by norm_num [fifteenthCenter])

theorem edge_cosine_uniform_error :
    |Real.cos (fifteenthCenter * (1619 / 2000 : ℝ)) -
        cosPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 10 ^ 30 : ℝ) := by
  exact fifteenthCenter_edge_cosine_error.trans (by norm_num [fifteenthCenter])

end AEGIS.RHKreinCell15PointwiseOct7

#check @AEGIS.RHKreinCell15PointwiseOct7.hat_sinc_polynomial_abs
#check @AEGIS.RHKreinCell15PointwiseOct7.edge_sinc_polynomial_abs
#check @AEGIS.RHKreinCell15PointwiseOct7.hat_sinc_error
#check @AEGIS.RHKreinCell15PointwiseOct7.edge_sinc_error
#check @AEGIS.RHKreinCell15PointwiseOct7.hat_cosine_uniform_error
#check @AEGIS.RHKreinCell15PointwiseOct7.edge_sine_uniform_error
#check @AEGIS.RHKreinCell15PointwiseOct7.edge_cosine_uniform_error
#print axioms AEGIS.RHKreinCell15PointwiseOct7.hat_sinc_polynomial_abs
#print axioms AEGIS.RHKreinCell15PointwiseOct7.edge_sinc_polynomial_abs
#print axioms AEGIS.RHKreinCell15PointwiseOct7.hat_sinc_error
#print axioms AEGIS.RHKreinCell15PointwiseOct7.edge_sinc_error
#print axioms AEGIS.RHKreinCell15PointwiseOct7.hat_cosine_uniform_error
#print axioms AEGIS.RHKreinCell15PointwiseOct7.edge_sine_uniform_error
#print axioms AEGIS.RHKreinCell15PointwiseOct7.edge_cosine_uniform_error
