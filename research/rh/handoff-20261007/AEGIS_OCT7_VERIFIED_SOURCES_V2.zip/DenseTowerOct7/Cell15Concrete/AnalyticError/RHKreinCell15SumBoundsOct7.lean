import RHKreinCell15PointwiseOct7
import RHKreinCorrectionDerivativeOct7
import RHKreinCell15ScalarBudgetOct7
import AEGISOverlay.RHKreinRationalCertificateV1

set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
noncomputable section

namespace AEGIS.RHKreinCell15SumBoundsOct7

open AEGIS.RHKreinCell15PhasesOct7
open AEGIS.RHKreinCell15PointwiseOct7
open AEGIS.RHKreinCorrectionDerivativeOct7
open AEGIS.RHKreinCell15ScalarBudgetOct7
open AEGIS.RHKreinExplicitCorrectionV1
open scoped BigOperators

theorem weighted_sum_error {ι : Type*} [Fintype ι]
    (a x y : ι → ℝ) (e : ℝ) (h : ∀ i, |x i - y i| ≤ e) :
    |(∑ i, a i * x i) - (∑ i, a i * y i)| ≤ (∑ i, |a i|) * e := by
  rw [← Finset.sum_sub_distrib, Finset.sum_mul]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro i _
  rw [← mul_sub, abs_mul]
  exact mul_le_mul_of_nonneg_left (h i) (abs_nonneg _)

theorem weighted_sum_abs {ι : Type*} [Fintype ι]
    (a x : ι → ℝ) (B : ℝ) (h : ∀ i, |x i| ≤ B) :
    |∑ i, a i * x i| ≤ (∑ i, |a i|) * B := by
  rw [Finset.sum_mul]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro i _
  rw [abs_mul]
  exact mul_le_mul_of_nonneg_left (h i) (abs_nonneg _)

theorem approx_abs (x p A e : ℝ) (hx : |x| ≤ A) (hxp : |x - p| ≤ e) :
    |p| ≤ A + e := by
  calc
    |p| = |x - (x - p)| := by congr 1; ring
    _ ≤ |x| + |x - p| := by
      simpa only [sub_eq_add_neg, abs_neg] using abs_add_le x (-(x - p))
    _ ≤ A + e := add_le_add hx hxp

theorem hat_center_abs (j : Fin 199) : |hatCenter j| ≤ 5 := by
  have hjNat : j.val ≤ 198 := by omega
  have hj : (j.val : ℝ) ≤ 198 := by exact_mod_cast hjNat
  have hu0 : 0 ≤ hatCenter j := by unfold hatCenter; positivity
  rw [abs_of_nonneg hu0]
  unfold hatCenter
  norm_num
  linarith

theorem hat_weight : (∑ j : Fin 199, |(hatCoefficient j : ℝ)|) ≤ 18125000 :=
  AEGIS.RHKreinRationalCertificateV1.hat_coefficient_budget

theorem spline_weight : (∑ j : Fin 5, |(splineCoefficient j : ℝ)|) ≤ 60000 := by
  norm_num [splineCoefficient, Fin.sum_univ_succ]

theorem hat_sum_abs : |hatSum fifteenthCenter| ≤ 18125000 := by
  have h := weighted_sum_abs (fun j : Fin 199 => (hatCoefficient j : ℝ))
    (fun j => Real.cos (fifteenthCenter * hatCenter j)) 1
    (fun j => Real.abs_cos_le_one _)
  simpa only [hatSum, mul_one] using h.trans (by simpa using hat_weight)

theorem hat_sum_error :
    |hatSum fifteenthCenter - hatSumP fifteenthCenter| ≤
      (18125000 / 10 ^ (20 : ℕ) : ℝ) := by
  have h := weighted_sum_error (fun j : Fin 199 => (hatCoefficient j : ℝ))
    (fun j => Real.cos (fifteenthCenter * hatCenter j))
    (fun j => AEGIS.RHKreinTrig15Sinc6PublicOct7.cosPolynomial15
      (fifteenthCenter * hatCenter j)) (1 / 10 ^ (20 : ℕ))
    (fun j => by simpa using hat_cosine_uniform_error j)
  refine h.trans ?_
  simpa [div_eq_mul_inv] using
    mul_le_mul_of_nonneg_right hat_weight (by positivity : (0 : ℝ) ≤ 1 / 10 ^ (20 : ℕ))

theorem hat_derivative_term_abs (j : Fin 199) :
    |-hatCenter j * Real.sin (fifteenthCenter * hatCenter j)| ≤ 5 := by
  calc
    _ = |hatCenter j| * |Real.sin (fifteenthCenter * hatCenter j)| := by
      rw [abs_mul, abs_neg]
    _ ≤ 5 * 1 := mul_le_mul (hat_center_abs j) (Real.abs_sin_le_one _)
      (abs_nonneg _) (by norm_num)
    _ = 5 := by norm_num

theorem hat_derivative_sum_abs : |hatSumDerivative fifteenthCenter| ≤ 90625000 := by
  have h := weighted_sum_abs (fun j : Fin 199 => (hatCoefficient j : ℝ))
    (fun j => -hatCenter j * Real.sin (fifteenthCenter * hatCenter j)) 5
    hat_derivative_term_abs
  exact h.trans (by nlinarith [hat_weight])

theorem hat_derivative_sum_error :
    |hatSumDerivative fifteenthCenter - hatSumDerivativeP fifteenthCenter| ≤
      (90625000 / 10 ^ (20 : ℕ) : ℝ) := by
  have hjerr (j : Fin 199) :
      |-hatCenter j * Real.sin (fifteenthCenter * hatCenter j) -
          -hatCenter j * AEGIS.RHKreinTrig15Sinc6PublicOct7.sinPolynomial15
            (fifteenthCenter * hatCenter j)| ≤ (5 / 10 ^ (20 : ℕ) : ℝ) := by
    rw [← mul_sub, abs_mul, abs_neg]
    have h := mul_le_mul (hat_center_abs j) (fifteenthCenter_hat_sine_uniform_error j)
      (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 5)
    norm_num at h ⊢
    exact h
  have h := weighted_sum_error (fun j : Fin 199 => (hatCoefficient j : ℝ))
    (fun j => -hatCenter j * Real.sin (fifteenthCenter * hatCenter j))
    (fun j => -hatCenter j * AEGIS.RHKreinTrig15Sinc6PublicOct7.sinPolynomial15
      (fifteenthCenter * hatCenter j)) (5 / 10 ^ (20 : ℕ)) hjerr
  refine h.trans ?_
  have hb := mul_le_mul_of_nonneg_right hat_weight
    (by positivity : (0 : ℝ) ≤ 5 / 10 ^ (20 : ℕ))
  norm_num at hb ⊢
  exact hb

theorem hat_sumP_abs : |hatSumP fifteenthCenter| ≤ 20000000 := by
  have h := approx_abs _ _ _ _ hat_sum_abs hat_sum_error
  exact h.trans (by norm_num)

theorem hat_derivative_sumP_abs : |hatSumDerivativeP fifteenthCenter| ≤ 100000000 := by
  have h := approx_abs _ _ _ _ hat_derivative_sum_abs hat_derivative_sum_error
  exact h.trans (by norm_num)

theorem center_power_abs (n : ℕ) : |fifteenthCenter ^ n| ≤ 1 := by
  rw [abs_pow]
  exact pow_le_one₀ (abs_nonneg _) (by norm_num [fifteenthCenter])

theorem spline_phase_abs (j : Fin 5) : |splinePhase j fifteenthCenter| ≤ 1 := by
  unfold splinePhase
  split_ifs
  · exact Real.abs_cos_le_one _
  · exact Real.abs_sin_le_one _

theorem spline_phase_derivative_abs (j : Fin 5) :
    |splinePhaseDerivative j fifteenthCenter| ≤ 1 := by
  unfold splinePhaseDerivative
  split_ifs <;> rw [abs_mul]
  · norm_num
    exact (mul_le_mul_of_nonneg_left (Real.abs_sin_le_one _) (by norm_num)).trans
      (by norm_num)
  · norm_num
    exact (mul_le_mul_of_nonneg_left (Real.abs_cos_le_one _) (by norm_num)).trans
      (by norm_num)

theorem spline_phase_error (j : Fin 5) :
    |splinePhase j fifteenthCenter - splinePhaseP j fifteenthCenter| ≤
      (1 / 10 ^ (30 : ℕ) : ℝ) := by
  unfold splinePhase splinePhaseP
  split_ifs
  · simpa using edge_cosine_uniform_error
  · simpa using edge_sine_uniform_error

theorem spline_phase_derivative_error (j : Fin 5) :
    |splinePhaseDerivative j fifteenthCenter - splinePhaseDerivativeP j fifteenthCenter| ≤
      (1 / 10 ^ (30 : ℕ) : ℝ) := by
  unfold splinePhaseDerivative splinePhaseDerivativeP
  split_ifs <;> rw [← mul_sub, abs_mul]
  · norm_num
    have h := mul_le_mul_of_nonneg_left edge_sine_uniform_error
      (by norm_num : (0 : ℝ) ≤ 1619 / 2000)
    exact h.trans (by norm_num)
  · norm_num
    have h := mul_le_mul_of_nonneg_left edge_cosine_uniform_error
      (by norm_num : (0 : ℝ) ≤ 1619 / 2000)
    exact h.trans (by norm_num)

theorem spline_sum_abs : |splineSum fifteenthCenter| ≤ 60000 := by
  have h := weighted_sum_abs (fun j : Fin 5 => (splineCoefficient j : ℝ))
    (fun j => fifteenthCenter ^ j.val * splinePhase j fifteenthCenter) 1
    (fun j => by
      rw [abs_mul]
      simpa using mul_le_mul (center_power_abs j.val) (spline_phase_abs j)
        (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 1))
  simpa [splineSum, mul_assoc] using h.trans (by simpa using spline_weight)

theorem spline_sum_error :
    |splineSum fifteenthCenter - splineSumP fifteenthCenter| ≤
      (60000 / 10 ^ (30 : ℕ) : ℝ) := by
  have h := weighted_sum_error (fun j : Fin 5 => (splineCoefficient j : ℝ))
    (fun j => fifteenthCenter ^ j.val * splinePhase j fifteenthCenter)
    (fun j => fifteenthCenter ^ j.val * splinePhaseP j fifteenthCenter)
    (1 / 10 ^ (30 : ℕ)) (fun j => by
      rw [← mul_sub, abs_mul]
      simpa using mul_le_mul (center_power_abs j.val) (spline_phase_error j)
        (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 1))
  have hb := mul_le_mul_of_nonneg_right spline_weight
    (by positivity : (0 : ℝ) ≤ 1 / 10 ^ (30 : ℕ))
  have hb' : (∑ j : Fin 5, |(splineCoefficient j : ℝ)|) *
      (1 / 10 ^ (30 : ℕ) : ℝ) ≤ (60000 / 10 ^ (30 : ℕ) : ℝ) := by
    simpa [div_eq_mul_inv] using hb
  simpa only [splineSum, splineSumP, mul_assoc] using h.trans hb'

theorem index_four (j : Fin 5) : |(j.val : ℝ)| ≤ 4 := by
  have hj : j.val ≤ 4 := by omega
  exact_mod_cast hj

theorem spline_derivative_term_abs (j : Fin 5) :
    |(j.val : ℝ) * fifteenthCenter ^ (j.val - 1) * splinePhase j fifteenthCenter +
      fifteenthCenter ^ j.val * splinePhaseDerivative j fifteenthCenter| ≤ 5 := by
  have ha : |(j.val : ℝ) * fifteenthCenter ^ (j.val - 1)| ≤ 4 := by
    rw [abs_mul]
    simpa using mul_le_mul (index_four j) (center_power_abs _) (abs_nonneg _)
      (by norm_num : (0 : ℝ) ≤ 4)
  have hb : |(j.val : ℝ) * fifteenthCenter ^ (j.val - 1) * splinePhase j fifteenthCenter| ≤ 4 := by
    rw [abs_mul]
    simpa using mul_le_mul ha (spline_phase_abs j) (abs_nonneg _)
      (by norm_num : (0 : ℝ) ≤ 4)
  have hc : |fifteenthCenter ^ j.val * splinePhaseDerivative j fifteenthCenter| ≤ 1 := by
    rw [abs_mul]
    simpa using mul_le_mul (center_power_abs _) (spline_phase_derivative_abs j)
      (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 1)
  exact (abs_add_le _ _).trans (by linarith)

theorem spline_derivative_sum_abs : |splineSumDerivative fifteenthCenter| ≤ 300000 := by
  have h := weighted_sum_abs (fun j : Fin 5 => (splineCoefficient j : ℝ))
    (fun j => (j.val : ℝ) * fifteenthCenter ^ (j.val - 1) * splinePhase j fifteenthCenter +
      fifteenthCenter ^ j.val * splinePhaseDerivative j fifteenthCenter) 5
    spline_derivative_term_abs
  exact h.trans (by nlinarith [spline_weight])

theorem spline_derivative_sum_error :
    |splineSumDerivative fifteenthCenter - splineSumDerivativeP fifteenthCenter| ≤
      (300000 / 10 ^ (30 : ℕ) : ℝ) := by
  have hjerr (j : Fin 5) :
      |((j.val : ℝ) * fifteenthCenter ^ (j.val - 1) * splinePhase j fifteenthCenter +
          fifteenthCenter ^ j.val * splinePhaseDerivative j fifteenthCenter) -
        ((j.val : ℝ) * fifteenthCenter ^ (j.val - 1) * splinePhaseP j fifteenthCenter +
          fifteenthCenter ^ j.val * splinePhaseDerivativeP j fifteenthCenter)| ≤
        (5 / 10 ^ (30 : ℕ) : ℝ) := by
    have ha : |(j.val : ℝ) * fifteenthCenter ^ (j.val - 1)| ≤ 4 := by
      rw [abs_mul]
      simpa using mul_le_mul (index_four j) (center_power_abs _) (abs_nonneg _)
        (by norm_num : (0 : ℝ) ≤ 4)
    have hb := mul_le_mul ha (spline_phase_error j) (abs_nonneg _)
      (by norm_num : (0 : ℝ) ≤ 4)
    have hc := mul_le_mul (center_power_abs j.val) (spline_phase_derivative_error j)
      (abs_nonneg _) (by norm_num : (0 : ℝ) ≤ 1)
    calc
      _ = |(j.val : ℝ) * fifteenthCenter ^ (j.val - 1) *
            (splinePhase j fifteenthCenter - splinePhaseP j fifteenthCenter) +
          fifteenthCenter ^ j.val *
            (splinePhaseDerivative j fifteenthCenter - splinePhaseDerivativeP j fifteenthCenter)| := by
        congr 1; ring
      _ ≤ _ := abs_add_le _ _
      _ ≤ 4 * (1 / 10 ^ (30 : ℕ)) + 1 * (1 / 10 ^ (30 : ℕ)) := by
        simpa only [abs_mul] using add_le_add hb hc
      _ = _ := by ring
  have h := weighted_sum_error (fun j : Fin 5 => (splineCoefficient j : ℝ)) _ _
    (5 / 10 ^ (30 : ℕ)) hjerr
  refine h.trans ?_
  have hb := mul_le_mul_of_nonneg_right spline_weight
    (by positivity : (0 : ℝ) ≤ 5 / 10 ^ (30 : ℕ))
  norm_num at hb ⊢
  exact hb

theorem spline_sumP_abs : |splineSumP fifteenthCenter| ≤ 100000 := by
  have h := approx_abs _ _ _ _ spline_sum_abs spline_sum_error
  exact h.trans (by norm_num)

theorem spline_derivative_sumP_abs : |splineSumDerivativeP fifteenthCenter| ≤ 500000 := by
  have h := approx_abs _ _ _ _ spline_derivative_sum_abs spline_derivative_sum_error
  exact h.trans (by norm_num)

end AEGIS.RHKreinCell15SumBoundsOct7

#print axioms AEGIS.RHKreinCell15SumBoundsOct7.weighted_sum_error
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.weighted_sum_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.approx_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_center_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_weight
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_weight
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_sum_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_sum_error
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_derivative_term_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_derivative_sum_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_derivative_sum_error
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_sumP_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.hat_derivative_sumP_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.center_power_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_phase_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_phase_derivative_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_phase_error
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_phase_derivative_error
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_sum_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_sum_error
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.index_four
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_derivative_term_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_derivative_sum_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_derivative_sum_error
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_sumP_abs
#print axioms AEGIS.RHKreinCell15SumBoundsOct7.spline_derivative_sumP_abs
