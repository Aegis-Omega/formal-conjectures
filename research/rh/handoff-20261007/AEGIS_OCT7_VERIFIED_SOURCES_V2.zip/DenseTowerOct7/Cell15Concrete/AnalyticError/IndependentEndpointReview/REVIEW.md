# Independent audit of the actual fifteenth-cell k=1 endpoint

PASS for the new canonical actual coefficient endpoint. An independently
invoked fresh replay compiled the frozen final source with `--trust=0`, printed
both full endpoint types and axiom lists, and ran the pinned `leanchecker`.
Both endpoint axiom lists are exactly `propext`, `Classical.choice`, `Quot.sound`.
The source and script hashes agree across both runs. The two raw OLEAN hashes
differ only in five bytes of the embedded absolute fresh-source pathname:
every byte outside that exact pathname is identical. The artifacts were not
modified; both raw object identities are recorded separately.

The final proposition has no premises:

```lean
|AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient
     AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter 1
   - (347860160497 / 10^12 : ℝ)| ≤ 1 / 10^12
```

The center is exactly `5025/65536`. The separately checked literal payload
theorem identifies its cell as public zero-based entry 14, with endpoints
`2475/32768` and `1275/16384` and payload value `292616690003685633`.
This is the one-based fifteenth cell. The jet is the actual normalized ordinary
derivative of the unchanged public `correctionSymbol`.

I read the complete chain: generic actual derivative, center/phase identities,
pointwise trig/sinc/derivative budgets, complete finite-sum bounds, exact signed
moments and their factorization, scalar evaluation, and final product/power
assembly. All 199 original hats and all five original spline coefficients
remain present. The previous independent literal coefficient audit additionally
compares those imported vectors to the public source literals. Both chain
factors `1/100` and `1/2000`, negative cosine derivative signs, the zero-degree
polynomial case, power-19 derivative coupling, and the undifferentiated power-19
term are retained.

The weighted-sum error theorem controls complete signed sums using proved
absolute coefficient budgets. Product error expands
`ab-ap*bp = a*(b-bp)+(a-ap)*bp` and pays both terms. The existing power-error
theorem pays every power contribution using independently established bounds
for actual sinc and its polynomial. The final module includes all four pieces:
hat sinc derivative times H, hat sinc square times H-prime, edge sinc
derivative/power18 times E, and edge power19 times E-prime. Its analytic error
bound is `10⁻¹³`, with every hypothesis discharged. No numerical JSON, receipt
predicate, `hformula`, RH-equivalent sign input, or floating-point decision is
used in the Lean proof.

Kernel arithmetic bounds the exact scalar surrogate within `10⁻¹⁴` of
`347860160497148/10¹⁵`. That rational differs from the serialized jet target by
exactly `148/10¹⁵`. The final triangle inequality pays
`10⁻¹³ + 10⁻¹⁴ + 148/10¹⁵ = 258/10¹⁵ < 10⁻¹²`.
This closes the requested serialized k=1 radius. It does not kernel-prove the
much narrower two-unit/10¹⁵ interval reported earlier for v33, or the particular
reported Fraction width and margin.

Recovered original source bytes are now available through `LibraryTransfer`.
Their hashes match its transfer records. The original reduction has the same
cell, center, k=1 target `347860160497/10¹²`, and radius `1/10¹²`. The original
first-derivative formula has the same full terms; its multiplication by the
scaled sinc derivatives agrees algebraically with the new division constants.
An explicitly named `RecoveredLiteral` diagnostic in this review folder also
compiles literal-definition comparisons. It is not accepted as a build of the
original module namespace. Actual-original-namespace transport is
`TYPECHECK_PENDING` in this review, and the original full dependency build is
not claimed. The restored source tree permits the parent to perform that build.

The frozen replay script has a stale introductory docstring saying it is not a
coefficient enclosure. Its actual commands, source, full printed types, and
receipts check precisely the enclosure above. Its `reported_zip_available:false`
refers to the raw ZIP container; original source bytes are now restored. This
review preserves the frozen receipts and distinguishes these scopes.

Scope: independent same-host fresh endpoint compile and separate kernel
checker, with identified imports reused. This is not an independent-machine
replay or a clean rebuild of the entire transitive closure. Whole-cell
soundness, all-cell semantics, global Weil positivity, and RH are not concluded
by this endpoint review.
