import RHKreinCell15AnalyticErrorOct7

/-! NEW literal-definition compatibility audit. The definitions below are
copied byte-for-byte from the recovered source blocks into an audit namespace.
This does not import or assert compilation of the original full dependency tree.
The actual correction symbol and exact jet definitions remain the imported
public objects. -/

set_option autoImplicit false
set_option maxRecDepth 8192
set_option maxHeartbeats 1500000
noncomputable section

namespace AEGIS.RHKreinCell15EndpointIdentityAuditOct7
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinCorrectionDerivativeOct7
open scoped BigOperators
namespace RecoveredLiteral
def fifteenthCell : FiniteCellV1 :=
  ⟨2475 / 32768, 1275 / 16384, 292616690003685633⟩

def fifteenthCenter : ℝ := 5025 / 65536
def fifteenthRadius : ℝ := 75 / 65536

def fifteenthJet : ℕ → ℝ
  | 0 => 416165963423 / 1000000000000
  | 1 => 347860160497 / 1000000000000
  | 2 => 1158807525507 / 500000000000
  | 3 => 8015489529 / 12500000000
  | 4 => 51983766003 / 25000000000
  | 5 => -5642042579 / 62500000000
  | 6 => -207036090341 / 1000000000000
  | 7 => -7422888411 / 125000000000
  | _ => 0

def fifteenthJetError (_ : ℕ) : ℝ := 1 / 1000000000000
def fifteenthSymbolLower : ℝ := -313119 / 50000
def fifteenthWeightUpper : ℝ := 4724429978091121 / 72057594037927936

def hatColumnDerivative (j : Fin 199) : ℝ :=
  (hatCoefficient j : ℝ) *
    (-(Real.sin (fifteenthCenter * hatCenter j) * hatCenter j))

def edgePhaseDerivative (j : Fin 5) : ℝ :=
  if j.val % 2 = 0 then
    -(Real.sin (fifteenthCenter * (1619 / 2000)) * (1619 / 2000))
  else
    Real.cos (fifteenthCenter * (1619 / 2000)) * (1619 / 2000)

def edgeColumnDerivative (j : Fin 5) : ℝ :=
  (splineCoefficient j : ℝ) *
    (((j.val : ℝ) * fifteenthCenter ^ (j.val - 1)) *
        (if j.val % 2 = 0 then
          Real.cos (fifteenthCenter * (1619 / 2000))
        else
          Real.sin (fifteenthCenter * (1619 / 2000))) +
      fifteenthCenter ^ j.val * edgePhaseDerivative j)

def fifteenthHatSincDerivative : ℝ :=
  ((fifteenthCenter / 100) * Real.cos (fifteenthCenter / 100) -
      Real.sin (fifteenthCenter / 100)) / (fifteenthCenter / 100) ^ 2 *
    (1 / 100)

def fifteenthEdgeSincDerivative : ℝ :=
  ((fifteenthCenter / 2000) * Real.cos (fifteenthCenter / 2000) -
      Real.sin (fifteenthCenter / 2000)) / (fifteenthCenter / 2000) ^ 2 *
    (1 / 2000)

def fifteenthCorrectionDerivativeFormula : ℝ :=
  (2 / 50) *
      ((2 * Real.sinc (fifteenthCenter / 100) * fifteenthHatSincDerivative) *
          (∑ j : Fin 199, (hatCoefficient j : ℝ) *
            Real.cos (fifteenthCenter * hatCenter j)) +
        Real.sinc (fifteenthCenter / 100) ^ 2 *
          (∑ j : Fin 199, hatColumnDerivative j)) +
    (19 * Real.sinc (fifteenthCenter / 2000) ^ 18 *
        fifteenthEdgeSincDerivative) *
      (∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
        (if j.val % 2 = 0 then
          Real.cos (fifteenthCenter * (1619 / 2000))
        else
          Real.sin (fifteenthCenter * (1619 / 2000)))) +
    Real.sinc (fifteenthCenter / 2000) ^ 19 *
      (∑ j : Fin 5, edgeColumnDerivative j)

end RecoveredLiteral

theorem center_literal_identity :
    RecoveredLiteral.fifteenthCenter =
      AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter := rfl

theorem cell_literal_identity :
    RecoveredLiteral.fifteenthCell =
      AEGIS.RHKreinCell15PhasesOct7.fifteenthCell := rfl

theorem target_literal_identity :
    RecoveredLiteral.fifteenthJet 1 = (347860160497 / 10 ^ (12 : ℕ) : ℝ) := by
  norm_num [RecoveredLiteral.fifteenthJet]

theorem error_literal_identity :
    RecoveredLiteral.fifteenthJetError 1 = (1 / 10 ^ (12 : ℕ) : ℝ) := by
  norm_num [RecoveredLiteral.fifteenthJetError]

theorem recovered_original_k1_target_closed :
    |exactJetCoefficient RecoveredLiteral.fifteenthCenter 1 -
        RecoveredLiteral.fifteenthJet 1| ≤ RecoveredLiteral.fifteenthJetError 1 := by
  rw [center_literal_identity, target_literal_identity, error_literal_identity]
  exact AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure

private theorem hat_derivative_literal_identity :
    hatSumDerivative RecoveredLiteral.fifteenthCenter =
      ∑ j : Fin 199, RecoveredLiteral.hatColumnDerivative j := by
  unfold hatSumDerivative
  apply Finset.sum_congr rfl
  intro j _
  unfold RecoveredLiteral.hatColumnDerivative
  ring

private theorem phase_derivative_literal_identity (j : Fin 5) :
    splinePhaseDerivative j RecoveredLiteral.fifteenthCenter =
      RecoveredLiteral.edgePhaseDerivative j := by
  unfold splinePhaseDerivative RecoveredLiteral.edgePhaseDerivative
  split_ifs <;> ring

private theorem spline_derivative_literal_identity :
    splineSumDerivative RecoveredLiteral.fifteenthCenter =
      ∑ j : Fin 5, RecoveredLiteral.edgeColumnDerivative j := by
  unfold splineSumDerivative
  apply Finset.sum_congr rfl
  intro j _
  rw [phase_derivative_literal_identity]
  rfl

theorem recovered_formula_literal_identity :
    correctionFirstFormula RecoveredLiteral.fifteenthCenter =
      RecoveredLiteral.fifteenthCorrectionDerivativeFormula := by
  unfold correctionFirstFormula
  rw [hat_derivative_literal_identity, spline_derivative_literal_identity]
  unfold RecoveredLiteral.fifteenthCorrectionDerivativeFormula
    RecoveredLiteral.fifteenthHatSincDerivative
    RecoveredLiteral.fifteenthEdgeSincDerivative
    sincDerivative hatSum splineSum splinePhase
  ring

end AEGIS.RHKreinCell15EndpointIdentityAuditOct7

#check @AEGIS.RHKreinCell15EndpointIdentityAuditOct7.recovered_original_k1_target_closed
#check @AEGIS.RHKreinCell15EndpointIdentityAuditOct7.recovered_formula_literal_identity
#print axioms AEGIS.RHKreinCell15EndpointIdentityAuditOct7.center_literal_identity
#print axioms AEGIS.RHKreinCell15EndpointIdentityAuditOct7.cell_literal_identity
#print axioms AEGIS.RHKreinCell15EndpointIdentityAuditOct7.target_literal_identity
#print axioms AEGIS.RHKreinCell15EndpointIdentityAuditOct7.error_literal_identity
#print axioms AEGIS.RHKreinCell15EndpointIdentityAuditOct7.recovered_original_k1_target_closed
#print axioms AEGIS.RHKreinCell15EndpointIdentityAuditOct7.recovered_formula_literal_identity
