#!/usr/bin/env python3
"""Scoped rejection tests; does not turn the arithmetic script into a proof."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'exact_fraction_sine17_reconstruction.py'


def run_cases():
    spec = importlib.util.spec_from_file_location('cell15_exact', SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    cases = []

    def reject(name, action):
        try:
            action()
        except (ValueError, ZeroDivisionError):
            cases.append({'case': name, 'rejected': True})
            return
        raise RuntimeError('Malformed input accepted: ' + name)

    reject('nonliteral_rational', lambda: module.rational('1+1'))
    reject('zero_denominator', lambda: module.rational('1/0'))
    reject('reversed_interval', lambda: module.I(2, 1))
    reject('zero_crossing_divisor', lambda: module.I(1) / module.I(-1, 1))
    reject('negative_power', lambda: module.I(1) ** -1)
    reject('sine_outside_domain', lambda: module.trig(2, True))
    reject('cosine_outside_domain', lambda: module.trig(-2, False))
    reject('zero_sinc_argument', lambda: module.sinc(0))
    reject('negative_sinc_argument', lambda: module.sinc(-1))
    reject('zero_derivative_argument', lambda: module.sinc_derivative(0))
    reject('missing_vector', lambda: module.coefficient_vector('', 'hatCoefficient', 199))
    reject('wrong_vector_length', lambda: module.coefficient_vector(
        'def hatCoefficient : Fin 199 -> Real :=\n ![1,2]', 'hatCoefficient', 199))
    reject('empty_intersection', lambda: module.I(2, 3).bounded(-1, 1))
    original_symbol, original_cells = module.SYMBOL, module.CELLS
    with tempfile.TemporaryDirectory(prefix='aegis-cell15-negative-') as tmp:
        altered = Path(tmp) / 'changed-symbol.lean'
        altered.write_bytes(original_symbol.read_bytes() + b'\n')
        module.SYMBOL = altered
        reject('changed_source_blob', module.main)
        module.SYMBOL = original_symbol
        changed_cells = Path(tmp) / 'changed-cells.lean'
        cells = original_cells.read_text()
        changed = cells.replace('292616690003685633', '292616690003685634')
        if cells == changed:
            raise RuntimeError('Negative cell mutation was not applied')
        changed_cells.write_text(changed)
        module.CELLS = changed_cells
        reject('changed_selected_cell', module.main)
        module.CELLS = original_cells
    return cases


def main():
    if '--child' in sys.argv:
        print(json.dumps(run_cases(), sort_keys=True))
        return
    executions = []
    for flags in ([], ['-O']):
        result = subprocess.run([sys.executable, *flags, str(Path(__file__).resolve()), '--child'],
                                text=True, capture_output=True, check=True)
        cases = json.loads(result.stdout)
        executions.append({'optimization': bool(flags), 'cases': cases,
                           'stderr': result.stderr, 'exit_code': result.returncode})
    report = {'schema': 'aegis.cell15.fraction-guard-tests.v1',
              'status': 'PASS', 'rh_proven': False,
              'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              'test_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'executions': executions,
              'scope': '15 invalid-input cases under normal Python and -O; not analytic soundness'}
    destination = HERE / 'EXACT_FRACTION_GUARD_RECEIPT.json'
    destination.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'tests': sum(len(x['cases']) for x in executions),
                      'receipt_sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
