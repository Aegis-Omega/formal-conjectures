#!/usr/bin/env python3
"""Independent scoped unchanged scalar endpoint + complete type/axiom audit."""
from pathlib import Path
import hashlib,json,subprocess,datetime,os,time,re
D=Path(__file__).resolve().parent; W=Path('/workspace/aegis-research/work')
S=W/'DenseTowerOct7/Cell15Concrete/ScalarBudget'
R=S/'scoped-replay-20261007T060448.125789Z/RECEIPT.json'
E=S/'SCALAR_BUDGET_EVIDENCE.json'
BIN=Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parent=json.loads(R.read_text());evidence=json.loads(E.read_text())
bindings={str(R):sha(R),str(E):sha(E),str(Path(__file__).resolve()):sha(__file__)}
bindings.update(parent['input_bindings'])
for row in evidence['source_bindings']:
 p=Path(row['path']);p=p if p.is_absolute() else W/p
 if not p.is_file() or sha(p)!=row['sha256']:raise ValueError('bound evidence input missing/altered '+str(p))
 bindings[str(p)]=row['sha256']
for p,h in bindings.items():
 if sha(p)!=h:raise ValueError('identified input altered '+p)
if parent['status']!='PASS' or evidence['status']!='KERNEL_VERIFIED_SCOPED_SCALAR_BUDGET':raise ValueError('input scalar evidence not successful')
O=D/('endpoint-replay-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
(O/'sources').mkdir(parents=True);(O/'lib').mkdir()
env=dict(os.environ);env['PATH']=str(BIN)+':'+env.get('PATH','');env['LEAN_PATH']=str(O/'lib')+':'+parent['LEAN_PATH']
jobs=[];axioms=[];objects=[];reason=None;status='FAIL'
def run(cmd,name,cap=90):
 start=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True,timeout=cap)
 out=O/(name+'.stdout.txt');err=O/(name+'.stderr.txt');out.write_bytes(p.stdout);err.write_bytes(p.stderr)
 jobs.append({'name':name,'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(out),'stderr_sha256':sha(err)})
 if p.returncode:raise ValueError('actual command failed '+name+': '+p.stdout.decode()[-2500:]+p.stderr.decode()[-2500:])
 return p.stdout.decode()
def parse(log):
 if 'sorryAx' in log:raise ValueError('placeholder in axiom output')
 out=[]
 for name,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",log,re.S):
  a=[x.strip() for x in s.split(',') if x.strip()]
  if set(a)!={'propext','Classical.choice','Quot.sound'}:raise ValueError('unexpected endpoint axioms '+name)
  out.append({'theorem':name,'axioms':a})
 return out
try:
 version=run([str(BIN/'lean'),'--version'],'version')
 if '4.33.1' not in version or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in version:raise ValueError('wrong compiler')
 for name,origin in [('RHKreinCell15ScalarClosureOct7',S/'RHKreinCell15ScalarClosureOct7.lean'),('RHKreinCell15ScalarIndependentAuditOct7',D/'RHKreinCell15ScalarIndependentAuditOct7.lean')]:
  src=O/'sources'/(name+'.lean');src.write_bytes(origin.read_bytes());bindings[str(origin)]=sha(origin);bindings[str(src)]=sha(src)
  deps=run([str(BIN/'lean'),'--deps',str(src)],name+'-deps')
  for dep in deps.splitlines():
   p=Path(dep.strip())
   if not p.is_file():raise ValueError('unavailable dependency '+str(p))
   bindings[str(p.resolve())]=sha(p)
  obj=O/'lib'/(name+'.olean')
  log=run([str(BIN/'lean'),'--trust=0','-DautoImplicit=false','-j1','-M6144','--root='+str(O/'sources'),'-o',str(obj),str(src)],name+'-compile')
  output=parse(log)
  if len(output)!=(3 if name=='RHKreinCell15ScalarClosureOct7' else 14):raise ValueError('missing/duplicate endpoint axiom list '+name)
  axioms.extend(output);objects.append({'module':name,'source_sha256':sha(src),'olean_sha256':sha(obj)})
  run([str(BIN/'leanchecker'),'-v',name],name+'-leanchecker')
 if objects[0]['olean_sha256']!=parent['fresh_object_sha256']:raise ValueError('independent unchanged-source scalar object differs')
 if any(not Path(p).is_file() or sha(p)!=h for p,h in bindings.items()):raise ValueError('bound input changed during replay')
 status='PASS'
except Exception as exc:reason=str(exc)
r={'schema':'aegis.cell15.scalar-independent.endpoint-replay.v1','status':status,'reason':reason,'input_bindings':bindings,'jobs':jobs,'objects':objects,'axiom_reports':axioms,'LEAN_PATH':env['LEAN_PATH'],'lean_version':'4.33.1','lean_compiler_commit':'819816b2e0a3bf405af45ae5c7af2491d8f5bee6','mathlib_commit':'0df444a360eaa60ab8c11dca51a86af692955474','full_transitive_source_rebuild':False,'generic_and_moment_imports_reused':True,'analytic_error_enclosure_proved_by_this_review':False,'rh_proven':False,'original_user_zip_replayed':False,'scope':'Independent fresh unchanged scalar closure source, generic factored199hat/complete5spline types and14 endpoint axiom probes, pinned checker. Identified generic/moment/base imported objects reused. Scalar surrogate enclosure alone is not an actual derivative enclosure without analytic-error transport.'}
p=O/'RECEIPT.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':status,'reason':reason,'receipt':str(p),'sha256':sha(p)}));raise SystemExit(0 if status=='PASS' else 1)
