#!/usr/bin/env python3
"""Read-only source/log audit. No Lean execution and no numerical proof oracle."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime, timezone
import json
import re

W = Path('/workspace/aegis-research/work')
OUT = Path(__file__).resolve().parent
B = W / 'DenseTowerOct7/Cell15Concrete/ScalarBudget'
G = W / 'DenseTowerOct7/Cell15Reuse'
ALLOWED = ['propext', 'Classical.choice', 'Quot.sound']
checks, bindings = [], {}

def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})

def bind(path, expected=None):
    path = Path(path)
    data = path.read_bytes()
    digest = sha256(data).hexdigest()
    bindings[str(path)] = {'path': str(path), 'bytes': len(data), 'sha256': digest}
    if expected is not None:
        check('hash:' + str(path), digest == expected)
    return data

def probes(src):
    return re.findall(r'^#print axioms ([A-Za-z0-9_.]+)\s*$', src, re.M)

def log_reports(log):
    return [{'theorem': n, 'axioms': [a.strip() for a in ax.split(',')]}
            for n, ax in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]", log)]

module_receipts = [
    (B, 'RHKreinCell15ScalarBudgetOct7', 'scoped-replay-20261007T060319.604969Z', 0,
     '211e536143bdef31b7e90944c5b3e325c3ec3837e6d2818c0fd4388de113b2e9'),
    (B, 'RHKreinCell15MomentsExtendedOct7', 'scoped-replay-20261007T060353.762007Z', 7,
     'c1ef29d4d6d16d5cb713512aabf0b7dde47532258e67dbcb1e9741430b11f22e'),
    (B, 'RHKreinCell15ScalarClosureOct7', 'scoped-replay-20261007T060448.125789Z', 3,
     'fbbdf2240967f8d6a05e832d1a04cb47e8a7b5432525379bdc4bc7f426450630'),
    (G, 'RHKreinTrig15Sinc6PublicOct7', 'scoped-replay-20261007T054804.722998Z', 7,
     '37c2c5e41303f89f24f5a1424bacbf447c0d47613bbf1664e4712e6e7f06bc79'),
]
endpoint_reports = {}
sources = {}
for folder, module, scope, count, digest in module_receipts:
    srcpath = folder / (module + '.lean')
    src = bind(srcpath).decode()
    sources[module] = src
    d = folder / scope
    r = json.loads(bind(d / 'RECEIPT.json', digest))
    check(module + ':actual_success', r['status'] == 'PASS')
    check(module + ':pins', r['lean_version'] == '4.33.1'
          and r['lean_compiler_commit'] == '819816b2e0a3bf405af45ae5c7af2491d8f5bee6'
          and r['mathlib_commit'] == '0df444a360eaa60ab8c11dca51a86af692955474')
    if module == 'RHKreinTrig15Sinc6PublicOct7':
        check(module + ':scoped_imports', 'Identified imports reused; no clean transitive-source build.' in r['scope'])
    else:
        check(module + ':scoped_imports', r['full_transitive_source_rebuild'] is False)
    check(module + ':copied_source', bind(d / 'source' / (module+'.lean')) == src.encode())
    for p, digest0 in r['input_bindings'].items():
        bind(p, digest0)
    for j in r['jobs']:
        check(module + ':exit0:' + j['name'], j['exit_code'] == 0)
        for stream in ('stdout', 'stderr'):
            bind(d / (j['name']+'.'+stream+'.txt'), j[stream+'_sha256'])
    compilejob = next(j for j in r['jobs'] if j['name'] == 'compile')
    checkerjob = next(j for j in r['jobs'] if j['name'] == 'leanchecker')
    check(module + ':trust0', '--trust=0' in compilejob['command'])
    check(module + ':pinned_checker', checkerjob['command'][0] ==
          '/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin/leanchecker')
    objpath = Path(compilejob['command'][compilejob['command'].index('-o')+1])
    bind(objpath, r['fresh_object_sha256'])
    actual = log_reports((d / 'compile.stdout.txt').read_text())
    check(module + ':exact_probe_names', [a['theorem'] for a in actual] == probes(src))
    check(module + ':exact_receipt_reports', actual == r['axiom_reports'])
    check(module + ':exact_probe_count', len(actual) == count)
    check(module + ':standard_axioms', all(a['axioms'] == ALLOWED for a in actual))
    check(module + ':no_placeholder_or_native', not re.search(
          r'\b(sorry|admit|sorryAx|axiom|native_decide|unsafe)\b', src))
    endpoint_reports[module] = actual

e = json.loads(bind(B / 'SCALAR_BUDGET_EVIDENCE.json'))
for s in e['source_bindings']:
    p = Path(s['path'])
    if not p.is_absolute():
        p = W / p
    bind(p, s['sha256'])
check('evidence:analytic_remainder_retained', e['analytic_remainder_closed_by_this_module'] is False)
check('evidence:all_actual_columns', e['actual_public_hat_coefficients'] == 199
      and e['actual_public_spline_columns'] == 5)
check('evidence:no_rh_or_zip_claim', e['rh_proven'] is False and e['original_user_zip_replay'] is False)

closure = sources['RHKreinCell15ScalarClosureOct7']
budget = sources['RHKreinCell15ScalarBudgetOct7']
moments = sources['RHKreinCell15MomentsExtendedOct7']
adapter = sources['RHKreinTrig15Sinc6PublicOct7']
check('source:exact_centre_and_radius', '5025 / 65536 : ℝ' in closure
      and '347860160497148 / 1000000000000000 : ℝ' in closure
      and '1 / 100000000000000 : ℝ' in closure)
check('source:all_hat_and_spline_indices', budget.count('Fin 199') == 2 and budget.count('Fin 5') == 4)
check('source:public_moment_identity', 'public_signed_moment (e : ℕ)' in moments
      and 'hatCenter j ^ e) = signedMoment e := rfl' in moments)
check('source:kernel_decision_moments', moments.count('decide +kernel') == 3)
check('source:generic_hat_premise_retained', '(hphase : |c * hatCenter j| ≤ 1)' in adapter
      and 'sin_degree15_error (c * hatCenter j) hphase' in adapter)
check('source:sinc_premises_retained', '(hx0 : 0 < x) (hx1 : |x| ≤ 1)' in adapter)

extra_sources = [
    W/'PR53CellIntegration/PinnedSources/AEGISOverlay/RHKreinExplicitCorrectionV1.lean',
    W/'GoalContinuation20261001/PolynomialBudget/RHKreinPolynomialHatMomentsCastV1.lean',
    W/'GoalContinuation20261001/PolynomialBudget/RHKreinPolynomialRationalMomentsV1.lean',
    W/'GoalContinuation20261001/PolynomialBudget/RHKreinPolynomialBudgetDataV1.lean',
]
for p in extra_sources:
    bind(p)

c, fine, coarse = F(5025,65536), F(347860160497148,10**15), F(347860160497,10**12)
ranges = {'maximum_hat_phase': c*F(239,50), 'spline_phase': c*F(1619,2000),
          'hat_sinc_argument': c/100, 'spline_sinc_argument': c/2000}
for name,x in ranges.items():
    check('exact_range:'+name, 0 < x < 1)
check('exact_centre_difference', fine-coarse == F(148,10**15))
check('conditional_triangle_budget', F(1,10**14)+F(1,10**13)+fine-coarse
      == F(258,10**15) < F(1,10**12))

# Coefficient-level check of the derivative distinction, not an analytic theorem.
coscoef = {0:F(1),2:-F(1,2),4:F(1,24),6:-F(1,720),8:F(1,40320),
           10:-F(1,3628800),12:F(1,479001600),14:-F(1,87178291200)}
sincoef = {1:F(1),3:-F(1,6),5:F(1,120),7:-F(1,5040),9:F(1,362880),
           11:-F(1,39916800),13:F(1,6227020800),15:-F(1,1307674368000)}
dcos = {k-1:k*v for k,v in coscoef.items() if k}
diff = {k:-sincoef.get(k,F(0))-dcos.get(k,F(0)) for k in set(sincoef)|set(dcos)}
check('exact_polynomial_derivative_difference',
      {k:v for k,v in diff.items() if v} == {15:F(1,1307674368000)})
check('polynomial_degrees', max(coscoef)==14 and max(sincoef)==15)

# Preserve source copies within the owned review folder only.
snapshot = OUT/'SourceSnapshot'
snapshot.mkdir(exist_ok=True)
for folder,module,_,_,_ in module_receipts:
    original = folder/(module+'.lean')
    target = snapshot/original.name
    data = original.read_bytes()
    if target.exists() and target.read_bytes() != data:
        raise SystemExit('Refusing changed source snapshot: '+str(target))
    target.write_bytes(data)
    bind(target)
bind(OUT/'REVIEW.md')
bind(Path(__file__))
passed = all(q['pass'] for q in checks)
result = {
    'schema':'aegis.oct7.cell15-scalar.independent-mathematical-audit.v1',
    'created_utc':datetime.now(timezone.utc).isoformat(),
    'status':'PASS_SCOPED_MATHEMATICAL_AUDIT' if passed else 'FAIL',
    'source_body_review':'Completed independently; see byte-bound REVIEW.md',
    'exact_endpoint':'AEGIS.RHKreinCell15ScalarClosureOct7.scalar_surrogate_cell15',
    'exact_type':'|scalar_surrogate (5025/65536) - 347860160497148/10^15| <= 1/10^14',
    'degree_conventions':{'cosPolynomial15':14,'sinPolynomial15':15,'sincPolynomial7':6},
    'derivative_shape':{'factorwise_approximation_of_actual_derivative':True,
        'derivative_of_polynomial_correction_approximant':False,
        'hat_derivative_difference':'t^15 * signedMoment 16 / 15!',
        'sincDerivativeP_is_derivative_of_sincPolynomial7':False},
    'actual_hat_count':199,'actual_spline_column_count':5,
    'range_checks':{k:{'numerator':x.numerator,'denominator':x.denominator} for k,x in ranges.items()},
    'source_and_original_stdout_axiom_reports':endpoint_reports,
    'new_lean_execution_in_this_audit':False,
    'original_replay_scope':'Fresh scalar modules and checker; byte-bound imported objects reused',
    'full_transitive_source_rebuild':False,
    'analytic_remainder_closed_by_reviewed_modules':False,
    'next_local_transport':'Prove a direct bound between deriv correctionSymbol (5025/65536) and scalar_surrogate (5025/65536)',
    'original_v33_zip_identified_or_replayed':False,
    'all_cells_proven':False,'rh_proven':False,
    'checks':checks,'passed_checks':sum(q['pass'] for q in checks),
    'total_checks':len(checks),'bindings':sorted(bindings.values(),key=lambda q:q['path'])}
receipt = OUT/'RECEIPT.json'
if receipt.exists():
    raise SystemExit('Refusing overwrite of frozen review receipt')
receipt.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'passed_checks':result['passed_checks'],
                  'total_checks':len(checks),'bindings':len(bindings),
                  'receipt':str(receipt),'receipt_sha256':sha256(receipt.read_bytes()).hexdigest()},indent=2))
raise SystemExit(0 if passed else 1)
