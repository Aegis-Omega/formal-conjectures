# Independent Cell15 scalar mathematical audit

The frozen scalar endpoint is valid within its stated scope. It proves

\[
\left|P(5025/65536)-347860160497148/10^{15}\right|\le 10^{-14},
\]

where `P` is exactly `AEGIS.RHKreinCell15ScalarBudgetOct7.scalar_surrogate`. The endpoint has no hypotheses. It does not identify `P` with the actual analytic derivative, and it does not prove an analytic remainder bound. The source and original execution evidence explicitly retain this distinction. This review adds no Lean execution; the parent conducts a separate independent endpoint replay.

## Actual carrier and finite algebra

The public correction is

\[
C(t)=\frac2{50}s(t/100)^2H(t)+s(t/2000)^{19}S(t),\quad s(x)=\operatorname{sinc}(x),
\]

with all 199 public rational hat coefficients in `H(t)=Σ a_j cos(tu_j)`, `u_j=(j+41)/50`, and all five public rational spline coefficients in `S(t)=Σ b_j t^j phase_j(1619t/2000)`. The scalar definition retains both blocks, their prefactors, powers, chain factors, signs, and all spline columns. The Nat subtraction in `t^(j.val-1)` is harmless for `j=0`, because its factor `j.val` is zero.

The two all-real factorization theorems are exact finite-sum algebra, not inequalities. They preserve signed moments, including the final `+t^15 M16/15!` term of the sine expression. They do not substitute absolute moments or omit hats. `public_signed_moment (e : ℕ)` identifies the public sum with the older moment carrier by `rfl`, for every exponent. The rational moments at 12, 14, and 16 use `decide +kernel`; their real versions use the already proved rational-to-real cast identity. The scalar endpoint rewrites moments 0 through 16, then uses exact rational normalization over all five spline columns. No positivity, RH premise, numerical interval, or analytic remainder is assumed in this calculation.

## Derivative-shape distinction

`cosPolynomial15` is degree 14; `sinPolynomial15` is degree 15. Their names refer to the common exponential Taylor truncation, not identical degrees. `sincPolynomial7` is degree 6. In particular,

\[
\hat H'_P(t)-\frac{d}{dt}\hat H_P(t)=\frac{t^{15}}{15!}M_{16}.
\]

Here the left member `hatSumDerivativeP` replaces the sine in the **actual derivative** by `sinPolynomial15`; it is not the derivative of the cosine approximation. Likewise `(x cosPolynomial15(x)-sinPolynomial15(x))/x²` approximates actual `sinc'(x)` at nonzero x and is not the derivative of `sincPolynomial7`. Even spline phases have the same extra sine term; odd spline phases do have the exact polynomial derivative relation. Consequently `scalar_surrogate` has the factorwise product-rule shape of `C'`, but is not obtained by differentiating the polynomial approximation to `C`.

An analytic transport must bound the errors in these independently approximated factors and their products directly. Differentiating the polynomial approximant without this correction would be an invalid argument. None of the three audited scalar files makes that invalid identification.

## Generic adapter and retained assumptions

The actual 199-hat sine adapter quantifies over `c : ℝ` and `j : Fin 199` and explicitly requires `|c * hatCenter j| ≤ 1`. The cosine and sine error theorems also retain `|x| ≤ 1`; the sinc error theorem retains `0 < x` and `|x| ≤ 1`. No premise is silently removed.

At the audited positive centre, `c=5025/65536`, all phase premises hold: `0 < c*u_j ≤ c*(239/50) < 1`, `0 < c*(1619/2000) < 1`, and both `c/100` and `c/2000` are positive and below one. The accompanying audit computes these range comparisons with exact fractions. These range checks establish applicability only; they are not an error bound for the full product-rule derivative.

## Original execution and axiom scope

The source probes match the original successful compile stdout and receipt by full declaration name: three closure endpoints plus seven moment endpoints, each reporting exactly `propext`, `Classical.choice`, and `Quot.sound`. The definitions module has no axiom probes; its empty report does not assert an independent axiom audit of each definition. The generic adapter has its own seven matching endpoint probes. The receipt commands contain `--trust=0` and the pinned Lean 4.33.1 checker; logs and object hashes are rebound by the audit script. Identified imported objects were reused. This is a scoped endpoint replay, not a fresh rebuild of the entire transitive closure.

## Exact conclusion and remaining scope

The fine centre differs from the coarse `347860160497/10^12` by exactly `148/10^15`; substituting the coarse centre while retaining radius `10^-14` is not justified. A separate analytic estimate `|C'(c)-P(c)| ≤ 10^-13`, if actually proved, would combine with this scalar bound and the centre shift to give radius `258/10^15 < 10^-12` around the coarse centre. It would not by itself establish the user's much narrower fine interval of radius `10^-15`.

The reviewed original v33 ZIP bytes were not available to this audit. No v33 source identity or replay is claimed. The exact open transport at this scope is an independently justified bound between the actual derivative and the scalar surrogate at the audited centre. All-cell semantics and RH remain outside this endpoint's conclusion. The receipt accompanying this document binds the precise bytes inspected; hashes do not substitute for the proof-body review above.
