# Independent Cell15 scalar verification

PASS in the stated scoped execution. I read the frozen proof bodies and executed a separate fresh `--trust=0` compilation of `RHKreinCell15ScalarClosureOct7`, followed by the pinned kernel checker. The unchanged source emitted exactly the previous OLEAN, SHA256 `74074a55abce2b25540c6ecc4243c0cd480658ae3012183b5101d1532c158e9b`.

A second fresh audit module prints the full types of both all-real 199-hat factorization identities, the scalar endpoint, public signed-moment identification and four generic approximation theorems. It prints fourteen distinct transitive axiom lists; every one contains only `propext`, `Classical.choice` and `Quot.sound`. Its pinned checker also passed. No `sorryAx`, new mathematical axiom or RH hypothesis appears in these actual lists.

The exact scalar result is

```lean
AEGIS.RHKreinCell15ScalarClosureOct7.scalar_surrogate_cell15 :
  |AEGIS.RHKreinCell15ScalarBudgetOct7.scalar_surrogate (5025/65536)
       - 347860160497148/1000000000000000| ≤
    1/100000000000000
```

It has no arguments or analytic-remainder premise. The independent receipt is `endpoint-replay-20261007T061029.840994Z/RECEIPT.json`, SHA256 `4b2c04bf1e4b6b388ebfca6097abfdfaab1cf476df09bdecc57e7ebcc976795d`. Its two source compilations took 4.79 and 3.05 seconds; two checker commands took 6.72 and 6.36 seconds. Lean 4.33.1 compiler `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, Mathlib `0df444a360eaa60ab8c11dca51a86af692955474`. Seventy-four declared source/object/receipt/compiler paths were checked unchanged before and after execution. Generic, moment and base imports were reused; this is not a full transitive source rebuild.

## Reconstructible finite algebra

Let the original public hat coefficients and centres be `a_j,b_j`, for `j : Fin 199`, and define `M_e = ∑_j a_j b_j^e`. The checked `public_signed_moment` identifies these actual objects with the exact existing `signedMoment e` for every natural `e`, by definitional equality. Existing moments 0 through10 and new exact moments12,14,16 remain signed, with no discarded column. The three new rational moments are proved by `decide +kernel` and then transported to the real numbers.

For `C(x)=∑_{m=0}^7(-1)^m x^(2m)/(2m)!` and `S(x)=∑_{m=0}^7(-1)^m x^(2m+1)/(2m+1)!`, finite-sum distributivity proves, for every real `t`,

```
hatSumP(t) = Σ[m=0..7] (-1)^m t^(2m) M_(2m)/(2m)!
hatSumDerivativeP(t) = Σ[m=0..7] (-1)^(m+1) t^(2m+1) M_(2m+2)/(2m+1)!.
```

After substituting these exact moments and all five actual spline coefficients into the complete scalar product-rule surrogate, the last inequality at the rational midpoint is proved by exact kernel arithmetic. The factors `2/50`, the chain scales `1/100` and `1/2000`, both spline powers18/19, and each phase and monomial contribution remain in the printed definition. No floating-point decision is used.

## Semantic boundary required for integration

The scalar surrogate is an approximation to the full analytic product-rule derivative, with independently chosen polynomial replacements for each analytic factor. It is not the derivative of one polynomial correction approximation. In particular,

```
hatSumDerivativeP(t) - deriv(hatSumP)(t) = t^15 M_16/15!
```

because the cosine polynomial has degree14 while the sine polynomial retains degree15. `sincDerivativeP(x)=(x*C(x)-S(x))/x²` is likewise distinct from `deriv(sincPolynomial7)(x)`. A valid analytic transport compares these surrogate factors directly with the real analytic factors and pays the product errors. The independently printed generic sine/cosine bounds retain `|x|≤1`; the sinc bound retains `0<x` and `|x|≤1`. None of these hypotheses is dropped from their types.

This review does not assert that the scalar inequality alone encloses `exactJetCoefficient c 1`. The separate analytic-error and exact derivative-identity modules must supply that bridge. Their absence from this scalar scope is not a claim they are absent elsewhere in the project.

The coarse centre `347860160497/10^12` is separated from the fine centre by exactly `148/10^15`. The proved fine radius is `10/10^15`; thus the triangle inequality implies distance at least `138/10^15` from that coarse centre. A coarse-centre radius `1/10^14` is therefore false, while the intended `1/10^12` enclosure can remain compatible after the independent analytic budget is paid.

RH, all cells, original user ZIP bytes and its reported349 hashes are not verified by this scalar replay. No frozen source or remote repository was changed.
