import RHKreinTrig15Sinc6PublicOct7
import AEGISOverlay.RHKreinFiniteCertificateDataV1
import RHKreinM8AnalyticV1

/-!
NEW reconstruction from the literal public PR53 one-based entry 15.
No identity with the unavailable reported ZIP is presumed.
The entry check identifies payload data only; it does not assert cell soundness.
-/

set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 1500000
noncomputable section

namespace AEGIS.RHKreinCell15PhasesOct7

open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteCertificateDataV1
open AEGIS.RHKreinTrig15Sinc6PublicOct7
open AEGIS.RHKreinSincIntervalV1
open AEGIS.RHKreinM8AnalyticV1

def fifteenthCell : FiniteCellV1 :=
  ⟨2475 / 32768, 1275 / 16384, 292616690003685633⟩

def fifteenthCenter : ℝ := 5025 / 65536

theorem fifteenthCell_is_public_payload_entry :
    finiteCells[14]? = some fifteenthCell := rfl

theorem fifteenthCenter_is_midpoint :
    fifteenthCenter =
      ((fifteenthCell.lo : ℝ) + (fifteenthCell.hi : ℝ)) / 2 := by
  norm_num [fifteenthCenter, fifteenthCell]

theorem fifteenthCenter_pos : 0 < fifteenthCenter := by
  norm_num [fifteenthCenter]

theorem fifteenthCenter_hat_phase (j : Fin 199) :
    0 ≤ fifteenthCenter * hatCenter j ∧
      fifteenthCenter * hatCenter j ≤ (48039 / 131072 : ℝ) := by
  have hjNat : j.val ≤ 198 := by omega
  have hj : (j.val : ℝ) ≤ 198 := by exact_mod_cast hjNat
  constructor
  · unfold fifteenthCenter hatCenter
    positivity
  · unfold fifteenthCenter hatCenter
    norm_num
    linarith

theorem fifteenthCenter_hat_phase_abs (j : Fin 199) :
    |fifteenthCenter * hatCenter j| ≤ 1 := by
  rw [abs_of_nonneg (fifteenthCenter_hat_phase j).1]
  exact (fifteenthCenter_hat_phase j).2.trans (by norm_num)

theorem fifteenthCenter_hat_sine_error (j : Fin 199) :
    |Real.sin (fifteenthCenter * hatCenter j) -
        sinPolynomial15 (fifteenthCenter * hatCenter j)| ≤
      |fifteenthCenter * hatCenter j| ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) :=
  hat_sine_degree15_error fifteenthCenter j
    (fifteenthCenter_hat_phase_abs j)

theorem fifteenthCenter_hat_cosine_error (j : Fin 199) :
    |Real.cos (fifteenthCenter * hatCenter j) -
        cosPolynomial15 (fifteenthCenter * hatCenter j)| ≤
      |fifteenthCenter * hatCenter j| ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) :=
  cos_degree15_error (fifteenthCenter * hatCenter j)
    (fifteenthCenter_hat_phase_abs j)

theorem fifteenthCenter_hat_sine_uniform_error (j : Fin 199) :
    |Real.sin (fifteenthCenter * hatCenter j) -
        sinPolynomial15 (fifteenthCenter * hatCenter j)| ≤
      (1 / 100000000000000000000 : ℝ) := by
  have h := fifteenthCenter_hat_sine_error j
  have hx : |fifteenthCenter * hatCenter j| ≤
      (48039 / 131072 : ℝ) := by
    simpa [abs_of_nonneg (fifteenthCenter_hat_phase j).1] using
      (fifteenthCenter_hat_phase j).2
  have hp := pow_le_pow_left₀
    (abs_nonneg (fifteenthCenter * hatCenter j)) hx 16
  refine h.trans ?_
  calc
    |fifteenthCenter * hatCenter j| ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) ≤
      (48039 / 131072 : ℝ) ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) :=
      mul_le_mul_of_nonneg_right hp (by positivity)
    _ ≤ _ := by norm_num

theorem fifteenthCenter_edge_sine_error :
    |Real.sin (fifteenthCenter * (1619 / 2000 : ℝ)) -
        sinPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      |fifteenthCenter * (1619 / 2000 : ℝ)| ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) :=
  sin_degree15_error _ (by norm_num [fifteenthCenter])

theorem fifteenthCenter_edge_cosine_error :
    |Real.cos (fifteenthCenter * (1619 / 2000 : ℝ)) -
        cosPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      |fifteenthCenter * (1619 / 2000 : ℝ)| ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) :=
  cos_degree15_error _ (by norm_num [fifteenthCenter])

theorem fifteenthCenter_hat_sinc_error :
    |Real.sinc (fifteenthCenter / 100) -
        sincPolynomial7 (fifteenthCenter / 100)| ≤
      |fifteenthCenter / 100| ^ 8 * (9 / (40320 * 8) : ℝ) /
        (fifteenthCenter / 100) :=
  sinc_degree6_error _ (by norm_num [fifteenthCenter])
    (by norm_num [fifteenthCenter])

theorem fifteenthCenter_edge_sinc_error :
    |Real.sinc (fifteenthCenter / 2000) -
        sincPolynomial7 (fifteenthCenter / 2000)| ≤
      |fifteenthCenter / 2000| ^ 8 * (9 / (40320 * 8) : ℝ) /
        (fifteenthCenter / 2000) :=
  sinc_degree6_error _ (by norm_num [fifteenthCenter])
    (by norm_num [fifteenthCenter])

theorem exactJetCoefficient_one_eq_deriv (c : ℝ) :
    exactJetCoefficient c 1 = deriv correctionSymbol c := by
  simp [exactJetCoefficient, iteratedDeriv_one]

end AEGIS.RHKreinCell15PhasesOct7

#print AEGIS.RHKreinCell15PhasesOct7.fifteenthCell
#print AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter
#print AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCell_is_public_payload_entry
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_is_midpoint
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_pos
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_phase
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_phase_abs
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_sine_error
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_cosine_error
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_sine_uniform_error
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_edge_sine_error
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_edge_cosine_error
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_sinc_error
#check @AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_edge_sinc_error
#check @AEGIS.RHKreinCell15PhasesOct7.exactJetCoefficient_one_eq_deriv
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCell_is_public_payload_entry
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_is_midpoint
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_pos
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_phase
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_phase_abs
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_sine_error
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_cosine_error
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_sine_uniform_error
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_edge_sine_error
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_edge_cosine_error
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_hat_sinc_error
#print axioms AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter_edge_sinc_error
#print axioms AEGIS.RHKreinCell15PhasesOct7.exactJetCoefficient_one_eq_deriv
