# Reconstructed public cell15 coefficient: ordinary exact enclosure

This is a NEW reconstruction from literal FormalConjectures PR53 head
`81bcd289cd6df73901fc97168b00a3b04376eac9`, not a replay or recovered copy
of the reported v33 or FIFTEENTH_K1 ZIP. The source identities and every
exact rational input are bound by the generated receipts and replay scripts.
No floating-point comparison occurs.

The one-based fifteenth serialized entry is

    (2475/32768, 1275/16384, 292616690003685633).

Its midpoint is c=5025/65536. The actual public symbol is

    F(t) = (1/25) sinc(t/100)^2 A(t) + sinc(t/2000)^19 B(t),
    A(t) = sum(j=0..198) a_j cos(t u_j), u_j=(j+41)/50,
    B(t) = sum(j=0..4) b_j t^j phi_j(t v), v=1619/2000,

where phi_j is cosine for even j and sine for odd j, and a_j,b_j are the
UNCHANGED exact rational `hatCoefficient` and `splineCoefficient` vectors.
The cell's stored lower64 value identifies payload data; it is not an input
assumption about F or its derivative.

## Exact derivative and normalization

For x!=0 set D(x)=(x cos(x)-sin(x))/x^2. With S=sinc(t/100),
H=sinc(t/2000), S'=D(t/100)/100, H'=D(t/2000)/2000,

    F'(t) = (1/25)(2 S S' A + S^2 A')
            + 19 H^18 H' B + H^19 B',
    A'(t) = -sum_j a_j u_j sin(t u_j),
    B'(t) = sum_j b_j [j t^(j-1) phi_j(t v)
                        + t^j v phi'_j(t v)].

The j=0 first summand is zero. All 199 hats, all five edge columns,
both sinc derivatives and the power19 derivative are retained. Differentiating
these finite sums requires no infinite-limit interchange. The generic
`DerivativeBridge/RHKreinCorrectionDerivativeOct7.lean` proves this identity
for every t!=0, and connects it to the actual `exactJetCoefficient t 1`.
Since 1!=1, the coefficient is F'(c), with no extra factorial or 2pi change.

## Taylor bounds already proved by the pinned kernel

Let C14 and S15 be the even degree14 and odd degree15 truncations of cosine
and sine. They are the real and imaginary parts of `expIPartial 16`.
The imaginary part of `expIPartial 17` is STILL S15: the extra order16 term
is purely real. Consequently, for |x|<=1 the existing Taylor remainder
theorem gives

    |cos(x)-C14(x)| <= |x|^16 * 17/(16!*16),
    |sin(x)-S15(x)| <= |x|^17 * 18/(17!*17).

For 0<x<=1 and P6(x)=1-x^2/6+x^4/120-x^6/5040,

    |sinc(x)-P6(x)| <= x^8 * 9/(8!*8) / x.

The generic degree15/degree6 adapters and the tightened same-polynomial sine
bound were compiled with explicit trust=0 and separately checked. At c,
every hat phase is between zero and 48039/131072<1. The edge phase c*v,
c/100 and c/2000 also lie in (0,1). These are exact rational comparisons;
the actual indexed phase bounds were separately kernel-checked.

## Interval propagation and finite exact computation

`exact_fraction_sine17_reconstruction.py` constructs the preceding primitive
Taylor intervals and intersects trigonometric/sinc value intervals with
[-1,1], using their known absolute bounds. D is enclosed by propagating
the sine/cosine intervals through its exact nonzero-denominator formula.
It then evaluates EVERY term of the displayed derivative using Fractions.

Each operation is sound over the reals: addition adds endpoints; negation
reverses them; multiplication takes the minimum and maximum of the four
corner products; division excludes zero and uses the reciprocal interval;
natural powers iterate sound multiplication. Bilinearity shows that extrema
on a rectangle occur at corners. Reciprocal monotonicity on either component
of R\{0} justifies division. Finite sums preserve enclosure. Repeated use of
the same uncertain value can widen an interval but cannot invalidate it.
Intersections retain the true value because both input enclosures contain it.

The source parser accepts only literal integer/fraction vectors, requires
exact lengths199 and5, counts2199 serialized entries and checks the literal
entry15, and rejects an altered correction Git blob or any phase outside
the proved domain. The formula in code is the full displayed derivative.
The complete cell-data source is hashed in the receipt; this one-coefficient
computation does not validate the other2198 cells. There are no `assert`
guards that disappear under Python -O.

The exact result, rounded OUTWARDS by integer division alone, is

    347860160497147719465207 / 10^24
       < F'(c)
       < 347860160497147766628587 / 10^24.

Thus it lies strictly in the reported v33 interval

    (347860160497147, 347860160497149) / 10^15,

and in particular within radius10^-12 of347860160497/10^12.
The generated raw interval has width less than4.7163378847318e-17; that last
decimal is an outward display of a rational, not a float proof decision.
Both normal Python and Python -O emitted the same generated receipt hash
`79c10e17f6648921077375fed70cc28477971173c5184ee1a1897a8a71aa4432`.

## What is and is not machine closed

This text supplies the ordinary analytic semantics of the exact Fraction
enclosure using the actual source formula and checked primitive bounds.
The derivative identity, phase bounds and Taylor primitives have scoped
kernel proofs. The FULL generated interval computation is not yet a Lean
proof term merely because the script passes. The separate scalar budget
and analytic error assembly are being formalized to close the concrete
coefficient without importing a Python result as an axiom.

This is one coefficient on one real midpoint. It is neither soundness of
the entire fifteenth cell, all2199 cells, unrestricted support positivity,
nor a proof of RH. It makes no source-provenance claim about the unavailable
user ZIP or its reported349 hashes.
