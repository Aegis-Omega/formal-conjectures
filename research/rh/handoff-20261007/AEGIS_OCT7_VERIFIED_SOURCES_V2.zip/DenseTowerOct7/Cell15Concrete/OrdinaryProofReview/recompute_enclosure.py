"""Independent exact Horner/tuple-interval recomputation; no float decisions."""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re

WORK = Path('/workspace/aegis-research/work')
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
SOURCE = WORK / 'DenseTowerOct7/PR53Lane/Public53/sources/AEGISOverlay/RHKreinExplicitCorrectionV1.lean'
CELLS = WORK / 'DenseTowerOct7/PR53Lane/Public53/sources/AEGISOverlay/RHKreinFiniteCertificateDataV1.lean'
RECEIPT = BASE / 'EXACT_FRACTION_SINE17_RECONSTRUCTION.json'

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def interval(lo, hi=None):
    lo = Q(lo)
    hi = lo if hi is None else Q(hi)
    if lo > hi:
        raise ValueError('reversed interval')
    return lo, hi

def plus(a, b):
    return a[0] + b[0], a[1] + b[1]

def times(a, b):
    corners = tuple(x * y for x in a for y in b)
    return min(corners), max(corners)

def scale(a, q):
    return times(a, interval(q))

def negate(a):
    return -a[1], -a[0]

def divide(a, b):
    if b[0] <= 0 <= b[1]:
        raise ValueError('denominator contains zero')
    return times(a, interval(1 / b[1], 1 / b[0]))

def power(a, n):
    if not isinstance(n, int) or n < 0:
        raise ValueError('invalid exponent')
    if a[0] >= 0:
        return a[0] ** n, a[1] ** n
    value = interval(1)
    for _ in range(n):
        value = times(value, a)
    return value

def horner(z, coefficients):
    value = Q(0)
    for coefficient in reversed(coefficients):
        value = value * z + coefficient
    return value

def trig(x, odd):
    if abs(x) > 1:
        raise ValueError('unproved trig phase')
    offsets = [2 * j + int(odd) for j in range(8)]
    p = horner(x * x, [Q((-1) ** j, factorial(k)) for j, k in enumerate(offsets)])
    if odd:
        p *= x
    n = 17 if odd else 16
    error = abs(x) ** n * Q(n + 1, factorial(n) * n)
    return interval(max(p - error, Q(-1)), min(p + error, Q(1)))

def sinc(x):
    if not 0 < x <= 1:
        raise ValueError('unproved sinc phase')
    p = horner(x * x, [Q((-1) ** j, factorial(2 * j + 1)) for j in range(4)])
    error = x ** 7 * Q(1, 35840)
    return interval(max(p - error, Q(-1)), min(p + error, Q(1)))

def sinc_derivative(x):
    return divide(plus(scale(trig(x, False), x), negate(trig(x, True))), interval(x * x))

def literal_vector(text, name, count):
    match = re.search(r'def ' + name + r'\b[^\n]*\n\s*!\[(.*?)\]', text, re.S)
    if match is None:
        raise ValueError('vector missing')
    values = []
    for item in match[1].split(','):
        if re.fullmatch(r'\s*-?\d+(?:/\d+)?\s*', item) is None:
            raise ValueError('nonliteral rational')
        values.append(Q(item.strip()))
    if len(values) != count:
        raise ValueError('wrong vector size')
    return values

def main():
    expected = json.loads(RECEIPT.read_text())
    checks = []
    def check(name, value):
        checks.append({'name': name, 'pass': bool(value)})
        if not value:
            raise ValueError('failed independent check: ' + name)
    for binding in expected['source_bindings']:
        p = WORK / binding['path']
        check('source:' + binding['path'], digest(p) == binding['sha256'])
        if 'git_blob' in binding:
            data = p.read_bytes()
            actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            check('blob:' + binding['path'], actual == binding['git_blob'])
    text = SOURCE.read_text()
    hats = literal_vector(text, 'hatCoefficient', 199)
    columns = literal_vector(text, 'splineCoefficient', 5)
    serialized = re.search(r'def finiteCells : List FiniteCellV1 := \[(.*?)\]',
                           CELLS.read_text(), re.S)
    if serialized is None:
        raise ValueError('serialized cell list missing')
    entries = re.findall(r'⟨\s*([^,]+),\s*([^,]+),\s*([^⟩]+)⟩', serialized[1])
    check('serialized_entry_count', len(entries) == 2199)
    fifteenth = tuple(Q(item.strip()) for item in entries[14])
    check('literal_one_based_fifteenth_cell', fifteenth ==
          (Q(2475, 32768), Q(1275, 16384), Q(292616690003685633)))
    c = Q(5025, 65536)
    u = [Q(j + 41, 50) for j in range(199)]
    beta = Q(1619, 2000)
    check('literal_midpoint', c == (Q(2475, 32768) + Q(1275, 16384)) / 2)
    check('maximum_hat_phase', max(c * z for z in u) == Q(48039, 131072) < 1)
    check('all_phases_positive_and_in_domain', all(0 < c * z < 1 for z in u) and
          all(0 < z < 1 for z in [c * beta, c / 100, c / 2000]))
    a = ap = b = bp = interval(0)
    for coefficient, centre in zip(hats, u):
        a = plus(a, scale(trig(c * centre, False), coefficient))
        ap = plus(ap, scale(trig(c * centre, True), -coefficient * centre))
    for j, coefficient in enumerate(columns):
        phase = trig(c * beta, bool(j % 2))
        dphase = scale(trig(c * beta, not bool(j % 2)), beta if j % 2 else -beta)
        b = plus(b, scale(phase, coefficient * c ** j))
        bp = plus(bp, scale(dphase, coefficient * c ** j))
        if j:
            bp = plus(bp, scale(phase, coefficient * j * c ** (j - 1)))
    s, h = sinc(c / 100), sinc(c / 2000)
    sp, hp = scale(sinc_derivative(c / 100), Q(1, 100)), scale(sinc_derivative(c / 2000), Q(1, 2000))
    first = scale(plus(times(times(scale(s, 2), sp), a), times(power(s, 2), ap)), Q(1, 25))
    second = times(times(scale(power(h, 18), 19), hp), b)
    third = times(power(h, 19), bp)
    enclosure = plus(plus(first, second), third)
    check('independent_horner_lower_matches', enclosure[0] == Q(expected['derivative_enclosure']['lower']))
    check('independent_horner_upper_matches', enclosure[1] == Q(expected['derivative_enclosure']['upper']))
    width = enclosure[1] - enclosure[0]
    check('raw_width_matches', width == Q(expected['derivative_enclosure']['width']))
    lower = Q(347860160497147719465207, 10 ** 24)
    upper = Q(347860160497147766628587, 10 ** 24)
    check('strict_lower_display_rounding', lower < enclosure[0])
    check('strict_upper_display_rounding', enclosure[1] < upper)
    check('lower_display_is_integer_floor', lower.numerator * (10 ** 24 // lower.denominator) ==
          enclosure[0].numerator * 10 ** 24 // enclosure[0].denominator)
    check('upper_display_is_integer_ceiling', upper.numerator * (10 ** 24 // upper.denominator) ==
          -((-enclosure[1]).numerator * 10 ** 24 // enclosure[1].denominator))
    check('strict_reported_fine_interval', Q(347860160497147, 10 ** 15) < enclosure[0] and
          enclosure[1] < Q(347860160497149, 10 ** 15))
    check('outward_width_display', width < Q('4.7163378847318e-17'))
    coarse = Q(347860160497, 10 ** 12)
    radius = Q(1, 10 ** 12)
    margin = min(enclosure[0] - (coarse - radius), coarse + radius - enclosure[1])
    check('coarse_target_requested_radius', margin > 0 and margin == Q(expected['minimum_margin']))
    check('false_coarse_1e_minus14_target_falsified', enclosure[0] - coarse > Q(1, 10 ** 14))
    check('negative_interval_division_boundary', divide(interval(1, 2), interval(-4, -2)) == interval(-1, Q(-1, 4)))
    check('signed_corner_products', times(interval(-2, 3), interval(-4, 5)) == interval(-12, 15))
    for name, thunk in [
        ('zero_denominator_rejected', lambda: divide(interval(1), interval(-1, 1))),
        ('negative_sinc_phase_rejected', lambda: sinc(Q(-1, 2))),
        ('large_trig_phase_rejected', lambda: trig(Q(2), False)),
        ('reversed_interval_rejected', lambda: interval(2, 1)),
    ]:
        try:
            thunk()
        except ValueError:
            check(name, True)
        else:
            check(name, False)
    result = {'schema': 'aegis.oct7.cell15-independent-horner-review.v1', 'status': 'PASS',
              'checks': checks, 'rh_proven': False, 'new_kernel_replay': False,
              'scope': 'Exact rational independent Horner/tuple-interval recomputation and ordinary interval semantics; not a new Lean interval proof or original user ZIP replay.',
              'source_bindings': [{'path': str(p.relative_to(WORK)), 'sha256': digest(p)}
                                  for p in [SOURCE, CELLS, RECEIPT, Path(__file__)]]}
    path = HERE / 'INDEPENDENT_RECOMPUTATION.json'
    path.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'PASS', 'checks': len(checks), 'receipt_sha256': digest(path)}, sort_keys=True))

if __name__ == '__main__':
    main()
