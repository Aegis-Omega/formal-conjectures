# Independent ordinary review of the reconstructed cell15 enclosure

The reviewed ordinary proof is correct in its stated scope: the actual public
PR53 correction symbol's first jet coefficient at the one-based fifteenth
serialized cell midpoint c=5025/65536. It is a new reconstruction rather than
recovery or replay of the user's unavailable ZIP. It asserts neither the
soundness of a whole cell nor global Weil positivity or RH.

The source symbol has prefactor 2/50=1/25, all 199 literal hat coefficients
at centres (j+41)/50, and all five spline columns at angular phase 1619t/2000.
The derivative formula preserves A and A', B and B', both scaled sinc
derivatives, and the factors 19H^18 and H^19. The j=0 monomial-derivative term
is zero, so omitting that zero term in Python agrees with the Lean finite-sum
formula. At nonzero c, the ordinary quotient derivative of sinc is
(x cos x-sin x)/x². The existing generic derivative bridge identifies this
formula with the actual jet coefficient at order one; 1! = 1, so no factorial
or 2π conversion is introduced.

The sine17 variant retains the degree-15 sine polynomial. Its additional
sixteenth Taylor term contributes only to the real coordinate. The existing
17-term error coefficient is 18/(17!·17); cosine uses 17/(16!·16), and sinc
uses 9/(8!·8) after division by its strictly positive phase. The actual maximum
hat phase is 48039/131072, and all hat, spline and scaled sinc phases lie in
(0,1). The independently checked literal source and indexed cell15 values
agree with these hypotheses.

The tuple-interval implementation in recompute_enclosure.py is independent of
the root script's interval class. It evaluates the same polynomials by Horner
recursion, uses endpoint-power monotonicity for positive sinc intervals, and
propagates the full derivative with exact Fractions. Its raw lower and upper
endpoints agree exactly with the root receipt. Reusing an uncertain quantity
in several products loses possible correlations by enlarging the feasible
rectangle; it does not lose enclosure. Bilinear corner bounds, reciprocal
monotonicity away from zero and known |sin|,|cos|,|sinc|≤1 justify each operation.

Strict displayed rounding was checked by rational cross multiplication:

    347860160497147719465207/10^24 < raw_lower ≤ F'(c),
    F'(c) ≤ raw_upper < 347860160497147766628587/10^24.

The endpoints are not exact multiples of 10^-24, so the two outward displayed
inequalities are genuinely strict. The raw interval lies strictly inside
(347860160497147,347860160497149)/10^15. Its width is strictly below the
displayed rational decimal 4.7163378847318e-17. The twelve-decimal target's
1e-12 radius and its minimum-margin formula also pass exact comparisons.

The different proposed target—an error at most 1e-14 around the coarser centre
347860160497/10^12—is false: raw_lower minus that centre is strictly greater
than 1e-14. This is a falsified numerical target for this coefficient, not a
counterexample to RH. The separately proved scalar-budget theorem uses the
correct finer centre 347860160497148/10^15 instead.

The parser scope is now stated accurately. It requires exactly 199 and five
literal coefficients, binds the full correction source's Git blob, counts
2199 serialized cell entries and validates the selected fifteenth entry.
The full cells-file bytes are hashed in the receipt; the script does not
validate the other 2198 cells or establish their analytic soundness. Reordering
or changing an unrelated cell is not claimed to be detected by this one-point
mathematical computation. There are no disappearing assert guards in the
reviewed script.

The independent recomputation was actually executed under ordinary Python and
Python -O; both runs produced the same receipt bytes. Its 27 exact checks cover
input hashes/blobs, cell indexing, phase domains, both raw endpoints, strict
outward rounding, target margins, signed interval corner products, negative
denominator division and invalid-input rejection. This is an ordinary exact
recomputation plus mathematical interval semantics, not a new Lean proof of
the full generated narrow interval. No expensive kernel job was rerun here.

The existing kernel primitives and derivative bridge retain their separate
scoped verification records. Their identified imported objects were reused;
this review does not expand their status into a clean full-transitive rebuild.
The root generated JSON still declines to claim that its full interval
computation is a Lean term. The ordinary enclosure is valid without treating
the receipt, Python process or hash as a mathematical axiom.
