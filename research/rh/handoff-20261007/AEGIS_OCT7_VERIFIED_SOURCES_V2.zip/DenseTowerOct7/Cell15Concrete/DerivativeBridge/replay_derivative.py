#!/usr/bin/env python3
"""Pinned scoped compile of the actual generic correction derivative; no cell enclosure.

Identified imported OLEANs are bound and reused, not rebuilt transitively.
Every run has a fresh target object and a separate Lean kernel checker.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
OLD = WORK / 'GoalContinuation20261001/K2CompletionOct3/audit-20261003T020824.834148Z/receipt.json'
BIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
NAME = 'RHKreinCorrectionDerivativeOct7'
SOURCE = HERE / (NAME + '.lean')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

old = json.loads(OLD.read_text())
inputs = {str(OLD): sha(OLD), str(SOURCE): sha(SOURCE), str(Path(__file__).resolve()): sha(__file__)}
for p, h in old['input_bindings'].items():
    if not Path(p).is_file() or sha(p) != h:
        raise ValueError('identified prior input missing or modified: ' + p)
    inputs[p] = h
for compiler in [BIN / 'lean', BIN / 'leanchecker']:
    inputs[str(compiler)] = sha(compiler)

stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
outdir = HERE / ('scoped-replay-' + stamp)
(outdir / 'source').mkdir(parents=True)
(outdir / 'lib').mkdir()
src = outdir / 'source' / SOURCE.name
src.write_bytes(SOURCE.read_bytes())
inputs[str(src)] = sha(src)
env = dict(os.environ)
env['PATH'] = str(BIN) + ':' + env.get('PATH', '')
env['LEAN_PATH'] = str(outdir / 'lib') + ':' + old['LEAN_PATH']
jobs = []

def run(args, name):
    start = time.monotonic()
    job = subprocess.run(args, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, timeout=180, check=False)
    stdout_path = outdir / (name + '.stdout.txt')
    stderr_path = outdir / (name + '.stderr.txt')
    stdout_path.write_bytes(job.stdout)
    stderr_path.write_bytes(job.stderr)
    jobs.append({'name': name, 'command': args, 'exit_code': job.returncode,
                 'elapsed_seconds': time.monotonic() - start,
                 'stdout_sha256': sha(stdout_path),
                 'stderr_sha256': sha(stderr_path)})
    if job.returncode:
        raise ValueError('actual execution failed: ' + name)
    return job.stdout.decode()

status = 'FAILED'
reason = None
axiom_reports = []
try:
    version = run([str(BIN / 'lean'), '--version'], 'version').strip()
    if '4.33.1' not in version or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in version:
        raise ValueError('unexpected compiler pin: ' + version)
    deps = run([str(BIN / 'lean'), '--deps', str(src)], 'dependencies')
    for p in deps.splitlines():
        if Path(p).is_file():
            inputs[p] = sha(p)
    text = run([str(BIN / 'lean'), '--trust=0', '-DautoImplicit=false', '-j1', '-M4096',
                '--root=' + str(outdir / 'source'), '-o',
                str(outdir / 'lib' / (NAME + '.olean')), str(src)], 'compile')
    for suffix in ['hasDerivAt_sincDerivative', 'hasDerivAt_scaled_sinc',
                   'hasDerivAt_hatSum', 'hasDerivAt_splinePhase',
                   'hasDerivAt_splineSum', 'correctionSymbol_hasDerivAt_firstFormula',
                   'correctionSymbol_deriv_firstFormula', 'exactJetCoefficient_one_firstFormula']:
        endpoint = 'AEGIS.' + NAME + '.' + suffix
        match = re.search(re.escape("'" + endpoint + "' depends on axioms: [") + r'(.*?)\]', text, re.S)
        if match is None:
            raise ValueError('missing actual axiom report: ' + endpoint)
        axioms = [s.strip() for s in match.group(1).split(',') if s.strip()]
        if not set(axioms) <= {'propext', 'Classical.choice', 'Quot.sound'}:
            raise ValueError('unexpected axioms: ' + endpoint + ': ' + repr(axioms))
        axiom_reports.append({'theorem': endpoint, 'axioms': axioms})
    run([str(BIN / 'leanchecker'), '-v', NAME], 'leanchecker')
    if any(sha(p) != h for p, h in inputs.items()):
        raise ValueError('input changed during replay')
    status = 'PASS'
except Exception as exc:
    reason = str(exc)

receipt = {
    'schema': 'aegis.actual-correction-derivative.scoped-replay.v1',
    'status': status, 'reason': reason, 'input_bindings': inputs,
    'LEAN_PATH': env['LEAN_PATH'], 'jobs': jobs, 'axiom_reports': axiom_reports,
    'lean_version': '4.33.1',
    'lean_compiler_commit': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6',
    'mathlib_commit': '0df444a360eaa60ab8c11dca51a86af692955474',
    'cell15_coefficient_enclosure_audit': 'NOT_RUN',
    'rh_proven': False,
    'scope': 'Fresh generic derivative and exact k=1 jet transport for the actual public correction symbol at every nonzero t. No fifteenth-center coefficient enclosure. Identified imports reused; no clean transitive-source build.',
}
obj = outdir / 'lib' / (NAME + '.olean')
if obj.is_file():
    receipt['fresh_object_sha256'] = sha(obj)
path = outdir / 'RECEIPT.json'
path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': status, 'reason': reason, 'receipt': str(path), 'sha256': sha(path)}))
raise SystemExit(0 if status == 'PASS' else 1)
