import RHKreinSincIntervalV1
import RHKreinCellAnalyticBridgeV1

/-!
Generic first derivative of the actual public PR53 correction symbol.
Every original hat and spline column is retained. The removable singularity
of the quotient formula for sinc is excluded explicitly; no cell enclosure
or RH conclusion is asserted.
-/

set_option autoImplicit false
set_option maxRecDepth 2048
set_option maxHeartbeats 1500000
noncomputable section

namespace AEGIS.RHKreinCorrectionDerivativeOct7

open AEGIS.RHKreinExplicitCorrectionV1
open scoped BigOperators Topology

def sincDerivative (x : ℝ) : ℝ :=
  (x * Real.cos x - Real.sin x) / x ^ 2

def hatSum (t : ℝ) : ℝ :=
  ∑ j : Fin 199, (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j)

def hatSumDerivative (t : ℝ) : ℝ :=
  ∑ j : Fin 199, (hatCoefficient j : ℝ) *
    (-hatCenter j * Real.sin (t * hatCenter j))

def splinePhase (j : Fin 5) (t : ℝ) : ℝ :=
  if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
  else Real.sin (t * (1619 / 2000))

def splinePhaseDerivative (j : Fin 5) (t : ℝ) : ℝ :=
  if j.val % 2 = 0 then -(1619 / 2000) * Real.sin (t * (1619 / 2000))
  else (1619 / 2000) * Real.cos (t * (1619 / 2000))

def splineSum (t : ℝ) : ℝ :=
  ∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val * splinePhase j t

def splineSumDerivative (t : ℝ) : ℝ :=
  ∑ j : Fin 5, (splineCoefficient j : ℝ) *
    ((j.val : ℝ) * t ^ (j.val - 1) * splinePhase j t +
      t ^ j.val * splinePhaseDerivative j t)

def correctionFirstFormula (t : ℝ) : ℝ :=
  (2 / 50) *
    ((2 * Real.sinc (t / 100) * sincDerivative (t / 100) / 100) * hatSum t +
      Real.sinc (t / 100) ^ 2 * hatSumDerivative t) +
    (19 * Real.sinc (t / 2000) ^ 18 * sincDerivative (t / 2000) / 2000) *
      splineSum t +
    Real.sinc (t / 2000) ^ 19 * splineSumDerivative t

theorem hasDerivAt_sincDerivative (x : ℝ) (hx : x ≠ 0) :
    HasDerivAt Real.sinc (sincDerivative x) x := by
  have h := (Real.hasDerivAt_sin x).div (hasDerivAt_id x) hx
  have heq : Real.sinc =ᶠ[𝓝 x] (fun y : ℝ => Real.sin y / y) := by
    filter_upwards [eventually_ne_nhds hx] with y hy
    exact Real.sinc_of_ne_zero hy
  convert h.congr_of_eventuallyEq heq using 1 <;>
    first | rfl | (simp only [sincDerivative, id_eq]; ring)

theorem hasDerivAt_scaled_sinc (t d : ℝ) (ht : t ≠ 0) (hd : d ≠ 0) :
    HasDerivAt (fun x : ℝ => Real.sinc (x / d))
      (sincDerivative (t / d) / d) t := by
  have h := (hasDerivAt_sincDerivative (t / d) (div_ne_zero ht hd)).comp t
    ((hasDerivAt_id t).div_const d)
  simpa only [one_div, div_eq_mul_inv, id_eq, Function.comp_def, one_mul] using h

theorem hasDerivAt_hatSum (t : ℝ) :
    HasDerivAt hatSum (hatSumDerivative t) t := by
  unfold hatSum hatSumDerivative
  apply HasDerivAt.fun_sum
  intro j hj
  have h := (((hasDerivAt_id t).mul_const (hatCenter j)).cos).const_mul
    (hatCoefficient j : ℝ)
  convert h using 1 <;> first | rfl | (simp only [id_eq, one_mul]; ring)

theorem hasDerivAt_splinePhase (j : Fin 5) (t : ℝ) :
    HasDerivAt (splinePhase j) (splinePhaseDerivative j t) t := by
  unfold splinePhase splinePhaseDerivative
  split_ifs with hj
  · have h := ((hasDerivAt_id t).mul_const (1619 / 2000 : ℝ)).cos
    convert h using 1 <;> first | rfl | (simp only [id_eq, one_mul]; ring)
  · have h := ((hasDerivAt_id t).mul_const (1619 / 2000 : ℝ)).sin
    convert h using 1 <;> first | rfl | (simp only [id_eq, one_mul]; ring)

theorem hasDerivAt_splineSum (t : ℝ) :
    HasDerivAt splineSum (splineSumDerivative t) t := by
  unfold splineSum splineSumDerivative
  apply HasDerivAt.fun_sum
  intro j hj
  have h := (((hasDerivAt_id t).pow j.val).const_mul
    (splineCoefficient j : ℝ)).mul (hasDerivAt_splinePhase j t)
  convert h using 1 <;>
    first | rfl | (simp only [id_eq, Pi.pow_apply, one_mul]; ring)

theorem correctionSymbol_hasDerivAt_firstFormula (t : ℝ) (ht : t ≠ 0) :
    HasDerivAt correctionSymbol (correctionFirstFormula t) t := by
  have h100 := hasDerivAt_scaled_sinc t 100 ht (by norm_num)
  have h2000 := hasDerivAt_scaled_sinc t 2000 ht (by norm_num)
  have hh := ((h100.pow 2).const_mul (2 / 50 : ℝ)).mul (hasDerivAt_hatSum t)
  have he := (h2000.pow 19).mul (hasDerivAt_splineSum t)
  convert hh.add he using 1 <;>
    first | rfl | (simp only [correctionFirstFormula, Pi.pow_apply]; norm_num; ring)

theorem correctionSymbol_deriv_firstFormula (t : ℝ) (ht : t ≠ 0) :
    deriv correctionSymbol t = correctionFirstFormula t :=
  (correctionSymbol_hasDerivAt_firstFormula t ht).deriv

end AEGIS.RHKreinCorrectionDerivativeOct7

#check @AEGIS.RHKreinCorrectionDerivativeOct7.correctionSymbol_hasDerivAt_firstFormula
#check @AEGIS.RHKreinCorrectionDerivativeOct7.correctionSymbol_deriv_firstFormula
#print axioms AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_sincDerivative
#print axioms AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_scaled_sinc
#print axioms AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_hatSum
#print axioms AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_splinePhase
#print axioms AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_splineSum
#print axioms AEGIS.RHKreinCorrectionDerivativeOct7.correctionSymbol_hasDerivAt_firstFormula
#print axioms AEGIS.RHKreinCorrectionDerivativeOct7.correctionSymbol_deriv_firstFormula
