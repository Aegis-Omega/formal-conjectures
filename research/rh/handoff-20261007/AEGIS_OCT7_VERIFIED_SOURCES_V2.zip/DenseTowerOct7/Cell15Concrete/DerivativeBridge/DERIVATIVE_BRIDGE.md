# Actual PR53 first-derivative bridge

The new generic theorem proves the exact first derivative of the unchanged
public correction symbol at every nonzero real argument. Its companion
theorem identifies that expression with the actual normalized jet coefficient
`exactJetCoefficient t 1`, since `1! = 1`.

Let

\[
D(x)=\frac{x\cos x-\sin x}{x^2},\quad
H(t)=\sum_{j\in\mathrm{Fin}(199)}a_j\cos(tu_j),
\]

where the `a_j` and `u_j` are the actual `hatCoefficient` and `hatCenter`.
Write `v=1619/2000`, let `P_j(t)` be `cos(tv)` for even j and `sin(tv)`
for odd j, and put

\[
E(t)=\sum_{j\in\mathrm{Fin}(5)}b_jt^jP_j(t).
\]

Here each `b_j` is the actual public `splineCoefficient`; no data are changed.
Then

\[
H'(t)=\sum_j a_j[-u_j\sin(tu_j)],\qquad
E'(t)=\sum_j b_j[jt^{j-1}P_j(t)+t^jP'_j(t)],
\]

with `P'_j(t)=-v sin(tv)` for even j and `v cos(tv)` for odd j. The j=0
polynomial-derivative term vanishes because its multiplier is zero. The
formal expression uses natural-number truncated subtraction `j.val - 1`,
so there is no negative power at j=0.

For `t ≠ 0`, the result is

\[
\begin{aligned}
C'(t)={}&\frac2{50}\left[
 \frac{2\operatorname{sinc}(t/100)D(t/100)}{100}H(t)
 +\operatorname{sinc}(t/100)^2H'(t)\right]\\
&+\frac{19\operatorname{sinc}(t/2000)^{18}D(t/2000)}{2000}E(t)
 +\operatorname{sinc}(t/2000)^{19}E'(t).
\end{aligned}
\]

The proof first differentiates `sin x / x` away from zero. Its equality
with `Real.sinc` holds on a whole neighborhood of any nonzero x, so the
derivative transfers by an eventual-equality theorem. Chain rules preserve
the factors `1/100` and `1/2000`. Finite-sum, power, and product rules supply
every displayed term, including both sinc derivatives and the negative sine
derivatives of all cosine columns. The final kernel theorem unfolds the
actual imported `correctionSymbol`, rather than declaring this expression
to be a substitute correction.

The initial compile failed on notation and elaboration details and is
preserved as a failed attempt. After those repairs, the generic derivative
compiled without placeholders; the final source also transports k=1 into
the actual jet. Its fresh scoped compile and separate pinned kernel checker
passed. All eight theorem axiom reports contain only `propext`,
`Classical.choice`, and `Quot.sound`.

The compile identifies and reuses imported objects. It does not constitute
a clean rebuild of the transitive source closure. This module makes no
fifteenth-center enclosure, all-cell, global positivity, or RH claim.
Composing it with the center-specific exact rational budget is a separate
obligation, now with a proved exact analytic formula.
