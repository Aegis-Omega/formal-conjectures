import RHKreinCorrectionDerivativeOct7

set_option autoImplicit false
set_option pp.fullNames true
set_option maxRecDepth 2048
set_option maxHeartbeats 1500000
noncomputable section
namespace DerivativeIndependentLiteralAudit
open AEGIS.RHKreinExplicitCorrectionV1 AEGIS.RHKreinCorrectionDerivativeOct7
open scoped BigOperators

def sourceHatCoefficient : Fin 199 → ℚ :=
  ![-100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -190093321285891/2500000000,
    100000,
    100000,
    100000,
    100000,
    29666418987513/2500000000,
    -100000,
    -100000,
    -100000,
    -117731535372369/2500000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    50425751969473/2000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    515177348963881/10000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    100000,
    100000,
    100000,
    -51422462806047/1000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -116660983646653/1250000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -166526644754763/10000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -118048813499739/1250000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    2953816304371/1000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    100000,
    7920263226739/1000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -164690278619151/10000000000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    6934524025071/80000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    730856184163993/10000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    414340348739593/10000000000,
    100000,
    100000,
    100000,
    100000,
    378057512105339/10000000000,
    -100000,
    -100000,
    -100000,
    -618999438984917/10000000000,
    100000,
    100000,
    -100000,
    -100000,
    -101839738853771/2500000000,
    100000,
    100000,
    100000,
    100000,
    86995914959651/1000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    100000,
    100000,
    -25574621798421/400000000,
    -100000,
    -469702038657277/10000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -247976924265647/5000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -100000,
    296561423630109/10000000000,
    100000,
    100000,
    100000,
    100000,
    100000,
    -373908230082811/5000000000,
    -100000,
    -100000,
    -100000,
    -100000,
    -186287944404417/10000000000,
    100000,
    100000,
    100000,
    100000,
    -16872084697291/5000000000,
    -100000,
    -100000,
    -100000,
    200108515493551/10000000000,
    100000,
    100000,
    100000,
    -100000,
    -100000,
    -100000,
    -100000,
    730445128203157/10000000000,
    100000,
    100000,
    19841790224691/2000000000,
    -47556077772879/5000000000,
    100000,
    -886028847662807/10000000000,
    -100000,
    -100000,
    110857698784947/10000000000,
    100000,
    100000,
    -431069777588841/5000000000]

def sourceSplineCoefficient : Fin 5 → ℚ :=
  ![234102120892757/5000000000,
    -12240399939171/2500000000,
    -2918648959121/10000000000,
    123578990441/10000000000,
    9711997751/10000000000]

-- Both function equalities compare every literal entry, in original index order.
theorem all_199_hat_coefficients : hatCoefficient = sourceHatCoefficient := rfl
theorem all_5_spline_coefficients : splineCoefficient = sourceSplineCoefficient := rfl

theorem actual_hat_center (j : Fin 199) :
    hatCenter j = ((j.val : ℝ) + 41) / 50 := rfl

theorem actual_hat_derivative_terms (t : ℝ) :
    hatSumDerivative t =
      ∑ j : Fin 199, (sourceHatCoefficient j : ℝ) *
        (-(((j.val : ℝ) + 41) / 50) * Real.sin (t * (((j.val : ℝ) + 41) / 50))) := rfl

theorem actual_spline_derivative_terms (t : ℝ) :
    splineSumDerivative t =
      ∑ j : Fin 5, (sourceSplineCoefficient j : ℝ) *
        ((j.val : ℝ) * t ^ (j.val - 1) *
          (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
            else Real.sin (t * (1619 / 2000))) +
          t ^ j.val * (if j.val % 2 = 0 then -(1619 / 2000) * Real.sin (t * (1619 / 2000))
            else (1619 / 2000) * Real.cos (t * (1619 / 2000)))) := rfl

theorem degree_zero_term (t : ℝ) :
    (0 : ℝ) * t ^ (0 - 1 : ℕ) * splinePhase (0 : Fin 5) t +
      t ^ (0 : ℕ) * splinePhaseDerivative (0 : Fin 5) t =
      -(1619 / 2000) * Real.sin (t * (1619 / 2000)) := by
  simp [splinePhaseDerivative]

theorem degree_zero_hasDerivAt (t : ℝ) :
    HasDerivAt
      (fun x : ℝ => (sourceSplineCoefficient (0 : Fin 5) : ℝ) *
        x ^ (0 : ℕ) * Real.cos (x * (1619 / 2000)))
      ((sourceSplineCoefficient (0 : Fin 5) : ℝ) *
        (-(1619 / 2000) * Real.sin (t * (1619 / 2000)))) t := by
  simpa [splinePhase, splinePhaseDerivative] using
    (hasDerivAt_splinePhase (0 : Fin 5) t).const_mul
      (sourceSplineCoefficient (0 : Fin 5) : ℝ)

theorem exact_jet_actual_definition (t : ℝ) (k : ℕ) :
    AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient t k =
      ((k.factorial : ℝ)⁻¹) * iteratedDeriv k correctionSymbol t := rfl

theorem exact_jet_one_deriv (t : ℝ) :
    AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient t 1 = deriv correctionSymbol t := by
  simp only [exact_jet_actual_definition, Nat.factorial_one, Nat.cast_one,
    inv_one, one_mul, iteratedDeriv_one]

end DerivativeIndependentLiteralAudit

#check @AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_sincDerivative
#check @AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_scaled_sinc
#check @AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_hatSum
#check @AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_splinePhase
#check @AEGIS.RHKreinCorrectionDerivativeOct7.hasDerivAt_splineSum
#check @AEGIS.RHKreinCorrectionDerivativeOct7.correctionSymbol_hasDerivAt_firstFormula
#check @AEGIS.RHKreinCorrectionDerivativeOct7.correctionSymbol_deriv_firstFormula
#check @AEGIS.RHKreinCorrectionDerivativeOct7.exactJetCoefficient_one_firstFormula
#print axioms DerivativeIndependentLiteralAudit.all_199_hat_coefficients
#print axioms DerivativeIndependentLiteralAudit.all_5_spline_coefficients
#print axioms DerivativeIndependentLiteralAudit.actual_hat_derivative_terms
#print axioms DerivativeIndependentLiteralAudit.actual_spline_derivative_terms
#print axioms DerivativeIndependentLiteralAudit.degree_zero_term
#print axioms DerivativeIndependentLiteralAudit.degree_zero_hasDerivAt
#print axioms DerivativeIndependentLiteralAudit.exact_jet_actual_definition
#print axioms DerivativeIndependentLiteralAudit.exact_jet_one_deriv
