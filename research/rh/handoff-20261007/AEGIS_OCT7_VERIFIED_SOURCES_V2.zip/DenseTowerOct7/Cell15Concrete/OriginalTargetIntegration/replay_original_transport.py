#!/usr/bin/env python3
"""Capped scoped source replay of genuine original target imports.

Existing identified import objects are reused and bound, not represented as
a clean rebuild of their source closure. Missing original modules are built
from the restored exact bytes, without a replacement namespace or fake target.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
RESTORED = WORK / 'DenseTowerOct7/LibraryTransfer/Restored/source'
OLD = WORK / 'DenseTowerOct7/Cell15Concrete/AnalyticError/scoped-replay-20261007T061004.484237Z/RECEIPT.json'
BIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
NAME = 'RHKreinFifteenthCellK1ClosureOct7'
SOURCE = HERE / (NAME + '.lean')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

old = json.loads(OLD.read_text())
inputs = {str(OLD): sha(OLD), str(SOURCE): sha(SOURCE), str(Path(__file__).resolve()): sha(__file__)}
for p, h in old['input_bindings'].items():
    if not Path(p).is_file() or sha(p) != h:
        raise ValueError('identified prior input missing or modified: ' + p)
    inputs[p] = h
for compiler in [BIN / 'lean', BIN / 'leanchecker']:
    inputs[str(compiler)] = sha(compiler)

stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
outdir = HERE / ('scoped-original-replay-' + stamp)
(outdir / 'source').mkdir(parents=True)
(outdir / 'lib').mkdir()
(outdir / 'logs').mkdir()
env = dict(os.environ)
env['PATH'] = str(BIN) + ':' + env.get('PATH', '')
env['LEAN_PATH'] = str(outdir / 'lib') + ':' + old['LEAN_PATH']
jobs = []
modules = []
started = time.monotonic()

def run(args, name):
    if time.monotonic() - started > 720:
        raise ValueError('explicit 720-second total source-replay cap reached')
    start = time.monotonic()
    try:
        job = subprocess.run(args, env=env, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, timeout=90, check=False)
        stdout, stderr, code = job.stdout, job.stderr, job.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b'', exc.stderr or b'', None
    stdout_path = outdir / 'logs' / (name + '.stdout.txt')
    stderr_path = outdir / 'logs' / (name + '.stderr.txt')
    stdout_path.write_bytes(stdout)
    stderr_path.write_bytes(stderr)
    jobs.append({'name': name, 'command': args, 'exit_code': code,
                 'elapsed_seconds': time.monotonic() - start,
                 'stdout_sha256': sha(stdout_path),
                 'stderr_sha256': sha(stderr_path)})
    if code != 0:
        raise ValueError('actual execution failed or 90-second module cap: ' + name)
    return stdout.decode()

source_map = {str(p.relative_to(RESTORED))[:-5].replace('/', '.'): p
              for p in RESTORED.rglob('*.lean')}
source_map[NAME] = SOURCE
visited = set()

def cached(module):
    for root in env['LEAN_PATH'].split(':'):
        p = Path(root) / (module.replace('.', '/') + '.olean')
        if p.is_file():
            return p
    return None

def build(module, force=False):
    if module in visited:
        return
    visited.add(module)
    src = source_map.get(module)
    obj = cached(module)
    if obj is not None and not force:
        inputs[str(obj)] = sha(obj)
        record = {'module': module, 'status': 'REUSED_IDENTIFIED_IMPORT_OBJECT',
                  'object_path': str(obj), 'object_sha256': sha(obj),
                  'compiled_from_restored_source_claimed': False}
        if src is not None:
            record['restored_source_path'] = str(src)
            record['restored_source_sha256'] = sha(src)
            inputs[str(src)] = sha(src)
        modules.append(record)
        return
    if src is None:
        raise ValueError('required source/import object unavailable: ' + module)
    inputs[str(src)] = sha(src)
    imports = []
    for line in src.read_text().splitlines():
        match = re.match(r'\s*(?:public\s+)?import\s+(.+)', line)
        if match:
            imports.extend(match.group(1).split())
    for dependency in imports:
        build(dependency)
    dst = outdir / 'source' / (module.replace('.', '/') + '.lean')
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(src.read_bytes())
    obj = outdir / 'lib' / (module.replace('.', '/') + '.olean')
    obj.parent.mkdir(parents=True, exist_ok=True)
    deptext = run([str(BIN / 'lean'), '--deps', str(dst)], 'deps-' + module)
    for dependency in deptext.splitlines():
        if Path(dependency).is_file():
            inputs[dependency] = sha(dependency)
    text = run([str(BIN / 'lean'), '--trust=0', '-DautoImplicit=false', '-j1', '-M4096',
                '--root=' + str(outdir / 'source'), '-o', str(obj), str(dst)], 'compile-' + module)
    modules.append({'module': module, 'status': 'FRESH_ORIGINAL_SOURCE_COMPILE',
                    'source_path': str(src), 'source_sha256': sha(src),
                    'effective_source_path': str(dst), 'effective_source_sha256': sha(dst),
                    'object_path': str(obj), 'object_sha256': sha(obj)})
    print(json.dumps({'compiled': module, 'source_sha256': sha(src)}), flush=True)
    return text

status, reason, axiom_reports = 'FAILED', None, []
try:
    version = run([str(BIN / 'lean'), '--version'], 'version').strip()
    if '4.33.1' not in version or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in version:
        raise ValueError('unexpected compiler pin: ' + version)
    text = build(NAME, force=True)
    endpoint = 'AEGIS.' + NAME + '.fifteenthCenter_k1_enclosure'
    match = re.search(re.escape("'" + endpoint + "' depends on axioms: [") + r'(.*?)\]', text, re.S)
    if match is None:
        raise ValueError('missing actual final axiom report')
    axioms = [s.strip() for s in match.group(1).split(',') if s.strip()]
    if not set(axioms) <= {'propext', 'Classical.choice', 'Quot.sound'}:
        raise ValueError('unexpected axioms: ' + repr(axioms))
    axiom_reports.append({'theorem': endpoint, 'axioms': axioms})
    run([str(BIN / 'leanchecker'), '-v', NAME], 'leanchecker')
    if any(sha(p) != h for p, h in inputs.items()):
        raise ValueError('identified input changed during replay')
    status = 'PASS'
except Exception as exc:
    reason = str(exc)

receipt = {'schema': 'aegis.cell15-original-target-transport.scoped-replay.v1',
           'status': status, 'reason': reason, 'input_bindings': inputs,
           'LEAN_PATH': env['LEAN_PATH'], 'jobs': jobs, 'module_records': modules,
           'axiom_reports': axiom_reports, 'rh_proven': False,
           'scope': 'Genuine original target import; absent original modules compiled from exact restored source. Identified existing imports reused without claiming they were rebuilt from restored bytes. No RH theorem or whole-cell positivity claim.'}
p = outdir / 'RECEIPT.json'
p.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': status, 'reason': reason, 'receipt': str(p), 'sha256': sha(p)}))
raise SystemExit(0 if status == 'PASS' else 1)
