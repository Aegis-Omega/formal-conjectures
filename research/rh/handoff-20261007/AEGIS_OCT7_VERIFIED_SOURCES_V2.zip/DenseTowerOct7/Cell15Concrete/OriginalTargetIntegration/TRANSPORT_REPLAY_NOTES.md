# Actual original namespace transport

The source wrapper imports the genuine recovered `RHKreinFifteenthCellReductionV1`
and applies the separately kernel-proved actual k=1 bound after unfolding its
literal midpoint, target and radius. It has not been accepted as typechecked.
No definition-only replacement of the original namespace was used.

Two actual scoped attempts were executed and preserved:

1. `replay_original_transport.py` reused an identified historical FirstCell
   import object. The restored SecondCellComposition source failed because this
   older object lacks firstJet_two/four/six_enclosure and its first-cell result
   still takes even-jet premises. This is an API/source mismatch, not a claim
   that those results are mathematically unproved. The failed compiler's
   diagnostic sorryAx is not accepted by the final gate.
2. `replay_original_transport_current_first.py` forced the complete restored
   FirstCell source, without source edits. Lean aborted after 58.9 seconds with
   lean::memory_exception at interpreter, exit -6 under the explicit -M4096
   cap. It was not a 90-second timeout. No usable FirstCell object was accepted.

The original reduction's literal cell, midpoint, target and radius match the
new independently checked premise-free endpoint. Original-namespace transport
remains REPLAY_PENDING because its import closure has not been rebuilt in this
scoped resource allocation. This does not reopen or weaken the new theorem.

The exact failure receipts and their SHA256 identities are in TRANSPORT_RESULT.
Original sources, failed source snapshots and receipts remain unchanged.
Neither an original-namespace PASS, whole-cell closure, nor RH is claimed.

## Existing-proof composition fallback

The already verified `RHKreinZeroJetInterpolationV1` unconditionally supplies
exactly the three even-jet bounds and first-cell soundness needed by the older
FirstCell API. A separate effective SecondCellComposition source adds a real
import and substitutes these proof terms; its theorem declarations, targets,
and data are unchanged. Exact source bytes and unified diffs are preserved.
This actual effective module compiled successfully. Third/Fourth/Fifth
compositions needed the same final first-cell proof replacement, and all three
also compiled successfully. No FirstCell namespace was fabricated or changed.
An independent typed probe verified the three exact jet substitutions, complete
eight-jet packaging, and direct first-cell producer with trust0 plus checker;
its five axiom reports are the standard three.

The next actual original import is RHEulerGammaSharpV1. Its complete written
proof derives gamma<5773/10000 from the Mathlib harmonic/log sandwich at8192,
an exact rational harmonic upper bound and the existing log-two enclosure.
The one large simp/norm_num evaluation of harmonic8192 exceeds -M4096 in the
interpreter, so no fresh usable object was accepted. The older existing Euler
constant bound gamma<5792/10000 is weaker and cannot be substituted. The exact
source, raw memory diagnostic and failed receipt are retained. A balanced or
chunked exact-rational proof body of the same harmonic inequality would close
this replay resource obligation without changing the mathematics or k1 bound.

`TRANSPORT_FINAL_RESULT.json` records all four attempts and the independent
fallback. The original namespace wrapper remains REPLAY_PENDING; the new actual
coefficient endpoint and its independent kernel replay remain PASS. Do not
confuse this dependency execution issue with the global RH sign obstruction.
