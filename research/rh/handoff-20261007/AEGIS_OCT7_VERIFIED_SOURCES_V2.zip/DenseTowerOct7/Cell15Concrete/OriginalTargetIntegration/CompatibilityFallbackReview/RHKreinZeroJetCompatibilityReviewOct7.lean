import RHKreinZeroJetInterpolationV1

set_option autoImplicit false
noncomputable section
namespace AEGIS.RHKreinZeroJetCompatibilityReviewOct7
open AEGIS.RHKreinFirstCellV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinFiniteCertificateAssemblyV1

theorem existing_two :
    |exactJetCoefficient firstCenter 2 - firstJet 2| ≤ firstJetError 2 := by
  simpa only [firstJet, firstJetError, AEGIS.RHKreinZeroJetInterpolationV1.target2]
    using AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_two

theorem existing_four :
    |exactJetCoefficient firstCenter 4 - firstJet 4| ≤ firstJetError 4 := by
  simpa only [firstJet, firstJetError, AEGIS.RHKreinZeroJetInterpolationV1.target4]
    using AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_four

theorem existing_six :
    |exactJetCoefficient firstCenter 6 - firstJet 6| ≤ firstJetError 6 := by
  simpa only [firstJet, firstJetError, AEGIS.RHKreinZeroJetInterpolationV1.target6]
    using AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_six

theorem existing_eight_enclosures :
    ∀ k ∈ Finset.range 8,
      |exactJetCoefficient firstCenter k - firstJet k| ≤ firstJetError k := by
  intro k hk
  have hklt : k < 8 := Finset.mem_range.mp hk
  interval_cases k
  · rw [firstJet_zero_exact]; norm_num [firstJetError]
  · rw [firstJet_one_exact]; norm_num [firstJetError]
  · exact existing_two
  · rw [firstJet_three_exact]; norm_num [firstJetError]
  · exact existing_four
  · rw [firstJet_five_exact]; norm_num [firstJetError]
  · exact existing_six
  · rw [firstJet_seven_exact]; norm_num [firstJetError]

theorem actual_first_cell_sound : CellAnalyticSoundV1 firstCell :=
  AEGIS.RHKreinZeroJetInterpolationV1.firstCell_sound_from_finite_interpolation
end AEGIS.RHKreinZeroJetCompatibilityReviewOct7

#print AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_two
#print AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_four
#print AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_six
#print AEGIS.RHKreinZeroJetInterpolationV1.firstCell_sound_from_finite_interpolation
#print axioms AEGIS.RHKreinZeroJetCompatibilityReviewOct7.existing_two
#print axioms AEGIS.RHKreinZeroJetCompatibilityReviewOct7.existing_four
#print axioms AEGIS.RHKreinZeroJetCompatibilityReviewOct7.existing_six
#print axioms AEGIS.RHKreinZeroJetCompatibilityReviewOct7.existing_eight_enclosures
#print axioms AEGIS.RHKreinZeroJetCompatibilityReviewOct7.actual_first_cell_sound
