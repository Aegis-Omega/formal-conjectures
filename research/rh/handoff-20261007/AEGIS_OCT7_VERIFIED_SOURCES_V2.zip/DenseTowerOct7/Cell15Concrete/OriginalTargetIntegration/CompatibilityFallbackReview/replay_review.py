#!/usr/bin/env python3
"""Independent typed reuse probe against identified actual older FirstCell imports."""
import datetime, hashlib, json, os, re, subprocess, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
WORK=Path('/workspace/aegis-research/work')
OLD=WORK/'GoalContinuation20261001/K2CompletionOct3/audit-20261003T020824.834148Z/receipt.json'
BIN=Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
NAME='RHKreinZeroJetCompatibilityReviewOct7'
SOURCE=HERE/(NAME+'.lean')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads(OLD.read_text())
inputs={str(OLD):sha(OLD),str(SOURCE):sha(SOURCE),str(Path(__file__).resolve()):sha(__file__)}
for p,h in old['input_bindings'].items():
    if not Path(p).is_file() or sha(p)!=h: raise ValueError('Old binding changed: '+p)
    inputs[p]=h
for p in [BIN/'lean',BIN/'leanchecker',WORK/'DenseTowerOct7/LibraryTransfer/Restored/source/RHKreinSecondCellCompositionV1.lean',WORK/'GoalContinuation20261001/AnalyticReplay/ZeroJetCompatibilityOct3/RHKreinZeroJetInterpolationV1.lean']:
    inputs[str(p)]=sha(p)
context=WORK/'GoalContinuation20261001/AnalyticReplay/actual-context-20261003T004616.608552Z'
for name in ['RHKreinZeroJetInterpolationV1','RHKreinFirstCellV1']:
    inputs[str(context/'sources'/(name+'.lean'))]=sha(context/'sources'/(name+'.lean'))
out=HERE/('scoped-review-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
(out/'source').mkdir(parents=True); (out/'lib').mkdir()
src=out/'source'/SOURCE.name; src.write_bytes(SOURCE.read_bytes());inputs[str(src)]=sha(src)
env=dict(os.environ);env['PATH']=str(BIN)+':'+env.get('PATH','');env['LEAN_PATH']=str(out/'lib')+':'+old['LEAN_PATH']
jobs=[]
def run(args,name):
    start=time.monotonic();p=subprocess.run(args,env=env,capture_output=True,timeout=180)
    a=out/(name+'.stdout.txt');b=out/(name+'.stderr.txt');a.write_bytes(p.stdout);b.write_bytes(p.stderr)
    jobs.append({'name':name,'command':args,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(a),'stderr_sha256':sha(b)})
    if p.returncode:raise ValueError(name+' failed')
    return p.stdout.decode()
status='FAILED';reason=None;reports=[]
try:
    version=run([str(BIN/'lean'),'--version'],'version')
    if '4.33.1' not in version or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in version:raise ValueError('Compiler pin mismatch')
    for p in run([str(BIN/'lean'),'--deps',str(src)],'dependencies').splitlines():
        if Path(p).is_file():inputs[p]=sha(p)
    log=run([str(BIN/'lean'),'--trust=0','-DautoImplicit=false','-j1','-M4096','--root='+str(out/'source'),'-o',str(out/'lib'/(NAME+'.olean')),str(src)],'compile')
    for suffix in ['existing_two','existing_four','existing_six','existing_eight_enclosures','actual_first_cell_sound']:
        name='AEGIS.'+NAME+'.'+suffix
        match=re.search(re.escape("'"+name+"' depends on axioms: [")+r'(.*?)\]',log,re.S)
        if match is None:raise ValueError('Missing axiom audit '+name)
        axioms=[a.strip() for a in match.group(1).split(',') if a.strip()]
        if set(axioms)-{'propext','Classical.choice','Quot.sound'}:raise ValueError('Unexpected axioms')
        reports.append({'theorem':name,'axioms':axioms})
    run([str(BIN/'leanchecker'),'-v',NAME],'leanchecker')
    if any(sha(p)!=h for p,h in inputs.items()):raise ValueError('Input changed')
    status='PASS'
except Exception as exc:reason=str(exc)
receipt={'schema':'aegis.existing-zero-jet-actual-reuse-review.v1','status':status,'reason':reason,'rh_proven':False,'scope':'Fresh five typed adapters importing actual verified ZeroJetInterpolation and real older FirstCell. Original SecondCellComposition source read but not compiled in this probe; no namespace shim. Imported objects identified, not full transitive source rebuild.','input_bindings':inputs,'LEAN_PATH':env['LEAN_PATH'],'jobs':jobs,'axiom_reports':reports,'lean_version':'4.33.1','lean_compiler_commit':'819816b2e0a3bf405af45ae5c7af2491d8f5bee6','mathlib_commit':'0df444a360eaa60ab8c11dca51a86af692955474'}
if (out/'lib'/(NAME+'.olean')).is_file():receipt['object_sha256']=sha(out/'lib'/(NAME+'.olean'))
path=out/'RECEIPT.json';path.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':status,'reason':reason,'receipt':str(path),'sha256':sha(path)}))
raise SystemExit(status!='PASS')
