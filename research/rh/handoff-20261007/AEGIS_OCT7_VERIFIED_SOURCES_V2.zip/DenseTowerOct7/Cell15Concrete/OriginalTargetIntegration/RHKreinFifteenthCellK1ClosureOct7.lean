import RHKreinFifteenthCellReductionV1
import RHKreinCell15AnalyticErrorOct7

/-!
Transport into the ACTUAL restored original target module. This source imports
the genuine original module; it does not recreate an original namespace.
Its own typecheck requires the original dependency closure to be compiled.
-/

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFifteenthCellK1ClosureOct7

theorem fifteenthCenter_k1_enclosure :
    |AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient
        AEGIS.RHKreinFifteenthCellReductionV1.fifteenthCenter 1 -
      AEGIS.RHKreinFifteenthCellReductionV1.fifteenthJet 1| ≤
        AEGIS.RHKreinFifteenthCellReductionV1.fifteenthJetError 1 := by
  have h := AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure
  norm_num [AEGIS.RHKreinFifteenthCellReductionV1.fifteenthCenter,
    AEGIS.RHKreinFifteenthCellReductionV1.fifteenthJet,
    AEGIS.RHKreinFifteenthCellReductionV1.fifteenthJetError,
    AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter] at h ⊢
  exact h

end AEGIS.RHKreinFifteenthCellK1ClosureOct7

#check @AEGIS.RHKreinFifteenthCellK1ClosureOct7.fifteenthCenter_k1_enclosure
#print axioms AEGIS.RHKreinFifteenthCellK1ClosureOct7.fifteenthCenter_k1_enclosure
