# Scalar budget for the actual public PR53 fifteenth-cell midpoint

The pure rational scalar budget is now proved in pinned Lean. Its endpoint is

    |scalar_surrogate (5025/65536)
       - 347860160497148/10^15| ≤ 1/10^14.

The surrogate is the complete correction first-derivative formula with only
the following replacements: cosine by the degree-at-most-15 polynomial,
sine by the degree-15 polynomial, sinc by the degree-6 polynomial, and sinc's
derivative by (x*cosPolynomial15(x)-sinPolynomial15(x))/x². Every original
199 hat coefficient and all five spline columns remain in its definition,
including the powers 18 and 19 of the spline sinc factor and the derivative
of each phase and monomial. This scalar statement does not itself substitute
these approximations for the analytic function without a remainder theorem.

The stable definitions-only source is RHKreinCell15ScalarBudgetOct7.lean.
Its scalar_surrogate definition is the same one supplied to the independent
analytic-error assembly. Definitions are not changed by the proof modules.

The proof reuses the existing exact moments 0,2,4,6,8,10 and their real casts
from the PolynomialBudget source family. The public hat coefficient vector
and centre function are definitionally identical to that reused data; the
public_signed_moment theorem checks this transport. Only three new rational
moments were needed, evaluated by kernel reduction rather than native code:

| Moment | Exact value |
| --- | --- |
| 12 | -201758443798350852706381456922770596683 / 1220703125000000000000000000000 |
| 14 | -17633621433353862250529797848952241377594343 / 3051757812500000000000000000000000 |
| 16 | -1505970030944505758817914277182238287670322601123 / 7629394531250000000000000000000000000 |

Generic finite-sum identities then collapse the complete cosine hat sum to
moments 0 through 14 and the complete derivative sine hat sum to moments 2
through 16. Each identity is proved for every real t by finite-sum algebra and
ring normalization. There are no 199 separate trigonometric certificates.
After inserting the checked moments and all five literal spline coefficients,
norm_num proves the remaining single exact rational inequality at 5025/65536.

The initially proposed bound 1e-14 around the coarser centre
347860160497/10^12 was rejected before formalization: the reconstructed value
differs from that centre by about 1.4774e-13. The proved fine-centre bound
above has the correct target. A separately proved analytic-surrogate error
of at most 1e-13 can be combined with this scalar result and the exact centre
shift 148/10^15; their total is 258/10^15, below the requested radius 1e-12.
No analytic error premise is asserted as already discharged by this module.

Three actual fresh scoped compilations and separately executed pinned Lean
checkers succeeded, for definitions, extended moments, and scalar closure.
The closure's fully elaborated type and all ten new theorem axiom reports
are recorded; their only axioms are propext, Classical.choice and Quot.sound.
The rational moment proofs use decide +kernel. There is no sorry, unsafe,
native decision, new mathematical axiom or RH premise.

Pins are Lean 4.33.1, compiler
819816b2e0a3bf405af45ae5c7af2491d8f5bee6 and Mathlib
0df444a360eaa60ab8c11dca51a86af692955474. Identified imported sources/objects
are bound and reused; their full transitive source closure was not rebuilt.
This is a scoped scalar result on the current runner, not a final RH proof,
the user's original ZIP replay, or an enclosure of all 2199 cells.

Actual commands are in the three receipts under scoped-replay-20261007T060319.604969Z,
scoped-replay-20261007T060353.762007Z and scoped-replay-20261007T060448.125789Z.
Reproduction invokes replay_scalar.py for RHKreinCell15ScalarBudgetOct7,
then RHKreinCell15MomentsExtendedOct7, then RHKreinCell15ScalarClosureOct7 with
the first two generated library directories as arguments. Each call writes
its own new source/object/log directory and checks that selected inputs did
not change during execution.
