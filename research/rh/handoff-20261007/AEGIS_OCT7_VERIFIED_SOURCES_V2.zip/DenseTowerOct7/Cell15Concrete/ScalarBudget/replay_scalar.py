#!/usr/bin/env python3
"""Pinned fresh scalar-module compilation, with selected identified imports reused."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
BASE = WORK / 'DenseTowerOct7/Cell15Reuse/scoped-replay-20261007T054804.722998Z/RECEIPT.json'
BIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
NAME = sys.argv[1] if len(sys.argv) > 1 else 'RHKreinCell15ScalarBudgetOct7'
if not re.fullmatch(r'RHKreinCell15[A-Za-z0-9]+Oct7', NAME):
    raise ValueError('unsupported module name')
SOURCE = HERE / (NAME + '.lean')
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
base = json.loads(BASE.read_text())
inputs = {str(BASE): sha(BASE), str(SOURCE): sha(SOURCE), str(Path(__file__).resolve()): sha(__file__)}
for path, value in base['input_bindings'].items():
    if not Path(path).is_file() or sha(path) != value:
        raise ValueError('base input differs: ' + path)
    inputs[path] = value
base_obj = BASE.parent / 'lib/RHKreinTrig15Sinc6PublicOct7.olean'
if sha(base_obj) != base['fresh_object_sha256']:
    raise ValueError('base generic object differs')
inputs[str(base_obj)] = sha(base_obj)
for stem in ['RHKreinPolynomialBudgetDataV1', 'RHKreinPolynomialRationalMomentsV1',
             'RHKreinPolynomialHatMomentsCastV1', 'RHKreinPolynomialHatFactorizationV1']:
    for suffix in ['.lean', '.olean']:
        path = WORK / 'GoalContinuation20261001/PolynomialBudget' / (stem + suffix)
        inputs[str(path)] = sha(path)
for binary in [BIN / 'lean', BIN / 'leanchecker']:
    inputs[str(binary)] = sha(binary)
out = HERE / ('scoped-replay-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
(out / 'source').mkdir(parents=True)
(out / 'lib').mkdir()
copied = out / 'source' / SOURCE.name
copied.write_bytes(SOURCE.read_bytes())
inputs[str(copied)] = sha(copied)
additional = [Path(p) for p in sys.argv[2:]]
for directory in additional:
    if not directory.is_dir():
        raise ValueError('extra library missing: ' + str(directory))
    for obj in directory.glob('RHKreinCell15*.olean'):
        inputs[str(obj)] = sha(obj)
env = dict(os.environ)
env['PATH'] = str(BIN) + ':' + env.get('PATH', '')
env['LEAN_PATH'] = ':'.join([str(out / 'lib'), *(str(p) for p in additional), base['LEAN_PATH']])
jobs = []
def run(command, name):
    start = time.monotonic()
    result = subprocess.run(command, env=env, capture_output=True, timeout=300)
    stdout = out / (name + '.stdout.txt')
    stderr = out / (name + '.stderr.txt')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    jobs.append({'command': command, 'name': name, 'exit_code': result.returncode,
                 'elapsed_seconds': time.monotonic() - start,
                 'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
    if result.returncode:
        raise RuntimeError(name + ' failed: ' + result.stdout.decode()[-6000:])
    return result.stdout.decode()
status, reason, axioms = 'FAIL', None, []
try:
    version = run([str(BIN / 'lean'), '--version'], 'version')
    if '4.33.1' not in version or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in version:
        raise ValueError('wrong compiler pin')
    dependencies = run([str(BIN / 'lean'), '--deps', str(copied)], 'dependencies')
    for path in dependencies.splitlines():
        if Path(path).is_file():
            inputs[path] = sha(path)
    output = run([str(BIN / 'lean'), '--trust=0', '-DautoImplicit=false', '-j1', '-M6144',
                  '--root=' + str(out / 'source'), '-o', str(out / 'lib' / (NAME + '.olean')),
                  str(copied)], 'compile')
    for theorem, listing in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]", output):
        values = [s.strip() for s in listing.split(',') if s.strip()]
        if not set(values) <= {'propext', 'Classical.choice', 'Quot.sound'}:
            raise ValueError('unexpected axioms: ' + theorem)
        axioms.append({'theorem': theorem, 'axioms': values})
    run([str(BIN / 'leanchecker'), '-v', NAME], 'leanchecker')
    if any(sha(path) != value for path, value in inputs.items()):
        raise ValueError('input changed during execution')
    status = 'PASS'
except Exception as exc:
    reason = str(exc)
receipt = {'schema': 'aegis.oct7.cell15-scalar.scoped-replay.v1', 'status': status,
           'reason': reason, 'module': NAME, 'input_bindings': inputs,
           'LEAN_PATH': env['LEAN_PATH'], 'jobs': jobs, 'axiom_reports': axioms,
           'lean_version': '4.33.1', 'lean_compiler_commit': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6',
           'mathlib_commit': '0df444a360eaa60ab8c11dca51a86af692955474',
           'rh_proven': False, 'full_transitive_source_rebuild': False,
           'scope': 'Fresh selected scalar module, trust0 and pinned checker; identified imported objects reused. No RH claim.'}
obj = out / 'lib' / (NAME + '.olean')
if obj.is_file():
    receipt['fresh_object_sha256'] = sha(obj)
path = out / 'RECEIPT.json'
path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': status, 'reason': reason, 'receipt': str(path), 'sha256': sha(path)}))
raise SystemExit(0 if status == 'PASS' else 1)
