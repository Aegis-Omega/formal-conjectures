#!/usr/bin/env python3
"""New exact reconstruction from literal public PR53 data, not a v33 ZIP replay.

The analytic inputs are the already checked n=16 trig and n=8 sinc bounds.
This script performs rational interval arithmetic; it is not a Lean proof
of its full derivative formula or its generated certificate.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math
import re

HERE = Path(__file__).resolve().parent
WORK = HERE.parent.parent
SYMBOL = HERE.parent / 'PR53Lane/Public53/sources/AEGISOverlay/RHKreinExplicitCorrectionV1.lean'
CELLS = HERE.parent / 'PR53Lane/Public53/sources/AEGISOverlay/RHKreinFiniteCertificateDataV1.lean'
PUBLIC_HEAD = '81bcd289cd6df73901fc97168b00a3b04376eac9'
SYMBOL_BLOB = 'eaec6e0ebd43e5b528b2eea0bb05a1ffa93cd51c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def rational(text):
    text = text.strip()
    if not re.fullmatch(r'-?\d+(?:/\d+)?', text):
        raise ValueError('unsupported rational input')
    return F(text)


def coefficient_vector(text, name, count):
    match = re.search(r'def ' + name + r'\b[^\n]*\n\s*!\[(.*?)\]', text, re.S)
    if match is None:
        raise ValueError('missing literal vector ' + name)
    result = [rational(s) for s in match.group(1).split(',')]
    if len(result) != count:
        raise ValueError('coefficient vector length mismatch')
    return result


class I:
    def __init__(self, lo, hi=None):
        self.lo = F(lo)
        self.hi = F(lo if hi is None else hi)
        if self.lo > self.hi:
            raise ValueError('reversed interval')

    def __add__(self, other):
        other = other if isinstance(other, I) else I(other)
        return I(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self):
        return I(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + (-other if isinstance(other, I) else -I(other))

    def __mul__(self, other):
        other = other if isinstance(other, I) else I(other)
        values = [self.lo * other.lo, self.lo * other.hi,
                  self.hi * other.lo, self.hi * other.hi]
        return I(min(values), max(values))

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = other if isinstance(other, I) else I(other)
        if other.lo <= 0 <= other.hi:
            raise ValueError('division by interval containing zero')
        return self * I(1 / other.hi, 1 / other.lo)

    def __pow__(self, n):
        if not isinstance(n, int) or n < 0:
            raise ValueError('invalid interval power')
        result = I(1)
        for _ in range(n):
            result = result * self
        return result

    def bounded(self, lo, hi):
        return I(max(self.lo, F(lo)), min(self.hi, F(hi)))

    def data(self):
        return {'lower': str(self.lo), 'upper': str(self.hi),
                'width': str(self.hi - self.lo)}


def trig(x, sine):
    x = F(x)
    if abs(x) > 1:
        raise ValueError('Taylor phase exceeds proved domain')
    polynomial = sum(((-1) ** (k // 2) * x ** k / math.factorial(k)
                      for k in range(16) if k % 2 == int(sine)), F(0))
    error = (abs(x) ** 17 * F(18, math.factorial(17) * 17) if sine
             else abs(x) ** 16 * F(17, math.factorial(16) * 16))
    return I(polynomial - error, polynomial + error).bounded(-1, 1)


def sinc(x):
    x = F(x)
    if not 0 < x <= 1:
        raise ValueError('sinc domain must be positive and at most one')
    polynomial = sum(((-1) ** k * x ** (2 * k) / math.factorial(2 * k + 1)
                      for k in range(4)), F(0))
    error = x ** 8 * F(9, math.factorial(8) * 8) / x
    return I(polynomial - error, polynomial + error).bounded(-1, 1)


def sinc_derivative(x):
    x = F(x)
    if x == 0:
        raise ValueError('nonzero sinc derivative argument required')
    return (trig(x, False) * x - trig(x, True)) / (x * x)


def main():
    source = SYMBOL.read_bytes()
    cells = CELLS.read_bytes()
    if git_blob(source) != SYMBOL_BLOB:
        raise ValueError('public correction source blob mismatch')
    text = source.decode()
    hats = coefficient_vector(text, 'hatCoefficient', 199)
    edges = coefficient_vector(text, 'splineCoefficient', 5)
    cell_text = cells.decode().split('def finiteCells : List FiniteCellV1 := [', 1)[1].split(']', 1)[0]
    entries = re.findall(r'⟨\s*([^,]+),\s*([^,]+),\s*([^⟩]+)⟩', cell_text)
    if len(entries) != 2199:
        raise ValueError('serialized cell count mismatch')
    lo, hi, lower64 = (rational(s) for s in entries[14])
    if (lo, hi, lower64) != (F(2475, 32768), F(1275, 16384), F(292616690003685633)):
        raise ValueError('literal fifteenth cell mismatch')
    c = (lo + hi) / 2
    if c != F(5025, 65536):
        raise ValueError('midpoint mismatch')
    centres = [F(j + 41, 50) for j in range(199)]
    A = sum((trig(c * u, False) * a for a, u in zip(hats, centres)), I(0))
    Ap = sum((-trig(c * u, True) * (a * u) for a, u in zip(hats, centres)), I(0))
    beta = F(1619, 2000)
    B = I(0)
    Bp = I(0)
    for j, d in enumerate(edges):
        v = trig(c * beta, bool(j % 2))
        vp = (trig(c * beta, False) if j % 2 else -trig(c * beta, True)) * beta
        B += v * (d * c ** j)
        Bp += vp * (d * c ** j)
        if j:
            Bp += v * (d * j * c ** (j - 1))
    S = sinc(c / 100)
    Sp = sinc_derivative(c / 100) / 100
    H = sinc(c / 2000)
    Hp = sinc_derivative(c / 2000) / 2000
    derivative = (2 * S * Sp * A + S ** 2 * Ap) / 25 + 19 * H ** 18 * Hp * B + H ** 19 * Bp
    target = F(347860160497, 10 ** 12)
    radius = F(1, 10 ** 12)
    margin = min(derivative.lo - (target - radius), target + radius - derivative.hi)
    if margin <= 0:
        raise ValueError('generated enclosure fails requested twelve-decimal target')
    report = {
        'schema': 'aegis.cell15.new-exact-fraction-sine17-reconstruction.v1',
        'status': 'EXACT_RATIONAL_ARITHMETIC_PASS_ANALYTIC_PORT_PENDING',
        'public_PR53_head': PUBLIC_HEAD,
        'source_bindings': [
            {'path': str(SYMBOL.relative_to(WORK)), 'sha256': sha(source), 'git_blob': git_blob(source)},
            {'path': str(CELLS.relative_to(WORK)), 'sha256': sha(cells), 'git_blob': git_blob(cells)},
            {'path': str(Path(__file__).relative_to(WORK)), 'sha256': sha(Path(__file__).read_bytes())}],
        'one_based_cell_index': 15,
        'literal_cell': {'lo': str(lo), 'hi': str(hi), 'lower64': str(lower64)},
        'reconstructed_midpoint': str(c),
        'candidate_target': 'exactJetCoefficient (5025/65536) 1 = deriv correctionSymbol (5025/65536)',
        'hat_count': len(hats), 'edge_count': len(edges),
        'max_hat_phase': str(max(c * u for u in centres)),
        'derivative_enclosure': derivative.data(),
        'twelve_decimal_target': str(target), 'target_radius': str(radius),
        'minimum_margin': str(margin),
        'Taylor_inputs': 'Kernel-checked n17 sine (same degree15 polynomial), n16 cosine; n8 sinc; x>0 and |x|<=1 checked with rationals',
        'float_decisions': False,
        'identity_with_user_ZIP_claimed': False,
        'full_derivative_formula_Lean_proof': False,
        'generated_enclosure_Lean_proof': False,
        'user_reported_width': '3.995e-14',
        'user_reported_margin': '8.323e-13',
        'rh_proven': False,
    }
    destination = HERE / 'EXACT_FRACTION_SINE17_RECONSTRUCTION.json'
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    def outward_integer(x, places):
        return x.numerator * 10 ** places // x.denominator
    print(json.dumps({'status': report['status'], 'centre': str(c),
                      'source_sha256': report['source_bindings'][2]['sha256'],
                      'receipt_sha256': sha(destination.read_bytes()),
                      'lower_floor_1e24': outward_integer(derivative.lo, 24),
                      'upper_ceil_1e24': -outward_integer(-derivative.hi, 24),
                      'width_ceil_1e30': -outward_integer(-(derivative.hi-derivative.lo), 30),
                      'margin_floor_1e30': outward_integer(margin, 30),
                      'within_reported_v33_interval':
                          F(347860160497147,10**15) < derivative.lo and
                          derivative.hi < F(347860160497149,10**15),
                      'rh_proven': False}))



if __name__ == '__main__':
    main()
