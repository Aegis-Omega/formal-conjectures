import RHKreinSincIntervalV1

/-!
Public normal-form adapters for the existing arbitrary-order exponential
Taylor kernel. These are a new reconstruction from identified sources, not
recovered exports from the unavailable fifteenth-cell ZIP.

No fifteenth cell, centre, coefficient interval, or RH conclusion is asserted.
The hat phase is the actual public PR53 `hatCenter` and its range condition
remains an explicit argument until the requested centre is supplied.
-/

set_option autoImplicit false
set_option maxRecDepth 2048
set_option maxHeartbeats 1500000
noncomputable section

namespace AEGIS.RHKreinTrig15Sinc6PublicOct7

open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinSincIntervalV1
open AEGIS.RHKreinExplicitCorrectionV1

def cosPolynomial15 (x : ℝ) : ℝ :=
  1 - x ^ 2 / 2 + x ^ 4 / 24 - x ^ 6 / 720 +
    x ^ 8 / 40320 - x ^ 10 / 3628800 +
    x ^ 12 / 479001600 - x ^ 14 / 87178291200

def sinPolynomial15 (x : ℝ) : ℝ :=
  x - x ^ 3 / 6 + x ^ 5 / 120 - x ^ 7 / 5040 +
    x ^ 9 / 362880 - x ^ 11 / 39916800 +
    x ^ 13 / 6227020800 - x ^ 15 / 1307674368000

theorem expIPartial_sixteen_re (x : ℝ) :
    (expIPartial 16 x).re = cosPolynomial15 x := by
  norm_num [expIPartial, cosPolynomial15, Finset.sum_range_succ,
    pow_succ, Complex.mul_re]
  ring

theorem expIPartial_sixteen_im (x : ℝ) :
    (expIPartial 16 x).im = sinPolynomial15 x := by
  norm_num [expIPartial, sinPolynomial15, Finset.sum_range_succ,
    pow_succ, Complex.mul_im]
  ring

theorem expIPartial_eight_im_div (x : ℝ) (hx : x ≠ 0) :
    (expIPartial 8 x).im / x = sincPolynomial7 x := by
  norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
    pow_succ, Complex.mul_im]
  field_simp
  ring

theorem cos_degree15_error (x : ℝ) (hx : |x| ≤ 1) :
    |Real.cos x - cosPolynomial15 x| ≤
      |x| ^ 16 * (17 / (20922789888000 * 16) : ℝ) := by
  have h := cos_expIPartial_error 16 x (by norm_num) hx
  rw [expIPartial_sixteen_re] at h
  norm_num at h ⊢
  exact h

theorem sin_degree15_error (x : ℝ) (hx : |x| ≤ 1) :
    |Real.sin x - sinPolynomial15 x| ≤
      |x| ^ 16 * (17 / (20922789888000 * 16) : ℝ) := by
  have h := sin_expIPartial_error 16 x (by norm_num) hx
  rw [expIPartial_sixteen_im] at h
  norm_num at h ⊢
  exact h

theorem sinc_degree6_error (x : ℝ) (hx0 : 0 < x) (hx1 : |x| ≤ 1) :
    |Real.sinc x - sincPolynomial7 x| ≤
      |x| ^ 8 * (9 / (40320 * 8) : ℝ) / x := by
  have h := sinc_expIPartial_error 8 x (by norm_num) hx0 hx1
  rw [expIPartial_eight_im_div x (ne_of_gt hx0)] at h
  norm_num at h ⊢
  exact h

/-- The actual indexed PR53 hat-sine phase needs no 199 separate proofs. -/
theorem hat_sine_degree15_error (c : ℝ) (j : Fin 199)
    (hphase : |c * hatCenter j| ≤ 1) :
    |Real.sin (c * hatCenter j) -
        sinPolynomial15 (c * hatCenter j)| ≤
      |c * hatCenter j| ^ 16 *
        (17 / (20922789888000 * 16) : ℝ) :=
  sin_degree15_error (c * hatCenter j) hphase

end AEGIS.RHKreinTrig15Sinc6PublicOct7

#check @AEGIS.RHKreinTrig15Sinc6PublicOct7.expIPartial_sixteen_re
#check @AEGIS.RHKreinTrig15Sinc6PublicOct7.expIPartial_sixteen_im
#check @AEGIS.RHKreinTrig15Sinc6PublicOct7.expIPartial_eight_im_div
#check @AEGIS.RHKreinTrig15Sinc6PublicOct7.cos_degree15_error
#check @AEGIS.RHKreinTrig15Sinc6PublicOct7.sin_degree15_error
#check @AEGIS.RHKreinTrig15Sinc6PublicOct7.sinc_degree6_error
#check @AEGIS.RHKreinTrig15Sinc6PublicOct7.hat_sine_degree15_error
#print axioms AEGIS.RHKreinTrig15Sinc6PublicOct7.expIPartial_sixteen_re
#print axioms AEGIS.RHKreinTrig15Sinc6PublicOct7.expIPartial_sixteen_im
#print axioms AEGIS.RHKreinTrig15Sinc6PublicOct7.expIPartial_eight_im_div
#print axioms AEGIS.RHKreinTrig15Sinc6PublicOct7.cos_degree15_error
#print axioms AEGIS.RHKreinTrig15Sinc6PublicOct7.sin_degree15_error
#print axioms AEGIS.RHKreinTrig15Sinc6PublicOct7.sinc_degree6_error
#print axioms AEGIS.RHKreinTrig15Sinc6PublicOct7.hat_sine_degree15_error
