import RHKreinCell15PhasesOct7

/-!
Reuse the existing public seventeen-term exponential error theorem while
keeping the exact degree-fifteen sine polynomial unchanged. The sixteenth
power contributes only to the real coordinate. No cell enclosure is asserted.
-/

set_option autoImplicit false
set_option maxRecDepth 2048
set_option maxHeartbeats 1500000
noncomputable section

namespace AEGIS.RHKreinCell15Sine17Oct7

open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinTrig15Sinc6PublicOct7
open AEGIS.RHKreinCell15PhasesOct7
open AEGIS.RHKreinExplicitCorrectionV1

theorem expIPartial_seventeen_im (x : ℝ) :
    (expIPartial 17 x).im = sinPolynomial15 x := by
  norm_num [expIPartial, sinPolynomial15, Finset.sum_range_succ,
    pow_succ, Complex.mul_im]
  ring

theorem sin_degree15_error_seventeen (x : ℝ) (hx : |x| ≤ 1) :
    |Real.sin x - sinPolynomial15 x| ≤
      |x| ^ 17 * (18 / (355687428096000 * 17) : ℝ) := by
  have h := sin_expIPartial_error 17 x (by norm_num) hx
  rw [expIPartial_seventeen_im] at h
  norm_num at h ⊢
  exact h

theorem fifteenthCenter_hat_sine_error_seventeen (j : Fin 199) :
    |Real.sin (fifteenthCenter * hatCenter j) -
        sinPolynomial15 (fifteenthCenter * hatCenter j)| ≤
      |fifteenthCenter * hatCenter j| ^ 17 *
        (18 / (355687428096000 * 17) : ℝ) :=
  sin_degree15_error_seventeen _ (fifteenthCenter_hat_phase_abs j)

theorem fifteenthCenter_edge_sine_error_seventeen :
    |Real.sin (fifteenthCenter * (1619 / 2000 : ℝ)) -
        sinPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      |fifteenthCenter * (1619 / 2000 : ℝ)| ^ 17 *
        (18 / (355687428096000 * 17) : ℝ) :=
  sin_degree15_error_seventeen _ (by norm_num [fifteenthCenter])

end AEGIS.RHKreinCell15Sine17Oct7

#check @AEGIS.RHKreinCell15Sine17Oct7.expIPartial_seventeen_im
#check @AEGIS.RHKreinCell15Sine17Oct7.sin_degree15_error_seventeen
#check @AEGIS.RHKreinCell15Sine17Oct7.fifteenthCenter_hat_sine_error_seventeen
#check @AEGIS.RHKreinCell15Sine17Oct7.fifteenthCenter_edge_sine_error_seventeen
#print axioms AEGIS.RHKreinCell15Sine17Oct7.expIPartial_seventeen_im
#print axioms AEGIS.RHKreinCell15Sine17Oct7.sin_degree15_error_seventeen
#print axioms AEGIS.RHKreinCell15Sine17Oct7.fifteenthCenter_hat_sine_error_seventeen
#print axioms AEGIS.RHKreinCell15Sine17Oct7.fifteenthCenter_edge_sine_error_seventeen
