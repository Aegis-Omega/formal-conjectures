import RHKreinTrig15Sinc6PublicOct7
import RHKreinPolynomialHatFactorizationV1

set_option autoImplicit false
set_option maxRecDepth 32768
set_option maxHeartbeats 32000000
noncomputable section

namespace AEGIS.RHKreinCell15ScalarBudgetOct7

open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinTrig15Sinc6PublicOct7
open AEGIS.RHKreinSincIntervalV1
open scoped BigOperators

def sincDerivativeP (x : ℝ) : ℝ :=
  (x * cosPolynomial15 x - sinPolynomial15 x) / x ^ 2

def hatSumP (t : ℝ) : ℝ :=
  ∑ j : Fin 199, (hatCoefficient j : ℝ) * cosPolynomial15 (t * hatCenter j)

def hatSumDerivativeP (t : ℝ) : ℝ :=
  ∑ j : Fin 199, (hatCoefficient j : ℝ) *
    (-hatCenter j * sinPolynomial15 (t * hatCenter j))

def splinePhaseP (j : Fin 5) (t : ℝ) : ℝ :=
  if j.val % 2 = 0 then cosPolynomial15 (t * (1619 / 2000))
  else sinPolynomial15 (t * (1619 / 2000))

def splinePhaseDerivativeP (j : Fin 5) (t : ℝ) : ℝ :=
  if j.val % 2 = 0 then -(1619 / 2000) * sinPolynomial15 (t * (1619 / 2000))
  else (1619 / 2000) * cosPolynomial15 (t * (1619 / 2000))

def splineSumP (t : ℝ) : ℝ :=
  ∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val * splinePhaseP j t

def splineSumDerivativeP (t : ℝ) : ℝ :=
  ∑ j : Fin 5, (splineCoefficient j : ℝ) *
    ((j.val : ℝ) * t ^ (j.val - 1) * splinePhaseP j t +
      t ^ j.val * splinePhaseDerivativeP j t)

def scalar_surrogate (t : ℝ) : ℝ :=
  (2 / 50) *
    ((2 * sincPolynomial7 (t / 100) * sincDerivativeP (t / 100) / 100) *
      hatSumP t + sincPolynomial7 (t / 100) ^ 2 * hatSumDerivativeP t) +
    (19 * sincPolynomial7 (t / 2000) ^ 18 * sincDerivativeP (t / 2000) / 2000) *
      splineSumP t +
    sincPolynomial7 (t / 2000) ^ 19 * splineSumDerivativeP t

end AEGIS.RHKreinCell15ScalarBudgetOct7
