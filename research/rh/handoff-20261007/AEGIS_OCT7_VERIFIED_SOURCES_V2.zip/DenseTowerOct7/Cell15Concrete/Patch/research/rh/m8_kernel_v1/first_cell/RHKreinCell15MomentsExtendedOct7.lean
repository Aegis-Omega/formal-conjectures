import RHKreinPolynomialHatMomentsCastV1
import RHKreinTrig15Sinc6PublicOct7

set_option autoImplicit false
set_option maxRecDepth 32768
set_option maxHeartbeats 32000000
noncomputable section

namespace AEGIS.RHKreinCell15MomentsExtendedOct7
open scoped BigOperators
open AEGIS.GoalContinuation20261001.PolynomialBudget

theorem public_signed_moment (e : ℕ) :
    (∑ j : Fin 199, (AEGIS.RHKreinExplicitCorrectionV1.hatCoefficient j : ℝ) *
      AEGIS.RHKreinExplicitCorrectionV1.hatCenter j ^ e) = signedMoment e := rfl

theorem rationalMoment_12 : signedMomentQ 12 =
    (-201758443798350852706381456922770596683 /
      1220703125000000000000000000000 : ℚ) := by
  decide +kernel

theorem rationalMoment_14 : signedMomentQ 14 =
    (-17633621433353862250529797848952241377594343 /
      3051757812500000000000000000000000 : ℚ) := by
  decide +kernel

theorem rationalMoment_16 : signedMomentQ 16 =
    (-1505970030944505758817914277182238287670322601123 /
      7629394531250000000000000000000000000 : ℚ) := by
  decide +kernel

theorem moment_12 : signedMoment 12 =
    (-201758443798350852706381456922770596683 /
      1220703125000000000000000000000 : ℝ) := by
  rw [signedMoment_eq_cast, rationalMoment_12]
  norm_num

theorem moment_14 : signedMoment 14 =
    (-17633621433353862250529797848952241377594343 /
      3051757812500000000000000000000000 : ℝ) := by
  rw [signedMoment_eq_cast, rationalMoment_14]
  norm_num

theorem moment_16 : signedMoment 16 =
    (-1505970030944505758817914277182238287670322601123 /
      7629394531250000000000000000000000000 : ℝ) := by
  rw [signedMoment_eq_cast, rationalMoment_16]
  norm_num

end AEGIS.RHKreinCell15MomentsExtendedOct7

#print axioms AEGIS.RHKreinCell15MomentsExtendedOct7.public_signed_moment
#print axioms AEGIS.RHKreinCell15MomentsExtendedOct7.rationalMoment_12
#print axioms AEGIS.RHKreinCell15MomentsExtendedOct7.rationalMoment_14
#print axioms AEGIS.RHKreinCell15MomentsExtendedOct7.rationalMoment_16
#print axioms AEGIS.RHKreinCell15MomentsExtendedOct7.moment_12
#print axioms AEGIS.RHKreinCell15MomentsExtendedOct7.moment_14
#print axioms AEGIS.RHKreinCell15MomentsExtendedOct7.moment_16
