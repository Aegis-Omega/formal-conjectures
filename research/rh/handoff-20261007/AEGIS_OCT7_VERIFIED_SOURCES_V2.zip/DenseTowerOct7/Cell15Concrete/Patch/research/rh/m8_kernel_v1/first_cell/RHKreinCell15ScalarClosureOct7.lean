import RHKreinCell15ScalarBudgetOct7
import RHKreinCell15MomentsExtendedOct7

set_option autoImplicit false
set_option maxRecDepth 32768
set_option maxHeartbeats 32000000
noncomputable section

namespace AEGIS.RHKreinCell15ScalarClosureOct7

open AEGIS.RHKreinCell15ScalarBudgetOct7
open AEGIS.RHKreinTrig15Sinc6PublicOct7
open AEGIS.RHKreinSincIntervalV1
open AEGIS.GoalContinuation20261001.PolynomialBudget
open AEGIS.RHKreinCell15MomentsExtendedOct7
open scoped BigOperators

theorem hatSumP_factor (t : ℝ) :
    hatSumP t =
      signedMoment 0 - (t ^ 2 / 2) * signedMoment 2 +
      (t ^ 4 / 24) * signedMoment 4 - (t ^ 6 / 720) * signedMoment 6 +
      (t ^ 8 / 40320) * signedMoment 8 - (t ^ 10 / 3628800) * signedMoment 10 +
      (t ^ 12 / 479001600) * signedMoment 12 -
      (t ^ 14 / 87178291200) * signedMoment 14 := by
  change (∑ j : Fin 199, (hatCoefficient j : ℝ) *
      cosPolynomial15 (t * hatCenter j)) = _
  unfold signedMoment
  simp only [pow_zero, mul_one]
  simp_rw [Finset.mul_sum]
  simp only [← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro j _
  unfold cosPolynomial15
  ring

theorem hatSumDerivativeP_factor (t : ℝ) :
    hatSumDerivativeP t =
      (-t) * signedMoment 2 + (t ^ 3 / 6) * signedMoment 4 -
      (t ^ 5 / 120) * signedMoment 6 + (t ^ 7 / 5040) * signedMoment 8 -
      (t ^ 9 / 362880) * signedMoment 10 +
      (t ^ 11 / 39916800) * signedMoment 12 -
      (t ^ 13 / 6227020800) * signedMoment 14 +
      (t ^ 15 / 1307674368000) * signedMoment 16 := by
  change (∑ j : Fin 199, (hatCoefficient j : ℝ) *
      (-hatCenter j * sinPolynomial15 (t * hatCenter j))) = _
  unfold signedMoment
  simp_rw [Finset.mul_sum]
  simp only [← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro j _
  unfold sinPolynomial15
  ring

theorem scalar_surrogate_cell15 :
    |scalar_surrogate (5025 / 65536 : ℝ) -
      (347860160497148 / 1000000000000000 : ℝ)| ≤
        (1 / 100000000000000 : ℝ) := by
  unfold scalar_surrogate
  rw [hatSumP_factor, hatSumDerivativeP_factor]
  rw [moment_0, moment_2, moment_4, moment_6, moment_8, moment_10,
    moment_12, moment_14, moment_16]
  norm_num [sincDerivativeP, sincPolynomial7, cosPolynomial15, sinPolynomial15,
    splineSumP, splineSumDerivativeP, splinePhaseP, splinePhaseDerivativeP,
    AEGIS.RHKreinExplicitCorrectionV1.splineCoefficient, Fin.sum_univ_succ]

end AEGIS.RHKreinCell15ScalarClosureOct7

#check @AEGIS.RHKreinCell15ScalarClosureOct7.scalar_surrogate_cell15
#print axioms AEGIS.RHKreinCell15ScalarClosureOct7.hatSumP_factor
#print axioms AEGIS.RHKreinCell15ScalarClosureOct7.hatSumDerivativeP_factor
#print axioms AEGIS.RHKreinCell15ScalarClosureOct7.scalar_surrogate_cell15
