# Executed pinned commands and scope

From /workspace/aegis-research/work, the primary and independent final endpoint
receipts were produced by separate invocations of:

```sh
python3 DenseTowerOct7/Cell15Concrete/AnalyticError/replay_enclosure.py
```

This driver first checks all prior source/cache/compiler SHA bindings, copies
the frozen source into a fresh scoped directory, obtains exact dependencies,
and executes Lean 4.33.1 with explicit `--trust=0 -DautoImplicit=false -j1
-M4096`, producing a new object. It then checks the two actual full endpoint
types and all axiom lists and invokes the pinned leanchecker. The complete argv,
LEAN_PATH, copied source, stdout/stderr and all hashes are in each receipt and
its neighboring raw logs. No unrecorded hosted job was executed.

Prior genuinely executed building blocks were obtained using:

```sh
python3 DenseTowerOct7/Cell15Reuse/replay_public_adapters.py
python3 DenseTowerOct7/Cell15Concrete/replay_phases.py
python3 DenseTowerOct7/Cell15Concrete/DerivativeBridge/replay_derivative.py
python3 DenseTowerOct7/Cell15Concrete/AnalyticError/Pointwise/replay_pointwise.py
python3 DenseTowerOct7/Cell15Concrete/ScalarBudget/replay_scalar.py RHKreinCell15ScalarBudgetOct7
python3 DenseTowerOct7/Cell15Concrete/ScalarBudget/replay_scalar.py RHKreinCell15MomentsExtendedOct7
python3 DenseTowerOct7/Cell15Concrete/ScalarBudget/replay_scalar.py RHKreinCell15ScalarClosureOct7
python3 DenseTowerOct7/Cell15Concrete/AnalyticError/replay_sum_bounds.py
python3 DenseTowerOct7/Cell15Concrete/replay_sine17.py
```

DerivativeErrors has directly recorded pinned compile/checker commands in its
RECEIPT.json and raw job logs; no nonexistent replay script is asserted.
The three scalar driver invocations separately produced definitions, extended
moments and final scalar closure. Identified preceding imports are reused. Its retained receipt paths are source-bound inputs to
the final endpoint replay. Sources above are in the live checkpoint; the
source-only patch by itself does not contain the entire existing cache context.

The main final replay source and driver are frozen. Its inherited introductory
docstring saying it is not a coefficient enclosure is stale prose; actual
commands and audited full types verify the coefficient enclosure explicitly.
`reported_zip_available:false` means no raw ZIP container was downloaded;
original text sources were subsequently restored and separately SHA/Git-bound.

Four capped attempts of the genuine recovered original-namespace wrapper are
separately recorded in OriginalTargetIntegration. The first exposed an old
import API mismatch. The second forced exact restored FirstCell bytes and
aborted under -M4096 with a lean::memory_exception. Neither is a wrapper PASS.
The existing-proof fallback then compiled four real effective cell composition
modules by explicit proof-only substitutions. The next exact original sharp
Euler-constant module hit the 4 GiB interpreter cap on harmonic8192 arithmetic.
The wrapper remains pending; detailed attempts and independent reuse checks are
in the included original transport result. None of these failures changes the
independently checked actual coefficient term.

All runs are scoped fresh endpoint builds with identified imports reused, not
fresh clean rebuilds of the entire transitive closure or independent-machine
replay. For a portable new checkout, first build the pinned prerequisite lane
and provider sources, then compile these new modules in dependency order with
its module root and cache context; changing a required source demands a new
appropriately bound check.
