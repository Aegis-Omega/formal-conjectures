#!/usr/bin/env python3
"""Fresh scoped kernel replay; imported dependency objects are reused explicitly."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

D = Path(__file__).resolve().parent
W = D.parent.parent
BIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
CONTEXT = W/'CIRepairOct3/Recent/pr45-changed-scope-20261003T023554.129814Z/receipt.json'
SOURCE = D/'WeilTowerButterflyOct7.lean'
EXPECTED = {'propext', 'Classical.choice', 'Quot.sound'}
NAMES = ['translation_factor_add', 'twoPoint_translation_kernel',
         'plus_minus_kernel_sum', 'plus_minus_kernel_difference',
         'imaginary_phase_kernel_difference', 'four_corner_quadratic']

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    out = D/('scoped-replay-'+stamp)
    (out/'source').mkdir(parents=True)
    (out/'lib').mkdir()
    snapshot = out/'source'/SOURCE.name
    snapshot.write_bytes(SOURCE.read_bytes())
    roots = [Path(p) for p in json.loads(CONTEXT.read_text())['explicit_root_order']]
    obj = next((p/'WeilZeroTwoPointV11.olean' for p in roots
                if (p/'WeilZeroTwoPointV11.olean').is_file()), None)
    if obj is None:
        raise RuntimeError('missing actual imported object')
    inputs = {str(p): sha(p) for p in
              [SOURCE, snapshot, Path(__file__).resolve(), CONTEXT, BIN/'lean', BIN/'leanchecker']}
    for suffix in ['.olean', '.olean.private', '.olean.server', '.ilean', '.ir']:
        p = obj.with_suffix(suffix)
        if p.is_file():
            inputs[str(p)] = sha(p)
    env = os.environ.copy()
    env['PATH'] = str(BIN)+':'+env.get('PATH', '')
    env['LEAN_PATH'] = ':'.join([str(out/'lib')]+[str(p) for p in roots])
    pre = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'inputs': inputs, 'resolved_direct_import': str(obj),
           'LEAN_PATH': env['LEAN_PATH'], 'full_dependency_rebuild': False,
           'rh_proven': False}
    (out/'PRESTART.json').write_text(json.dumps(pre, indent=2, sort_keys=True)+'\n')
    records = []

    def run(cmd, name):
        start = time.monotonic()
        result = subprocess.run(cmd, cwd=out/'source', env=env,
                                capture_output=True, timeout=120)
        (out/(name+'.stdout.txt')).write_bytes(result.stdout)
        (out/(name+'.stderr.txt')).write_bytes(result.stderr)
        records.append({'name': name, 'command': cmd, 'exit_code': result.returncode,
                        'elapsed_seconds': time.monotonic()-start,
                        'stdout_sha256': sha(out/(name+'.stdout.txt')),
                        'stderr_sha256': sha(out/(name+'.stderr.txt'))})
        if result.returncode:
            raise RuntimeError(name+' failed: '+result.stdout.decode()+result.stderr.decode())
        return result.stdout.decode()

    result = {'status': 'FAILED', 'rh_proven': False}
    fresh_obj = out/'lib'/SOURCE.with_suffix('.olean').name
    try:
        version = run([str(BIN/'lean'), '--version'], 'version')
        if '4.33.1' not in version:
            raise RuntimeError('unexpected Lean version')
        log = run([str(BIN/'lean'), '--trust=0', '-DautoImplicit=false', '-j1', '-M4096',
                   '--root='+str(out/'source'), '-o', str(fresh_obj), str(snapshot)], 'compile')
        if re.search(r'\b(?:error|warning):', log):
            raise RuntimeError('warning/error gate')
        reports = []
        for name in NAMES:
            full = 'AEGIS.WeilTowerButterflyOct7.'+name
            pat = re.escape("'"+full+"' depends on axioms: [")+r'([^\]]*)\]'
            match = re.search(pat, log)
            if match is None:
                raise RuntimeError('missing axiom audit '+full)
            axioms = [a.strip() for a in match.group(1).replace('\n', '').split(',') if a.strip()]
            if set(axioms) != EXPECTED:
                raise RuntimeError('unexpected axiom set '+repr(axioms))
            reports.append({'theorem': full, 'axioms': axioms})
        run([str(BIN/'leanchecker'), '-v', SOURCE.stem], 'leanchecker')
        changed = [p for p, h in inputs.items() if sha(p) != h]
        if changed:
            raise RuntimeError('input changed during replay '+repr(changed))
        result = {'status': 'PASS', 'axiom_reports': reports,
                  'inputs_unchanged': True, 'rh_proven': False}
    except Exception as exc:
        result = {'status': 'FAILED', 'reason': str(exc), 'rh_proven': False}
    receipt = {'schema': 'aegis.actual-butterfly.scoped-replay.v1',
               'prestart_sha256': sha(out/'PRESTART.json'), 'records': records,
               'source_sha256': sha(snapshot), 'result': result,
               'lean_version': '4.33.1',
               'lean_compiler': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6',
               'mathlib_commit': '0df444a360eaa60ab8c11dca51a86af692955474',
               'scope': 'Fresh actual two-point/rectangle identities, no sign/RH. '
                        'Explicit trust=0 and separate pinned LeanChecker; identified imported '
                        'objects reused. Not a clean full transitive build.',
               'full_dependency_rebuild': False, 'rh_proven': False}
    if fresh_obj.is_file():
        receipt['fresh_object_sha256'] = sha(fresh_obj)
    path = out/'RECEIPT.json'
    path.write_text(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'status': result['status'], 'receipt': str(path),
                      'sha256': sha(path), 'rh_proven': False}))
    if result['status'] != 'PASS':
        raise SystemExit(1)

if __name__ == '__main__':
    main()
