# Exact interval-extension source and application audit

7 October 2026. A real literature read and ordinary hypothesis check.
No new Lean theorem, kernel replay, global zeta identification, or RH claim.
All previously frozen `LocalMoment/` files remain unchanged.

## Checked source

Palle E. T. Jorgensen and Robert Niedzialomski, *Extension of positive definite
functions*, arXiv:1212.3047v3 (31 December 2013).

PDF: https://arxiv.org/pdf/1212.3047v3

SHA256: `1184604a8c330fd4fffc894b592458fdce636dcab10633c78acbc79f1112aede`

The complete PDF was downloaded, converted with `pdftotext -layout`, and the
relevant statements AND proof read. The actual PDF page 25 was also rendered
and inspected to resolve conjugation marks lost by text extraction. Those
source bytes and the rendered page are retained here.

### Actual local positive-definiteness definition, equation (1), p. 1

Let Omega be an open subset of R^n, and let F:Omega-Omega -> C. The source
calls F positive definite if for EVERY finite choice x_1,...,x_m in Omega
and EVERY complex coefficients c_1,...,c_m,

    sum_(j,k) F(x_j-x_k)c_j conj(c_k) >= 0.

It is the full positive-semidefinite Gram condition, not positivity of
entries, four individual phases, or all 2-by-2 minors. The conjugate on c_k
is visible in the PDF; text extraction may drop the overline.

### Exact existence theorem, Corollary 7.9, p. 25

Quoted statement:

> (n = 1) A continuous positive definite function F:Omega-Omega -> C,
> with Omega=(p,r) subset R, being a bounded and open interval, always
> has an extension to a continuous positive definite function defined
> on the entire real line R. Moreover, there is either precisely one,
> or at least a one-parameter family of distinct continuous positive
> definite extensions.

This theorem applies to COMPLEX Hermitian kernels. It does not require F
real, analytic, differentiable, strictly positive, globally bounded in
advance, moment determinate, or associated with a known positive spectrum.
It does require a single continuous local function and the full finite Gram
condition on a connected one-dimensional interval. The corresponding
higher-dimensional extension assertion is not imported.

### Author proof actually checked

The source constructs the Hilbert space H_F from the local positive kernel
and the smoothed vectors F_phi for phi in C_c^infinity(Omega). Its densely
defined derivative operator is S^F F_phi = -i F_(phi'). The source's Lemma
5.1 establishes well-definedness and symmetry by compact integration by
parts; no differentiation of a nonsmooth F is assumed.

For Omega=(p,r), interval reflection is k(t)=p+r-t. The proof's map is

    phi_k(t)=conj(phi(k(t))),     J F_phi=F_(phi_k).

The conjugation bar in phi_k is in the PDF but easy to miss in OCR. With
that bar, J is conjugate-linear, J^2=Id, and is isometric by Hermitianity
F(-z)=conj(F(z)) and reflected change of variables. The reflection's
minus derivative sign and complex conjugation's minus-i sign cancel, so
J S^F = S^F J. A densely defined symmetric operator commuting with a
conjugation has equal deficiency indices and thus a self-adjoint extension
by von Neumann's extension theorem. This is an existence argument; it
does not assert essential self-adjointness or uniqueness of the extension.
The source then invokes the sufficient direction of its Theorem 1.6 to
obtain the global continuous positive-definite extension from that
self-adjoint extension and its unitary group. This local translation
construction does not claim that its spectrum is the actual zeta zeros.

Only this one-dimensional existence assertion is used in the application.
No claim about a universal bijection between every extension and operators
on the original kernel Hilbert space is required here.

### Bochner, Theorem 3.3, p. 10

The source states that a continuous F:R^n -> C is positive definite if and
only if there is a POSITIVE FINITE Borel measure nu with

    F(t)=integral exp(i t.x) nu(dx).

This is the PLUS Fourier convention. In dimension one, nu(R)=F(0).
Zero mass is allowed; then the extension is identically zero. Finiteness
is sufficient for the new root theorem; no uncontrolled infinite measure,
regularized transform, or moment series is introduced.

## Exact match to the actual narrow-packet application

The root manuscript checked in this continuation is
`DenseTowerOct7/KREIN_ACTUAL_GERM_EXTENSION.md`.
Its actual fixed narrow packet has logarithmic half-width r=9/128, chosen
once from the already recovered construction; it is not substituted for
the opaque `AEGIS.RHFixedPacketFrontierV1.detectingPacket` in the main target.
The reused universal local source radius is r0=9/64, with delta=1/10.
Then a=2(r0-r)=9/64 is POSITIVE.

For arbitrary finitely many shifts t_j in an interval of length less than
a, their translated packets occupy one logarithmic interval with half-width

    r+(max_j t_j-min_j t_j)/2 < r0.

The legal moments survive every translated complex linear combination.
The reused full local coercivity gives, after exact Gram expansion,

    sum_(i,j)c_j conj(c_i)[K(t_j-t_i)-delta R_h(t_j-t_i)] >= 0.

Here H(x)=integral h(u)exp(ixu)du, and

    R_h(t)=integral exp(ixt)|H(x)|^2 dx/(2pi)
          =integral h(v)conj(h(v+t))dv.

For T_t h(u)=h(u-t), the actual cross L2 integral is precisely
R_h(t_j-t_i). It matches the actual kernel's Mellin translation exponent
exp((rho-1/2)t); both differences must use the same orientation.

To apply Corollary 7.9, choose **Omega=(0,a)**. Its difference set is
(-a,a). Choosing Omega=(-a,a) would incorrectly demand a function on
(-2a,2a), which the source would not supply. Points in (0,a) have total
range strictly less than a, so the proved Gram condition is exactly enough.
Conversely, any finite set of real shifts with all differences in (-a,a)
can be translated into (0,a), since its diameter is strictly less than a.
No support expansion outside the local source radius has been hidden.

The actual continuity and Hermitianity of
J(t)=K(t)-delta R_h(t) are independently known. Thus all hypotheses of the
one-dimensional extension theorem are verified, and a positive finite nu
whose PLUS Fourier transform agrees with J on (-a,a) is legitimate.

The residual value J(0)=Q-delta||h||_2^2 can equal zero. This is harmless;
nu can then be zero, while the later competing measures remain distinct.
No proof of strict residual positivity is required or inferred.

If T>2r+a, the explicit competing measures

    rho_± = nu + delta(1±cos(Tx)) mu_h

have mass Q and yield two global bounded positive-definite functions that
agree with the ACTUAL K for every |t|<a, because the correlation shifts
R_h(t±T) are outside the compact interval [-2r,2r]. At t=T their difference
is delta||h||_2^2. Only finite Fourier algebra and disjoint supports are
used; no moment finiteness of nu is needed.

The root's displayed rational choice T=27/64 satisfies T>2r+a=18/64.
There is a useful optional specialization: 2r+a=9/32, and the already known
log2 lower bound gives log2>9/32. Thus T=log2 also works, so the ambiguity
can be placed at one of the requested dense-group generators. This option
does not identify either extension with the actual global kernel.

## Provenance and limits

The original historical reference is identified exactly by [21] in the
checked source: M. Krein, *Sur le probleme du prolongement des fonctions
hermitiennes positives et continues*, C. R. (Doklady) Acad. Sci. URSS (N.S.)
26 (1940), 17--22. The 1940 original was NOT fetched/read here. The imported
existence result is supported by the modern authors' actual proof above,
not merely their history paragraph or abstract.

An additional monograph, Jorgensen--Pedersen--Tian,
*Extensions of Positive Definite Functions: Applications and Their Harmonic
Analysis*, arXiv:1507.02547v1, was also fetched during the targeted search.
It is retained as UNREVIEWED additional source material and is NOT used as
an input to this audit. Its text conversion emitted an xref-reconstruction
warning; the clean checked 1212.3047v3 proof is the authority actually used.
This warning does not affect the clean PDF, rendered p.25, or checked proof.

The new theorem supplies a genuine local-to-global EXISTENCE result plus
explicit nonuniqueness of global identification. It is compatible with RH
and with the possibility that the actual K is already one of the positive
extensions. It does not show the actual kernel unbounded, that neither
extension equals it, or that all zeta-specific recursive routes are impossible.
The full arithmetic identification outside the local interval remains a
separate mathematical obligation. No RH-equivalent premise was used to
construct these competing extensions.
