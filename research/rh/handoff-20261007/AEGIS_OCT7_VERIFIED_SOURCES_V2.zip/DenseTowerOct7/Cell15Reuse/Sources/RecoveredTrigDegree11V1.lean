/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinSincIntervalV1
import RHKreinFirstCellV1

/-!
# First-cell trigonometric interval kernel

This module instantiates the exact exponential Taylor kernel for every one of
the 199 hat-column cosine phases and for the common edge sine/cosine phase at
the first-cell center.  The indexed hat theorem replaces 199 independent
transcendental obligations by one proof plus exact finite arithmetic.

It does not assemble the signed coefficient sums and therefore does not yet
prove the complete `k = 0` Taylor-jet enclosure.

AUTHORITY_EFFECT = NONE.
-/

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFirstCellTrigV1

open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinFirstCellV1

def cosPolynomial11 (x : ℝ) : ℝ :=
  1 - x ^ 2 / 2 + x ^ 4 / 24 - x ^ 6 / 720 +
    x ^ 8 / 40320 - x ^ 10 / 3628800

def sinPolynomial11 (x : ℝ) : ℝ :=
  x - x ^ 3 / 6 + x ^ 5 / 120 - x ^ 7 / 5040 +
    x ^ 9 / 362880 - x ^ 11 / 39916800

private theorem expIPartial_twelve_re (x : ℝ) :
    (expIPartial 12 x).re = cosPolynomial11 x := by
  norm_num [expIPartial, cosPolynomial11, Finset.sum_range_succ,
    pow_succ, Complex.mul_re]
  ring

private theorem expIPartial_twelve_im (x : ℝ) :
    (expIPartial 12 x).im = sinPolynomial11 x := by
  norm_num [expIPartial, sinPolynomial11, Finset.sum_range_succ,
    pow_succ, Complex.mul_im]
  ring

/-- Uniform exact error budget for all 199 hat cosine phases at the first-cell
center.  Every phase is nonnegative and below `11/250 < 1`. -/
theorem firstCenter_hat_cos_error (j : Fin 199) :
    |Real.cos (firstCenter * hatCenter j) -
        cosPolynomial11 (firstCenter * hatCenter j)| ≤
      (1 / 1000000000000000000000000 : ℝ) := by
  let x : ℝ := firstCenter * hatCenter j
  have hjNat : j.val ≤ 198 := by omega
  have hj : (j.val : ℝ) ≤ 198 := by exact_mod_cast hjNat
  have hx0 : 0 ≤ x := by
    dsimp [x]
    unfold firstCenter hatCenter
    positivity
  have hxub : x ≤ (11 / 250 : ℝ) := by
    dsimp [x]
    unfold firstCenter hatCenter
    norm_num
    linarith
  have hx1 : |x| ≤ 1 := by
    rw [abs_of_nonneg hx0]
    exact hxub.trans (by norm_num)
  have h := cos_expIPartial_error 12 x (by norm_num) hx1
  rw [expIPartial_twelve_re] at h
  have habs : |x| ≤ (11 / 250 : ℝ) := by simpa [abs_of_nonneg hx0] using hxub
  have hp := pow_le_pow_left₀ (abs_nonneg x) habs 12
  refine h.trans ?_
  calc
    |x| ^ 12 * (((Nat.succ 12 : ℕ) : ℝ) *
        ((Nat.factorial 12 : ℕ) * 12 : ℝ)⁻¹) ≤
        (11 / 250 : ℝ) ^ 12 *
          (((Nat.succ 12 : ℕ) : ℝ) *
            ((Nat.factorial 12 : ℕ) * 12 : ℝ)⁻¹) := by
            exact mul_le_mul_of_nonneg_right hp (by positivity)
    _ ≤ (1 / 1000000000000000000000000 : ℝ) := by norm_num

private theorem edgePhase_eq :
    firstCenter * (1619 / 2000 : ℝ) = (24285 / 3276800 : ℝ) := by
  norm_num [firstCenter]

/-- Exact cosine enclosure for the common edge-column phase. -/
theorem firstCenter_edge_cos_error :
    |Real.cos (firstCenter * (1619 / 2000 : ℝ)) -
        cosPolynomial11 (firstCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 1000000000000000000000000000000000 : ℝ) := by
  rw [edgePhase_eq]
  have h := cos_expIPartial_error 12 (24285 / 3276800 : ℝ)
    (by norm_num) (by norm_num)
  rw [expIPartial_twelve_re] at h
  exact h.trans (by norm_num)

/-- Exact sine enclosure for the common edge-column phase. -/
theorem firstCenter_edge_sin_error :
    |Real.sin (firstCenter * (1619 / 2000 : ℝ)) -
        sinPolynomial11 (firstCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 1000000000000000000000000000000000 : ℝ) := by
  rw [edgePhase_eq]
  have h := sin_expIPartial_error 12 (24285 / 3276800 : ℝ)
    (by norm_num) (by norm_num)
  rw [expIPartial_twelve_im] at h
  exact h.trans (by norm_num)

end AEGIS.RHKreinFirstCellTrigV1

#print axioms AEGIS.RHKreinFirstCellTrigV1.firstCenter_hat_cos_error
#print axioms AEGIS.RHKreinFirstCellTrigV1.firstCenter_edge_cos_error
#print axioms AEGIS.RHKreinFirstCellTrigV1.firstCenter_edge_sin_error
