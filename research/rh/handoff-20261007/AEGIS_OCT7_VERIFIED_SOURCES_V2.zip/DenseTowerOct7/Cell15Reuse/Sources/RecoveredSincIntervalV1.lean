/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import AEGISOverlay.RHKreinFiniteIntervalKernelV1
import AEGISOverlay.RHKreinExplicitCorrectionV1

/-!
# Kernel-side sinc interval primitive

This module turns the existing exact Taylor enclosure for `sin x` into an
exact enclosure for `sinc x` at a positive rational phase.  It is the missing
reusable division step needed by the first-cell `k = 0` correction-symbol
certificate.  No numerical certificate and no RH claim is included.

AUTHORITY_EFFECT = NONE.
-/

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinSincIntervalV1

open AEGIS.RHKreinFiniteIntervalKernelV1

/-- Divide the sine Taylor error by a strictly positive phase to obtain a
rigorous sinc error.  For a fixed rational `x` and `n`, the right side is
entirely exact rational arithmetic. -/
theorem sinc_expIPartial_error (n : ℕ) (x : ℝ)
    (hn : 0 < n) (hx0 : 0 < x) (hx1 : |x| ≤ 1) :
    |Real.sinc x - (expIPartial n x).im / x| ≤
      (|x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹)) / x := by
  have hsin := sin_expIPartial_error n x hn hx1
  have hsin' :
      |Real.sin x - (expIPartial n x).im| ≤
        x ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹) := by
    simpa [abs_of_pos hx0] using hsin
  have hxne : x ≠ 0 := ne_of_gt hx0
  rw [Real.sinc_of_ne_zero hxne]
  rw [← sub_div, abs_div, abs_of_pos hx0]
  exact div_le_div_of_nonneg_right hsin' hx0.le

/-- Two-sided exact sinc interval at a positive rational phase. -/
theorem sinc_expIPartial_interval (n : ℕ) (x : ℝ)
    (hn : 0 < n) (hx0 : 0 < x) (hx1 : |x| ≤ 1) :
    (expIPartial n x).im / x -
          (|x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹)) / x ≤
        Real.sinc x ∧
      Real.sinc x ≤
        (expIPartial n x).im / x +
          (|x| ^ n * ((n.succ : ℝ) * (n.factorial * n : ℝ)⁻¹)) / x := by
  have h := sinc_expIPartial_error n x hn hx0 hx1
  rw [abs_sub_le_iff] at h
  exact ⟨by linarith [h.1], by linarith [h.2]⟩

/-- The degree-six even polynomial obtained by dividing the odd part of the
eight-term exponential Taylor polynomial by its phase. -/
def sincPolynomial7 (x : ℝ) : ℝ :=
  1 - x ^ 2 / 6 + x ^ 4 / 120 - x ^ 6 / 5040

/-- Exact error budget for the common hat sinc factor at the first-cell
center: `firstCenter / 100 = 3 / 32768`. -/
theorem firstCenter_hat_sinc_error :
    |Real.sinc (3 / 32768 : ℝ) - sincPolynomial7 (3 / 32768 : ℝ)| ≤
      (1 / 10000000000000000000000000000 : ℝ) := by
  have h := sinc_expIPartial_error 8 (3 / 32768 : ℝ)
    (by norm_num) (by norm_num) (by norm_num)
  have hp :
      (expIPartial 8 (3 / 32768 : ℝ)).im / (3 / 32768 : ℝ) =
        sincPolynomial7 (3 / 32768 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

/-- Exact error budget for the common edge sinc factor at the first-cell
center: `firstCenter / 2000 = 3 / 655360`. -/
theorem firstCenter_edge_sinc_error :
    |Real.sinc (3 / 655360 : ℝ) - sincPolynomial7 (3 / 655360 : ℝ)| ≤
      (1 / 1000000000000000000000000000000000000 : ℝ) := by
  have h := sinc_expIPartial_error 8 (3 / 655360 : ℝ)
    (by norm_num) (by norm_num) (by norm_num)
  have hp :
      (expIPartial 8 (3 / 655360 : ℝ)).im / (3 / 655360 : ℝ) =
        sincPolynomial7 (3 / 655360 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

end AEGIS.RHKreinSincIntervalV1

#print axioms AEGIS.RHKreinSincIntervalV1.sinc_expIPartial_error
#print axioms AEGIS.RHKreinSincIntervalV1.sinc_expIPartial_interval
#print axioms AEGIS.RHKreinSincIntervalV1.firstCenter_hat_sinc_error
#print axioms AEGIS.RHKreinSincIntervalV1.firstCenter_edge_sinc_error
