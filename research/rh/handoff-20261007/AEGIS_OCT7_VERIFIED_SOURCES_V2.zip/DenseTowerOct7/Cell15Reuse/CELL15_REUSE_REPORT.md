# Exact scope of this continuation

The user reports that `AEGIS_RI_2026-10-07_FIFTEENTH_K1_TAYLOR_REUSE_V1.zip`
contains an exact-Fraction enclosure of width `3.995e-14` and margin
`8.323e-13`, with a deterministic replay and dry-run diff. The user explicitly
does **not** report a Lean kernel PASS. Those facts remain user-reported here.
The ZIP's bytes, mathematical centre, exact coefficient endpoints, source
manifest and verifier receipt have not been supplied to this runner. Neither
`fifteenthCenter` nor `fifteenthCenter_k1_enclosure` was located in the inspected
public-head or recovered source scope. This is not a claim that those sources
do not exist in an external library or another branch.

The inspected public PR53 head is
`81bcd289cd6df73901fc97168b00a3b04376eac9`. Its
`AEGISOverlay/RHKreinFiniteIntervalKernelV1.lean` already proves arbitrary-order
public Taylor bounds. Its source bytes reproduce Git blob
`96558a2d0914a198cfa18d9749246590092a179b`. The actual public correction source
was fetched read-only at the same head; its bytes reproduce Git blob
`eaec6e0ebd43e5b528b2eea0bb05a1ffa93cd51c`. The source identities are recorded in
`SOURCE_RECOVERY.json` and copies are retained under `Sources/`.

Recovered first-cell trig sources contain degree-eleven polynomials and
private `expIPartial_twelve_re` / `expIPartial_twelve_im`, not the reported
private degree-fifteen primitives. Recovered sinc sources expose the generic
public `sinc_expIPartial_error` and degree-six `sincPolynomial7`. Rather than
renaming the unavailable private proofs, the new module makes minimum public
normal-form adapters to the already-proved arbitrary-order kernel. This is a
**new reconstruction**, not an assertion that the reported ZIP was recovered.

# Concrete proof result

`RHKreinTrig15Sinc6PublicOct7.lean` compiles from source with pinned Lean
4.33.1, `--trust=0`, and a separately executed pinned `leanchecker`. Seven
endpoints have elaborated types and actual `#print axioms` output. All have
only `propext`, `Classical.choice`, `Quot.sound`.

For all real `x`, the sixteen-term exponential polynomial has exactly the
cosine even normal form through degree fourteen and sine odd normal form
through degree fifteen. For nonzero `x`, its eight-term imaginary part divided
by `x` is exactly the existing degree-six `sincPolynomial7`.

For `|x| ≤ 1`, the rigorous real sine and cosine errors are each at most

```
|x|^16 * 17 / (16! * 16).
```

For `0 < x` and `|x| ≤ 1`, the rigorous sinc error is at most

```
|x|^8 * 9 / (8! * 8) / x.
```

These inequalities reuse the source proofs of `sin_expIPartial_error`,
`cos_expIPartial_error` and `sinc_expIPartial_error`; they introduce no new
analytic premise. The public indexed hat-sine endpoint is precisely

```
∀ (c : ℝ) (j : Fin 199),
  |c * hatCenter j| ≤ 1 →
  |sin(c * hatCenter j) - sinPolynomial15(c * hatCenter j)|
    ≤ |c * hatCenter j|^16 * 17 / (16! * 16).
```

Here `hatCenter j = ((j.val : ℝ) + 41)/50` is the actual PR53 phase. One generic
proof handles every indexed hat phase. The phase restriction remains explicit;
it has not been silently asserted for an unidentified fifteenth centre.

`PrintReusedDefinitionsOct7.lean` separately kernel-checks three literal
definition identities with `rfl` and prints the imported `hatCenter`,
`expIPartial`, and `sincPolynomial7`. This guards against replacing the actual
objects by similarly named local definitions.

First scoped compile/checker receipt:
`scoped-replay-20261007T054557.559296Z/RECEIPT.json`, SHA256
`009f5ee1d3445974b0b49aa9afe35ea2aaaf6239347ad63591d830bf72e5205d`.

Two separately invoked agent replays also passed in fresh output directories:
`scoped-replay-20261007T054804.722998Z/RECEIPT.json` (SHA256
`37c2c5e41303f89f24f5a1424bacbf447c0d47613bbf1664e4712e6e7f06bc79`)
and `scoped-replay-20261007T054953.393698Z/RECEIPT.json` (SHA256
`3ec01f76f92ac0ff49aa9f5f2ee18392e488d7b34e94e928c70339fcb50bed06`).
All three fresh target objects have identical SHA256
`60e025615f9f0a56e6d9ef4810c052ba9f9d171bec4eba9aa6bbf962edcf637f`.
The independent mathematical review in `IndependentReview/REVIEW.md` confirms
the factorial constants, actual polynomial degrees, division domains and
hat-phase quantifiers. Its 25 static source/evidence bindings passed. These
are separate agent executions on the same host using the same identified
import context, not independent clean rebuilds of the full dependency closure.

# Trust and replay limits

The target module is freshly compiled. Imported identified cached OLEANs are
reused through the literal `LEAN_PATH` in the receipt. The source closure was
not fully rebuilt. In particular, the identified inherited finite-kernel
object has SHA256
`8e2d65db2aba3e12a206d0f0eb1d4aa937d06604d8c33d29a4166df39dd246df`,
and the inherited correction object has SHA256
`b41f1cabe080abe0b0c7d17707936ed8d52c8efde971d5b4d09027f892cbc257`.
This is a scoped generic-adapter replay, not the requested fifteenth-cell
enclosure replay, a clean full transitive build, or an RH replay.

No existing frozen source was changed, no degree-fifty-three port was made,
and no remote change or hosted runner was requested.

# Exact next application

Supply or recover the actual reported ZIP snapshot (or a commit/blob/URL
containing its exact sources and receipt). Read the definition of
`fifteenthCenter`, the analytic `k=1` formula, exact interval endpoints and
remainder budgets. Reuse the public adapters above only after proving that
their normal forms, phase conditions and transformation conventions are the
same objects used by that snapshot. Then compile and audit the literal
`fifteenthCenter_k1_enclosure` from source in two fresh output directories.

The current problem is missing provenance/source for that application, not a
demonstrated missing mathematical derivation. The reported width and margin
have not been used as proof premises. `cell15_kernel_audit = NOT_RUN` and
`rh_proven = false`.
