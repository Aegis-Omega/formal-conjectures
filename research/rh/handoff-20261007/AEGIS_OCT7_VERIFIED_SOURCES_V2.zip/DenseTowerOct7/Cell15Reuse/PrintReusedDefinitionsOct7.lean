import RHKreinTrig15Sinc6PublicOct7

set_option autoImplicit false

-- Check the imported mathematical objects against their literal public or
-- recovered source definitions. This is a definition audit, not a cell claim.
example (j : Fin 199) :
    AEGIS.RHKreinExplicitCorrectionV1.hatCenter j =
      ((j.val : ℝ) + 41) / 50 := rfl

example (n : ℕ) (x : ℝ) :
    AEGIS.RHKreinFiniteIntervalKernelV1.expIPartial n x =
      ∑ m ∈ Finset.range n, (((x : ℂ) * Complex.I) ^ m) / m.factorial := rfl

example (x : ℝ) :
    AEGIS.RHKreinSincIntervalV1.sincPolynomial7 x =
      1 - x ^ 2 / 6 + x ^ 4 / 120 - x ^ 6 / 5040 := rfl

#print AEGIS.RHKreinExplicitCorrectionV1.hatCenter
#print AEGIS.RHKreinFiniteIntervalKernelV1.expIPartial
#print AEGIS.RHKreinSincIntervalV1.sincPolynomial7
