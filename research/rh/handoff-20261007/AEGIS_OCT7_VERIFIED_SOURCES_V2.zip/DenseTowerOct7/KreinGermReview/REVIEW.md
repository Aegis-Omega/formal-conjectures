# Independent review of the actual narrow-kernel germ extension

7 October 2026, reviewer task `/root/no_finite_recurrence_oct7`.
Result: PASS as ordinary mathematical composition of the stated recovered
source results and the checked one-dimensional interval extension theorem.
No new Lean declaration, new kernel replay, or RH closure is certified.
Exact final paper and source identities are bound in `REVIEW_RECEIPT.json`.
All earlier frozen NoFiniteRecurrence and LocalMoment files are unchanged.

## Exact complex Gram orientation

For the source normalized packet translation, the logarithmic lift is
`T_t h(u)=h(u-t)`. For finitely many locations and coefficients, its
energy is

    sum_(i,j) c_j conj(c_i)
      integral h(u-t_j) conj(h(u-t_i)) du.

Substituting v=u-t_j makes the cross integral
`integral h(v) conj(h(v+t_j-t_i)) dv=R_h(t_j-t_i)`.
With the PLUS Fourier transform this is exactly the characteristic
function of `|H|^2 dx/(2 pi)`. It is C(-t), not C(t), for the
other correlation convention in the arithmetic notes.

The actual zero coefficient after finite translation is independently
checked in the same orientation. The first Mellin factor gains
`sum_j c_j exp(lambda t_j)`; the reflected, conjugated second factor
gains `sum_i conj(c_i) exp(-lambda t_i)`. Their product and the full
zero sum therefore give

    Q_zero(f)=sum_(i,j)c_j conj(c_i)K(t_j-t_i).

Each finite-shift zero series has the inherited norm-summable
majorant, so the finite/countable interchange is valid. Hermitian
reflection makes this entire finite quadratic sum real. No factor
is silently replaced by a square modulus at a hypothetical off-line
zero, and no cross term is omitted.

## Full local positivity and the correct extension interval

At r=9/128 and r0=9/64, the residual interval parameter is
`a=2(r0-r)=9/64`. If all finite pair differences lie in (-a,a),
their span is less than a. The supports of all translated h lie in
one interval of length `2r+span<2r0`; hence the legal sum f has
half-width less than r0 about its actual midpoint. All moment
conditions are preserved by the exact normalized translation and
finite linear combination. The full recovered local coercivity
therefore applies to EVERY complex coefficient vector, not merely
two-point tests, four phases, or bounded-size minors.

It proves local positive definiteness of `J=K-(1/10)R_h` on (-a,a).
Continuity and Hermitianity are inherited from the two source kernels.
In the author's convention this is precisely the finite-point condition
on Omega=(0,a), since Omega-Omega=(-a,a). Selecting Omega=(-a,a)
instead would wrongly require twice as large a domain; that selection
is not made.

## Primary-author theorem and trust scope

I independently read the exact PDF and extracted text of P. E. T.
Jorgensen and R. Niedzialomski, *Extension of positive definite
functions*, arXiv:1212.3047v3, SHA256
`1184604a8c330fd4fffc894b592458fdce636dcab10633c78acbc79f1112aede`.
Rendered PDF pages 1 and 10 were created and inspected here; rendered
page 25 from the source recovery was also independently inspected.
This avoids OCR's omitted conjugation bars.

Definition (1), p.1, quantifies over arbitrary finite points in Omega
and ALL complex coefficients. Corollary 7.9, p.25, gives the needed
extension for a bounded open interval, with no analyticity,
determinacy, RH, spectral location, or further positivity hypothesis.
Its author proof uses reflection combined with complex conjugation,
the symmetric derivative operator, and a self-adjoint extension;
the sufficient extension construction and local unitary transport
are given in the preceding proof passages. In one dimension there
is no additional multi-operator strong-commutativity requirement.
This review does not import a claim identifying such an extension
operator with the actual full zeta spectrum, nor any classification
of all higher-dimensional extensions.

Theorem 3.3, p.10, is precisely Bochner's finite positive measure
statement, with PLUS Fourier convention `integral exp(i t x)dnu(x)`.
Its hypotheses hold for the continuous global positive-definite
extension of J. Thus its representing measure is finite and positive,
with mass `J(0)=Q-(1/10)||h||_2^2>=0`.
The original 1940 Krein paper is not claimed fetched or read here.
These are ordinary literature dependencies, not freshly ported Lean
theorems or substitutes for a final RH axiom audit.

## Global positive measures match the ACTUAL germ and differ at log2

The compact-smooth correlation vanishes outside [-2r,2r]. The
strict elementary integral inequality `log2>1/2>9/32=2r+a`
proves that T=log2 is admissible without floating constants.
The two densities `1+cos(Tx)` and `1-cos(Tx)` are nonnegative.
Adding either times delta to the SAME positive measure nu gives
positive finite rho_+ and rho_-. Their equal mass is exactly Q:
the cosine integral is zero because R_h(T)=0.

The finite cosine expansion gives exactly

    F_±(t)=J_ext(t)+delta R_h(t)
             ±(delta/2)(R_h(t+T)+R_h(t-T)).

For |t|<a both shifted correlations vanish, and J_ext=J, so
both functions equal the ACTUAL K on the entire open interval.
At t=T their difference is `delta R_h(0)=delta||h||_2^2>0`.
Consequently two globally bounded positive-definite extensions
of the same actual germ already disagree at the first requested
dyadic generator. At least one therefore does not equal actual K
at that generator. The proof correctly does not conclude that
neither equals K globally, that K is unbounded, or that RH fails.

All Fourier integrals in this construction concern finite measures,
and the cosine expansion is finite. No moment finiteness of nu
is needed. Derivatives of the two functions on the shared interval
exist and agree with K because the functions coincide there, not
because of an unproved differentiation under a nu moment integral.
The separately proved nonanalyticity of this same narrow K at zero
is consistent with these facts and concerns t, not the complex
Laplace/resolvent parameter w.

## Actual-object and quantifier audit

The SAME narrow actual detector selected at r=9/128 is used
throughout. Its existence and full local coercivity are the
already recovered ordinary and formal source results with their
recorded replay/port scopes. No width is attributed to the opaque
Classical.choose detector in DenseFixedPacketSign.

The theorem constructs two global positive kernels and proves
their exact coincidence with actual K only on |t|<a. It does NOT
identify either one with the actual prime/Gamma/zero expression
on the whole dense group. The construction uses the SAME seed with its two Mellin moment
conditions; it does not assert that either extension is the zero kernel
of another packet. Their different values at log2 demonstrate that
those seed inputs and the full local germ do not provide the desired
global identity. Consequently no RH-equivalent premise is hidden
above the construction and no unconditional RH conclusion is
claimed below it.
