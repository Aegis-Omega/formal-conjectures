# Dense fixed-packet continuation — 7 October 2026

This continuation is unfinished RH research. It does not prove RH or a new
RH equivalence. The original CHECKPOINT.md, all earlier source packages and
their proof scopes remain unchanged. Work is isolated on local branch
`research/rh-dense-tower-20261007`, based on
`c721361f7c5ac2b9d1a05abece40c87315a4a81b`. There were no remote writes,
hosted dispatches, merges, deployments or account changes.

## Exact requested target and source reuse

The linked upstream issue 693 is **Dashboard for (negative) results?**. Its
actual body requests reports of failed/partial automated-prover attempts and
their resources. It contains no RH theorem and is distinct from AEGIS PR693.
A concrete local contribution is ready in Dashboard/; it has not been posted.

The user's mathematical description agrees with the actual carrying source:

```
AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign :=
  forall d : Real, d in SnowflakeShiftGroup ->
    forall c : Complex, WeilFourPhaseV1 c ->
      Re(WeilExplicitRightSideV1
        (WeilAutocorrelationV1
          (WeilTwoPointTranslateV11 detectingPacket d c))) <= 0.
```

The SAME packet is `AEGIS.RHFixedPacketFrontierV1.detectingPacket`; the group
is Z log2 + Z log3 with BOTH signed integer coefficients, not the positive
semigroup. Phases are exactly 1,-1,i,-i. With the original normalization
T_dg(x)=exp(-d/2)g(exp(-d)x), Q=Re Q_zero(g) and the actual canonical kernel K,
the four zero-side values are

    2Q+2ReK(d), 2Q-2ReK(d), 2Q-2ImK(d), 2Q+2ImK(d).

The already proved full explicit formula changes RHS<=0 into these values>=0.
The existing density/continuity, sign-to-universal and sign-to-actual-RH
arrows are reused without re-proving them. Their sign input stays explicit.
K(-d)=conj K(d) does not assert K(d) is real for this opaque chosen detector.

Current fork42/52 carrying sources match the old kernel-audited bytes. The
source auditor also read all six newer679 additions, with exact current heads,
and found only scoped sign producers or explicit global-sign consumers in
that inspected set. Unsearched branches and unprovided snapshots remain
UNKNOWN; no global absence claim is made. See SourceAudit/SOURCE_AUDIT.md.

The genuine existing dyadic tower controls ALL complex mixed coefficients,
with seed width 2^-max(10,N+2). The existing prime3 mixed estimate similarly
retains a k-dependent width. Neither proof permits replacing that order of
quantifiers by a single fixed seed valid for all N. Both results are retained.

## New actual kernel identities, formalized and independently replayed

For the ACTUAL zero kernel and every compact smooth g, all real a,b and complex c,
no moment, positivity or RH hypothesis is needed for the identity

    K_(g+c T_a g)(b)
      =(1+c conj(c)) K_g(b)+c K_g(a+b)+conj(c) K_g(b-a).

Its countable-sum transport is justified by the existing absolute summability
at EACH of the three required shifts. Uniform-in-b summability is not assumed.
The plus/minus channels give respectively

    K_(g+T_a g)(b)+K_(g-T_a g)(b)=4K_g(b),
    K_(g+T_a g)(b)-K_(g-T_a g)(b)=2[K_g(a+b)+K_g(b-a)],
    K_(g+iT_a g)(b)-K_(g-iT_a g)(b)=2i[K_g(a+b)-K_g(b-a)].

The exact four-corner quadratic assembly retains every horizontal, vertical
and BOTH diagonal mixed terms. All six declarations are in
Formal/WeilTowerButterflyOct7.lean. They passed fresh scoped Lean4.33.1
`--trust=0`, the separately executed pinned leanchecker, and full type/axiom
audits. Root and an actual separate agent executed different fresh output
directories and obtained the same source/object hashes. Only
propext, Classical.choice, Quot.sound occur. Identified imported objects were
reused; this is not a full clean transitive dependency build or an RH replay.

These identities expose the exact gap in using two channels: a sign premise
about the SAME seed g does not supply sign premises for the newly created
packet g+c T_a g. Adding two output energies cancels cross terms but does not
prove either output is nonnegative.

## Four mathematically distinct attempted transports and their outcomes

### Finite autonomous linear tower

No nontrivial finite constant-coefficient real-shift recurrence can hold for
the SAME actual detector kernel, even on a half-line. Finite stencils on the
whole requested log2/log3 group are included. This is a complete ordinary
argument, not a new Lean theorem:

* The finite shift symbol F(z)=sum b_j exp(d_j z) is bounded on the actual
  exponent strip. The shifted coefficients remain absolutely summable.
* The genuine meromorphic Laplace/resolvent identity forces
  a_rho F(rho-1/2)=0 at every actual zero. Detection supplies a_rho!=0.
* Jensen bounds a nonzero finite exponential polynomial's zero count by O(T).
  Conrey's explicitly checked unconditional SIMPLE critical-line-zero theorem
  supplies Omega(T log T) distinct actual modes, giving a contradiction.

A lower-literature two-pure-channel proof uses irrational log2/log3 and only
infinitely many actual zeros. This exclusion applies to exact finite linear
constant updates only. Nonlinear, variable, inhomogeneous arithmetic,
infinite-dimensional and inequality-based recursions remain outside it.
See NoFiniteRecurrence/NO_FINITE_SHIFT_RECURRENCE.md and independent reviews.

### Plus/minus or first-middle-last propagation from pair tests

A complete six-mode reflection/conjugation-symmetric MODEL uses a fixed legal
compact smooth real packet with both moments and

    K(t)=cos(t/6)[1+cosh(t/4)/144], Q=145/144.

All four-phase pair tests hold on the ENTIRE interval [-2,2], including log2
and log3. Nevertheless h=log2 gives the SAME packet's legal three-point tower

    u=g-2cos(h/6)T_h g+T_(2h)g

with full reflected quadratic

    q(u)=4(1/144)sinh²(h/4)cos²(h/6)
            [tanh²(h/8)-tan²(h/6)] < -1/250000.

Every pair difference is in that certified interval and on the requested
group. The negative margin is an exact rational/trigonometric proof, not a
floating eigenvalue; all mixed terms are paid. A separate exact rational
large-shift checker and a different independent Taylor recomputation are
also recorded. This is NOT an actual zeta/Euler/Gamma counterexample and does
not affect the existing ALL-shift criterion or the actual narrow dyadic
arithmetic theorem. It falsifies the proposed generic pair-sign propagation.

### Local derivative positivity and moment/operator reconstruction

A new precise ordinary theorem was proved: for nonzero compact smooth h and
the energy moment functional J from |H|² dx/(2pi), if a Hermitian polynomial
functional L satisfies L(pp*)>=delta J(pp*) for ALL polynomials with one
delta>0, its moment problem is indeterminate. For T beyond support diameter,

    rho_+ = nu+delta(1+cos(Tx))mu_h,
    rho_- = nu+delta(1-cos(Tx))mu_h

are distinct positive measures representing EVERY same moment. Existence of
nu follows from the checked Hamburger theorem for the positive residual
L-delta J. The Fourier autocorrelation's compact support proves that the
cosine perturbation has all moments zero. The two characteristic kernels
agree on a whole neighborhood of zero, but differ at T by delta||h||².

The theorem applies to the existing independently constructed narrow ACTUAL
zeta detector and its actual polynomial Weil functional using the recovered
9/64 coercivity delta=1/10, full explicit formula and exact energy isometry.
That narrow detector is NOT silently identified with the opaque named packet
in DenseFixedPacketSign. The argument proves actual narrow moment
indeterminacy and failure of Carleman's sufficient condition; it does not
claim a new Lean port or that positive representing measures are the actual
zero kernel. An independent global arithmetic identity would still have to
select that specific kernel. See LocalMoment/ and its real independent reviews.

The same constructed narrow kernel is NOT real analytic at zero: analyticity
would bound its even derivatives by M(2n)!r^-2n, forcing a divergent Carleman
sum, contrary to the newly proved finite sum. This corollary has its own
independent ordinary review. The resolvent is analytic in its Laplace
parameter; that is not analyticity of the time kernel.

### A concrete Krein global positive representation and its falsification

The construction part of a stronger route was actually closed. Choose the
existing narrow detector once with half-width r=9/128. Full local coercivity
proves ALL finite Gram matrices of J(t)=K(t)-(1/10)R_h(t) positive whenever
their shift diameter is less than a=9/64. This retains every mixed term.
The exact checked complex interval-extension theorem, Jorgensen--Niedzialomski
1212.3047v3 Cor7.9, applies with Omega=(0,a), not (-a,a). Bochner supplies a
finite positive measure nu for a global extension of this actual residual
germ. With T=log2>2r+a, the concrete positive measures

    rho_+ = nu+(1/10)(1+cos(Tx))mu_h,
    rho_- = nu+(1/10)(1-cos(Tx))mu_h

produce two global bounded positive kernels F_+,F_- of mass Q, matching
the ENTIRE actual K on |t|<a and differing already at the requested
generator log2 by ||h||²/10. This is an actual ordinary construction, not
a numerical approximation or a new certificate assumption.

The proposed global identification was then ATTACKED, not left unchecked:
NEITHER constructed kernel equals actual K globally. If one did, the existing
any-detector bound-to-RH theorem would deduce RH inside that contradiction;
actual K would then be the Fourier transform of a finite pure-point zero
measure. But each constructed rho contains a nonzero positive absolutely
continuous component, which positive nu cannot cancel. Finite-measure Fourier
uniqueness gives a contradiction and discharges the supposed identification.
No RH premise remains in the negative result.

The same argument proves a precise stronger two-energy limitation: no ONE
delta>0 gives Q(sum c_jT_(t_j)g)>=delta*energy(sum c_jT_(t_j)g) for ALL finite
complex combinations of this same actual detector, even if every t_j lies
on the exact dense log2/log3 group. Such a global floor would force RH and
positivity of the signed measure mu_Z-delta mu_h, impossible on the complement
of the countable actual zero heights. Floors depending on window/size and
tending to zero are preserved as possible; global SEMIDEFINITE positivity
is the RH task and was not falsified.

Full ordinary proofs and real independent reviews:
KREIN_ACTUAL_GERM_EXTENSION.md, KREIN_EXTENSION_IDENTITY_FALSIFIER.md,
KreinGermSource/ and KreinGermReview/. The first extension-construction review
is retained under its original byte hash; the subsequent falsification is
a separately bound stronger finding. No complete formal port is claimed.

## Concrete dashboard contribution

Dashboard/UPSTREAM_CONTRIBUTION_DRAFT.md reports six existing scoped outcomes,
including actual failed exact-RH composition, full identity replay, recovered
width21/20 positivity, actual-zeta countertest, unpaid global arithmetic bound
and local CI repairs. The machine-readable draft distinguishes proof,
application, replay and availability. The checker and independent reviewer
checked30 literal evidence bindings and26 Git commit/blob roundtrips.
Unknown models/FLOPS/kWh/peak RAM remain null; no resource totals are invented.
One initially mixed local-result/public-diagnostic source tuple was corrected,
its initial snapshot retained, and the corrected bytes rechecked.
This draft is LOCAL and has not been posted to upstream issue693.

## Pins and one exact remaining obligation

Lean4.33.1 compiler819816b2e0a3bf405af45ae5c7af2491d8f5bee6;
Mathlib0df444a360eaa60ab8c11dca51a86af692955474;
target FormalConjectures02da1ad1288b4881ea1f8e575fbe84af7db04364.
No pins were upgraded. The external sorry proof body remains excluded.

The SINGLE selected mathematical obligation is still

    AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign

with the original same packet, all signed integer log2/log3 shifts, four
phases, full primes/prime powers/Gamma/poles/zero multiplicities and unchanged
test carrier. The four new transport attempts above do not discharge it.
They specify which recursive and reconstruction shortcuts fail, and preserve
the genuine routes outside those falsifiers.

Next executable mathematical work is a SEMIDEFINITE signed arithmetic inequality
for this SAME packet which retains both rectangle diagonals in the new exact
butterfly identity. The inequality must control arbitrary signed mixed shifts;
finite interval pair tests, conservation alone, or selecting a positive
moment measure cannot supply it. The already falsified uniform strict energy
floor and the forced-continuous Krein completion must not be used as premises.
No replacement inequality is assumed here.

There is no own final RH term, no full final clean build or final RH axiom
audit, and no final independent RH replay. RH_PROVEN and
RH_EXACT_TARGET_PROVED remain false. This is a saved unfinished continuation,
not a proof of mathematical impossibility or exhaustion of all sources/routes.

## Latest steering: v33 rational k=1 report and library access

The user reports `AEGIS_PR53_first_cell_reduction.zip` v33 enclosing a k=1
formula strictly between 347860160497147/10^15 and
347860160497149/10^15, with exact-rational decisions, 349/349 source hashes,
ZIP/replay PASS, and Lean kernel/axiom audit NOT_RUN. These are USER-REPORTED
facts. The actual v33 ZIP and its 349-entry manifest/receipt were not read.
The reported interval has rational half-width 10^-15, narrower than 10^-12;
that arithmetic comparison alone does not identify or certify the coefficient.

K1V33/ records targeted local recovery and the current fork PR53 source
sampling. The existing actual zero-centre coefficient theorem was reused:
`AEGIS.RHKreinFirstCellV1.firstJet_one_exact`, with firstCenter=0 and
firstJet1=0. A source-bound compatibility adapter passed TWO actual fresh
trust=0 compiles and separate pinned leanchecker runs; a separate agent
executed the second replay and checked full types/standard-three axioms.
The preserved older midpoint source instead uses firstCenter=75/8192.
Neither object is silently identified with the unidentified v33 formula.
The centre-zero guard supplies no new RH positivity and does not refute v33.
Selected identified imported objects and recorded import search paths were
reused; the full transitive closure was not rebuilt or exhaustively rebound.

After the user said the packet was in the library, actual available
ChatGPT Space tools were called: two named searches, the accessible-page
listing through its final cursor, and a read of the one returned tutorial
page. No v33 file reference appeared. This Page API is not an exhaustive
personal-file Library index; its reference reader explicitly does not support
arbitrary ZIP archives. V33_LIBRARY_ACCESS_SCOPE.json records this exact
scope. No claim that the ZIP does not exist elsewhere is made.

Minimal input needed for the requested v33 Taylor/Lagrange port is the actual
ZIP bytes or source URL/commit with the coefficient formula/object definitions,
exact rational certificate, verifier, 349-entry manifest and replay receipt.
Its mathematical status remains UNKNOWN and its own kernel audit NOT_RUN.
The earlier scoped centre-zero proof remains proved under its exact identity.
This access task is separate from the SINGLE selected full DenseFixedPacketSign
mathematical obligation; finite-cell recovery is not a new global producer.

On the user's equation-direction question: F(x)=0 and 0=F(x) have identical
solutions by symmetry of equality. Rewriting a formula can reveal structure,
but merely swapping its two sides creates no new implication or sign bound.
