#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,subprocess,os,time,datetime,re
D=Path(__file__).resolve().parent;W=Path('/workspace/aegis-research/work')
R=W/'DenseTowerOct7/Cell15Concrete/OriginalTargetIntegration/CompatibilityFallbackReview/scoped-review-20261007T062824.614585Z/RECEIPT.json'
B=Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin');S=D/'RHKreinExistingK4ReuseOct7.lean'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads(R.read_text());bindings=dict(base['input_bindings']);bindings.update({str(R):sha(R),str(S):sha(S),str(Path(__file__).resolve()):sha(__file__),str(B/'lean'):sha(B/'lean'),str(B/'leanchecker'):sha(B/'leanchecker')})
for p,h in bindings.items():
 if not Path(p).is_file() or sha(p)!=h:raise ValueError('changed known existing source/object '+p)
if base['status']!='PASS':raise ValueError('actual prior typed reuse review failed')
O=D/('scoped-replay-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'));(O/'source').mkdir(parents=True);(O/'lib').mkdir()
s=O/'source'/S.name;s.write_bytes(S.read_bytes());bindings[str(s)]=sha(s)
env=dict(os.environ);env['PATH']=str(B)+':'+env.get('PATH','');env['LEAN_PATH']=str(O/'lib')+':'+base['LEAN_PATH'];jobs=[];status='FAIL';reason=None;axioms=[]
def run(cmd,n,cap=90):
 start=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True,timeout=cap)
 out=O/(n+'.stdout.txt');err=O/(n+'.stderr.txt');out.write_bytes(p.stdout);err.write_bytes(p.stderr)
 jobs.append({'name':n,'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(out),'stderr_sha256':sha(err)})
 if p.returncode:raise ValueError('actual execution failed '+n+': '+p.stdout.decode()[-3000:]+p.stderr.decode()[-1000:])
 return p.stdout.decode()
try:
 v=run([str(B/'lean'),'--version'],'version')
 if '4.33.1' not in v or '819816b2e0a3bf405af45ae5c7af2491d8f5bee6' not in v:raise ValueError('compiler pin changed')
 deps=run([str(B/'lean'),'--deps',str(s)],'dependencies')
 for p in deps.splitlines():
  q=Path(p.strip())
  if not q.is_file():raise ValueError('missing exact existing import '+p)
  bindings[str(q.resolve())]=sha(q)
 obj=O/'lib'/'RHKreinExistingK4ReuseOct7.olean'
 log=run([str(B/'lean'),'--trust=0','-DautoImplicit=false','-j1','-M4096','--root='+str(O/'source'),'-o',str(obj),str(s)],'compile')
 if 'sorryAx' in log:raise ValueError('unexpected placeholder')
 for name,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",log,re.S):
  values=[x.strip() for x in a.split(',') if x.strip()]
  if set(values)!={'propext','Classical.choice','Quot.sound'}:raise ValueError('unexpected axiom '+name)
  axioms.append({'theorem':name,'axioms':values})
 if {x['theorem'] for x in axioms}!={'AEGIS.RHKreinExistingK4ReuseOct7.existing_zero_center_k4','AEGIS.RHKreinExistingK4ReuseOct7.existing_zero_center_k6'} or len(axioms)!=2:raise ValueError('missing/duplicate axiom endpoint')
 run([str(B/'leanchecker'),'-v','RHKreinExistingK4ReuseOct7'],'leanchecker')
 if any(not Path(p).is_file() or sha(p)!=h for p,h in bindings.items()):raise ValueError('identified proof/source changed during run')
 status='PASS'
except Exception as ex:reason=str(ex)
r={'schema':'aegis.existing-k4-k6.concrete-typed-reuse.v1','status':status,'reason':reason,'axiom_reports':axioms,'input_bindings':bindings,'jobs':jobs,'LEAN_PATH':env['LEAN_PATH'],'source_sha256':sha(s),'lean_version':'4.33.1','lean_compiler_commit':'819816b2e0a3bf405af45ae5c7af2491d8f5bee6','mathlib_commit':'0df444a360eaa60ab8c11dca51a86af692955474','source_objects_reused':True,'full_transitive_source_rebuild':False,'cell15_k4_proved':False,'rh_proven':False,'scope':'Two literal transparent aliases of already-proved zero-centre k4/k6, fresh trust0 type/application/axiom audit and pinned checker. No closed arithmetic body was rederived. No change of centre to Cell15.'}
if obj.is_file():r['object_sha256']=sha(obj)
p=O/'RECEIPT.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':status,'reason':reason,'receipt':str(p),'sha256':sha(p)}));raise SystemExit(0 if status=='PASS' else 1)
