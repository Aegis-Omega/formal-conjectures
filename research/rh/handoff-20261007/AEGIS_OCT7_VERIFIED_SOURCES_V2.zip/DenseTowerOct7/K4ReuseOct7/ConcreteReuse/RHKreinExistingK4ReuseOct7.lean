import RHKreinZeroJetInterpolationV1

set_option autoImplicit false
noncomputable section
namespace AEGIS.RHKreinExistingK4ReuseOct7

/-- Transparent application of the existing proved zero-centre k=4 endpoint. -/
theorem existing_zero_center_k4 :
    |AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient 0 4 -
      (2096414380799 / 1000000000000 : ℝ)| ≤
        (1 / 1000000000000 : ℝ) := by
  simpa only [AEGIS.RHKreinFirstCellV1.firstCenter,
    AEGIS.RHKreinZeroJetInterpolationV1.target4]
    using AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_four

/-- The existing k=6 result remains closed under its exact zero-centre scope. -/
theorem existing_zero_center_k6 :
    |AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient 0 6 -
      (-190744442117 / 1000000000000 : ℝ)| ≤
        (1 / 1000000000000 : ℝ) := by
  simpa only [AEGIS.RHKreinFirstCellV1.firstCenter,
    AEGIS.RHKreinZeroJetInterpolationV1.target6]
    using AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_six

end AEGIS.RHKreinExistingK4ReuseOct7
#print AEGIS.RHKreinFirstCellV1.firstCenter
#check @AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_four
#check @AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_six
#check @AEGIS.RHKreinExistingK4ReuseOct7.existing_zero_center_k4
#check @AEGIS.RHKreinExistingK4ReuseOct7.existing_zero_center_k6
#print axioms AEGIS.RHKreinExistingK4ReuseOct7.existing_zero_center_k4
#print axioms AEGIS.RHKreinExistingK4ReuseOct7.existing_zero_center_k6
