# Existing k=4 proof reuse, frozen bounded audit

The existing zero-centre k=4 result has been reused directly. A new literal adapter, compiled with pinned Lean `--trust=0` and checked with the pinned `leanchecker`, states

```
|AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient 0 4
  - (2096414380799 / 1000000000000 : ℝ)| ≤ 1 / 1000000000000.
```

Its proof is only `simpa` from `AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_four`. The matching existing order-six enclosure is reused similarly. Both axiom lists contain exactly `propext`, `Classical.choice`, `Quot.sound`. The raw full types, zero-centre definition and axiom outputs are in `ConcreteReuse/scoped-replay-20261007T063818.465049Z/compile.stdout.txt`; the actual compile/checker receipt is beside that file. No closed fourth-derivative arithmetic was derived again. This is fresh scoped reuse of identified existing import objects, not a full transitive source rebuild.

## Existing applications recovered and actually compiled

`OriginalTargetIntegration/EffectiveSources/RHKreinSecondCellCompositionV1.lean` applies the existing `actual_even_jet_four` directly in the k=4 branch of `existing_zero_jet_enclosures`. The exact existing k=2 and k=6 terms are also reused. Its actual fresh source compilation exited zero and printed the three standard axiom lists. Effective Third, Fourth and Fifth cell compositions also freshly compiled and printed standard axiom lists. Their exact effective sources, objects, commands and raw logs are bound in `EXISTING_APPLICATION_REPLAY_RECORDS.json`.

The original two enclosing runner receipts remain `FAILED`: the first later encountered a missing API in the Third source, and the second later encountered the Euler-gamma sharp module's memory cap. Successful individual compilation records are preserved without converting either enclosing failed receipt to a successful full run. This audit did not run an additional independent checker on those four modules; the concrete zero-centre adapter above did receive its own fresh checker.

The 155-source restored library contains a complete direct zero-centre derivative proof in `RHKreinFirstCellV1.firstJet_four_enclosure`, using sinc-power/product derivative formulas and exact hat/spline moments. That recovered direct body is distinct from the existing interpolation proof just reused. The large restored FirstCell module's attempted fresh compilation hit its resource cap; this audit does not claim that replay succeeded, nor does it invalidate the already checked interpolation term.

The restored `RHKreinFourteenthCellCompositionV1.first_fourteen_cells_sound` has a complete premise-free written Lean body composing actual cells 1–14. Its source is recovered and read. A fresh kernel replay of that full chain was not established here. The module name `FourthCellComposition` refers to the fourth serialized cell, not derivative order four.

## Full-type applicability map

| Result/object | Exact scope and assumptions | Reuse decision |
|---|---|---|
| `actual_even_jet_four` | Actual correction symbol, normalized fourth coefficient, centre `0`, target `2096414380799/10^12`, radius `10^-12`, no mathematical premises | Reused by fresh literal adapter and the actual effective Second-cell producer. |
| Direct `firstJet_four_enclosure` in restored FirstCell | Same actual zero-centre target; complete direct proof body, premise-free | Preserved as written proof recovery. Fresh replay of this body remains separate from the checked interpolation endpoint. |
| Old midpoint FirstCell source in `PR53CellIntegration` | Centre `75/8192`, target `2096174510847/10^12`; `firstCell_sound_of_jet_enclosures` retains all eight actual coefficient bounds | A different, earlier reduction. Its data or theorem name cannot substitute for the zero-centre or Cell15 coefficient. |
| `fifteenthCell_sound_of_midpoint_jets` | Centre `5025/65536`, `hjet : ∀ k ∈ range 8, |exactJetCoefficient fifteenthCenter k-fifteenthJet k| ≤ fifteenthJetError k` | A consumer of k=4 among the eight exact inputs. It does not produce its input. |
| `fifteenthCell_sound_of_midpoint_jets_except_zero` | Inserts proved k=0, retains the enclosure family on `Ico 1 8` | Valuable existing composition; k=4 remains explicit. |
| `fifteenthCenter_exactJetCoefficient_one` and its enclosure adapter | Fixed derivative order one at actual midpoint, with numerical premise retained by the adapter | Reusable analytic mechanism, not an order-four conclusion. The separately closed current k=1 continuation is not rederived here. |
| `EvenJetInterpolation.extractFour_evenPolynomial` | Arbitrary real coefficients, isolates `q4*h^4` from three even-polynomial node values | General reusable algebra. A shifted application needs a shifted coupling, actual node/baseline bounds and the exact scaled error budget. |
| `extractFour_error`, `coefficient_error_of_scaled` | Explicit node errors with weights `13/24`, `1/6`, `1/72`; positive scale, scaled error and target deviation | Transfer lemmas retain their proved-input requirements. Zero-centre parity coupling is not an arbitrary-centre producer. |
| `Real.iteratedDeriv_fourier` | All orders `n`; `N : ℕ∞`, integrable ordinary moments for all `k≤N`, `n≤N`; conclusion `iteratedDeriv n (𝓕 f)=𝓕(fun x =>(-2π I x)^n • f x)` | Already supplies the order-four identity. Read at pinned Mathlib source lines 805–824, including its proof. No new derivative theorem is needed; actual moment inputs must be supplied. |
| `hasMomentsUpToEight_of_continuous_compact` | Continuous compactly supported `f : ℝ→ℂ`; conclusion all ordinary moments through order eight are integrable | Existing unconditional producer of the Fourier derivative's analytic hypotheses, including order four. A point-value numerical enclosure is a separate task. |
| `correction_taylor7_remainder`, `centeredTaylor_eq_exactJet` | Actual correction, every supplied centre/argument; function-value Taylor remainder and coefficient identity | Unconditional analytic tools. They do not give the coefficients' numerical values at a new centre. |
| `cellAnalyticSound_of_symmetric_jet_box` | Retains hjet, symbol bounds, geometry, weight and ground-budget inputs | Existing generic cell assembler; not a missing transcendental coefficient producer. |
| `actual_packet_fourier_factor` | Actual legal packet, log-lift support in `[a,b]`, `a≤b`, moment conditions; smooth compact factor with multiplier `(t²+1/4)²` | Existing unconditional factorization. Its degree-four polynomial is not a fourth-derivative enclosure or global Weil sign. |

`exactJetCoefficient c k` is `(k.factorial : ℝ)⁻¹ * iteratedDeriv k correctionSymbol c`. Thus k=4 includes division by 24 throughout this map. The actual correction symbol, Fourier normalization and support class were not changed.

## Bounded discovery scope and remaining shifted question

The independent child source review read all 155 restored files as bytes and verified their indexed Git blobs: 173/173 checks passed. It read the relevant producer and consumer bodies. The parent workspace discovery found 56 matching source paths, deduplicated to 22 contents, plus 131 selected Lean members across five actual local archives. Exact scopes and archive hashes are recorded in `SOURCE_SEARCH_SCOPE.json`, and the independent written review is `LibraryAudit/REVIEW.md` with its separate receipt. Original remote attachment paths are absent in this runtime; transfer metadata is not an original ZIP replay.

The optional Cell15 target

```
|exactJetCoefficient (5025/65536) 4
  - (51983766003/25000000000 : ℝ)| ≤ 1/1000000000000
```

was not located as a produced conclusion in these inspected sources. It remains `NOT_LOCATED_IN_SEARCHED_SCOPE`; no mathematical nonexistence or project-wide absence is asserted. This is not assumed to be what every user reference to “k=4 modules” meant. The zero-centre existing producer is positively identified, reused and scoped-kernel checked.

The zero-centre and Cell15 numeric target centres differ by `17063740679/10^12`, far beyond their enclosure radii. This prevents accidental substitution of a different centre; it does not refute either correctly stated result. If the Cell15 route is selected, the exact literal midpoint coefficient above is the local application question. It is not a replacement for the root task's global RH frontier.

RH and all-cell soundness are not conclusions of this bounded reuse audit. No remote state or frozen predecessor sources were changed.
