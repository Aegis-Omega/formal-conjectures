/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFifteenthCellReductionV1
import RHKreinSincIntervalV1

/-!
# Fifteenth-cell zeroth centered Taylor-jet enclosure

This module proves the first of the eight analytic jet premises retained by
`RHKreinFifteenthCellReductionV1`. The proof evaluates the unchanged explicit
correction at `5025/65536` using degree-fifteen sine/cosine Taylor polynomials,
the existing exact sinc primitive, and exact rational error propagation.

No symbol enclosure, complete cell theorem, all-cells theorem, or RH statement
is concluded.

AUTHORITY_EFFECT = NONE.
-/

set_option autoImplicit false
set_option maxHeartbeats 12000000
set_option maxRecDepth 32768
noncomputable section

namespace AEGIS.RHKreinFifteenthCellK0V1

open AEGIS.RHKreinFifteenthCellReductionV1
open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinSincIntervalV1
open scoped BigOperators

private def cosPolynomial15 (x : ℝ) : ℝ :=
  1 - x ^ 2 / 2 + x ^ 4 / 24 - x ^ 6 / 720 +
    x ^ 8 / 40320 - x ^ 10 / 3628800 + x ^ 12 / 479001600 -
      x ^ 14 / 87178291200

private def sinPolynomial15 (x : ℝ) : ℝ :=
  x - x ^ 3 / 6 + x ^ 5 / 120 - x ^ 7 / 5040 +
    x ^ 9 / 362880 - x ^ 11 / 39916800 + x ^ 13 / 6227020800 -
      x ^ 15 / 1307674368000

private theorem expIPartial_sixteen_re (x : ℝ) :
    (expIPartial 16 x).re = cosPolynomial15 x := by
  norm_num [expIPartial, cosPolynomial15, Finset.sum_range_succ,
    pow_succ, Complex.mul_re]
  ring

private theorem expIPartial_sixteen_im (x : ℝ) :
    (expIPartial 16 x).im = sinPolynomial15 x := by
  norm_num [expIPartial, sinPolynomial15, Finset.sum_range_succ,
    pow_succ, Complex.mul_im]
  ring

private theorem fifteenth_hat_cos_error (j : Fin 199) :
    |Real.cos (fifteenthCenter * hatCenter j) -
        cosPolynomial15 (fifteenthCenter * hatCenter j)| ≤
      (1 / 100000000000000000000 : ℝ) := by
  let x : ℝ := fifteenthCenter * hatCenter j
  have hjNat : j.val ≤ 198 := by omega
  have hj : (j.val : ℝ) ≤ 198 := by exact_mod_cast hjNat
  have hx0 : 0 ≤ x := by
    dsimp [x]
    unfold fifteenthCenter hatCenter
    positivity
  have hxub : x ≤ (3 / 8 : ℝ) := by
    dsimp [x]
    unfold fifteenthCenter hatCenter
    norm_num
    linarith
  have hx1 : |x| ≤ 1 := by
    rw [abs_of_nonneg hx0]
    exact hxub.trans (by norm_num)
  have h := cos_expIPartial_error 16 x (by norm_num) hx1
  rw [expIPartial_sixteen_re] at h
  have habs : |x| ≤ (3 / 8 : ℝ) := by
    simpa [abs_of_nonneg hx0] using hxub
  have hp := pow_le_pow_left₀ (abs_nonneg x) habs 16
  refine h.trans ?_
  calc
    |x| ^ 16 * (((Nat.succ 16 : ℕ) : ℝ) *
        ((Nat.factorial 16 : ℕ) * 16 : ℝ)⁻¹) ≤
        (3 / 8 : ℝ) ^ 16 * (((Nat.succ 16 : ℕ) : ℝ) *
          ((Nat.factorial 16 : ℕ) * 16 : ℝ)⁻¹) := by
      exact mul_le_mul_of_nonneg_right hp (by positivity)
    _ ≤ (1 / 100000000000000000000 : ℝ) := by norm_num

private theorem edgePhase_eq :
    fifteenthCenter * (1619 / 2000 : ℝ) =
      (325419 / 5242880 : ℝ) := by
  norm_num [fifteenthCenter]

private theorem fifteenth_edge_cos_error :
    |Real.cos (fifteenthCenter * (1619 / 2000 : ℝ)) -
        cosPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 10000000000000000000000000 : ℝ) := by
  rw [edgePhase_eq]
  have h := cos_expIPartial_error 16 (325419 / 5242880 : ℝ)
    (by norm_num) (by norm_num)
  rw [expIPartial_sixteen_re] at h
  exact h.trans (by norm_num)

private theorem fifteenth_edge_sin_error :
    |Real.sin (fifteenthCenter * (1619 / 2000 : ℝ)) -
        sinPolynomial15 (fifteenthCenter * (1619 / 2000 : ℝ))| ≤
      (1 / 10000000000000000000000000 : ℝ) := by
  rw [edgePhase_eq]
  have h := sin_expIPartial_error 16 (325419 / 5242880 : ℝ)
    (by norm_num) (by norm_num)
  rw [expIPartial_sixteen_im] at h
  exact h.trans (by norm_num)

private theorem fifteenth_hat_sinc_error :
    |Real.sinc (fifteenthCenter / 100) -
        sincPolynomial7 (fifteenthCenter / 100)| ≤
      (1 / 100000000000000000000000000 : ℝ) := by
  have hphase : fifteenthCenter / 100 = (201 / 262144 : ℝ) := by
    norm_num [fifteenthCenter]
  have h := sinc_expIPartial_error 8 (fifteenthCenter / 100)
    (by norm_num) (by norm_num [fifteenthCenter]) (by norm_num [fifteenthCenter])
  rw [hphase] at h ⊢
  have hp :
      (expIPartial 8 (201 / 262144 : ℝ)).im / (201 / 262144 : ℝ) =
        sincPolynomial7 (201 / 262144 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

private theorem fifteenth_edge_sinc_error :
    |Real.sinc (fifteenthCenter / 2000) -
        sincPolynomial7 (fifteenthCenter / 2000)| ≤
      (1 / 10000000000000000000000000000000000 : ℝ) := by
  have hphase : fifteenthCenter / 2000 = (201 / 5242880 : ℝ) := by
    norm_num [fifteenthCenter]
  have h := sinc_expIPartial_error 8 (fifteenthCenter / 2000)
    (by norm_num) (by norm_num [fifteenthCenter]) (by norm_num [fifteenthCenter])
  rw [hphase] at h ⊢
  have hp :
      (expIPartial 8 (201 / 5242880 : ℝ)).im / (201 / 5242880 : ℝ) =
        sincPolynomial7 (201 / 5242880 : ℝ) := by
    norm_num [expIPartial, sincPolynomial7, Finset.sum_range_succ,
      pow_succ, Complex.mul_im]
  rw [hp] at h
  exact h.trans (by norm_num)

private def hatApproxSum : ℝ :=
  ∑ j : Fin 199, (hatCoefficient j : ℝ) *
    cosPolynomial15 (fifteenthCenter * hatCenter j)

private def edgePhase (j : Fin 5) : ℝ :=
  if j.val % 2 = 0 then Real.cos (fifteenthCenter * (1619 / 2000))
  else Real.sin (fifteenthCenter * (1619 / 2000))

private def edgePhaseApprox (j : Fin 5) : ℝ :=
  if j.val % 2 = 0 then cosPolynomial15 (fifteenthCenter * (1619 / 2000))
  else sinPolynomial15 (fifteenthCenter * (1619 / 2000))

private def edgeApproxSum : ℝ :=
  ∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
    edgePhaseApprox j

private def fifteenthCorrectionApprox : ℝ :=
  (2 / 50) * sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum +
    sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum

private def hatSumError : ℝ :=
  (∑ j : Fin 199, |(hatCoefficient j : ℝ)|) *
    (1 / 100000000000000000000 : ℝ)

private def edgeSumError : ℝ :=
  ∑ j : Fin 5, |(splineCoefficient j : ℝ) * fifteenthCenter ^ j.val| *
    (1 / 10000000000000000000000000 : ℝ)

private def fifteenthK0ErrorBudget : ℝ :=
  (2 / 50) * (hatSumError +
    |hatApproxSum| * (2 / 100000000000000000000000000 : ℝ)) +
  (edgeSumError +
    |edgeApproxSum| * (19 / 10000000000000000000000000000000000 : ℝ))

private theorem hatSum_error :
    |(∑ j : Fin 199, (hatCoefficient j : ℝ) *
        Real.cos (fifteenthCenter * hatCenter j)) - hatApproxSum| ≤
      hatSumError := by
  unfold hatApproxSum hatSumError
  rw [← Finset.sum_sub_distrib, Finset.sum_mul]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro j _
  rw [← mul_sub, abs_mul]
  exact mul_le_mul_of_nonneg_left (fifteenth_hat_cos_error j) (abs_nonneg _)

private theorem edgePhase_error (j : Fin 5) :
    |edgePhase j - edgePhaseApprox j| ≤
      (1 / 10000000000000000000000000 : ℝ) := by
  fin_cases j
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_cos_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_sin_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_cos_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_sin_error
  · simpa [edgePhase, edgePhaseApprox] using fifteenth_edge_cos_error

private theorem edgeSum_error :
    |(∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
        edgePhase j) - edgeApproxSum| ≤ edgeSumError := by
  unfold edgeApproxSum edgeSumError
  rw [← Finset.sum_sub_distrib]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro j _
  rw [← mul_sub, abs_mul]
  exact mul_le_mul_of_nonneg_left (edgePhase_error j) (abs_nonneg _)

private theorem product_error_unit {x x' y y' ex ey : ℝ}
    (hx : |x| ≤ 1) (hdx : |x - x'| ≤ ex) (hdy : |y - y'| ≤ ey)
    (hex : 0 ≤ ex) :
    |x * y - x' * y'| ≤ ey + |y'| * ex := by
  calc
    |x * y - x' * y'| =
        |x * (y - y') + (x - x') * y'| := by congr 1; ring
    _ ≤ |x * (y - y')| + |(x - x') * y'| := abs_add_le _ _
    _ = |x| * |y - y'| + |x - x'| * |y'| := by rw [abs_mul, abs_mul]
    _ ≤ 1 * ey + ex * |y'| := by
      exact add_le_add
        (mul_le_mul hx hdy (abs_nonneg _) (by norm_num))
        (mul_le_mul hdx le_rfl (abs_nonneg _) hex)
    _ = ey + |y'| * ex := by ring

private theorem hatSincSq_error :
    |Real.sinc (fifteenthCenter / 100) ^ 2 -
        sincPolynomial7 (fifteenthCenter / 100) ^ 2| ≤
      (2 / 100000000000000000000000000 : ℝ) := by
  have ha := Real.abs_sinc_le_one (fifteenthCenter / 100)
  have hp : |sincPolynomial7 (fifteenthCenter / 100)| ≤ 1 := by
    norm_num [fifteenthCenter, sincPolynomial7]
  have hm : max |Real.sinc (fifteenthCenter / 100)|
      |sincPolynomial7 (fifteenthCenter / 100)| ≤ 1 := max_le ha hp
  have hpow : max |Real.sinc (fifteenthCenter / 100)|
      |sincPolynomial7 (fifteenthCenter / 100)| ^ (2 - 1) ≤ 1 := by
    simpa using hm
  calc
    |Real.sinc (fifteenthCenter / 100) ^ 2 -
        sincPolynomial7 (fifteenthCenter / 100) ^ 2| ≤
      |Real.sinc (fifteenthCenter / 100) -
          sincPolynomial7 (fifteenthCenter / 100)| * (2 : ℝ) *
        max |Real.sinc (fifteenthCenter / 100)|
          |sincPolynomial7 (fifteenthCenter / 100)| ^ (2 - 1) :=
      abs_pow_sub_pow_le _ _ _
    _ ≤ (1 / 100000000000000000000000000 : ℝ) * 2 * 1 := by
      exact mul_le_mul
        (mul_le_mul fifteenth_hat_sinc_error le_rfl (by norm_num) (by positivity))
        hpow (by positivity) (by positivity)
    _ = (2 / 100000000000000000000000000 : ℝ) := by norm_num

private theorem edgeSincPow_error :
    |Real.sinc (fifteenthCenter / 2000) ^ 19 -
        sincPolynomial7 (fifteenthCenter / 2000) ^ 19| ≤
      (19 / 10000000000000000000000000000000000 : ℝ) := by
  have ha := Real.abs_sinc_le_one (fifteenthCenter / 2000)
  have hp : |sincPolynomial7 (fifteenthCenter / 2000)| ≤ 1 := by
    norm_num [fifteenthCenter, sincPolynomial7]
  have hm : max |Real.sinc (fifteenthCenter / 2000)|
      |sincPolynomial7 (fifteenthCenter / 2000)| ≤ 1 := max_le ha hp
  have hpow : max |Real.sinc (fifteenthCenter / 2000)|
      |sincPolynomial7 (fifteenthCenter / 2000)| ^ (19 - 1) ≤ 1 := by
    calc
      _ ≤ 1 ^ (19 - 1) := pow_le_pow_left₀ (by positivity) hm _
      _ = 1 := by norm_num
  calc
    |Real.sinc (fifteenthCenter / 2000) ^ 19 -
        sincPolynomial7 (fifteenthCenter / 2000) ^ 19| ≤
      |Real.sinc (fifteenthCenter / 2000) -
          sincPolynomial7 (fifteenthCenter / 2000)| * (19 : ℝ) *
        max |Real.sinc (fifteenthCenter / 2000)|
          |sincPolynomial7 (fifteenthCenter / 2000)| ^ (19 - 1) :=
      abs_pow_sub_pow_le _ _ _
    _ ≤ (1 / 10000000000000000000000000000000000 : ℝ) * 19 * 1 := by
      exact mul_le_mul
        (mul_le_mul fifteenth_edge_sinc_error le_rfl (by norm_num) (by positivity))
        hpow (by positivity) (by positivity)
    _ = (19 / 10000000000000000000000000000000000 : ℝ) := by norm_num

private theorem correctionApprox_error :
    |correctionSymbol fifteenthCenter - fifteenthCorrectionApprox| ≤
      fifteenthK0ErrorBudget := by
  let hatActual : ℝ :=
    ∑ j : Fin 199, (hatCoefficient j : ℝ) *
      Real.cos (fifteenthCenter * hatCenter j)
  let edgeActual : ℝ :=
    ∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
      edgePhase j
  have hhatSum : |hatActual - hatApproxSum| ≤ hatSumError := by
    simpa [hatActual] using hatSum_error
  have hedgeSum : |edgeActual - edgeApproxSum| ≤ edgeSumError := by
    simpa [edgeActual] using edgeSum_error
  have hhatPow : |Real.sinc (fifteenthCenter / 100) ^ 2| ≤ 1 := by
    rw [abs_pow]
    exact (pow_le_pow_left₀ (abs_nonneg _) (Real.abs_sinc_le_one _) 2).trans
      (by norm_num)
  have hedgePow : |Real.sinc (fifteenthCenter / 2000) ^ 19| ≤ 1 := by
    rw [abs_pow]
    exact (pow_le_pow_left₀ (abs_nonneg _) (Real.abs_sinc_le_one _) 19).trans
      (by norm_num)
  have hhat := product_error_unit hhatPow hatSincSq_error hhatSum (by norm_num)
  have hedge := product_error_unit hedgePow edgeSincPow_error hedgeSum (by norm_num)
  unfold correctionSymbol fifteenthCorrectionApprox fifteenthK0ErrorBudget
  change
    |(2 / 50) * Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual +
        Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
      ((2 / 50) * sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum +
        sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum)| ≤ _
  have hdecomp :
      (2 / 50) * Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual +
          Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
        ((2 / 50) * sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum +
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum) =
      (2 / 50) * (Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual -
          sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum) +
        (Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum) := by
    ring
  calc
    _ ≤ |(2 / 50) * (Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual -
          sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum)| +
        |Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum| := by
      rw [hdecomp]
      exact abs_add_le _ _
    _ = (2 / 50) *
          |Real.sinc (fifteenthCenter / 100) ^ 2 * hatActual -
            sincPolynomial7 (fifteenthCenter / 100) ^ 2 * hatApproxSum| +
        |Real.sinc (fifteenthCenter / 2000) ^ 19 * edgeActual -
          sincPolynomial7 (fifteenthCenter / 2000) ^ 19 * edgeApproxSum| := by
      rw [abs_mul, abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 2 / 50)]
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hhat (by norm_num)) hedge

private theorem rational_budget :
    |fifteenthCorrectionApprox - fifteenthJet 0| + fifteenthK0ErrorBudget ≤
      (1 / 1000000000000 : ℝ) := by
  norm_num [fifteenthCorrectionApprox, fifteenthK0ErrorBudget, hatSumError,
    edgeSumError, hatApproxSum, edgeApproxSum, edgePhaseApprox,
    fifteenthCenter, fifteenthJet, sincPolynomial7, cosPolynomial15,
    sinPolynomial15, hatCenter, hatCoefficient, splineCoefficient,
    Fin.sum_univ_succ]

/-- Kernel-checked zeroth centered-jet premise for serialized fifteenth cell. -/
theorem fifteenthCenter_k0_enclosure :
    |exactJetCoefficient fifteenthCenter 0 - fifteenthJet 0| ≤
      fifteenthJetError 0 := by
  have htriangle :
      |correctionSymbol fifteenthCenter - fifteenthJet 0| ≤
        |correctionSymbol fifteenthCenter - fifteenthCorrectionApprox| +
          |fifteenthCorrectionApprox - fifteenthJet 0| := by
    simpa only [sub_add_sub_cancel] using
      abs_add_le (correctionSymbol fifteenthCenter - fifteenthCorrectionApprox)
        (fifteenthCorrectionApprox - fifteenthJet 0)
  have h := htriangle.trans (add_le_add correctionApprox_error
    (le_refl |fifteenthCorrectionApprox - fifteenthJet 0|))
  simp only [exactJetCoefficient, iteratedDeriv_zero, Nat.factorial_zero,
    Nat.cast_one, inv_one, one_mul, fifteenthJetError]
  exact h.trans (by linarith [rational_budget])
end AEGIS.RHKreinFifteenthCellK0V1

#print axioms AEGIS.RHKreinFifteenthCellK0V1.fifteenthCenter_k0_enclosure
