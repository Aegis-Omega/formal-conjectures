/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFifteenthCellK0V1

/-!
# Fifteenth-cell first-derivative formula

This file expands the first derivative of `correctionSymbol` at the exact
fifteenth-cell midpoint.  It reduces the `k = 1` Taylor-jet premise to one
explicit numerical enclosure.  It does not assert that enclosure.

AUTHORITY_EFFECT = NONE.
-/

open scoped BigOperators

set_option autoImplicit false
set_option maxHeartbeats 800000
noncomputable section

namespace AEGIS.RHKreinFifteenthCellK1FormulaV1

open AEGIS.RHKreinExplicitCorrectionV1
open AEGIS.RHKreinFifteenthCellReductionV1
open AEGIS.RHKreinM8AnalyticV1

/-- Quotient-rule derivative of `sinc` away from zero. -/
theorem hasDerivAt_sinc_of_ne_zero {x : ℝ} (hx : x ≠ 0) :
    HasDerivAt Real.sinc ((x * Real.cos x - Real.sin x) / x ^ 2) x := by
  have hquot : HasDerivAt (fun y : ℝ => Real.sin y / y)
      ((x * Real.cos x - Real.sin x) / x ^ 2) x := by
    have h := (Real.hasDerivAt_sin x).div (hasDerivAt_id x) hx
    have hfun : (Real.sin / id : ℝ → ℝ) = fun y : ℝ => Real.sin y / y := by
      funext y
      rfl
    rw [hfun] at h
    simpa only [id_eq, mul_one, one_mul, mul_comm] using h
  apply hquot.congr_of_eventuallyEq
  filter_upwards [eventually_ne_nhds hx] with y hy
  rw [Real.sinc_of_ne_zero hy]

/-- Chain-rule specialization for a nonzero scaled sinc argument. -/
theorem hasDerivAt_sinc_div_const {c d : ℝ} (hc : c / d ≠ 0) :
    HasDerivAt (fun t : ℝ => Real.sinc (t / d))
      (((c / d) * Real.cos (c / d) - Real.sin (c / d)) / (c / d) ^ 2 *
        (1 / d)) c := by
  have hi : HasDerivAt (fun t : ℝ => t / d) (1 / d) c := by
    simpa only [id_eq] using (hasDerivAt_id c).div_const d
  exact (hasDerivAt_sinc_of_ne_zero hc).comp c hi

/-- The derivative of one trigonometric hat column at the midpoint. -/
def hatColumnDerivative (j : Fin 199) : ℝ :=
  (hatCoefficient j : ℝ) *
    (-(Real.sin (fifteenthCenter * hatCenter j) * hatCenter j))

/-- Derivative of the parity-selected edge phase at the midpoint. -/
def edgePhaseDerivative (j : Fin 5) : ℝ :=
  if j.val % 2 = 0 then
    -(Real.sin (fifteenthCenter * (1619 / 2000)) * (1619 / 2000))
  else
    Real.cos (fifteenthCenter * (1619 / 2000)) * (1619 / 2000)

/-- Derivative of one polynomial-times-phase edge column at the midpoint. -/
def edgeColumnDerivative (j : Fin 5) : ℝ :=
  (splineCoefficient j : ℝ) *
    (((j.val : ℝ) * fifteenthCenter ^ (j.val - 1)) *
        (if j.val % 2 = 0 then
          Real.cos (fifteenthCenter * (1619 / 2000))
        else
          Real.sin (fifteenthCenter * (1619 / 2000))) +
      fifteenthCenter ^ j.val * edgePhaseDerivative j)

/-- The sinc derivative in the hat component. -/
def fifteenthHatSincDerivative : ℝ :=
  ((fifteenthCenter / 100) * Real.cos (fifteenthCenter / 100) -
      Real.sin (fifteenthCenter / 100)) / (fifteenthCenter / 100) ^ 2 *
    (1 / 100)

/-- The sinc derivative in the edge component. -/
def fifteenthEdgeSincDerivative : ℝ :=
  ((fifteenthCenter / 2000) * Real.cos (fifteenthCenter / 2000) -
      Real.sin (fifteenthCenter / 2000)) / (fifteenthCenter / 2000) ^ 2 *
    (1 / 2000)

/-- Fully expanded product-rule value for `correctionSymbol' fifteenthCenter`. -/
def fifteenthCorrectionDerivativeFormula : ℝ :=
  (2 / 50) *
      ((2 * Real.sinc (fifteenthCenter / 100) * fifteenthHatSincDerivative) *
          (∑ j : Fin 199, (hatCoefficient j : ℝ) *
            Real.cos (fifteenthCenter * hatCenter j)) +
        Real.sinc (fifteenthCenter / 100) ^ 2 *
          (∑ j : Fin 199, hatColumnDerivative j)) +
    (19 * Real.sinc (fifteenthCenter / 2000) ^ 18 *
        fifteenthEdgeSincDerivative) *
      (∑ j : Fin 5, (splineCoefficient j : ℝ) * fifteenthCenter ^ j.val *
        (if j.val % 2 = 0 then
          Real.cos (fifteenthCenter * (1619 / 2000))
        else
          Real.sin (fifteenthCenter * (1619 / 2000)))) +
    Real.sinc (fifteenthCenter / 2000) ^ 19 *
      (∑ j : Fin 5, edgeColumnDerivative j)

private theorem hatColumn_hasDerivAt (j : Fin 199) :
    HasDerivAt
      (fun t : ℝ => (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j))
      (hatColumnDerivative j) fifteenthCenter := by
  have hinner := (hasDerivAt_id fifteenthCenter).mul_const (hatCenter j)
  simpa [hatColumnDerivative, mul_assoc] using
    ((Real.hasDerivAt_cos (fifteenthCenter * hatCenter j)).comp
      fifteenthCenter hinner).const_mul (hatCoefficient j : ℝ)

private theorem edgePhase_hasDerivAt (j : Fin 5) :
    HasDerivAt
      (fun t : ℝ =>
        if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
        else Real.sin (t * (1619 / 2000)))
      (edgePhaseDerivative j) fifteenthCenter := by
  have hinner := (hasDerivAt_id fifteenthCenter).mul_const (1619 / 2000 : ℝ)
  by_cases hj : j.val % 2 = 0
  · simp only [hj, if_true, edgePhaseDerivative]
    simpa [Function.comp_def, mul_assoc] using
      (Real.hasDerivAt_cos (fifteenthCenter * (1619 / 2000))).comp
        fifteenthCenter hinner
  · simp only [hj, if_false, edgePhaseDerivative]
    simpa [Function.comp_def] using
      (Real.hasDerivAt_sin (fifteenthCenter * (1619 / 2000))).comp
        fifteenthCenter hinner

private theorem edgeColumn_hasDerivAt (j : Fin 5) :
    HasDerivAt
      (fun t : ℝ => (splineCoefficient j : ℝ) * t ^ j.val *
        (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
        else Real.sin (t * (1619 / 2000))))
      (edgeColumnDerivative j) fifteenthCenter := by
  have hpow := hasDerivAt_pow j.val fifteenthCenter
  have hphase := edgePhase_hasDerivAt j
  have hproduct := hpow.mul hphase
  simpa [edgeColumnDerivative, mul_add, mul_assoc] using
    hproduct.const_mul (splineCoefficient j : ℝ)

/-- The explicit formula is the ordinary first derivative at the exact
fifteenth-cell midpoint. -/
theorem correctionSymbol_hasDerivAt_fifteenthCenter :
    HasDerivAt correctionSymbol fifteenthCorrectionDerivativeFormula
      fifteenthCenter := by
  have hhatSum :
      HasDerivAt
        (fun t : ℝ => ∑ j : Fin 199,
          (hatCoefficient j : ℝ) * Real.cos (t * hatCenter j))
        (∑ j : Fin 199, hatColumnDerivative j) fifteenthCenter := by
    exact HasDerivAt.fun_sum fun j _ => hatColumn_hasDerivAt j
  have hedgeSum :
      HasDerivAt
        (fun t : ℝ => ∑ j : Fin 5, (splineCoefficient j : ℝ) * t ^ j.val *
          (if j.val % 2 = 0 then Real.cos (t * (1619 / 2000))
          else Real.sin (t * (1619 / 2000))))
        (∑ j : Fin 5, edgeColumnDerivative j) fifteenthCenter := by
    exact HasDerivAt.fun_sum fun j _ => edgeColumn_hasDerivAt j
  have hhatSinc : HasDerivAt (fun t : ℝ => Real.sinc (t / 100))
      fifteenthHatSincDerivative fifteenthCenter := by
    apply hasDerivAt_sinc_div_const
    norm_num [fifteenthCenter]
  have hedgeSinc : HasDerivAt (fun t : ℝ => Real.sinc (t / 2000))
      fifteenthEdgeSincDerivative fifteenthCenter := by
    apply hasDerivAt_sinc_div_const
    norm_num [fifteenthCenter]
  have hhat := (hhatSinc.pow 2).mul hhatSum
  have hedge := (hedgeSinc.pow 19).mul hedgeSum
  have hfull := hhat.const_mul (2 / 50 : ℝ) |>.add hedge
  have hsymbol := hfull.congr_of_eventuallyEq
    (show Filter.EventuallyEq (nhds fifteenthCenter) correctionSymbol _ from
      Filter.Eventually.of_forall fun t => by
        simp only [correctionSymbol]
        ring)
  apply hsymbol.congr_deriv
  simp only [fifteenthCorrectionDerivativeFormula,
    fifteenthHatSincDerivative, fifteenthEdgeSincDerivative, Pi.pow_apply]
  ring

/-- For `k = 1`, the normalized exact jet is the expanded derivative formula. -/
theorem fifteenthCenter_exactJetCoefficient_one :
    exactJetCoefficient fifteenthCenter 1 =
      fifteenthCorrectionDerivativeFormula := by
  rw [exactJetCoefficient, iteratedDeriv_one]
  norm_num
  exact correctionSymbol_hasDerivAt_fifteenthCenter.deriv

/-- Formula-to-target transport for the serialized `k = 1` enclosure. -/
theorem fifteenthCenter_k1_enclosure_of_formula
    (hformula :
      |fifteenthCorrectionDerivativeFormula - fifteenthJet 1| ≤
        fifteenthJetError 1) :
    |exactJetCoefficient fifteenthCenter 1 - fifteenthJet 1| ≤
      fifteenthJetError 1 := by
  rwa [fifteenthCenter_exactJetCoefficient_one]

end AEGIS.RHKreinFifteenthCellK1FormulaV1

#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.hasDerivAt_sinc_of_ne_zero
#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.correctionSymbol_hasDerivAt_fifteenthCenter
#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.fifteenthCenter_exactJetCoefficient_one
#print axioms AEGIS.RHKreinFifteenthCellK1FormulaV1.fifteenthCenter_k1_enclosure_of_formula
