/-
Copyright 2026 The Formal Conjectures Authors.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import RHKreinFifteenthCellK0V1

/-!
# Compose the fifteenth-cell k=0 enclosure

Exactly the seven nonzero midpoint jets remain explicit premises. No global RH
or admission statement is introduced.
-/

set_option autoImplicit false
noncomputable section

namespace AEGIS.RHKreinFifteenthCellK0CompositionV1

open AEGIS.RHKreinFiniteCertificateAssemblyV1
open AEGIS.RHKreinFiniteIntervalKernelV1
open AEGIS.RHKreinM8AnalyticV1
open AEGIS.RHKreinFifteenthCellReductionV1
open AEGIS.RHKreinFifteenthCellK0V1

theorem fifteenthCell_sound_of_midpoint_jets_except_zero
    (hjet : ∀ k ∈ Finset.Ico 1 8,
      |exactJetCoefficient fifteenthCenter k - fifteenthJet k| ≤
        fifteenthJetError k) :
    CellAnalyticSoundV1 fifteenthCell := by
  apply fifteenthCell_sound_of_midpoint_jets
  intro k hk
  by_cases hk0 : k = 0
  · simpa [hk0] using fifteenthCenter_k0_enclosure
  · apply hjet k
    simp only [Finset.mem_Ico]
    simp only [Finset.mem_range] at hk
    omega

theorem first_fifteen_cells_sound_of_midpoint_jets_except_zero
    (hjet : ∀ k ∈ Finset.Ico 1 8,
      |exactJetCoefficient fifteenthCenter k - fifteenthJet k| ≤
        fifteenthJetError k) :
    CellAnalyticSoundV1 AEGIS.RHKreinFirstCellV1.firstCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSecondCellReductionV1.secondCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirdCellCompositionV1.thirdCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourthCellCompositionV1.fourthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFifthCellCompositionV1.fifthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSixthCellReductionV1.sixthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinSeventhCellCompositionV1.seventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEighthCellCompositionV1.eighthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinNinthCellCompositionV1.ninthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTenthCellCompositionV1.tenthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinEleventhCellCompositionV1.eleventhCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinTwelfthCellCompositionV1.twelfthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinThirteenthCellCompositionV1.thirteenthCell ∧
      CellAnalyticSoundV1 AEGIS.RHKreinFourteenthCellCompositionV1.fourteenthCell ∧
      CellAnalyticSoundV1 fifteenthCell := by
  apply first_fifteen_cells_sound_of_midpoint_jets
  intro k hk
  by_cases hk0 : k = 0
  · simpa [hk0] using fifteenthCenter_k0_enclosure
  · apply hjet k
    simp only [Finset.mem_Ico]
    simp only [Finset.mem_range] at hk
    omega

end AEGIS.RHKreinFifteenthCellK0CompositionV1

#print axioms AEGIS.RHKreinFifteenthCellK0CompositionV1.fifteenthCell_sound_of_midpoint_jets_except_zero
#print axioms AEGIS.RHKreinFifteenthCellK0CompositionV1.first_fifteen_cells_sound_of_midpoint_jets_except_zero
