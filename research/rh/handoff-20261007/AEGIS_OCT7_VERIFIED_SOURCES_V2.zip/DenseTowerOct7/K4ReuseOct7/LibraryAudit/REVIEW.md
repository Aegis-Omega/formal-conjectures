# Cell15 k=4: bounded existing-proof reuse audit

The requested proposition is the normalized fourth ordinary derivative of the **actual unchanged correction symbol** at the fifteenth-cell midpoint:

\[
\left|\operatorname{exactJetCoefficient}(5025/65536,4)
  -51983766003/25000000000\right|\le10^{-12}.
\]

`exactJetCoefficient c k` is `(k.factorial : ℝ)⁻¹ * iteratedDeriv k correctionSymbol c`; hence order four includes division by 24. The centre, coefficient, and radius above are the original definitions in `RHKreinFifteenthCellReductionV1`. No surrogate or other symbol was substituted.

## Scope and result

All 155 restored Lean source files were read as bytes, hashed, matched to the source index's Git blob identities, and searched for exact target constants, aliases, coefficient definitions, derivative formulas, and generic Taylor/jet transport. The candidate proof bodies below were read semantically. This is not a semantic audit of every unrelated Li/Weil proof, nor an elaborated-type or fresh kernel replay. The parent handles the wider workspace and source-bound application/probes. No restored library or previous result was changed.

Within this finite source scope, the exact midpoint k=4 enclosure was **not located as a produced conclusion**. It is retained as a premise in the original midpoint reductions. This means `NOT_LOCATED_IN_SEARCHED_SCOPE`, not mathematical nonexistence, not a claim that another branch or archive lacks it, and not a request to reprove the already closed zero-centre coefficient.

The restored `RHKreinFirstCellV1` contains the complete direct zero-centre fourth-derivative proof body, but this audit does not claim a fresh replay of that body. This source recovery is distinct from the earlier source-bound kernel-checked `actual_even_jet_four` and `actual_even_jet_six` interpolation endpoints in the wider workspace. Those earlier closures remain valid under their precise source identities; the parent handles their current lightweight type/axiom probe. The fourteen-cell composition below is likewise a recovered complete source body, not a newly replayed endpoint or a CI-status assertion.

## Reusable proofs and exact compatibility

| Existing result | Actual conclusion and hypotheses | Relation to requested k=4 |
|---|---|---|
| `AEGIS.RHKreinFirstCellV1.firstJet_four_enclosure` | Premise-free `|exactJetCoefficient firstCenter 4 - firstJet 4| ≤ firstJetError 4`; `firstCenter=0`, `firstJet 4=2096414380799/10^12`, `firstJetError 4=10^-12` | Already proved and preserved. Same actual correction and normalization, different centre and interval. Not a direct application to `5025/65536`. |
| `AEGIS.RHKreinFirstCellV1.correctionSymbol_fourth_formula` (private) | Fourth derivative formula at zero, using sinc/hat/spline zero derivatives | Its proof uses zero-centre parity and zero derivative identities; it does not state an arbitrary-centre formula. |
| `AEGIS.RHKreinSecondCellCompositionV1.existing_zero_jet_enclosures` | All eight normalized enclosures at `firstCenter=0` | Reuses the original order-four and order-six proof terms, preserving their centre. Does not produce midpoint coefficients. |
| `AEGIS.RHKreinFourteenthCellCompositionV1.first_fourteen_cells_sound` | Premise-free conjunction of the first fourteen actual `CellAnalyticSoundV1` endpoints | Substantial existing composition. It uses the original zero jet and PR54 finite-window M8. Cell positivity is not a fourth derivative enclosure at a new point. |
| `AEGIS.RHKreinFifteenthCellReductionV1.fifteenthCell_sound_of_midpoint_jets` | Takes `hjet : ∀ k ∈ range 8, |exactJetCoefficient fifteenthCenter k-fifteenthJet k| ≤ fifteenthJetError k` | The requested theorem is literally its k=4 input. Applying it does not produce that input. |
| `AEGIS.RHKreinFifteenthCellK0CompositionV1.fifteenthCell_sound_of_midpoint_jets_except_zero` | Takes the same `hjet` on `Ico 1 8`, inserts the proved zeroth enclosure | k=0 is closed by an actual producer; k=4 remains in this exact theorem's stated premises. |
| `AEGIS.RHKreinFifteenthCellK0V1.fifteenthCenter_k0_enclosure` | Premise-free actual midpoint zeroth coefficient bound | The analytic Taylor/error mechanism and actual data are reusable, but the theorem concerns k=0. |
| `AEGIS.RHKreinFifteenthCellK1FormulaV1.fifteenthCenter_exactJetCoefficient_one` | Actual midpoint first coefficient equals its explicit first derivative formula | A proved formula, with all product-rule factors. It is not a fourth derivative or its numerical bound. |
| `AEGIS.RHKreinFifteenthCellK1FormulaV1.fifteenthCenter_k1_enclosure_of_formula` | Takes the numerical first-formula enclosure and transports it to k=1 | Precisely preserves its numerical premise; cannot instantiate k=4 because order one is fixed. |

The zero-centre and midpoint k=4 interval centres differ by exactly `17063740679/10^12`, over ten billion times the target radius. Their enclosures are disjoint. This is a straightforward guard against accidental centre substitution, not a refutation of either correctly stated theorem.

## Generic analytic modules: producers versus consumers

`RHKreinM8AnalyticV1.correction_taylor7_remainder (c x : ℝ)` gives an actual **function-value** approximation by its degree-seven Taylor polynomial, for every centre and argument. `centeredTaylor_eq_exactJet` identifies that polynomial with the normalized coefficients at its supplied centre. These are valuable unconditional results. Neither supplies values of those coefficients at a new centre.

`jetPolynomial7_error`, `correction_jet7_error`, and `correction_lower_of_jet_enclosures` retain the exact `hjet` enclosure family as an argument. They propagate supplied coefficient bounds to function bounds. Replacing that argument by the desired conclusion is circular. `correction_lower_of_exact_taylor` instead retains the bound on the actual Taylor polynomial; that is also a separate input.

`RHKreinSymmetricCellProducerV1.cellAnalyticSound_of_symmetric_jet_box` explicitly retains `hjet`, symbol bounds, cell geometry, weight, sign, and ground-budget premises. It is a cell-soundness constructor, not a transcendental jet-value generator. The inspected body does not drop these assumptions.

`RHKreinCorrectionTaylorBridgeV1` identifies the actual correction's angular Fourier transform, proves its moments and smoothness through order eight, and bounds its **eighth** derivative. `RHKreinFourierTaylorBoundV1` has corresponding general eighth-order statements with explicit `HasMomentsUpToEight`. `RHKreinFiniteIntervalKernelV1` gives arbitrary-order exponential sine/cosine errors and the degree-seven Taylor remainder. These supply reusable analytic primitives. The audited declarations do not directly enclose the actual fourth coefficient at `5025/65536`.

The PR54 finite-window theorem preserves all real frequency/window parameters and controls the eighth derivative; it is already composed into cells 6–14. It is not a shifted fourth-derivative evaluation. Files named `FourthCellComposition` refer to the fourth serialized cell, not derivative order four.

## Composition decision

No new proof of zero-centre k=4 or k=6 should be commissioned from this audit. Those terms are existing inputs to many successful cell compositions. The direct shifted-target proof term was not located in this restored scope, while the original exact midpoint reduction makes its required type unambiguous. Before constructing a new midpoint formula/enclosure, the parent should continue the already assigned wider search for a matching existing term or an arbitrary-centre derivative producer with discharged error bounds.

No fresh compile, axiom print, or original ZIP replay was performed by this audit. Source `#print axioms` directives are recorded as directives only; they are not relabeled as executed output. The original transfer receipt explicitly records no Lean kernel replay. RH and all-cell soundness are not conclusions of the reviewed k=4 reuse search.

## Separate wider interpolation observation

The delegated read-only review also inspected the already bound wider `PR53Lane/IntegrationReview/FinalReviewOct7/Snapshot15` sources. These files are **not among the 155 restored files**, and are not counted as such. `RHKreinZeroJetInterpolationV1.actual_even_jet_four` is the zero-centre coefficient bound, with `firstCenter=0` and `target4=2096414380799/10^12`; its coupling uses odd-jet vanishing at zero.

`EvenJetInterpolation.extractFour_evenPolynomial` is valid for arbitrary coefficients and isolates `q4*h^4` from three even-polynomial node values. `extractFour_error` retains three node-error premises and weights them by `13/24`, `1/6`, and `1/72`. `coefficient_error_of_scaled` retains positive scale, scaled-error, and target-deviation premises. To apply these existing generic terms at the new midpoint requires an appropriate shifted coupling, three actually produced shifted node enclosures (including any baseline error), and the exact scaled target/error budget. The original zero-centre coupling is not a shifted producer. This observation identifies reusable algebra, not a new proof or a claim that shifted producers do not exist elsewhere.
