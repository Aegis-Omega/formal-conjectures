#!/usr/bin/env python3
"""Read and bind the complete restored scope; emit source-level candidates only."""
from pathlib import Path
from hashlib import sha256, sha1
from fractions import Fraction
from datetime import datetime, timezone
import json
import re

W=Path('/workspace/aegis-research/work')
L=W/'DenseTowerOct7/LibraryTransfer'
S=L/'Restored/source'
O=Path(__file__).resolve().parent
checks=[]
bindings={}
def bind(p):
    data=Path(p).read_bytes()
    bindings[str(p)]={'path':str(p),'sha256':sha256(data).hexdigest(),'bytes':len(data)}
    return data
def check(name,ok):
    checks.append({'name':name,'pass':bool(ok)})

index=bind(L/'MODULE_INDEX.md').decode()
rows=re.findall(r'^\| `([^`]+)` \| `source/([^`]+)` \| ([^|]+) \| `([a-f0-9]{40})` \|$',index,re.M)
files=sorted(S.rglob('*.lean'))
check('exact155LeanFiles',len(files)==155)
check('exact155IndexedModules',len(rows)==155)
byrel={rel:(module,parts.strip(),blob) for module,rel,parts,blob in rows}
check('indexCoversExactlyRestoredScope',set(byrel)=={str(p.relative_to(S)) for p in files})
terms=[r'51983766003',r'5025\s*/\s*65536',r'exactJetCoefficient',r'iteratedDeriv\s+4',
       r'fourth',r'Fourth',r'four_enclosure',r'\b[Kk]4\b',r'shiftTaylor',r'zeroJet',
       r'midpoint',r'centeredTaylor',r'HasDerivAt',r'jet_enclosures']
patterns=[re.compile(p) for p in terms]
scan=[]
sources={}
for p in files:
    data=bind(p)
    src=data.decode()
    rel=str(p.relative_to(S))
    module,parts,expected=byrel[rel]
    blob=sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    check('indexGitBlob:'+rel,blob==expected)
    sources[rel]=src
    hits=[{'line':i+1,'text':line,'patterns':[terms[k] for k,rx in enumerate(patterns) if rx.search(line)]}
          for i,line in enumerate(src.splitlines()) if any(rx.search(line) for rx in patterns)]
    scan.append({'module':module,'relative_source':rel,'git_blob':blob,'indexed_parts':parts,
                 'sha256':sha256(data).hexdigest(),'bytes':len(data),'matching_lines':hits})

for p in [L/'TRANSFER_RECEIPT.json',L/'IMPORT_GRAPH.json',L/'source-receipt.json']:
    bind(p)
transfer=json.loads((L/'TRANSFER_RECEIPT.json').read_text())
check('transferKernelScopeNotMisattributed',transfer['result']['lean_kernel_replayed'] is False)
target=sources['RHKreinFifteenthCellReductionV1.lean']
check('exactTargetCentre', 'def fifteenthCenter : ℝ := 5025 / 65536' in target)
check('exactTargetCoefficient','| 4 => 51983766003 / 25000000000' in target)
check('exactTargetRadius','def fifteenthJetError (_ : ℕ) : ℝ := 1 / 1000000000000' in target)
check('originalReductionRetainsJetPremise','(hjet : ∀ k ∈ Finset.range 8,' in target)
zero=sources['RHKreinFirstCellV1.lean']
check('closedZeroCentreRetained','def firstCenter : ℝ := 0' in zero)
check('closedZeroK4Retained','theorem firstJet_four_enclosure :' in zero
      and '|exactJetCoefficient firstCenter 4 - firstJet 4| ≤ firstJetError 4' in zero)
check('closedZeroK6Retained','theorem firstJet_six_enclosure :' in zero)
shift=sources['AEGISOverlay/RHKreinM8AnalyticV1.lean']
check('genericJetConsumerRetainsPremise',shift.count('(hjet : ∀ k ∈ Finset.range 8,')==3)
check('sourceDefinitionNormalization','(k.factorial : ℝ)⁻¹ * iteratedDeriv k correctionSymbol c' in shift)
check('fourteenExistingCompositionRetained','theorem first_fourteen_cells_sound :' in sources['RHKreinFourteenthCellCompositionV1.lean'])
check('k0ProducerPresent','theorem fifteenthCenter_k0_enclosure :' in sources['RHKreinFifteenthCellK0V1.lean'])
check('k1FormulaTransportRetainsNumericalPremise',
      'theorem fifteenthCenter_k1_enclosure_of_formula\n    (hformula :' in sources['RHKreinFifteenthCellK1FormulaV1.lean'])
qzero=Fraction(2096414380799,10**12)
qmid=Fraction(51983766003,25000000000)
diff=qzero-qmid
check('distinctK4TargetIntervals',diff==Fraction(17063740679,10**12) and diff>Fraction(2,10**12))

# Explicitly separate already frozen wider candidate sources from the 155-file scope.
wider = W/'DenseTowerOct7/PR53Lane/IntegrationReview/FinalReviewOct7/Snapshot15'
for name in ('RHKreinZeroJetInterpolationV1.lean','EvenJetInterpolation.lean'):
    bind(wider/name)
widezero=(wider/'RHKreinZeroJetInterpolationV1.lean').read_text()
check('widerInterpolationExplicitlyZeroCentred','theorem actual_even_jet_four' in widezero
      and 'exactJetCoefficient firstCenter 4' in widezero)

# Preserve exact source declarations with full bodies, not invented compiler output.
audited=[
 'RHKreinFirstCellV1.lean','RHKreinSecondCellCompositionV1.lean',
 'RHKreinFourteenthCellCompositionV1.lean','RHKreinFifteenthCellReductionV1.lean',
 'RHKreinFifteenthCellK0CompositionV1.lean','RHKreinFifteenthCellK0V1.lean',
 'RHKreinFifteenthCellK1FormulaV1.lean','RHKreinSymmetricCellProducerV1.lean',
 'RHKreinCellAnalyticBridgeV1.lean','AEGISOverlay/RHKreinM8AnalyticV1.lean',
 'AEGISOverlay/RHKreinCorrectionTaylorBridgeV1.lean',
 'AEGISOverlay/RHKreinFourierTaylorBoundV1.lean',
 'AEGISOverlay/RHKreinFiniteIntervalKernelV1.lean',
 'research/rh/finite_m8_v1/RHKreinM8FiniteWindowV1.lean'
]
snapshot=O/'CandidateSources'
for rel in audited:
    dest=snapshot/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    data=sources[rel].encode()
    if dest.exists() and dest.read_bytes()!=data:
        raise SystemExit('Refusing changed snapshot '+str(dest))
    dest.write_bytes(data)
    bind(dest)

scanpath=O/'SCANNED_MODULES.json'
if scanpath.exists():
    raise SystemExit('Refusing overwrite of scan record')
scanpath.write_text(json.dumps({'source_scope':str(S),'module_count':len(scan),
    'scan_is_source_search_not_elaboration':True,'modules':scan},indent=2,sort_keys=True)+'\n')
bind(scanpath)
bind(O/'REVIEW.md')
bind(Path(__file__))

result={'schema':'aegis.oct7.cell15-k4.restored-library-reuse-audit.v1',
    'created_utc':datetime.now(timezone.utc).isoformat(),
    'status':'PASS_BOUNDED_SOURCE_AUDIT' if all(c['pass'] for c in checks) else 'FAIL',
    'exact_target':'|AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient (5025/65536) 4 - 51983766003/25000000000| <= 1/10^12',
    'searched_source_scope':str(S),'all_sources_byte_read_and_searched':155,
    'semantically_reviewed_candidate_files':audited,
    'direct_target_producer_status':'NOT_LOCATED_IN_SEARCHED_SCOPE',
    'absence_is_not_mathematical_nonexistence':True,
    'existing_zero_centre_k4_and_k6_proofs_preserved':True,
    'exact_midpoint_required_by_existing_reduction':True,
    'generic_value_transport_hjet_is_consumer_not_producer':True,
    'first_fourteen_cell_composition':'WRITTEN_PROOF_RECOVERED_UNDER_NO_JET_PREMISES',
    'shifted_coefficient_application':'COMPOSITION_PENDING_MATCHING_PRODUCER',
    'source_type_audit':'Stated Lean source types and proof bodies; no new elaboration',
    'compiler_execution_or_axiom_print_in_this_audit':False,
    'kernel_replay_status':'NOT_RUN_BY_THIS_AUDIT',
    'broader_workspace_and_archives':'Outside this bounded task; parent searches independently',
    'wider_interpolation_observation':{
        'separate_sources_bound':str(wider),
        'not_counted_among155':True,
        'actual_even_jet_four':'Existing zero-centre kernel closure; not target midpoint',
        'reusable_generic_algebra':['extractFour_evenPolynomial','extractFour_error','coefficient_error_of_scaled'],
        'shifted_application_requires':['shifted coupling','three shifted node enclosures with baseline errors',
                                      'scaled target-error budget','positive scale']},
    'new_mathematics_requested_by_audit':False,
    'rh_proven':False,'all_cells_proven':False,
    'checks':checks,'passed_checks':sum(c['pass'] for c in checks),'total_checks':len(checks),
    'bindings':sorted(bindings.values(),key=lambda q:q['path'])}
dest=O/'RECEIPT.json'
if dest.exists():
    raise SystemExit('Refusing overwrite of frozen audit receipt')
dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'checks':f"{result['passed_checks']}/{len(checks)}",
                 'bindings':len(bindings),'receipt':str(dest),
                 'receipt_sha256':sha256(dest.read_bytes()).hexdigest()},indent=2))
raise SystemExit(0 if result['status'].startswith('PASS') else 1)
