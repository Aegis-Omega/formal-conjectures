#!/usr/bin/env python3
"""Record bounded existing-proof reuse; never compile or alter reviewed sources."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
INTEGRATION = WORK / 'Cell15Concrete/OriginalTargetIntegration'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    compile_records = []
    bindings = {}
    for run_name, names in [
        ('scoped-original-replay-20261007T062514.855467Z', ['RHKreinSecondCellCompositionV1']),
        ('scoped-original-replay-20261007T062632.011537Z', [
            'RHKreinThirdCellCompositionV1', 'RHKreinFourthCellCompositionV1',
            'RHKreinFifthCellCompositionV1']),
    ]:
        run = INTEGRATION / run_name
        receipt_path = run / 'RECEIPT.json'
        receipt = json.loads(receipt_path.read_text())
        bindings[str(receipt_path)] = digest(receipt_path)
        require(receipt['status'] == 'FAILED', 'Preserve the failed overall run status')
        for name in names:
            record = next(r for r in receipt['module_records'] if r['module'] == name)
            job = next(j for j in receipt['jobs'] if j['name'] == 'compile-' + name)
            require(job['exit_code'] == 0, name + ' did not compile')
            require('--trust=0' in job['command'], name + ' trust flag missing')
            for path_key, hash_key in [
                ('source_path', 'source_sha256'),
                ('effective_source_path', 'effective_source_sha256'),
                ('object_path', 'object_sha256'),
            ]:
                path = Path(record[path_key])
                actual = digest(path)
                require(actual == record[hash_key], 'Changed source/object ' + str(path))
                bindings[str(path)] = actual
            log = run / 'logs' / ('compile-' + name + '.stdout.txt')
            error_log = run / 'logs' / ('compile-' + name + '.stderr.txt')
            text = log.read_text()
            reports = []
            for theorem, axioms in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]", text):
                axiom_list = [a.strip() for a in axioms.split(',') if a.strip()]
                require(set(axiom_list) == {'propext', 'Classical.choice', 'Quot.sound'},
                        'Unexpected axioms for ' + theorem)
                reports.append({'theorem': theorem, 'axioms': axiom_list})
            require(bool(reports), 'No axiom output for ' + name)
            require(digest(log) == job['stdout_sha256'], 'Changed compiler stdout')
            require(digest(error_log) == job['stderr_sha256'], 'Changed compiler stderr')
            bindings[str(log)] = digest(log)
            bindings[str(error_log)] = digest(error_log)
            compile_records.append({
                'module': name,
                'individual_compile_status': 'PASS_FRESH_EFFECTIVE_SOURCE_COMPILE',
                'overall_original_receipt_status': receipt['status'],
                'overall_original_receipt_reason': receipt['reason'],
                'receipt_path': str(receipt_path),
                'receipt_sha256': digest(receipt_path),
                'module_record': record, 'job': job,
                'compiler_stdout': str(log), 'axiom_reports': reports,
                'independent_module_leanchecker_in_this_audit': 'NOT_RUN',
                'full_transitive_source_rebuild': False,
            })
    require(len(compile_records) == 4, 'Require all four actual cell composition records')
    second_source = Path(compile_records[0]['module_record']['source_path']).read_text()
    require('AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_four' in second_source,
            'Actual reused k4 application missing')
    write('EXISTING_APPLICATION_REPLAY_RECORDS.json', {
        'schema': 'aegis.k4.existing-applied-composition-source-records.v1',
        'status': 'PASS_BOUND_INDIVIDUAL_COMPILE_AND_AXIOM_RECORDS',
        'overall_failed_runs_not_relabelled_pass': True,
        'records': compile_records, 'bindings': bindings,
        'rh_proven': False, 'first_fourteen_fresh_kernel_replay_claimed': False,
    })

    concrete_path = HERE / 'ConcreteReuse/scoped-replay-20261007T063818.465049Z/RECEIPT.json'
    concrete = json.loads(concrete_path.read_text())
    require(concrete['status'] == 'PASS', 'Concrete typed alias replay did not pass')
    for path, expected in concrete['input_bindings'].items():
        require(digest(path) == expected, 'Changed concrete input ' + path)
    library_path = HERE / 'LibraryAudit/RECEIPT.json'
    library = json.loads(library_path.read_text())
    require(library['status'] == 'PASS_BOUNDED_SOURCE_AUDIT', 'Library review not pass')
    require(library['passed_checks'] == library['total_checks'], 'Library review failed checks')
    scope = json.loads((HERE / 'SOURCE_SEARCH_SCOPE.json').read_text())
    selected_sources = [
        Path('/workspace/aegis-research/provider/.lake/packages/mathlib/Mathlib/Analysis/Fourier/FourierTransformDeriv.lean'),
        Path('/workspace/aegis-research/work/PR53CellIntegration/RHKreinFirstCellV1.lean'),
        WORK / 'LibraryTransfer/Restored/source/AEGISOverlay/RHKreinFourierTaylorBoundV1.lean',
        WORK / 'LibraryTransfer/Restored/source/RHKreinFourierFactorV1.lean',
        WORK / 'LibraryTransfer/Restored/source/RHKreinFifteenthCellReductionV1.lean',
        WORK / 'LibraryTransfer/Restored/source/RHKreinFourteenthCellCompositionV1.lean',
        WORK / 'LibraryTransfer/SOURCE_PINS.json',
    ]
    write('RESULT.json', {
        'schema': 'aegis.k4.existing-proof-reuse-result.v1',
        'status': 'PASS_BOUNDED_REUSE_AND_APPLICABILITY_AUDIT',
        'concrete_typed_reuse_receipt': {'path': str(concrete_path), 'sha256': digest(concrete_path)},
        'independent_library_source_review': {
            'path': str(library_path), 'sha256': digest(library_path),
            'passed_checks': library['passed_checks'], 'total_checks': library['total_checks'],
            'fresh_kernel_execution': False,
        },
        'actual_premise_free_endpoints': concrete['axiom_reports'],
        'endpoint_object_sha256': concrete['object_sha256'],
        'source_sha256': concrete['source_sha256'],
        'lean_version': concrete['lean_version'],
        'lean_compiler_commit': concrete['lean_compiler_commit'],
        'mathlib_commit': concrete['mathlib_commit'],
        'new_arithmetic_derivation_performed': False,
        'reused_actual_k4_proof': 'AEGIS.RHKreinZeroJetInterpolationV1.actual_even_jet_four',
        'existing_k4_reused_in_actual_second_cell_composition': True,
        'four_individual_effective_compositions_bound': True,
        'source_objects_reused': True,
        'full_transitive_source_rebuild': False,
        'first_fourteen_recovered_complete_source_body': True,
        'first_fourteen_fresh_kernel_replay_claimed': False,
        'restored_direct_firstcell_k4_body_fresh_replay_claimed': False,
        'direct_midpoint_cell15_k4_status': 'NOT_LOCATED_IN_SEARCHED_SCOPE',
        'optional_cell15_next_coefficient_proposition':
            '|AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient (5025/65536) 4 '
            '- (51983766003/25000000000 : Real)| <= 1/1000000000000',
        'optional_target_not_a_claim_about_global_RH_frontier': True,
        'search_scope_manifest': {'path': str(HERE / 'SOURCE_SEARCH_SCOPE.json'),
                                  'sha256': digest(HERE / 'SOURCE_SEARCH_SCOPE.json')},
        'matching_source_paths': len(scope['matching_source_files']),
        'deduplicated_source_groups': len(scope['content_deduplicated_source_groups']),
        'source_read_bindings': {str(p): digest(p) for p in selected_sources},
        'original_supplied_zip_replay_performed': False,
        'all_cells_proven': False, 'rh_proven': False,
        'public_or_hosted_state_changed': False,
    })

    entries = []
    for path in sorted(HERE.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        if path.name == 'SOURCE_MANIFEST.json' or path.suffix in {'.olean', '.ilean', '.ir', '.pyc'}:
            continue
        if '__pycache__' in path.parts:
            continue
        entries.append({'path': str(path.relative_to(HERE)),
                        'sha256': digest(path), 'bytes': path.stat().st_size})
    write('SOURCE_MANIFEST.json', {
        'schema': 'aegis.k4.bounded-reuse.static-manifest.v1',
        'scope': str(HERE), 'entries': entries, 'file_count': len(entries),
        'excluded': ['self', 'symlinks', 'compiled objects', '__pycache__'],
        'rh_proven': False,
    })
    print(json.dumps({'status': 'FROZEN_BOUNDED_REUSE',
                      'result_sha256': digest(HERE / 'RESULT.json'),
                      'manifest_sha256': digest(HERE / 'SOURCE_MANIFEST.json'),
                      'application_records_sha256': digest(HERE / 'EXISTING_APPLICATION_REPLAY_RECORDS.json'),
                      'files': len(entries)}))


if __name__ == '__main__':
    main()
