# Independent review and replay of the public trig/sinc adapters

The unchanged source RHKreinTrig15Sinc6PublicOct7.lean passed an actual second
fresh scoped compilation and a separate pinned Lean checker. Its source hash
is 81b890155ef3f5f3f2e835df7cd56c4d5c7cd14b1df5218e1a5fdd4a4093eb1b.
This is a new generic adapter reconstruction from identified existing sources,
not a recovered export from the unidentified fifteenth-cell packet.

The exact normal forms are correct. expIPartial 16 includes powers zero through
15 of ix divided by factorials. Its real part has the eight alternating even
terms through degree 14; its imaginary part has the eight alternating odd
terms through degree 15. Thus cosPolynomial15 is the degree-at-most-15 Taylor
truncation, whose actual highest degree is 14. Division of the imaginary part
of expIPartial 8 by nonzero x gives the four even sinc terms through degree 6:

    1 - x²/6 + x⁴/120 - x⁶/5040.

All displayed integer denominators were independently compared with exact
factorials using Fraction arithmetic. No floating decision was used.

The existing arbitrary-order complex exponential theorem assumes n>0 and
|x|≤1, and gives norm error at most |x|^n (n+1)/(n! n). Projection to real and
imaginary parts preserves that bound. At n=16 the coefficient is exactly
17/(16!·16)=17/334764638208000. The new sine and cosine errors retain |x|≤1
explicitly; neither asserts this error estimate on arbitrary phases.

The sinc adapter applies the existing sine-error division theorem at n=8.
Its coefficient is exactly 9/(8!·8)=1/35840. The assumptions x>0 and |x|≤1
remain explicit and justify division without reversing the inequality. At
x=0 the displayed quotient expression would require separate handling; this
new theorem does not claim to cover that boundary. The algebraic normal-form
identity separately requires x≠0.

The actual imported indexed phase was inspected both in the public source and
by a new trust=0 definition/type probe. Lean prints:

    hatCenter : Fin 199 → Real := fun j => (j.val+41)/50.

The public correctionSymbol uses the angular phase t·hatCenter j. The new
hat-sine adapter uses exactly that existing definition with a generic real c
and retains |c·hatCenter j|≤1 as an argument. It neither invents a fifteenth
centre nor establishes the range condition for a missing centre. One Fin 199
theorem covers the indices without 199 repeated proofs. The sine bound alone
does not bound the whole correctionSymbol, its weighted sum, sinc prefactors,+spline contribution or an exact derivative coefficient; those require the
corresponding formula and arithmetic data.

The first replay receipt is bound to the requested SHA256
009f5ee1d3445974b0b49aa9afe35ea2aaaf6239347ad63591d830bf72e5205d.
The independent second execution created
scoped-replay-20261007T054804.722998Z/RECEIPT.json with SHA256
37c2c5e41303f89f24f5a1424bacbf447c0d47613bbf1664e4712e6e7f06bc79.
Both receipts record Lean 4.33.1, compiler
819816b2e0a3bf405af45ae5c7af2491d8f5bee6 and Mathlib
0df444a360eaa60ab8c11dca51a86af692955474. Both fresh compiles explicitly used
trust=0 and both separate pinned checker commands exited zero. Source,
compiler, selected imported-object and log bindings were recomputed after
execution. The fresh emitted object hashes match exactly:

    60e025615f9f0a56e6d9ef4810c052ba9f9d171bec4eba9aa6bbf962edcf637f.

All seven elaborated endpoint axiom reports contain only propext,
Classical.choice and Quot.sound. Their full types retain the stated phase and
division hypotheses, with no hidden certificate, cell interval or RH premise.
The additional definition/type probe also exited zero and its output is bound
separately.

The two replays used the same host and pinned engine, with identified cached
imports reused. There was no clean full-transitive source rebuild, independent
machine provisioning or final RH replay. The literal binding/rational audit
passes 90 checks over 44 bound files; this is provenance and exact arithmetic
checking in addition to the actual scoped kernel replay, not a replacement for
the analytic hypotheses.

No defect was found in these seven generic public endpoints. The user's actual
fifteenth-cell ZIP, formula, centre and interval remain unavailable in this
scope. No fifteenth-centre enclosure was proved, that cell-specific kernel
audit remains NOT_RUN, and RH remains unproved. The earlier IntegrationReview
files were not changed by this separate task.
