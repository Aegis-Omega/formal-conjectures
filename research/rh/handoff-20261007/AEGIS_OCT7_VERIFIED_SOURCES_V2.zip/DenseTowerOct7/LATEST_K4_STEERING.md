# Existing k=4 producers reused

This later addendum preserves the frozen earlier proof-state and graph bytes.
The current user pointed out that many k=4 modules already exist. They were
searched by their actual coefficient, centre, source body and consumers.

The exact existing zero-centre theorem was applied transparently, without
rederiving its interpolation arithmetic:

```lean
AEGIS.RHKreinExistingK4ReuseOct7.existing_zero_center_k4 :
  |AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient 0 4 -
    (2096414380799 / 1000000000000 : ℝ)| ≤
      (1 / 1000000000000 : ℝ)
```

Its body uses `RHKreinZeroJetInterpolationV1.actual_even_jet_four`. The same
adapter retains the existing zero-centre k=6 theorem with target
`-190744442117/10^12`. One fresh adapter compilation checked both endpoint
applications with explicit `--trust=0`; the pinned `leanchecker` passed and
both axiom lists contain only `propext`, `Classical.choice`, `Quot.sound`.
The actual receipt is
`K4ReuseOct7/ConcreteReuse/scoped-replay-20261007T063818.465049Z/RECEIPT.json`,
SHA256 `7e0a6bb707c49636f1cb3da8446720566b157b63e58a8b3aa7a9ecadb5b7e55a`.
Identified imported objects were reused; this is not a complete fresh
transitive source rebuild.

This is also actual integration work: the already-proved even-jet and
first-cell producers replace incompatible historical proof names in four
effective original Second/Third/Fourth/Fifth composition modules. Those four
modules compiled. Original bytes, public definitions and theorem statements
are preserved; explicit original/effective proof-body diffs and execution
receipts are under `Cell15Concrete/OriginalTargetIntegration/`.

The original fifteenth-cell reduction has a different k=4 premise:

```lean
|exactJetCoefficient (5025/65536) 4 -
  (51983766003 / 25000000000 : ℝ)| ≤ 1/1000000000000
```

The recovered midpoint reduction and generic cell producer consume this
premise. Centre-zero k=4 cannot be substituted for it. The bounded source
search, existing generic interpolation/Taylor mechanisms, and independent
review are recorded in `K4ReuseOct7/RESULT.json` and its manifest. Failure to
locate that shifted producer in those sources is not a claim that no such
proof exists elsewhere. All previously proved zero-centre endpoints remain
closed.

The actual fifteenth-cell k=1 coefficient is separately newly kernel-closed,
with an independent fresh scoped replay, in
`Cell15Concrete/AnalyticError/RHKreinCell15AnalyticErrorOct7.lean`.
Its genuine original-namespace wrapper still requires import-closure replay:
the next original gamma-bound source exceeded the recorded 4096MiB compiler
limit. This execution failure does not retract the new analytic endpoint.

No finite-cell-to-global implication was established. The completed 2199-cell
certificate would still have the audited support restriction `r ≤ 2/5`.
The selected main mathematical obligation remains the full
`DenseFixedPacketSign` for the same detecting packet, every signed-integer
log2/log3 shift and all four phases. No unconditional producer was obtained
in this session. `rh_proven=false`; no remote write or hosted run was made.
