# Recorded scoped replay audit

Status: PASS, with no defect found in the audited receipt/source bindings.
This review recomputed hashes and inspected recorded commands, outputs and
types. It did not execute Lean or LeanChecker again.

The validator checked 258 conditions across 81 bound files. Both butterfly
replay receipts and both K1 compatibility replay receipts record successful
pinned Lean 4.33.1 compilation with explicit `--trust=0`, followed by a
separate pinned `leanchecker -v` command with exit code zero. Raw logs match
their receipts. Bound compiler binaries, source snapshots, selected imported
objects and fresh output objects remain unchanged. The two executions of
each module emit identical source/object bytes and endpoint axiom lists.

The butterfly module audits six new algebraic identity theorems. Its
independent full-type audit prints each complete type and the same axiom
list. The printed types quantify over the actual packet, real shifts and
complex coefficients, with no positivity or RH input. The K1 module audits
three new compatibility declarations and the reused imported
`firstJet_one_exact`. All ten reported endpoint lists contain only
`propext`, `Classical.choice` and `Quot.sound`. No `sorryAx` appears.

The K1 source correctly reuses the recovered zero-centre coefficient. Its
two rejection declarations prove that the reported positive interval and
midpoint cannot apply to that zero-centre object. They do not identify the
unavailable v33 target, refute its mathematical formula, or audit its
claimed 349-source/ZIP replay. The v33 audit remains `NOT_RUN`.

The independent executions used separate agents on the same host and
pinned engine. Selected imported objects were identified and reused; the
full transitive source closure was not rebuilt. The receipts and independent
reviews state these limits. These are scoped auxiliary-module checks,
not an independent implementation, clean final RH build, global sign
producer, or completed RH proof.

Reproduction of this read-only audit:

```sh
cd /workspace/aegis-research/work
python3 DenseTowerOct7/IntegrationReview/ReplayValidation/audit_recorded_replays.py
```

The command writes only this review's JSON receipt. The underlying replay
scripts are separately bound evidence and were not invoked by this audit.
