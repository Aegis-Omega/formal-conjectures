#!/usr/bin/env python3
"""Read-only validation of recorded scoped executions; never invokes Lean."""
import datetime
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
STD = {'propext', 'Classical.choice', 'Quot.sound'}
PIN = '819816b2e0a3bf405af45ae5c7af2491d8f5bee6'
BIN = Path('/home/agent/.elan/toolchains/leanprover--lean4---v4.33.1/bin')
checks = []
bindings = {}

def bind(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    bindings[str(path)] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    return raw

def sha(path):
    return hashlib.sha256(bind(path)).hexdigest()

def check(name, truth, **extra):
    checks.append({'name': name, 'pass': bool(truth), **extra})

def load(path):
    return json.loads(bind(path))

def validate_inputs(tag, values):
    for path, expected in values.items():
        check(tag + ':input:' + path, sha(path) == expected)

def axiom_lists(log):
    return [{'theorem': m.group(1), 'axioms': [a.strip() for a in m.group(2).split(',') if a.strip()]}
            for m in re.finditer(r"'([^']+)' depends on axioms: \[([^\]]*)\]", log, re.S)]

def validate_jobs(folder, jobs, reports, tag):
    check(tag + ':three_recorded_commands', [j['name'] for j in jobs] == ['version', 'compile', 'leanchecker'])
    for job in jobs:
        check(tag + ':' + job['name'] + ':recorded_exit_zero', job['exit_code'] == 0)
        check(tag + ':' + job['name'] + ':elapsed_nonnegative', job['elapsed_seconds'] >= 0)
        for stream in ['stdout', 'stderr']:
            check(tag + ':' + job['name'] + ':' + stream + '_bound',
                  sha(folder / (job['name'] + '.' + stream + '.txt')) == job[stream + '_sha256'])
    compile_cmd = jobs[1]['command']
    check(tag + ':literal_trust_zero', '--trust=0' in compile_cmd)
    check(tag + ':pinned_compiler_path', compile_cmd[0] == str(BIN / 'lean'))
    check(tag + ':pinned_checker_path', jobs[2]['command'][0] == str(BIN / 'leanchecker'))
    check(tag + ':nonimplicit_compile', '-DautoImplicit=false' in compile_cmd)
    version = bind(folder / 'version.stdout.txt').decode()
    check(tag + ':recorded_version_pin', '4.33.1' in version and PIN in version)
    text = bind(folder / 'compile.stdout.txt').decode()
    actual = axiom_lists(text)
    check(tag + ':raw_axioms_match_receipt', actual == reports)
    check(tag + ':only_standard_axioms', all(set(x['axioms']) == STD for x in actual))
    check(tag + ':no_compile_warning_error', re.search(r'\b(?:error|warning):', text) is None)
    check(tag + ':no_sorryAx_log', 'sorryAx' not in text)

def validate_pair(kind, stamps, source, module, count):
    rows = []
    for stamp in stamps:
        folder = BASE / kind / ('scoped-replay-' + stamp)
        receipt = load(folder / 'RECEIPT.json')
        tag = kind + ':' + stamp
        if kind == 'Formal':
            pre = load(folder / 'PRESTART.json')
            check(tag + ':prestart_bound', sha(folder / 'PRESTART.json') == receipt['prestart_sha256'])
            validate_inputs(tag, pre['inputs'])
            check(tag + ':prestart_no_full_rebuild', pre['full_dependency_rebuild'] is False)
            check(tag + ':receipt_no_full_rebuild', receipt['full_dependency_rebuild'] is False)
            check(tag + ':status_pass', receipt['result']['status'] == 'PASS')
            check(tag + ':reported_inputs_unchanged', receipt['result']['inputs_unchanged'] is True)
            validate_jobs(folder, receipt['records'], receipt['result']['axiom_reports'], tag)
            check(tag + ':snapshot_bound', sha(folder / 'source' / source.name) == receipt['source_sha256'])
            check(tag + ':source_bound', sha(source) == receipt['source_sha256'])
            reports = receipt['result']['axiom_reports']
            inputs = pre['inputs']
        else:
            validate_inputs(tag, receipt['input_bindings'])
            check(tag + ':status_pass', receipt['status'] == 'PASS' and receipt['reason'] is None)
            validate_jobs(folder, receipt['jobs'], receipt['axiom_reports'], tag)
            check(tag + ':no_v33_authority', receipt['v33_available'] is False and receipt['v33_kernel_audit'] == 'NOT_RUN')
            reports = receipt['axiom_reports']
            inputs = receipt['input_bindings']
        check(tag + ':no_rh_authority', receipt['rh_proven'] is False)
        check(tag + ':expected_endpoint_count', len(reports) == count)
        obj = folder / 'lib' / (module + '.olean')
        check(tag + ':actual_fresh_object_bound', sha(obj) == receipt['fresh_object_sha256'])
        check(tag + ':same_current_source_snapshot', bind(source) == bind(folder / 'source' / source.name))
        check(tag + ':scope_admits_import_reuse', 'reused' in receipt['scope'])
        check(tag + ':scope_denies_clean_transitive_build', 'Not a clean full transitive build' in receipt['scope'] or 'not a clean transitive source build' in receipt['scope'])
        rows.append((folder, receipt, inputs, reports))
    check(kind + ':identical_fresh_objects', rows[0][1]['fresh_object_sha256'] == rows[1][1]['fresh_object_sha256'])
    common = set(rows[0][2]) & set(rows[1][2])
    check(kind + ':all_common_inputs_same_hash', all(rows[0][2][p] == rows[1][2][p] for p in common), count=len(common))
    check(kind + ':same_endpoint_reports', rows[0][3] == rows[1][3])
    return rows

def main():
    bind(Path(__file__))
    butterfly = validate_pair('Formal', ['20261007T050144.848816Z', '20261007T050235.915744Z'],
                               BASE / 'Formal/WeilTowerButterflyOct7.lean', 'WeilTowerButterflyOct7', 6)
    k1 = validate_pair('K1V33', ['20261007T052807.216296Z', '20261007T052918.634006Z'],
                      BASE / 'K1V33/K1TargetCompatibilityOct7.lean', 'K1TargetCompatibilityOct7', 4)
    reviewdir = BASE / 'Dashboard/FormalReview'
    review = load(reviewdir / 'INDEPENDENT_KERNEL_REPLAY_RECEIPT.json')
    check('butterfly_review:root_receipt_bound', sha(butterfly[0][0] / 'RECEIPT.json') == review['root_replay_receipt_sha256'])
    check('butterfly_review:second_receipt_bound', sha(butterfly[1][0] / 'RECEIPT.json') == review['actual_independent_replay_receipt_sha256'])
    check('butterfly_review:scope_same_host', 'same host and engine' in review['scope'])
    check('butterfly_review:no_full_build', review['full_dependency_rebuild'] is False and review['rh_proven'] is False)
    typeaudit = review['type_audit']
    check('type_audit:source_bound', sha(reviewdir / 'ButterflyFullTypeAudit.lean') == typeaudit['source_sha256'])
    check('type_audit:recorded_exit_zero', typeaudit['exit_code'] == 0)
    check('type_audit:trust_zero', '--trust=0' in typeaudit['command'])
    for stream in ['stdout', 'stderr']:
        check('type_audit:' + stream + '_bound', sha(reviewdir / ('full-type-audit.' + stream + '.txt')) == typeaudit[stream + '_sha256'])
    typelog = bind(reviewdir / 'full-type-audit.stdout.txt').decode()
    check('type_audit:all_six_printed_types', all(x['theorem'] + ' :' in typelog for x in butterfly[0][3]))
    check('type_audit:all_six_actual_axioms', axiom_lists(typelog) == butterfly[0][3])
    sourcereview = load(reviewdir / 'SOURCE_REVIEW_RECEIPT.json')
    for source in sourcereview['sources']:
        check('ordinary_algebra_review:source_bound:' + source['path'], sha(source['path']) == source['sha256'])
        check('ordinary_algebra_review:size_bound:' + source['path'], len(bind(source['path'])) == source['bytes'])
    check('ordinary_algebra_review:does_not_claim_execution', sourcereview['fresh_compiler_replay'] is False and sourcereview['fresh_axiom_audit'] is False)
    k1review = load(BASE / 'K1V33/IndependentReview/INDEPENDENT_SECOND_REPLAY_RECEIPT.json')
    validate_inputs('k1_independent_review', k1review['input_bindings'])
    check('k1_independent_review:all_recorded_checks_pass', all(c['pass'] for c in k1review['checks']))
    k1semantics = bind(BASE / 'K1V33/IndependentReview/INDEPENDENT_SEMANTIC_REVIEW.md').decode()
    check('k1_independent_review:same_host_scope', 'same host and engine' in k1semantics)
    check('k1_independent_review:does_not_claim_v33_or_rh',
          k1review['v33_identified'] is False and k1review['v33_kernel_audit'] == 'NOT_RUN' and k1review['rh_proven'] is False
          and k1review['independent_rh_replay'] is False and k1review['clean_transitive_source_build'] is False)
    check('k1_independent_review:correct_execution_paths',
          Path(k1review['first_actual_replay_receipt']) == k1[0][0] / 'RECEIPT.json'
          and Path(k1review['second_actual_replay_receipt']) == k1[1][0] / 'RECEIPT.json')
    limits = [
        'This is a read-only audit of recorded executions, not a new compiler/checker run.',
        'The two runs per module were executed by separate agents on the same host and pinned engine; no independent implementation or runner is claimed.',
        'Identified selected imported objects were reused. Full transitive source closure was not rebuilt.',
        'Six new butterfly identity endpoints and three new K1 compatibility endpoints were compiled; the fourth K1 axiom endpoint is the reused imported theorem.',
        'The K1 compatibility adapter only rejects identifying the reported positive interval with the recovered zero-centre coefficient. It does not falsify or audit the unidentified v33 artifact.',
        'No final RH theorem or global sign producer is supplied by these receipts.'
    ]
    receipt = {'schema': 'aegis.oct7.integration.recorded-replay-validation.v1',
               'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'reviewer_agent': '/root/integration_audit_oct7/replay_binding_audit',
               'status': 'PASS' if all(c['pass'] for c in checks) else 'FAIL',
               'checks': checks, 'source_bindings': bindings, 'scope_limits': limits,
               'fresh_compiler_execution': False, 'full_transitive_source_build': False,
               'v33_kernel_audit': 'NOT_RUN', 'rh_proven': False}
    path = HERE / 'REVIEW_RECEIPT.json'
    path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': receipt['status'], 'checks': len(checks), 'bound_files': len(bindings),
                      'failures': [c['name'] for c in checks if not c['pass']],
                      'receipt_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}))
    raise SystemExit(0 if receipt['status'] == 'PASS' else 1)

if __name__ == '__main__':
    main()
