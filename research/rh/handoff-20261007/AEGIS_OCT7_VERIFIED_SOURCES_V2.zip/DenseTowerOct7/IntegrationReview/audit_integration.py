"""Read-only binding and graph validation; not mathematical or kernel soundness."""
from __future__ import annotations

from collections import defaultdict, deque
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

WORK = Path('/workspace/aegis-research/work')
OUT = WORK / 'DenseTowerOct7/IntegrationReview'
CHECKS: list[dict] = []
BINDINGS: dict[str, dict] = {}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(name: str, ok: bool, **detail) -> None:
    CHECKS.append({'name': name, 'pass': bool(ok), **detail})


def bind(path: Path) -> None:
    label = str(path.relative_to(WORK)) if path.is_relative_to(WORK) else str(path)
    BINDINGS[label] = {'path': label, 'sha256': digest(path), 'bytes': path.stat().st_size}


def load(path: Path):
    bind(path)
    return json.loads(path.read_text())


def resolve(label: str, owner: Path) -> Path:
    p = Path(label)
    if p.is_absolute():
        return p
    if label.startswith(('DenseTowerOct7/', 'BreakthroughContinuationOct3B/',
                         'BreakthroughV4Oct3/')):
        return WORK / p
    return owner.parent / p


def validate_rows(owner: Path, rows: list[dict], context: str) -> None:
    for row in rows:
        label = row.get('snapshot', row.get('path'))
        expected = row.get('sha256')
        if not label or not expected:
            continue
        path = resolve(label, owner)
        exists = path.is_file()
        ok = exists and digest(path) == expected
        if 'bytes' in row:
            ok = ok and path.stat().st_size == row['bytes']
        check(context + ':' + label, ok, expected_sha256=expected,
              actual_sha256=digest(path) if exists else None)
        if exists:
            bind(path)


def main() -> int:
    old_path = WORK / 'BreakthroughContinuationOct3B/FinalPackage/RH_CAUSAL_DAG.json'
    dag_path = WORK / 'DenseTowerOct7/RH_CAUSAL_DAG.json'
    state_path = WORK / 'DenseTowerOct7/RH_PROOF_STATE.json'
    checkpoint_path = WORK / 'DenseTowerOct7/CONTINUATION_CHECKPOINT.md'
    old, dag, state = load(old_path), load(dag_path), load(state_path)
    bind(checkpoint_path)
    text = checkpoint_path.read_text()
    check('old_graph_hash', digest(old_path) == dag['base_graph_binding']['sha256'])
    check('old_59_nodes_preserved', len(old['nodes']) == 59 and
          all(n in dag['nodes'] for n in old['nodes']))
    check('old_57_proved_edges_preserved', len(old['proved_edges']) == 57 and
          all(e in dag['proved_edges'] for e in old['proved_edges']))
    ids = [n['id'] for n in dag['nodes']]
    node_ids = set(ids)
    check('unique_node_ids', len(node_ids) == len(ids))
    check('current_graph_counts', len(ids) == 71 and len(dag['proved_edges']) == 66)
    missing = {x for edge in dag['proved_edges']
               for x in edge['from_nodes'] + [edge['to_node']] if x not in node_ids}
    check('proved_edge_references_resolve', not missing, missing=sorted(missing))
    adjacency = defaultdict(set)
    indegree = {key: 0 for key in node_ids}
    for edge in dag['proved_edges']:
        for source in edge['from_nodes']:
            target = edge['to_node']
            if target not in adjacency[source]:
                adjacency[source].add(target)
                indegree[target] += 1
    queue = deque(key for key, value in indegree.items() if value == 0)
    order = []
    while queue:
        key = queue.popleft()
        order.append(key)
        for target in adjacency[key]:
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    check('proved_graph_acyclic', len(order) == len(node_ids), visited=len(order))
    old_nodes = {n['id'] for n in old['nodes']}
    for node in dag['nodes']:
        if node['id'] not in old_nodes:
            validate_rows(dag_path, node.get('source_bindings', []), 'new_dag_source')
    new_edges = [edge for edge in dag['proved_edges'] if edge not in old['proved_edges']]
    for result in ['ACTUAL_NARROW_MOMENT_INDETERMINACY_OCT7',
                   'BOUNDED_POSITIVE_ACTUAL_GERM_EXTENSIONS_OCT7']:
        edges = [e for e in new_edges if e['to_node'] == result]
        check(result + ':full_coercivity_dependency', len(edges) == 1 and
              'EXISTING_NINE64_COERCIVITY_OCT7' in edges[0]['from_nodes'] and
              'FULL_EXPLICIT_FORMULA' in edges[0]['from_nodes'])
    coercivity = WORK / 'DenseTowerOct7/LocalMoment/Sources/RHWindowNineOver64GlobalizationV14.lean'
    bind(coercivity)
    source = coercivity.read_text()
    check('actual_nine64_coercive_body_read',
          'theorem nine_over_64_coercive' in source and
          '(hw : HalfWidthAt g (9 / 64) a)' in source and
          '(hm : WeilMomentConditionsV1 g)' in source and
          '-(1 / 10) * energy g.1' in source and
          'momentGain_nine_over_64 (energy_nonnegative g.1)' in source)
    selected = state['open_obligations']
    check('single_full_dense_obligation', len(selected) == 1 and
          selected[0]['type'] == 'AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign' and
          selected[0]['same_packet'] == 'AEGIS.RHFixedPacketFrontierV1.detectingPacket' and
          'forall d in Zlog2+Zlog3' in selected[0]['quantifiers'] and
          'forall c in {1,-1,I,-I}' in selected[0]['quantifiers'] and
          'ALL signed integers' in selected[0]['scope'])
    check('dag_state_goal_identical', dag['single_selected_open_obligation'] == selected[0])
    check('no_unconditional_rh_producer_or_own_term', dag['rh_proven'] is False and
          state['rh_proven'] is False and dag['own_RH_theorem'] is None and
          dag['unconditional_edge_into_RH_component_found'] is False and
          all(e['to_node'] not in {'RH', 'PACKET_BOUND', 'FIXED_SIGN', 'DENSE_SIGN',
                                  'DENSE_FIXED_SIGN'} for e in dag['proved_edges']))
    formal = state['new_formal_results']
    check('scoped_kernel_scope_preserved', formal['full_transitive_source_rebuild'] is False and
          formal['identified_imported_objects_reused'] is True and
          formal['positivity_produced'] is False and len(formal['theorems']) == 6 and
          set(formal['axioms']) == {'propext', 'Classical.choice', 'Quot.sound'})
    k1 = state['latest_v33_steering']
    check('v33_source_and_audit_fail_closed', k1['v33_kernel_audit'] == 'NOT_RUN' and
          k1['reported_result_replayed_here'] is False and k1['rh_load_bearing'] is False)
    check('checkpoint_no_full_k1_import_rebinding_claim',
          'Its full imported transitive closure was identified/reused' not in text)
    manifests = [
        'SourceAudit/SOURCE_MANIFEST.json',
        'Recurrence/SOURCE_AND_REVIEW_RECEIPT.json',
        'NoFiniteRecurrence/SOURCE_MANIFEST.json',
        'LocalMoment/SOURCE_MANIFEST.json',
        'KreinGermSource/SOURCE_MANIFEST.json',
        'KreinGermReview/SOURCE_MANIFEST.json',
        'KreinGermReview/IdentityFalsifier/SOURCE_MANIFEST.json',
        'K1V33/SOURCE_MANIFEST.json',
        'Dashboard/EVIDENCE_INDEX.json',
    ]
    for label in manifests:
        path = WORK / 'DenseTowerOct7' / label
        manifest = load(path)
        for key in ['files', 'bindings', 'external_source_bindings',
                    'external_reused_source_bindings', 'records']:
            validate_rows(path, manifest.get(key, []), 'frozen_manifest')
    for label, expected in [
        ('CHECKPOINT.md', '3a333ea557a91bdc8f9724dc18e3d14b4d6561942a246f678b88e4467b2403ff'),
        ('aegis_compute.py', '08f2e0a21242a6762dd18989b83666ca12f1ddf802a88e12291c23f971618b17'),
    ]:
        path = WORK / label
        bind(path)
        check('inherited_immutable:' + label, digest(path) == expected)
    registry = dag.get('diagnostic_external_node_registry', {})
    registered = set(registry) if isinstance(registry, dict) else {n['id'] for n in registry}
    if isinstance(registry, list):
        check('diagnostic_registry_outside_proved_graph',
              all(n.get('part_of_proved_edges') is False and n['id'] not in node_ids
                  for n in registry))
        for node in registry:
            validate_rows(dag_path, [node['source_binding']] if 'source_binding' in node else [],
                          'diagnostic_registry_source')
        alias = next((n for n in registry if n['id'] == 'DENSE_FIXED_SIGN'), {})
        check('dense_diagnostic_alias_exact', alias.get('alias_of') == 'DENSE_SIGN' and
              alias.get('exact_proposition') == selected[0]['type'])
    external = {x for category in ['candidate_edges_and_falsifications',
                                  'conditional_interfaces_not_producers']
                for edge in dag[category] for x in edge['from_nodes'] + [edge['to_node']]
                if x not in node_ids}
    check('diagnostic_external_references_resolve', external <= registered,
          external_references=sorted(external), unregistered=sorted(external - registered))
    old_equivalence = WORK / 'BreakthroughContinuationOct3B/FinalPackage/RH_EQUIVALENCE_DAG.json'
    new_equivalence = WORK / 'DenseTowerOct7/RH_EQUIVALENCE_DAG.json'
    bind(old_equivalence)
    bind(new_equivalence)
    check('old_equivalence_dag_byte_identical',
          old_equivalence.read_bytes() == new_equivalence.read_bytes())
    failed = [row for row in CHECKS if not row['pass']]
    result = {
        'schema': 'aegis.oct7.integration-binding-audit.v1',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'reviewer': '/root/integration_audit_oct7',
        'status': 'PASS' if not failed else 'FAIL',
        'scope': 'Read-only integrated graph, literal frozen source bindings and trust-scope audit; no new mathematical proof or kernel execution.',
        'rh_proven': False,
        'full_transitive_source_build': False,
        'new_kernel_replay': False,
        'checks': CHECKS,
        'failures': failed,
        'source_bindings': list(BINDINGS.values()),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'BINDING_AUDIT_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': result['status'], 'checks': len(CHECKS),
                      'literal_bound_files': len(BINDINGS), 'failures': failed}, indent=2))
    return 0 if not failed else 1


if __name__ == '__main__':
    sys.exit(main())
