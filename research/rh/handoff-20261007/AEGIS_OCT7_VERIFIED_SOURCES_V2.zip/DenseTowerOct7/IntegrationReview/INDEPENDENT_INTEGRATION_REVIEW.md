# Independent integration audit — 7 October 2026

This audit checks the exact integrated source, graph references, frozen byte
bindings and stated verification scopes. It does not reconstruct the earlier
ordinary mathematical proofs again, execute a new Lean proof, or establish RH.
The separate replay-binding review checks recorded executions against their
actual source, object and log bytes; it does not rerun the compiler.

The audited root files are:

| File | SHA256 |
| --- | --- |
| RH_CAUSAL_DAG.json | 212db24378010f14ac94e1fb3f3a60e68e0b1fa13a00548e51bdfda52f3318af |
| RH_PROOF_STATE.json | 698a2c85b9ac7e3dd5079cec3ec9686711a7f84ff8d9edcd25e83c246eca85bb |
| CONTINUATION_CHECKPOINT.md | 678088e6104bb67e375c1f89ad111078b915c64c57f122ee79f4b6ceea806c86 |
| RH_EQUIVALENCE_DAG.json | 2642a3fa45996b05adcc0c7f6baa6cc227c873db3c185cafb45eb134902765af |

The inherited causal graph's 59 node values and 57 proved-edge values are
preserved exactly. The current graph has 71 unique proved-source nodes and
66 proved edges. Its proved references resolve and its dependency relation is
acyclic. Conditional interfaces and failed candidates remain outside the
proved-edge set. The equivalence graph is byte-identical to the previous
package; no new equivalence is attributed to this continuation.

Two concrete integration defects were found and corrected before this audit
was finalized:

1. Diagnostic external references lacked a registry, and the newly added
   butterfly candidate used DENSE_FIXED_SIGN whereas the retained interface
   used DENSE_SIGN. The root added a separate 15-entry diagnostic registry,
   with an explicit alias to the same exact DenseFixedPacketSign proposition.
   These entries remain outside the proved graph; none is a positivity producer.
2. The K1 checkpoint initially said its full imported transitive closure had
   been identified. Its receipt identifies selected imported objects and
   recorded import paths, rather than an exhaustive transitive object binding.
   The checkpoint now states that narrower scope explicitly.

The new local-moment and Krein-germ applications depend explicitly on the
actual nine_over_64_coercive source theorem, including its half-width and both
moment hypotheses, and on the full explicit formula. Its conclusion has the
required local factor 1/10 times the actual energy. Bare local nonnegativity
is not used as a substitute. This old theorem's proof body was read and reused;
no fresh full-transitive replay is claimed for it.

The six new butterfly declarations have a separate scoped status: the recorded
fresh trust=0 compilation, pinned checker and type/axiom audits concern those
identities. Only propext, Classical.choice and Quot.sound are reported. The
separate agent replay used the same host and pinned engine with identified
imports reused. Neither run is labeled an independently provisioned runner or
a clean full-transitive RH replay.

The ordinary new results preserve their reviewed scope: the generic pair-sign
falsifier is a model rather than actual zeta; the narrow detector is separately
constructed rather than identified with the opaque named detectingPacket;
the Krein extensions match the whole local germ but are not the full actual
kernel; the strict energy-floor falsifier retains semidefinite positivity and
window-dependent floors as possible. The reductio proofs do not retain RH as
an unconditional premise. Their mathematical content remains ordinary proof
and review, with Lean ports pending.

The user-reported v33 interval and 349-file/ZIP replay are not attributed to
this runner. The K1 adapter is expressly the old actual centre-zero coefficient
guard. It neither identifies nor rejects the unidentified v33 coefficient.
The actual v33 kernel audit remains NOT_RUN, and the API Library-access note
states its sampled Page-tool scope rather than an exhaustive file search.

There is exactly one selected RH mathematical obligation:

    AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign

It retains the same named detectingPacket, every signed integer log2/log3 shift,
all four phases, the original carrier and every prime-power, Gamma, pole and
zero-multiplicity term. The source graph contains no unconditional producer
of that premise or another RH-equivalent sign premise. RH flags are false,
the own final RH term is absent, and final clean-build/audit gates stay unmet.

The binding checker passes 312 graph and literal-byte checks over 241 distinct
bound files. Original CHECKPOINT.md and aegis_compute.py hashes are unchanged.
Digest validation is provenance checking, not mathematical soundness.

The separately delegated recorded-replay audit also passes: 258 checks across
81 source, log, object and compiler bindings, with no defect. It confirms four
actual recorded scoped compile/checker sequences, six new butterfly identities,
three K1 compatibility declarations and the reused K1 theorem's axiom report.
It performed no additional compiler execution.

This receipt covers the four root files at the hashes above and their frozen
bindings. A later separately generated PR53 lane steering/compatibility
addendum, later source changes, later commits or a future final package require
their own corresponding evidence; they are not silently covered by this audit.
