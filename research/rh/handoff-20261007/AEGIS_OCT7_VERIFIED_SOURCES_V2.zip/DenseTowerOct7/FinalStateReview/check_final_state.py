#!/usr/bin/env python3
"""Read-only final integration checks; no compile and no root-file writes."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import io
import contextlib
import json
import sys
import types

sys.dont_write_bytecode = True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
WORK=ROOT.parent
checks=[]; bindings={}

def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
    p=Path(p)
    if not p.is_absolute(): p=WORK/p
    b=p.read_bytes();bindings[str(p)]={'sha256':sha(b),'bytes':len(b)};return b
def data(rel):return json.loads(read(ROOT/rel))
def ck(name,p,detail=None):
    checks.append({'check':name,'passed':bool(p),'detail':detail})
    if not p:raise ValueError(name+': '+str(detail))

frozen={
 'RH_CAUSAL_DAG.json':'212db24378010f14ac94e1fb3f3a60e68e0b1fa13a00548e51bdfda52f3318af',
 'RH_PROOF_STATE.json':'698a2c85b9ac7e3dd5079cec3ec9686711a7f84ff8d9edcd25e83c246eca85bb',
 'CONTINUATION_CHECKPOINT.md':'678088e6104bb67e375c1f89ad111078b915c64c57f122ee79f4b6ceea806c86',
 'RH_EQUIVALENCE_DAG.json':'2642a3fa45996b05adcc0c7f6baa6cc227c873db3c185cafb45eb134902765af'}
for name,s in frozen.items():ck('frozen:'+name,sha(read(ROOT/name))==s)
old=data('RH_CAUSAL_DAG.json');g=data('RH_CAUSAL_DAG_FINAL.json')
oldstate=data('RH_PROOF_STATE.json');state=data('RH_PROOF_STATE_FINAL.json')
addendum=read(ROOT/'PR53_LANE_STEERING_ADDENDUM.md').decode()
driver=read(ROOT/'write_final_state.py').decode()
ck('graph_counts',len(old['nodes'])==71 and len(old['proved_edges'])==66 and len(g['nodes'])==76 and len(g['proved_edges'])==67)
ck('all_prior_node_and_edge_values_preserved',g['nodes'][:71]==old['nodes'] and g['proved_edges'][:66]==old['proved_edges'])
ck('other_prior_graph_values_preserved',all(g[k]==v for k,v in old.items() if k not in ['nodes','proved_edges']))
changed_state={'created_utc','latest_v33_steering'}
ck('prior_state_values_preserved',all(state[k]==v for k,v in oldstate.items() if k not in changed_state))
latest=state['latest_v33_steering'];prior_latest=oldstate['latest_v33_steering']
changed_latest={'analytic_target_identification','source_availability','minimal_missing_snapshot','v33_kernel_audit'}
ck('prior_v33_other_values_and_scope_reports_preserved',all(latest[k]==v for k,v in prior_latest.items() if k not in changed_latest) and latest['earlier_scope_preserved_in']['sha256']==frozen['RH_PROOF_STATE.json'])
ck('recovery_updates_target_availability_only',latest['source_availability']=='ORIGINAL_FORMULA_INPUTS_AND_155_READABLE_SOURCES_RECOVERED' and latest['analytic_target_identification']=='CANONICAL_CELL15_MIDPOINT_AND_K1_TYPE_RECOVERED' and not latest['reported_result_replayed_here'] and 'STRICT_ARCHIVE_INTERVAL_NOT_RUN' in latest['v33_kernel_audit'])
ck('one_exact_global_obligation_preserved',len(state['open_obligations'])==1 and state['open_obligations'][0]==g['single_selected_open_obligation']==old['single_selected_open_obligation'] and g['single_selected_open_obligation']['type']=='AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign')
ck('global_quantifiers',g['single_selected_open_obligation']['same_packet']=='AEGIS.RHFixedPacketFrontierV1.detectingPacket' and 'Zlog2+Zlog3' in g['single_selected_open_obligation']['quantifiers'] and '{1,-1,I,-I}' in g['single_selected_open_obligation']['quantifiers'] and 'ALL signed integers' in g['single_selected_open_obligation']['scope'])
ids=[n['id'] for n in g['nodes']]
ck('node_ids_unique',len(ids)==len(set(ids)))
newids={n['id'] for n in g['nodes'][71:]}
expected={'PR53_FIRST_CELL_SCOPED_OCT7','CELL15_DERIVATIVE_OCT7','CELL15_SCALAR_OCT7','CELL15_ANALYTIC_ERROR_OCT7','CELL15_K1_OCT7'}
ck('new_node_set',newids==expected and all(n['necessary_for_RH'] is False for n in g['nodes'][71:]))
edge=g['proved_edges'][-1]
ck('one_local_composition_edge',edge['from_nodes']==['CELL15_DERIVATIVE_OCT7','CELL15_SCALAR_OCT7','CELL15_ANALYTIC_ERROR_OCT7'] and edge['to_node']=='CELL15_K1_OCT7' and edge['full_transitive_source_rebuild'] is False)
adj={i:[] for i in ids}
for e in g['proved_edges']:
    for f in e['from_nodes']:
        if f not in adj:adj[f]=[]
        adj[f].append(e['to_node'])
visited=set();active=set()
def walk(n):
    if n in active:raise ValueError('cycle at '+n)
    if n in visited:return
    active.add(n)
    for to in adj.get(n,[]):walk(to)
    active.remove(n);visited.add(n)
for n in adj:walk(n)
ck('graph_is_acyclic',len(active)==0)
reached=set(newids);todo=list(newids)
while todo:
    for v in adj.get(todo.pop(),[]):
        if v not in reached:reached.add(v);todo.append(v)
ck('no_path_from_new_finite_nodes_to_any_old_node',reached<=newids and not (reached & set(ids[:71])))
ck('all_RH_gates_remain_false',not state['rh_proven'] and not state['RH_EXACT_TARGET_PROVED'] and state['final_theorem'] is None and not g['rh_proven'] and not g['unconditional_edge_into_RH_component_found'])

# Check every content binding reachable from the final documents. No reruns.
seen=set()
def bound(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
            pair=(value['path'],value['sha256'])
            if pair not in seen:
                seen.add(pair);ck('binding:'+value['path'],sha(read(value['path']))==value['sha256'])
        for v in value.values():bound(v)
    elif isinstance(value,list):
        for v in value:bound(v)
bound(state)
# Prior graph records contain historical origin paths as well as snapshot paths.
# Their values are preserved above; only the new graph objects are re-audited here.
bound(g['nodes'][71:]);bound(g['proved_edges'][66:]);bound(g['earlier_immutable_snapshot'])

c=state['cell15_k1'];allowed={'propext','Classical.choice','Quot.sound'}
endpoint='AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure'
errorendpoint='AEGIS.RHKreinCell15AnalyticErrorOct7.correctionFirstFormula_surrogate_error'
ck('coefficient_exact_type_and_no_explicit_hypotheses',c['theorem']==endpoint and c['exact_type']=='|exactJetCoefficient (5025/65536) 1 -347860160497/10^12| <=1/10^12' and c['explicit_hypotheses']==[] and set(c['axioms'])==allowed)
ck('coefficient_scope_limits',c['same_host_independent_agent'] and c['identified_imported_objects_reused'] and not c['full_transitive_source_rebuild'] and not c['whole_cell_proved'] and not c['all_cells_proved'] and not c['RH_globalization_producer'] and not c['strict_reported_fine_interval_kernel_proved'] and c['strict_reported_fine_interval_ordinary_proof_reviewed'])
source=read(c['source']['path']);object_paths=[];receipts=[]
for label in ['parent_replay','independent_replay']:
    path=WORK/c[label]['path'];r=json.loads(read(path));receipts.append(r)
    ck(label+':actual_audit_PASS',r['status']=='PASS' and r['cell15_k1_enclosure_kernel_audit']=='PASS' and r['cell15_whole_cell_soundness_kernel_audit']=='NOT_RUN' and not r['rh_proven'])
    ck(label+':pins',r['lean_version']=='4.33.1' and r['mathlib_commit']=='0df444a360eaa60ab8c11dca51a86af692955474' and r['lean_compiler_commit']=='819816b2e0a3bf405af45ae5c7af2491d8f5bee6')
    reports={a['theorem']:a for a in r['axiom_reports']}
    ck(label+':axioms',endpoint in reports and errorendpoint in reports and all(set(a['axioms'])<=allowed for a in r['axiom_reports']))
    ck(label+':source_receipt_binding',r['input_bindings'][str((WORK/c['source']['path']).resolve())]==sha(source) and read(path.parent/'source/RHKreinCell15AnalyticErrorOct7.lean')==source)
    for p,s in r['input_bindings'].items():ck(label+':import_input:'+p,sha(read(p))==s)
    for job in r['jobs']:
        ck(label+':job_exit:'+job['name'],job['exit_code']==0)
        for stream in ['stdout','stderr']:
            ck(label+':job_stream:'+job['name']+':'+stream,sha(read(path.parent/(job['name']+'.'+stream+'.txt')))==job[stream+'_sha256'])
    comp=[j for j in r['jobs'] if j['name']=='compile'];checker=[j for j in r['jobs'] if j['name']=='leanchecker']
    ck(label+':trust0_and_checker',len(comp)==len(checker)==1 and '--trust=0' in comp[0]['command'] and 'RHKreinCell15AnalyticErrorOct7' in checker[0]['command'])
    text=read(path.parent/'compile.stdout.txt').decode()
    ck(label+':actual_elaborated_endpoint_type',endpoint+' :' in text and 'AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient' in text and 'AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter 1' in text and '347860160497 / 10 ^ 12' in text)
    objpath=path.parent/'lib/RHKreinCell15AnalyticErrorOct7.olean';object_paths.append(objpath)
    ck(label+':current_object',sha(read(objpath))==r['fresh_object_sha256'])
ck('two_object_hashes_preserved',c['raw_object_sha256s']==[r['fresh_object_sha256'] for r in receipts] and not c['raw_objects_identical'])
byteaudit=json.loads(read(c['object_difference_audit']['path']))
a,b=[read(p) for p in object_paths]
offsets=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
ck('raw_byte_difference_scope',len(a)==len(b)==424608 and offsets==byteaudit['differing_offsets'] and len(offsets)==byteaudit['differing_byte_count']==5 and not byteaudit['raw_objects_byte_identical'])
srcpaths=[str(p.parent.parent/'source/RHKreinCell15AnalyticErrorOct7.lean').encode() for p in object_paths]
ck('only_embedded_path_differs',a.count(srcpaths[0])==b.count(srcpaths[1])==1 and a.replace(srcpaths[0],b'SOURCE_PATH')==b.replace(srcpaths[1],b'SOURCE_PATH'))
recovery=state['original_library_source_recovery']
ck('recovery_scope',recovery['key_text_files_recovered']==14 and recovery['readable_chunks_recovered']==11 and recovery['modules_restored_with_SHA256_and_Git_blob']==155 and not recovery['archive_bytes_downloaded'] and not recovery['full_546_archive_manifest_replayed'] and not recovery['full_349_v33_manifest_replayed'] and not recovery['all_155_sources_kernel_rebuilt'] and recovery['original_assert_guard_optimization_defect_verified'] and recovery['original_wide_interval_does_not_prove_fine_reference'])
ck('addendum_fine_vs_coarse_and_scope',all(s in addendum for s in ['347860160497147719465207/10^24','347860160497147766628587/10^24','This narrower generated interval is NOT claimed','not a fresh','full155-module/Mathlib closure rebuild','Raw ZIP bytes','single main research','same named','every signed-integer log2/log3 shift','every one of four phases']))

# Adversarially execute generator validation without permitting any root writes.
spec=importlib.util.spec_from_file_location('final_state_driver',ROOT/'write_final_state.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
parent_text=(WORK/c['parent_replay']['path']).read_text();writes=[]
module.write=lambda name,value:writes.append((name,value))
mutations={
 'truthy_NOT_RUN':lambda r:r.update(cell15_k1_enclosure_kernel_audit='NOT_RUN'),
 'empty_endpoint_audit':lambda r:r.update(cell15_k1_enclosure_kernel_audit=''),
 'missing_final_axiom_report':lambda r:r.update(axiom_reports=[a for a in r['axiom_reports'] if a['theorem']!=endpoint]),
 'unexpected_axiom':lambda r:r['axiom_reports'][0]['axioms'].append('sorryAx'),
 'source_mismatch':lambda r:r['input_bindings'].update({str((WORK/c['source']['path']).resolve()):'0'*64}),
 'object_mismatch':lambda r:r.update(fresh_object_sha256='0'*64),
 'missing_trust0':lambda r:next(j for j in r['jobs'] if j['name']=='compile')['command'].remove('--trust=0'),
 'missing_checker':lambda r:r.update(jobs=[j for j in r['jobs'] if j['name']!='leanchecker']),
 'nonzero_job':lambda r:r['jobs'][0].update(exit_code=1)}
negative_results=[]
for name,mutation in mutations.items():
    writes.clear()
    def loads(text,mutate=mutation):
        r=json.loads(text)
        if text==parent_text:mutate(r)
        return r
    module.json=types.SimpleNamespace(loads=loads,dumps=json.dumps)
    try:
        with contextlib.redirect_stdout(io.StringIO()):module.main()
    except ValueError as error:negative_results.append({'case':name,'rejected':True,'reason':str(error),'writes':len(writes)})
    else:raise ValueError('generator accepted '+name)
    ck('generator_fail_closed:'+name,len(writes)==0)
module.json=json;writes.clear()
with contextlib.redirect_stdout(io.StringIO()):module.main()
ck('valid_generator_reproduces_current_graph_without_root_writes',len(writes)==2 and writes[1][0]=='RH_CAUSAL_DAG_FINAL.json' and writes[1][1]==g)
captured=copy.deepcopy(writes[0][1]);captured.pop('created_utc');current=copy.deepcopy(state);current.pop('created_utc')
ck('valid_generator_reproduces_current_state_without_root_writes',captured==current)
for name,s in frozen.items():ck('frozen_after_validation:'+name,sha(read(ROOT/name))==s)
report={'schema':'aegis.oct7.final-state.independent-consistency.v1','status':'PASS','checks':checks,'check_count':len(checks),'source_bindings':bindings,'graph_nodes':76,'proved_edges':67,'prior_nodes_preserved':71,'prior_edges_preserved':66,'generator_negative_cases':negative_results,'corrected_defect':'Original generator tested a nonempty audit string for truthiness. Root changed this to exact PASS plus exact named axiom reports, source/object binding and unique trust0/checker jobs. Existing real kernel receipts were valid throughout.','fresh_kernel_replay_by_this_review':False,'root_files_written_by_this_review':False,'original_namespace_build_status':'Handled separately by cell15 parent; not asserted by this final-state consistency review','rh_proven':False}
(HERE/'AUDIT_RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'source_bindings':len(bindings),'generator_negative_cases':len(negative_results),'nodes':76,'edges':67,'rh_proven':False}))
