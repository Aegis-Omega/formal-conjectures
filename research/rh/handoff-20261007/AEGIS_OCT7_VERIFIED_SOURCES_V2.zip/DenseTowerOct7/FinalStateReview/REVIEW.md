# Final-state consistency review

The reviewed `RH_CAUSAL_DAG_FINAL.json`, `RH_PROOF_STATE_FINAL.json`, generator and later steering addendum are consistent with their bound local evidence. This is a static integration review with intercepted generator validation, not a new kernel replay or rederivation of the earlier mathematics.

The four earlier audited root snapshots retain their exact frozen hashes. The final graph has 76 nodes and 67 proved edges. Every original 71-node/66-edge value, and every other prior graph field, is preserved. The five new nodes describe the public first serialized cell and the cell15 derivative, scalar, analytic error and K1 results. Their only new edge composes the three cell15 ingredients into the local coefficient enclosure. No new finite-result node reaches any earlier node, DenseFixedPacketSign or RH; the entire proved graph remains acyclic.

The actual cell15 endpoint is premise-free:

```text
AEGIS.RHKreinCell15AnalyticErrorOct7.fifteenthCenter_k1_enclosure :
  |AEGIS.RHKreinM8AnalyticV1.exactJetCoefficient
      AEGIS.RHKreinCell15PhasesOct7.fifteenthCenter 1
    - 347860160497 / 10^12| ≤ 1 / 10^12
```

The phase definition identifies this centre as `5025/65536`. Both recorded executions have explicit `--trust=0`, successful fresh compile and kernel-checker jobs, matching current source/import/object digests, and the exact named endpoint and analytic-error axiom reports. Their only reported axioms are `propext`, `Classical.choice`, `Quot.sound`. The two raw OLEANs are not identical: all five differing bytes are characters of one embedded absolute source pathname. Replacing that pathname for comparison makes their complete byte sequences equal; neither object is changed. These are independent-agent runs on the same host with identified imported objects, not a complete source rebuild of the 155 transferred modules and Mathlib.

The reviewed state preserves the scalar bound about the fine centre `347860160497148/10^15` with radius `10^-14`, analytic error `10^-13`, and resulting coarse-centre kernel enclosure with radius `10^-12`. The tighter strict ordinary interval

```text
(347860160497147719465207,
 347860160497147766628587)/10^24
```

remains ordinary reviewed evidence. It is not attributed to the coarser Lean endpoint. The original wider rational replay does not prove the reported fine reference interval; the optimized assertion-guard defect remains explicit.

The later source recovery records 14 key text files, 11 readable chunks and all 155 source modules matching SHA256 and Git blobs. Archive bytes, the 546-file manifest, the earlier 349-file v33 archive check and a 155-module fresh kernel rebuild remain unexecuted in this recovery. The earlier source-search UNKNOWN/NOT_LOCATED findings retain their historical reports and frozen snapshot; the later identified centre/source is added without rewriting that history. The earlier zero-centre K1 guard remains a separate old-target replay.

The single selected main mathematical obligation is still

```text
AEGIS.RHFixedPacketDenseShiftV1.DenseFixedPacketSign
```

for the same named detecting packet, every signed-integer `Zlog2+Zlog3` shift and every phase `{1,-1,I,-I}`, retaining the full prime-power, Gamma, pole and multiplicity conventions. No unconditional producer was added. The cell15 original-namespace compatibility build is a separate task and is not claimed by this review. All RH success fields remain false.

One generator validation defect was found and corrected before this binding: a truthiness check would accept the nonempty string `NOT_RUN`. The generator now requires exact `PASS`, both exact endpoint axiom reports, matching source and object hashes, unique compile/checker jobs, explicit trust zero and successful exits. The two real receipts were valid throughout; this was a metadata validation defect, not an invalid proof. Nine controlled malformed-receipt variants were rejected by the actual corrected generator before any write. A valid dry run with writes intercepted reproduced the current graph exactly and current state except its expected timestamp.

The final audit passes 189 checks against 97 file bindings. Historical graph-origin paths are preserved as values rather than incorrectly resolved against the new graph's directory; earlier proof/source audits remain frozen. No root file, earlier receipt, or proof source was modified by this reviewer.
