from pathlib import Path, PurePosixPath
import datetime
import hashlib
import io
import json
import shutil
import stat
import subprocess
import sys
import zipfile

OUT = Path(__file__).resolve().parent
SOURCE = OUT / 'Incoming/AEGIS_V7_V12_TRANSFER_FALSIFIER_V2'
REPLAY = OUT / 'AnalysisReplay'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check_zip(content, depth=0):
    if depth > 4:
        raise RuntimeError('Unexpected nested archive depth')
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        infos = z.infolist()
        if len({x.filename for x in infos}) != len(infos):
            raise RuntimeError('Duplicate nested member')
        if sum(x.file_size for x in infos) > 32 * 1024 * 1024:
            raise RuntimeError('Nested expansion limit')
        if z.testzip() is not None:
            raise RuntimeError('Nested CRC failure')
        for i in infos:
            p = PurePosixPath(i.filename)
            if p.is_absolute() or '..' in p.parts or stat.S_ISLNK(i.external_attr >> 16):
                raise RuntimeError('Unsafe nested ZIP')
            if i.filename.endswith('.zip'):
                check_zip(z.read(i), depth + 1)


rows = []
for line in (SOURCE / 'SHA256SUMS.txt').read_text().splitlines():
    digest, rel = line.split('  ', 1)
    p = SOURCE / rel
    if sha(p) != digest:
        raise RuntimeError('Packaged hash mismatch ' + rel)
    rows.append(rel)
inventory = {p.relative_to(SOURCE).as_posix() for p in SOURCE.rglob('*') if p.is_file()}
if set(rows) != inventory - {'SHA256SUMS.txt'} or len(rows) != len(set(rows)):
    raise RuntimeError('Packaged manifest scope incomplete')
for p in sorted((SOURCE / 'source').glob('*.zip')):
    check_zip(p.read_bytes())

if REPLAY.exists():
    raise RuntimeError('No overwrite of earlier replay')
shutil.copytree(SOURCE, REPLAY, ignore=shutil.ignore_patterns('stable', 'transfer_audit_v2'))
logdir = OUT / 'ExecutionLogs'
logdir.mkdir(exist_ok=False)
commands = []


def run(label, args, cwd, expected_exit=0):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True, timeout=60)
    (logdir / (label + '.stdout')).write_text(result.stdout)
    (logdir / (label + '.stderr')).write_text(result.stderr)
    if result.returncode != expected_exit:
        raise RuntimeError(label + ' unexpected exit: ' + result.stderr)
    commands.append({'label': label, 'argv': args, 'cwd': str(cwd),
                     'exit_code': result.returncode,
                     'stdout_sha256': sha(logdir / (label + '.stdout')),
                     'stderr_sha256': sha(logdir / (label + '.stderr'))})


# The shipped README's first command really fails closed: stable is present.
run('packaged_prepare_guard', [sys.executable, 'analysis/prepare_sources.py'], SOURCE, 1)
if 'STABLE_TREE_EXISTS_NO_SILENT_OVERWRITE' not in (logdir / 'packaged_prepare_guard.stderr').read_text():
    raise RuntimeError('Unexpected package preparation failure')
run('prepare_fresh', [sys.executable, 'analysis/prepare_sources.py'], REPLAY)
run('analyze', [sys.executable, 'analysis/analyze_v7_v12_transfer_v2.py'], REPLAY)
for name in ['transfer_falsifier_v2.json', 'cluster_metrics.csv']:
    if (REPLAY / 'transfer_audit_v2' / name).read_bytes() != (SOURCE / 'transfer_audit_v2' / name).read_bytes():
        raise RuntimeError('Fresh analysis differs from source ' + name)
run('verify_normal', [sys.executable, 'analysis/verify_transfer_v2.py'], REPLAY)
normal = (REPLAY / 'transfer_audit_v2/independent_check_v2.json').read_bytes()
run('verify_optimized', [sys.executable, '-O', 'analysis/verify_transfer_v2.py'], REPLAY)
if (REPLAY / 'transfer_audit_v2/independent_check_v2.json').read_bytes() != normal:
    raise RuntimeError('Optimized checker changed report')
if normal != (SOURCE / 'transfer_audit_v2/independent_check_v2.json').read_bytes():
    raise RuntimeError('Checker report differs from saved source')

comparisons = []
for p in sorted((SOURCE / 'run_v12_20261007/contexts').glob('*.json')):
    comparisons.append({'kind': 'saved_context', 'path': p.name,
                        'byte_identical': p.read_bytes() == (REPLAY / 'stable/v12_canonical/contexts' / p.name).read_bytes()})
for p in sorted((SOURCE / 'run_v12_20261007/outcomes').glob('*.json')):
    comparisons.append({'kind': 'saved_outcome', 'path': p.name,
                        'byte_identical': p.read_bytes() == (REPLAY / 'stable/v12_canonical' / p.name).read_bytes()})
if len(comparisons) != 156 or not all(r['byte_identical'] for r in comparisons):
    raise RuntimeError('Saved replay does not match canonical sources')

# demand(...) is explicit under -O; a false replay count must not pass.
bad = OUT / 'NegativeCountReplay'
shutil.copytree(REPLAY, bad)
bad_receipt = bad / 'run_v12_20261007/CURRENT_FRESH_REPLAY_RECEIPT.json'
j = json.loads(bad_receipt.read_text())
j['comparisons']['mixed_contexts_byte_identical'] = 143
bad_receipt.write_text(json.dumps(j))
for mode in [[], ['-O']]:
    label = 'negative_count_optimized' if mode else 'negative_count_normal'
    run(label, [sys.executable, *mode, 'analysis/verify_transfer_v2.py'], bad, 1)
    if 'AssertionError: mixed replay' not in (logdir / (label + '.stderr')).read_text():
        raise RuntimeError('Wrong rejection')

# All delivered bytes are preserved; execution outputs are in separate folders.
for line in (SOURCE / 'SHA256SUMS.txt').read_text().splitlines():
    digest, rel = line.split('  ', 1)
    if sha(SOURCE / rel) != digest:
        raise RuntimeError('Incoming bytes changed ' + rel)

audit = json.loads((REPLAY / 'transfer_audit_v2/transfer_falsifier_v2.json').read_text())
result = {'schema': 'AEGIS_V7_V12_CURRENT_PACKAGED_ANALYSIS_REPLAY_V1',
    'executed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'zip_sha256': 'a228858479c0eadeee457a9e8f5d831beaf0273b2292e2125888147717faa34d',
    'source_directory': str(SOURCE), 'replay_directory': str(REPLAY),
    'bound_source_hashes_checked': len(rows), 'zip_safety_and_crc': 'PASS',
    'commands': commands,
    'full_analysis_byte_identical': True,
    'independent_checker_normal_and_optimized_byte_identical': True,
    'saved_contexts_compared': 144, 'saved_outcomes_compared': 12,
    'saved_snapshot_comparisons': comparisons,
    'malformed_count_rejected_normal_and_optimized': True,
    'README_first_command_on_shipped_tree': 'REJECTED_STABLE_EXISTS',
    'fresh_no_overwrite_workflow': 'PASS_WITHOUT_EDITING_INCOMING_SOURCE',
    'decision': audit['decision'], 'numerical_results': {
        'V12': audit['V12']['result'], 'V7': audit['V7']['result']},
    'current_full_288_simulation_executed': False,
    'physical_hardware_or_QPU_executed': False,
    'Lean_or_kernel_replay': 'NOT_RUN_NO_LEAN_SOURCE_IN_PACKET',
    'RH_object_identification': 'NONE_IN_INSPECTED_PACKET',
    'rh_proven': False,
    'scope': 'Fresh standard-library data analysis and source/saved-byte replay; packaged expensive simulation not rerun, numerical error not rigorously bounded, no RH causal edge.'}
receipt = OUT / 'CURRENT_ANALYSIS_REPLAY_RECEIPT.json'
receipt.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'receipt': str(receipt), 'receipt_sha256': sha(receipt),
                  'source_hash_count': len(rows), 'decision': audit['decision'],
                  'saved_byte_comparisons': len(comparisons), 'analysis_replay': 'PASS',
                  'full_simulation_rerun': False, 'rh_proven': False}))
