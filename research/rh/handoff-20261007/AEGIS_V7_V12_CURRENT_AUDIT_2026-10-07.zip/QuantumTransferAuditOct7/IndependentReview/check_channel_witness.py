#!/usr/bin/env python3
"""Stdlib-only exact rational matrix examples, not a bath/QPU/Lean replay."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json


def z(a=0, b=0): return F(a), F(b)
def add(a, b): return a[0]+b[0], a[1]+b[1]
def neg(a): return -a[0], -a[1]
def mul(a, b): return a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0]
def conj(a): return a[0], -a[1]
def zero(): return [[z() for _ in range(4)] for _ in range(4)]
def plus(a, b): return [[add(a[i][j], b[i][j]) for j in range(4)] for i in range(4)]
def scale(c, a): return [[mul(z(c), x) for x in row] for row in a]
def product(a, b):
    return [[sumz(mul(a[i][k], b[k][j]) for k in range(4))
             for j in range(4)] for i in range(4)]
def sumz(values):
    answer = z()
    for v in values: answer = add(answer, v)
    return answer
def trace(a): return sumz(a[i][i] for i in range(4))
def adjoint(a): return [[conj(a[j][i]) for j in range(4)] for i in range(4)]
def outer(v): return [[mul(v[i], conj(v[j])) for j in range(4)] for i in range(4)]
def fmatrix(j):
    a = zero(); a[0][j] = z(0, 1); a[j][0] = z(0, -1)
    return a
def demand(ok, label):
    if ok is not True: raise ValueError(label)


def run():
    checks=[]
    def check(ok,label):
        demand(ok,label)
        checks.append({'name':label,'status':'PASS'})
    identity=zero()
    for k in range(4): identity[k][k]=z(1)
    d=scale(F(1,4),identity)
    f1=fmatrix(1);f2=fmatrix(2)
    b=zero();b[0][0]=z(1);b[1][1]=z(-1)
    epsilon=F(1,8)
    check(trace(b)==z(),'perturbation output is traceless')
    check(F(1,4)-epsilon==F(1,8),'strict Choi positive lower bound')
    check(2*epsilon==F(1,4),'exact diamond distance constant')
    real_probes=[]
    for k in range(4):
        v=[z() for _ in range(4)];v[k]=z(1);real_probes.append(outer(v))
    real_probes.append(scale(F(1,2),outer([z(1),z(),z(),z(1)])))
    real_probes.append(scale(F(1,2),outer([z(),z(1),z(1),z()])))
    real_probes.append(scale(F(1,4),outer([z(1),z(1),z(1),z(1)])))
    check(len(real_probes)==7,'all seven source-defined real probes included')
    for idx,rho in enumerate(real_probes):
        check(trace(rho)==z(1),'real probe unit trace '+str(idx))
        check(trace(product(f1,rho))==z() and trace(product(f2,rho))==z(),
              'imaginary coherence blindness of source real probe '+str(idx))
    # Rational mixed-state example is an illustration, not actual mixed_seed_41.
    sigma=plus(d,plus(scale(F(3,40),f1),scale(F(1,10),f2)))
    s1=trace(product(f1,sigma));s2=trace(product(f2,sigma))
    check(s1==z(F(3,20)) and s2==z(F(1,5)),
          'exact mixed witness pairings')
    check(F(3,40)**2+F(1,10)**2==F(1,8)**2,
          'mixed witness perturbation norm gives positive density')
    a=plus(scale(F(4,5),f1),scale(-F(3,5),f2))
    check(trace(a)==z() and adjoint(a)==a,'nonzero branch Hermitian traceless')
    check(product(product(a,a),a)==a and trace(product(a,a))==z(2),
          'normalized blind observable eigenvalues plus/minus one and zeros')
    check(trace(product(a,sigma))==z(),'source-specific mixed cancellation')
    for idx,rho in enumerate(real_probes+[sigma]):
        check(trace(product(a,rho))==z(),'both channels equal on all eight probes '+str(idx))
    # Exact eigenstate: normalize the rational outer product by 1/2.
    eigen=scale(F(1,2),outer([z(1),z(0,-F(4,5)),z(0,F(3,5)),z()]))
    check(trace(eigen)==z(1),'detecting eigenstate unit trace')
    check(product(a,eigen)==eigen,'detecting eigenstate has eigenvalue one')
    check(trace(product(a,eigen))==z(1),'nonprobe channel trace distance epsilon')
    check(trace(product(f1,d))==z() and trace(product(f2,d))==z(),
          'zero-pairing branch mixed state')
    check(product(product(f1,f1),f1)==f1 and trace(product(f1,f1))==z(2),
          'zero-pairing branch normalized observable')
    k=[[F(1),F(0),F(1)],[F(0),F(1),F(1)],[F(1),F(1),F(1)]]
    v=(F(1),F(1),F(-1))
    check(sum(v[i]*k[i][j]*v[j] for i in range(3) for j in range(3))==-1,
          'pair-deleted positive Gram matrix gives negative quadratic value')
    negatives=0
    for action in (lambda:demand(False,'deliberate false comparison'),
                   lambda:demand(trace(product(a,eigen))==z(),'false probe completeness'),
                   lambda:demand(sum(v[i]*k[i][j]*v[j] for i in range(3) for j in range(3))>=0,'false pair deletion PSD')):
        try: action()
        except ValueError: negatives+=1
        else: raise ValueError('false claim was accepted')
    check(negatives==3,'all three false claims rejected under normal and optimized Python')
    path=Path(__file__).resolve();paper=path.parent/'MODEL_AND_CHANNEL_AUDIT.md'
    return {'schema':'AEGIS_SOURCE_PROBE_CHANNEL_EXACT_WITNESS_V1',
            'status':'PASS_EXACT_FINITE_MATRIX_EXAMPLES_ONLY',
            'checks':checks,'check_count':len(checks),'negative_guard_count':negatives,
            'source_bindings':{'checker_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                               'manuscript_sha256':hashlib.sha256(paper.read_bytes()).hexdigest()},
            'quantum_worker_executed':False,'actual_random_mixed_seed_recomputed':False,
            'scope':'Rational examples in both branches and scalar constants only; general CPTP/diamond theorem is an ordinary written proof. No actual simulated bath-channel falsifier.',
            'kernel_replay':False,'rh_proven':False}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);args=p.parse_args()
    Path(args.output).write_text(json.dumps(run(),sort_keys=True,indent=2)+'\n')
