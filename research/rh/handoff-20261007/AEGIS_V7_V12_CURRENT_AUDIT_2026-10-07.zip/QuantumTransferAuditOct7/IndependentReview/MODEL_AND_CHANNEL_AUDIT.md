# Independent mathematical audit of the uploaded V7/V12 operator packet

7 October 2026. Reviewer: /root/signed_arithmetic_bridge_oct7. This audit
reads the supplied sources and proves a source-specific channel counterexample.
It does not run the expensive numerical worker, a QPU, Lean or an RH proof.
All archive sources and earlier research folders remain unchanged.

## 1. What V7/V12 actually denote here

The supplied README, REPORT_BHS and MEASUREMENT_CONTRACT explicitly classify
the work as numerical simulation with empirical authority NONE. V7 and V12
are coupling-operator predictive-model/replication versions. Their actual
Hamiltonian is the4-dimensional two-qubit matrix

    H=J Z_0 Z_1+h(X_0+X_1),
    S_TRANSVERSE=X_0+0.73 X_1,
    S_MIXED=Z_0+0.73 X_1.

These definitions occur literally in both holdout workers. The V12 model
is an already fitted per-operator standardized linear predictor with17
features; its frozen JSON contains separate coefficient, mean and scale
arrays for the two operator names. It is not a theorem that its outputs
represent true channel errors on arbitrary H or arbitrary operators.

For one context the code constructs three superoperators:

    E_sec=exp[(L_H+D(diag rates))/Gamma],
    E_base=exp[(L_H+D(K))/Gamma],
    E_abl=exp[(L_H+D(K_abl))/Gamma],
    Gamma=max rates, tau=tau_factor/Gamma.

K_abl removes the nearest distinct-frequency pair's two off-diagonal
entries. The code-defined error is the maximum over the eight listed
input states of half the trace norm of the HERMITIAN PART of the output
difference. For ideal Hermiticity-preserving maps this is the ordinary
state trace distance. The measured target is

    reduction=(baseline_error-ablated_error)/baseline_error,

with a conventional0 output when the denominator is zero. It is a
finite-probe error-reduction statistic, not a channel or diamond norm.
The V12 analysis averages24 such contexts for each(id,operator,beta),
then compares the frozen predictor with those12 shard means.

For positive baseline_error, this reduction is always ≤1 because the
ablated error is nonnegative. It has no uniform lower bound when the
baseline approaches zero. In particular the preserved V7 global
predictions around6-9 cannot be physically interpreted as fractional
reductions. The bounded V7 claim already reports that mismatch. This
does not justify incorrectly restricting negative reductions to[-1,1].

## 2. What Gram positivity does and does not supply

The exact mathematical integral represented by exact_bath_K is

    K_ij=(lambda²/tau)∫_0^M [b_down(nu) I(omega_i-nu)I(omega_j-nu)
                        +b_up(nu) I(omega_i+nu)I(omega_j+nu)]dnu,
    I(x)=tau sinc(x tau/2).

For beta,tau>0 and M≥0, both bath weights are nonnegative, and all these
integrands are integrable on the finite interval. Thus for every complex
vector z,

    z* K z=(lambda²/tau)∫[b_down |sum z_j I(omega_j-nu)|²
                         +b_up |sum z_j I(omega_j+nu)|²]dnu≥0.   (1)

Likewise the factorized_K function's mathematical sinc kernel satisfies

    sinc((omega_i-omega_j)tau/2)
      =(1/tau)∫_{-tau/2}^{tau/2}exp[i(omega_i-omega_j)u]du,

so it is a Gram matrix. Conjugating by the real diagonal sqrt(rates)
preserves positive semidefiniteness. These are valid finite Gram facts.
The exact integral is positive; a floating-point quadrature approximation
does not acquire an exact eigenvalue certificate from the function name.

Deleting a single off-diagonal pair does NOT preserve PSD in general.
For the exact rank-one Gram matrix K=ones(3,3), deleting K_01,K_10 gives

    K_abl=[[1,0,1],[0,1,1],[1,1,1]].

Its determinant is-1; for v=(1,1,-1), v^T K_abl v=-1. This is a
counterexample to the universal deletion rule, not a claim that the
particular simulated K_abl matrices in this archive are indefinite.

For a Hermitian K the displayed dissipator preserves trace algebraically.
For PSD K its exact finite-dimensional generator has the usual Lindblad
positive-rate decomposition, yielding a CPTP semigroup. A Hermitian
K_abl alone does not establish that decomposition. The worker never calls
the available core min_choi diagnostic and does not save a Choi PSD
certificate. The package's REPORT_BHS correctly preserves positivity of
the ablated generator outside tested points as an unresolved obligation.

## 3. Exact blindness of these eight probes

The source-defined mathematical probe set consists of four computational
basis projectors, the projectors of

    (|0>+|3>)/sqrt2, (|1>+|2>)/sqrt2,
    (|0>+|1>+|2>+|3>)/2,

and one mixed state sigma. In the ideal mathematical interpretation the
last state is G G*/Tr(G G*) for a nonzero complex G. The seven preceding
states are real symmetric. No exact binary NumPy Hermiticity or a specific
random matrix value is being assumed in the following theorem: sigma
can be ANY genuine density matrix.

Define the Hermitian traceless matrices

    F_01=i(|0><1|-|1><0|),
    F_02=i(|0><2|-|2><0|),
    s_1=Tr(F_01 sigma), s_2=Tr(F_02 sigma).

Both s_j are real; explicitly s_j=2 Im(sigma_0j). Every real symmetric
probe rho is orthogonal to both F matrices under Tr(F rho). Choose

    if (s_1,s_2)!=(0,0):
      A=s_2 F_01-s_1 F_02, r=sqrt(s_1²+s_2²);
    otherwise:
      A=F_01, r=1.
    Ahat=A/r.                                              (2)

In either case Ahat is Hermitian, traceless and nonzero; its eigenvalues
are1,-1,0,0. This follows directly from its3x3 star block, whose
characteristic polynomial is lambda(lambda²-r²), plus the fourth zero
row. Its operator norm is1. By construction

    Tr(Ahat rho_j)=0 for EACH of the eight source probes.    (3)

The mixed-state pairing is (s_2 s_1-s_1 s_2)/r=0 in the nonzero branch;
the zero branch also gives0. Thus adding one arbitrarily complex mixed
probe does not repair the seven real probes' imaginary-coherence blind
direction.

## 4. Two genuine channels indistinguishable on all eight probes

Put B=diag(1,-1,0,0), epsilon=1/8, and define complex-linear maps on all
4x4 matrices by

    D(X)=Tr(X) I_4/4,
    Phi(X)=D(X)+epsilon Tr(Ahat X) B.                        (4)

They are BOTH CPTP. Trace preservation follows from Tr(B)=0. In the
exact unnormalized block Choi convention used by core.choi,

    J(D)=I_16/4,
    J(Phi)=I_16/4+epsilon Ahat^T tensor B.                   (5)

To check the transpose, the(i,j) block of the perturbation is
epsilon Tr(Ahat E_ij)B=epsilon Ahat_ji B, which is exactly the indicated
tensor product. Ahat^T is Hermitian with norm1, and ||B||_op=1. Therefore

    J(Phi)≥(1/4-epsilon) I_16=I_16/8>0.                    (6)

The Choi positivity criterion in finite dimensions follows by factoring
the positive matrix into vectorized Kraus vectors, so(6) gives complete
positivity without relying on numerical eigenvalues. Both channels
produce valid density states, not merely Hermitian matrices.

By(3), Phi(rho_j)=D(rho_j) for all eight probes. Their finite-probe
maximum trace distance is EXACTLY zero. For a normalized eigenvector
v of Ahat with eigenvalue1,

    Phi(|v><v|)-D(|v><v|)=epsilon B,
    0.5||Phi(|v><v|)-D(|v><v|)||_1=epsilon=1/8.             (7)

The corresponding diamond norm is exactly1/4, not just nonzero. Let
Delta=Phi-D. For any ancillary dimension and any input X, rearranging
tensor factors gives

    (Delta tensor id)(X)
       =epsilon B tensor Tr_input[(Ahat tensor I)X].

Finite-dimensional trace/operator-norm duality implies

    ||Tr_input[(Ahat tensor I)X]||_1≤||Ahat||_op ||X||_1.

Indeed pair the left side with any ancillary Y of operator norm≤1 and
apply |Tr((Ahat tensor Y*)X)|≤||Ahat tensor Y*||_op||X||_1.
Since ||B||_1=2, the upper diamond bound is2epsilon=1/4. Equation(7),
already with no ancilla, gives the matching lower bound.

Consequently for this exact probe geometry there exists NO finite C
such that the full or half diamond distance between arbitrary CPTP
channels is bounded by C times the maximum trace distance on these
eight probes. The right side can be0 and the left side1/4 or1/8.
This is not a counterexample within the particular restricted bath
family. A theorem using that restricted family needs additional proved
identifiability or structural assumptions; the finite-probe data alone
do not supply them.

The accompanying stdlib Fraction/Gaussian-rational checker verifies one
fully rational example in each branch of(2). It does not numerically
reconstruct the mixed_seed_41 state or assert equality of any actual
NumPy channel. The proof above applies to every genuine sigma, which
is stronger than one numerical mixed-state test.

## 5. Prediction and statistical audit scope

The checked analysis code computes per-shard and four-cluster MAEs,
then enumerates16 sign assignments and256 cluster bootstrap draws.
This is finite exhaustive enumeration on floating-point saved data;
"exact" here refers to enumeration of the assignments, not an
interval certificate for physical/model-form error. Sign-flip p-values
need a symmetry/exchangeability null if interpreted probabilistically;
the deliberately selected four Hamiltonian/operator clusters are not
automatically a random population sample. Cluster-bootstrap percentile
endpoints likewise are resampling statistics, not distribution-free
95% guaranteed coverage. Their displayed finite values can still be
reproduced and provide useful descriptive falsification.

V7's best frozen threshold is selected retrospectively from five options
for descriptive comparison against zero. The primary script explicitly
labels it descriptive. The observation that even this selected option
loses in all four clusters is stronger than evidence from selecting a
worse threshold; it does not license a post-selection significance claim.

The prospective MEASUREMENT_CONTRACT is DESIGN_ONLY_NOT_EXECUTED. Its
calibration and shot records are requirements for a future physical test,
not included empirical authority. A reported quad_vec error estimate,
a cutoff80/100 comparison or byte equality is not a uniform interval
bound on quadrature, cutoff tails or the matrix exponential. This audit
does not independently perform that expensive simulation replay.

## 6. RH transport: exact search scope and reusable content

The reviewed outer files are the README, REPORT_BHS, MEASUREMENT_CONTRACT,
CHECKPOINT, both holdout workers, the V12 context worker, bath core,
frozen per-operator model, preregistrations and primary analysis/verifier.
A text search of the extracted outer code/report sources for actual RH
objects (RiemannHypothesis, Weil, zeta, Mellin, detectingPacket) found no
explicit mathematical object identification or property-preserving map.
No Lean/Coq theorem source was found by the corresponding outer filename
scan. Nested ZIP proof content outside the read sources and all other
project branches are NOT ruled out by this scope. V7/V12 names are not
RH zero-kernel version identifiers merely because their numbers coincide.

The finite Gram identity(1) can be reused as a positive weighted kernel
lemma. The explicit source-specific counterexample(2)-(7) can be reused
to reject an unpaid finite-probe-to-channel-norm bridge. Neither lemma
identifies the positive bath weights or finite Hamiltonian spectrum with
the actual signed prime/Gamma/zero Weil form. Such an identification would
need its own exact objects, domains, normalization, mixed terms and
quantifier transport. This archive's predictive transfer decision does
not currently produce the fixed detecting packet sign or RH.

RH_PROVEN=false. This audit establishes a genuine mathematical
counterexample to a generic auxiliary transfer principle; it does not
refute RH, the actual bath channels, or every possible restricted-family
identifiability theorem.
