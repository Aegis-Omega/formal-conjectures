# Independent source/model/channel review

`MODEL_AND_CHANNEL_AUDIT.md` reconstructs the actual two-qubit model and
proves an explicit counterexample for its eight-probe geometry: two CPTP
channels agree on every probe, yet have diamond distance1/4. The half trace
distance on another state is1/8. This rejects a universal finite-probe-to-
channel-norm bound, not the particular simulated bath channels or RH.

The general proof was independently reconstructed by /root; its separate
receipt is `RootReview/RECEIPT.json`. Both agents ran the stdlib exact
matrix checker normally and with python-O:38 comparisons and3 rejection
guards, byte-identical outputs. This is ordinary mathematical review and
finite exact arithmetic, not Lean/kernel verification or a hardware run.

Reproduce the finite examples into NEW paths:

```sh
python3 check_channel_witness.py --output /tmp/channel-review-normal.json
python3 -O check_channel_witness.py --output /tmp/channel-review-optimized.json
cmp /tmp/channel-review-normal.json /tmp/channel-review-optimized.json
```

`STATIC_PREDICTION_RECONSTRUCTION.json` records a separate stdlib Fraction
reconstruction of the12 V12 frozen predictions. For each saved CSV row,
the calculation is `intercept+sum(coef*(feature-mean)/scale)` across all17
features, using the exact decimal strings as rational numbers. All saved
predictions differ from this calculation by at most the explicit radius
1/10^12. The radius covers compatibility of saved floating-point model
values; it is not a physical or analytic model-error certificate.

`RH_SEARCH_SCOPE.json` records an actual search of377 extracted outer
text files, with no relevant RH identifier matches and no outer Lean/Coq
source filenames. Nested ZIP contents and other project branches are
outside that search scope. No inference of global absence follows.

The original incoming archive and earlier frozen RH folders were not
modified. `RH_PROVEN=false`; no mathematical transfer from these bath
objects to the actual Weil/RH objects was recovered in the reviewed scope.
