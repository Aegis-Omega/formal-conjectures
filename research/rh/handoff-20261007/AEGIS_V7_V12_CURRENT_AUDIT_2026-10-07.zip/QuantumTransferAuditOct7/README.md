# V7/V12 operator packet: current read, replay and exact channel audit

The supplied versions describe a finite two-qubit bath/operator prediction
experiment. The inspected source supplies no map to the actual zeta/Weil
objects. RH_PROVEN=false; the prior pinned RH source checkpoint remains
unchanged and its DenseFixedPacketSign obligation has no new producer here.

PACKET.zip contains the exact uploaded bytes, SHA256
`a228858479c0eadeee457a9e8f5d831beaf0273b2292e2125888147717faa34d`.
All392 file bytes were extracted safely and bound in the outer source
manifest. Its delivered SHA256SUMS checks390 rows but omits the included
stable/v7_outer/SHA256SUMS.txt; the actual initial rejection and the explicit
scope repair are preserved. Delivered source bytes were not edited.

A fresh standard-library prepare/analyze/verify replay reproduces the
complete saved analysis and all156 saved context/outcome byte comparisons.
The checker passes normal and optimized Python and rejects a deliberately
incorrect count in both. This execution did not repeat the288-context
numerical simulation or execute hardware, a QPU or a Lean proof.

V12 has2/4 cluster wins, sign-flip enumeration0.75 and bootstrap endpoints
[-0.0520466322246535,0.0073321791130267384]. Almost all positive gain is in
one cluster. The exact decision is HOLD_NOT_CLUSTER_ROBUST. These are finite
float/resampling statistics, not rigorous numerical or physical bounds.

The separately authored and root-reconstructed channel manuscript establishes
an exact counterexample specific to the eight ideal source-defined probes:
two CPTP channels agree on every probe yet have diamond distance1/4.
It also gives an exact3x3 counterexample to preserving PSD by deleting one
off-diagonal pair. Neither counterexample asserts failure of the particular
simulated bath channels. Read its source domains and finite-check boundaries.

For a NEW working copy of this audit directory, verify PACKET.zip's hash,
extract its already path/CRC-reviewed contents into Incoming, then run:

    python3 replay_packaged_analysis.py

The wrapper creates NEW output directories and refuses overwrite. It uses
only checked standard-library analysis code from the byte-bound packet.
The saved README's naive prepare command rejects the already-present stable
directory; the wrapper preserves it and rebuilds in a separate copy.
IndependentReview/check_channel_witness.py accepts --output for a fresh
finite exact witness check; it does not prove the general analytic theorem
by execution. Original receipt absolute paths refer to actual executed
contexts, not promised new standalone environments.

This unit is a separate local source/history addition. No remote changes or
new final-RH axiom/build/replay claims result from it.
